import { describe, expect, it, vi } from "vitest";
import { clampAssistantPosition, getDefaultAssistantPosition } from "./publicAiAssistantPosition";

describe("PublicAiAssistant position helpers", () => {
  it("keeps the default mobile button inside the viewport with a safe bottom offset", () => {
    vi.stubGlobal("window", { innerWidth: 390, innerHeight: 844 });

    expect(getDefaultAssistantPosition()).toEqual({ left: 256, top: 716 });
  });

  it("clamps dragged mobile positions to the actual button bounds", () => {
    vi.stubGlobal("window", { innerWidth: 390, innerHeight: 844 });

    expect(clampAssistantPosition({ left: -100, top: -50 })).toEqual({ left: 16, top: 16 });
    expect(clampAssistantPosition({ left: 1000, top: 1000 })).toEqual({ left: 256, top: 788 });
  });

  it("uses a wider desktop button without allowing it to leave the viewport", () => {
    vi.stubGlobal("window", { innerWidth: 1280, innerHeight: 720 });

    expect(getDefaultAssistantPosition()).toEqual({ left: 1132, top: 580 });
    expect(clampAssistantPosition({ left: 2000, top: 2000 })).toEqual({ left: 1132, top: 660 });
  });
});
