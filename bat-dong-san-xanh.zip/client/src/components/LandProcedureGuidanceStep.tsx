import { useMemo, useRef, useState } from "react";
import { CheckCircle2, Eye, FileDown, FileText, Search, Sparkles, Trash2, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { landDossierBuilderBundle, landDossierBuilderTemplates } from "@/pages/LandDossierBuilder";
import { trpc } from "@/lib/trpc";

export type GuidanceProperty = {
  title?: string | null;
  location?: string | null;
  propertyType?: string | null;
  transactionType?: string | null;
  area?: string | number | null;
  legalStatus?: string | null;
};

type Evidence = { name: string; size: number; type: string; status: "uploaded" | "ocr" | "analysis" | "review" | "error"; progress: number; stage: string };
type GuidanceBundleItem = { id: string; label: string; category: string; required?: boolean; condition?: string };
type GuidanceProcedureOption = { id: string; code: string; label: string; keywords: string; authority?: string | null; groupName?: string | null };

const procedureOptions: GuidanceProcedureOption[] = [
  { id: "transfer", label: "Chuyển nhượng / sang tên", keywords: "đất nhà căn hộ biệt thự nghỉ dưỡng villa resort dự án" },
  { id: "lease", label: "Cho thuê / cho thuê lại", keywords: "cho thuê đất nông nghiệp thương mại khu công nghiệp dự án resort" },
  { id: "gift", label: "Tặng cho", keywords: "đất nhà căn hộ" },
  { id: "inheritance", label: "Thừa kế", keywords: "đất nhà căn hộ" },
  { id: "purpose-change", label: "Chuyển mục đích sử dụng", keywords: "đất nông nghiệp đất thương mại đất dự án" },
  { id: "split-merge", label: "Tách thửa / hợp thửa", keywords: "đất nền đất nông nghiệp đất dự án" },
  { id: "certificate", label: "Đăng ký, cấp Giấy chứng nhận", keywords: "mọi loại bất động sản" },
  { id: "tax", label: "Thuế, lệ phí và nghĩa vụ tài chính", keywords: "chuyển nhượng cho thuê mọi loại bất động sản" },
  ] as GuidanceProcedureOption[];

const propertyLabels: Record<string, string> = {
  land: "Đất nền", agricultural: "Đất nông nghiệp", commercial_land: "Đất thương mại", commercial: "Khu thương mại", industrial: "Đất/khu công nghiệp", project: "Đất dự án", apartment: "Căn hộ", house: "Nhà phố", villa: "Villa", resort: "Khu nghỉ dưỡng / resort",
};

function propertyLabel(property?: GuidanceProperty) {
  const raw = String(property?.propertyType || "").toLowerCase();
  return propertyLabels[raw] || property?.propertyType || "Bất động sản chưa phân loại";
}

function normalizeProcedureText(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/đ/g, "d")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function procedureSearchScore(item: GuidanceProcedureOption, query: string) {
  const normalizedQuery = normalizeProcedureText(query);
  if (!normalizedQuery) return 1;
  const haystack = normalizeProcedureText(`${item.label} ${item.keywords}`);
  const queryTokens = normalizedQuery.split(" ").filter(token => token.length > 1 && !["xin", "cho", "cua", "va", "theo", "voi"].includes(token));
  const matchedTokens = queryTokens.filter(token => haystack.includes(token)).length;
  if (haystack.includes(normalizedQuery)) return 100;
  if (matchedTokens === queryTokens.length && queryTokens.length > 0) return 80 + matchedTokens;
  if (matchedTokens > 0) return 40 + matchedTokens;
  const synonyms: Record<string, string[]> = {
    "trich luc": ["certificate", "data-request"],
    "ban do dia chinh": ["certificate", "data-request"],
    "sang ten": ["transfer"],
    "mua ban": ["transfer"],
    "tach thua": ["split-merge"],
    "hop thua": ["split-merge"],
    "thue phi": ["tax"],
  };
  return Object.entries(synonyms).some(([phrase, ids]) => normalizedQuery.includes(phrase) && ids.includes(item.id)) ? 30 : 0;
}

function procedureTemplates(procedureId: string) {
  const normalized = procedureId === "split-merge" ? "parcel-change" : procedureId;
  return [...landDossierBuilderTemplates(normalized), ...landDossierBuilderBundle(normalized)];
}

export function landProcedureBundleFor(procedureId: string): GuidanceBundleItem[] {
  return procedureTemplates(procedureId).map(item => ({
    id: item.id,
    label: item.label,
    category: "category" in item ? item.category : "form",
    required: "required" in item ? item.required : undefined,
    condition: "condition" in item ? item.condition : undefined,
  }));
}

export function landProcedurePreviewFor(template: GuidanceBundleItem, property: GuidanceProperty | undefined, procedureId: string) {
  return {
    title: template.label,
    procedureId,
    propertyTitle: property?.title || "Chưa nhập",
    propertyType: propertyLabel(property),
    location: property?.location || "Chưa nhập",
    area: property?.area ? `${property.area} m²` : "Chưa nhập",
    legalStatus: property?.legalStatus || "Chưa xác nhận",
    sourceStatus: template.condition || "Bản nháp cần đối chiếu theo địa phương",
  };
}

export function landProcedureGuidanceSuggestion(property?: GuidanceProperty) {
  const raw = `${property?.transactionType || ""} ${property?.propertyType || ""}`.toLowerCase();
  if (raw.includes("lease") || raw.includes("thuê")) return "lease";
  if (raw.includes("inheritance") || raw.includes("thừa")) return "inheritance";
  if (raw.includes("gift") || raw.includes("tặng")) return "gift";
  return "transfer";
}

export function LandProcedureGuidanceStep({ property, initialProcedureId, evidence, onUpload, onDelete, onBuildBundle }: { property?: GuidanceProperty; initialProcedureId?: string; evidence: Evidence[]; onUpload: (file: File) => void; onDelete: (name: string) => void; onBuildBundle: (procedureId: string, bundle: GuidanceBundleItem[]) => void }) {
  const suggested = initialProcedureId || landProcedureGuidanceSuggestion(property);
  const [procedureId, setProcedureId] = useState(suggested);
  const [query, setQuery] = useState("");
  const procedureCatalogQuery = trpc.legalKnowledge.procedures.useQuery({});
  const dynamicProcedureOptions = useMemo<GuidanceProcedureOption[]>(() => {
    const rows = procedureCatalogQuery.data ?? [];
    if (!rows.length) return procedureOptions;
    return rows.map(row => {
      let aliases: string[] = [];
      try { aliases = row.aliases ? JSON.parse(row.aliases) : []; } catch { aliases = []; }
      return { id: row.code, code: row.code, label: row.name || `Mã TTHC ${row.code}`, keywords: [row.groupName, ...aliases].filter(Boolean).join(" · "), authority: row.authority, groupName: row.groupName };
    });
  }, [procedureCatalogQuery.data]);
  const [previewTemplate, setPreviewTemplate] = useState<GuidanceBundleItem | null>(null);
  const [previewProcedureId, setPreviewProcedureId] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const guidanceDetailsRef = useRef<HTMLDivElement>(null);
  const filtered = useMemo(() => dynamicProcedureOptions
    .map(item => ({ item, score: procedureSearchScore(item, query) }))
    .filter(result => !query.trim() || result.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(result => result.item), [query]);
  const selected = dynamicProcedureOptions.find(item => item.id === procedureId) || dynamicProcedureOptions[0];
  const templates = procedureTemplates(procedureId);
  const propertyName = propertyLabel(property);
  const procedureTitle = selected.label;
  const checklist = procedureId === "lease"
    ? ["Giấy chứng nhận và quyền cho thuê", "Thông tin bên cho thuê và bên thuê", "Hợp đồng cho thuê/cho thuê lại", "Hồ sơ đăng ký biến động nếu thuộc trường hợp phải đăng ký", "Tờ khai và nghĩa vụ tài chính theo trường hợp"]
    : procedureId === "tax"
      ? ["Thông tin chủ thể và giao dịch", "Giá trị, diện tích và loại tài sản", "Tờ khai thuế phù hợp", "Tờ khai lệ phí trước bạ nếu phát sinh", "Chứng từ miễn/giảm hoặc nộp tiền"]
      : ["Giấy chứng nhận bản gốc và dữ liệu thửa đất", "CCCD/giấy tờ nhân thân của các bên", "Hợp đồng hoặc văn bản giao dịch", "Hồ sơ công chứng và xác nhận tình trạng hôn nhân khi cần", "Tờ khai thuế, lệ phí và hồ sơ đăng ký biến động"];

  return <section className="mt-5 rounded-2xl border-2 border-[#BFD2C5] bg-white p-5 shadow-sm sm:p-6" data-testid="land-procedure-guidance-step">
    <div className="flex flex-col gap-4 border-b border-[#E1EAE3] pb-4 lg:flex-row lg:items-end lg:justify-between">
      <div><div className="inline-flex rounded-full bg-[#F4E7BF] px-3 py-1.5 text-[11px] font-black uppercase tracking-[0.16em] text-[#80601C]">Bước 2 · Quy trình thủ tục hướng dẫn</div><h3 className="mt-2 text-2xl font-black text-[#18352D]">AI phân tích đường đi hồ sơ từ giao dịch đến hoàn tất</h3><p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">Dữ liệu từ Bước 1 được dùng để gợi ý thủ tục, bộ giấy tờ và mẫu cần rà soát. Hệ thống không thay thế công chứng viên, cơ quan thuế hoặc cơ quan đăng ký đất đai.</p></div>
      <div className="rounded-xl bg-[#EAF2ED] px-4 py-3 text-xs text-[#1F5A4A]"><p className="font-black">BĐS đang phân tích</p><p className="mt-1 font-bold">{property?.title || "Chưa gắn BĐS"} · {propertyName}</p><p className="mt-1">{property?.location || "Chưa có địa chỉ"}</p></div>
    </div>
    <div className="mt-4 grid gap-4 lg:grid-cols-[.9fr_1.1fr]">
      <div className="rounded-xl border border-[#D8E4DC] bg-[#F7FBF7] p-4"><p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">AI chọn nguồn thủ tục · {procedureCatalogQuery.isLoading ? "đang tải catalog" : `${dynamicProcedureOptions.length} thủ tục đã đồng bộ`}</p><div className="relative mt-2"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-[#7B9186]"/><Input value={query} onChange={event => setQuery(event.target.value)} className="bg-white pl-9" placeholder="Tìm tên thủ tục gần giống, ví dụ trích lục bản đồ..." aria-label="Tìm quy trình thủ tục"/></div><div className="mt-3 space-y-2">{filtered.map(item => <div key={item.id} className={`rounded-lg border p-3 ${item.id === procedureId ? "border-[#1F5A4A] bg-[#EAF2ED]" : "border-[#D8E4DC] bg-white"}`}><div className="flex items-start justify-between gap-2"><button type="button" onClick={() => setProcedureId(item.id)} className="min-w-0 flex-1 text-left"><span className="flex items-center gap-2 text-sm font-black text-[#18352D]">{item.label}{item.id === procedureId && <CheckCircle2 className="h-4 w-4 text-[#1F5A4A]"/>}</span><span className="mt-1 block text-[11px] leading-4 text-[#60766D]">Mã TTHC: {item.code} · {item.groupName || "Nguồn thủ tục đã đồng bộ"}</span><span className="mt-1 block text-[11px] leading-4 text-[#60766D]">Từ khóa: {item.keywords || "Đang bổ sung từ khóa"}</span></button><div className="flex shrink-0 gap-1"><Button type="button" variant="outline" className="h-8 px-2 text-[10px]" onClick={() => { setPreviewProcedureId(item.id); requestAnimationFrame(() => guidanceDetailsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" })); }}><Eye className="mr-1 h-3.5 w-3.5"/>Xem</Button><Button type="button" className="h-8 bg-[#1F5A4A] px-2 text-[10px] hover:bg-[#164637]" onClick={() => { setProcedureId(item.id); setPreviewProcedureId(null); }}>Chọn</Button></div></div></div>)}</div></div>
      <div ref={guidanceDetailsRef} id="land-procedure-guidance-details" className="rounded-xl border border-[#D8E4DC] bg-[#FBFDFB] p-4"><p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">Kết quả phân tích sơ bộ</p><h4 className="mt-1 text-xl font-black text-[#18352D]">{procedureTitle} · {propertyName}</h4>{previewProcedureId && <p className="mt-2 rounded-lg bg-[#EAF2ED] p-2 text-xs font-semibold text-[#1F5A4A]">Đang xem hướng dẫn: {dynamicProcedureOptions.find(item => item.id === previewProcedureId)?.label}</p>}<div className="mt-3 grid gap-2 sm:grid-cols-2">{["Sau giao dịch/công chứng: hoàn thiện văn bản và hồ sơ chủ thể", "Kê khai thuế, lệ phí và lưu chứng từ", "Nộp đăng ký biến động hoặc thủ tục tương ứng", "Theo dõi phiếu tiếp nhận, bổ sung và nhận kết quả"].map((step, index) => <div key={step} className="flex gap-2 rounded-lg bg-[#F7FBF7] p-3 text-xs leading-5 text-[#50685D]"><span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#1F5A4A] text-[10px] font-black text-white">{index + 1}</span>{step}</div>)}</div><div className="mt-4 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3"><p className="text-xs font-black text-[#6F5520]">Giấy tờ cần chuẩn bị</p><ul className="mt-2 space-y-1 text-xs leading-5 text-[#6F5520]">{checklist.map(item => <li key={item}>• {item}</li>)}</ul></div></div>
    </div>
    <div className="mt-4 rounded-xl border border-[#D8E4DC] bg-white p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">Kho biểu mẫu liên quan</p><p className="mt-1 text-sm font-black text-[#18352D]">{templates.length} tài liệu trong bộ hồ sơ · {dynamicProcedureOptions.length} thủ tục trong catalog · gồm mẫu chính, giấy tờ kèm theo và nghĩa vụ tài chính</p></div><Button type="button" onClick={() => onBuildBundle(procedureId, landProcedureBundleFor(procedureId))} className="bg-[#1F5A4A] hover:bg-[#164637]"><Sparkles className="mr-2 h-4 w-4"/>Dựng bộ hồ sơ tham khảo</Button></div><div className="mt-3 grid gap-2 md:grid-cols-2">{templates.map(template => <div key={template.id} className="flex items-start gap-2 rounded-lg bg-[#F7FBF7] p-3"><FileText className="mt-0.5 h-4 w-4 shrink-0 text-[#1F5A4A]"/><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><div className="flex flex-wrap items-center gap-2"><p className="text-xs font-bold text-[#18352D]">{template.label}</p>{"required" in template && template.required && <span className="rounded-full bg-[#EAF2ED] px-2 py-0.5 text-[9px] font-black text-[#1F5A4A]">Cần chuẩn bị</span>}</div><Button type="button" variant="outline" className="h-7 px-2 text-[10px]" onClick={() => setPreviewTemplate({ id: template.id, label: template.label, category: "category" in template ? template.category : "form", required: "required" in template ? template.required : undefined, condition: "condition" in template ? template.condition : undefined })}><Eye className="mr-1 h-3.5 w-3.5"/>Xem trước</Button></div><p className="mt-1 text-[10px] leading-4 text-[#60766D]">{"category" in template ? template.category : "supporting"} · {"condition" in template && template.condition ? template.condition : "Bản nháp cần đối chiếu theo địa phương"}</p></div></div>)}</div><p className="mt-3 text-[11px] leading-4 text-[#6F5520]">Nguồn pháp lý và biểu mẫu chính thức phải được kiểm tra theo cổng dịch vụ công, cơ quan tiếp nhận và thời điểm nộp. Không tự động coi bản tham khảo là văn bản chính thức.</p></div>
    <div className="mt-4 rounded-xl border border-[#D8E4DC] bg-[#F7FBF7] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">Ảnh / video / tệp hồ sơ</p><p className="mt-1 text-sm text-[#60766D]">Tải từ máy hoặc camera để AI tiếp tục OCR và phân tích. Tệp giấy tờ không được đưa vào ảnh marketing công khai.</p></div><><input ref={inputRef} type="file" accept="image/*,video/*,.pdf,.doc,.docx" multiple className="hidden" onChange={event => { Array.from(event.target.files || []).forEach(onUpload); event.currentTarget.value = ""; }}/><Button type="button" variant="outline" onClick={() => inputRef.current?.click()}><Upload className="mr-2 h-4 w-4"/>Tải ảnh/video/tệp</Button></></div>{evidence.length > 0 ? <div className="mt-3 space-y-2">{evidence.map(item => <div key={`${item.name}-${item.size}`} className="flex flex-col gap-2 rounded-lg border border-[#D8E4DC] bg-white p-3 sm:flex-row sm:items-center sm:justify-between"><div className="min-w-0"><p className="truncate text-xs font-bold text-[#18352D]">{item.name}</p><p className="text-[10px] text-[#60766D]">{item.stage} · {Math.round(item.size / 1024)} KB</p></div><div className="flex items-center gap-2"><span className="text-[10px] font-black text-[#1F5A4A]">{item.progress}%</span><Button type="button" variant="outline" className="h-8 px-2 text-xs" onClick={() => onDelete(item.name)}><Trash2 className="mr-1 h-3.5 w-3.5"/>Xóa</Button></div></div>)}</div> : <div className="mt-3 rounded-lg border border-dashed border-[#BFD2C5] bg-white p-4 text-center text-xs text-[#60766D]">Chưa có ảnh, video hoặc tài liệu đầu vào.</div>}</div>
    {previewTemplate && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#102B24]/55 p-4" role="dialog" aria-modal="true" aria-label={`Xem trước ${previewTemplate.label}`}><div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-[#F8FBF8] shadow-2xl"><div className="sticky top-0 flex items-start justify-between gap-4 border-b border-[#D8E4DC] bg-white p-4 sm:p-5"><div><p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">Bản xem trước biểu mẫu</p><h4 className="mt-1 text-xl font-black text-[#18352D]">{previewTemplate.label}</h4><p className="mt-1 text-xs text-[#60766D]">{procedureTitle} · {propertyName}</p></div><Button type="button" variant="outline" className="h-9 w-9 shrink-0 p-0" aria-label="Đóng xem trước" onClick={() => setPreviewTemplate(null)}><X className="h-4 w-4"/></Button></div><div className="p-4 sm:p-6"><div className="rounded-xl border border-[#D8E4DC] bg-white p-5 text-[#18352D] sm:p-8"><div className="text-center"><p className="text-xs font-bold uppercase tracking-[0.12em]">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p><p className="mt-1 text-[10px] font-semibold">Độc lập - Tự do - Hạnh phúc</p><div className="mx-auto mt-4 h-px w-24 bg-[#18352D]"/><h5 className="mt-5 text-lg font-black uppercase">{previewTemplate.label}</h5><p className="mt-2 text-xs text-[#60766D]">Bản dự thảo điền từ dữ liệu Hồ sơ đất đai AI</p></div><div className="mt-6 grid gap-3 text-sm sm:grid-cols-2"><div className="border-b border-dashed border-[#BFD2C5] pb-2"><span className="text-xs text-[#60766D]">Bất động sản</span><p className="font-semibold">{property?.title || "Chưa nhập"}</p></div><div className="border-b border-dashed border-[#BFD2C5] pb-2"><span className="text-xs text-[#60766D]">Loại tài sản</span><p className="font-semibold">{propertyName}</p></div><div className="border-b border-dashed border-[#BFD2C5] pb-2"><span className="text-xs text-[#60766D]">Địa chỉ</span><p className="font-semibold">{property?.location || "Chưa nhập"}</p></div><div className="border-b border-dashed border-[#BFD2C5] pb-2"><span className="text-xs text-[#60766D]">Diện tích</span><p className="font-semibold">{property?.area ? `${property.area} m²` : "Chưa nhập"}</p></div><div className="border-b border-dashed border-[#BFD2C5] pb-2"><span className="text-xs text-[#60766D]">Pháp lý</span><p className="font-semibold">{property?.legalStatus || "Chưa xác nhận"}</p></div><div className="border-b border-dashed border-[#BFD2C5] pb-2"><span className="text-xs text-[#60766D]">Mã thủ tục</span><p className="font-semibold">{procedureId}</p></div></div><div className="mt-6 min-h-28 rounded-lg border border-dashed border-[#BFD2C5] p-4 text-xs leading-6 text-[#60766D]"><p className="font-bold text-[#18352D]">Nội dung biểu mẫu</p><p className="mt-2">Các trường còn thiếu sẽ được AI điền sau khi dữ liệu OCR và thông tin các bên được người dùng xác nhận. Hãy kiểm tra bản gốc, nguồn pháp lý và yêu cầu của cơ quan tiếp nhận trước khi ký hoặc nộp.</p></div></div><div className="mt-4 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-4"><p className="text-xs font-black text-[#6F5520]">Trạng thái nguồn và an toàn pháp lý</p><p className="mt-1 text-xs leading-5 text-[#6F5520]">{previewTemplate.condition || "Bản nháp cần đối chiếu theo địa phương"}. Đây là bản xem trước tham khảo, không phải văn bản chính thức nếu chưa có tệp nguồn đã xác minh.</p></div><div className="mt-4 flex flex-wrap justify-end gap-2"><Button type="button" variant="outline" onClick={() => setPreviewTemplate(null)}>Đóng</Button><Button type="button" className="bg-[#1F5A4A] hover:bg-[#164637]" onClick={() => { onBuildBundle(procedureId, landProcedureBundleFor(procedureId)); setPreviewTemplate(null); }}><FileDown className="mr-2 h-4 w-4"/>Tiếp tục tạo bộ hồ sơ</Button></div></div></div></div>}
    <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl bg-[#123D32] p-4 text-white"><FileDown className="h-5 w-5 text-[#D8B15A]"/><p className="flex-1 text-xs leading-5 text-white/80">Bộ hồ sơ tạo ra là bản nháp tham khảo để bạn xem, chỉnh sửa, in và ký. Hãy đối chiếu bản gốc trước khi nộp.</p><Button type="button" variant="outline" className="border-white/30 bg-white/10 text-white hover:bg-white/20" onClick={() => onBuildBundle(procedureId, landProcedureBundleFor(procedureId))}>Tạo bộ hồ sơ</Button></div>
  </section>;
}
