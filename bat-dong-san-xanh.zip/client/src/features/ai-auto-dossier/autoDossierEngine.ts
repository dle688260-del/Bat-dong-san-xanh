export type AutoProcedure = {
  code: string;
  title: string;
  description?: string;
  source: string;
  category?: string;
};

export type AutoWorkflowStep = {
  id: string;
  title: string;
  description: string;
  requiresInput: boolean;
  source?: string;
};

export type ProcedureInputField = {
  key: string;
  label: string;
  type: "text" | "textarea" | "number" | "date" | "select";
  required: boolean;
  placeholder?: string;
  help?: string;
  options?: string[];
  group: "parties" | "land" | "request" | "financial" | "supporting";
};

const commonIdentityFields: ProcedureInputField[] = [
  { key: "applicantName", label: "Họ và tên người yêu cầu", type: "text", required: true, placeholder: "Nhập đúng theo giấy tờ nhân thân", group: "parties" },
  { key: "citizenId", label: "CCCD/giấy tờ nhân thân", type: "text", required: true, placeholder: "Số định danh hoặc giấy tờ tương ứng", group: "parties" },
  { key: "contactPhone", label: "Số điện thoại liên hệ", type: "text", required: false, placeholder: "Dùng để nhận thông báo hồ sơ", group: "parties" },
  { key: "contactAddress", label: "Địa chỉ liên hệ", type: "textarea", required: true, placeholder: "Số nhà, đường, xã/phường, tỉnh/thành", group: "parties" },
];

const landIdentityFields: ProcedureInputField[] = [
  { key: "landAddress", label: "Địa chỉ thửa đất", type: "textarea", required: true, placeholder: "Thôn/tổ, xã/phường, quận/huyện, tỉnh/thành", group: "land" },
  { key: "parcelNumber", label: "Số thửa", type: "text", required: false, placeholder: "Theo Giấy chứng nhận hoặc trích đo", group: "land" },
  { key: "mapSheetNumber", label: "Tờ bản đồ số", type: "text", required: false, placeholder: "Theo hồ sơ địa chính", group: "land" },
  { key: "area", label: "Diện tích (m²)", type: "number", required: false, placeholder: "Ví dụ: 120.5", group: "land" },
  { key: "certificateNumber", label: "Số Giấy chứng nhận", type: "text", required: false, placeholder: "Nếu đã được cấp", group: "land" },
];

export function getProcedureInputSchema(code: string, procedureName = ""): ProcedureInputField[] {
  const normalized = `${code} ${procedureName}`.toLocaleLowerCase("vi");
  if (code === "1.012789" || normalized.includes("cung cấp thông tin") || normalized.includes("dữ liệu đất đai")) {
    return [
      ...commonIdentityFields,
      { key: "requestedData", label: "Nội dung thông tin/dữ liệu cần cung cấp", type: "textarea", required: true, placeholder: "Nêu rõ loại dữ liệu, phạm vi và mục đích yêu cầu", group: "request" },
      { key: "deliveryMethod", label: "Hình thức nhận kết quả", type: "select", required: true, options: ["Trực tuyến", "Trực tiếp", "Bưu chính"], group: "request" },
      { key: "requestedTime", label: "Thời điểm/phạm vi dữ liệu cần tra cứu", type: "text", required: false, placeholder: "Ví dụ: hiện trạng tại thời điểm nộp", group: "request" },
    ];
  }
  if (code === "1.013978" || normalized.includes("đăng ký đất đai") || normalized.includes("cấp giấy chứng nhận lần đầu")) {
    return [
      ...commonIdentityFields,
      ...landIdentityFields,
      { key: "landOrigin", label: "Nguồn gốc và thời điểm sử dụng đất", type: "textarea", required: true, placeholder: "Mô tả theo giấy tờ và thực tế sử dụng; không tự suy đoán", group: "land" },
      { key: "attachedAssets", label: "Tài sản gắn liền với đất", type: "textarea", required: false, placeholder: "Nhà ở/công trình/cây lâu năm nếu có", group: "land" },
    ];
  }
  if (code === "2.000889" || /(chuyển nhượng|tặng cho|thừa kế|cho thuê|góp vốn|biến động)/i.test(normalized)) {
    return [
      { key: "transferor", label: "Bên chuyển quyền", type: "text", required: true, placeholder: "Họ tên/tổ chức theo giấy tờ", group: "parties" },
      { key: "transferee", label: "Bên nhận quyền", type: "text", required: true, placeholder: "Họ tên/tổ chức theo giấy tờ", group: "parties" },
      ...commonIdentityFields.filter(field => !["applicantName", "contactAddress"].includes(field.key)),
      ...landIdentityFields,
      { key: "transactionType", label: "Loại biến động", type: "select", required: true, options: ["Chuyển nhượng", "Tặng cho", "Thừa kế", "Cho thuê", "Góp vốn", "Khác"], group: "request" },
      { key: "transactionDate", label: "Ngày văn bản giao dịch", type: "date", required: false, group: "request" },
      { key: "transactionValue", label: "Giá trị giao dịch (VNĐ)", type: "number", required: false, placeholder: "Chỉ nhập theo hợp đồng/chứng từ", group: "financial" },
    ];
  }
  return [
    ...commonIdentityFields,
    ...landIdentityFields,
    { key: "requestContent", label: "Nội dung đề nghị/biến động", type: "textarea", required: true, placeholder: "Mô tả đúng yêu cầu của thủ tục đã chọn", group: "request" },
  ];
}

export function mapUploadTarget(componentId: string | undefined, componentName: string | undefined, fileName: string) {
  return { componentId: componentId || "general", componentName: componentName || "Tài liệu bổ sung chung", fileName };
}

export function groupProcedureFields(fields: ProcedureInputField[]) {
  return fields.reduce<Record<ProcedureInputField["group"], ProcedureInputField[]>>((groups, field) => {
    groups[field.group].push(field);
    return groups;
  }, { parties: [], land: [], request: [], financial: [], supporting: [] });
}


const categoryRules: Array<[RegExp, string]> = [
  [/(chuyển nhượng|tặng cho|thừa kế|giao dịch)/i, "Giao dịch bất động sản"],
  [/(cấp|đổi|lại).*(giấy chứng nhận|sổ)/i, "Cấp Giấy chứng nhận"],
  [/(tách|hợp) thửa/i, "Tách thửa / hợp thửa"],
  [/(mục đích)/i, "Chuyển mục đích sử dụng đất"],
  [/(cho thuê|giao đất|thu hồi|bồi thường|đấu giá)/i, "Quản lý và sử dụng đất"],
];

export function classifyProcedure(item: AutoProcedure): string {
  if (item.category?.trim()) return item.category.trim();
  return categoryRules.find(([rule]) => rule.test(item.title))?.[1] || "Đăng ký đất đai";
}

export function normalizeProcedure(item: AutoProcedure): AutoProcedure {
  return { ...item, code: item.code.trim(), title: item.title.trim(), category: classifyProcedure(item) };
}

function normalizeSearchText(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("vi").replace(/đ/g, "d").replace(/[^a-z0-9.\s]/g, " ").replace(/\s+/g, " ").trim();
}

function editDistance(left: string, right: string): number {
  const previous = Array.from({ length: right.length + 1 }, (_, index) => index);
  for (let row = 1; row <= left.length; row += 1) {
    let diagonal = previous[0];
    previous[0] = row;
    for (let column = 1; column <= right.length; column += 1) {
      const above = previous[column];
      previous[column] = left[row - 1] === right[column - 1] ? diagonal : Math.min(diagonal + 1, previous[column] + 1, previous[column - 1] + 1);
      diagonal = above;
    }
  }
  return previous[right.length];
}

const PROCEDURE_ABBREVIATIONS: Record<string, string> = {
  dkdd: "dang ky dat dai",
  dkkd: "dang ky bien dong",
  gcn: "giay chung nhan",
  sdd: "su dung dat",
  sdđ: "su dung dat",
  dvc: "dich vu cong",
  tdh: "tach thua",
  hth: "hop thua",
  qsd: "quyen su dung dat",
  bds: "bat dong san",
};

function fuzzyTokenMatches(token: string, haystack: string): boolean {
  if (!token) return true;
  if (haystack.includes(token)) return true;
  if (token.length < 3) return false;
  return haystack.split(/\s+/).some(candidate => Math.abs(candidate.length - token.length) <= 2 && editDistance(token, candidate) <= (token.length >= 7 ? 2 : 1));
}

export function filterProcedures(items: AutoProcedure[], query: string, category: string): AutoProcedure[] {
  const normalizedQuery = normalizeSearchText(query);
  const queryTokens = normalizedQuery.split(/\s+/).filter(Boolean);
  return items.map(normalizeProcedure).filter(item => {
    const categoryMatches = category === "Tất cả" || item.category === category;
    const normalizedTitle = normalizeSearchText(item.title);
    const shorthandAliases = Object.entries(PROCEDURE_ABBREVIATIONS)
      .filter(([, expansion]) => expansion.split(" ").some(word => normalizedTitle.includes(word)))
      .map(([abbreviation]) => abbreviation)
      .join(" ");
    const searchable = normalizeSearchText(`${item.code} ${item.title} ${item.description || ""} ${item.category || ""} ${shorthandAliases}`);
    const queryMatches = !queryTokens.length || queryTokens.every(token => {
      const expanded = PROCEDURE_ABBREVIATIONS[token];
      return fuzzyTokenMatches(token, searchable) || Boolean(expanded && expanded.split(" ").every(word => fuzzyTokenMatches(word, searchable)));
    });
    return categoryMatches && queryMatches;
  });
}

export function buildCategories(items: AutoProcedure[]): Array<{ category: string; count: number }> {
  const normalized = items.map(normalizeProcedure);
  const names = Array.from(new Set(normalized.map(item => item.category || "Đăng ký đất đai"))).sort((a, b) => a.localeCompare(b, "vi"));
  return [{ category: "Tất cả", count: normalized.length }, ...names.map(category => ({ category, count: normalized.filter(item => item.category === category).length }))];
}

export function buildAutoWorkflow(input: {
  procedureName: string;
  officialSteps?: AutoWorkflowStep[];
  requirements?: Array<{ id: string; label: string; source: string; status: string }>;
  dossierComponents?: Array<{ name: string }>;
}): AutoWorkflowStep[] {
  if (input.officialSteps?.length) return input.officialSteps;
  const requirements = input.requirements || [];
  const components = input.dossierComponents || [];
  const steps: AutoWorkflowStep[] = [
    { id: "discover", title: `Tìm thủ tục: ${input.procedureName}`, description: "Tự tìm và mở nguồn thủ tục chính thức; không yêu cầu người dùng nhập URL.", requiresInput: false },
    { id: "read", title: "Đọc toàn bộ hướng dẫn", description: "Nhận diện trình tự, cách nộp, thời hạn, phí, cơ quan, điều kiện và căn cứ pháp lý.", requiresInput: false },
    { id: "forms", title: "Tìm và phân tích toàn bộ biểu mẫu", description: "Phát hiện file gốc, phân tích PDF/DOC/DOCX/XLS/XLSX hoặc OCR bản scan.", requiresInput: false },
    ...requirements.map(item => ({ id: `requirement-${item.id}`, title: `Chuẩn bị: ${item.label}`, description: item.source || "Thành phần hồ sơ từ nguồn thủ tục.", requiresInput: true, source: item.source })),
    ...components.map((item, index) => ({ id: `component-${index}`, title: item.name, description: "Thành phần được trích xuất từ hướng dẫn chính thức; cần xác nhận trước khi nộp.", requiresInput: true })),
    { id: "profile", title: "Nhập hồ sơ dùng một lần", description: "Dùng lại thông tin đã xác nhận cho tất cả biểu mẫu liên quan.", requiresInput: true },
    { id: "validate", title: "Kiểm tra hồ sơ", description: "Phân loại đủ, cần bổ sung, có lỗi hoặc không áp dụng; không tự bịa dữ liệu.", requiresInput: false },
    { id: "review", title: "Xem và sửa bộ hồ sơ", description: "Xem từng tài liệu, trường dữ liệu, nguồn và trạng thái xác minh.", requiresInput: true },
    { id: "export", title: "Xuất DOCX/PDF", description: "Xuất bản nháp hoặc Official theo đúng cổng xác minh binary và traceability.", requiresInput: false },
  ];
  return steps;
}
