CREATE TABLE `manus_change_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`requestType` enum('fix','update','configuration') NOT NULL DEFAULT 'update',
	`status` enum('requested','staged','synced','approved','rejected') NOT NULL DEFAULT 'requested',
	`localDraft` text,
	`syncSummary` text,
	`requestedBy` int NOT NULL,
	`approvedBy` int,
	`requestedAt` timestamp NOT NULL DEFAULT (now()),
	`syncedAt` timestamp,
	`approvedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `manus_change_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `manus_connection_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`status` enum('connected','disconnected') NOT NULL DEFAULT 'disconnected',
	`lastSyncStatus` enum('never','pending','success','failed') NOT NULL DEFAULT 'never',
	`lastSyncMessage` text,
	`lastSyncVersion` varchar(80),
	`connectedAt` timestamp,
	`disconnectedAt` timestamp,
	`lastSyncedAt` timestamp,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `manus_connection_settings_id` PRIMARY KEY(`id`)
);
