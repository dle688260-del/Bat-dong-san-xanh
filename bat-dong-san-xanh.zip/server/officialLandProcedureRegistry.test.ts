import { describe, expect, it } from "vitest";
import { getOfficialLandProcedure, listOfficialLandProcedures, searchOfficialLandProcedures } from "./officialLandProcedureRegistry";
import { OFFICIAL_2304_PROCEDURE_CODES, OFFICIAL_2304_SOURCE_URL, VERIFIED_2304_PROCEDURE_NAMES } from "./officialLandProcedureCodeIndex";

describe("official land procedure registry", () => {
  it("bao phủ các nhóm thủ tục đất đai phổ biến từ DVC Quốc gia và MONRE", () => {
    const items = searchOfficialLandProcedures("đất");
    const codes = items.map(item => item.code);
    expect(codes).toEqual(expect.arrayContaining(["2.000889", "1.012789", "1.013978", "1.012783", "1.012784", "2.000410", "1.013949", "2.002317", "1.004278"]));
    expect(items.every(item => item.sourceUrl.startsWith("https://"))).toBe(true);
    expect(items.every(item => item.referenceTemplates.every(template => template.provenance === "metadata_only"))).toBe(true);
  });

  it("đăng ký đủ thủ tục đăng ký và xóa biện pháp bảo đảm từ DVC Quốc gia", () => {
    const registration = searchOfficialLandProcedures("1.011441")[0];
    const cancellation = searchOfficialLandProcedures("1.011443")[0];
    expect(registration?.sourceUrl).toContain("ma_thu_tuc=1.011441");
    expect(cancellation?.sourceUrl).toContain("ma_thu_tuc=1.011443");
    expect(registration?.referenceTemplates[0]?.provenance).toBe("metadata_only");
    expect(cancellation?.referenceTemplates[0]?.provenance).toBe("metadata_only");
    expect(registration?.verifiedTemplates || []).toHaveLength(0);
    expect(cancellation?.verifiedTemplates || []).toHaveLength(0);
  });

  it("tìm theo mã mới và giữ nguồn chính thức riêng với binary", () => {
    const item = searchOfficialLandProcedures("2.002317")[0];
    expect(item.sourceUrl).toBe("https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67");
    expect(item.verifiedBinaryAvailable).toBe(true);
  });

  it("đăng ký Mẫu 01/ĐK Official cho thủ tục tách hoặc hợp thửa", () => {
    const item = searchOfficialLandProcedures("1.012784")[0];
    const template = item.verifiedTemplates?.find(candidate => candidate.documentType === "parcel_split_merge_request");
    expect(template?.format).toBe("docx");
    expect(template?.status).toBe("verified_binary");
    expect(template?.provenance).toBe("official_source");
    expect(template?.checksum).toBe("7c1b2afc87f72b3cae065e1a6bbc1bb4c7089ae366a12e66c9380132162c42ff");
    expect(template?.sourceUrl).toContain("cdnchinhphu.vn");
  });

  it("đăng ký Mẫu 09/ĐK Official cho mã 2.000889 và alias 2912", () => {
    const item = searchOfficialLandProcedures("2.000889")[0];
    const template = item.verifiedTemplates?.find(candidate => candidate.documentType === "land_change_registration");
    expect(template?.format).toBe("docx");
    expect(template?.status).toBe("verified_binary");
    expect(template?.provenance).toBe("official_source");
    expect(template?.checksum).toBe("c589d04cf6b0e6f6f82574d4e806194291077459c2a7d86d0b2f79e0e2057dc2");
    expect(template?.sourceUrl).toContain("vptt-nhabe.tphcm.gov.vn");
    expect(getOfficialLandProcedure("2912")?.code).toBe("2.000889");
  });

  it("đăng ký căn cứ pháp lý trung ương và đánh dấu điều kiện địa phương cần rà soát", () => {
    const item = searchOfficialLandProcedures("1.012784")[0];
    expect(item.legalDocuments?.map(document => document.documentNumber)).toEqual(expect.arrayContaining(["101/2024/NĐ-CP", "151/2025/NĐ-CP"]));
    expect(item.requirements?.some(requirement => requirement.id === "local-minimum-area" && requirement.status === "needs_review")).toBe(true);
    expect(item.requirements?.some(requirement => requirement.id === "access-road")).toBe(true);
  });

  it("lưu nguồn rà soát địa phương cho Hà Nội, TP.HCM và Đà Nẵng", () => {
    const item = searchOfficialLandProcedures("1.012784")[0];
    const documents = item.legalDocuments ?? [];
    expect(documents.find(document => document.documentNumber === "61/2024/QĐ-UBND")?.sourceUrl).toContain("sonnmt.hanoi.gov.vn");
    expect(documents.find(document => document.documentNumber === "100/2024/QĐ-UBND")?.sourceUrl).toContain("hochiminhcity.gov.vn");
    expect(documents.find(document => document.documentNumber === "LOCAL-DANANG-PARCEL-SPLIT-MERGE")?.sourceUrl).toContain("danang.gov.vn");
    expect(item.verifiedTemplates?.some(template => template.documentType === "parcel_split_merge_request")).toBe(true);
  });

  it("đưa mã 1.012750 và 1.012751 vào catalog từ nguồn Bộ nhưng giữ trạng thái Pending", () => {
    const dataRequest = searchOfficialLandProcedures("1.012750")[0];
    const dispute = searchOfficialLandProcedures("1.012751")[0];
    expect(dataRequest?.sourceUrl).toContain("qldd.mae.gov.vn");
    expect(dispute?.sourceUrl).toContain("qldd.mae.gov.vn");
    expect(dataRequest?.referenceTemplates[0]?.provenance).toBe("metadata_only");
    expect(dispute?.referenceTemplates[0]?.provenance).toBe("metadata_only");
    expect(dataRequest?.verifiedTemplates || []).toHaveLength(0);
    expect(dispute?.verifiedTemplates || []).toHaveLength(0);
  });

  it("đưa mã 2304 chưa có metadata chi tiết vào cùng pipeline DVC mà vẫn giữ Pending", () => {
    const item = getOfficialLandProcedure("1.012821", "Hà Nội");
    expect(item?.code).toBe("1.012821");
    expect(item?.sourceUrl).toContain("1586_QD-UBND");
    expect(item?.legalDocuments?.[0]?.documentNumber).toBe("2304/QĐ-BNNMT");
    expect(item?.verifiedTemplates || []).toHaveLength(0);
  });

  it("giữ Nghị định 101 là Official Legal Document, không coi là mẫu đơn", () => {
    const item = searchOfficialLandProcedures("1.013978")[0];
    const legal = item.legalDocuments?.find(document => document.documentNumber === "101/2024/NĐ-CP");
    expect(legal?.status).toBe("verified");
    expect(legal?.documentRole).toBe("legal_basis");
    expect(legal?.checksum).toBe("dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e");
    expect(item.referenceTemplates.every(template => template.provenance === "metadata_only")).toBe(true);
  });
});

describe("official 2304 procedure code index", () => {
  it("uses government-source names for mapped codes and keeps unresolved codes explicit", () => {
    const revoked = getOfficialLandProcedure("1.012818");
    const leasedAsset = getOfficialLandProcedure("1.012820");
    const unresolved = getOfficialLandProcedure("1.012819");
    expect(revoked?.name).toContain("Thu hồi Giấy chứng nhận");
    expect(revoked?.sourceUrl).toContain("357513");
    expect(leasedAsset?.name).toContain("Bán hoặc góp vốn bằng tài sản gắn liền với đất thuê");
    expect(leasedAsset?.sourceUrl).toContain("ma-thu-tuc=41099");
    expect(unresolved?.name).toBe("Cấp lại Giấy chứng nhận do bị mất");
    const landPlan = getOfficialLandProcedure("1.012821");
    expect(landPlan?.name).toBe("Thẩm định, phê duyệt phương án sử dụng đất");
    expect(landPlan?.sourceUrl).toContain("1586_QD-UBND");
  });

  it("lấy tên đã đối soát cho mã 2304 trước khi dùng fallback tên tạm", () => {
    const convertedPurpose = getOfficialLandProcedure("1.012775");
    const parcelSplit = getOfficialLandProcedure("1.012784");
    expect(convertedPurpose?.name).toContain("Cho phép chuyển mục đích sử dụng đất");
    expect(parcelSplit?.name).toBe("Tách thửa hoặc hợp thửa đất");
    expect(convertedPurpose?.name).not.toContain("cần đối soát tên thủ tục");
    expect(convertedPurpose?.verifiedBinaryAvailable).toBe(false);
    expect(parcelSplit?.verifiedBinaryAvailable).toBe(true);
  });

  it("list catalog bao phủ toàn bộ mã 2304 và search trả tên canonical", () => {
    const listed = listOfficialLandProcedures();
    const listedCodes = new Set(listed.map(item => item.code));
    expect(listed.length).toBeGreaterThanOrEqual(OFFICIAL_2304_PROCEDURE_CODES.length);
    for (const code of OFFICIAL_2304_PROCEDURE_CODES) {
      expect(listedCodes.has(code)).toBe(true);
      const item = searchOfficialLandProcedures(code)[0];
      expect(item?.name).toBe(getOfficialLandProcedure(code)?.name);
      expect(item?.name).not.toContain("cần đối soát tên thủ tục");
    }
    expect(searchOfficialLandProcedures("1.012784")[0]?.verifiedBinaryAvailable).toBe(true);
    expect(searchOfficialLandProcedures("2.000889")[0]?.verifiedBinaryAvailable).toBe(true);
  });

  it("contains source-confirmed codes without binary Official claims", () => {
    expect(OFFICIAL_2304_PROCEDURE_CODES.length).toBeGreaterThanOrEqual(60);
    expect(OFFICIAL_2304_PROCEDURE_CODES).toContain("1.012750");
    expect(OFFICIAL_2304_PROCEDURE_CODES).toContain("1.012821");
    expect(OFFICIAL_2304_SOURCE_URL).toMatch(/^https:\/\//);
  });

  it("nạp đủ tên 2304 đã đối soát nhưng không suy diễn binary Official", () => {
    expect(Object.keys(VERIFIED_2304_PROCEDURE_NAMES)).toHaveLength(OFFICIAL_2304_PROCEDURE_CODES.length);
    for (const code of Object.keys(VERIFIED_2304_PROCEDURE_NAMES)) {
      const item = getOfficialLandProcedure(code);
      expect(item?.name).toBe(VERIFIED_2304_PROCEDURE_NAMES[code]);
      expect(item?.verifiedBinaryAvailable).toBe(code === "1.012784");
    }
  });
});
