# Nguồn fallback Bộ Tài nguyên và Môi trường / địa phương

Ngày kiểm tra: 2026-08-21.

## Nguồn chính thức đã truy cập

1. Hệ thống thông tin giải quyết thủ tục hành chính Bộ Nông nghiệp và Môi trường, lĩnh vực Đất đai: https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8
   - Trang hiển thị bộ lọc lĩnh vực Đất đai và cấp cơ quan quản lý, gồm UBND Tỉnh/TP, UBND Phường/Xã/Thị trấn, UBND Quận/Huyện, Sở ban ngành.
   - Kết quả hiển thị mã 2.002317 “Cung cấp thông tin, dữ liệu đất đai” và mã 1.004278 “Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Tài nguyên và Môi trường”.
   - Chi tiết mẫu/đính kèm cần mở từ từng thủ tục; không suy đoán URL binary.

2. Danh mục thủ tục hành chính của hệ thống Bộ: https://dichvucong.monre.gov.vn/Pages/linhvuc.aspx
   - Có các cấp cơ quan quản lý và phân loại lĩnh vực để discovery theo địa bàn/cấp xử lý.

3. Phụ lục VII danh sách mẫu biểu trên mae.gov.vn: https://mae.gov.vn/noidung/Lists/DuLieuLinhVucCongBo/Attachments/2/ph%E1%BB%A5%20l%E1%BB%A5c%20VII.pdf
   - Văn bản liệt kê các mẫu đất đai, gồm Mẫu số 14 (Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai), Mẫu số 15 (Đơn đăng ký đất đai, tài sản gắn với đất), Mẫu số 18 (Đơn đăng ký biến động đất đai, tài sản gắn với đất), Mẫu số 20 (Đơn đề nghị tách thửa, hợp thửa đất), Mẫu số 21 (Bản vẽ tách thửa đất, hợp thửa đất) và các mẫu khác.
   - Phụ lục này là bằng chứng chính thức về danh mục/ký hiệu/tên mẫu; bản thân URL PDF chưa chứng minh đã có binary DOCX/PDF riêng cho từng mẫu.

## Quy tắc dùng fallback

- Có thể dùng hệ thống DVC Bộ làm nguồn discovery khi DVC Quốc gia trả 503.
- Chỉ nâng lên Official khi binary tải được từ miền được phép, kiểm tra định dạng, SHA-256, provenance và mapping đúng thủ tục/thành phần.
- Nếu chỉ xác minh được tên mẫu trong phụ lục hoặc trang thủ tục mà chưa có binary, giữ Pending/metadata-only.
- Nguồn Văn phòng đăng ký đất đai/chi nhánh theo tỉnh phải được tra từ cổng tỉnh đã xác minh; không tự suy đoán domain hoặc tên chi nhánh.

## Nguồn địa phương đã tìm được

- Hà Nội: Trung tâm Phục vụ hành chính công Hà Nội có thông tin Văn phòng đăng ký đất đai Hà Nội tiếp nhận thủ tục đất đai trực tuyến: https://ttpvhcc.hanoi.gov.vn/loi-ich-khi-su-dung-dvc-truc-tuyen/tu-ngay-3-9-trien-khai-tiep-nhan-ho-so-thu-tuc-dat-dai-truc-tuyen-khong-phu-thuoc-dia-gioi-hanh-chinh-2850250902173649545.htm
- TP.HCM: Cổng Dịch vụ công TP.HCM: https://dichvucong.hochiminhcity.gov.vn/ ; Cổng Thông tin Đất đai TP.HCM: https://hcm.mplis.gov.vn/og
- Đà Nẵng: Trang cơ quan Văn phòng Đăng ký đất đai TP. Đà Nẵng trên Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-co-quan-chi-tiet.html?id=423787
- DVC Quốc gia có các trang cơ quan Văn phòng Đăng ký đất đai, có thể dùng để xác định cơ quan tiếp nhận nhưng không mặc định là URL binary mẫu.

Các URL địa phương này dùng cho discovery/cơ quan tiếp nhận. Chỉ file tải thành công từ nguồn được xác minh, có checksum và mapping đúng mới được xét Official.

## Kết quả đọc trực tiếp

Cổng Bộ hiện công bố rõ hai thủ tục đất đai cấp Bộ: mã 2.002317 “Cung cấp thông tin, dữ liệu đất đai” tại https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 và mã 1.004278 “Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Tài nguyên và Môi trường” tại https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=69. Trang danh mục xác nhận lĩnh vực Đất đai, cấp cơ quan và mức độ trực tuyến; cần mở trang chi tiết để kiểm tra file đính kèm, không suy đoán binary từ trang danh mục.

Cổng DVC TP.HCM xác nhận đây là hệ thống do UBND TP.HCM chủ quản và thông báo từ ngày 19/6/2025 cá nhân/tổ chức thực hiện dịch vụ công trực tuyến tại một điểm duy nhất là Cổng DVC Quốc gia. Vì vậy, với TP.HCM, fallback nên dùng cổng này để xác định cơ quan/địa bàn và DVC Quốc gia để lấy hồ sơ, thay vì giả định mọi file vẫn nằm trên domain địa phương.

## Kết quả đọc trực tiếp bổ sung — 2026-08-21

### Cổng DVC Bộ — thủ tục dv=67
URL: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67

Trang “Cung cấp thông tin, dữ liệu đất đai” hiển thị đầy đủ các tab thông tin, hồ sơ và văn bản mẫu. Trang công bố các Mẫu 13/ĐK, 13a/ĐK, 13b/ĐK, 13c/ĐK, 13d/ĐK, 13đ/ĐK theo Nghị định 101/2024/NĐ-CP. Cuối phần hồ sơ có ba dòng tải mẫu: “Phieu Yeu Cau”, “Hop Dong” và “Văn bản, phiếu yêu cầu cung cấp dữ liệu đất đai” với nhãn “Tải về”. Cơ quan thực hiện ở cấp Bộ là Trung tâm Dữ liệu và Thông tin đất đai thuộc Cục Đăng ký và Dữ liệu thông tin đất đai. Trang không trả 503 trong lần kiểm tra này.

### Phụ lục VII danh sách mẫu biểu
URL: https://mae.gov.vn/noidung/Lists/DuLieuLinhVucCongBo/Attachments/2/ph%E1%BB%A5%20l%E1%BB%A5c%20VII.pdf

PDF chính thức liệt kê các mẫu: Mẫu 14 và 14a–14đ về cung cấp thông tin dữ liệu đất đai; Mẫu 15 và các biến thể về đăng ký đất đai; Mẫu 18 về đăng ký biến động; Mẫu 20 về tách/hợp thửa; Mẫu 21 về bản vẽ tách/hợp thửa; cùng các mẫu khác. PDF là căn cứ xác minh tên/ký hiệu mẫu, chưa tự động chứng minh binary DOCX/PDF riêng cho từng mẫu.

### Quy trình nội bộ của Bộ
URL: https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf

Tài liệu xác định quy trình cấp Bộ và cơ quan thực hiện. Tài liệu nêu mã nội bộ 1.012750 cho cung cấp thông tin dữ liệu đất đai và mô tả các Mẫu 14, 14a, 14b, 14c, 14d, 14đ trong quy trình; tiếp nhận trực tuyến tại http://dvc.mae.gov.vn. Đây là nguồn đối chiếu thủ tục/cơ quan, không phải mặc định binary mẫu.

### Kết luận
Cổng Bộ có trang không 503 và có nhãn tải mẫu thực tế ở thủ tục dv=67. Có thể dùng để bổ sung candidate fallback cho nhóm Mẫu 13/ĐK–14/ĐK. Chỉ gắn Official sau khi tải được binary, xác minh MIME/nội dung, tính SHA-256 và mapping đúng thủ tục/thành phần; nếu không tải được binary thì giữ Pending/metadata-only.

## Xác minh bổ sung từ cổng Bộ — 2026-08-21

1. Cổng DVC Bộ, thủ tục dv=67, “Cung cấp thông tin, dữ liệu đất đai”: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67. Trang đọc được không lỗi 503. Trang nêu các Mẫu 13/ĐK, 13a/ĐK, 13b/ĐK, 13c/ĐK, 13d/ĐK, 13đ/ĐK theo Nghị định 101/2024/NĐ-CP; phần “Văn bản mẫu” có các mục “Phieu Yeu Cau”, “Hop Dong” và “Văn bản, phiếu yêu cầu cung cấp dữ liệu đất đai” với liên kết “Tải về”. Cơ quan trung ương là Trung tâm Dữ liệu và Thông tin đất đai thuộc Cục Đăng ký và Dữ liệu thông tin đất đai.

2. Cổng DVC Bộ, thủ tục dv=180, “Xác nhận tiếp tục sử dụng đất nông nghiệp của hộ gia đình, cá nhân khi hết hạn sử dụng đất”: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=180. Trang đọc được không lỗi 503; nêu mẫu Đơn đăng ký biến động đất đai theo Mẫu 09/ĐK, cơ quan thực hiện là Văn phòng đăng ký đất đai hoặc Chi nhánh Văn phòng đăng ký đất đai, cấp quản lý UBND tỉnh/thành phố. Trang này cung cấp căn cứ và mapping thủ tục, nhưng phần trích xuất không cho thấy một URL binary trực tiếp của Mẫu 09/ĐK.

3. Phụ lục VII danh sách mẫu biểu của Bộ: https://mae.gov.vn/noidung/Lists/DuLieuLinhVucCongBo/Attachments/2/ph%E1%BB%A5%20l%E1%BB%A5c%20VII.pdf. Danh mục xác định Mẫu 14 và 14a–14đ là phiếu/thông tin dữ liệu đất đai; Mẫu 15 và biến thể là đăng ký đất đai; Mẫu 18 là đăng ký biến động; Mẫu 20 là đơn đề nghị tách thửa, hợp thửa; Mẫu 21 là bản vẽ tách thửa, hợp thửa. Đây là căn cứ xác minh tên/ký hiệu mẫu, không tự chứng minh binary riêng.

Kết luận: nguồn Bộ hiện có thể dùng làm fallback discovery và mapping cho các mẫu Pending; chỉ nâng Official khi tải được binary từ URL nguồn được phép, kiểm tra MIME/nội dung, SHA-256 và mapping đúng thủ tục/thành phần. Nếu chỉ có trang hướng dẫn hoặc danh mục mẫu thì giữ Pending/metadata-only.

## Đối chiếu bổ sung sau khi đọc trực tiếp

- Cổng DVC Bộ: https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8 hiển thị lĩnh vực Đất đai, bộ lọc cấp UBND Tỉnh/TP, UBND Phường/Xã/Thị trấn, UBND Quận/Huyện và Sở ban ngành; xác nhận phù hợp làm tầng discovery cấp Bộ và địa phương.
- Chi tiết Bộ dv=67: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 công bố thủ tục 2.002317, các Mẫu 13/ĐK–13đ/ĐK theo Nghị định 101/2024/NĐ-CP và các mục tải về “Phieu Yeu Cau”, “Hop Dong”, “Văn bản, phiếu yêu cầu cung cấp dữ liệu đất đai”. Việc có nhãn “Tải về” chưa thay thế bước tải binary, kiểm tra chữ ký định dạng và SHA-256.
- Cổng DVC Hà Nội: https://dichvucong.hanoi.gov.vn/dich-vu-cong đọc được danh mục 3.205 thủ tục và thông báo từ 01/07/2025 dịch vụ công trực tuyến thực hiện tại Cổng DVC Quốc gia. Vì vậy registry Hà Nội dùng làm nguồn discovery/cơ quan, còn binary phải lấy từ liên kết thực tế hoặc tầng quốc gia.
- Nguồn Đà Nẵng hcc.danang.gov.vn có kết quả tìm kiếm xác nhận Văn phòng Đăng ký đất đai thành phố tham gia xử lý thủ tục đất đai; trang chi tiết cần browser fallback nếu muốn trích xuất liên kết, không tự suy đoán URL file.

## Kiểm tra binary Cổng DVC Bộ — lần truy cập trình duyệt

Trang chính thức `https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67` xác nhận thủ tục Cung cấp thông tin, dữ liệu đất đai và các mẫu 13/ĐK, 13a/ĐK, 13b/ĐK, 13c/ĐK, 13d/ĐK, 13đ/ĐK theo Nghị định 101/2024/NĐ-CP. Phần Văn bản mẫu hiển thị các dòng “Phieu Yeu Cau”, “Hop Dong” và “Văn bản, phiếu yêu cầu cung cấp dữ liệu đất đai” với nhãn “Tải về”. Trình duyệt không cung cấp được href binary trong lần kiểm tra này và một lần xem HTML bị `ERR_BLOCKED_BY_CLIENT`; vì vậy chưa được phép gắn Official. Các candidate chỉ được xét sau khi tải được DOCX/PDF, kiểm tra MIME/nội dung, SHA-256 và mapping đúng thủ tục.

## 2026-08-21 — Binary DVC Bộ đã tải và xác minh

Trang `https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67` công khai các nút `downloadfile(...)`. POST `action=downloadfile&FileActachmenId=...` trả về endpoint binary chính thức trên `mdm.monre.gov.vn:8800`.

| Mẫu | URL binary được trang trả về | MIME | Kích thước | SHA-256 | Kết quả nội dung |
|---|---|---:|---:|---|---|
| Phiếu yêu cầu | `https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/0ff8d095-1ea7-4567-a475-781d46b3c9bf` | DOCX | 23,926 bytes | `3e68adcddb6e249af61fa2a3bdc883b73ad5800fd5af6c89e3b31b4e03fccbb2` | Mẫu số 01/PYC, kèm Thông tư 34/2014/TT-BTNMT |
| Hợp đồng | `https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/13f2af36-a65a-426a-99dd-e098de8d091e` | DOCX | 19,727 bytes | `d5853a5ee35f4d115e3011007f23364670fed45d9ed95549d5982f5309706dce` | Mẫu số 02 Hợp đồng cung cấp dữ liệu đất đai |
| Phiếu yêu cầu — nhãn tệp khác | `https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/0b362fa7-818b-48ae-ba54-9ce7fd2332b4` | DOCX | 23,926 bytes | `3e68adcddb6e249af61fa2a3bdc883b73ad5800fd5af6c89e3b31b4e03fccbb2` | Nội dung trùng SHA-256 với Phiếu yêu cầu |

Các URL và checksum đã được thêm vào `verifiedTemplates` của thủ tục Bộ `2.002317`. Scheduled sync vẫn phải tải lại binary, kiểm tra chữ ký DOCX, SHA-256 và lưu S3 trước khi ghi Official vào cơ sở dữ liệu. Không suy luận rằng các mẫu này thay thế biểu mẫu cập nhật nếu pháp luật/thủ tục hiện hành đã thay đổi.
