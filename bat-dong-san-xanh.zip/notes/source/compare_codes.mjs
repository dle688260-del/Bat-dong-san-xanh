import fs from 'node:fs';
const indexText = fs.readFileSync('/home/ubuntu/bat-dong-san-xanh/server/officialLandProcedureCodeIndex.ts','utf8');
const indexed = [...indexText.matchAll(/"(1\.012\d{3})"/g)].map((m) => m[1]);
const extracted = JSON.parse(fs.readFileSync('/home/ubuntu/bat-dong-san-xanh/notes/source/2304-names-extracted.json','utf8'));
const named = new Set(extracted.map((x) => x.code));
const missing = indexed.filter((code) => !named.has(code));
const extra = extracted.filter((x) => !indexed.includes(x.code)).map((x) => x.code);
console.log(JSON.stringify({ indexedCount: indexed.length, namedCount: named.size, missing, extra }, null, 2));
