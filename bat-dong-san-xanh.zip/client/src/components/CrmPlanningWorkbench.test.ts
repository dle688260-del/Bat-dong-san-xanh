import { describe, expect, it } from "vitest";
import { calculateComparableValuation, calculateLoanPlan } from "./CrmPlanningWorkbench";

describe("CRM planning workbench", () => {
  it("calculates an annuity loan plan from user inputs", () => {
    const plan = calculateLoanPlan(2, 0.8, 9, 20);
    expect(plan.loanAmount).toBeCloseTo(1.2, 5);
    expect(plan.ltv).toBeCloseTo(60, 5);
    expect(plan.monthlyPayment).toBeGreaterThan(0);
    expect(plan.totalInterest).toBeGreaterThan(0);
  });

  it("calculates a comparable-property valuation with an adjustment", () => {
    expect(calculateComparableValuation(55, 100, 10)).toBeCloseTo(6.05, 5);
    expect(calculateComparableValuation(-10, 100, 10)).toBe(0);
  });

  it("handles zero interest without division by zero", () => {
    const plan = calculateLoanPlan(1, 0.4, 0, 10);
    expect(plan.loanAmount).toBeCloseTo(0.6, 5);
    expect(plan.monthlyPayment).toBeCloseTo(0.005, 5);
    expect(plan.totalInterest).toBeCloseTo(0, 5);
  });

  it("clamps capital to the property price and rejects negative inputs", () => {
    const plan = calculateLoanPlan(-1, 5, -3, 0);
    expect(plan.propertyPrice).toBe(0);
    expect(plan.ownCapital).toBe(0);
    expect(plan.loanAmount).toBe(0);
    expect(plan.ltv).toBe(0);
  });
});
