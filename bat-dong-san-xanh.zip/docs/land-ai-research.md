# Nguồn tham khảo thiết kế Kho hồ sơ đất đai AI

Ngày thu thập: 2026-08-16.

## Nguồn chính

1. Cổng Dịch vụ công Quốc gia — thủ tục đăng ký biến động quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất trong các trường hợp chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410

Nguồn này mô tả việc nộp hồ sơ, tiếp nhận và yêu cầu bổ sung hồ sơ chưa đầy đủ; các tài liệu thường gồm đơn đăng ký biến động, hợp đồng/văn bản giao dịch, bản gốc Giấy chứng nhận và tài liệu bổ sung theo trường hợp. Nguồn cũng nêu cơ quan đăng ký kiểm tra điều kiện, gửi thông tin địa chính để xác định nghĩa vụ tài chính và cập nhật biến động vào hồ sơ địa chính/cơ sở dữ liệu đất đai.

2. Vụ Pháp chế, Bộ Nông nghiệp và Môi trường — hướng dẫn thủ tục nhận chuyển nhượng quyền sử dụng đất: https://vupc.mae.gov.vn/dat-dai/1420/huong-dan-cu-the-thu-tuc-nhan-chuyen-nhuong-quyen-su-dung-dat

Nguồn chính thức mô tả các bước nộp bộ hồ sơ, kiểm tra hồ sơ, xác định nghĩa vụ tài chính, xác nhận biến động và cập nhật hồ sơ địa chính. Nội dung dùng làm căn cứ để mô hình hóa checklist theo giai đoạn, không dùng để tự kết luận hồ sơ đủ điều kiện pháp lý.

3. Luật Việt Nam — thủ tục sang tên Sổ đỏ từ 01/07/2025: https://luatvietnam.vn/dat-dai-nha-o/sang-ten-so-do-567-23920-article.html

Nguồn tổng hợp pháp lý nêu các nhóm việc thường gặp khi sang tên như công chứng/chứng thực hợp đồng, kê khai nghĩa vụ tài chính và đăng ký biến động; các điều kiện và thành phần hồ sơ phải được kiểm tra theo văn bản đang có hiệu lực và trường hợp cụ thể.

## Quy tắc thiết kế sản phẩm

- AI chỉ tạo đề xuất, checklist và cảnh báo cần kiểm tra; không tự xác nhận quyền sử dụng đất, hiệu lực hợp đồng, nghĩa vụ thuế hoặc tình trạng quy hoạch.
- Mỗi hồ sơ phải giữ bản gốc, nguồn văn bản, thời điểm phân tích, phiên bản kết quả AI và người xác nhận.
- Checklist cần phân biệt “đã có”, “thiếu”, “cần kiểm tra”, “không áp dụng” và “đã xác nhận bởi chuyên viên”.
- Các mẫu hợp đồng/dự thảo phải hiển thị rõ: “Bản nháp — cần người có chuyên môn pháp lý kiểm tra trước khi sử dụng”.
- Các checklist phải có ngày rà soát và nguồn pháp lý để cập nhật khi quy định thay đổi.
