export type UploadedDossierFileRecord = {
  id: string;
  fileName: string;
  componentId: string;
  componentName: string;
  mimeType: string;
  extractedFields?: { label: string; value: string; evidence?: string }[];
};

/** Keep a single visible row for a file identity while preserving its original position. */
export function upsertUploadedDossierFile(
  current: UploadedDossierFileRecord[],
  next: UploadedDossierFileRecord,
): UploadedDossierFileRecord[] {
  const firstIndex = current.findIndex(item => item.id === next.id);
  if (firstIndex < 0) return [...current, next];

  return current.reduce<UploadedDossierFileRecord[]>((result, item, index) => {
    if (item.id !== next.id) result.push(item);
    else if (index === firstIndex) result.push({ ...item, ...next });
    return result;
  }, []);
}
