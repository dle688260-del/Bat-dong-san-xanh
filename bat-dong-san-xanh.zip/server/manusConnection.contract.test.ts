import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("Manus connection portal contract", () => {
  const router = readFileSync(
    resolve(process.cwd(), "server/routers.ts"),
    "utf8"
  );
  const schema = readFileSync(
    resolve(process.cwd(), "drizzle/schema.ts"),
    "utf8"
  );
  const page = readFileSync(
    resolve(process.cwd(), "client/src/pages/CrmDashboard.tsx"),
    "utf8"
  );

  it("stores local requests and exposes only admin procedures", () => {
    expect(schema).toContain("manus_connection_settings");
    expect(schema).toContain("manus_change_requests");
    expect(router).toContain("manusConnection: router({");
    expect(router).toMatch(/status: adminProcedure/);
    expect(router).toMatch(/requestUpdate: adminProcedure/);
    expect(router).toMatch(/syncRequest: adminProcedure/);
    expect(router).toMatch(/approveRequest: adminProcedure/);
    expect(router).not.toMatch(
      /manusConnection:\s*router\([\s\S]{0,500}publicProcedure/
    );
  });

  it("blocks disconnect while a sync is pending and renders reconnect controls", () => {
    expect(router).toContain('state.lastSyncStatus === "pending"');
    expect(router).toContain("Chưa thể ngắt kết nối");
    expect(page).toContain("Kết nối lại");
    expect(page).toContain("Ngắt kết nối");
    expect(page).toContain("Xác nhận đã đồng bộ");
    expect(page).toContain("Phê duyệt áp dụng");
    expect(page).toMatch(
      /Chỉ khi bạn phê duyệt thì thay đổi mới được\s+phép áp dụng/
    );
  });
});
