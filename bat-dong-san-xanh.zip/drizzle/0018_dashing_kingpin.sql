CREATE TABLE `land_dossier_audits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`dossierId` int NOT NULL,
	`action` varchar(120) NOT NULL,
	`status` enum('passed','warning','blocked') NOT NULL,
	`evidenceJson` text,
	`actorId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `land_dossier_audits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_procedure_versions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`procedureId` int NOT NULL,
	`sourceUrl` text NOT NULL,
	`sourceHash` varchar(128),
	`snapshotKey` text,
	`workflowJson` text NOT NULL,
	`requirementsJson` text NOT NULL,
	`discoveredAt` timestamp NOT NULL DEFAULT (now()),
	`effectiveFrom` timestamp,
	`status` enum('discovered','reviewed','active','superseded') NOT NULL DEFAULT 'discovered',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `legal_procedure_versions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_template_mappings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`procedureId` int NOT NULL,
	`requirementId` int,
	`templateId` int NOT NULL,
	`mappingJson` text NOT NULL,
	`confidence` int NOT NULL DEFAULT 0,
	`status` enum('suggested','reviewed','approved','rejected') NOT NULL DEFAULT 'suggested',
	`reviewedAt` timestamp,
	`reviewedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_template_mappings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `land_dossier_audits` ADD CONSTRAINT `land_dossier_audits_dossierId_land_dossiers_id_fk` FOREIGN KEY (`dossierId`) REFERENCES `land_dossiers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `land_dossier_audits` ADD CONSTRAINT `land_dossier_audits_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_procedure_versions` ADD CONSTRAINT `legal_procedure_versions_procedureId_legal_procedures_id_fk` FOREIGN KEY (`procedureId`) REFERENCES `legal_procedures`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `legal_template_mappings_procedureId_legal_procedures_id_fk` FOREIGN KEY (`procedureId`) REFERENCES `legal_procedures`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `legal_template_mappings_requirementId_legal_procedure_requirements_id_fk` FOREIGN KEY (`requirementId`) REFERENCES `legal_procedure_requirements`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `legal_template_mappings_templateId_legal_templates_id_fk` FOREIGN KEY (`templateId`) REFERENCES `legal_templates`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `legal_template_mappings_reviewedBy_users_id_fk` FOREIGN KEY (`reviewedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;