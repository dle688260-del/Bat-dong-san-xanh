import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("public and admin access boundary", () => {
  const source = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");

  it("keeps public property discovery unauthenticated", () => {
    expect(source).toMatch(/list: publicProcedure[\s\S]*?detail: publicProcedure/);
  });

  it("allows signed-in users to create drafts while keeping admin-only inventory writes", () => {
    expect(source).toMatch(/create: protectedProcedure\.input\(z\.object\(\{ title:/);
    expect(source).toMatch(/updateLocation: adminProcedure/);
    expect(source).toMatch(/landDossiers: router\(\{[\s\S]*?create: adminProcedure/);
    expect(source).toMatch(/landDossierBuilder: router\(\{[\s\S]*?ocr: adminProcedure/);
  });
});
