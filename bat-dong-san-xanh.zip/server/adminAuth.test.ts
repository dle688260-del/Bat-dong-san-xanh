import { describe, expect, it } from "vitest";
import { verifyAdminCredentials } from "./adminAuth";

describe("admin credentials secret", () => {
  it("accepts the configured admin credentials through the lightweight verifier", () => {
    const username = process.env.ADMIN_USERNAME;
    const password = process.env.ADMIN_PASSWORD;
    expect(username).toBeTruthy();
    expect(password).toBeTruthy();
    expect(verifyAdminCredentials(username ?? "", password ?? "")).toBe(true);
    expect(verifyAdminCredentials(username ?? "", "")).toBe(false);
  });
});
