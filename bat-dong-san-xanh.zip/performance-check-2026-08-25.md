# Kiểm tra hiệu năng production — 2026-08-25

## Phạm vi
Đo phiên bản production `https://batdongsan-7bupubgw.manus.space` cho `/`, `/bat-dong-san` và `/quan-ly-moi-gioi` bằng curl, sau đó kiểm tra homepage bằng trình duyệt.

## Đo network ban đầu
- `/`: HTTP 200; TTFB 3.670–6.028 giây; tổng 4.980–7.261 giây; 371,978 bytes chưa nén.
- `/bat-dong-san`: HTTP 200; TTFB 3.690–4.585 giây; tổng 5.014–6.536 giây; 371,978 bytes chưa nén.
- `/quan-ly-moi-gioi`: HTTP 200; TTFB 3.616–5.041 giây; tổng 5.385–7.556 giây; 371,978 bytes chưa nén.
- Khi bật nén, HTML homepage còn khoảng 106,333 bytes; phản hồi vẫn mất khoảng 4.911 giây ở lần đo.
- HTML tải cùng shell SPA cho cả route; bundle chính `/assets/index-BeUtXMPw.js` khoảng 1,083,215 bytes chưa nén và 223,203 bytes sau nén, lần đo tải mất khoảng 5.364 giây.
- HTML tham chiếu bundle chính, vendor React/data/misc và CSS; các route được phục vụ bằng cùng SPA shell.

## Quan sát trình duyệt homepage
- Lần chụp đầu hiển thị trắng trong khoảng chờ ứng dụng khởi chạy; lần xem lại đã render đầy đủ nội dung.
- Homepage có nội dung chính, danh mục, 2 bài đăng, ảnh sản phẩm và các CTA; không thấy trạng thái lỗi sau khi ứng dụng hoàn tất khởi chạy.
- Bằng chứng cho thấy độ trễ nổi bật hiện tại nằm ở TTFB/khởi động production và bundle JavaScript lớn hơn là do HTML theo từng route chứa quá nhiều dữ liệu riêng.

## Cần đo tiếp
- Mở và kiểm tra `/bat-dong-san` và `/quan-ly-moi-gioi` bằng trình duyệt.
- Kiểm tra network/API sau khi React khởi chạy và tổng hợp mức độ ảnh hưởng của ảnh sản phẩm.

## Quan sát thêm bằng trình duyệt
- `/bat-dong-san` đã tải được shell và hiển thị bộ lọc, nhưng tại thời điểm chụp vẫn hiện `Đang tải sản phẩm...` và `Đang tìm nguồn hàng...`; cần xem xét thời gian API/query hoặc trạng thái chờ trong client.
- `/quan-ly-moi-gioi` hiển thị đúng màn hình yêu cầu đăng nhập quản trị, không tải toàn bộ form quản trị khi chưa xác thực; đây là dấu hiệu tốt về việc tránh nạp dữ liệu admin không cần thiết cho khách.
- Homepage sau khi chờ thêm đã render đầy đủ, gồm danh mục, sản phẩm, ảnh và CTA.

## Nhận định tạm thời
Các route đều trả cùng SPA shell khoảng 372 KB chưa nén, nên số lượng module không làm HTML mỗi route tăng riêng biệt. Bundle JavaScript chính khoảng 1.08 MB chưa nén/223 KB sau nén là tải chung. Độ trễ TTFB production khoảng 3.6–6.0 giây và tổng phản hồi khoảng 5.0–7.6 giây là vấn đề đáng chú ý hơn số lượng dữ liệu hiển thị. Catalog còn có dấu hiệu chờ API sau khi shell đã tải.

## Catalog sau khi chờ
Sau lần tải lại và chờ thêm, `/bat-dong-san` đã hiển thị **2 sản phẩm phù hợp** cùng ảnh và CTA đầy đủ. Vì vậy trạng thái loading ban đầu là độ trễ khởi chạy/query hoặc ảnh, không phải lỗi dữ liệu cố định. Ảnh sản phẩm có lúc xuất hiện sau nội dung card, cho thấy nên lazy-load và kích thước ảnh rõ ràng để tránh ảnh hưởng cảm nhận tốc độ.

## Navigation Timing trong trình duyệt
- Catalog `/bat-dong-san`: TTFB khoảng 3,096 ms; DOM interactive khoảng 4,108 ms; DOMContentLoaded khoảng 4,439 ms; load khoảng 4,614 ms; document decoded body 371,978 bytes.
- Catalog phát sinh 29 tài nguyên. Request gộp `propertyLayoutSettings.public` + `properties.list` có duration khoảng 1,162 ms và payload decoded khoảng 4,063 bytes; đây là phần chờ dữ liệu đáng chú ý sau khi document bắt đầu tải.
- Bundle `vendor-misc` có decoded body khoảng 13,258,418 bytes, lớn hơn đáng kể so với bundle app chính khoảng 1,083,215 bytes. Đây là bottleneck tải JavaScript tiềm năng, dù transferSize trong browser cache hiện báo 0.
- CSS chính khoảng 209,841 bytes; CSS vendor khoảng 29,193 bytes.
- Homepage đã render nội dung đầy đủ sau khi khởi chạy; catalog cũng render đủ 2 sản phẩm sau khi chờ query/API và ảnh hoàn tất.

## Route quản trị trước đăng nhập
- `/quan-ly-moi-gioi`: TTFB khoảng 1,530 ms; DOM interactive khoảng 2,365 ms; DOMContentLoaded khoảng 2,542 ms; load khoảng 2,642 ms; 27 tài nguyên; decoded document 371,978 bytes.
- Route này chỉ hiển thị màn hình đăng nhập và không gọi dữ liệu quản trị trước xác thực, nên nhanh hơn catalog/homepage trong lần đo này.

## Kết luận đo được
- Dữ liệu HTML không phải nguyên nhân chính: cả ba route nhận cùng SPA shell khoảng 372 KB chưa nén.
- Bottleneck lớn nhất là độ trễ phản hồi production không ổn định và bundle `vendor-misc` decoded khoảng 13.26 MB; app bundle khoảng 1.08 MB.
- Catalog còn chờ request tRPC gộp layout + danh sách sản phẩm khoảng 1.16 giây, sau đó ảnh sản phẩm có thể tải tiếp.
- Trang quản trị chưa đăng nhập không gây tải dữ liệu nghiệp vụ; việc nhiều mô-đun không đồng nghĩa khách hàng tải hết toàn bộ chức năng.
