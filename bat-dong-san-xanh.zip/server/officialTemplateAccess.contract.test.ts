import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const moduleSource = readFileSync(new URL("../client/src/pages/AiLandDossierAutoModule.tsx", import.meta.url), "utf8");

describe("Official template access contract", () => {
  it("returns sourceUrl separately from the verified binary URL and storage key", () => {
    expect(routerSource).toContain("sourceUrl: item.sourceUrl");
    expect(routerSource).toContain("fileUrl: item.fileUrl || null");
    expect(routerSource).toContain("storageKey: item.storageKey || null");
  });

  it("does not use an Official source page as the preview/download binary fallback", () => {
    expect(moduleSource).toContain("previewOfficialTemplate?.fileUrl");
    expect(moduleSource).toContain("/api/official-storage");
    expect(moduleSource).toContain("Chưa có file Official đã xác minh và có đường dẫn lưu kho hợp lệ");
    expect(moduleSource).not.toContain(")?.sourceUrl;");
  });

  it("uses the current officialStatus binary as the only Official export authority", () => {
    expect(moduleSource).toContain("const canExportOfficial = isVerifiedBinaryAsset(officialStatusAsset);");
    expect(moduleSource).toContain("const previewOfficialTemplate = isVerifiedBinaryAsset(officialStatusAsset) ? officialStatusAsset : undefined;");
    expect(moduleSource).toContain("const previewTemplateUrl = previewOfficialTemplate?.storageKey ? `/api/official-storage?key=${encodeURIComponent(previewOfficialTemplate.storageKey)}`");
    expect(moduleSource).not.toContain("officialTemplates.some(isVerifiedBinaryAsset)");
  });
});
