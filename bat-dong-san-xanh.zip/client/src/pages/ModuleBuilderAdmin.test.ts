import { describe, expect, it } from "vitest";
import { COMPONENT_REGISTRY, MODULE_REGISTRY } from "./ModuleBuilderAdmin";

describe("Module Builder registry contracts", () => {
  it("keeps the operating center and inventory routes stable", () => {
    expect(
      MODULE_REGISTRY.find(item => item.id === "operating-center")
    ).toMatchObject({
      route: "/dashboard",
      required: true,
      enabled: true,
    });
    expect(MODULE_REGISTRY.find(item => item.id === "inventory")).toMatchObject(
      {
        route: "/quan-ly-moi-gioi",
        required: true,
        enabled: true,
      }
    );
  });

  it("registers the source workflow and product listing components", () => {
    expect(COMPONENT_REGISTRY).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          id: "source-creation-workflow",
          location: "Tầng 3 · Vận hành",
        }),
        expect.objectContaining({
          id: "property-listings",
          safety: "Cần duyệt trước khi công khai",
        }),
      ])
    );
  });

  it("exposes module editing, reorder, add and safe component management controls", async () => {
    const fs = await import("node:fs/promises");
    const source = await fs.readFile(new URL("./ModuleBuilderAdmin.tsx", import.meta.url), "utf8");
    expect(source).toContain("data-module-add-form");
    expect(source).toContain("draggable");
    expect(source).toContain("Đã đổi vị trí mô-đun");
    expect(source).toContain("Chỉnh sửa module hiện tại");
    expect(source).toContain("Đã thêm mô-đun mới");
    expect(source).toContain("Thành phần / thẻ trong module");
    expect(source).toContain("chèn trước một thẻ bất kỳ");
    expect(source).toContain("Sửa thẻ");
    expect(source).toContain("Đã đổi vị trí thẻ trong module");
    expect(source).toContain("Đã thêm thành phần vào mô-đun");
    expect(source).toContain("Gỡ thành phần khỏi module?");
    expect(source).toContain("dữ liệu nghiệp vụ vẫn được giữ nguyên");
  });

  it("marks AI and workflow safety constraints for human review", () => {
    const ocr = COMPONENT_REGISTRY.find(item => item.id === "ocr-review");
    const workflow = COMPONENT_REGISTRY.find(
      item => item.id === "source-creation-workflow"
    );

    expect(ocr?.safety).toContain("không kết luận pháp lý");
    expect(workflow?.safety).toContain("không bị xóa");
    expect(MODULE_REGISTRY.some(item => item.required)).toBe(true);
  });
});
