import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { storagePut } from "../server/storage";

const sourceUrl = "https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf";
const filePath = "/tmp/official-check/101-nd.signed.pdf";
const bytes = await readFile(filePath);
const checksum = createHash("sha256").update(bytes).digest("hex");
if (bytes.subarray(0, 5).toString("ascii") !== "%PDF-") {
  throw new Error("Nguồn không có chữ ký PDF hợp lệ");
}
const stored = await storagePut(
  `legal-official/nghi-dinh-101-2024/${checksum}.pdf`,
  bytes,
  "application/pdf",
);
console.log(JSON.stringify({ sourceUrl, bytes: bytes.length, checksum, ...stored }, null, 2));
