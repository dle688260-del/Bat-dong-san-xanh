CREATE TABLE `legal_document_scans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`propertyId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`imageUrl` text NOT NULL,
	`storageKey` text NOT NULL,
	`extractedData` text,
	`confidence` decimal(5,2),
	`status` enum('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
	`reviewedBy` int,
	`reviewedAt` timestamp,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_document_scans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `legal_document_scans` ADD CONSTRAINT `legal_document_scans_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_document_scans` ADD CONSTRAINT `legal_document_scans_reviewedBy_users_id_fk` FOREIGN KEY (`reviewedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_document_scans` ADD CONSTRAINT `legal_document_scans_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;