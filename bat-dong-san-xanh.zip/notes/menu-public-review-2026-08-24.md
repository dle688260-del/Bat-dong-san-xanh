# Review menu public — 2026-08-24

- Mobile 390×844: trang chủ public render đúng logo, nút gọi tư vấn và nút hamburger; không còn nút admin hoặc chuông yêu cầu rời trên header. Thanh điều hướng Nguồn hàng / Mua BĐS / Ký gửi / Tư vấn vẫn hiển thị gọn.
- Desktop 1280×720: header public chỉ còn logo, gọi tư vấn và hamburger; không còn lối admin/chuông rời. Nội dung nguồn hàng và các nút danh mục vẫn render bình thường.
- Trạng thái đóng của menu được xác nhận qua preview với `aria-label="Mở menu"`; code dùng `menuOpen ? X : Menu`, nên dấu X chỉ xuất hiện khi menu mở.
- Biểu tượng khóa ở thanh địa chỉ trình duyệt là chỉ báo bảo mật của trình duyệt, không thuộc giao diện website và website không thể/không nên tự xóa.
- Cần tiếp tục: chạy Vitest/TypeScript, kiểm tra test menu, đánh dấu todo và lưu checkpoint.
