# Rà soát nguồn hợp đồng chuyển nhượng — 2026-08-24

Nguồn DVC Quốc gia của thủ tục 2.000889: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889

Nguồn này xác nhận thành phần hồ sơ gồm Đơn Mẫu số 09/ĐK và hợp đồng/văn bản chuyển nhượng theo quy định, nhưng liên kết tải cho thành phần hợp đồng là rỗng (`ma=`), không cung cấp binary Official hợp đồng riêng.

Nguồn Bộ Tư pháp đã đọc: https://htpldn.moj.gov.vn/Pages/chi-tiet-tin.aspx?ItemID=23&l=Phobienphapluatkinh

Trang này công bố mẫu “Hợp đồng chuyển nhượng quyền sử dụng đất đã có hạ tầng kỹ thuật trong dự án bất động sản”, đăng ngày 30/05/2025. Đây là mẫu theo phạm vi dự án bất động sản có hạ tầng kỹ thuật, không đủ căn cứ để coi là binary Official của thành phần hợp đồng trong mọi trường hợp của thủ tục 2.000889. Vì vậy mẫu hợp đồng legacy `.doc` hiện tại tiếp tục giữ trạng thái Reference-only; không thêm vào allowlist Official/export tự động.
