import { useMemo } from "react";
import { Check, ChevronRight, Home, KeyRound, MapPinned, Sparkles } from "lucide-react";
import { getListingProfile, type ListingKind, type ListingTransaction } from "@/lib/propertyListingRegistry";

type Props = {
  transaction: ListingTransaction;
  propertyType: ListingKind;
  onTransactionChange: (value: ListingTransaction) => void;
  onPropertyTypeChange: (value: ListingKind) => void;
};

const selectClass = "mt-1 h-11 w-full rounded-xl border border-[#CDE1D6] bg-white px-3 text-sm font-semibold text-[#123C2F] outline-none transition focus:border-[#0F6B4F] focus:ring-2 focus:ring-[#0F6B4F]/15";
const inputClass = "min-w-0 flex-1 rounded-lg bg-transparent px-2 py-2 text-right text-sm text-[#123C2F] outline-none placeholder:text-[#82968B]";
const kindOptions: Array<{ value: ListingKind; label: string; short: string }> = [
  { value: "house", label: "Nhà phố", short: "Nhà" },
  { value: "apartment", label: "Căn hộ", short: "Căn hộ" },
  { value: "land", label: "Đất nền", short: "Đất" },
  { value: "villa", label: "Villa / Resort", short: "Villa" },
  { value: "industrial", label: "Khu công nghiệp", short: "KCN" },
  { value: "commercial_land", label: "Đất thương mại", short: "TM" },
  { value: "agricultural", label: "Đất nông nghiệp", short: "NN" },
  { value: "commercial", label: "Khu thương mại", short: "KTM" },
  { value: "resort", label: "Khu nghỉ dưỡng", short: "Nghỉ dưỡng" },
  { value: "project", label: "Đất dự án", short: "Dự án" },
  { value: "rental", label: "Cho thuê khác", short: "Thuê khác" },
];

export default function DynamicListingFields({ transaction, propertyType, onTransactionChange, onPropertyTypeChange }: Props) {
  const profile = useMemo(() => getListingProfile(transaction, propertyType), [transaction, propertyType]);
  const transactionLabel = transaction === "sale" ? "Đang bán" : "Đang cho thuê";

  return (
    <section className="md:col-span-2 overflow-hidden rounded-[1.5rem] border border-[#C9DED2] bg-white shadow-[0_16px_40px_rgba(31,90,74,.08)]">
      <div className="relative overflow-hidden bg-[#123C2F] px-4 py-5 text-white sm:px-6 sm:py-6">
        <div className="pointer-events-none absolute -right-12 -top-20 h-48 w-48 rounded-full border-[24px] border-[#D9B75D]/20" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#D9B75D] text-[#123C2F] shadow-sm"><Sparkles size={19} /></span>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-[10px] font-bold uppercase tracking-[.2em] text-[#D9B75D]">AI Listing Studio</p>
                <span className="rounded-full bg-white/10 px-2 py-1 text-[10px] font-semibold text-white/75">Tự đổi biểu mẫu</span>
              </div>
              <h3 className="mt-2 text-xl font-bold tracking-tight sm:text-2xl">{profile.label}</h3>
              <p className="mt-1 max-w-xl text-xs leading-5 text-white/70">{profile.eyebrow}. Chỉ hiển thị những trường phù hợp để bài đăng rõ ràng và dễ duyệt.</p>
            </div>
          </div>
          <div className="grid w-full gap-3 sm:grid-cols-2 lg:w-[360px]">
            <label className="text-[10px] font-bold uppercase tracking-[.16em] text-white/60">Loại giao dịch<select name="listingType" value={transaction} onChange={event => onTransactionChange(event.target.value as ListingTransaction)} className={selectClass} aria-label="Loại giao dịch"><option value="sale">Bán bất động sản</option><option value="rent">Cho thuê bất động sản</option></select></label>
            <label className="text-[10px] font-bold uppercase tracking-[.16em] text-white/60">Loại bất động sản<select name="propertyType" value={propertyType} onChange={event => onPropertyTypeChange(event.target.value as ListingKind)} className={selectClass} aria-label="Loại bất động sản">{kindOptions.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
          </div>
        </div>
      </div>

      <div className="border-b border-[#DFECE4] bg-[#F5FAF7] px-4 py-4 sm:px-6">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-bold text-[#123C2F]"><MapPinned size={16} className="text-[#0F6B4F]" /> Hồ sơ {transactionLabel.toLowerCase()} · {profile.label}</div>
          <span className="hidden items-center gap-1 text-[11px] font-semibold text-[#617A6D] sm:flex"><Check size={14} className="text-[#21805E]" /> Trường đã tối ưu</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {kindOptions.map(option => <button type="button" key={option.value} onClick={() => onPropertyTypeChange(option.value)} className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${propertyType === option.value ? "border-[#0F6B4F] bg-[#0F6B4F] text-white" : "border-[#CDE1D6] bg-white text-[#547266] hover:border-[#0F6B4F] hover:text-[#0F6B4F]"}`}>{option.short}</button>)}
        </div>
      </div>

      <div className="bg-[#F5FAF7] px-4 pb-5 sm:px-6 sm:pb-6">
        <div className="mb-3 flex items-center gap-2 text-xs font-bold uppercase tracking-[.16em] text-[#0F6B4F]"><Home size={15} /> Thông tin riêng của mẫu này <ChevronRight size={14} /></div>
        <div className="grid gap-3 sm:grid-cols-2">
          {profile.fields.map(field => field.kind === "textarea" ? (
            <label key={field.name} className="sm:col-span-2 rounded-2xl border border-[#D9E8DE] bg-white p-3 transition focus-within:border-[#0F6B4F] focus-within:ring-2 focus-within:ring-[#0F6B4F]/10">
              <span className="block text-xs font-bold text-[#4F695C]">{field.label}</span>
              <textarea name={field.name} placeholder={field.placeholder} className="mt-2 min-h-20 w-full resize-y bg-transparent text-sm text-[#123C2F] outline-none placeholder:text-[#82968B]" aria-label={field.label} />
            </label>
          ) : (
            <label key={field.name} className="flex min-h-14 items-center gap-2 rounded-2xl border border-[#D9E8DE] bg-white px-3 transition focus-within:border-[#0F6B4F] focus-within:ring-2 focus-within:ring-[#0F6B4F]/10">
              <span className="min-w-0 flex-1 text-xs font-semibold leading-4 text-[#4F695C]">{field.label}</span>
              <input name={field.name} type={field.kind === "number" ? "number" : "text"} placeholder={field.placeholder} className={inputClass} aria-label={field.label} />
              {field.suffix && <span className="shrink-0 text-xs font-semibold text-[#748B7E]">{field.suffix}</span>}
            </label>
          ))}
        </div>
      </div>
    </section>
  );
}
