import { describe, expect, it, beforeEach } from "vitest";
import {
  countUnreadNotifications,
  filterNewConsignmentRequests,
  filterNewConsultationRequests,
  getConsultationNotificationLabel,
  getReadNotificationIds,
  markNotificationsAsRead,
  NOTIFICATION_READ_STORAGE_KEY,
} from "./DashboardLayout";

type StoredWindow = {
  localStorage: {
    getItem: (key: string) => string | null;
    setItem: (key: string, value: string) => void;
  };
  dispatchEvent: (event: Event) => boolean;
};

const requests = [
  { id: 1, name: "Nguyễn An", phone: "0900000001", interest: "Ký gửi bất động sản", message: null, createdAt: Date.now(), status: "new" as const },
  { id: 2, name: "Trần Bình", phone: "0900000002", interest: "Ký gửi bất động sản", message: null, createdAt: Date.now(), status: "new" as const },
  { id: 3, name: "Lê Chi", phone: "0900000003", interest: "Mua BĐS", message: null, createdAt: Date.now(), status: "new" as const },
];

describe("Dashboard notification read state", () => {
  const storage = new Map<string, string>();

  beforeEach(() => {
    storage.clear();
    Object.defineProperty(globalThis, "window", {
      configurable: true,
      value: {
        localStorage: {
          getItem: (key: string) => storage.get(key) ?? null,
          setItem: (key: string, value: string) => storage.set(key, value),
        },
        dispatchEvent: () => true,
      } satisfies StoredWindow,
    });
  });

  it("only filters new consignment requests", () => {
    expect(filterNewConsignmentRequests(requests).map(request => request.id)).toEqual([1, 2]);
  });

  it("includes viewing appointments in the top notification feed", () => {
    const filtered = filterNewConsultationRequests([
      ...requests,
      { id: 4, name: "Đỗ Minh", phone: "0900000004", interest: "Đặt lịch xem: Đất nền Sơn Trà", message: "Muốn xem cuối tuần", createdAt: Date.now(), status: "new" as const },
    ]);
    expect(filtered.map(request => request.id)).toEqual([1, 2, 3, 4]);
    expect(getConsultationNotificationLabel("Đặt lịch xem: Đất nền Sơn Trà")).toBe("Yêu cầu đặt lịch xem");
  });

  it("counts all filtered notifications before they are read", () => {
    const filtered = filterNewConsignmentRequests(requests);
    expect(countUnreadNotifications(filtered)).toBe(2);
  });

  it("removes the red badge count after all visible notifications are read", () => {
    const filtered = filterNewConsignmentRequests(requests);
    markNotificationsAsRead(filtered.map(request => request.id));
    expect(getReadNotificationIds()).toEqual(new Set([1, 2]));
    expect(countUnreadNotifications(filtered)).toBe(0);
    expect(storage.has(NOTIFICATION_READ_STORAGE_KEY)).toBe(true);
  });
});
