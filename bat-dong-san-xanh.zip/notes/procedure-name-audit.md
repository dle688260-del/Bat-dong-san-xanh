# Ghi chú rà soát tên thủ tục

## Nguồn trong registry

- Registry chính: `server/officialLandProcedureRegistry.ts`.
- Chỉ số mã nguồn DVC: `server/officialLandProcedureCodeIndex.ts`.
- Registry yêu cầu mỗi mục có `code`, `name`, `aliases`, `sourceUrl`, `authority` và các tài liệu/mẫu liên quan.
- Mã `2.000889` có alias ngoài `2912`; tên hiện tại là “Đăng ký biến động quyền sử dụng đất do chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn”.
- Mã `1.012789` hiện có tên “Cung cấp thông tin, dữ liệu đất đai”.
- Mã `1.013978` hiện có tên “Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận lần đầu”.
- Mã `1.012783` hiện có tên “Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất”.
- Mã `1.011441` hiện có tên “Đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, tài sản gắn liền với đất”.

## Quy tắc an toàn

- `verifiedTemplates` chỉ được gắn `verified_binary` khi có binary DOCX/PDF thật, checksum SHA-256, URL nguồn và provenance xác minh.
- `referenceTemplates` là metadata tham khảo, không được nâng thành Official chỉ vì có tên hoặc URL.
- Khi chuẩn hóa tên, giữ nguyên mã và alias cũ để không làm hỏng bundle, dữ liệu đã lưu hoặc đường dẫn lookup.
- Cần tách rõ: tên đã chuẩn hóa trong catalog; tên nguồn DVC; tên hiển thị; alias tìm kiếm.

## Kết quả đối chiếu nguồn ngoài ngày 2026-08-23

- Cổng thông tin Bộ Nông nghiệp và Môi trường công bố Quyết định 2304/QĐ-BNNMT ngày 23/06/2025; quyết định có hiệu lực từ 01/07/2025 và thay Quyết định 629/QĐ-BTNMT. Bài công bố cho biết danh mục gồm thủ tục cấp trung ương, cấp tỉnh và cấp xã. Nguồn: https://mae.gov.vn/bo-nong-nghiep-va-moi-truong-cong-bo-thu-tuc-hanh-chinh-linh-vuc-at-ai-18780.htm
- Bản trích lục Quyết định 2304 cho thấy mã `1.012750` có tên “Cung cấp thông tin, dữ liệu đất đai” và mã `1.012751` có tên “Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Nông nghiệp và Môi trường”. Nguồn tham khảo: https://luatvietnam.vn/tai-nguyen/quyet-dinh-2304-qd-bnnmt-2025-cong-bo-thu-tuc-hanh-chinh-linh-vuc-dat-dai-thuoc-quan-ly-cua-bo-nong-nghiep-va-moi-truong-403869-d1.html
- Trang Cổng Dịch vụ công Quốc gia cho mã `1.012789` hiển thị tên “Cung cấp thông tin, dữ liệu đất đai”, liên kết chi tiết `ma_thu_tuc=348167`, quy trình 5 bước và Mẫu 14/14a/14b/14c/14d/14đ. Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
- Nguồn Bộ là căn cứ ưu tiên cho phạm vi/quyết định; Cổng DVC là căn cứ ưu tiên cho tên/quy trình từng mã; nguồn thương mại chỉ dùng để đối chiếu phụ trợ, không dùng để gắn Official.

## Đối soát bổ sung từ nguồn chính thức

Nguồn Bộ Nông nghiệp và Môi trường: https://mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/3305/1.%20PHU%20LUC%20CONG%20BO%20theo%20%20N%C4%90%20151.2025.N%C4%90-CP.pdf — Phụ lục ban hành kèm Quyết định 2304/QĐ-BNNMT ngày 23/06/2025. Tài liệu chứa bảng mã số TTHC và tên thủ tục theo cấp thực hiện.

Nguồn quy trình nội bộ của Cục Quản lý đất đai: https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf — Quyết định 4052/QĐ-BNNMT ngày 30/09/2025, dùng để đối chiếu tên quy trình nội bộ và thành phần xử lý; không dùng riêng tài liệu này để gắn Official binary.

Các tên đã xác nhận trong phần trích xuất: 1.012750 Cung cấp thông tin, dữ liệu đất đai; 1.012751 Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Nông nghiệp và Môi trường; 1.012756 Đăng ký đất đai lần đầu đối với trường hợp được Nhà nước giao đất để quản lý; 1.012766 Xóa đăng ký thuê, cho thuê lại quyền sử dụng đất trong dự án xây dựng kinh doanh kết cấu hạ tầng; 1.012793 Đăng ký biến động đối với trường hợp thành viên của hộ gia đình hoặc cá nhân đang sử dụng đất thành lập doanh nghiệp tư nhân và sử dụng đất vào hoạt động sản xuất kinh doanh của doanh nghiệp; 1.012781 Đăng ký, cấp Giấy chứng nhận đối với thửa đất có diện tích tăng thêm do thay đổi ranh giới so với Giấy chứng nhận đã cấp; 1.012782 Đăng ký, cấp Giấy chứng nhận đối với trường hợp cá nhân, hộ gia đình đã được cấp Giấy chứng nhận một phần diện tích vào loại đất ở trước ngày 01 tháng 7 năm 2004, phần diện tích còn lại của thửa đất chưa được cấp Giấy chứng nhận; 1.012783 Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất; 1.012784 Tách thửa hoặc hợp thửa đất; 1.012786 Cấp lại Giấy chứng nhận do bị mất; 1.012790 Đính chính Giấy chứng nhận đã cấp; 1.012791 Thu hồi Giấy chứng nhận đã cấp không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi; 1.012785 Đăng ký, cấp Giấy chứng nhận đối với trường hợp đã chuyển quyền sử dụng đất trước ngày 01 tháng 8 năm 2024 mà bên chuyển quyền đã được cấp Giấy chứng nhận nhưng chưa thực hiện thủ tục chuyển quyền theo quy định; 1.012787 Đăng ký, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất cho người nhận chuyển nhượng quyền sử dụng đất, quyền sở hữu nhà ở, công trình xây dựng trong dự án bất động sản; 1.012789 Cung cấp thông tin, dữ liệu đất đai; 1.012821 Thẩm định, phê duyệt phương án sử dụng đất; 1.012805 Giải quyết tranh chấp đất đai thuộc thẩm quyền của Chủ tịch Ủy ban nhân dân cấp tỉnh; 1.012819 Cấp lại Giấy chứng nhận do bị mất.

Quy tắc: tên lấy từ cột tên TTHC trong văn bản chính thức; nếu một mã có nhiều dòng do PDF dàn trang thì phải kiểm tra thủ công trước khi cập nhật. Tên chuẩn hóa không đồng nghĩa với Official binary; trạng thái file vẫn Pending cho tới khi có DOCX/PDF, URL nguồn và SHA-256 hợp lệ.

## Xác minh bổ sung ngày 23/08/2026

Nguồn PDF công bố của Văn phòng UBND Đắk Lắk: https://vpubnd.daklak.gov.vn/CMS/Content/PL.DM.TTHC.SNN.CHUAN%20HOA%20DAT%20DAI.edit.official.pdf. Trích văn bản gốc xác nhận:

- **1.012806** — “Giao đất, cho thuê đất, giao khu vực biển để thực hiện hoạt động lấn biển mà người xin giao đất, thuê đất là cá nhân”.
- **1.012807** — “Gia hạn sử dụng đất khi hết thời hạn sử dụng đất mà người xin gia hạn sử dụng đất là cá nhân, cộng đồng dân cư”.

Trang thủ tục hành chính của Cổng thông tin tỉnh Thừa Thiên Huế: https://tthc.hue.gov.vn/Content/Print/thutuc.aspx?iThuTuc=23622 xác nhận mã **1.012818** có tên: “Thu hồi Giấy chứng nhận đã cấp lần đầu không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi”.

Các nguồn trên chỉ xác nhận tên/mã thủ tục; không được dùng để tự gắn Official binary nếu chưa có file mẫu DOCX/PDF và SHA-256 tương ứng.

## Đối chiếu mã nguồn sau lần kiểm tra tiếp theo

Script `notes/source/compare_codes.mjs` hiện trả về `indexedCount: 84`, `namedCount: 60`, `extra: []`. Sáu mã còn thiếu duy nhất là `1.012757`, `1.012774`, `1.012779`, `1.012806`, `1.012807`, `1.012818`; output cũ lặp lại một số mã do hợp nhất nhiều nhóm. Hai mã 1.012806 và 1.012807, cùng 1.012818, đã có căn cứ nguồn được ghi ở mục xác minh bổ sung nhưng cần bảo đảm mapping trong chỉ mục đã được cập nhật và script so sánh đã loại trùng. Không dùng kết quả này để gắn Official binary.

## Bổ sung căn cứ nguồn 2304

Nguồn chính thức của Bộ Nông nghiệp và Môi trường: https://mae.gov.vn/Pages/chitietvanbandh.aspx?ItemID=3305. Trang văn bản xác nhận Quyết định 2304/QĐ-BNNMT ngày 23/06/2025 về công bố thủ tục hành chính lĩnh vực đất đai.

Nguồn đối chiếu nội dung phụ lục: https://luatvietnam.vn/tai-nguyen/quyet-dinh-2304-qd-bnnmt-2025-cong-bo-thu-tuc-hanh-chinh-linh-vuc-dat-dai-thuoc-quan-ly-cua-bo-nong-nghiep-va-moi-truong-403869-d1.html. Các tên đã đọc rõ trong phần trích xuất gồm: 1.012750 — Cung cấp thông tin, dữ liệu đất đai; 1.012751 — Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Nông nghiệp và Môi trường; 1.012756 — Đăng ký đất đai lần đầu đối với trường hợp được Nhà nước giao đất để quản lý; 1.012766 — Xóa đăng ký thuê, cho thuê lại quyền sử dụng đất trong dự án xây dựng kinh doanh kết cấu hạ tầng.

Nguồn xác minh bổ sung của Văn phòng UBND Đắk Lắk: https://vpubnd.daklak.gov.vn/CMS/Content/PL.DM.TTHC.SNN.CHUAN%20HOA%20DAT%20DAI.edit.official.pdf. Mã 1.012806 có tên “Giao đất, cho thuê đất, giao khu vực biển để thực hiện hoạt động lấn biển mà người xin giao đất, thuê đất là cá nhân”; mã 1.012807 có tên “Gia hạn sử dụng đất khi hết thời hạn sử dụng đất mà người xin gia hạn sử dụng đất là cá nhân, cộng đồng dân cư”.

Nguồn Cổng thông tin tỉnh Thừa Thiên Huế: https://tthc.hue.gov.vn/Content/Print/thutuc.aspx?iThuTuc=23622 xác nhận mã 1.012818 có tên “Thu hồi Giấy chứng nhận đã cấp lần đầu không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi”.

Các nguồn trên chỉ xác nhận mã/tên; không được dùng để gắn Official binary nếu chưa có DOCX/PDF, URL file và SHA-256 hợp lệ.
