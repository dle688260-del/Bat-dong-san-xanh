ALTER TABLE `consultation_requests` ADD `aiStatus` enum('pending','analyzed','failed') DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `aiPriority` enum('high','potential','reference') DEFAULT 'reference' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `aiSummary` text;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `aiProfile` text;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `aiMatches` text;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `aiAnalyzedAt` timestamp;