export type LegalSourceAuditInput = {
  province: string;
  sourceUrl: string;
  sourceCheckedAt: string;
  templateProvenance: "metadata-only" | "verified-binary";
  requiredTemplateCount: number;
  verifiedTemplateCount: number;
  now?: Date;
};

export type LegalSourceAuditCheck = {
  id: string;
  label: string;
  passed: boolean;
  detail: string;
};

export type LegalSourceAuditResult = {
  checks: LegalSourceAuditCheck[];
  canReview: boolean;
  canExportOrPrint: boolean;
  canExportDraftOrPrint: boolean;
  blockingReasons: string[];
};

function parseSourceDate(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return null;
  const vietnameseDate = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(trimmed);
  if (vietnameseDate) return new Date(Number(vietnameseDate[3]), Number(vietnameseDate[2]) - 1, Number(vietnameseDate[1]));
  const parsed = new Date(trimmed);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function auditLandDossierLegalSources(input: LegalSourceAuditInput): LegalSourceAuditResult {
  const now = input.now ?? new Date();
  const sourceDate = parseSourceDate(input.sourceCheckedAt);
  const ageDays = sourceDate ? Math.floor((now.getTime() - sourceDate.getTime()) / 86_400_000) : Number.POSITIVE_INFINITY;
  const checks: LegalSourceAuditCheck[] = [
    { id: "province", label: "Đã xác định địa phương", passed: Boolean(input.province.trim()), detail: input.province.trim() || "Chưa chọn tỉnh/thành." },
    { id: "https", label: "Nguồn dùng HTTPS", passed: input.sourceUrl.startsWith("https://"), detail: input.sourceUrl || "Chưa có URL nguồn." },
    { id: "checked-date", label: "Có ngày kiểm tra nguồn", passed: Boolean(sourceDate), detail: sourceDate ? sourceDate.toLocaleDateString("vi-VN") : "Thiếu hoặc sai định dạng ngày kiểm tra." },
    { id: "freshness", label: "Nguồn còn trong thời hạn rà soát", passed: ageDays >= 0 && ageDays <= 365, detail: Number.isFinite(ageDays) ? `Đã kiểm tra ${ageDays} ngày trước.` : "Không xác định được tuổi nguồn." },
    { id: "template-binary", label: "Mẫu gốc đã xác minh", passed: input.templateProvenance === "verified-binary" && input.verifiedTemplateCount >= input.requiredTemplateCount, detail: input.templateProvenance === "verified-binary" ? "Có binary đã xác minh." : "Mới có metadata hoặc nguồn tham khảo." },
  ];
  const blockingReasons = checks.filter(check => !check.passed).map(check => check.detail);
  const canReview = checks.slice(0, 4).every(check => check.passed);
  const canExportOrPrint = checks.every(check => check.passed);
  // Người dùng được phép tạo bản nháp để kiểm tra, in và mang đi đối chiếu;
  // mẫu Official vẫn giữ điều kiện binary riêng ở canExportOrPrint.
  const canExportDraftOrPrint = canReview;
  return { checks, canReview, canExportOrPrint, canExportDraftOrPrint, blockingReasons };
}

export function legalSourceAuditSummary(result: LegalSourceAuditResult) {
  if (result.canExportOrPrint) return "Đã đối chiếu nguồn, địa phương và mẫu binary; có thể xuất mẫu Official.";
  if (result.canExportDraftOrPrint) return "Có thể tạo, xem trước và in bản nháp AI; mẫu Official vẫn cần binary được xác minh.";
  return "Chưa đủ căn cứ đối chiếu pháp lý; cần bổ sung địa phương, nguồn HTTPS hoặc ngày kiểm tra.";
}

export const LEGAL_SOURCE_AUDIT_IDS = ["province", "https", "checked-date", "freshness", "template-binary"] as const;

export type LegalSourceAuditId = (typeof LEGAL_SOURCE_AUDIT_IDS)[number];
