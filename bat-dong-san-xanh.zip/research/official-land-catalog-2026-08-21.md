# Căn cứ mở rộng catalog thủ tục đất đai

Ngày kiểm tra: 2026-08-21.

## Nguồn chính thức đã đọc

1. [Cổng DVC Quốc gia — mã 1.013978](https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978). Trang nêu thủ tục đăng ký đất đai, tài sản gắn liền với đất và cấp Giấy chứng nhận lần đầu; phần thành phần hồ sơ có liên kết binary `Mus15DKLD.docx` tới `https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1`. Trang cũng mô tả các bước tiếp nhận, xác nhận tại cấp xã và chuyển Chi nhánh Văn phòng đăng ký đất đai.

2. [Cổng DVC Quốc gia — mã 1.012783](https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783). Trang nêu thủ tục cấp đổi Giấy chứng nhận; cơ quan tiếp nhận gồm Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh Văn phòng đăng ký đất đai. Thời hạn và điều kiện thay đổi theo trường hợp; không được suy ra biểu mẫu Official chỉ từ tên thủ tục.

3. [Quyết định/quy trình nội bộ lĩnh vực đất đai của Bộ NN&MT](https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf). Phần danh mục hiển thị mã 1.012750 về cung cấp thông tin, dữ liệu đất đai và mã 1.012751 về giải quyết tranh chấp đất đai thuộc thẩm quyền Bộ trưởng. Tài liệu mô tả quy trình nội bộ, cơ quan thực hiện và các Mẫu 14, 14a, 14b, 14c, 14d, 14đ cho yêu cầu cung cấp thông tin. Đây là nguồn metadata/quy trình; binary chỉ được gắn Official sau khi tải và kiểm SHA-256.

4. [Kết quả tìm kiếm danh mục TTHC lĩnh vực Nông nghiệp và Môi trường](https://vukhcn.monre.gov.vn/thong-tin-tuyen-truyen/-danh-muc-thu-tuc-hanh-chinh-trong-linh-vuc-nong-nghiep-va-moi-truong/tt-7996). Kết quả tìm kiếm chính thức nêu lĩnh vực Đất đai có 66 TTHC. Trang không trích xuất được toàn văn tự động trong lần đọc này, vì vậy chưa nhập 66 mã vào registry khi chưa có bảng mã xác thực.

## Quy tắc nhập catalog

Chỉ nhập mã, tên, cơ quan và URL khi đối chiếu được từ nguồn chính thức. Nguồn quy trình hoặc trang hướng dẫn có thể tạo bản ghi metadata/Pending; chỉ binary tải được, đúng liên kết thành phần và vượt kiểm tra chữ ký/SHA-256 mới được phân loại Official. Các mã bổ sung 1.012750 và 1.012751 là căn cứ nghiên cứu tiếp theo, chưa tự động thêm vào registry core trong phiên này vì cần đối soát đầy đủ dữ liệu thành phần hồ sơ và mapping.


## Bổ sung nguồn chính thức đã xác nhận

5. [Trang văn bản Bộ NN&MT — Quyết định 2304/QĐ-BNNMT](https://mae.gov.vn/Pages/chitietvanbandh.aspx?ItemID=3305) xác nhận quyết định ngày 23/06/2025 và liên kết ba phụ lục chính thức. Phụ lục chi tiết được dùng làm căn cứ quy trình/mẫu; không tự gắn Official nếu chưa tải binary và kiểm SHA-256.

6. [Sổ tay điện tử Cục Quản lý đất đai](https://qldd.mae.gov.vn/so-tay-dien-tu/so-tay-dien-tu-huong-dan-ve-trinh-tu-thu-tuc-hanh-chinh-linh-vuc-dat-dai-thuoc-pham-vi-chuc-nang-quan-ly-nha-nuoc-cua-bo-nong-nghiep-va-moi-truong-3318.htm) xác nhận có sơ đồ cho 48 TTHC đất đai và 10 thủ tục nội bộ, kèm các thư mục discovery cấp Trung ương, cấp tỉnh, cấp xã và nội bộ trên Google Drive. Các thư mục chỉ là nguồn discovery; mã TTHC phải được đối chiếu với trang/quyết định chính thức trước khi nhập catalog.

7. Thư mục discovery cấp Trung ương: https://drive.google.com/drive/folders/1oxvmBtTmJ3jEtDMkzN-4FL_5DKXj1u0c?usp=sharing
8. Thư mục discovery cấp tỉnh: https://drive.google.com/drive/folders/1OWX_co3__UjeNlT6JIykZpZrrBhS05Or?usp=sharing
9. Thư mục discovery cấp xã: https://drive.google.com/drive/folders/1oBu3P8lxOTDK92FUho4jD2BZxUY7k3tL?usp=sharing
10. Thư mục thủ tục nội bộ: https://drive.google.com/drive/folders/13qbgnsfzOOZxm9Dc50gXWVrCbpw6MG_L

Kết luận cập nhật: nguồn chính thức xác nhận phạm vi 48 TTHC dân sự/doanh nghiệp và 10 thủ tục nội bộ, nhưng lần trích xuất hiện tại không cung cấp bảng mã đầy đủ ở dạng máy đọc được. Hệ thống tiếp tục giữ catalog động theo các mã đã đối chiếu, và để các mục chưa có mã ở Queue for Code Matching/Pending thay vì tạo mã giả.
