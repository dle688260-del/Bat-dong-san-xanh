import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: null,
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("consultations.create", () => {
  it("rejects a request without a valid phone number", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.consultations.create({
      interest: "An cư tại Đà Nẵng",
      name: "Nguyễn Văn A",
      phone: "123",
      message: "",
    })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
