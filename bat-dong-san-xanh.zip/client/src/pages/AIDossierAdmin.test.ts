import { describe, expect, it } from "vitest";
import { aiLandWorkspaceTabs, aiDossierProcedureSearch, aiDossierBuildInputProperty, aiDossierAcceptsCamera, aiDossierAiAssistKinds, aiDossierArchiveCategory, aiDossierAutofillTemplate, aiDossierEvidenceStatusLabel, aiDossierFileActions, aiDossierLandProcedureTitles, aiDossierLegalDisclaimer, aiDossierLegalTemplateTitles, aiDossierNaturalSearch, aiDossierOfficialSource, aiDossierOfficialSourceIds, aiDossierProcedureRequirements, aiDossierProcedureTemplates, aiDossierSubmissionStatusLabel, aiDossierTemplateNames, aiDossierUniversalPreviewSample, aiDossierUniversalWorkflowTitles, aiDossierOfficialLegalDocuments, aiDossierOfficialTemplateMetadata, aiDossierProcedureLegalBundle, aiDossierExportFormats, aiDossierChecklistTemplateMapping, aiDossierLegalVerificationNextStep, aiDossierAnalysisStatus, aiDossierManualBrokerTemplate, aiDossierSharedLegalSourceTitle } from "./AIDossierAdmin";

describe("AI dossier workspace", () => {
  it("keeps the three separate land-AI workspaces visible", () => {
    expect(aiLandWorkspaceTabs()).toEqual(["Tạo hồ sơ", "Hồ sơ của tôi", "AI chuyên trách đất đai"]);
  });
  it("exposes the requested survey, planning and transaction templates", () => {
    expect(aiDossierTemplateNames()).toEqual([
      "Phiếu khảo sát BĐS",
      "Phiếu kiểm tra quy hoạch",
      "Quy trình đặt cọc – sang tên",
    ]);
  });

  it("supports camera capture and file actions", () => {
    expect(aiDossierAcceptsCamera()).toBe(true);
    expect(aiDossierFileActions()).toEqual(["Xem file", "Tải về", "Xóa"]);
  });

  it("includes the user-requested complete AI land dossier pack in the legal template catalog", () => {
    expect(aiDossierLegalTemplateTitles()).toContain("AI · BỘ HỒ SƠ ĐẤT ĐAI HOÀN CHỈNH · THEO YÊU CẦU NGƯỜI DÙNG");
  });

  it("maps legal templates to official sources with version metadata", () => {
    const ids = aiDossierOfficialSourceIds();
    expect(ids).toContain("transfer-variation");
    expect(ids).toContain("registration-certificate");
    const source = aiDossierOfficialSource("transfer-variation");
    expect(source?.sourceUrl).toMatch(/^https:\/\//);
    expect(source?.lastCheckedAt).toBe("16/08/2026");
    expect(source?.version).toContain("2.000410");
    expect(source?.status).toBe("verified");
  });

  it("does not claim a directory source is an approved legal form", () => {
    const source = aiDossierOfficialSource("transfer-tax");
    expect(source?.status).toBe("directory");
    expect(source?.version).toContain("không phải bản mẫu thuế");
  });

  it("classifies archive groups and matches Vietnamese natural-language queries", () => {
    expect(aiDossierArchiveCategory("legal")).toBe("Pháp lý");
    expect(aiDossierArchiveCategory("transaction")).toBe("Giao dịch");
    expect(aiDossierNaturalSearch("Tờ khai chuyển nhượng quyền sử dụng đất", "Hồ sơ chuyển nhượng đất")).toBe(true);
    expect(aiDossierNaturalSearch("Phiếu khảo sát căn hộ", "Hồ sơ công chứng")).toBe(false);
    expect(aiDossierNaturalSearch("Đăng ký biến động đất đai", "dang ky bien dong dat")).toBe(true);
    expect(aiDossierNaturalSearch("Hồ sơ tách thửa quyền sử dụng đất", "công chứng")).toBe(false);
  });

  it("matches expanded land-search records beyond the default procedure list", () => {
    expect(aiDossierNaturalSearch("Đơn đề nghị cấp Giấy chứng nhận quyền sử dụng đất", "cấp giấy chứng nhận")).toBe(true);
    expect(aiDossierNaturalSearch("Giấy tờ công chứng chuyển nhượng đất Sơn Trà", "công chứng đất")).toBe(true);
    expect(aiDossierNaturalSearch("Hợp đồng thuê mặt bằng thương mại", "thừa kế đất")).toBe(false);
  });

  it("returns separate split and merge procedures and templates", () => {
    expect(aiDossierLandProcedureTitles()).toEqual(expect.arrayContaining(["Tách thửa", "Hợp thửa"]));
    expect(aiDossierLegalTemplateTitles("tách thửa")).toContain("Đơn đề nghị tách thửa");
    expect(aiDossierLegalTemplateTitles("hợp thửa")).toContain("Đơn đề nghị hợp thửa");
    expect(aiDossierLegalTemplateTitles("tách thửa")).not.toContain("Đơn đề nghị hợp thửa");
  });

  it("fills split and merge templates with user dossier data and preserves missing-field warnings", () => {
    const answers = { seller: "Nguyễn Văn A", buyer: "", parcel: "Thửa 123, tờ bản đồ 04", certificate: "GCN số CS123", marital: "Đã kết hôn", mortgage: "Không thế chấp", location: "Đà Nẵng" };
    const split = aiDossierAutofillTemplate("Đơn đề nghị tách thửa", "Nội dung mẫu tách thửa", answers);
    const merge = aiDossierAutofillTemplate("Đơn đề nghị hợp thửa", "Nội dung mẫu hợp thửa", answers);
    expect(split).toContain("Đơn đề nghị tách thửa");
    expect(split).toContain("Thửa 123, tờ bản đồ 04");
    expect(split).toContain("[CHƯA NHẬP — CẦN BỔ SUNG]");
    expect(merge).toContain("Đơn đề nghị hợp thửa");
    expect(merge).toContain("Đà Nẵng");
  });

  it("builds an input-only land record without requiring an existing property", () => {
    const input = aiDossierBuildInputProperty({ seller: "Nguyễn Văn A", buyer: "", parcel: "Thửa 12, tờ 03", certificate: "GCN CS123", marital: "", mortgage: "", location: "Đà Nẵng" });
    expect(input.id).toBe(0);
    expect(input.title).toContain("chưa gắn BĐS");
    expect(input.location).toBe("Đà Nẵng");
    expect(input.ownerName).toBe("Nguyễn Văn A");
    expect(input.propertyCode).toBeNull();
  });

  it("searches Vietnamese procedures without accents and filters by procedure family", () => {
    expect(aiDossierProcedureSearch("cap giay chung nhan").some(item => item.id === "first_registration")).toBe(true);
    expect(aiDossierProcedureSearch("", "bien-dong").every(item => ["transfer", "gift", "inheritance", "variation"].includes(item.id))).toBe(true);
    expect(aiDossierProcedureSearch("tách thửa", "thua-dat").some(item => item.id === "split")).toBe(true);
  });

  it("shows procedure-specific templates when a procedure is selected", () => {
    expect(aiDossierProcedureTemplates("split")).toContain("Đơn đề nghị tách thửa");
    expect(aiDossierProcedureTemplates("split")).not.toContain("Đơn đề nghị hợp thửa");
    expect(aiDossierProcedureTemplates("inheritance")).toContain("Bộ hồ sơ thừa kế quyền sử dụng đất");
  });

  it("exposes the universal six-step dossier workflow", () => {
    expect(aiDossierUniversalWorkflowTitles()).toEqual([
      "Thông tin hồ sơ", "Chọn thủ tục", "AI phân tích", "Lắp bộ hồ sơ", "Rà soát & chỉnh sửa", "Xuất hồ sơ",
    ]);
    expect(aiDossierProcedureRequirements("inheritance")).toContain("Thông tin người thừa kế");
    expect(aiDossierProcedureRequirements("purpose")).toContain("Mục đích đề nghị chuyển");
    expect(aiDossierUniversalPreviewSample("transfer")).toContain("MỤC LỤC");
    expect(aiDossierUniversalPreviewSample("transfer")).toContain("6. Xuất hồ sơ");
  });

  it("maps official template metadata to the selected land procedure", () => {
    const variation = aiDossierOfficialTemplateMetadata("variation");
    expect(variation.length).toBeGreaterThan(0);
    expect(variation.every(template => template.title)).toBe(true);
    const officialFiles = variation.filter(template => template.officialFileName);
    expect(officialFiles.length).toBeGreaterThanOrEqual(2);
    expect(officialFiles.every(template => template.officialFormStatus)).toBe(true);
    const namedFiles = officialFiles.map(template => template.officialFileName).filter(Boolean).join(" ");
    expect(namedFiles).toMatch(/09|18|Mus15|DKLD/i);
  });

  it("uses verified government legal documents as the source set for dossier generation", () => {
    const documents = aiDossierOfficialLegalDocuments();
    expect(documents).toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: "Luật", status: "verified", sourceUrl: expect.stringContaining("vanban.chinhphu.vn") }),
      expect.objectContaining({ kind: "Nghị định", status: "verified", sourceUrl: expect.stringContaining("vanban.chinhphu.vn") }),
      expect.objectContaining({ kind: "Cổng thủ tục", status: "verified", sourceUrl: expect.stringContaining("dichvucong.gov.vn") }),
    ]));
    expect(documents.every(document => document.lastCheckedAt && document.sourceUrl && document.note)).toBe(true);
  });

  it("automatically bundles legal documents and mapped templates after selecting a procedure", () => {
    const bundle = aiDossierProcedureLegalBundle("variation");
    expect(bundle.procedureTitle).toContain("Đăng ký biến động");
    expect(bundle.legalDocuments.map(document => document.kind)).toEqual(expect.arrayContaining(["Luật", "Nghị định", "Cổng thủ tục"]));
    expect(bundle.officialTemplate?.sourceUrl).toMatch(/^https:\/\//);
    expect(bundle.templates.length).toBeGreaterThan(0);
  });

  it("exposes the next action after legal-source selection", () => {
    expect(aiDossierLegalVerificationNextStep()).toEqual({ step: 5, label: "Bước 5–8 · AI kiểm tra và dựng bộ hồ sơ", actionLabel: "Xác minh & phân tích tiếp" });
  });

  it("explains why AI analysis is waiting and what action comes next", () => {
    expect(aiDossierAnalysisStatus({ filesCount: 0, ocrStatus: "idle", confirmed: false, aiCheck: "idle" }).nextAction).toBe("Tải hoặc chụp giấy tờ");
    expect(aiDossierAnalysisStatus({ filesCount: 1, ocrStatus: "processing", confirmed: false, aiCheck: "idle" }).title).toBe("OCR đang đọc giấy tờ");
    expect(aiDossierAnalysisStatus({ filesCount: 1, ocrStatus: "ready", confirmed: false, aiCheck: "idle" }).nextAction).toBe("Kiểm tra và xác nhận OCR");
    expect(aiDossierAnalysisStatus({ filesCount: 1, ocrStatus: "ready", confirmed: true, aiCheck: "idle" }).nextAction).toBe("Bấm AI phân tích và dựng bộ hồ sơ");
  });

  it("labels evidence and submission states for the closed-loop land workflow", () => {
    expect(aiDossierEvidenceStatusLabel("uploaded")).toBe("Đang tải lên");
    expect(aiDossierEvidenceStatusLabel("review")).toContain("AI/OCR");
    expect(aiDossierSubmissionStatusLabel("ready_to_print")).toBe("Sẵn sàng in");
    expect(aiDossierSubmissionStatusLabel("signed")).toBe("Đã ký");
    expect(aiDossierSubmissionStatusLabel("submitted")).toBe("Đã chuẩn bị nộp");
  });

  it("exposes a clear legal disclaimer for AI results", () => {
    expect(aiDossierLegalDisclaimer()).toContain("không thay thế");
  });

  it("supports structured AI checklist statuses", () => {
    expect(aiDossierAiAssistKinds()).toEqual(["required", "conditional", "verify"]);
  });

  it("maps checklist requirements to templates without falsely promoting pending files", () => {
    const mapping = aiDossierChecklistTemplateMapping("transfer", ["Đơn đăng ký biến động", "Giấy chứng nhận bản gốc", "Tờ khai thuế"]);
    expect(mapping[0].templateLabel || mapping[0].templateStatus).toBeTruthy();
    expect(mapping.every(item => ["official", "reference", "pending", "not-applicable"].includes(item.templateStatus))).toBe(true);
    expect(mapping.some(item => item.templateStatus === "reference")).toBe(true);
    expect(mapping.every(item => item.templateStatus !== "reference" || item.templateStatus !== "official")).toBe(true);
  });

  it("exposes the user-provided manual broker template as a downloadable DOCX asset", () => {
    const template = aiDossierManualBrokerTemplate();
    expect(template.title).toContain("chủ nhà");
    expect(template.fileName).toBe("phieu-dam-phan-bds.docx");
    expect(template.fileUrl).toMatch(/^\/manus-storage\/.*\.docx$/);
    expect(template.usage).toContain("thủ công");
  });

  it("uses the shared legal-source registry from the legal knowledge base", () => {
    expect(aiDossierSharedLegalSourceTitle).toBe("Nguồn pháp lý từ AI Kho pháp lý hồ sơ AI");
  });

  it("uses binary-friendly export formats and keeps Official status gated", () => {
    expect(aiDossierExportFormats()).toEqual({
      preferred: "DOCX",
      available: ["DOCX", "PDF"],
      legacyHtmlDocRemoved: true,
      officialLabelRequiresVerifiedBinary: true,
    });
  });
});
