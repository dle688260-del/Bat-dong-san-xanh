import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("PWA installability", () => {
  const publicDir = resolve(process.cwd(), "client/public");

  it("declares a standalone manifest with stable app identity and icons", () => {
    const manifest = JSON.parse(readFileSync(resolve(publicDir, "manifest.webmanifest"), "utf8"));
    expect(manifest.id).toBe("/");
    expect(manifest.start_url).toBe("/");
    expect(manifest.scope).toBe("/");
    expect(manifest.display).toBe("standalone");
    expect(manifest.icons).toEqual(expect.arrayContaining([
      expect.objectContaining({ sizes: "192x192", type: "image/png" }),
      expect.objectContaining({ sizes: "512x512", type: "image/png" }),
    ]));
  });

  it("declares a CRM manifest scoped to the CRM entrypoint", () => {
    const manifest = JSON.parse(readFileSync(resolve(publicDir, "crm-manifest.webmanifest"), "utf8"));
    expect(manifest.id).toBe("/crm-app");
    expect(manifest.start_url).toBe("/crm");
    expect(manifest.scope).toBe("/crm");
    expect(manifest.display).toBe("standalone");
    expect(manifest.name).toContain("CRM");
  });

  it("ships a root-scoped service worker without API caching", () => {
    const serviceWorker = readFileSync(resolve(publicDir, "sw.js"), "utf8");
    expect(serviceWorker).toContain('self.addEventListener("install"');
    expect(serviceWorker).toContain('self.addEventListener("activate"');
    expect(serviceWorker).toContain('request.method !== "GET"');
    expect(serviceWorker).toContain('request.mode === "navigate"');
    expect(serviceWorker).toContain('response.ok');
    expect(serviceWorker).toContain('bdsxanh-shell-v3');
    expect(serviceWorker).toContain('"/crm"');
    expect(serviceWorker).toContain('"/crm/login"');
    expect(serviceWorker).toContain('path.startsWith("/crm/")');
    expect(serviceWorker).not.toContain("/api/trpc");
  });

  it("selects the CRM manifest before the browser installs from a CRM route", () => {
    const html = readFileSync(resolve(process.cwd(), "client/index.html"), "utf8");
    expect(html).toContain('manifest.href = isCrm ? "/crm-manifest.webmanifest" : "/manifest.webmanifest"');
    expect(html).toContain('path.indexOf("/crm/") === 0');
  });

  it("keeps installation infrastructure while keeping the public storefront compact", () => {
    const home = readFileSync(resolve(process.cwd(), "client/src/pages/Home.tsx"), "utf8");
    expect(home).not.toContain("Cài ngay");
    expect(home).not.toContain("Cài đặt ứng dụng");
    expect(home).not.toContain("beforeinstallprompt");
    expect(home).toContain('href="/bat-dong-san"');
  });
});
