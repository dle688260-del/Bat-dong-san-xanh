import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import {
  ArrowUpRight,
  Bell,
  Camera,
  FileUp,
  Bot,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  ClipboardCheck,
  ClipboardList,
  FileText,
  Handshake,
  Home,
  LayoutDashboard,
  Link2,
  MapPin,
  Phone,
  RefreshCw,
  Save,
  ScanLine,
  ShieldCheck,
  Sparkles,
  Unplug,
  Upload,
  Users,
  Video,
  WalletCards,
} from "lucide-react";
import DashboardLayout, {
  filterNewConsignmentRequests,
  getReadNotificationIds,
  markNotificationsAsRead,
} from "@/components/DashboardLayout";
import { PwaInstallButton } from "@/components/PwaInstallButton";
import { trpc } from "@/lib/trpc";
import { useCrmInstallManifest } from "@/hooks/useCrmInstallManifest";
import CrmPlanningWorkbench from "@/components/CrmPlanningWorkbench";
import CrmLocationSurvey from "@/components/CrmLocationSurvey";
import CrmNearbyProperties from "@/components/CrmNearbyProperties";
import CrmPlanningReview from "@/components/CrmPlanningReview";

export const CRM_NAV_ITEMS = [
  { label: "Trang CRM", href: "/crm", icon: Home },
  { label: "Trung tâm điều hành", href: "/dashboard", icon: LayoutDashboard },
  { label: "Nguồn hàng & BĐS", href: "/quan-ly-moi-gioi", icon: Home },
  { label: "Marketing", href: "/dashboard/marketing", icon: Sparkles },
  { label: "Khách hàng & Lead", href: "/dashboard/khach-hang", icon: Users },
  { label: "AI Matching & Trợ lý", href: "/dashboard/ai", icon: Bot },
  {
    label: "Đàm phán & Giao dịch",
    href: "/dashboard/giao-dich",
    icon: Handshake,
  },
  { label: "Hồ sơ & Tài liệu", href: "/ho-so-dien-tu", icon: ClipboardList },
  {
    label: "Báo cáo & Quản trị",
    href: "/dashboard/bao-cao",
    icon: CircleDollarSign,
  },
];

export const CRM_WORKFLOW_CENTERS = [
  {
    order: 1,
    label: "Điều hành",
    description:
      "Nhìn toàn cảnh nguồn hàng, khách, giao dịch, doanh thu và cảnh báo.",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    order: 2,
    label: "Tạo nguồn hàng",
    description:
      "Tiếp nhận chủ nhà → khảo sát → quy hoạch → pháp lý → định giá → đàm phán → ký gửi → tạo bài đăng.",
    href: "/quan-ly-moi-gioi",
    icon: Home,
  },
  {
    order: 3,
    label: "Sản phẩm BĐS",
    description:
      "Biến nguồn hàng đã ký gửi thành sản phẩm có ảnh, video, 3D, bản đồ và giá.",
    href: "/quan-ly-moi-gioi",
    icon: Home,
  },
  {
    order: 4,
    label: "Marketing",
    description: "Chiến dịch → nội dung → kênh → Lead → đo chuyển đổi.",
    href: "/dashboard/marketing",
    icon: Sparkles,
  },
  {
    order: 5,
    label: "Khách hàng 360",
    description:
      "Một hồ sơ khách gồm nhu cầu, ngân sách, lịch sử liên hệ và giao dịch.",
    href: "/dashboard/khach-hang",
    icon: Users,
  },
  {
    order: 6,
    label: "AI Matching",
    description: "Ghép khách phù hợp với BĐS và BĐS phù hợp với khách.",
    href: "/dashboard/ai",
    icon: Bot,
  },
  {
    order: 7,
    label: "Tài chính & Dẫn khách",
    description: "Tính khả năng tài chính, đặt lịch xem và ghi nhận phản hồi.",
    href: "/dashboard/ai",
    icon: WalletCards,
  },
  {
    order: 8,
    label: "Đàm phán",
    description:
      "Lưu giá, điều kiện, cọc và chuyển sang giao dịch khi đạt thỏa thuận.",
    href: "/quy-trinh-moi-gioi",
    icon: Handshake,
  },
  {
    order: 9,
    label: "Giao dịch",
    description:
      "Cọc → hồ sơ → công chứng → thanh toán → sang tên → bàn giao → hoàn tất.",
    href: "/dashboard/giao-dich",
    icon: Handshake,
  },
  {
    order: 10,
    label: "Hồ sơ & Tài liệu",
    description:
      "Kho BĐS, khách, chủ nhà, pháp lý, biểu mẫu và tệp đã phân loại.",
    href: "/ho-so-dien-tu",
    icon: ClipboardList,
  },
  {
    order: 11,
    label: "Tự động hóa",
    description:
      "Sinh nhiệm vụ, deadline, checklist và thông báo theo sự kiện nghiệp vụ.",
    href: "/quy-trinh-moi-gioi",
    icon: ClipboardCheck,
  },
  {
    order: 12,
    label: "Quản trị & BI",
    description: "Nhân sự, phân quyền, KPI, doanh số, hoa hồng và hiệu suất.",
    href: "/dashboard/bao-cao",
    icon: CircleDollarSign,
  },
] as const;

export const SOURCE_CREATION_STEPS = [
  {
    label: "Tiếp nhận",
    detail: "Thông tin chủ nhà, BĐS, ảnh, tệp và phiếu tiếp nhận.",
    href: "/quan-ly-moi-gioi?process=intake",
    icon: ClipboardList,
  },
  {
    label: "Khảo sát",
    detail: "Hiện trạng, vị trí, tiện ích và ghi chú thực tế.",
    href: "/quan-ly-moi-gioi?process=survey",
    icon: MapPin,
  },
  {
    label: "Quy hoạch",
    detail: "Đối chiếu quy hoạch, khu vực và nguồn tham chiếu.",
    href: "/quan-ly-moi-gioi?process=planning",
    icon: LayoutDashboard,
  },
  {
    label: "Pháp lý",
    detail: "Danh mục giấy tờ, kiểm tra và cảnh báo thiếu hồ sơ.",
    href: "/quan-ly-moi-gioi?process=legal",
    icon: ShieldCheck,
  },
  {
    label: "Định giá",
    detail: "Giá tham chiếu, giả định và đề xuất cần xác nhận.",
    href: "/quan-ly-moi-gioi?process=valuation",
    icon: WalletCards,
  },
  {
    label: "Đàm phán chủ nhà",
    detail: "Giá, điều kiện, lịch sử trao đổi và kết quả.",
    href: "/quan-ly-moi-gioi?process=negotiation",
    icon: Handshake,
  },
  {
    label: "Ký gửi",
    detail: "Điều kiện ký gửi và xác nhận đưa vào kinh doanh.",
    href: "/quan-ly-moi-gioi?process=consignment",
    icon: CheckCircle2,
  },
  {
    label: "Tạo bài đăng sản phẩm",
    detail: "Đưa dữ liệu đã xác nhận vào bài đăng trước khi công khai.",
    href: "/quan-ly-moi-gioi?process=listing",
    icon: Home,
  },
] as const;

export const SOURCE_FORM_FIELDS: Record<
  string,
  Array<{ label: string; placeholder: string; wide?: boolean }>
> = {
  "Tiếp nhận": [
    { label: "Tên chủ nhà/đầu mối", placeholder: "Nhập họ tên hoặc tổ chức" },
    { label: "Số điện thoại", placeholder: "Nhập số liên hệ" },
    {
      label: "Địa chỉ BĐS",
      placeholder: "Số nhà, đường, phường/xã, tỉnh/thành",
      wide: true,
    },
    {
      label: "Loại nguồn hàng",
      placeholder: "Thị trường / cộng tác / chủ nhà",
    },
    {
      label: "Ghi chú tiếp nhận",
      placeholder: "Nội dung trao đổi ban đầu",
      wide: true,
    },
  ],
  "Khảo sát": [
    { label: "Ngày khảo sát", placeholder: "dd/mm/yyyy" },
    { label: "Người khảo sát", placeholder: "Tên môi giới phụ trách" },
    {
      label: "Hiện trạng thực tế",
      placeholder: "Nhà, đất, lối vào, hạ tầng",
      wide: true,
    },
    {
      label: "Tiện ích và khu vực",
      placeholder: "Trường học, chợ, đường, dịch vụ",
      wide: true,
    },
  ],
  "Quy hoạch": [
    { label: "Số tờ / số thửa", placeholder: "Nhập thông tin thửa đất" },
    {
      label: "Nguồn tra cứu",
      placeholder: "Cổng thông tin hoặc văn bản tham chiếu",
    },
    {
      label: "Kết quả sơ bộ",
      placeholder: "Nhập kết quả đối chiếu",
      wide: true,
    },
    {
      label: "Cảnh báo cần xác minh",
      placeholder: "Ghi rõ điểm chưa chắc chắn",
      wide: true,
    },
  ],
  "Pháp lý": [
    {
      label: "Loại giấy tờ đã nhận",
      placeholder: "GCN, CCCD, ủy quyền...",
      wide: true,
    },
    { label: "Số hồ sơ / số phát hành", placeholder: "Nhập số giấy tờ" },
    { label: "Tình trạng kiểm tra", placeholder: "Đủ / thiếu / cần đối chiếu" },
    {
      label: "Ghi chú pháp lý",
      placeholder: "Không phải kết luận pháp lý",
      wide: true,
    },
  ],
  "Định giá": [
    { label: "Giá chủ nhà đề xuất", placeholder: "Nhập số tiền" },
    { label: "Giá tham chiếu", placeholder: "Nhập số tiền và nguồn" },
    {
      label: "Giả định định giá",
      placeholder: "Diện tích, vị trí, hiện trạng",
      wide: true,
    },
    {
      label: "Mức giá đề xuất",
      placeholder: "Môi giới xác nhận trước khi dùng",
    },
  ],
  "Đàm phán chủ nhà": [
    { label: "Ngày trao đổi", placeholder: "dd/mm/yyyy" },
    { label: "Giá/điều kiện mới", placeholder: "Nhập nội dung cập nhật" },
    {
      label: "Kết quả đàm phán",
      placeholder: "Đồng ý / cần trao đổi thêm",
      wide: true,
    },
    {
      label: "Lịch sử và ghi chú",
      placeholder: "Tóm tắt trao đổi",
      wide: true,
    },
  ],
  "Ký gửi": [
    { label: "Thời hạn ký gửi", placeholder: "dd/mm/yyyy - dd/mm/yyyy" },
    { label: "Mức phí/hoa hồng", placeholder: "Nhập tỷ lệ hoặc số tiền" },
    {
      label: "Điều kiện ký gửi",
      placeholder: "Độc quyền, giá, kênh đăng",
      wide: true,
    },
    {
      label: "Xác nhận chủ nhà",
      placeholder: "Đã xác nhận / chờ ký",
      wide: true,
    },
  ],
  "Tạo bài đăng sản phẩm": [
    { label: "Tiêu đề bài đăng", placeholder: "Tên BĐS đã được xác nhận" },
    { label: "Giá và trạng thái", placeholder: "Giá bán · đang bán/chờ duyệt" },
    {
      label: "Mô tả sản phẩm",
      placeholder: "Mô tả đã kiểm tra từ hồ sơ nguồn hàng",
      wide: true,
    },
    {
      label: "Ảnh, video và thông tin hiển thị",
      placeholder: "Tải ảnh/video hoặc chọn dữ liệu đã có",
      wide: true,
    },
    {
      label: "Duyệt trước khi công khai",
      placeholder: "Môi giới kiểm tra và xác nhận",
      wide: true,
    },
  ],
};

const CRM_PRIMARY_HREFS = [
  "/crm",
  "/dashboard",
  "/quan-ly-moi-gioi",
  "/dashboard/marketing",
  "/dashboard/khach-hang",
  "/dashboard/ai",
  "/dashboard/giao-dich",
  "/ho-so-dien-tu",
  "/dashboard/bao-cao",
] as const;
export const CRM_PRIMARY_NAV_ITEMS = CRM_NAV_ITEMS.filter(item =>
  CRM_PRIMARY_HREFS.includes(item.href as (typeof CRM_PRIMARY_HREFS)[number])
);

export const CRM_OPERATING_LAYERS = [
  { order: 1, key: "status", label: "Trạng thái sàn", href: "/dashboard" },
  {
    order: 2,
    key: "urgent",
    label: "Việc cần xử lý ngay",
    href: "/dashboard/bao-cao",
  },
  { order: 3, key: "workflow", label: "Vận hành workflow", href: "/dashboard" },
  { order: 4, key: "ai", label: "AI điều hành", href: "/dashboard/ai" },
] as const;

export const getOperatingTaskHref = (taskId: string | number) => {
  const id = String(taskId);
  if (id.startsWith("consultation-")) return "/quan-ly";
  if (id.startsWith("buyer-")) return "/dashboard/khach-hang?filter=new";
  if (id.startsWith("deal-")) return "/dashboard/giao-dich";
  return "/dashboard/bao-cao";
};

export const getOperatingPipelineHref = (label: string) =>
  `/dashboard/giao-dich?stage=${encodeURIComponent(label)}`;

export const CRM_QUICK_ACTIONS = [
  {
    label: "1 · Tạo nguồn hàng",
    description: "Tiếp nhận chủ nhà và BĐS",
    href: "/quan-ly-moi-gioi",
    icon: Home,
  },
  {
    label: "2 · Tạo sản phẩm",
    description: "Ảnh, video, 3D và thông tin bán",
    href: "/quan-ly-moi-gioi",
    icon: Home,
  },
  {
    label: "3 · Thu Lead",
    description: "Marketing và khách hàng",
    href: "/dashboard/marketing",
    icon: Sparkles,
  },
  {
    label: "4 · Matching AI",
    description: "Ghép khách với BĐS",
    href: "/dashboard/ai",
    icon: Bot,
  },
  {
    label: "5 · Dẫn khách",
    description: "Đặt lịch và ghi nhận phản hồi",
    href: "/dashboard/khach-hang",
    icon: CalendarDays,
  },
  {
    label: "6 · Tạo giao dịch",
    description: "Cọc, hồ sơ và hoàn tất",
    href: "/dashboard/giao-dich",
    icon: Handshake,
  },
] as const;

const PIPELINE_TONES: Record<string, string> = {
  "Tiếp nhận": "bg-[#dcefe8]",
  "Kiểm tra": "bg-[#e3eef9]",
  "Ký gửi": "bg-[#fff0c9]",
  "Tìm khách": "bg-[#eee7fb]",
  "Đàm phán": "bg-[#fce4df]",
  "Đặt cọc": "bg-[#d9f0ee]",
  "Công chứng": "bg-[#e8edf7]",
  "Hoàn tất": "bg-[#e4f1df]",
};
const formatMoney = (value: number) =>
  value
    ? `${value.toLocaleString("vi-VN", { maximumFractionDigits: 2 })} tỷ`
    : "0 tỷ";
const formatTime = (value: Date | string) =>
  new Date(value).toLocaleTimeString("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
  });
const formatUpdatedAt = (value?: string) =>
  value
    ? new Date(value).toLocaleString("vi-VN", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : "Chưa có dữ liệu";

type ResponsiveAudit = {
  score: number;
  summary: string;
  priority: "low" | "medium" | "high";
  issues: Array<{
    title: string;
    severity: "info" | "warning" | "critical";
    detail: string;
    fix: string;
  }>;
  actions: Array<{ label: string; target: string; rationale: string }>;
};

export const getResponsiveMetrics = (
  viewportWidth: number,
  documentWidth: number
) => ({
  viewportWidth,
  documentWidth,
  horizontalOverflow: documentWidth > viewportWidth + 2,
  overflowPixels: Math.max(0, documentWidth - viewportWidth),
});

function ResponsiveOptimizer() {
  const [audit, setAudit] = useState<ResponsiveAudit | null>(null);
  const [optimized, setOptimized] = useState(
    () =>
      typeof document !== "undefined" &&
      document.documentElement.dataset.uiOptimization === "compact"
  );
  const optimize = trpc.ai.optimizeResponsive.useMutation({
    onSuccess: setAudit,
  });
  const runAudit = () => {
    const viewportWidth = Math.round(window.innerWidth);
    const viewportHeight = Math.round(window.innerHeight);
    const documentWidth = Math.max(
      document.documentElement.scrollWidth,
      document.body.scrollWidth
    );
    const visibleSections = Array.from(
      document.querySelectorAll("[data-responsive-section]"),
      element => element.getAttribute("data-responsive-section") || ""
    )
      .filter(Boolean)
      .slice(0, 30);
    const metrics = getResponsiveMetrics(viewportWidth, documentWidth);
    optimize.mutate({
      viewportWidth,
      viewportHeight,
      documentWidth,
      horizontalOverflow: metrics.horizontalOverflow,
      route: window.location.pathname,
      visibleSections,
      interactionNotes: metrics.horizontalOverflow
        ? [
            `Phát hiện chiều rộng tài liệu lớn hơn viewport ${metrics.overflowPixels}px.`,
          ]
        : ["Chưa phát hiện tràn ngang ở thời điểm quét."],
    });
  };
  const applyOptimization = () => {
    const next = !optimized;
    document.documentElement.dataset.uiOptimization = next
      ? "compact"
      : "default";
    window.localStorage.setItem(
      "bdsxanh-ui-optimization",
      next ? "compact" : "default"
    );
    setOptimized(next);
  };
  return (
    <section
      data-responsive-section="AI Responsive Optimizer"
      className="mt-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
            AI UI Optimization
          </p>
          <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
            Tự động tối ưu Responsive
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-[#688078]">
            AI đo viewport thật, phát hiện tràn ngang và đề xuất cách gom hàng,
            co nút, giữ vùng bấm dễ thao tác trên mobile.
          </p>
        </div>
        <Sparkles className="h-6 w-6 text-[#b48a36]" />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={runAudit}
          disabled={optimize.isPending}
          className="inline-flex items-center gap-2 rounded-full bg-[#173f36] px-4 py-2.5 text-sm font-bold text-white disabled:cursor-wait disabled:opacity-60"
        >
          <Sparkles className="h-4 w-4" />
          {optimize.isPending ? "AI đang quét…" : "Quét và phân tích giao diện"}
        </button>
        <button
          type="button"
          onClick={applyOptimization}
          className={`rounded-full border px-4 py-2.5 text-sm font-bold ${optimized ? "border-[#2d8069] bg-[#e2f1e8] text-[#1e6a59]" : "border-[#dce7df] bg-white text-[#527068]"}`}
        >
          {optimized
            ? "Đang bật tối ưu Mobile-first"
            : "Áp dụng tối ưu tự động"}
        </button>
      </div>
      {audit ? (
        <div className="mt-4 grid gap-4 lg:grid-cols-[.8fr_1.2fr]">
          <div className="rounded-2xl bg-[#173f36] p-4 text-white">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#e8c96d]">
              Điểm Responsive
            </p>
            <p className="mt-2 text-4xl font-bold">
              {audit.score}
              <span className="text-lg text-white/60">/100</span>
            </p>
            <p className="mt-2 text-sm leading-5 text-white/75">
              {audit.summary}
            </p>
            <span className="mt-4 inline-flex rounded-full bg-white/10 px-3 py-1 text-xs font-bold">
              Mức ưu tiên:{" "}
              {audit.priority === "high"
                ? "Cao"
                : audit.priority === "medium"
                  ? "Trung bình"
                  : "Thấp"}
            </span>
          </div>
          <div className="space-y-2">
            {audit.issues.length ? (
              audit.issues.slice(0, 4).map(issue => (
                <div
                  key={issue.title}
                  className="rounded-xl border border-[#edf1ed] bg-white px-3 py-3"
                >
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-sm font-bold text-[#173b35]">
                      {issue.title}
                    </p>
                    <span
                      className={`text-[10px] font-bold uppercase ${issue.severity === "critical" ? "text-[#c65b4d]" : issue.severity === "warning" ? "text-[#b48a36]" : "text-[#2d8069]"}`}
                    >
                      {issue.severity}
                    </span>
                  </div>
                  <p className="mt-1 text-xs leading-5 text-[#688078]">
                    {issue.detail}
                  </p>
                  <p className="mt-1 text-xs font-semibold text-[#1e6a59]">
                    Gợi ý: {issue.fix}
                  </p>
                </div>
              ))
            ) : (
              <p className="rounded-xl border border-[#dce7df] bg-white p-4 text-sm text-[#527068]">
                AI chưa phát hiện vấn đề ưu tiên.
              </p>
            )}
          </div>
        </div>
      ) : null}
    </section>
  );
}

function AICallComposer() {
  const [customerName, setCustomerName] = useState("");
  const [phone, setPhone] = useState("");
  const [goal, setGoal] = useState(
    "Tư vấn BĐS phù hợp và xác nhận nhu cầu xem nhà"
  );
  const [script, setScript] = useState<{
    greeting: string;
    talkingPoints: string[];
    consentLine: string;
    closing: string;
  } | null>(null);
  const prepareCall = trpc.ai.prepareCall.useMutation({ onSuccess: setScript });
  return (
    <section className="mt-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
            AI chăm sóc khách hàng
          </p>
          <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
            Chuẩn bị cuộc gọi
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-[#688078]">
            AI tạo kịch bản theo nhu cầu. Bạn kiểm tra và xác nhận trước khi bấm
            gọi; hệ thống chưa tự động gọi thay bạn nếu chưa kết nối nhà cung
            cấp viễn thông.
          </p>
        </div>
        <Phone className="h-6 w-6 text-[#2d8069]" />
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <input
          value={customerName}
          onChange={event => setCustomerName(event.target.value)}
          placeholder="Tên khách hàng"
          className="rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm outline-none focus:border-[#2d8069]"
        />
        <input
          value={phone}
          onChange={event => setPhone(event.target.value)}
          placeholder="Số điện thoại"
          inputMode="tel"
          className="rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm outline-none focus:border-[#2d8069]"
        />
        <input
          value={goal}
          onChange={event => setGoal(event.target.value)}
          placeholder="Mục tiêu cuộc gọi"
          className="rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm outline-none focus:border-[#2d8069]"
        />
      </div>
      <button
        type="button"
        disabled={
          prepareCall.isPending || !customerName.trim() || !phone.trim()
        }
        onClick={() => prepareCall.mutate({ customerName, phone, goal })}
        className="mt-3 inline-flex items-center gap-2 rounded-full bg-[#173f36] px-4 py-2.5 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50"
      >
        <Bot className="h-4 w-4" />
        {prepareCall.isPending ? "AI đang soạn…" : "Tạo kịch bản gọi"}
      </button>
      {script ? (
        <div className="mt-4 rounded-2xl border border-[#dce7df] bg-white p-4">
          <p className="text-sm font-bold text-[#173b35]">{script.greeting}</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-[#527068]">
            {script.talkingPoints.map(point => (
              <li key={point}>{point}</li>
            ))}
          </ul>
          <p className="mt-3 text-sm italic text-[#527068]">
            {script.consentLine}
          </p>
          <p className="mt-2 text-sm text-[#527068]">{script.closing}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <a
              href={`tel:${phone.replace(/[^+\\d]/g, "")}`}
              onClick={() => {
                if (
                  !window.confirm(
                    "Bạn đã kiểm tra kịch bản và muốn mở cuộc gọi đến số này?"
                  )
                )
                  return false;
              }}
              className="inline-flex items-center gap-2 rounded-full bg-[#2d8069] px-4 py-2.5 text-sm font-bold text-white"
            >
              <Phone className="h-4 w-4" />
              Xác nhận và gọi
            </a>
            <button
              type="button"
              onClick={() => setScript(null)}
              className="rounded-full border border-[#dce7df] px-4 py-2.5 text-sm font-bold text-[#527068]"
            >
              Sửa thông tin
            </button>
          </div>
        </div>
      ) : null}
    </section>
  );
}

function ManusConnectionPortal() {
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.manusConnection.status.useQuery(undefined, {
    refetchInterval: 15_000,
  });
  const connect = trpc.manusConnection.connect.useMutation({
    onSuccess: () => utils.manusConnection.status.invalidate(),
  });
  const disconnect = trpc.manusConnection.disconnect.useMutation({
    onSuccess: () => utils.manusConnection.status.invalidate(),
  });
  const requestUpdate = trpc.manusConnection.requestUpdate.useMutation({
    onSuccess: () => {
      setTitle("");
      setDescription("");
      utils.manusConnection.status.invalidate();
    },
  });
  const syncRequest = trpc.manusConnection.syncRequest.useMutation({
    onSuccess: () => utils.manusConnection.status.invalidate(),
  });
  const approveRequest = trpc.manusConnection.approveRequest.useMutation({
    onSuccess: () => utils.manusConnection.status.invalidate(),
  });
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const state = data?.state;
  const requests = data?.requests ?? [];
  const connected = state?.status === "connected";
  const syncReady = state?.lastSyncStatus !== "pending";
  return (
    <section
      data-responsive-section="Manus Connection"
      className="mt-5 rounded-[24px] border border-[#cfe1d7] bg-[#f1f8f2] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.05)]"
    >
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
            Cổng quản trị có phê duyệt
          </p>
          <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
            Kết nối Manus
          </h2>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">
            Mọi yêu cầu sửa lỗi hoặc cập nhật đều được lưu trong website, đồng
            bộ và kiểm tra trước. Chỉ khi bạn phê duyệt thì thay đổi mới được
            phép áp dụng.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-bold ${connected ? "bg-[#dcefe5] text-[#1e6a59]" : "bg-white text-[#688078]"}`}
          >
            <span
              className={`h-2 w-2 rounded-full ${connected ? "bg-[#2d8069]" : "bg-[#9ab0a5]"}`}
            />
            {connected ? "Đang kết nối" : "Đã ngắt kết nối"}
          </span>
          {connected ? (
            <button
              type="button"
              disabled={!syncReady || disconnect.isPending}
              onClick={() => disconnect.mutate()}
              className="inline-flex items-center gap-2 rounded-full border border-[#cfe1d7] bg-white px-3 py-2 text-xs font-bold text-[#527068] disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Unplug className="h-4 w-4" />
              Ngắt kết nối
            </button>
          ) : (
            <button
              type="button"
              disabled={connect.isPending}
              onClick={() => connect.mutate()}
              className="inline-flex items-center gap-2 rounded-full bg-[#173f36] px-3 py-2 text-xs font-bold text-white disabled:opacity-50"
            >
              <Link2 className="h-4 w-4" />
              Kết nối lại
            </button>
          )}
          <a
            href="/ai-ho-so-dat-dai-tu-dong"
            className="inline-flex items-center gap-2 rounded-full border border-[#cfe1d7] bg-white px-3 py-2 text-xs font-bold text-[#1e6a59]"
          >
            <ArrowUpRight className="h-4 w-4" />
            Mở phần sản xuất
          </a>
        </div>
      </div>
      <div className="mt-4 grid gap-4 xl:grid-cols-[.9fr_1.1fr]">
        <div className="rounded-2xl border border-[#dce7df] bg-white p-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-[#2d8069]" />
            <p className="font-bold text-[#173b35]">Trạng thái đồng bộ</p>
          </div>
          <p className="mt-3 text-sm text-[#527068]">
            {isLoading
              ? "Đang đọc trạng thái…"
              : state?.lastSyncMessage || "Chưa có phiên đồng bộ nào."}
          </p>
          <div className="mt-3 flex flex-wrap gap-2 text-[11px] font-bold">
            <span
              className={`rounded-full px-2.5 py-1 ${state?.lastSyncStatus === "success" ? "bg-[#dcefe5] text-[#1e6a59]" : state?.lastSyncStatus === "pending" ? "bg-[#fff1ca] text-[#9d751f]" : "bg-[#f2f5f1] text-[#688078]"}`}
            >
              {state?.lastSyncStatus === "success"
                ? "Đồng bộ thành công"
                : state?.lastSyncStatus === "pending"
                  ? "Đang chờ đồng bộ"
                  : state?.lastSyncStatus === "never"
                    ? "Chưa đồng bộ"
                    : state?.lastSyncStatus}
            </span>
            {state?.lastSyncedAt ? (
              <span className="rounded-full bg-[#f2f5f1] px-2.5 py-1 text-[#688078]">
                Lần cuối: {formatUpdatedAt(state.lastSyncedAt.toISOString())}
              </span>
            ) : null}
          </div>
        </div>
        <form
          className="rounded-2xl border border-[#dce7df] bg-white p-4"
          onSubmit={event => {
            event.preventDefault();
            if (!title.trim() || !description.trim()) return;
            requestUpdate.mutate({ title, description, requestType: "update" });
          }}
        >
          <p className="font-bold text-[#173b35]">Gửi yêu cầu sửa/cập nhật</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <input
              value={title}
              onChange={event => setTitle(event.target.value)}
              placeholder="Ví dụ: Cập nhật mục nguồn hàng"
              className="rounded-xl border border-[#dce7df] px-3 py-2.5 text-sm outline-none focus:border-[#2d8069]"
            />
            <button
              type="submit"
              disabled={
                !connected ||
                requestUpdate.isPending ||
                !title.trim() ||
                !description.trim()
              }
              className="rounded-xl bg-[#e8c96d] px-3 py-2.5 text-sm font-bold text-[#173f36] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {requestUpdate.isPending ? "Đang lưu…" : "Lưu yêu cầu"}
            </button>
          </div>
          <textarea
            value={description}
            onChange={event => setDescription(event.target.value)}
            placeholder="Mô tả lỗi hoặc nội dung cần cập nhật. Yêu cầu sẽ được lưu thành bản nháp trước."
            rows={3}
            className="mt-3 w-full rounded-xl border border-[#dce7df] px-3 py-2.5 text-sm outline-none focus:border-[#2d8069]"
          />
        </form>
      </div>
      <div className="mt-4 rounded-2xl border border-[#dce7df] bg-white p-4">
        <div className="flex items-center justify-between gap-3">
          <p className="font-bold text-[#173b35]">
            Lịch sử yêu cầu và phê duyệt
          </p>
          <span className="text-xs text-[#688078]">
            {requests.length} yêu cầu
          </span>
        </div>
        <div className="mt-3 space-y-2">
          {requests.length ? (
            requests.slice(0, 6).map(item => (
              <div
                key={item.id}
                className="flex flex-col gap-3 rounded-xl border border-[#edf1ed] p-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-[#173b35]">
                    {item.title}
                  </p>
                  <p className="mt-1 text-xs text-[#688078]">
                    {item.description}
                  </p>
                  <span className="mt-2 inline-flex rounded-full bg-[#f2f5f1] px-2.5 py-1 text-[11px] font-bold text-[#527068]">
                    {item.status === "approved"
                      ? "Đã phê duyệt"
                      : item.status === "synced"
                        ? "Đã đồng bộ, chờ phê duyệt"
                        : item.status === "requested"
                          ? "Đã lưu bản nháp"
                          : item.status}
                  </span>
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  {item.status === "requested" ? (
                    <button
                      type="button"
                      disabled={syncRequest.isPending}
                      onClick={() =>
                        syncRequest.mutate({
                          id: item.id,
                          syncSummary:
                            "Đã lưu và kiểm tra bản nháp cục bộ; chờ chủ quản trị phê duyệt áp dụng.",
                        })
                      }
                      className="rounded-full border border-[#cfe1d7] px-3 py-2 text-xs font-bold text-[#1e6a59]"
                    >
                      Xác nhận đã đồng bộ
                    </button>
                  ) : null}
                  {item.status === "synced" ? (
                    <button
                      type="button"
                      disabled={approveRequest.isPending}
                      onClick={() => approveRequest.mutate({ id: item.id })}
                      className="inline-flex items-center gap-1 rounded-full bg-[#173f36] px-3 py-2 text-xs font-bold text-white"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Phê duyệt áp dụng
                    </button>
                  ) : null}
                </div>
              </div>
            ))
          ) : (
            <p className="py-3 text-sm text-[#688078]">
              Chưa có yêu cầu nào. Hãy kết nối Manus rồi tạo yêu cầu đầu tiên.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}

type OperatingCenterProps = {
  navigate: (to: string) => void;
  stats: Array<{
    label: string;
    value: string;
    delta: string;
    icon: typeof Home;
    tone: string;
    href: string;
  }>;
  pipeline: Array<{ label: string; value: number }>;
  todayTasks: Array<{
    id: string | number;
    createdAt: Date | string;
    title: string;
    meta: string;
    tone: string;
  }>;
  suggestions: Array<{ title: string; text: string; tag: string }>;
  unreadCount: number;
};

function SourceIntakeWizard({
  onNotice,
}: {
  onNotice: (message: string) => void;
}) {
  const [step, setStep] = useState(0);
  const [sourceType, setSourceType] = useState("Chủ nhà");
  const [propertyType, setPropertyType] = useState("Nhà phố");
  const [form, setForm] = useState<Record<string, string>>({});
  const [photos, setPhotos] = useState<File[]>([]);
  const [videos, setVideos] = useState<File[]>([]);
  const [documents, setDocuments] = useState<File[]>([]);
  const [ocrReady, setOcrReady] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const sourceOptions = ["Chủ nhà", "Môi giới nội bộ", "Cộng tác viên", "Thị trường", "Đối tác", "Dự án", "AI tìm kiếm"];
  const propertyOptions = ["Nhà phố", "Nhà riêng", "Đất ở", "Đất nền", "Căn hộ", "Shophouse", "Biệt thự", "Dự án"];
  const update = (key: string, value: string) => setForm(current => ({ ...current, [key]: value }));
  const selectFiles = (files: FileList | null, setter: (items: File[]) => void) => setter(files ? Array.from(files) : []);
  const steps = ["Chọn nguồn", "Chọn loại BĐS", "Thông tin ban đầu", "Ảnh & video", "Giấy tờ + OCR", "Xác nhận"];
  const canNext = step === 0 ? Boolean(sourceType) : step === 1 ? Boolean(propertyType) : step === 2 ? Boolean(form.title?.trim() && form.address?.trim()) : true;
  const submit = () => {
    setConfirmed(true);
    onNotice(`Đã tạo bản nháp nguồn hàng ${sourceType} · ${propertyType}. Dữ liệu chưa công khai và chờ kiểm duyệt.`);
  };

  return (
    <section data-source-intake-wizard className="mt-4 rounded-[22px] border border-[#d8e7dc] bg-white p-4 shadow-[0_12px_32px_rgba(23,59,53,0.06)] sm:p-5">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#1d8065]">QUY TRÌNH · TẠO NGUỒN</p>
          <h3 className="mt-1 font-serif text-2xl text-[#173b35]">Tạo nguồn hàng mới</h3>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">Chọn nguồn và loại BĐS trước, sau đó nhập hồ sơ đầy đủ. Ảnh, video và giấy tờ được giữ cùng nguồn để các bước CRM cũ tiếp tục xử lý.</p>
        </div>
        <span className="inline-flex items-center gap-1 rounded-full bg-[#e8f1ec] px-3 py-1.5 text-xs font-bold text-[#1d8065]"><ClipboardCheck className="h-3.5 w-3.5" /> Bản nháp · chưa công khai</span>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
        {steps.map((label, index) => (
          <button key={label} type="button" onClick={() => setStep(index)} aria-current={step === index ? "step" : undefined} className={`min-h-[66px] rounded-xl border px-2 py-2 text-left text-xs font-bold ${step === index ? "border-[#b48a36] bg-[#fff4cf] text-[#173f36]" : index < step ? "border-[#b9d7c5] bg-[#f2faf4] text-[#1d8065]" : "border-[#e2ebe4] bg-[#fbfdfb] text-[#688078]"}`}><span className="block text-[10px] uppercase tracking-[0.12em]">Bước {index + 1}</span><span className="mt-1 block leading-4">{label}</span></button>
        ))}
      </div>

      {step === 0 ? (
        <div className="mt-5">
          <p className="text-sm font-bold text-[#173b35]">Nguồn hàng đến từ đâu?</p>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
            {sourceOptions.map(option => <button key={option} type="button" onClick={() => setSourceType(option)} aria-pressed={sourceType === option} className={`min-h-[76px] rounded-xl border px-2 text-sm font-bold ${sourceType === option ? "border-[#1d8065] bg-[#e8f1ec] text-[#173f36]" : "border-[#e2ebe4] bg-white text-[#527068]"}`}>{option}</button>)}
          </div>
        </div>
      ) : null}

      {step === 1 ? (
        <div className="mt-5">
          <p className="text-sm font-bold text-[#173b35]">Chọn loại bất động sản</p>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-8">
            {propertyOptions.map(option => <button key={option} type="button" onClick={() => setPropertyType(option)} aria-pressed={propertyType === option} className={`min-h-[76px] rounded-xl border px-2 text-sm font-bold ${propertyType === option ? "border-[#1d8065] bg-[#e8f1ec] text-[#173f36]" : "border-[#e2ebe4] bg-white text-[#527068]"}`}>{option}</button>)}
          </div>
        </div>
      ) : null}

      {step === 2 ? (
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          {[{ key: "title", label: "Tên/mô tả nguồn hàng", placeholder: "Ví dụ: Nhà phố 2 tầng chính chủ" }, { key: "owner", label: "Tên chủ nhà/đầu mối", placeholder: "Họ tên hoặc tổ chức" }, { key: "phone", label: "Số điện thoại", placeholder: "Số liên hệ", type: "tel" }, { key: "price", label: "Giá chủ nhà đề xuất", placeholder: "Ví dụ: 5.000.000.000", type: "number" }, { key: "area", label: "Diện tích", placeholder: "m²", type: "number" }, { key: "address", label: "Địa chỉ BĐS", placeholder: "Số nhà, đường, phường/xã, tỉnh/thành" }, { key: "legal", label: "Tình trạng pháp lý", placeholder: "Sổ hồng, hồ sơ đang bổ sung..." }, { key: "note", label: "Ghi chú ban đầu", placeholder: "Nhu cầu, thời hạn, điều kiện trao đổi..." }].map(field => <label key={field.key} className="block"><span className="mb-1.5 block text-xs font-bold text-[#49645a]">{field.label}</span><input type={field.type ?? "text"} value={form[field.key] ?? ""} onChange={event => update(field.key, event.target.value)} placeholder={field.placeholder} className="w-full rounded-xl border border-[#d7e4da] bg-[#fbfdfb] px-3 py-2.5 text-sm text-[#173b35] outline-none focus:border-[#1d8065]" /></label>)}
        </div>
      ) : null}

      {step === 3 ? (
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <label className="rounded-2xl border border-dashed border-[#b9d7c5] bg-[#f7fbf8] p-4"><span className="flex items-center gap-2 text-sm font-bold text-[#173f36]"><Camera className="h-4 w-4" /> Tải ảnh hoặc chụp ảnh</span><span className="mt-1 block text-xs leading-5 text-[#688078]">Trên điện thoại, nút này mở camera sau để chụp hiện trạng.</span><input className="mt-3 block w-full text-xs" type="file" accept="image/*" capture="environment" multiple onChange={event => { selectFiles(event.target.files, setPhotos); onNotice(`${event.target.files?.length ?? 0} ảnh đã chọn.`); }} /><span className="mt-2 block text-xs font-semibold text-[#1d8065]">{photos.length ? `${photos.length} ảnh đã chọn` : "Chưa có ảnh"}</span></label>
          <label className="rounded-2xl border border-dashed border-[#b9d7c5] bg-[#f7fbf8] p-4"><span className="flex items-center gap-2 text-sm font-bold text-[#173f36]"><Video className="h-4 w-4" /> Tải hoặc quay video</span><span className="mt-1 block text-xs leading-5 text-[#688078]">Tệp video được giữ trong hồ sơ nguồn, không tự đăng công khai.</span><input className="mt-3 block w-full text-xs" type="file" accept="video/*" capture="environment" multiple onChange={event => { selectFiles(event.target.files, setVideos); onNotice(`${event.target.files?.length ?? 0} video đã chọn.`); }} /><span className="mt-2 block text-xs font-semibold text-[#1d8065]">{videos.length ? `${videos.length} video đã chọn` : "Chưa có video"}</span></label>
        </div>
      ) : null}

      {step === 4 ? (
        <div className="mt-5 grid gap-3 lg:grid-cols-[1fr_.8fr]">
          <label className="rounded-2xl border border-dashed border-[#d9c788] bg-[#fffaf0] p-4"><span className="flex items-center gap-2 text-sm font-bold text-[#7c5f1d]"><FileUp className="h-4 w-4" /> Tải giấy tờ</span><span className="mt-1 block text-xs leading-5 text-[#806b3a]">Nhận PDF, DOCX, JPG hoặc PNG. Hệ thống chỉ lưu đường dẫn tệp và metadata.</span><input className="mt-3 block w-full text-xs" type="file" accept="application/pdf,.doc,.docx,image/*" multiple onChange={event => { selectFiles(event.target.files, setDocuments); setOcrReady(false); onNotice(`${event.target.files?.length ?? 0} giấy tờ đã chọn.`); }} /><span className="mt-2 block text-xs font-semibold text-[#7c5f1d]">{documents.length ? documents.map(file => file.name).join(" · ") : "Chưa có giấy tờ"}</span></label>
          <div className="rounded-2xl border border-[#eadfc5] bg-[#fffdf8] p-4"><p className="flex items-center gap-2 text-sm font-bold text-[#7c5f1d]"><ScanLine className="h-4 w-4" /> OCR và tự điền</p><p className="mt-1 text-xs leading-5 text-[#806b3a]">AI chỉ đề xuất trường dữ liệu từ giấy tờ. Bạn phải kiểm tra, sửa và xác nhận trước khi ghi vào hồ sơ nguồn.</p><button type="button" disabled={!documents.length} onClick={() => { setOcrReady(true); onNotice("Đã tạo vùng kết quả OCR để kiểm tra và xác nhận; chưa ghi đè dữ liệu thủ công."); }} className="mt-3 inline-flex items-center gap-2 rounded-full bg-[#173f36] px-3 py-2 text-xs font-bold text-white disabled:cursor-not-allowed disabled:opacity-40"><Sparkles className="h-3.5 w-3.5" /> Đọc giấy tờ bằng OCR</button>{ocrReady ? <div className="mt-3 rounded-xl bg-[#e8f1ec] p-3 text-xs leading-5 text-[#1e6a59]"><strong>Đề xuất OCR đang chờ xác nhận.</strong><br />Các trường nhận diện cần được môi giới đối chiếu với bản gốc trước khi áp dụng.</div> : null}</div>
        </div>
      ) : null}

      {step === 5 ? (
        <div className="mt-5 rounded-2xl border border-[#d7e4da] bg-[#f7fbf8] p-4"><p className="text-xs font-bold uppercase tracking-[0.14em] text-[#1d8065]">Kiểm tra trước khi lưu</p><div className="mt-3 grid gap-2 text-sm text-[#49645a] sm:grid-cols-2"><p><strong>Nguồn:</strong> {sourceType}</p><p><strong>Loại BĐS:</strong> {propertyType}</p><p><strong>Tên nguồn:</strong> {form.title || "Chưa nhập"}</p><p><strong>Địa chỉ:</strong> {form.address || "Chưa nhập"}</p><p><strong>Ảnh/video:</strong> {photos.length}/{videos.length}</p><p><strong>Giấy tờ:</strong> {documents.length} · {ocrReady ? "OCR chờ xác nhận" : "Chưa chạy OCR"}</p></div><label className="mt-4 flex items-start gap-2 text-xs leading-5 text-[#49645a]"><input type="checkbox" checked={confirmed} onChange={event => setConfirmed(event.target.checked)} className="mt-0.5" /> Tôi đã kiểm tra dữ liệu đầu vào. AI chỉ hỗ trợ đề xuất; tôi chịu trách nhiệm xác nhận trước khi chuyển sang workflow CRM.</label></div>
      ) : null}

      <div className="mt-5 flex flex-col gap-2 border-t border-[#e8eee9] pt-4 sm:flex-row sm:items-center sm:justify-between"><button type="button" onClick={() => setStep(current => Math.max(0, current - 1))} disabled={step === 0} className="rounded-full border border-[#d7e4da] px-4 py-2.5 text-xs font-bold text-[#49645a] disabled:opacity-40">Bước trước</button><div className="flex flex-wrap gap-2"><button type="button" onClick={() => onNotice("Đã lưu bản nháp cục bộ của quy trình Tạo nguồn.")} className="inline-flex items-center gap-2 rounded-full border border-[#cfe1d7] px-4 py-2.5 text-xs font-bold text-[#1e6a59]"><Save className="h-3.5 w-3.5" /> Lưu nháp</button>{step < steps.length - 1 ? <button type="button" disabled={!canNext} onClick={() => setStep(current => Math.min(steps.length - 1, current + 1))} className="rounded-full bg-[#e8c96d] px-4 py-2.5 text-xs font-bold text-[#173f36] disabled:opacity-40">Tiếp tục <ChevronRight className="ml-1 inline h-3.5 w-3.5" /></button> : <button type="button" disabled={!confirmed || !canNext} onClick={submit} className="rounded-full bg-[#173f36] px-4 py-2.5 text-xs font-bold text-white disabled:opacity-40">Tạo bản nháp nguồn hàng</button>}</div></div>
    </section>
  );
}

function OperatingCenter({
  navigate,
  stats,
  pipeline,
  todayTasks,
  suggestions,
  unreadCount,
}: OperatingCenterProps) {
  const [sourceCreationOpen, setSourceCreationOpen] = useState(false);
  const [activeSourceStep, setActiveSourceStep] = useState(0);
  const [sourceDraft, setSourceDraft] = useState<Record<string, string>>({});
  const [sourceFormNotice, setSourceFormNotice] = useState("");
  const controlCards = [
    {
      label: "Nguồn hàng & khảo sát",
      value: stats[0]?.value ?? "0",
      href: "/quan-ly-moi-gioi",
      icon: Home,
    },
    {
      label: "Khách & Lead mới",
      value: stats[1]?.value ?? "0",
      href: "/dashboard/khach-hang?filter=new",
      icon: Users,
    },
    {
      label: "Giao dịch đang chạy",
      value: stats[2]?.value ?? "0",
      href: "/dashboard/giao-dich",
      icon: Handshake,
    },
    {
      label: "Doanh thu dự kiến",
      value: stats[3]?.value ?? "0 tỷ",
      href: "/dashboard/bao-cao",
      icon: WalletCards,
    },
  ];
  const urgentTasks = todayTasks.slice(0, 4);
  const alerts = unreadCount
    ? [
        `${unreadCount} yêu cầu ký gửi mới cần tiếp nhận`,
        "Kiểm tra và phân công người phụ trách ngay",
      ]
    : [
        "Chưa có cảnh báo mới từ dữ liệu CRM",
        "Tiếp tục theo dõi pipeline và lịch trong ngày",
      ];
  const sourceBuckets = [
    {
      label: "Nguồn hàng thị trường",
      detail: "Nguồn tự tìm kiếm và cập nhật",
      href: "/quan-ly-moi-gioi?source=market",
      icon: MapPin,
    },
    {
      label: "Nguồn hàng cộng tác",
      detail: "Hàng từ môi giới/đối tác",
      href: "/quan-ly-moi-gioi?source=partner",
      icon: Users,
    },
    {
      label: "Nguồn hàng tồn kho",
      detail: "BĐS đang lưu và cần xử lý",
      href: "/quan-ly-moi-gioi?source=inventory",
      icon: Home,
    },
    {
      label: "Nguồn hàng đã bán",
      detail: "Theo dõi sau khi chuyển trạng thái",
      href: "/quan-ly-moi-gioi?source=sold",
      icon: CheckCircle2,
    },
    {
      label: "Nguồn hàng đang khảo sát",
      detail: "Chưa hoàn tất kiểm tra đầu vào",
      href: "/quan-ly-moi-gioi?source=surveying",
      icon: ClipboardCheck,
    },
  ];
  const activeStep = SOURCE_CREATION_STEPS[activeSourceStep];
  const activeFields = SOURCE_FORM_FIELDS[activeStep.label] ?? [];
  const updateDraft = (label: string, value: string) =>
    setSourceDraft(current => ({ ...current, [label]: value }));
  const saveSourceDraft = (message: string) => {
    setSourceFormNotice(message);
    window.setTimeout(() => setSourceFormNotice(""), 2600);
  };
  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#f5f7f4] text-[#173b35]">
        <div className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6 lg:px-8">
          <section
            data-operating-layer="status"
            data-responsive-section="Operating Center · Tầng 1"
            className="rounded-[26px] bg-[#173f36] p-5 text-white shadow-[0_16px_42px_rgba(23,63,54,0.18)] sm:p-7"
          >
            <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.22em] text-[#e8c96d]">
                  BẤT ĐỘNG SẢN XANH · TẦNG 1 · TRẠNG THÁI SÀN
                </p>
                <h1 className="mt-2 font-serif text-3xl font-semibold tracking-tight sm:text-5xl">
                  Trung tâm điều hành
                </h1>
                <p className="mt-3 max-w-2xl text-sm leading-6 text-[#c9ddd3]">
                  Bộ não điều hành toàn bộ sàn: nhìn thấy dữ liệu thật trong
                  10–20 giây, biết việc cần xử lý và đi thẳng tới module chịu
                  trách nhiệm.
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate("/dashboard/ai")}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-[#e8c96d] px-4 py-3 text-sm font-bold text-[#173f36]"
              >
                <Bot className="h-4 w-4" /> Hỏi AI điều hành
              </button>
            </div>
            <div className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {controlCards.map(({ label, value, href, icon: Icon }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => navigate(href)}
                  className="flex min-w-0 items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.09] p-4 text-left hover:bg-white/[0.15]"
                >
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-[#c9ddd3]">
                      {label}
                    </span>
                    <span className="mt-2 block truncate text-2xl font-bold text-white">
                      {value}
                    </span>
                  </span>
                  <Icon className="h-6 w-6 shrink-0 text-[#e8c96d]" />
                </button>
              ))}
            </div>
          </section>

          <section
            data-operating-section="source-buckets"
            data-responsive-section="Operating Center · Nhóm Nguồn hàng"
            className="mt-5 rounded-[24px] border border-[#dce7df] bg-white p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
          >
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#1d8065]">
                  NGUỒN HÀNG · PHÂN LOẠI ĐIỀU HÀNH
                </p>
                <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                  Theo dõi toàn bộ nguồn hàng
                </h2>
                <p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">
                  Chọn một nhóm để mở đúng khu vực quản lý. Dữ liệu nguồn hàng
                  được giữ riêng với chuỗi xử lý tạo nguồn.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSourceCreationOpen(true);
                  setActiveSourceStep(0);
                  setSourceFormNotice("");
                }}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-[#173f36] px-4 py-2.5 text-sm font-bold text-white"
              >
                Tạo nguồn hàng <ArrowUpRight className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
              {sourceBuckets.map(({ label, detail, href, icon: Icon }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => navigate(href)}
                  className="flex min-h-[126px] min-w-0 flex-col items-start justify-between rounded-2xl border border-[#e4ebe5] bg-[#fbfdfb] p-4 text-left hover:border-[#a9cdb9] hover:bg-[#f4faf5]"
                >
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#e8f1ec] text-[#1d8065]">
                    <Icon className="h-4 w-4" />
                  </span>
                  <span className="mt-3 min-w-0">
                    <span className="block text-sm font-bold leading-5 text-[#173b35]">
                      {label}
                    </span>
                    <span className="mt-1 block text-xs leading-5 text-[#688078]">
                      {detail}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          </section>

          {sourceCreationOpen ? (
            <div
              data-operating-section="source-creation-workspace"
              className="mt-5 rounded-2xl border border-[#eadfc5] bg-[#fffaf0] p-4 sm:p-5"
            >
              <SourceIntakeWizard onNotice={saveSourceDraft} />
              <div className="mt-6 border-t border-[#eadfc5] pt-5">
                <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                    TẠO NGUỒN HÀNG · 8 BỘ FORM
                  </p>
                  <h3 className="mt-2 font-serif text-xl text-[#173b35]">
                    Chọn bộ form cần thực hiện
                  </h3>
                  <p className="mt-1 text-sm leading-6 text-[#688078]">
                    Mỗi bước mở đúng form nghiệp vụ; môi giới có thể nhập tay,
                    tải ảnh/tệp, dùng AI hỗ trợ rồi kiểm tra và xác nhận.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigate(SOURCE_CREATION_STEPS[0].href)}
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-[#173f36] px-3 py-2 text-xs font-bold text-white"
                >
                  Mở bộ form đầu tiên <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
                </div>
              <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4">
                {SOURCE_CREATION_STEPS.map(
                  ({ label, detail, icon: Icon }, index) => (
                    <button
                      key={label}
                      type="button"
                      onClick={() => {
                        setActiveSourceStep(index);
                        setSourceFormNotice("");
                      }}
                      aria-pressed={activeSourceStep === index}
                      className={`flex min-h-[118px] min-w-0 flex-col items-start rounded-2xl border p-3 text-left ${activeSourceStep === index ? "border-[#b48a36] bg-[#fff4cf]" : "border-[#eadfc5] bg-white"}`}
                    >
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#e8c96d] text-sm font-extrabold text-[#173f36]">
                        {index + 1}
                      </span>
                      <span className="mt-2 flex min-w-0 items-center gap-1 text-sm font-bold text-[#173b35]">
                        {label}
                        <Icon className="h-3.5 w-3.5 shrink-0 text-[#b48a36]" />
                      </span>
                      <span className="mt-1 line-clamp-2 text-xs leading-5 text-[#688078]">
                        {detail}
                      </span>
                    </button>
                  )
                )}
              </div>
              <div className="mt-4 rounded-2xl border border-[#d7e4da] bg-white p-4 sm:p-5">
                <div className="flex flex-col gap-3 border-b border-[#e8eee9] pb-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0">
                    <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#1d8065]">
                      BỘ FORM {activeSourceStep + 1}/7
                    </p>
                    <h4 className="mt-1 text-lg font-bold text-[#173b35]">
                      {activeStep.label}
                    </h4>
                    <p className="mt-1 text-sm text-[#688078]">
                      {activeStep.detail}
                    </p>
                  </div>
                  <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-[#e8f1ec] px-3 py-1.5 text-xs font-bold text-[#1d8065]">
                    <ClipboardCheck className="h-3.5 w-3.5" /> Đang chỉnh sửa
                    thủ công
                  </span>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {activeFields.map(field => (
                    <label
                      key={field.label}
                      className={field.wide ? "sm:col-span-2" : ""}
                    >
                      <span className="mb-1.5 block text-xs font-bold text-[#49645a]">
                        {field.label}
                      </span>
                      {field.wide ? (
                        <textarea
                          value={sourceDraft[field.label] ?? ""}
                          onChange={event =>
                            updateDraft(field.label, event.target.value)
                          }
                          placeholder={field.placeholder}
                          rows={3}
                          className="w-full resize-y rounded-xl border border-[#d7e4da] bg-[#fbfdfb] px-3 py-2.5 text-sm text-[#173b35] outline-none focus:border-[#1d8065]"
                        />
                      ) : (
                        <input
                          value={sourceDraft[field.label] ?? ""}
                          onChange={event =>
                            updateDraft(field.label, event.target.value)
                          }
                          placeholder={field.placeholder}
                          className="w-full rounded-xl border border-[#d7e4da] bg-[#fbfdfb] px-3 py-2.5 text-sm text-[#173b35] outline-none focus:border-[#1d8065]"
                        />
                      )}
                    </label>
                  ))}
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl border border-dashed border-[#c5d9cb] bg-[#f7fbf8] p-3">
                    <div className="flex items-center gap-2 text-sm font-bold text-[#173f36]">
                      <Upload className="h-4 w-4" /> Ảnh và tệp đính kèm
                    </div>
                    <p className="mt-1 text-xs leading-5 text-[#688078]">
                      Tải ảnh chụp, PDF, DOCX hoặc biên bản thực tế để lưu cùng
                      bước này.
                    </p>
                    <input
                      type="file"
                      multiple
                      className="mt-2 block w-full text-xs text-[#49645a]"
                      onChange={event =>
                        saveSourceDraft(
                          `${event.target.files?.length ?? 0} tệp đã được chọn; cần bấm Lưu hồ sơ để ghi nhận.`
                        )
                      }
                    />
                  </div>
                  <div className="rounded-xl border border-dashed border-[#d9c788] bg-[#fffaf0] p-3">
                    <div className="flex items-center gap-2 text-sm font-bold text-[#7c5f1d]">
                      <ScanLine className="h-4 w-4" /> AI hỗ trợ điền
                    </div>
                    <p className="mt-1 text-xs leading-5 text-[#806b3a]">
                      AI chỉ đề xuất dữ liệu từ ảnh/tệp; môi giới phải kiểm tra
                      trước khi áp dụng.
                    </p>
                    <button
                      type="button"
                      onClick={() =>
                        saveSourceDraft(
                          "Đã tạo đề xuất AI; hãy kiểm tra từng trường trước khi xác nhận."
                        )
                      }
                      className="mt-2 inline-flex items-center gap-1 rounded-full border border-[#d9c788] px-3 py-1.5 text-xs font-bold text-[#7c5f1d]"
                    >
                      <Sparkles className="h-3.5 w-3.5" /> Nhận diện/OCR
                    </button>
                  </div>
                </div>
                <div className="mt-4 flex flex-col gap-3 border-t border-[#e8eee9] pt-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        saveSourceDraft("Đã lưu bản nháp cục bộ của bộ form.")
                      }
                      className="inline-flex items-center gap-1 rounded-full border border-[#cfe1d7] px-3 py-2 text-xs font-bold text-[#1e6a59]"
                    >
                      <Save className="h-3.5 w-3.5" /> Lưu nháp
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        saveSourceDraft(
                          "Đã lưu hồ sơ; cần người phụ trách kiểm tra và xác nhận."
                        )
                      }
                      className="inline-flex items-center gap-1 rounded-full bg-[#173f36] px-3 py-2 text-xs font-bold text-white"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" /> Lưu hồ sơ
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        saveSourceDraft(
                          "Đã mở chế độ xem trước, chưa phát hành dữ liệu."
                        )
                      }
                      className="inline-flex items-center gap-1 rounded-full border border-[#cfe1d7] px-3 py-2 text-xs font-bold text-[#1e6a59]"
                    >
                      <FileText className="h-3.5 w-3.5" /> Xem trước
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={activeSourceStep === 0}
                      onClick={() =>
                        setActiveSourceStep(step => Math.max(0, step - 1))
                      }
                      className="rounded-full border border-[#d7e4da] px-3 py-2 text-xs font-bold text-[#49645a]"
                    >
                      Bước trước
                    </button>
                    <button
                      type="button"
                      disabled={
                        activeSourceStep === SOURCE_CREATION_STEPS.length - 1
                      }
                      onClick={() =>
                        setActiveSourceStep(step =>
                          Math.min(SOURCE_CREATION_STEPS.length - 1, step + 1)
                        )
                      }
                      className="rounded-full bg-[#e8c96d] px-3 py-2 text-xs font-bold text-[#173f36]"
                    >
                      Chuyển bước{" "}
                      <ChevronRight className="ml-1 inline h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
                {sourceFormNotice ? (
                  <p
                    role="status"
                    className="mt-3 rounded-xl bg-[#e8f1ec] px-3 py-2 text-xs font-semibold text-[#1e6a59]"
                  >
                    {sourceFormNotice}
                  </p>
                ) : null}
              </div>
              <p className="mt-4 text-xs leading-5 text-[#806b3a]">
                AI chỉ hỗ trợ nhận diện/OCR và đề xuất. Thông tin pháp lý, quy
                hoạch, định giá và điều kiện ký gửi phải được người phụ trách
                đối chiếu, chỉnh sửa và xác nhận.
              </p>
              </div>
            </div>
          ) : null}

          <section
            data-operating-layer="urgent"
            data-responsive-section="Operating Center · Tầng 2"
            className="mt-5 grid min-w-0 gap-5 xl:grid-cols-[minmax(0,1.15fr)_minmax(18rem,0.85fr)]"
          >
            <div className="rounded-[24px] border border-[#eadfc5] bg-[#fffaf0] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                    TẦNG 2 · ƯU TIÊN
                  </p>
                  <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                    Việc cần xử lý ngay
                  </h2>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      navigate(
                        urgentTasks[0]
                          ? getOperatingTaskHref(urgentTasks[0].id)
                          : "/dashboard/bao-cao"
                      )
                    }
                    className="rounded-full bg-[#173f36] px-3 py-2 text-xs font-bold text-white"
                  >
                    Xử lý ngay
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate("/dashboard/bao-cao")}
                    className="rounded-full border border-[#dfcfae] bg-white px-3 py-2 text-xs font-bold text-[#8b6820]"
                  >
                    Xem tất cả
                  </button>
                  <ClipboardCheck className="h-6 w-6 text-[#b48a36]" />
                </div>
              </div>
              <div className="mt-5 space-y-3">
                {urgentTasks.length ? (
                  urgentTasks.map(task => (
                    <button
                      key={task.id}
                      type="button"
                      onClick={() => navigate(getOperatingTaskHref(task.id))}
                      className="flex w-full items-center gap-3 rounded-2xl border border-[#ebdfc7] bg-white p-3 text-left"
                    >
                      <span
                        className={`h-2.5 w-2.5 shrink-0 rounded-full ${task.tone === "rose" ? "bg-[#c65b4d]" : task.tone === "gold" ? "bg-[#d2a237]" : "bg-[#4f9178]"}`}
                      />
                      <span className="min-w-0 flex-1">
                        <b className="block truncate text-sm text-[#173b35]">
                          {task.title}
                        </b>
                        <small className="mt-1 block truncate text-xs text-[#688078]">
                          {task.meta}
                        </small>
                      </span>
                      <span className="text-xs font-bold text-[#b48a36]">
                        {formatTime(task.createdAt)}
                      </span>
                    </button>
                  ))
                ) : (
                  <p className="rounded-2xl bg-white p-4 text-sm text-[#688078]">
                    Chưa có việc ưu tiên từ dữ liệu hiện tại.
                  </p>
                )}
              </div>
            </div>
            <div className="rounded-[24px] border border-[#f0d8d1] bg-[#fff8f6] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b25549]">
                CẢNH BÁO
              </p>
              <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                Không bỏ sót điểm nghẽn
              </h2>
              <div className="mt-5 space-y-3">
                {alerts.map(alert => (
                  <div
                    key={alert}
                    className="flex gap-3 rounded-2xl border border-[#f0d8d1] bg-white p-3 text-sm text-[#6d4a44]"
                  >
                    <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#c65b4d]" />
                    <span>{alert}</span>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() =>
                  navigate(unreadCount ? "/quan-ly" : "/dashboard/bao-cao")
                }
                className="mt-4 text-sm font-bold text-[#b25549]"
              >
                {unreadCount
                  ? "Mở yêu cầu ký gửi →"
                  : "Mở danh sách cảnh báo →"}
              </button>
            </div>
          </section>

          <section
            data-operating-layer="workflow"
            data-responsive-section="Operating Center · Tầng 3"
            className="mt-5 rounded-[24px] border border-[#dce7df] bg-white p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
          >
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#1d8065]">
                  TẦNG 3 · VẬN HÀNH WORKFLOW
                </p>
                <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                  Điều hành theo đúng thứ tự CRM
                </h2>
              </div>
              <span className="text-xs font-semibold text-[#688078]">
                Mỗi thẻ mở đúng module phụ trách
              </span>
            </div>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {CRM_WORKFLOW_CENTERS.map(
                ({ order, label, description, href, icon: Icon }) => (
                  <button
                    key={order}
                    type="button"
                    onClick={() =>
                      label === "Tạo nguồn hàng"
                        ? setSourceCreationOpen(open => !open)
                        : navigate(href)
                    }
                    aria-expanded={
                      label === "Tạo nguồn hàng"
                        ? sourceCreationOpen
                        : undefined
                    }
                    className="flex min-h-[118px] min-w-0 items-start gap-3 rounded-2xl border border-[#e4ebe5] bg-[#fbfdfb] p-4 text-left hover:border-[#a9cdb9] hover:bg-[#f4faf5]"
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#e8c96d] text-sm font-extrabold text-[#173f36]">
                      {order}
                    </span>
                    <span className="min-w-0">
                      <span className="flex items-center gap-1 text-sm font-bold text-[#173b35]">
                        {label}
                        <ChevronRight className="h-3.5 w-3.5 text-[#b48a36]" />
                      </span>
                      <span className="mt-1 block text-xs leading-5 text-[#688078]">
                        {description}
                      </span>
                    </span>
                    <Icon className="ml-auto hidden h-4 w-4 shrink-0 text-[#6e9c88] sm:block" />
                  </button>
                )
              )}
            </div>
          </section>

          <section
            data-operating-layer="ai"
            data-responsive-section="Operating Center · Tầng 4"
            className="mt-5 grid min-w-0 gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(18rem,0.8fr)]"
          >
            <div className="rounded-[24px] bg-[#234f43] p-5 text-white shadow-[0_12px_30px_rgba(23,63,54,0.15)]">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#e8c96d]">
                    TẦNG 4 · AI ĐIỀU HÀNH
                  </p>
                  <h2 className="mt-2 font-serif text-2xl">
                    Gợi ý bước tiếp theo
                  </h2>
                </div>
                <Sparkles className="h-6 w-6 text-[#e8c96d]" />
              </div>
              <div className="mt-5 space-y-3">
                {suggestions.length ? (
                  suggestions.slice(0, 3).map(item => (
                    <button
                      key={item.title}
                      type="button"
                      onClick={() => navigate("/dashboard/ai")}
                      className="w-full rounded-2xl bg-white/10 p-4 text-left hover:bg-white/[0.16]"
                    >
                      <p className="font-bold">{item.title}</p>
                      <p className="mt-1 text-sm leading-5 text-white/75">
                        {item.text}
                      </p>
                      <span className="mt-3 inline-flex rounded-full bg-[#e8c96d] px-3 py-1 text-xs font-bold text-[#173f36]">
                        {item.tag}
                      </span>
                    </button>
                  ))
                ) : (
                  <p className="rounded-2xl bg-white/10 p-4 text-sm text-white/75">
                    Chưa có đề xuất AI từ dữ liệu hiện tại.
                  </p>
                )}
              </div>
              <p className="mt-4 text-xs leading-5 text-white/65">
                AI chỉ là trợ lý điều phối và gợi ý bước tiếp theo. Kết luận
                pháp lý, quy hoạch và hồ sơ chính thức phải được đối chiếu nguồn
                có thẩm quyền và xác nhận bởi người phụ trách.
              </p>
            </div>
            <div className="rounded-[24px] border border-[#dce7df] bg-white p-5">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                BẢNG ĐIỀU KHIỂN NHANH
              </p>
              <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                Pipeline hiện tại
              </h2>
              <div className="mt-5 space-y-2">
                {pipeline.slice(0, 6).map(item => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() =>
                      navigate(getOperatingPipelineHref(item.label))
                    }
                    className="flex w-full items-center justify-between rounded-xl bg-[#f5f8f5] px-3 py-3 text-left"
                  >
                    <span className="text-sm font-semibold text-[#527068]">
                      {item.label}
                    </span>
                    <span className="font-bold text-[#173b35]">
                      {item.value}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </section>
        </div>
      </div>
    </DashboardLayout>
  );
}

export default function CrmDashboard() {
  useCrmInstallManifest();
  const [, navigate] = useLocation();
  const activePath = window.location.pathname;
  const sectionTitle =
    activePath === "/dashboard" || activePath === "/crm"
      ? "Tổng quan công việc"
      : (CRM_NAV_ITEMS.find(item => item.href === activePath)?.label ??
        "Dashboard");
  const { data, isLoading, isError, refetch, dataUpdatedAt } =
    trpc.dashboard.summary.useQuery(undefined, {
      refetchInterval: 30_000,
      staleTime: 15_000,
    });
  const consultationQuery = trpc.consultations.list.useQuery(undefined, {
    refetchInterval: 30_000,
    staleTime: 15_000,
  });
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [readNotificationVersion, setReadNotificationVersion] = useState(0);
  const newNotifications = filterNewConsignmentRequests(
    consultationQuery.data ?? []
  );
  const readNotificationIds = getReadNotificationIds();
  const unreadNotifications = newNotifications.filter(
    item => !readNotificationIds.has(item.id)
  );
  void readNotificationVersion;

  useEffect(() => {
    const handleNotificationsRead = () =>
      setReadNotificationVersion(version => version + 1);
    window.addEventListener(
      "bdsxanh-notifications-read",
      handleNotificationsRead
    );
    return () =>
      window.removeEventListener(
        "bdsxanh-notifications-read",
        handleNotificationsRead
      );
  }, []);

  const markAllNotificationsAsRead = () =>
    markNotificationsAsRead(newNotifications.map(item => item.id));
  const stats = data
    ? [
        {
          label: "BĐS đang bán",
          value: String(data.stats.propertiesForSale),
          delta: "Đồng bộ từ Nguồn hàng",
          icon: Home,
          tone: "green",
        },
        {
          label: "Khách hàng",
          value: String(data.stats.customers),
          delta: `+${data.stats.newCustomersThisMonth} khách mới tháng này`,
          icon: Users,
          tone: "blue",
        },
        {
          label: "Giao dịch đang xử lý",
          value: String(data.stats.activeDeals),
          delta: "Theo trạng thái giao dịch",
          icon: Handshake,
          tone: "gold",
        },
        {
          label: "Doanh thu dự kiến",
          value: formatMoney(data.stats.expectedRevenue),
          delta: `Đã hoàn tất ${formatMoney(data.stats.completedRevenue)}`,
          icon: WalletCards,
          tone: "rose",
        },
      ]
    : [];
  const pipeline = data?.pipeline ?? [];
  const todayTasks = data?.tasks ?? [];
  const suggestions = data?.suggestions ?? [];

  if (activePath === "/dashboard") {
    return (
      <OperatingCenter
        navigate={navigate}
        stats={stats.map(item => ({ ...item, href: "/dashboard" }))}
        pipeline={pipeline}
        todayTasks={todayTasks}
        suggestions={suggestions}
        unreadCount={unreadNotifications.length}
      />
    );
  }

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#f5f7f4] text-[#173b35]">
        <div className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6 lg:px-8">
          <header className="mb-6 flex flex-col gap-4 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] px-5 py-5 shadow-[0_14px_40px_rgba(23,59,53,0.06)] sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="mb-1 text-xs font-bold uppercase tracking-[0.22em] text-[#b48a36]">
                BẤT ĐỘNG SẢN XANH · CRM
              </p>
              <h1 className="font-serif text-3xl font-semibold tracking-tight text-[#123c35] sm:text-4xl">
                {sectionTitle}
              </h1>
              <p className="mt-2 text-sm text-[#688078]">
                Thứ Hai, 17 tháng 8, 2026 · Chào buổi sáng, đội ngũ môi giới.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3">
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setNotificationsOpen(open => !open)}
                  className="relative rounded-full border border-[#dbe5df] bg-white p-3 text-[#173b35]"
                  aria-expanded={notificationsOpen}
                  aria-label={
                    unreadNotifications.length
                      ? `${unreadNotifications.length} thông báo chưa xem`
                      : "Thông báo đã xem hết"
                  }
                >
                  <Bell className="h-5 w-5" />
                  {unreadNotifications.length ? (
                    <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#c65b4d] px-1 text-[10px] font-bold text-white">
                      {unreadNotifications.length > 99
                        ? "99+"
                        : unreadNotifications.length}
                    </span>
                  ) : null}
                </button>
                {notificationsOpen ? (
                  <div className="absolute right-0 top-14 z-30 w-[min(22rem,calc(100vw-2rem))] rounded-2xl border border-[#dce7df] bg-[#fffdf8] p-3 text-left shadow-[0_18px_50px_rgba(23,59,53,0.18)]">
                    <div className="flex items-center justify-between gap-3 border-b border-[#edf1ed] px-2 pb-3">
                      <div>
                        <p className="font-bold text-[#173b35]">Thông báo</p>
                        <p className="mt-1 text-xs text-[#688078]">
                          {unreadNotifications.length
                            ? `${unreadNotifications.length} yêu cầu chưa xem`
                            : "Bạn đã xem hết thông báo"}
                        </p>
                      </div>
                      {newNotifications.length ? (
                        <button
                          type="button"
                          onClick={() => {
                            markAllNotificationsAsRead();
                            setNotificationsOpen(false);
                          }}
                          className="text-xs font-bold text-[#1d8065]"
                        >
                          Đã xem xong
                        </button>
                      ) : null}
                    </div>
                    <div className="max-h-72 overflow-y-auto py-1">
                      {newNotifications.length ? (
                        newNotifications.map(item => (
                          <button
                            type="button"
                            key={item.id}
                            onClick={() => {
                              markNotificationsAsRead([item.id]);
                              navigate("/quan-ly");
                              setNotificationsOpen(false);
                            }}
                            className="flex w-full items-start gap-3 rounded-xl px-2 py-3 text-left hover:bg-[#edf5ef]"
                          >
                            <span
                              className={`mt-1 h-2 w-2 shrink-0 rounded-full ${readNotificationIds.has(item.id) ? "bg-[#b8c8bf]" : "bg-[#c65b4d]"}`}
                            />
                            <span className="min-w-0">
                              <b className="block truncate text-sm text-[#173b35]">
                                {item.name}
                              </b>
                              <span className="mt-1 block truncate text-xs text-[#688078]">
                                {item.phone} · Yêu cầu ký gửi mới
                              </span>
                            </span>
                          </button>
                        ))
                      ) : (
                        <p className="px-2 py-5 text-center text-sm text-[#688078]">
                          Chưa có thông báo mới.
                        </p>
                      )}
                    </div>
                  </div>
                ) : null}
              </div>
              <PwaInstallButton
                appName="CRM"
                className="bg-[#e7f1e9] text-[#1e6a59]"
              />
              <button
                onClick={() => navigate("/dashboard/ai")}
                className="flex items-center gap-2 rounded-full bg-[#e7f1e9] px-4 py-3 text-sm font-bold text-[#1e6a59]"
              >
                <Bot className="h-4 w-4" /> Hỏi AI
              </button>
            </div>
          </header>
          <nav
            aria-label="Điều hướng CRM"
            className="mb-6 rounded-[22px] border border-[#cfe1d7] bg-[#173f36] p-2 shadow-[0_12px_30px_rgba(23,63,54,0.14)]"
          >
            <div className="mb-1 flex items-center justify-between gap-3 px-2 py-1.5">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#e8c96d]">
                Trung tâm CRM
              </p>
              <span className="hidden text-xs text-white/60 sm:block">
                9 phân hệ · Chọn mục để làm việc
              </span>
            </div>
            <div className="grid grid-cols-1 gap-1 pb-1 sm:grid-cols-2 lg:flex lg:flex-wrap">
              {CRM_NAV_ITEMS.map(({ label, href, icon: Icon }) => {
                const isActive = activePath === href;
                return (
                  <button
                    key={href}
                    type="button"
                    onClick={() => navigate(href)}
                    aria-current={isActive ? "page" : undefined}
                    className={`flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors lg:flex-1 ${isActive ? "bg-[#e8c96d] text-[#173f36] shadow-sm" : "text-white/80 hover:bg-white/10 hover:text-white"}`}
                  >
                    <Icon className="h-4 w-4" />
                    {label}
                  </button>
                );
              })}
            </div>
          </nav>
          <section
            data-responsive-section="CRM Workflow"
            className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#173b35] p-5 text-white shadow-[0_14px_32px_rgba(23,59,53,0.12)]"
          >
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#e5c77b]">
                  Quy trình CRM chuẩn
                </p>
                <h2 className="mt-2 font-serif text-2xl">
                  Từ nguồn hàng đến giao dịch hoàn tất
                </h2>
                <p className="mt-1 max-w-3xl text-sm leading-6 text-[#c9ddd3]">
                  Mỗi trung tâm có một vai trò rõ ràng; dữ liệu được chuyển tiếp
                  theo thứ tự, không phải tìm lại ở nhiều menu.
                </p>
              </div>
              <span className="text-xs font-semibold text-[#e5c77b]">
                12 trung tâm liên kết
              </span>
            </div>
            <div className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-4">
              {CRM_WORKFLOW_CENTERS.map(
                ({ order, label, description, href, icon: Icon }) => (
                  <button
                    key={order}
                    type="button"
                    onClick={() => navigate(href)}
                    className="group flex min-h-[104px] items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.08] p-3 text-left transition-colors hover:bg-white/[0.15]"
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#e5c77b] text-sm font-extrabold text-[#173b35]">
                      {order}
                    </span>
                    <span className="min-w-0">
                      <span className="flex items-center gap-1 text-sm font-bold text-white">
                        {label}
                        <ChevronRight className="h-3.5 w-3.5 text-[#e5c77b]" />
                      </span>
                      <span className="mt-1 block text-xs leading-5 text-[#c9ddd3]">
                        {description}
                      </span>
                    </span>
                  </button>
                )
              )}
            </div>
          </section>
          <section
            data-responsive-section="CRM Quick Actions"
            className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
          >
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                  Lối tắt công việc
                </p>
                <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                  Bắt đầu nhanh
                </h2>
                <p className="mt-1 text-sm text-[#688078]">
                  Các thao tác thường dùng được gom vào một hàng để môi giới xử
                  lý nhanh trên điện thoại.
                </p>
              </div>
              <span className="text-xs font-semibold text-[#527068]">
                CRM mobile-first
              </span>
            </div>
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
              {CRM_QUICK_ACTIONS.map(
                ({ label, description, href, icon: Icon }) => (
                  <button
                    key={href + label}
                    type="button"
                    onClick={() => navigate(href)}
                    className="group flex min-w-0 flex-col rounded-2xl border border-[#e4ebe5] bg-white p-4 text-left transition-colors hover:border-[#a9cdb9] hover:bg-[#f4faf5]"
                  >
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e2f1e8] text-[#25725e]">
                      <Icon className="h-5 w-5" />
                    </span>
                    <span className="mt-3 block text-sm font-bold text-[#173b35]">
                      {label}
                    </span>
                    <span className="mt-1 block text-xs leading-5 text-[#688078]">
                      {description}
                    </span>
                    <span className="mt-3 block text-xs font-bold text-[#1e6a59]">
                      Mở ngay{" "}
                      <ArrowUpRight className="ml-1 inline h-3.5 w-3.5" />
                    </span>
                  </button>
                )
              )}
            </div>
          </section>
          <section
            data-responsive-section="Trợ lý AI"
            className="mb-5 rounded-[24px] border border-[#cfe1d7] bg-[#eef7f0] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
          >
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                  Khu làm việc AI
                </p>
                <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                  Trợ lý AI
                </h2>
                <p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">
                  Một nơi tập trung để định giá, khảo sát khu vực, tìm nguồn
                  hàng lân cận và đối chiếu quy hoạch. Các công cụ chi tiết
                  không còn tách thành nhiều mục lặp trong menu CRM.
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate("/dashboard/ai")}
                className="inline-flex items-center gap-2 self-start rounded-full bg-[#e8c96d] px-4 py-2.5 text-sm font-bold text-[#173f36]"
              >
                Đang ở Trợ lý AI <Bot className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-4 grid min-w-0 gap-4 xl:grid-cols-2 [&>section]:mt-0 [&>section]:h-full">
              <CrmPlanningWorkbench />
              <CrmLocationSurvey />
              <CrmNearbyProperties />
              <CrmPlanningReview />
            </div>
          </section>
          <section
            data-responsive-section="AI Lead Router"
            className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
          >
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                  Bộ điều phối khách hàng AI
                </p>
                <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                  Lead từ AI tư vấn
                </h2>
                <p className="mt-1 max-w-3xl text-sm text-[#688078]">
                  AI đã thu thập nhu cầu, tìm nguồn hàng và đưa khách vào hàng
                  chờ theo khu vực. Quản trị viên có thể tiếp nhận hoặc chuyển
                  tiếp cho môi giới phụ trách.
                </p>
              </div>
              <button
                type="button"
                onClick={() => navigate("/dashboard/khach-hang")}
                className="inline-flex items-center gap-2 self-start rounded-full bg-[#173f36] px-4 py-2.5 text-sm font-bold text-white"
              >
                Mở CRM <ArrowUpRight className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-5 grid min-w-0 gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {(consultationQuery.data ?? [])
                .filter(item => item.aiStatus === "analyzed")
                .slice(0, 6)
                .map(item => (
                  <article
                    key={item.id}
                    className="rounded-2xl border border-[#dce7df] bg-white p-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-bold text-[#173b35]">
                          {item.name}
                        </p>
                        <p className="mt-1 truncate text-xs text-[#688078]">
                          {item.phone} ·{" "}
                          {item.aiArea || "Chưa xác định khu vực"}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold ${item.aiPriority === "high" ? "bg-[#fbe6df] text-[#b25549]" : item.aiPriority === "potential" ? "bg-[#fff1ca] text-[#9d751f]" : "bg-[#e2f1e8] text-[#25725e]"}`}
                      >
                        {item.aiPriority === "high"
                          ? "Nóng"
                          : item.aiPriority === "potential"
                            ? "Ấm"
                            : "Tham khảo"}
                      </span>
                    </div>
                    <p className="mt-3 line-clamp-2 text-sm leading-5 text-[#527068]">
                      {item.aiSummary || item.interest}
                    </p>
                    <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] font-semibold text-[#688078]">
                      <span className="rounded-full bg-[#e7f1e9] px-2.5 py-1 text-[#1e6a59]">
                        Điểm {item.aiScore ?? "—"}/100
                      </span>
                      <span className="rounded-full bg-[#f2f5f1] px-2.5 py-1">
                        {item.routingStage === "area_queue"
                          ? "Hàng chờ khu vực"
                          : item.routingStage === "backup_queue"
                            ? "Môi giới dự phòng"
                            : "Hàng chờ quản trị"}
                      </span>
                    </div>
                  </article>
                ))}
              {(consultationQuery.data ?? []).filter(
                item => item.aiStatus === "analyzed"
              ).length === 0 ? (
                <div className="rounded-2xl border border-dashed border-[#cfe1d7] bg-white p-6 text-sm text-[#688078] lg:col-span-3">
                  Chưa có lead AI đã phân tích. Khi khách hoàn tất trò chuyện và
                  để lại số điện thoại, hồ sơ sẽ tự xuất hiện tại đây.
                </div>
              ) : null}
            </div>
          </section>
          \n\n <ManusConnectionPortal />
          <ResponsiveOptimizer />
          <AICallComposer />
          {activePath !== "/dashboard" ? (
            <section className="rounded-[24px] border border-[#dce7df] bg-white p-8 shadow-[0_12px_36px_rgba(23,59,53,0.05)]">
              <p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                Phân hệ CRM
              </p>
              <h2 className="mt-3 font-serif text-3xl text-[#173b35]">
                {sectionTitle}
              </h2>
              <p className="mt-3 max-w-2xl text-[#688078]">
                Khu vực này đã được gắn vào điều hướng CRM. Bạn có thể tiếp tục
                mở rộng bảng dữ liệu, bộ lọc và nghiệp vụ chuyên sâu tại đây.
              </p>
            </section>
          ) : isLoading ? (
            <section className="rounded-[24px] border border-[#dce7df] bg-white p-8 text-center">
              <RefreshCw className="mx-auto h-7 w-7 animate-spin text-[#2d8069]" />
              <p className="mt-3 font-semibold text-[#527068]">
                Đang tải dữ liệu CRM…
              </p>
            </section>
          ) : isError || !data ? (
            <section className="rounded-[24px] border border-[#f1d5cf] bg-[#fff8f5] p-8 text-center">
              <p className="font-semibold text-[#9d4b40]">
                Chưa thể tải dữ liệu Dashboard.
              </p>
              <button
                onClick={() => refetch()}
                className="mt-4 rounded-full bg-[#c65b4d] px-4 py-2 text-sm font-bold text-white"
              >
                Thử lại
              </button>
            </section>
          ) : (
            <>
              <div className="grid min-w-0 grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                {stats.map(({ label, value, delta, icon: Icon, tone }) => (
                  <div
                    key={label}
                    className="rounded-[20px] border border-[#dce7df] bg-white p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"
                  >
                    <div className="flex items-start justify-between">
                      <p className="text-sm font-semibold text-[#688078]">
                        {label}
                      </p>
                      <span
                        className={`rounded-2xl p-3 ${tone === "green" ? "bg-[#e2f1e8] text-[#25725e]" : tone === "blue" ? "bg-[#e5eef9] text-[#52729c]" : tone === "gold" ? "bg-[#fff1ca] text-[#a8771d]" : "bg-[#fbe6df] text-[#b25549]"}`}
                      >
                        <Icon className="h-5 w-5" />
                      </span>
                    </div>
                    <p className="mt-4 text-3xl font-bold tracking-tight text-[#173b35]">
                      {value}
                    </p>
                    <p className="mt-2 text-xs font-semibold text-[#4f9178]">
                      {delta}
                    </p>
                  </div>
                ))}
              </div>

              <div className="mt-5 grid min-w-0 gap-5 xl:grid-cols-[minmax(0,1.35fr)_minmax(18rem,0.65fr)]">
                <section className="rounded-[24px] border border-[#dce7df] bg-white p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                        Pipeline giao dịch
                      </p>
                      <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                        Tiến độ nguồn hàng & giao dịch
                      </h2>
                    </div>
                    <button
                      className="flex items-center gap-1 text-sm font-bold text-[#c65b4d]"
                      onClick={() => navigate("/dashboard/giao-dich")}
                    >
                      Xem chi tiết <ArrowUpRight className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                    {pipeline.map(item => (
                      <button
                        key={item.label}
                        onClick={() => navigate("/quy-trinh-moi-gioi")}
                        className={`flex min-w-0 min-h-[7rem] flex-col justify-between rounded-2xl ${PIPELINE_TONES[item.label] || "bg-[#e8edf7]"} p-4 text-left transition-transform hover:-translate-y-0.5`}
                      >
                        <p className="text-xs font-semibold text-[#5e706a]">
                          {item.label}
                        </p>
                        <p className="mt-2 text-2xl font-bold text-[#173b35]">
                          {item.value}
                        </p>
                        <span className="mt-2 block text-[11px] text-[#688078]">
                          hồ sơ
                        </span>
                      </button>
                    ))}
                  </div>
                </section>
                <section className="rounded-[24px] bg-[#173f36] p-5 text-white shadow-[0_12px_30px_rgba(23,63,54,0.18)]">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#e8c96d]">
                        AI Assistant
                      </p>
                      <h2 className="mt-2 font-serif text-2xl">
                        Gợi ý hôm nay
                      </h2>
                    </div>
                    <Sparkles className="h-6 w-6 text-[#e8c96d]" />
                  </div>
                  <div className="mt-5 space-y-3">
                    {suggestions.map(item => (
                      <button
                        key={item.title}
                        onClick={() => navigate("/dashboard/ai")}
                        className="w-full rounded-2xl bg-white/10 p-4 text-left"
                      >
                        <p className="font-bold">{item.title}</p>
                        <p className="mt-1 text-sm leading-5 text-white/75">
                          {item.text}
                        </p>
                        <span className="mt-3 inline-flex rounded-full bg-[#e8c96d] px-3 py-1 text-xs font-bold text-[#173f36]">
                          {item.tag}
                        </span>
                      </button>
                    ))}
                  </div>
                </section>
              </div>

              <div className="mt-5 grid min-w-0 gap-5 lg:grid-cols-2">
                <section className="rounded-[24px] border border-[#dce7df] bg-white p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                        Công việc hôm nay
                      </p>
                      <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                        Lịch cần xử lý
                      </h2>
                    </div>
                    <CalendarDays className="h-6 w-6 text-[#6e9c88]" />
                  </div>
                  <div className="mt-5 space-y-3">
                    {todayTasks.map(item => (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 rounded-2xl border border-[#edf1ed] p-3"
                      >
                        <span
                          className={`w-14 shrink-0 rounded-xl ${item.tone === "rose" ? "bg-[#fbe6df]" : item.tone === "gold" ? "bg-[#fff1cc]" : "bg-[#e2f0e8]"} px-2 py-2 text-center text-xs font-bold text-[#173b35]`}
                        >
                          {formatTime(item.createdAt)}
                        </span>
                        <div className="min-w-0">
                          <p className="truncate text-sm font-bold text-[#173b35]">
                            {item.title}
                          </p>
                          <p className="mt-1 text-xs text-[#688078]">
                            {item.meta}
                          </p>
                        </div>
                        <ChevronRight className="ml-auto h-4 w-4 shrink-0 text-[#9ab0a5]" />
                      </div>
                    ))}
                  </div>
                  <button
                    onClick={() => navigate("/dashboard/bao-cao")}
                    className="mt-4 text-sm font-bold text-[#1d8065]"
                  >
                    Xem toàn bộ công việc →
                  </button>
                </section>
                <section className="rounded-[24px] border border-[#dce7df] bg-white p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">
                        Khách tiềm năng
                      </p>
                      <h2 className="mt-2 font-serif text-2xl text-[#173b35]">
                        Cần chăm sóc tiếp
                      </h2>
                    </div>
                    <Users className="h-6 w-6 text-[#6e9c88]" />
                  </div>
                  <div className="mt-5 divide-y divide-[#edf1ed]">
                    {suggestions.length ? (
                      suggestions.map(item => (
                        <button
                          key={item.title}
                          onClick={() => navigate("/dashboard/khach-hang")}
                          className="flex w-full items-center gap-3 py-3 text-left"
                        >
                          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#e3f0e8] text-sm font-bold text-[#28755e]">
                            {item.title
                              .split(" ")
                              .map(x => x[0])
                              .slice(-2)
                              .join("")}
                          </span>
                          <span className="min-w-0 flex-1">
                            <b className="block text-sm text-[#173b35]">
                              {item.title}
                            </b>
                            <small className="block truncate text-xs text-[#688078]">
                              {item.text}
                            </small>
                          </span>
                          <span className="rounded-full bg-[#fff1ca] px-2.5 py-1 text-xs font-bold text-[#9d751f]">
                            {item.tag}
                          </span>
                        </button>
                      ))
                    ) : (
                      <p className="py-4 text-sm text-[#688078]">
                        Chưa có khách tiềm năng cần chăm sóc.
                      </p>
                    )}
                  </div>
                </section>
              </div>
            </>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
