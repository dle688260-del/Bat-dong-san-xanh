# Nguồn tham chiếu thủ tục đất đai

## Cổng Dịch vụ công — thủ tục mã 2.000889
URL: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889

Nội dung đã đối chiếu: thủ tục đăng ký biến động quyền sử dụng đất và tài sản gắn liền với đất trong các trường hợp chuyển đổi, chuyển nhượng, cho thuê, cho thuê lại, thừa kế, tặng cho, góp vốn và trường hợp liên quan. Trang nêu nơi tiếp nhận có thể là Văn phòng đăng ký đất đai/Chi nhánh hoặc nơi do UBND cấp tỉnh quy định; hộ gia đình, cá nhân có thể nộp tại UBND cấp xã nếu có nhu cầu. Trang cũng mô tả việc kiểm tra hồ sơ, gửi thông tin địa chính sang cơ quan thuế khi có nghĩa vụ, chỉnh lý/cấp Giấy chứng nhận và trả kết quả.

Trang hiển thị thời hạn tham chiếu không quá 10 ngày kể từ khi nhận đủ hồ sơ hợp lệ đối với chuyển nhượng; không tính ngày nghỉ, thời gian thực hiện nghĩa vụ tài chính và các khoảng thời gian loại trừ theo mô tả thủ tục. Thành phần hồ sơ được hiển thị gồm Mẫu số 09/ĐK, hợp đồng/văn bản chuyển quyền, bản gốc Giấy chứng nhận và tài liệu bổ sung theo trường hợp. Liên kết file Mẫu 09/ĐK được trang cung cấp tại: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe4648992ad74c2

## Nghị định 101/2024/NĐ-CP
URL: https://vanban.chinhphu.vn/?pageid=27160&docid=210791

Thông tin metadata đã đối chiếu: Nghị định số 101/2024/NĐ-CP, ngày ban hành 29-07-2024, có hiệu lực 01-08-2024, do Chính phủ ban hành; trích yếu quy định về điều tra cơ bản đất đai, đăng ký/cấp Giấy chứng nhận và Hệ thống thông tin đất đai. Không dùng metadata này để kết luận một hồ sơ cụ thể; builder vẫn yêu cầu rà soát nguồn địa phương và cơ quan tiếp nhận.

## Giới hạn provenance

File DOCX Mẫu 09/ĐK trên liên kết Cổng DVC trả lỗi 503 khi thử tải tự động trong sandbox tại thời điểm kiểm tra, nên chưa được đưa vào allowlist `verified-binary`. Builder chỉ hiển thị nguồn tham chiếu và nhãn `Confirmed Draft`/`metadata-only` cho file AI dựng; không gắn nhãn `Official` nếu binary gốc chưa được tải, kiểm tra checksum, lưu trữ và điền thành công.
