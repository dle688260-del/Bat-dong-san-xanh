# Căn cứ nghiên cứu ban đầu cho hồ sơ chuyển nhượng

Ngày kiểm tra: 2026-08-19.

## Nguồn chính thức đã đối chiếu

1. Cổng Dịch vụ công Quốc gia, thủ tục đăng ký biến động quyền sử dụng đất và tài sản gắn liền với đất trong các trường hợp chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889. Nội dung cho biết hồ sơ có Mẫu số 09/ĐK, hợp đồng/văn bản chuyển quyền, bản gốc Giấy chứng nhận và các giấy tờ bổ sung tùy trường hợp; thời hạn chuyển nhượng được mô tả không quá 10 ngày kể từ khi nhận đủ hồ sơ hợp lệ, nhưng thời hạn cụ thể cần đối chiếu địa phương.

2. Cổng thông tin điện tử Chính phủ, Nghị định 151/2025/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=213927. Trang xác nhận số hiệu 151/2025/NĐ-CP, ngày ban hành 12-06-2025, ngày hiệu lực 01-07-2025 và có tệp PDF đính kèm chính thức. Nguồn này được lưu như một căn cứ có thể truy xuất; hệ thống không suy diễn nội dung điều khoản ngoài dữ liệu đã xác minh.

## Quy tắc an toàn khi triển khai

Hệ thống phải phân biệt “nguồn đã xác minh” với “metadata cần quản trị viên rà soát”. Không được coi tên Mẫu 09/ĐK hoặc một URL là tệp biểu mẫu Official nếu chưa tải được binary và kiểm tra chữ ký/checksum. Hồ sơ tạo tự động phải được gắn trạng thái bản nháp cần rà soát khi thiếu tệp mẫu đã xác minh, thiếu dữ liệu bắt buộc, hoặc chưa xác định quy định địa phương.

## Phạm vi bản đầu tiên

Ưu tiên thủ tục chuyển nhượng quyền sử dụng đất tại địa phương được người dùng chọn. Bản đầu tiên gồm chọn địa phương, xác nhận thủ tục AI đề xuất, nhập bên chuyển/bên nhận, thông tin thửa đất, tải giấy tờ, checklist, traceability và tạo bộ tài liệu nháp DOCX/PDF thật. Việc nộp hồ sơ hoặc khẳng định hồ sơ chắc chắn hợp lệ không thuộc phạm vi tự động hóa.

## Bổ sung nguồn chính thức cho pipeline lọc biểu mẫu

Ngày kiểm tra: 2026-08-19.

Cổng Dịch vụ công Quốc gia về thủ tục đăng ký biến động quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất do chuyển đổi, chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn và trường hợp liên quan: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889. Trang thể hiện trình tự trực tiếp/điện tử, cơ quan tiếp nhận, thời hạn tham chiếu và thành phần hồ sơ. Thành phần được trích xuất có Đơn đăng ký biến động theo Mẫu 09/ĐK, hợp đồng/văn bản giao dịch, bản gốc Giấy chứng nhận và các giấy tờ điều kiện tùy trường hợp. Trang cũng cung cấp liên kết tải Mẫu 09/ĐK từ csdl.dichvucong.gov.vn.

Cổng thông tin điện tử Chính phủ về Luật số 31/2024/QH15: https://chinhphu.vn/?pageid=27160&docid=211189&classid=1&typegroupid=3. Metadata xác nhận số hiệu 31/2024/QH15, ngày ban hành 18-01-2024, ngày hiệu lực 01-01-2025 và các tệp PDF đính kèm từ datafiles.chinhphu.vn.

Cổng thông tin văn bản Chính phủ về Nghị định 101/2024/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=210791. Metadata xác nhận Nghị định 101/2024/NĐ-CP, ngày ban hành 29-07-2024, ngày hiệu lực 01-08-2024 và tệp PDF chính thức https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf.

Quy tắc thiết kế: AI có thể truy xuất, trích xuất, đối chiếu và đề xuất biểu mẫu từ các nguồn này; nhưng chỉ được đưa vào bộ hồ sơ “mẫu gốc đã xác minh” khi tải được file, kiểm tra chữ ký/MIME/checksum, lưu nguồn, phiên bản, địa phương áp dụng và trạng thái hiệu lực. Nếu liên kết tải mẫu trống hoặc không truy cập được, giao diện phải báo CHƯA XÁC MINH thay vì tự gọi bản dựng là mẫu chính thức.

## Kiểm tra nguồn MONRE và PDF người dùng gửi — 2026-08-19

- URL `http://www.monre.gov.vn/` không mở được trong môi trường kiểm tra do lỗi chứng thư `ERR_CERT_COMMON_NAME_INVALID`; thử `https://www.monre.gov.vn/` nhưng không trích xuất được nội dung.
- PDF `/home/ubuntu/upload/Nghịđịnh-101-2024-NĐ-CP(1).pdf` có 137 trang, không mã hóa, nhưng không có lớp text để trích xuất; `pdftotext` trả về rỗng. Metadata cho thấy tiêu đề `Logo LVN_chen footer_2021`, tác giả `Đỗ Văn Chính`, tạo năm 2021 và sửa năm 2024. Đây là dấu hiệu cần xác minh nguồn/bản phát hành trước khi coi là bản chính thức của Nghị định 101/2024/NĐ-CP.
- Kết luận kỹ thuật: AI không thể tự lọc điều khoản/mẫu từ PDF hiện tại bằng text extraction; cần OCR hoặc bản PDF có lớp text, sau đó đối chiếu với nguồn chính thức và lưu trạng thái `CHƯA XÁC MINH` cho tới khi xác nhận được URL, cơ quan, số hiệu, ngày ban hành và phiên bản.

## Đối chiếu nguồn Chính phủ chính thức — 2026-08-19

Nguồn chính thức: https://vanban.chinhphu.vn/?pageid=27160&docid=210791. Trang xác nhận Nghị định số 101/2024/NĐ-CP, ngày ban hành 29-07-2024, có hiệu lực 01-08-2024, cơ quan ban hành Chính phủ, người ký Trần Hồng Hà, trích yếu về điều tra cơ bản đất đai; đăng ký, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất và Hệ thống thông tin đất đai.

Tệp PDF chính thức: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf. Trang PDF trả về thông tin chữ ký điện tử của Cổng Thông tin điện tử Chính phủ, Văn phòng Chính phủ, thời gian ký 31-07-2024 15:07:16 +07:00. Đây là nguồn ưu tiên hơn tệp người dùng gửi khi tạo bản ghi văn bản pháp lý.

Tệp người dùng gửi `/home/ubuntu/upload/Nghịđịnh-101-2024-NĐ-CP(1).pdf` có 137 trang nhưng không có lớp văn bản để `pdftotext` đọc; metadata mang dấu hiệu bản sao/biên tập (tiêu đề `Logo LVN_chen footer_2021`, tác giả `Đỗ Văn Chính`, tạo 2021). Không được tự đánh dấu tệp này là bản gốc chính thức chỉ dựa trên tên file.

Kết luận: AI hoàn toàn có thể tự truy xuất trang Chính phủ và tải nguồn PDF chính thức khi pipeline được nối đúng; phần hiện tại chưa tự làm là worker tải nguồn, lưu binary vào S3, trích xuất/OCR, lập quan hệ điều-khoản–thủ tục–biểu mẫu và tạo bản ghi xác minh trong kho. Việc tự lọc biểu mẫu chỉ có thể thực hiện sau bước đọc nội dung nguồn thủ tục tương ứng; Nghị định 101 là căn cứ pháp lý, không phải mọi mẫu hồ sơ đều nằm trực tiếp trong một nghị định.
