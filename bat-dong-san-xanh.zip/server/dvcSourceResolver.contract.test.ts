import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("DVC source procedure code normalization contract", () => {
  it("normalizes canonical, UI and external procedure identifiers before DVC lookup", () => {
    const router = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");

    expect(router).toContain("const resolveDiscoveryProcedureCode = (procedureId: string, province?: string)");
    expect(router).toContain("getOfficialLandProcedure(mappedCode, province) || getOfficialLandProcedure(procedureId, province)");
    expect(router).toContain("const officialCode = resolveDiscoveryProcedureCode(input.procedureId, input.province);");
    expect(router).not.toContain("const officialCode = OFFICIAL_DISCOVERY_PROCEDURE_CODES[input.procedureId];");
  });
});
