import { describe, expect, it } from "vitest";
import { landProcedureBundleFor, landProcedureGuidanceSuggestion, landProcedurePreviewFor } from "./LandProcedureGuidanceStep";

describe("LandProcedureGuidanceStep", () => {
  it("suggests transfer for land and property sale dossiers", () => {
    expect(landProcedureGuidanceSuggestion({ propertyType: "land", transactionType: "sale" })).toBe("transfer");
    expect(landProcedureGuidanceSuggestion({ propertyType: "apartment", transactionType: "transfer_land" })).toBe("transfer");
  });

  it("suggests lease for industrial, agricultural and resort rental dossiers", () => {
    expect(landProcedureGuidanceSuggestion({ propertyType: "industrial", transactionType: "lease" })).toBe("lease");
    expect(landProcedureGuidanceSuggestion({ propertyType: "agricultural", transactionType: "Cho thuê đất nông nghiệp" })).toBe("lease");
    expect(landProcedureGuidanceSuggestion({ propertyType: "resort", transactionType: "cho thuê villa resort" })).toBe("lease");
  });

  it("keeps a safe transfer default when the property metadata is incomplete", () => {
    expect(landProcedureGuidanceSuggestion()).toBe("transfer");
  });

  it("builds a transfer bundle with registration, contract and financial documents", () => {
    const labels = landProcedureBundleFor("transfer").map(item => item.label).join(" | ");
    expect(labels).toContain("Mẫu 09/ĐK");
    expect(labels).toContain("Hợp đồng chuyển nhượng");
    expect(labels).toContain("lệ phí trước bạ");
    expect(labels).toContain("thuế thu nhập cá nhân");
  });

  it("prepares a transparent preview payload before download", () => {
    const template = landProcedureBundleFor("transfer").find(item => item.label.includes("Mẫu 09/ĐK"));
    expect(template).toBeTruthy();
    const preview = landProcedurePreviewFor(template!, { title: "Đất nền Thanh Khê", propertyType: "land", location: "Thanh Khê, Đà Nẵng", area: 200, legalStatus: "Đã có Giấy chứng nhận" }, "transfer");
    expect(preview.title).toContain("Mẫu 09/ĐK");
    expect(preview.procedureId).toBe("transfer");
    expect(preview.area).toBe("200 m²");
    expect(preview.sourceStatus).toContain("đối chiếu");
  });

  it("keeps lease bundles distinct from transfer bundles", () => {
    const labels = landProcedureBundleFor("lease").map(item => item.label).join(" | ");
    expect(labels).toContain("Hợp đồng cho thuê");
    expect(labels).not.toContain("Hợp đồng chuyển nhượng");
  });
});
