import { describe, expect, it } from "vitest";
import { auditLandDossierLegalSources, legalSourceAuditSummary } from "./legalSourceAudit";

describe("legal source audit draft-first workflow", () => {
  it("allows draft export/print after source review without verified binary", () => {
    const result = auditLandDossierLegalSources({
      province: "Đà Nẵng",
      sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791",
      sourceCheckedAt: "19/08/2026",
      templateProvenance: "metadata-only",
      requiredTemplateCount: 1,
      verifiedTemplateCount: 0,
      now: new Date("2026-08-19T10:00:00.000Z"),
    });

    expect(result.canReview).toBe(true);
    expect(result.canExportDraftOrPrint).toBe(true);
    expect(result.canExportOrPrint).toBe(false);
    expect(legalSourceAuditSummary(result)).toContain("bản nháp AI");
  });

  it("keeps Official export locked until binary verification is complete", () => {
    const result = auditLandDossierLegalSources({
      province: "Đà Nẵng",
      sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791",
      sourceCheckedAt: "19/08/2026",
      templateProvenance: "verified-binary",
      requiredTemplateCount: 1,
      verifiedTemplateCount: 1,
      now: new Date("2026-08-19T10:00:00.000Z"),
    });

    expect(result.canExportDraftOrPrint).toBe(true);
    expect(result.canExportOrPrint).toBe(true);
    expect(legalSourceAuditSummary(result)).toContain("Official");
  });
});

/* Draft output is a preparation aid; the user must verify, sign, and submit it
 * according to the receiving authority's current requirements. */
