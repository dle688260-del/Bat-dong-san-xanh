import { describe, expect, it } from "vitest";
import { buildAutoWorkflow, buildCategories, filterProcedures, type AutoProcedure } from "./autoDossierEngine";

const procedures: AutoProcedure[] = [
  { code: "1.012789", title: "Chuyển nhượng quyền sử dụng đất", description: "Đăng ký biến động đất đai", source: "Cổng Dịch vụ công" },
  { code: "2.000889", title: "Cấp Giấy chứng nhận lần đầu", description: "Cấp sổ lần đầu", source: "Cổng Dịch vụ công" },
];

describe("AI auto dossier module contract", () => {
  it("classifies and filters a live-like catalog without hard-coding one procedure", () => {
    const categories = buildCategories(procedures);
    expect(categories[0]).toEqual({ category: "Tất cả", count: 2 });
    expect(filterProcedures(procedures, "chuyển nhượng", "Giao dịch bất động sản")).toHaveLength(1);
    expect(filterProcedures(procedures, "2.000889", "Tất cả")[0]?.code).toBe("2.000889");
  });

  it("creates an independent ordered workflow from procedure metadata", () => {
    const workflow = buildAutoWorkflow({
      procedureName: "Đăng ký biến động đất đai",
      officialSteps: [
        { id: "discover", title: "Tìm nguồn chính thức", description: "Không yêu cầu URL từ người dùng", requiresInput: false },
        { id: "read", title: "Đọc hướng dẫn", description: "Tách thành phần hồ sơ", requiresInput: false },
        { id: "forms", title: "Phân tích biểu mẫu", description: "DOCX/PDF/XLSX/OCR", requiresInput: false },
        { id: "profile", title: "Nhập hồ sơ dùng một lần", description: "Dùng lại dữ liệu đã xác nhận", requiresInput: true },
        { id: "validate", title: "Kiểm tra", description: "Không bịa dữ liệu", requiresInput: false },
        { id: "export", title: "Xuất hồ sơ", description: "Draft hoặc Official có kiểm chứng", requiresInput: false },
      ],
    });
    expect(workflow.map(step => step.id)).toEqual(["discover", "read", "forms", "profile", "validate", "export"]);
    expect(workflow[0].description).toContain("URL");
    expect(workflow.at(-1)?.description).toContain("Official");
  });

  it("keeps requirements and dossier components in the generated sequence", () => {
    const workflow = buildAutoWorkflow({
      procedureName: "Cấp Giấy chứng nhận lần đầu",
      requirements: [{ id: "r1", label: "Giấy tờ nhân thân", source: "DVC", status: "required" }],
      dossierComponents: [{ name: "Đơn đăng ký" }],
    });
    expect(workflow.some(step => step.title.includes("Giấy tờ nhân thân"))).toBe(true);
    expect(workflow.some(step => step.title === "Đơn đăng ký")).toBe(true);
    expect(workflow.find(step => step.id === "profile")?.requiresInput).toBe(true);
  });
});
