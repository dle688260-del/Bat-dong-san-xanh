import { describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  createBuyerLead: vi.fn(async (input: unknown) => ({ id: 2, input })), createConsultationRequest: vi.fn(), createDeal: vi.fn(async (input: unknown) => ({ id: 6, input })), createLegalCheck: vi.fn(async (input: unknown) => ({ id: 4, input })), createOwner: vi.fn(async (input: unknown) => ({ id: 1, input })), createProperty: vi.fn(async (input: unknown) => ({ id: 10, input })), createPropertyImage: vi.fn(), ensurePropertyDossier: vi.fn(async (input: unknown) => ({ id: 20, created: true, input })), createSurvey: vi.fn(async (input: unknown) => ({ id: 3, input })), createValuation: vi.fn(async (input: unknown) => ({ id: 5, input })), getPublishedPropertyWithImages: vi.fn(), listBuyerLeads: vi.fn(), listConsultationRequests: vi.fn(), listDeals: vi.fn(), listLegalChecks: vi.fn(), listOwners: vi.fn(), listProperties: vi.fn(), listPropertiesByCreator: vi.fn(async (createdBy: number) => [{ id: 12, createdBy }]), listPublishedProperties: vi.fn(), listSurveys: vi.fn(), listValuations: vi.fn(), updateConsultationStatus: vi.fn(), updatePropertyStatus: vi.fn(async (id: number, status: string) => ({ success: true, id, status, reason: "updated" as const })), deleteProperty: vi.fn(async (id: number, requesterId?: number) => id === 99 ? { success: false, reason: "linked_records" as const } : requesterId === undefined ? { success: true } : { success: true }),
}));
vi.mock("./db", () => mocks);
vi.mock("./storage", () => ({ storagePut: vi.fn(async (key: string) => ({ key, url: `/manus-storage/${key}` })) }));

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const context = { user: { id: 7, openId: "admin", role: "admin", name: "Admin", email: "admin@example.com", loginMethod: "manus", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] } satisfies TrpcContext;
const userContext = { ...context, user: { ...context.user, id: 8, openId: "broker-user", role: "user", name: "Broker user" } } satisfies TrpcContext;

describe("brokerage mutations", () => {
  it("allows a signed-in user to upload source intake media", async () => {
    const caller = appRouter.createCaller(userContext);
    await expect(caller.properties.uploadImage({ fileName: "mat-tien.jpg", mimeType: "image/jpeg", data: Buffer.from("demo-image").toString("base64") })).resolves.toMatchObject({ url: expect.stringContaining("/manus-storage/") });
  });
  it("creates a standard property post with legal, transaction, broker and gallery fields", async () => {
    const caller = appRouter.createCaller(context);
    await caller.properties.create({ title: "Bán nhà 2 tầng Thanh Khê", slug: "ban-nha-thanh-khe", propertyType: "house", price: "7.90", area: "95", buildArea: "180", bedrooms: 4, bathrooms: 3, constructionYear: 2020, orientation: "Đông Nam", location: "Thanh Khê, Đà Nẵng", certificateType: "Sổ hồng", certificateArea: "95", landUsePurpose: "Đất ở đô thị", planningStatus: "Theo hồ sơ/chủ nhà cung cấp", mortgageStatus: "Không thế chấp", legalSource: "Theo hồ sơ/chủ nhà cung cấp", brokerageFee: "Thỏa thuận", depositTerms: "Đặt cọc theo thỏa thuận", transactionTerms: "Công chứng theo thỏa thuận", propertyCode: "BDS-TK-001", brokerName: "Lê Văn Tiến", brokerPhone: "0989682825", brokerZalo: "https://zalo.me/0989682825", imageUrls: ["https://example.com/front.jpg", "https://example.com/kitchen.jpg"] });
    expect(mocks.createProperty).toHaveBeenCalledWith(expect.objectContaining({ title: "Bán nhà 2 tầng Thanh Khê", buildArea: "180", bedrooms: 4, certificateType: "Sổ hồng", propertyCode: "BDS-TK-001", createdBy: 7 }));
    expect(mocks.createPropertyImage).toHaveBeenCalledTimes(2);
    expect(mocks.ensurePropertyDossier).toHaveBeenCalledWith(expect.objectContaining({ propertyId: 10, createdBy: 7 }));
  });

  it("allows a signed-in non-admin user to create a property draft", async () => {
    const caller = appRouter.createCaller(userContext);
    const created = await caller.properties.create({ title: "Nhà nháp Sơn Trà", slug: "nha-nhap-son-tra", propertyType: "house", price: "5.20", area: "80", location: "Sơn Trà, Đà Nẵng" });
    expect(created.id).toBe(10);
    expect(mocks.createProperty).toHaveBeenCalledWith(expect.objectContaining({ title: "Nhà nháp Sơn Trà", createdBy: 8 }));
    expect(mocks.ensurePropertyDossier).toHaveBeenCalledWith(expect.objectContaining({ propertyId: 10, createdBy: 8 }));
  });

  it("allows an admin to publish a created draft", async () => {
    const caller = appRouter.createCaller(context);
    const created = await caller.properties.create({ title: "Nhà kiểm duyệt Hải Châu", slug: "nha-kiem-duyet-hai-chau", propertyType: "house", price: "6.80", area: "90", location: "Hải Châu, Đà Nẵng" });
    await caller.properties.updateStatus({ id: created.id, status: "published" });
    expect(mocks.updatePropertyStatus).toHaveBeenCalledWith(created.id, "published");
  });

  it("lets a non-admin user read only their own property drafts", async () => {
    const caller = appRouter.createCaller(userContext);
    await expect(caller.properties.mine()).resolves.toEqual([{ id: 12, createdBy: 8 }]);
    expect(mocks.listPropertiesByCreator).toHaveBeenCalledWith(8);
  });

  it("allows an admin to delete any property", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.properties.delete({ id: 10 })).resolves.toEqual({ success: true });
    expect(mocks.deleteProperty).toHaveBeenCalledWith(10, undefined);
  });

  it("blocks a non-admin user from deleting any property", async () => {
    const caller = appRouter.createCaller(userContext);
    await expect(caller.properties.delete({ id: 12 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("blocks deleting a property with linked operational records", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.properties.delete({ id: 99 })).rejects.toMatchObject({ code: "CONFLICT" });
  });

  it("keeps non-admin users away from admin listing and publishing", async () => {
    const caller = appRouter.createCaller(userContext);
    await expect(caller.properties.adminList()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.properties.updateStatus({ id: 10, status: "published" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("creates owner and buyer records through protected procedures", async () => {
    const caller = appRouter.createCaller(context);
    await caller.brokerage.createOwner({ name: "Chủ nhà", phone: "0989682825" });
    await caller.brokerage.createBuyer({ name: "Khách mua", phone: "0900000000", preferredArea: "Sơn Trà" });
    expect(mocks.createOwner).toHaveBeenCalledWith(expect.objectContaining({ name: "Chủ nhà", phone: "0989682825" }));
    expect(mocks.createBuyerLead).toHaveBeenCalledWith(expect.objectContaining({ name: "Khách mua", assignedTo: 7 }));
  });

  it("creates survey, legal check, valuation and deal records with admin attribution", async () => {
    const caller = appRouter.createCaller(context);
    await caller.brokerage.createSurvey({ propertyId: 10, purpose: "Đầu tư" });
    await caller.brokerage.createLegalCheck({ propertyId: 10, status: "pending" });
    await caller.brokerage.createValuation({ propertyId: 10, estimatedPrice: "4.50" });
    await caller.brokerage.createDeal({ propertyId: 10, stage: "new" });
    expect(mocks.createSurvey).toHaveBeenCalledWith(expect.objectContaining({ propertyId: 10, createdBy: 7 }));
    expect(mocks.createLegalCheck).toHaveBeenCalledWith(expect.objectContaining({ propertyId: 10, checkedBy: 7 }));
    expect(mocks.createValuation).toHaveBeenCalledWith(expect.objectContaining({ propertyId: 10, assessedBy: 7 }));
    expect(mocks.createDeal).toHaveBeenCalledWith(expect.objectContaining({ propertyId: 10, assignedTo: 7 }));
  });
});
