ALTER TABLE `legal_templates` ADD `province` varchar(120);--> statement-breakpoint
ALTER TABLE `legal_templates` ADD `receivingAuthority` varchar(255);--> statement-breakpoint
ALTER TABLE `legal_templates` ADD `jurisdictionScope` enum('national','provincial','district','commune','agency_specific') DEFAULT 'national' NOT NULL;