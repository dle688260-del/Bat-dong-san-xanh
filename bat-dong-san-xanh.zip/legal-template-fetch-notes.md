# Ghi chú kiểm tra nguồn binary biểu mẫu

Ngày kiểm tra: 17/08/2026.

- URL CSDL DVC cho Mus15DKLD.docx: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1 — phản hồi HTTP 503, content-type text/html, 203 bytes; không phải file DOCX.
- URL CSDL DVC cho Mẫu 09/ĐK: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fd07c1846d6e054 — phản hồi HTTP 503, content-type text/html, 203 bytes; không phải file DOC/DOCX.
- Kết quả tìm kiếm có URL bên thứ ba cho Mẫu 09/ĐK: https://cdn.thuvienphapluat.vn/uploads/DanLuat-BanAn/mau-09-dk.doc — cần kiểm tra quyền sử dụng, phiên bản và đối chiếu với cơ quan nhà nước trước khi gọi là verified.
- Kết quả tìm kiếm có URL bên thứ ba cho Mẫu 15: https://cdn.thuvienphapluat.vn/uploads/tintuc/2025/06/17/M%E1%BA%ABu%20s%E1%BB%91%2015.docx — cần kiểm tra quyền sử dụng, nội dung và phiên bản trước khi tích hợp.
- Một nguồn địa phương được tìm thấy cho Mẫu 15 dạng PDF: https://trangbom.dongnai.gov.vn/uploads/trangbom/news/2025_09/mau-so-15-cap-moi.signed.pdf — cần xác minh trực tiếp với địa phương và không tự động gắn Official.

Kết luận: các URL chính thức hiện trả 503; không được lưu HTML lỗi làm template binary hoặc gắn nhãn Official. Engine chỉ nên nhận file đã xác minh MIME/magic bytes, checksum và metadata nguồn.

## Bổ sung kiểm tra ngày 17/08/2026

- Cổng DVC Quốc gia: https://dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc — kết quả tìm kiếm nêu Mẫu số 09/ĐK và liên kết tệp “Mẫu 09.docx”, nhưng chưa cung cấp URL binary ổn định trong kết quả thụ động.
- Cổng DVC Văn phòng Chính phủ: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc — trang thủ tục đăng ký biến động do chuyển nhượng; cần lấy tệp thực tế từ trang tương ứng trước khi tích hợp.
- Cổng TTHC Huế: https://tthc.hue.gov.vn/Content/Thutuc/chitiet.aspx?iThuTuc — nguồn địa phương tham khảo thành phần hồ sơ.
- Cổng DVC An Giang: https://dichvucong1.angiang.gov.vn/kiosk/chi-tiet/chi-tiet-thu-tuc?ma-thu-tuc — nguồn địa phương tham khảo thành phần hồ sơ.
- Bộ Tài chính: https://vbpq.mof.gov.vn/DKC.FileManagement/FileStorage/File/561782 — có tệp văn bản thuế nhưng chưa phải binary biểu mẫu chuyển nhượng đất cần tích hợp.
- Đồng Tháp: https://lapvo.dongthap.gov.vn/documents/439374/0/I+1.docx/e526a0bf-2084-8681-99c6-ffa9ce0db230?t=1589443086307 — kết quả nêu Mẫu 01/LPTB và tờ khai thuế TNCN; cần xác minh thời hiệu và nội dung trước khi dùng.

Kết luận giữ nguyên: không gắn nhãn Official/verified-binary dựa trên snippet hoặc nguồn bên thứ ba. Chỉ bật adapter khi nhận được file thật, đúng magic bytes/MIME, checksum và metadata nguồn/phiên bản có thể kiểm chứng.

## Kiểm tra bổ sung ngày 17/08/2026
- Trang thủ tục chính thức `https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410` xác nhận hồ sơ chuyển nhượng gồm Mẫu 09/ĐK, hợp đồng/văn bản chuyển quyền, bản gốc Giấy chứng nhận và giấy tờ phát sinh theo trường hợp.
- Trang này dẫn Mẫu 09/ĐK tới `https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe998b4cf4ed90a`; trang cấp Giấy chứng nhận lần đầu dẫn Mus15DKLD.docx tới `https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1`.
- Kiểm tra thụ động bằng User-Agent/Referer: cả hai endpoint trả HTTP 503, `Content-Type: text/html`, không phải PDF/DOCX. Không tích hợp phản hồi này làm template binary.
