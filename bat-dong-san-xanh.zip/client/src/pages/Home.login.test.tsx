import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  startLogin: vi.fn(),
  latestQuery: { data: [], isLoading: false },
  createMutation: { mutate: vi.fn(), isPending: false },
}));

vi.mock("@/const", () => ({ startLogin: mocks.startLogin }));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { role: "admin" } }) }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    properties: { latest: { useQuery: () => mocks.latestQuery } },
    consultations: { create: { useMutation: () => mocks.createMutation } },
  },
}));

import Home, { requestLogin } from "./Home";

describe("Home login entry point", () => {
  beforeEach(() => mocks.startLogin.mockClear());

  it("renders one admin entry while keeping the public storefront free of admin-only shortcuts", () => {
    const markup = renderToStaticMarkup(createElement(Home));
    expect(markup).toContain('href="/crm/login"');
    expect(markup).toContain("Đăng nhập CRM");
    expect(markup).not.toContain('href="/crm"');
    expect(markup).not.toContain("Đăng nhập email");
    expect(markup).not.toContain("Thông báo yêu cầu");
    expect(markup).not.toContain("Quản lý nguồn hàng");
    expect(markup).not.toContain('href="/dang-nhap-quan-tri"');
  });

  it("renders the compact quick navigation above the hero", () => {
    const markup = renderToStaticMarkup(createElement(Home));
    expect(markup).toContain('aria-label="Điều hướng nhanh"');
    expect(markup).toContain('data-testid="public-menu-toggle"');
    expect(markup).toContain('data-testid="public-share-button"');
    expect(markup).toContain('aria-label="Chia sẻ website"');
    expect(markup).toContain('aria-label="Mở menu"');
    expect(markup).toContain("Nguồn hàng");
    expect(markup).toContain("Mua BĐS");
    expect(markup).toContain("Ký gửi");
    expect(markup).toContain("Tư vấn");
  });

  it("routes the login CTA callback to the existing OAuth handler", () => {
    requestLogin();
    expect(mocks.startLogin).toHaveBeenCalledOnce();
  });

  it("renders compact consultation form and direct contact links", () => {
    const markup = renderToStaticMarkup(createElement(Home));
    expect(markup).toContain("Đăng ký tư vấn");
    expect(markup).toContain('href="tel:0989682825"');
    expect(markup).toContain('href="https://zalo.me/0989682825"');
    expect(markup).toContain('href="https://www.facebook.com/"');
    expect(markup).toContain('name="interest"');
    expect(markup).toContain('name="phone"');
  });
});
