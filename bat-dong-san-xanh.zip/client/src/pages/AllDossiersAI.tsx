import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { FileSearch, FolderOpen, Building2, UserRound, Handshake, FileText, Sparkles, ExternalLink, ShieldCheck, Lock } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

const dossierGroups = [
  { id: "all", label: "Tất cả hồ sơ" },
  { id: "customer", label: "Hồ sơ khách hàng" },
  { id: "owner", label: "Hồ sơ chủ nhà" },
  { id: "property", label: "Hồ sơ bất động sản" },
  { id: "legal", label: "Hồ sơ pháp lý" },
  { id: "tax", label: "Hồ sơ thuế" },
  { id: "transaction", label: "Hồ sơ giao dịch" },
  { id: "notary", label: "Hồ sơ công chứng" },
  { id: "brokerage", label: "Hồ sơ môi giới" },
  { id: "land", label: "Hồ sơ đất đai" },
] as const;

type HubItem = { id: string; group: string; title: string; subtitle: string; status: string; propertyId?: number; icon: "property" | "person" | "deal" | "file" };

function iconFor(kind: HubItem["icon"]) {
  if (kind === "property") return <Building2 className="h-5 w-5" />;
  if (kind === "person") return <UserRound className="h-5 w-5" />;
  if (kind === "deal") return <Handshake className="h-5 w-5" />;
  return <FileText className="h-5 w-5" />;
}

export function landDossierToHubItem(item: { id: number; title: string; dossierCode: string; procedureType: string; status: string; propertyId: number | null }): HubItem {
  return {
    id: `land-${item.id}`,
    group: "land",
    title: item.title,
    subtitle: `${item.dossierCode} · ${item.procedureType}${item.propertyId ? ` · BĐS #${item.propertyId}` : ""}`,
    status: item.status === "completed" ? "Đã hoàn tất" : item.status === "paused" ? "Tạm dừng" : item.status === "cancelled" ? "Đã hủy" : "Đang xử lý",
    propertyId: item.propertyId || undefined,
    icon: "file",
  };
}

export default function AllDossiersAI() {
  const [query, setQuery] = useState("");
  const [group, setGroup] = useState("all");
  const me = trpc.auth.me.useQuery();
  const isAdmin = me.data?.role === "admin";
  const properties = trpc.properties.adminList.useQuery();
  const owners = trpc.brokerage.owners.useQuery();
  const buyers = trpc.brokerage.buyers.useQuery();
  const archives = trpc.archives.list.useQuery({});
  const landDossiers = trpc.landDossiers.list.useQuery();

  const records = useMemo<HubItem[]>(() => {
    const items: HubItem[] = [];
    (properties.data || []).forEach(item => items.push({ id: `property-${item.id}`, group: "property", title: item.title, subtitle: `${item.propertyCode || "Chưa có mã"} · ${item.location}`, status: item.status, propertyId: item.id, icon: "property" }));
    (owners.data || []).forEach(item => items.push({ id: `owner-${item.id}`, group: "owner", title: item.name, subtitle: `${item.phone}${item.email ? ` · ${item.email}` : ""}`, status: "Đang quản lý", icon: "person" }));
    (buyers.data || []).forEach(item => items.push({ id: `buyer-${item.id}`, group: "customer", title: item.name, subtitle: `${item.preferredArea || "Chưa có khu vực"} · ${item.status}`, status: item.status, icon: "person" }));
    (archives.data || []).forEach(item => items.push({ id: `archive-${item.file.id}`, group: item.file.category === "legal" ? "legal" : item.file.category === "transaction" ? "transaction" : item.file.category === "marketing" ? "brokerage" : item.file.category === "valuation" ? "tax" : "property", title: item.file.fileName, subtitle: `${item.file.documentType} · ${item.property.title}`, status: "Đã lưu", propertyId: item.property.id, icon: "file" }));
    (landDossiers.data || []).forEach(item => items.push(landDossierToHubItem(item)));
    return items;
  }, [properties.data, owners.data, buyers.data, archives.data, landDossiers.data]);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return records.filter(item => {
      const matchesGroup = group === "all" || item.group === group;
      const matchesQuery = !normalized || `${item.title} ${item.subtitle} ${item.status}`.toLowerCase().includes(normalized);
      return matchesGroup && matchesQuery;
    });
  }, [records, group, query]);

  function askAI() {
    if (query.trim().length < 4) { toast.error("Hãy nhập nội dung cần tìm, ví dụ: Hồ sơ chuyển nhượng đất."); return; }
    toast.success(`Đã lọc kho hồ sơ theo: ${query.trim()}`);
  }

  return <DashboardLayout><main className="min-h-screen bg-[#F4F7F4] px-4 py-5 text-[#18352D] sm:px-6 lg:px-8"><div className="mx-auto max-w-[1500px]">
    <section className="rounded-[28px] bg-gradient-to-br from-[#0E5A45] via-[#16745A] to-[#3B9A78] p-6 text-white shadow-lg sm:p-8"><div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end"><div><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#E7C36B]">Quản lý nguồn hàng · Kho tổng hợp</p><h1 className="mt-2 text-3xl font-black sm:text-4xl">Hồ sơ AI</h1><p className="mt-3 max-w-3xl text-sm leading-6 text-white/85 sm:text-base">Kho quản lý toàn bộ hồ sơ liên quan đến nguồn hàng và giao dịch. Tìm theo khách hàng, chủ nhà, BĐS, pháp lý, thuế, công chứng, môi giới hoặc đất đai.</p></div><div className="flex flex-wrap gap-2 text-xs font-bold"><span className="rounded-full bg-white/15 px-3 py-2">Kho tập trung</span><span className="rounded-full bg-white/15 px-3 py-2">Tìm bằng ngôn ngữ tự nhiên</span><span className="rounded-full bg-white/15 px-3 py-2">Liên kết theo BĐS</span></div></div></section>
    <section className="mt-5 rounded-2xl border border-[#D7E8DC] bg-white p-5 shadow-sm"><div className={`mb-4 flex items-start gap-3 rounded-xl border p-3 text-sm ${isAdmin ? "border-[#B8DEC8] bg-[#F0FAF3] text-[#21623E]" : "border-[#F0D9A4] bg-[#FFF9EA] text-[#6F5520]"}`}><span className="mt-0.5">{isAdmin ? <ShieldCheck className="h-5 w-5" /> : <Lock className="h-5 w-5" />}</span><div><p className="font-black">{isAdmin ? "Quyền quản trị: được xem và tải hồ sơ nhạy cảm" : "Hồ sơ nhạy cảm được giới hạn theo vai trò"}</p><p className="mt-1 text-xs leading-5">{isAdmin ? "Các hồ sơ pháp lý và giao dịch được bảo vệ ở backend; thao tác tải, đổi tên và xóa yêu cầu quyền quản trị." : "Tài khoản người dùng thường không được xem hoặc tải hồ sơ pháp lý và giao dịch. Hãy liên hệ quản trị viên nếu cần cấp quyền."}</p></div></div><div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between"><div><p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">Không phải thư viện biểu mẫu</p><h2 className="mt-1 text-2xl font-black">Tìm hồ sơ trong toàn bộ nguồn hàng</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">Ví dụ: <strong>“Hồ sơ chuyển nhượng đất”</strong>, “hồ sơ khách hàng Sơn Trà” hoặc “tài liệu pháp lý của BĐS”. Kết quả bên dưới là hồ sơ đang có trong hệ thống.</p></div><div className="flex items-center gap-2 rounded-xl bg-[#EEF8F2] px-3 py-2 text-sm font-bold text-[#17634D]"><FileSearch className="h-4 w-4" />{filtered.length} kết quả</div></div><div className="mt-4 flex flex-col gap-2 sm:flex-row"><Input value={query} onChange={e => setQuery(e.target.value)} placeholder="Ví dụ: Hồ sơ chuyển nhượng đất..." aria-label="Tìm kiếm Hồ sơ AI" /><Button type="button" onClick={askAI} className="bg-[#234D70] hover:bg-[#0B4B39]"><Sparkles className="mr-2 h-4 w-4" />AI tìm hồ sơ</Button></div><div className="mt-3 flex gap-2 overflow-x-auto pb-1">{dossierGroups.map(item => <button key={item.id} type="button" onClick={() => setGroup(item.id)} className={`whitespace-nowrap rounded-full px-3 py-2 text-xs font-bold ${group === item.id ? "bg-[#234D70] text-white" : "bg-[#EEF8F2] text-[#17634D] hover:bg-[#DCEAF3]"}`}>{item.label}</button>)}</div></section>
    <section className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">{dossierGroups.slice(1).map(item => <button key={item.id} type="button" onClick={() => setGroup(item.id)} className={`rounded-2xl border p-4 text-left shadow-sm transition-colors ${group === item.id ? "border-[#234D70] bg-[#E4F4EA]" : "border-[#D7E8DC] bg-white hover:border-[#9CC9B0]"}`}><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Nhóm hồ sơ</p><p className="mt-2 font-black text-[#18352D]">{item.label}</p><p className="mt-2 text-xs text-[#60766D]">Mở và quản lý tài liệu liên quan</p></button>)}</section>
    <section className="mt-5 rounded-2xl border border-[#D7E8DC] bg-white p-5 shadow-sm"><div className="flex items-center justify-between gap-3"><div><h2 className="text-xl font-black">Hồ sơ đang quản lý</h2><p className="mt-1 text-sm text-[#60766D]">Danh sách tổng hợp, không thay thế thư viện biểu mẫu pháp lý.</p></div><a href="/hs-dat-dai-ai" className="inline-flex items-center gap-2 rounded-lg bg-[#FFF4D7] px-3 py-2 text-xs font-black text-[#6F5617]">Mở HS ĐẤT ĐAI AI <ExternalLink className="h-3.5 w-3.5" /></a></div>{filtered.length ? <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">{filtered.slice(0, 60).map(item => <article key={item.id} className="rounded-xl border border-[#E4ECE6] bg-[#FBFEFC] p-4"><div className="flex items-start gap-3"><span className="rounded-xl bg-[#E4F4EA] p-3 text-[#17634D]">{iconFor(item.icon)}</span><div className="min-w-0 flex-1"><p className="text-[10px] font-black uppercase tracking-wide text-[#B38321]">{dossierGroups.find(groupItem => groupItem.id === item.group)?.label || "Hồ sơ"}</p><h3 className="mt-1 truncate font-black">{item.title}</h3><p className="mt-1 line-clamp-2 text-xs leading-5 text-[#60766D]">{item.subtitle}</p></div></div><div className="mt-3 flex items-center justify-between text-xs"><span className="rounded-full bg-[#EEF8F2] px-2 py-1 font-bold text-[#17634D]">{item.status}</span>{item.propertyId && <a href={`/ho-so-dien-tu?propertyId=${item.propertyId}`} className="font-bold text-[#17634D]">Mở hồ sơ BĐS</a>}</div></article>)}</div> : <div className="mt-4 rounded-xl bg-[#FFF9EA] p-8 text-center text-sm text-[#6F5520]"><FolderOpen className="mx-auto mb-3 h-10 w-10" />Chưa có hồ sơ phù hợp với điều kiện tìm kiếm.</div>}<p className="mt-5 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3 text-xs leading-5 text-[#6F5520]"><strong>Phạm vi Hồ sơ AI:</strong> AI hỗ trợ tìm kiếm, phân loại và tóm tắt dữ liệu nội bộ. Không dùng kết quả AI thay cho văn bản chính thức, luật sư, công chứng viên hoặc cơ quan nhà nước.</p></section>
  </div></main></DashboardLayout>;
}

export function allDossiersAIGroups() { return dossierGroups.map(item => item.id); }
export function allDossiersAIPlaceholder() { return "Ví dụ: Hồ sơ chuyển nhượng đất..."; }
