# Nghiên cứu danh mục thủ tục đất đai cho AI đa thủ tục

Ngày: 18/08/2026.

Các nguồn công khai được dùng để định hướng danh mục và luồng, không coi là tư vấn pháp lý tự động:

| Nhóm | Nguồn | Ghi nhận thiết kế |
|---|---|---|
| Đăng ký biến động quyền sử dụng đất/quyền sở hữu tài sản | https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889 | AI cần hỏi loại biến động, giấy tờ quyền sử dụng đất, các bên, nghĩa vụ tài chính và nơi nộp. |
| Tách thửa/hợp thửa đồng thời với chuyển quyền | https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-lien-thong-chi-tiet.html?ma_thu_tuc=418843 | AI cần tách riêng dữ liệu thửa gốc, thửa sau tách/hợp, bản vẽ và điều kiện địa phương. |
| Cấp đổi Giấy chứng nhận | https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783 | AI cần hỏi lý do cấp đổi, giấy chứng nhận hiện có và điểm tiếp nhận hồ sơ. |
| Thủ tục đất đai cấp bộ | https://dichvucong.monre.gov.vn/pages/ChiTietThuTucHanhChinh.aspx?tt=189 | AI cần hiển thị thời hạn/địa điểm như thông tin tham khảo và cảnh báo cần kiểm tra địa phương. |
| Cung cấp dữ liệu đất đai | https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 | Có thể là một thủ tục bổ sung khi người dùng cần trích lục/thông tin dữ liệu đất đai. |

Danh mục sản phẩm nghiệp vụ dự kiến: sang tên do mua bán nhà/đất; chuyển nhượng quyền sử dụng đất; cho thuê/cho thuê lại đất; tặng cho; thừa kế; đăng ký biến động; cấp Giấy chứng nhận lần đầu; cấp đổi/cấp lại; chuyển mục đích sử dụng đất; tách thửa; hợp thửa; đăng ký/xóa thế chấp; đính chính/cập nhật thông tin; góp vốn bằng quyền sử dụng đất; cung cấp dữ liệu đất đai.

Thiết kế AI: người dùng nhập câu tự nhiên hoặc chọn nhóm; AI nhận diện một hay nhiều thủ tục liên quan; hỏi bộ câu hỏi dùng chung và câu hỏi riêng; tạo checklist, biểu mẫu tham khảo, nghĩa vụ tài chính có thể phát sinh, hướng dẫn từng bước và bộ file DOCX/PDF/ZIP riêng.

Phạm vi an toàn: dữ liệu và file là bản hỗ trợ tham khảo để rà soát, in, ký và nộp; không tự khẳng định đủ điều kiện pháp lý, không thay thế cơ quan tiếp nhận, công chứng viên hoặc tư vấn chuyên môn.
