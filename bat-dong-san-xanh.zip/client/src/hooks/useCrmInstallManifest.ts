import { useEffect } from "react";

const CRM_MANIFEST_HREF = "/crm-manifest.webmanifest";
const STOREFRONT_MANIFEST_HREF = "/manifest.webmanifest";

export function useCrmInstallManifest() {
  useEffect(() => {
    const existing = document.querySelector<HTMLLinkElement>('link[rel="manifest"]');
    const link = existing ?? document.createElement("link");
    const previousHref = existing?.getAttribute("href") ?? STOREFRONT_MANIFEST_HREF;
    link.rel = "manifest";
    link.href = CRM_MANIFEST_HREF;
    if (!existing) document.head.appendChild(link);

    return () => {
      link.href = previousHref;
      if (!existing) link.remove();
    };
  }, []);
}

export const CRM_MANIFEST_PATH = CRM_MANIFEST_HREF;
