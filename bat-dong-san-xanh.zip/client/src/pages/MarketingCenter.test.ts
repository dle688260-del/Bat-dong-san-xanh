import { describe, expect, it } from "vitest";
import fs from "node:fs";
import path from "node:path";

const source = fs.readFileSync(path.resolve(process.cwd(), "client/src/pages/MarketingCenter.tsx"), "utf8");

describe("MarketingCenter contract", () => {
  it("exposes the requested marketing sections", () => {
    expect(source).toContain('"overview", "Tổng quan"');
    expect(source).toContain('"campaigns", "Chiến dịch"');
    expect(source).toContain('"content", "AI Content"');
    expect(source).toContain('"channels", "Kênh"');
    expect(source).toContain('"inventory", "Nguồn hàng"');
    expect(source).toContain('"audiences", "Đối tượng"');
    expect(source).toContain('"calendar", "Lịch nội dung"');
    expect(source).toContain('"analytics", "Phân tích"');
  });

  it("uses published property data as the marketing inventory source", () => {
    expect(source).toContain('property.status === "published"');
    expect(source).toContain("BĐS lấy trực tiếp từ kho đang bán");
    expect(source).toContain("Nguồn hàng, chiến dịch, nội dung AI và lead được nối với cùng dữ liệu CRM");
  });

  it("keeps AI content as a reviewable draft instead of auto-publishing", () => {
    expect(source).toContain("AI Content · bản nháp cần duyệt");
    expect(source).toContain("AI không tự khẳng định pháp lý hoặc quy hoạch.");
    expect(source).toContain("Nội dung được lưu ở trạng thái nháp.");
  });
});
