import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

describe("legal production pipeline contract", () => {
  it("materializes every fetched DVC snapshot into production requirements", () => {
    const scheduled = readFileSync(new URL("./scheduledLegalSync.ts", import.meta.url), "utf8");
    const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(scheduled).toContain("materializeLegalProcedureSnapshot");
    expect(scheduled).toContain("dossierComponents: scan.dossierComponents");
    expect(db).toContain("legalProcedureRequirements");
    expect(db).toContain("Idempotent theo procedureId + label");
  });

  it("exposes the full 2304 appendix catalog instead of only the curated registry", () => {
    const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(db).toContain("OFFICIAL_2304_PROCEDURE_CODES");
    expect(db).toContain("Phụ lục 2304");
    expect(db).toContain("const appendixCode = OFFICIAL_2304_PROCEDURE_CODES.find");
  });

  it("uses verified government names for the pilot appendix procedures", () => {
    const index = readFileSync(new URL("./officialLandProcedureCodeIndex.ts", import.meta.url), "utf8");
    const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(index).toContain("VERIFIED_2304_PROCEDURE_NAMES");
    expect(index).toContain("1.012775");
    expect(index).toContain("Cho phép chuyển mục đích sử dụng đất");
    expect(index).toContain("1.012779");
    expect(index).toContain("1.012784");
    expect(index).toContain("Tách thửa hoặc hợp thửa đất");
    expect(index).toContain("1.012785");
    expect(index).toContain("đã chuyển quyền sử dụng đất trước ngày 01 tháng 8 năm 2024");
    expect(index).toContain("1.012787");
    expect(index).toContain("trong dự án bất động sản");
    expect(index).toContain('"1.012786": "Cấp lại Giấy chứng nhận do bị mất"');
    expect(db).toContain("getVerified2304ProcedureName");
    expect(db).toContain("verifiedName?.toLocaleLowerCase(\"vi\")");
  });

  it("uses the in-flight materialize cache and skips slow alternate scans after DVC failure", () => {
    const routers = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(routers).toContain("const materialized = await materializeRegistryOnce(procedureCode)");
    expect(routers).toContain("const shouldFallback = snapshot.fetched &&");
  });

  it("keeps Official gated by verified binary and checksum", () => {
    const scheduled = readFileSync(new URL("./scheduledLegalSync.ts", import.meta.url), "utf8");
    expect(scheduled).toContain("downloaded.checksum !== official.checksum");
    expect(scheduled).toContain("upsertOfficialLegalTemplate");
  });

  it("keeps failed fetches and missing snapshots visible as incomplete", () => {
    const scheduled = readFileSync(new URL("./scheduledLegalSync.ts", import.meta.url), "utf8");
    const page = readFileSync(new URL("../client/src/pages/AILegalKnowledgeBase.tsx", import.meta.url), "utf8");
    expect(scheduled).toContain('status: "failed"');
    expect(scheduled).toContain('status: "not-found"');
    expect(page).toContain("pendingProcedures");
    expect(page).toContain("Boolean(item.error || item.warning");
    expect(page).toContain("Pending/chưa hoàn tất");
  });

  it("cập nhật tên placeholder theo registry khi materialize thủ tục đã tồn tại", () => {
    const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(db).toContain("const verifiedName = item?.name ?? registryItem?.name");
    expect(db).toContain("const isPlaceholder = !currentName");
    expect(db).toContain("await db.update(legalProcedures).set({ name: verifiedName");
    expect(db).toContain("return existing[0];");
  });

  it("does not report zero pending when a batch item has warning or missing snapshot", () => {
    const page = readFileSync(new URL("../client/src/pages/AILegalKnowledgeBase.tsx", import.meta.url), "utf8");
    expect(page).toContain("pendingProcedures");
    expect(page).toContain("Boolean(item.error || item.warning");
    expect(page).toContain("Pending/chưa hoàn tất");
    expect(page).toContain("Math.max(item.syncStatus.pendingCount || 0, item.warning || item.error ? 1 : 0)");
  });
});

// This file is intentionally contract-focused: network fetches and storage writes
// must remain in the application/runtime tests and must not seed or mutate data.
