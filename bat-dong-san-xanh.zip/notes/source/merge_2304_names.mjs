import fs from "node:fs";

const sourcePath = new URL("./2304-names-extracted.json", import.meta.url);
const targetPath = new URL("../../server/officialLandProcedureCodeIndex.ts", import.meta.url);
const entries = JSON.parse(fs.readFileSync(sourcePath, "utf8"));
const target = fs.readFileSync(targetPath, "utf8");

const unique = new Map();
for (const entry of entries) {
  if (!entry || typeof entry.code !== "string" || typeof entry.name !== "string") continue;
  const code = entry.code.trim().replace(/\s+/g, "");
  const name = entry.name.trim();
  if (!/^1\.012\d{3}$/.test(code) || !name) continue;
  unique.set(code, name);
}

const mapBody = [...unique.entries()]
  .sort(([left], [right]) => left.localeCompare(right))
  .map(([code, name]) => `  ${JSON.stringify(code)}: ${JSON.stringify(name)},`)
  .join("\n");

const replacement = `/** Tên đã đối soát từ Phụ lục Quyết định 2304/QĐ-BNNMT. */\nexport const VERIFIED_2304_PROCEDURE_NAMES: Readonly<Record<string, string>> = {\n${mapBody}\n};`;
const pattern = /\/\*\* Tên đã đối soát[\s\S]*?export const VERIFIED_2304_PROCEDURE_NAMES: Readonly<Record<string, string>> = \{[\s\S]*?\n\};/;
if (!pattern.test(target)) throw new Error("Không tìm thấy mapping VERIFIED_2304_PROCEDURE_NAMES");
fs.writeFileSync(targetPath, target.replace(pattern, replacement));
console.log(JSON.stringify({ extracted: entries.length, mapped: unique.size, first: [...unique.keys()][0], last: [...unique.keys()].at(-1) }));
