import fs from "node:fs";
const s=fs.readFileSync("client/src/pages/LandDossierBuilder.tsx","utf8");
for (const re of [/const \[[^\]]+\] = useState\([^;]+\);/g,/const [A-Za-z0-9_]+ = trpc\.[^;]+;/g]) {
  console.log(`\n=== ${re} ===`);
  let m; let count=0;
  while((m=re.exec(s)) && count++<120) console.log(m[0]);
}
