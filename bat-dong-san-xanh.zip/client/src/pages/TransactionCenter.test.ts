import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "client/src/pages/TransactionCenter.tsx"), "utf8");

describe("TransactionCenter contract", () => {
  it("keeps Quy trình and Giao dịch as separate CRM concepts", () => {
    expect(source).toContain("Trung tâm CRM · Hồ sơ giao dịch");
    expect(source).toContain("Pipeline giao dịch");
    expect(source).toContain("Hồ sơ giao dịch điện tử");
  });

  it("persists a real transaction through the brokerage mutation", () => {
    expect(source).toContain("trpc.brokerage.createDeal.useMutation");
    expect(source).toContain("createDeal.mutate");
    expect(source).toContain("propertyId: Number(form.propertyId)");
    expect(source).toContain("Lưu giao dịch");
  });

  it("selects an existing sold product and reuses its dossier link", () => {
    expect(source).toContain("trpc.properties.soldForTransaction.useQuery");
    expect(source).toContain("Sản phẩm Đã bán trong Nguồn hàng");
    expect(source).toContain("propertyId #{form.propertyId}");
    expect(source).toContain("Hồ sơ Đã bán");
    expect(source).toContain("không tạo bản sao");
  });

  it("exposes the transaction AI assistant without claiming legal confirmation", () => {
    expect(source).toContain("trpc.brokerage.aiAssistant.useMutation");
    expect(source).toContain("Phân tích hồ sơ giao dịch");
    expect(source).toContain("không tự xác nhận tính hợp lệ của giấy tờ");
  });
});
