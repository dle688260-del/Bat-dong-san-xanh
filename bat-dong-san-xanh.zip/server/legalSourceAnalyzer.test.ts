import { describe, expect, it, vi, afterEach } from "vitest";
import { TRPCError } from "@trpc/server";
import { analyzeLegalSourceUrl, searchLegalDocuments } from "./legalSourceAnalyzer";

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe("analyzeLegalSourceUrl", () => {
  it("rejects non-HTTPS sources before fetching", async () => {
    await expect(analyzeLegalSourceUrl("http://dichvucong.gov.vn/thu-tuc"))
      .rejects.toMatchObject<Partial<TRPCError>>({ code: "BAD_REQUEST" });
  });

  it("extracts metadata, authority and DOCX/PDF attachments from public HTML", async () => {
    const html = `<!doctype html><html><head><title>Đăng ký biến động đất đai</title></head><body>
      <h1>Đăng ký biến động đất đai do chuyển nhượng</h1>
      <p>Số hiệu: 10/2024/TT-BTNMT</p>
      <p>Cơ quan thực hiện: Văn phòng đăng ký đất đai thành phố Đà Nẵng</p>
      <a href="/files/mau-09-dk.docx">Mẫu 09/ĐK</a>
      <a href="https://dichvucong.gov.vn/files/huong-dan.pdf">Hướng dẫn PDF</a>
    </body></html>`;
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(html, {
      status: 200,
      headers: { "content-type": "text/html; charset=utf-8" },
    })));

    const result = await analyzeLegalSourceUrl("https://dichvucong.gov.vn/thu-tuc/bien-dong");

    expect(result.sourceType).toBe("public_service");
    expect(result.sourceName).toBe("dichvucong.gov.vn");
    expect(result.title).toBe("Đăng ký biến động đất đai");
    expect(result.documentNumber).toBe("10/2024/TT-BTNMT");
    expect(result.receivingAuthority).toContain("Văn phòng đăng ký đất đai");
    expect(result.attachments).toEqual([
      expect.objectContaining({ format: "docx", fileName: "mau-09-dk.docx" }),
      expect.objectContaining({ format: "pdf", fileName: "huong-dan.pdf" }),
    ]);
  });

  it("searches by decree name/number and keeps only official domains", async () => {
    const html = `<a href="/url?q=https%3A%2F%2Fvanban.chinhphu.vn%2F%3Fdoc%3D102%26x%3D1"><h3>Nghị định 102/2024/NĐ-CP về quy định chi tiết</h3></a><a href="/url?q=https%3A%2F%2Fexample.com%2Ffake"><h3>Nguồn không chính thức</h3></a>`;
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(html, { status: 200, headers: { "content-type": "text/html" } })));
    const result = await searchLegalDocuments("Nghị định 102");
    expect(result).toHaveLength(1);
    expect(result[0]).toEqual(expect.objectContaining({ documentNumber: "102/2024/NĐ-CP", sourceName: "vanban.chinhphu.vn", isOfficialDomain: true }));
  });

  it("returns official seed sources when the search page is unavailable", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("network")));
    const result = await searchLegalDocuments("102/2024/NĐ-CP");
    expect(result.length).toBeGreaterThan(0);
    expect(result.every(item => item.isOfficialDomain)).toBe(true);
    expect(result[0].warning).toContain("Chưa lấy được kết quả chi tiết");
  });

  it("normalizes the 101/2024 decree typo and returns the verified government source", async () => {
    const result = await searchLegalDocuments("Nghị định 101/2024/NĐ-CI");
    expect(result).toHaveLength(1);
    expect(result[0]).toEqual(expect.objectContaining({
      documentNumber: "101/2024/NĐ-CP",
      url: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791",
      sourceName: "vanban.chinhphu.vn",
      isOfficialDomain: true,
    }));
    expect(result[0].warning).toContain("Đã chuẩn hóa");
  });

  it("accepts an unpunctuated 101/2024 query and keeps official provenance", async () => {
    const result = await searchLegalDocuments("101 2024 ND CP");
    expect(result[0]).toEqual(expect.objectContaining({ documentNumber: "101/2024/NĐ-CP", isOfficialDomain: true }));
  });

  it("returns a direct PDF attachment and provenance warning", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(new Uint8Array([37, 80, 68, 70]), {
      status: 200,
      headers: { "content-type": "application/pdf" },
    })));

    const result = await analyzeLegalSourceUrl("https://vanban.chinhphu.vn/files/thong-tu-10.pdf");

    expect(result.attachments[0]).toEqual(expect.objectContaining({ format: "pdf", fileName: "thong-tu-10.pdf" }));
    expect(result.warnings.join(" ")).toContain("URL là tệp PDF");
  });
});


describe("legal document status enrichment", () => {
  it("detects candidate effective status, amendments and related documents without asserting official validity", async () => {
    const html = `<!doctype html><html><head><title>Nghị định 102/2024/NĐ-CP</title></head><body>
      <p>Nghị định có hiệu lực từ ngày 01/08/2024 và hiện hành.</p>
      <p>Văn bản sửa đổi, bổ sung Nghị định 01/2023/NĐ-CP.</p>
    </body></html>`;
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(html, {
      status: 200,
      headers: { "content-type": "text/html; charset=utf-8" },
    })));

    const result = await analyzeLegalSourceUrl("https://vanban.chinhphu.vn/nghi-dinh-102");

    expect(result.effectiveStatus).toBe("in_force_candidate");
    expect(result.versionStatus).toBe("amended_candidate");
    expect(result.relatedDocumentMentions).toContain("01/2023/NĐ-CP");
    expect(result.warnings.join(" ")).toContain("Chưa phát hiện liên kết DOCX/PDF");
  });
});
