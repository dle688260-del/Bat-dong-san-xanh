CREATE TABLE `land_dossier_steps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`dossierId` int NOT NULL,
	`stepNumber` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`status` enum('completed','in_progress','not_started','needs_review') NOT NULL DEFAULT 'not_started',
	`checklist` text NOT NULL,
	`relatedTemplates` text,
	`notes` text,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `land_dossier_steps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `land_dossiers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`dossierCode` varchar(40) NOT NULL,
	`procedureType` varchar(120) NOT NULL,
	`title` varchar(255) NOT NULL,
	`status` enum('draft','in_progress','completed','paused') NOT NULL DEFAULT 'draft',
	`currentStep` int NOT NULL DEFAULT 1,
	`answers` text,
	`notes` text,
	`createdBy` int NOT NULL,
	`propertyId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `land_dossiers_id` PRIMARY KEY(`id`),
	CONSTRAINT `land_dossiers_dossierCode_unique` UNIQUE(`dossierCode`)
);
--> statement-breakpoint
ALTER TABLE `land_dossier_steps` ADD CONSTRAINT `land_dossier_steps_dossierId_land_dossiers_id_fk` FOREIGN KEY (`dossierId`) REFERENCES `land_dossiers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `land_dossiers` ADD CONSTRAINT `land_dossiers_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `land_dossiers` ADD CONSTRAINT `land_dossiers_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;