import { describe, expect, it } from "vitest";
import {
  buildAutoWorkflow,
  buildCategories,
  classifyProcedure,
  filterProcedures,
  getProcedureInputSchema,
  mapUploadTarget,
  type AutoProcedure,
} from "./autoDossierEngine";

describe("AI auto dossier engine", () => {
  const procedures: AutoProcedure[] = [
    { code: "1.012789", title: "Đăng ký biến động đất đai do chuyển nhượng", description: "Hồ sơ chuyển nhượng", source: "DVC quốc gia" },
    { code: "2.000889", title: "Cấp đổi Giấy chứng nhận", description: "Cấp đổi sổ", source: "DVC quốc gia" },
  ];

  it("classifies and normalizes procedure categories independently", () => {
    expect(classifyProcedure(procedures[0])).toBe("Giao dịch bất động sản");
    expect(classifyProcedure(procedures[1])).toBe("Cấp Giấy chứng nhận");
    expect(buildCategories(procedures)).toEqual(expect.arrayContaining([
      { category: "Tất cả", count: 2 },
      { category: "Giao dịch bất động sản", count: 1 },
    ]));
  });

  it("filters by Vietnamese query and category without hard-coded procedure lists", () => {
    expect(filterProcedures(procedures, "chuyển nhượng", "Tất cả").map(item => item.code)).toEqual(["1.012789"]);
    expect(filterProcedures(procedures, "", "Cấp Giấy chứng nhận").map(item => item.code)).toEqual(["2.000889"]);
  });

  it("matches accent-free queries, common abbreviations, typos, and exact codes", () => {
    const searchProcedures: AutoProcedure[] = [
      { code: "1.013978", title: "Đăng ký đất đai, cấp Giấy chứng nhận lần đầu", description: "Thủ tục đăng ký quyền sử dụng đất", source: "DVC" },
      { code: "2.000889", title: "Đăng ký biến động đất đai", description: "Chuyển nhượng quyền sử dụng đất", source: "DVC" },
      { code: "1.012789", title: "Cung cấp thông tin, dữ liệu đất đai", description: "Yêu cầu dữ liệu địa chính", source: "DVC" },
    ];
    expect(filterProcedures(searchProcedures, "dang ky lan dau", "Tất cả").map(item => item.code)).toEqual(["1.013978"]);
    expect(filterProcedures(searchProcedures, "DKDD", "Tất cả").map(item => item.code)).toContain("1.013978");
    expect(filterProcedures(searchProcedures, "GCN", "Tất cả").map(item => item.code)).toContain("1.013978");
    expect(filterProcedures(searchProcedures, "bien dộng", "Tất cả").map(item => item.code)).toContain("2.000889");
    expect(filterProcedures(searchProcedures, "2.000889", "Tất cả").map(item => item.code)).toEqual(["2.000889"]);
  });

  it("builds a procedure-specific workflow from official metadata and requirements", () => {
    const workflow = buildAutoWorkflow({
      procedureName: "Chuyển nhượng quyền sử dụng đất",
      requirements: [{ id: "dk09", label: "Đơn đăng ký biến động", source: "DVC quốc gia", status: "pending" }],
      dossierComponents: [{ name: "Hợp đồng chuyển nhượng" }],
    });
    expect(workflow[0].title).toContain("Tìm thủ tục");
    expect(workflow.some(step => step.title.includes("Đơn đăng ký biến động"))).toBe(true);
    expect(workflow.some(step => step.title === "Nhập hồ sơ dùng một lần")).toBe(true);
    expect(workflow.at(-1)?.title).toBe("Xuất DOCX/PDF");
  });

  it("preserves verified official steps when the source supplies them", () => {
    const workflow = buildAutoWorkflow({
      procedureName: "Thủ tục riêng",
      officialSteps: [{ id: "official-1", title: "Bước chính thức", description: "Nguồn DVC", requiresInput: false }],
    });
    expect(workflow).toEqual([{ id: "official-1", title: "Bước chính thức", description: "Nguồn DVC", requiresInput: false }]);
  });

  it("creates a different information schema for each selected procedure", () => {
    const dataRequest = getProcedureInputSchema("1.012789", "Cung cấp thông tin dữ liệu đất đai");
    const transfer = getProcedureInputSchema("2.000889", "Đăng ký biến động do chuyển nhượng");
    expect(dataRequest.map(field => field.key)).toContain("requestedData");
    expect(dataRequest.map(field => field.key)).not.toContain("transferor");
    expect(transfer.map(field => field.key)).toEqual(expect.arrayContaining(["transferor", "transferee", "transactionType"]));
    expect(transfer.find(field => field.key === "transactionType")?.options).toContain("Chuyển nhượng");
  });

  it("maps camera or uploaded files to the selected dossier component without changing verification", () => {
    expect(mapUploadTarget("component-contract", "Hợp đồng chuyển nhượng", "camera-001.jpg")).toEqual({
      componentId: "component-contract",
      componentName: "Hợp đồng chuyển nhượng",
      fileName: "camera-001.jpg",
    });
    expect(mapUploadTarget(undefined, undefined, "bo-sung.pdf").componentId).toBe("general");
  });
});
