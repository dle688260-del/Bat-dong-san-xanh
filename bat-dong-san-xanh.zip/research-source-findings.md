# Biên bản rà soát nguồn đất đai

## 2026-08-21

Cổng Thông tin điện tử Chính phủ tại https://chinhphu.vn/he-thong-van-ban là hệ thống tra cứu văn bản chính thức, có lĩnh vực “Đất đai - Nhà ở”, “Thủ tục hành chính”, “Luật” và mục cơ quan ban hành. Đây là URL discovery cấp trung ương, không phải URL binary mẫu của từng thủ tục.

Trang Luật Đất đai được kết quả tìm kiếm xác định tại https://chinhphu.vn/?pageid=27160&docid=211189&classid=1&typegroupid=3. Cổng DVC Quốc gia có các URL thủ tục đã thấy trong registry, gồm các mã 1.013978, 1.012783, 1.012789 và 2.000410. Cổng DVC Bộ tại https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 đã được xác định là nguồn thủ tục cấp Bộ; URL discovery không tự động được coi là file Official.

Nguyên tắc tích hợp: URL cổng, trang cơ quan, trang văn bản và danh mục chỉ được dùng cho discovery/legal provenance. Chỉ binary tải được từ miền cho phép, đúng định dạng, có provenance phù hợp và SHA-256 mới được gắn Official Template File. Các cổng tỉnh, văn phòng đăng ký đất đai và chi nhánh sẽ được đăng ký theo URL đã xác minh; không tự sinh hàng loạt domain hoặc đường dẫn phường/xã chưa được kiểm tra.

## Tham khảo

1. [Hệ thống văn bản Chính phủ](https://chinhphu.vn/he-thong-van-ban)
2. [Luật số 31/2024/QH15 — Luật Đất đai](https://chinhphu.vn/?pageid=27160&docid=211189&classid=1&typegroupid=3)
3. [Cổng DVC Bộ — Cung cấp thông tin, dữ liệu đất đai](https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67)

## Xác minh bổ sung

Trang Cổng DVC Bộ tại https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 hiển thị thủ tục “Cung cấp thông tin, dữ liệu đất đai”, phần “Văn bản mẫu” có ba mục tải về: Phiếu yêu cầu, Hợp đồng và Văn bản/phiếu yêu cầu cung cấp dữ liệu đất đai. Trang cũng nêu các Mẫu 13/ĐK, 13a/ĐK, 13b/ĐK, 13c/ĐK, 13d/ĐK và 13đ/ĐK theo Nghị định 101/2024/NĐ-CP, cùng căn cứ Luật Đất đai 31/2024/QH15 và Quyết định 2124/QĐ-BTNMT. Đây là nguồn có giá trị discovery và có thể là nguồn binary khi endpoint tải trả về đúng file; trang HTML tự thân không phải binary Official.

Cục Quản lý đất đai thuộc Bộ tại https://qldd.mae.gov.vn/danh-sach-van-ban.htm có danh mục văn bản quy phạm với lĩnh vực Đất đai, loại văn bản gồm Luật, Nghị định, Thông tư, Quyết định và Văn bản hợp nhất, cùng bộ lọc cơ quan ban hành. Đây là nguồn legal-document discovery cấp Bộ; cần lấy từng URL văn bản cụ thể trước khi ghi nhận vào registry.

Cổng DVC Quốc gia có thể bị ERR_BLOCKED_BY_CLIENT/ERR_TUNNEL_CONNECTION_FAILED trong môi trường quét hiện tại, nên không được coi lỗi truy cập là bằng chứng nguồn bị thiếu. Hệ thống nên giữ URL DVC Quốc gia làm tier national và chuyển sang Cổng Bộ, Cổng Chính phủ, Cục Quản lý đất đai và nguồn địa phương đã xác minh.
