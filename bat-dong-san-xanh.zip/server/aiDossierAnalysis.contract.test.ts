import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("AI dossier analysis contract", () => {
  const routerSource = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
  const pageSource = readFileSync(resolve(process.cwd(), "client/src/pages/AiLandDossierAutoModule.tsx"), "utf8");

  it("uses the canonical legal bundle and rejects unverified templates from Official context", () => {
    expect(routerSource).toContain("analyzeDossier: protectedProcedure");
    expect(routerSource).toContain("getLegalProcedureBundle(input.procedureCode)");
    expect(routerSource).toContain('item.provenance === "verified_binary" || item.provenance === "official"');
    expect(routerSource).toContain("Boolean(item.storageKey || item.fileUrl)");
    expect(routerSource).toContain("Boolean(item.checksum)");
    expect(routerSource).toContain("legalSources");
    expect(routerSource).toContain("legalDocuments");
    expect(routerSource).toContain("templates:");
    expect(routerSource).toContain("sourceCounts");
    expect(routerSource).toContain("contentText: item.contentText?.slice(0, 30000)");
  });

  it("normalizes oversized component names without discarding the source name", () => {
    expect(routerSource).toContain("dossierComponentForAnalysisSchema = z.preprocess");
    expect(routerSource).toContain("sourceName: originalName");
    expect(routerSource).toContain("name: z.string().trim().min(1).max(240)");
    expect(routerSource).toContain("dossierComponents: z.array(dossierComponentForAnalysisSchema)");
  });

  it("requires evidence and explicit confirmation for every AI suggestion", () => {
    expect(routerSource).toContain('needsConfirmation: { type: "boolean" }');
    expect(routerSource).toContain('source: { type: "string", enum: ["profile", "ocr", "missing"] }');
    expect(routerSource).toContain("Mọi trường đề xuất phải có source là profile, ocr hoặc missing và needsConfirmation=true");
    expect(pageSource).toContain("confirmed: false");
    expect(pageSource).toContain("AI phân tích & điền nháp");
  });

  it("keeps export locked until required profile fields and OCR/AI fields are confirmed", () => {
    expect(pageSource).toContain("requiredInputComplete");
    expect(pageSource).toContain("!allConfirmed || !requiredInputComplete");
    expect(pageSource).toContain("Cần xác nhận tất cả trường OCR/AI trước khi xuất.");
    expect(pageSource).toContain("canAdvanceFromDossierStage");
    expect(pageSource).toContain("fileCount: files.length");
    expect(pageSource).toContain("Hãy chụp hoặc tải lên ít nhất một giấy tờ trong phần Điền thông tin");
    expect(pageSource).toContain("templateSource: getSafeTemplateSource");
    expect(pageSource).toContain("const DEFAULT_TEMPLATE_SOURCE = \"https://dichvucong.gov.vn\"");
    expect(pageSource).toContain("(stage === \"profile\" || stage === \"upload\")");
  });

  it("keeps the procedure catalog stable when a province is selected", () => {
    expect(pageSource).toContain("const officialSearch = trpc.aiAutoDossier.catalog.useQuery({});");
    expect(pageSource).toContain("province chỉ áp dụng sau khi đã chọn mã");
    expect(pageSource).toContain("procedureCode: selectedCode, province: province || undefined");
  });
});
