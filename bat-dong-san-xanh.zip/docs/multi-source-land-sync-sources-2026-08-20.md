# Nguồn đồng bộ đa nguồn đất đai — 2026-08-20

## Nguồn chính thức

- Nghị định 101/2024/NĐ-CP — Cổng Thông tin điện tử Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=210791
- Văn bản hợp nhất 83/VBHN-BNNMT (09/12/2025), hợp nhất nội dung Nghị định 101, 151, 226 và các nội dung liên quan — Bộ Nông nghiệp và Môi trường: https://mae.gov.vn/Pages/chitietvanban.aspx?ItemID=692
- File PDF đính kèm từ Bộ Nông nghiệp và Môi trường: https://mae.gov.vn/noidung/Lists/VBQPPL/Attachments/692/83-VBHN-BNNMT%20Hop%20nhat%20ND%20101%20-%20151%20-%20226%20-%20RS%2028.10%20-%20trinh%20L2%20-%20Format_251209105641__09122025110237_signed.pdf

## Nguồn mẫu tham khảo công khai

- Mẫu số 14 — Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai (DOC): https://cdn.thuvienphapluat.vn/uploads/khoinghiep/2025/06/27/mau-so-14.doc
- Mẫu số 14 liên quan Nghị định 151 (DOCX): https://cdn.thuviennhadat.vn/upload/hinh-anh-bai-viet/TTTP/Thang-6-2025/MS-14-nd-151.docx

## Kết quả kiểm tra

- Trang Bộ Nông nghiệp và Môi trường trả về metadata văn bản và URL file PDF đính kèm rõ ràng.
- File DOC Mẫu số 14 trả về nội dung Word hợp lệ, có tiêu đề “Mẫu số 14. Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai”; đây là nguồn công khai ngoài miền cơ quan nhà nước nên chỉ được dùng làm Reference.
- URL DOCX Mẫu số 14 liên quan Nghị định 151 không trích xuất được nội dung qua trình đọc web; cần tải binary bằng fetcher, kiểm tra chữ ký/định dạng và SHA-256 trước khi lưu S3.
- Không được suy ra rằng mọi nghị định đều chứa file mẫu riêng. Nghị định có thể là legal basis; chỉ phụ lục/mẫu có mã khớp thành phần thủ tục mới được ghép thành Reference.

## Các URL chính thức bổ sung đã xác nhận qua tra cứu

- Nghị định 102/2024/NĐ-CP — Cổng Thông tin điện tử Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=210795
- Nghị định 103/2024/NĐ-CP — Cổng Thông tin điện tử Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=210797
- Nghị định 96/2024/NĐ-CP — Cổng Thông tin điện tử Chính phủ; văn bản này quy định chi tiết Luật Kinh doanh bất động sản, chỉ gắn cho workflow có liên quan kinh doanh BĐS, không gắn mặc định cho mọi thủ tục đất đai: https://vanban.chinhphu.vn/?pageid=27160&docid=210798&classid=1
- Nghị định 151/2025/NĐ-CP — cần tiếp tục xác nhận URL chính thức riêng trước khi ghi vào registry; không dùng URL bên thứ ba thay cho nguồn Chính phủ.

## Quy tắc phạm vi

Nghị định 101 và 102 là căn cứ trực tiếp cho nhiều thủ tục đăng ký/đất đai; Nghị định 103 dùng cho nghĩa vụ tài chính về tiền sử dụng đất, tiền thuê đất; Nghị định 96 chỉ áp dụng cho quy trình kinh doanh bất động sản. Các văn bản được lưu như legal basis, không tự biến thành file mẫu. Chỉ phụ lục hoặc file có mã/tên mẫu khớp thành phần hồ sơ mới được ghép Reference.

## Ứng viên mẫu công khai đã kiểm tra

- Mẫu 09/ĐK: https://cdn.thuvienphapluat.vn/uploads/DanLuat-BanAn/mau-09-dk.doc — tải được, nhận diện là đơn đăng ký biến động đất đai; nguồn công khai ngoài cơ quan nhà nước, chỉ Reference.
- Mẫu 10/ĐK: https://motcua.haiduong.gov.vn/public_dir/HAI_DUONG/giayto/2017_05/1494788949_Mau_so_10-DK_-_Don_de_nghi_cap_lai_Giay_chung_nhan.doc — URL cổng địa phương; cần runtime fetch và kiểm tra signature/content trước khi ghép, chỉ Reference.
- Mẫu 18: https://cdn.thuvienphapluat.vn/uploads/khoinghiep/2025/07/09/mau-so-18.doc — tải được, nhận diện là Mẫu số 18 về đăng ký biến động; nguồn ngoài cơ quan nhà nước, chỉ Reference.
- Mẫu 18 DOCX: https://cdn.thuviennhadat.vn/upload/hinh-anh-bai-viet/TTMN/thang-6-2025/18-6-2025/mau-so-18.docx — ứng viên DOCX cần runtime fetch/checksum trước khi ghép, chỉ Reference.

Các URL trên không được tự động nâng thành Official. Chỉ binary lấy từ nguồn nhà nước đủ provenance, chữ ký định dạng, checksum và kiểm tra nội dung mới có thể vào Official Nhà nước.
