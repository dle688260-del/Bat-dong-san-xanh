import fs from "node:fs";

const path = "client/src/pages/Home.tsx";
let source = fs.readFileSync(path, "utf8");
const start = source.indexOf('      <section id="noi-bat"');
const endMarker = '\n\n      <section id="dich-vu"';
const end = source.indexOf(endMarker, start);
if (start < 0 || end < 0) throw new Error("Featured section marker not found");
const replacement = `      <FeaturedPropertySection state={featuredState} properties={featuredProperties.data || []} />`;
source = source.slice(0, start) + replacement + source.slice(end);
const marker = "export default function Home() {";
const component = `type FeaturedProperty = { id: number; slug: string; title: string; location: string; price: string; area: string; propertyType: "house" | "land" | "apartment" | "villa" };

export function FeaturedPropertySection({ state, properties }: { state: "loading" | "items" | "empty"; properties: FeaturedProperty[] }) {
  return <section id="noi-bat" className="bg-[#18352D] px-6 py-24 text-white lg:px-10 lg:py-32"><div className="mx-auto max-w-[1320px]"><div className="flex flex-col justify-between gap-6 md:flex-row md:items-end"><div><p className="section-kicker text-[#E6C478]"><span className="bg-[#E6C478]" /> Nguồn hàng nổi bật</p><h2 className="mt-6 max-w-2xl font-serif text-5xl leading-[.98] tracking-[-.05em] sm:text-6xl">Những lựa chọn<br /><em className="font-normal text-[#E6C478]">đáng để xem.</em></h2></div><a href="/bat-dong-san" className="inline-flex items-center gap-2 text-sm font-bold text-[#E6C478]">Xem toàn bộ nguồn hàng <ArrowUpRight size={16} /></a></div>{state === "loading" ? <div data-testid="featured-loading" className="mt-12 rounded-2xl bg-white/10 p-10 text-center text-white/70">Đang tải nguồn hàng...</div> : state === "items" ? <div data-testid="featured-items" className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{properties.map(property => <a key={property.id} href={"/bat-dong-san/" + property.slug} className="group overflow-hidden rounded-2xl bg-[#F5F2EA] text-[#18352D] transition hover:-translate-y-1"><div className="h-44 bg-[#1F5A4A] p-5"><span className="rounded-full bg-[#E6C478] px-3 py-1 text-xs font-bold">{property.propertyType === "land" ? "Đất" : property.propertyType === "house" ? "Nhà" : property.propertyType === "villa" ? "Villa" : "Căn hộ"}</span></div><div className="p-5"><p className="text-sm text-[#60766D]">{property.location}</p><h3 className="mt-2 font-serif text-2xl leading-tight">{property.title}</h3><div className="mt-5 flex items-end justify-between"><strong className="text-[#1F5A4A]">{property.price} tỷ</strong><span className="text-sm text-[#60766D]">{property.area} m²</span></div></div></a>)}</div> : <div data-testid="featured-empty" className="mt-12 rounded-2xl border border-white/15 bg-white/5 p-10 text-center"><p className="font-serif text-3xl">Nguồn hàng nổi bật đang được cập nhật.</p><p className="mx-auto mt-3 max-w-md text-sm leading-6 text-white/65">Khi sàn công khai các sản phẩm được đánh dấu nổi bật, danh sách sẽ tự động xuất hiện tại đây.</p><a href="/bat-dong-san" className="mt-6 inline-flex rounded-full bg-[#E6C478] px-5 py-3 text-sm font-bold text-[#18352D]">Khám phá danh mục</a></div>}</div></section>;
}

`;
source = source.replace(marker, component + marker);
fs.writeFileSync(path, source);
