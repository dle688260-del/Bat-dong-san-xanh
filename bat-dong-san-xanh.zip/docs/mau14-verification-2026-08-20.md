# Xác minh mau-so-14.doc — 2026-08-20

Tệp người dùng gửi: `/home/ubuntu/upload/mau-so-14.doc`.

| Trường | Kết quả |
|---|---|
| Định dạng | Microsoft Compound Document File V2 (`.doc`) |
| Kích thước | 41,472 bytes |
| SHA-256 | `308c0deaa8bf45faef1b6a98175155fc3ee392b0d22fab9f6f76c8c966b5a00d` |
| Số trang | 2 |
| Số từ | 345 |
| Tiêu đề | Mẫu số 14. Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai |
| Ngày lưu cuối | 27/06/2025 |

Nội dung trích xuất xác định đây là “Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai”, có các trường tên tổ chức/cá nhân, CCCD/hộ chiếu, địa chỉ, nội dung dữ liệu cần cung cấp, mục đích sử dụng và phương thức nhận kết quả. Đây là mẫu phù hợp với thủ tục DVC mã `1.012789` — “Cung cấp thông tin, dữ liệu đất đai”.

Tệp đọc được bằng antiword và chưa được đánh dấu Official chỉ từ tệp người dùng gửi. Cần lưu provenance URL DVC và kiểm tra byte nguồn DVC tương ứng trước khi chuyển trạng thái Official Template File.

## Storage

Tệp đã được đưa vào storage dùng chung tại `/manus-storage/mau-so-14_dbc898bb.doc`. Đây là tệp người dùng cung cấp để đối chiếu; trạng thái Official vẫn phụ thuộc vào xác minh URL/byte nguồn DVC tương ứng.
