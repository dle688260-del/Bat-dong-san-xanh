import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("application dossier route aliases", () => {
  const source = readFileSync(
    resolve(process.cwd(), "client/src/App.tsx"),
    "utf8"
  );

  it("maps the common land dossier path to the land dossier builder", () => {
    expect(source).toContain(
      '<Route path="/ai-ho-so-dat-dai" component={LandDossierBuilder} />'
    );
  });

  it("maps pipeline and automatic aliases to the shared three-part builder", () => {
    expect(source).toContain('path="/ai-land-dossier-pipeline"');
    expect(source).toContain("component={LandDossierBuilder}");
    expect(source).toContain('path="/ai-ho-so-tu-dong"');
    expect(source).toContain('path="/ai-ho-so-dat-dai-tu-dong-moi"');
    expect(source).toContain('path="/ai-ho-so-dat-dai-ai-moi"');
  });

  it("loads internal CRM and AI screens on demand", () => {
    expect(source).toContain(
      'const BrokerageAdmin = lazy(() => import("./pages/BrokerageAdmin"));'
    );
    expect(source).toContain(
      'const AIDossierAdmin = lazy(() => import("./pages/AIDossierAdmin"));'
    );
    expect(source).toContain("<Suspense fallback={<AdminRouteFallback />}>");
    expect(source).not.toContain(
      'import BrokerageAdmin from "./pages/BrokerageAdmin"'
    );
  });

  it("exposes dedicated CRM entry and legacy dossier aliases without changing the storefront root", () => {
    expect(source).toContain(
      '{mode === "crm" && <Route path="/" component={CrmDashboard} />}'
    );
    expect(source).toContain('<Route path="/crm" component={CrmDashboard} />');
    expect(source).toContain("const normalizedPathname =");
    expect(source).toContain("window.location.pathname.replace");
    expect(source).toContain('normalizedPathname === "/crm"');
    expect(source).toContain('normalizedPathname.startsWith("/crm/")');
    expect(source).toContain(
      '<Route path="/crm/login" component={AdminLogin} />'
    );
    expect(source).toContain(
      '<Route path="/dang-nhap-quan-tri" component={AdminLogin} />'
    );
    expect(source).toContain(
      '<Route path="/crm/ai-san-xuat" component={AIDossierAdmin} />'
    );
    expect(source).toContain(
      '<Route path="/hs-dat-dai-ai" component={AIDossierAdmin} />'
    );
  });
});

export {};
