import fs from "node:fs";
const source = fs.readFileSync("client/src/pages/LandDossierBuilder.tsx", "utf8");
const keys = ["province:", "receiving", "authority", "autoDiscoverDvcBinaryCandidates", "setForm", "formData"];
for (const key of keys) {
  let start = 0;
  let count = 0;
  while (count < 6) {
    const index = source.indexOf(key, start);
    if (index < 0) break;
    console.log(`\n--- ${key} @ ${index} ---\n${source.slice(Math.max(0, index - 420), index + 1200)}`);
    start = index + key.length;
    count += 1;
  }
}
