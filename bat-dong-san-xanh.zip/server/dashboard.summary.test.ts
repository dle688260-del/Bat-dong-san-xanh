import { describe, expect, it } from "vitest";
import { getDashboardSummary } from "./db";
import { appRouter } from "./routers";

describe("Dashboard summary contract", () => {
  it("exposes the database aggregation helper", () => {
    expect(typeof getDashboardSummary).toBe("function");
  });

  it("registers the protected dashboard summary procedure", () => {
    const record = (appRouter._def as unknown as { record: Record<string, { summary?: unknown }> }).record;
    expect(record.dashboard?.summary).toBeDefined();
  });

  it("registers public chat and protected call preparation procedures", () => {
    const record = (appRouter._def as unknown as { record: Record<string, { chat?: unknown; prepareCall?: unknown }> }).record;
    expect(record.ai?.chat).toBeDefined();
    expect(record.ai?.prepareCall).toBeDefined();
  });
});
