import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  diverseSupplyCategories,
  ALL_SUPPLY_PATH,
  LAND_SUPPLY_CHILDREN,
  FEATURED_GRID_CLASS,
  getCategoryScrollDistance,
  getNextCategoryScrollLeft,
  shouldUseCustomCategoryDrag,
  groupSupplyCategories,
  filterFeaturedProperties,
  getSupplyCategoryCount,
  getFeaturedState,
  FEATURED_REQUEST_TIMEOUT_MS,
  scoreSupplyDemand,
  type FeaturedProperty,
  type SupplyDemand,
} from "./Home";

const homeSource = readFileSync(new URL("./Home.tsx", import.meta.url), "utf8");

const properties: FeaturedProperty[] = [
  {
    id: 1,
    title: "Nhà phố Thanh Khê",
    propertyType: "house",
    price: 7.9,
    area: 95,
    location: "Đà Nẵng",
    publishedAt: "2026-08-15",
  },
  {
    id: 2,
    title: "Căn hộ ven sông",
    propertyType: "apartment",
    price: 3.2,
    area: 72,
    location: "Đà Nẵng",
    publishedAt: "2026-08-15",
  },
  {
    id: 3,
    title: "Đất nền Hội An",
    propertyType: "land",
    price: 3.2,
    area: 100,
    location: "Quảng Nam",
    publishedAt: "2026-08-15",
  },
  {
    id: 5,
    title: "Đất nông nghiệp Hội An",
    propertyType: "land",
    price: 1.8,
    area: 600,
    location: "Quảng Nam",
    publishedAt: "2026-08-15",
  },
  {
    id: 4,
    title: "Villa nghỉ dưỡng biển",
    propertyType: "villa",
    price: 12,
    area: 180,
    location: "Đà Nẵng",
    publishedAt: "2026-08-15",
  },
];

describe("AI demand matching", () => {
  it("ranks a property higher when it matches type, location, budget and area", () => {
    const demand: SupplyDemand = {
      propertyType: "Nhà",
      location: "Thanh Khê",
      minBudget: "6",
      maxBudget: "8",
      minArea: "80",
      maxArea: "110",
      purpose: "Ở",
      bedrooms: "",
      legal: "",
      specialRequirements: "",
      priority: "Cao",
    };
    const ranked = scoreSupplyDemand(
      [
        { ...properties[0], location: "Thanh Khê, Đà Nẵng" },
        ...properties.slice(1),
      ],
      demand
    );
    expect(ranked[0].id).toBe(1);
    expect(ranked[0].matchScore).toBeGreaterThan(ranked[1].matchScore);
    expect(ranked[0].matchReasons).toEqual(
      expect.arrayContaining([
        "Đúng loại BĐS",
        "Đúng khu vực",
        "Trong ngân sách",
        "Đúng diện tích",
      ])
    );
  });

  it("keeps fallback results when optional filters are empty", () => {
    const demand: SupplyDemand = {
      propertyType: "",
      location: "",
      minBudget: "",
      maxBudget: "",
      minArea: "",
      maxArea: "",
      purpose: "Đầu tư",
      bedrooms: "",
      legal: "",
      specialRequirements: "",
      priority: "Vừa",
    };
    expect(scoreSupplyDemand(properties, demand)).toHaveLength(
      properties.length
    );
  });
});

describe("featured loading state", () => {
  it("uses returned published properties instead of the showcase fallback", () => {
    expect(getFeaturedState(properties, false, false)).toBe("items");
    expect(homeSource).toContain('state === "items"');
    expect(homeSource).toContain("items={properties}");
    expect(homeSource).not.toContain("showcaseListings.map");
    expect(homeSource).not.toContain("MẪU THAM KHẢO");
  });

  it("defers below-the-fold images and decodes them asynchronously", () => {
    expect(homeSource).toContain('loading="lazy"');
    expect(homeSource).toContain('decoding="async"');
    expect(homeSource).toContain('fetchPriority="low"');
  });

  it("offers image retry and expands a single published card on desktop", () => {
    expect(homeSource).toContain("Tải lại ảnh");
    expect(homeSource).toContain("properties.length === 1");
    expect(homeSource).toContain("max-w-[1120px]");
  });

  it("keeps category selection separate from the property feed", () => {
    expect(homeSource).toContain('data-testid="featured-category-panel"');
    expect(homeSource).toContain('data-testid="featured-listings-panel"');
    expect(homeSource).toContain("01 · Chọn nhóm nguồn hàng");
    expect(homeSource).toContain("02 · Bài đăng đang hiển thị");
  });

  it("does not hide returned data behind the initial loader during refetch", () => {
    expect(getFeaturedState(properties, true, false)).toBe("items");
    expect(getFeaturedState([], true, false)).toBe("empty");
    expect(getFeaturedState(undefined, true, false)).toBe("loading");
    expect(getFeaturedState(undefined, false, true)).toBe("empty");
  });
});

describe("featured request timeout", () => {
  it("uses a bounded timeout for unresolved featured requests", () => {
    expect(FEATURED_REQUEST_TIMEOUT_MS).toBe(1_500);
  });
});

describe("featured responsive layout", () => {
  it("uses one column on mobile, two on tablet and four on desktop", () => {
    expect(FEATURED_GRID_CLASS).toBe(
      "grid-cols-1 md:grid-cols-2 xl:grid-cols-4"
    );
  });

  it("keeps the category strip step and supports a next-only control", () => {
    expect(getCategoryScrollDistance(390, 1)).toBeCloseTo(319.8);
    expect(getCategoryScrollDistance(390, -1)).toBeCloseTo(-319.8);
    expect(getCategoryScrollDistance(100, 1)).toBe(260);
    expect(getNextCategoryScrollLeft(0, 320, 960)).toBe(320);
    expect(getNextCategoryScrollLeft(900, 320, 960)).toBe(960);
  });

  it("uses native momentum for touch and custom drag only for mouse", () => {
    expect(shouldUseCustomCategoryDrag("touch")).toBe(false);
    expect(shouldUseCustomCategoryDrag("pen")).toBe(false);
    expect(shouldUseCustomCategoryDrag("mouse")).toBe(true);
  });

  it("keeps one category per compact horizontal card", () => {
    const groups = groupSupplyCategories([
      "Nhà phố",
      "Căn hộ",
      "Đất nền",
      "Villa",
      "Resort",
    ]);
    expect(groups).toEqual([
      ["Nhà phố"],
      ["Căn hộ"],
      ["Đất nền"],
      ["Villa"],
      ["Resort"],
    ]);
  });

  it("keeps the view-all action on the public catalog route", () => {
    expect(ALL_SUPPLY_PATH).toBe("/bat-dong-san");
  });
});

describe("filterFeaturedProperties", () => {
  it("returns all properties when no category is selected", () => {
    expect(filterFeaturedProperties(properties, null)).toEqual(properties);
  });

  it("filters by the selected supply category", () => {
    expect(
      filterFeaturedProperties(properties, "Nhà phố").map(item => item.id)
    ).toEqual([1]);
    expect(
      filterFeaturedProperties(properties, "Căn hộ").map(item => item.id)
    ).toEqual([2]);
    expect(
      filterFeaturedProperties(properties, "Đất nền").map(item => item.id)
    ).toEqual([3, 5]);
    expect(
      filterFeaturedProperties(properties, "Resort · Villa").map(
        item => item.id
      )
    ).toEqual([4]);
  });

  it("groups the land parent with its land-related child categories", () => {
    expect(LAND_SUPPLY_CHILDREN).toEqual([
      "Đất nền",
      "Đất nông nghiệp",
      "Đất khu công nghiệp",
      "Đất dự án",
    ]);
    expect(
      filterFeaturedProperties(properties, "Đất nông nghiệp").map(
        item => item.id
      )
    ).toEqual([5]);
  });

  it("counts posts for each category from the same filter contract", () => {
    expect(getSupplyCategoryCount(properties, "Nhà phố")).toBe(1);
    expect(getSupplyCategoryCount(properties, "Căn hộ")).toBe(1);
    expect(getSupplyCategoryCount(properties, "Đất nền")).toBe(2);
    expect(getSupplyCategoryCount(properties, "Đất nông nghiệp")).toBe(1);
    expect(getSupplyCategoryCount(properties, "Resort · Villa")).toBe(1);
    expect(getSupplyCategoryCount(properties, "Cho thuê")).toBe(0);
  });

  it("assigns a distinct visual tone to every supply category", () => {
    const tones = diverseSupplyCategories.map(category => category.tone);
    expect(diverseSupplyCategories).toHaveLength(10);
    expect(new Set(tones).size).toBe(diverseSupplyCategories.length);
    expect(
      tones.every(tone => tone.includes("bg-[#") && tone.includes("border-[#"))
    ).toBe(true);
  });

  it("maps recognisable icons to the relevant property groups", () => {
    const iconNames = diverseSupplyCategories.map(
      category => category.icon.displayName || category.icon.name
    );
    expect(iconNames).toEqual([
      "House",
      "Building2",
      "LandPlot",
      "Sprout",
      "Factory",
      "Store",
      "Hotel",
      "Waves",
      "Compass",
      "KeyRound",
    ]);
  });
});
