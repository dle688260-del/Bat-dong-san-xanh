import { afterEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { assembleDvcProcedureBundle, confirmReferenceForPersonalUse, discoverDvcReceivingAuthorities, DVC_SOURCE_REGISTRY, getDvcSourcesForProcedure, mergeDvcReferenceBinaries, scanDvcProcedureSource } from "./dvcSourceRegistry";
import { getOfficialLandProcedure } from "./officialLandProcedureRegistry";

describe("DVC source scanner", () => {
  it("xác nhận thủ công file tham khảo cho mục đích cá nhân nhưng không nâng Official Nhà nước", () => {
    const scan = {
      sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789",
      checkedAt: "2026-08-20T00:00:00.000Z",
      fetched: true,
      receivingSection: "",
      processingSection: "",
      items: [],
      warnings: [],
      dossierComponents: [{ id: "c1", name: "Mẫu Mus14", required: true, description: "Biểu mẫu" }],
      attachments: [{
        id: "ref-mus14",
        name: "Mus14.docx",
        url: "https://example.com/Mus14.docx",
        kind: "docx" as const,
        sourceUrl: "https://example.com",
        checkedAt: "2026-08-20T00:00:00.000Z",
        status: "awaiting_manual_review" as const,
        evidence: "Đã đối chiếu đúng tên/mã mẫu",
        componentId: "c1",
        sourceLayer: "template_file" as const,
      }],
      procedureSteps: [],
    };
    const confirmed = confirmReferenceForPersonalUse(scan, "ref-mus14");
    const bundle = assembleDvcProcedureBundle(confirmed, "1.012789");
    expect(confirmed.attachments[0].status).toBe("confirmed_reference");
    expect(bundle.referenceTemplates).toHaveLength(1);
    expect(bundle.officialTemplates).toHaveLength(0);
  });
  afterEach(() => vi.restoreAllMocks());

  it("đăng ký đủ tier quốc gia, Bộ, tỉnh và Văn phòng đăng ký đất đai", () => {
    expect(DVC_SOURCE_REGISTRY.map(source => source.tier)).toEqual(expect.arrayContaining(["national_dvc", "ministry_monre", "provincial_dvc", "land_registry_office"]));
    expect(DVC_SOURCE_REGISTRY.find(source => source.id === "ministry-monre-land")?.sourceUrl).toBe("https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8");
    expect(DVC_SOURCE_REGISTRY.find(source => source.id === "ministry-monre-land")?.procedureUrls?.["2.002317"]).toContain("dv=67");
    expect(DVC_SOURCE_REGISTRY.filter(source => source.tier === "land_registry_office").every(source => source.discoveryOnly)).toBe(true);
  });

  it("đăng ký đúng các cổng DVC địa phương đã kiểm tra và lọc theo tỉnh", () => {
    expect(DVC_SOURCE_REGISTRY.map(source => source.id)).toEqual(expect.arrayContaining(["local-hanoi", "local-ho-chi-minh", "local-da-nang"]));
    const daNangSources = getDvcSourcesForProcedure({ procedureCode: "2.000889", province: "Đà Nẵng" });
    expect(daNangSources.map(source => source.id)).toContain("local-da-nang");
    expect(daNangSources.find(source => source.id === "local-da-nang")?.sourceUrl).toBe("https://hcc.danang.gov.vn");
    const hanoiSources = getDvcSourcesForProcedure({ procedureCode: "1.012789", province: "Hà Nội" });
    expect(hanoiSources.map(source => source.id)).toContain("local-hanoi");
    expect(getDvcSourcesForProcedure({ procedureCode: "1.012789" }).map(source => source.id)).not.toContain("local-hanoi");
  });

  it("tiếp tục thử nguồn Bộ/tỉnh khi DVC Quốc gia trả 503 và vẫn giữ cảnh báo", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      calls.push(url);
      if (url.includes("dichvucong.monre.gov.vn")) {
        return new Response("<h2>Thành phần hồ sơ</h2><p>Đơn đề nghị theo thủ tục 1.012789</p>", { status: 200, headers: { "content-type": "text/html" } });
      }
      return new Response("DVC unavailable", { status: 503 });
    }));
    const result = await scanDvcProcedureSource({ procedureCode: "1.012789", province: "Hà Nội" });
    expect(calls[0]).toContain("vpcp.dichvucong.gov.vn");
    expect(calls.some(url => url.includes("dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8"))).toBe(true);
    expect(result.fetched).toBe(true);
    expect(result.warnings.join(" ")).toContain("503");
    expect(result.attachments.every(file => file.status !== "verified_binary")).toBe(true);
  });

  it("discovery DOCX/PDF trong mục thành phần hồ sơ của DVC địa phương", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      calls.push(url);
      if (url.includes("dichvucong.hanoi.gov.vn")) {
        return new Response(`<h2>Thành phần hồ sơ</h2><ul><li>Đơn đề nghị tách thửa</li></ul><a href="/files/mau-tach-thua.docx">Mẫu đơn tách thửa</a><a href="/files/phu-luc.pdf">Phụ lục bản đồ</a><h2>Thời hạn giải quyết</h2>`, { status: 200, headers: { "content-type": "text/html" } });
      }
      return new Response("DVC unavailable", { status: 503 });
    }));

    const result = await scanDvcProcedureSource({ procedureCode: "1.012784", province: "Hà Nội" });
    expect(calls.some(url => url.includes("dichvucong.hanoi.gov.vn"))).toBe(true);
    expect(result.attachments).toEqual(expect.arrayContaining([
      expect.objectContaining({ url: "https://dichvucong.hanoi.gov.vn/files/mau-tach-thua.docx", kind: "docx" }),
      expect.objectContaining({ url: "https://dichvucong.hanoi.gov.vn/files/phu-luc.pdf", kind: "pdf" }),
    ]));
    expect(result.dossierComponents.length).toBeGreaterThan(0);
  });

  it("trích xuất cơ quan từ nội dung trang chính thức và giữ trạng thái cần xác nhận", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(`
      <h2>Trình tự thực hiện</h2>
      <p>Người sử dụng đất nộp hồ sơ tại Văn phòng đăng ký đất đai hoặc Chi nhánh Văn phòng đăng ký đất đai.</p>
      <h2>Cơ quan thực hiện</h2>
      <p>Văn phòng đăng ký đất đai</p>
      <h2>Yêu cầu, điều kiện thực hiện</h2>
    `, { status: 200, headers: { "content-type": "text/html" } })));

    const result = await discoverDvcReceivingAuthorities({ procedureCode: "2.000889", province: "Thành phố Đà Nẵng", district: "Hải Châu", ward: "Hải Châu" });
    expect(result.items.map(item => item.name)).toContain("Văn phòng đăng ký đất đai");
    expect(result.items.some(item => item.name.includes("Chi nhánh Văn phòng đăng ký đất đai"))).toBe(true);
    expect(result.items.every(item => item.requiresUserConfirmation)).toBe(true);
    expect(result.items.every(item => item.sourceUrl.includes("vpcp.dichvucong.gov.vn"))).toBe(true);
    expect(result.items.every(item => item.name !== "Chi nhánh Văn phòng đăng ký đất đai Hải Châu")).toBe(true);
  });

  it("trả cảnh báo khi nguồn không có tên cơ quan cụ thể thay vì suy đoán", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("<h1>Trang DVC</h1><p>Thông tin đang cập nhật</p>", { status: 200 })));
    const result = await scanDvcProcedureSource({ procedureCode: "1.012784", province: "Tỉnh X", district: "Huyện Y", ward: "Xã Z" });
    expect(result.items).toHaveLength(0);
    expect(result.warnings.join(" ")).toContain("Không trích xuất được cơ quan");
    expect(result.warnings.join(" ")).toContain("Cần mở/tra cứu thêm nguồn DVC địa phương");
  });

  it("không trả dữ liệu khi thiếu tỉnh/thành", async () => {
    const result = await discoverDvcReceivingAuthorities({ procedureCode: "1.012784" });
    expect(result.items).toHaveLength(0);
    expect(result.notice).toContain("Cần chọn tỉnh/thành");
  });
});

  it("đọc sâu phần Hướng dẫn làm hồ sơ, tự thử tải binary và nêu rõ lỗi xác minh", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(`
      <h2>Hướng dẫn làm hồ sơ</h2>
      <table>
        <tr><td>1.</td><td>Đơn đăng ký biến động đất đai, tài sản gắn liền với đất</td></tr>
        <tr><td>2.</td><td>Giấy chứng nhận quyền sử dụng đất (bản gốc)</td></tr>
        <tr><td>3.</td><td>Văn bản chuyển nhượng (nếu có)</td></tr>
      </table>
      <a data-url="/files/mau-09-dk.docx">Mẫu 09/ĐK</a>
      <a href="https://example.gov.vn/ignored.txt">Tài liệu khác</a>
      <script>window.files = { url: "https:\\/\\/vpcp.dichvucong.gov.vn\\/files\\/phu-luc.pdf" };</script>
      <h2>Thời hạn giải quyết</h2>
    `, { status: 200, headers: { "content-type": "text/html" } })));

    const result = await scanDvcProcedureSource({ procedureCode: "2.000889", province: "Thành phố Đà Nẵng" });
    expect(result.dossierComponents.map(item => item.name)).toEqual(expect.arrayContaining([
      "Đơn đăng ký biến động đất đai, tài sản gắn liền với đất",
      "Giấy chứng nhận quyền sử dụng đất (bản gốc)",
      "Văn bản chuyển nhượng (nếu có)",
    ]));
    expect(result.attachments).toEqual(expect.arrayContaining([
      expect.objectContaining({ url: "https://vpcp.dichvucong.gov.vn/files/mau-09-dk.docx", kind: "docx", status: "failed", verificationError: expect.any(String) }),
    ]));
    expect(result.attachments.every(item => item.status !== "pending")).toBe(true);
  });

  it("ghép binary vào đúng thành phần và giữ mục thiếu trong bundle", () => {
    const scan = {
      sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889",
      checkedAt: "2026-08-20T00:00:00.000Z",
      fetched: true,
      receivingSection: "",
      processingSection: "",
      items: [],
      warnings: [],
      dossierComponents: [
        { id: "c1", name: "Đơn đăng ký biến động", required: true, evidence: "DVC" },
        { id: "c2", name: "Giấy chứng nhận quyền sử dụng đất", required: true, evidence: "DVC" },
      ],
      attachments: [
        { id: "a1", name: "Mẫu đơn đăng ký biến động.docx", url: "https://vpcp.dichvucong.gov.vn/files/mau.docx", kind: "docx" as const, sourceUrl: "https://vpcp.dichvucong.gov.vn", checkedAt: "2026-08-20T00:00:00.000Z", status: "verified_binary" as const, evidence: "Đơn đăng ký biến động", componentId: "c1", checksum: "abc", fillable: true },
      ],
    };
    const bundle = assembleDvcProcedureBundle(scan, "2.000889");
    expect(bundle.readyCount).toBe(1);
    expect(bundle.totalCount).toBe(2);
    expect(bundle.components[0].attachments[0].status).toBe("verified_binary");
    expect(bundle.missingComponents).toEqual(["Giấy chứng nhận quyền sử dụng đất"]);
  });


it("merge binary reference đúng mẫu vào snapshot và giữ trạng thái chưa Official", () => {
  const scan = {
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789",
    checkedAt: "2026-08-20T00:00:00.000Z",
    fetched: true,
    receivingSection: "",
    processingSection: "",
    items: [],
    warnings: [],
    dossierComponents: [{ id: "c1", name: "Mẫu số 14 - Phiếu yêu cầu cung cấp thông tin đất đai", required: true, evidence: "DVC" }],
    attachments: [],
  };
  const merged = mergeDvcReferenceBinaries(scan, [{ name: "Mẫu số 14.doc", url: "https://example.org/mau-so-14.doc", kind: "docx", sourceUrl: "https://example.org", checksum: "308c0deaa8bf45faef1b6a98175155fc3ee392b0d22fab9f6f76c8c966b5a00d", matchedKeywords: ["mẫu số 14"] }]);
  const bundle = assembleDvcProcedureBundle(merged, "1.012789");
  expect(bundle.components[0].status).toBe("ready_reference");
  expect(["matched_reference", "awaiting_manual_review"]).toContain(bundle.components[0].attachments[0].status);
  expect(bundle.components[0].attachments[0].componentId).toBe("c1");
});

it("giữ Word legacy .doc của hợp đồng ở Reference-only", () => {
  const scan = {
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889",
    checkedAt: "2026-08-20T00:00:00.000Z",
    fetched: true,
    receivingSection: "",
    processingSection: "",
    items: [],
    warnings: [],
    dossierComponents: [{ id: "contract", name: "Hợp đồng chuyển quyền sử dụng đất", required: true, evidence: "DVC" }],
    attachments: [],
  };
  const merged = mergeDvcReferenceBinaries(scan, [{ name: "Hợp đồng chuyển nhượng QSDĐ.doc", url: "https://htpldn.moj.gov.vn/example/contract.doc", kind: "doc", sourceUrl: "https://htpldn.moj.gov.vn/Pages/chi-tiet-tin.aspx?ItemID=24", checksum: "contract-reference-checksum", matchedKeywords: ["hợp đồng chuyển quyền sử dụng đất"] }]);
  const attachment = merged.attachments[0];
  expect(attachment.kind).toBe("doc");
  expect(attachment.status).toBe("awaiting_manual_review");
  expect(attachment.componentId).toBe("contract");
  expect(attachment.status).not.toBe("verified_binary");
});

it("ghép đúng-mẫu reference vào hồ sơ nhưng giữ trạng thái chưa Official", () => {
  const scan = {
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789",
    checkedAt: "2026-08-20T00:00:00.000Z",
    fetched: true,
    receivingSection: "",
    processingSection: "",
    items: [],
    warnings: [],
    dossierComponents: [{ id: "c1", name: "Mẫu số 14 - Phiếu yêu cầu cung cấp thông tin đất đai", required: true, evidence: "DVC" }],
    attachments: [{ id: "ref-14", name: "Mẫu số 14.doc", url: "https://example.org/mau-so-14.doc", kind: "doc" as const, sourceUrl: "https://example.org", checkedAt: "2026-08-20T00:00:00.000Z", status: "matched_reference" as const, evidence: "Đối chiếu đúng tên và nội dung Mẫu số 14", componentId: "c1", checksum: "308c0deaa8bf45faef1b6a98175155fc3ee392b0d22fab9f6f76c8c966b5a00d" }],
  };
  const bundle = assembleDvcProcedureBundle(scan, "1.012789");
  expect(bundle.components[0].status).toBe("ready_reference");
  expect(bundle.readyCount).toBe(1);
  expect(bundle.missingComponents).toEqual([]);
  expect(["matched_reference", "awaiting_manual_review"]).toContain(bundle.components[0].attachments[0].status);
  expect(bundle.components[0].attachments[0].evidence).toContain("Đối chiếu đúng tên");
});

it("gắn biến thể Mus14 vào component Mẫu số 14 khi attachment chưa có componentId", () => {
  const scan = {
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789",
    checkedAt: "2026-08-20T00:00:00.000Z",
    fetched: true,
    receivingSection: "",
    processingSection: "",
    items: [],
    warnings: [],
    dossierComponents: [{ id: "c14", name: "Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai theo Mẫu số 14, 14a, 14b, 14c, 14d", required: true, evidence: "DVC" }],
    attachments: [{ id: "mus14", name: "Mus14a14b14c14d.docx", url: "https://example.org/Mus14a14b14c14d.docx", kind: "docx" as const, sourceUrl: "https://example.org", checkedAt: "2026-08-20T00:00:00.000Z", status: "matched_reference" as const, evidence: "Mẫu biểu tham khảo" }],
  };
  const bundle = assembleDvcProcedureBundle(scan, "1.012789");
  expect(bundle.components[0].status).toBe("ready_reference");
  expect(bundle.components[0].attachments[0].componentId).toBe("c14");
});


describe("Attachment tier fallback contract", () => {
  it("nhận diện URL chi tiết DVC có mã thủ tục dạng 1.012789", () => {
    const source = readFileSync(new URL("./dvcSourceRegistry.ts", import.meta.url), "utf8");
    expect(source).toContain("ma_thu_tuc=\\d+(?:\\.\\d+)*");
  });

  it("nhận diện endpoint tải file không có đuôi từ onclick/data-*", () => {
    const source = readFileSync(new URL("./dvcSourceRegistry.ts", import.meta.url), "utf8");
    expect(source).toContain("scriptDownloadPattern");
    expect(source).toContain("data-download-url");
    expect(source).toContain("hydrateDvcAttachment");
  });

  it("có nhánh fallback attachment sau khi trang DVC đã mở nhưng binary lỗi", () => {
    const source = readFileSync(new URL("./dvcSourceRegistry.ts", import.meta.url), "utf8");
    expect(source).toContain("needsAttachmentFallback");
    expect(source).toContain("fallbackSources");
    expect(source).toContain("attachmentFallbackNotes");
    expect(source).toContain("candidate attachment");
  });
});


it("dùng metadata registry làm fallback có kiểm soát khi trang DVC không có mục thành phần", async () => {
  vi.stubGlobal("fetch", vi.fn(async () => new Response("<html><body><h1>Chi tiết thủ tục</h1></body></html>", {
    status: 200,
    headers: { "content-type": "text/html" },
  })));

  const result = await scanDvcProcedureSource({ procedureCode: "2.000889", province: "Đà Nẵng" });

  expect(result.dossierComponents.length).toBeGreaterThan(0);
  expect(result.dossierComponents[0].id).toBe("registry-component-0");
  expect(result.dossierComponents[0].evidence).toContain("Metadata registry");
  expect(result.dossierComponents.every(component => component.required === false)).toBe(true);
});


describe("Registry lookup và parser fallback", () => {
  it("tra thủ tục theo mã không phụ thuộc province và bỏ khoảng trắng", () => {
    expect(getOfficialLandProcedure(" 2.000889 ", "Tỉnh không nằm trong registry")?.code).toBe("2.000889");
  });

  it("không trả 0/0 khi thủ tục registry không có requirement/template metadata", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("<html><body><h1>Chi tiết thủ tục</h1></body></html>", { status: 200 })));
    const result = await scanDvcProcedureSource({ procedureCode: "1.012784", province: "Đà Nẵng" });
    expect(result.dossierComponents.length).toBeGreaterThan(0);
    expect(result.officialLayers?.procedureUrl.status).toBe("verified");
  });

  it("đọc bảng và danh sách lồng nhau khi heading DVC không chuẩn", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(`
      <section><div>Hồ sơ gồm</div><table>
        <tr><th>STT</th><th>Tài liệu</th></tr>
        <tr><td>1</td><td>Đơn đề nghị đăng ký đất đai</td></tr>
        <tr><td>2</td><td><ul><li>Giấy chứng nhận quyền sử dụng đất</li><li>Giấy tờ nhân thân của người nộp hồ sơ</li></ul></td></tr>
      </table></section><div>Thời hạn giải quyết</div>
    `, { status: 200, headers: { "content-type": "text/html" } })));
    const result = await scanDvcProcedureSource({ procedureCode: "1.013978", province: "Hà Nội" });
    expect(result.dossierComponents.map(item => item.name)).toEqual(expect.arrayContaining([
      "Đơn đề nghị đăng ký đất đai",
      "Giấy chứng nhận quyền sử dụng đất",
      "Giấy tờ nhân thân của người nộp hồ sơ",
    ]));
  });
});


it("chạy được workflow discovery → components → candidate → classification cho mã ngoài seed 1.012750", async () => {
  vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => {
    const url = String(input);
    if (url.endsWith(".docx") || url.endsWith(".pdf")) {
      return new Response("binary unavailable in contract test", { status: 503 });
    }
    return new Response(`
      <h1>Cung cấp thông tin, dữ liệu đất đai</h1>
      <h2>Thành phần hồ sơ</h2>
      <p>Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai theo Mẫu số 14, 14a, 14b, 14c, 14d, 14đ</p>
      <a href="/files/mau-14.docx">Mẫu số 14</a>
      <h2>Cơ quan thực hiện</h2><p>Trung tâm Dữ liệu và Thông tin đất đai</p>
    `, { status: 200, headers: { "content-type": "text/html" } });
  }));

  const scan = await scanDvcProcedureSource({ procedureCode: "1.012750", province: "Hà Nội" });
  const bundle = assembleDvcProcedureBundle(scan, "1.012750");

  expect(scan.fetched).toBe(true);
  expect(scan.dossierComponents.length).toBeGreaterThan(0);
  expect(scan.dossierComponents.some(item => item.name.includes("Mẫu số 14"))).toBe(true);
  expect(bundle.procedureCode).toBe("1.012750");
  expect(bundle.totalCount).toBeGreaterThan(0);
  expect(bundle.officialTemplates).toHaveLength(0);
  expect(bundle.referenceTemplates.length + bundle.missingComponents.length).toBeGreaterThan(0);
}, 15000);
