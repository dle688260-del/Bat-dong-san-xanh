# Nguồn đối chiếu tên thủ tục đất đai

## Nguồn chính thức

- Bộ Nông nghiệp và Môi trường: https://mae.gov.vn/bo-nong-nghiep-va-moi-truong-cong-bo-thu-tuc-hanh-chinh-linh-vuc-at-ai-18780.htm
  - Bài đăng ngày 23/06/2025 về Quyết định 2304/QĐ-BNNMT.
  - Quyết định có hiệu lực từ 01/07/2025 và thay Quyết định 629/QĐ-BTNMT.
  - Bài viết nêu các nhóm TTHC: sửa đổi/bổ sung cấp trung ương 02, cấp tỉnh 15, cấp xã 04; thay thế cấp tỉnh 26, cấp xã 16; không thay đổi cấp xã 01; bãi bỏ cấp tỉnh 01 và cấp huyện 01.
  - Các văn bản nền được nêu: Nghị định 151/2025/NĐ-CP, 131/2025/NĐ-CP và 118/2025/NĐ-CP.

- Trang văn bản của Bộ: https://mae.gov.vn/Pages/chitietvanbandh.aspx?ItemID=3305
  - Có file toàn văn và 3 file đính kèm: quyết định, phụ lục công bố theo Nghị định 151/2025/NĐ-CP, phụ lục chi tiết các thủ tục.
  - File phụ lục chi tiết: https://mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/3305/2. PHU LUC CHI TIET CÁC THU TUC 151.2025.NĐ-CP.pdf

- Cục Quản lý đất đai: https://qldd.mae.gov.vn/Pages/van-ban-dieu-hanh.aspx?ItemID=91
  - Xác nhận Quyết định 2304/QĐ-BNNMT ngày 23/06/2025.
  - Có các tệp chính thức: https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/91/2304-BNNMT-QLĐĐ.pdf, phụ lục 1 và phụ lục 2.

## Kết luận dùng cho hệ thống

Không được dùng số “11 mẫu liên quan” để đại diện cho toàn bộ catalog. Tên thủ tục phải lấy từ phụ lục chính thức hoặc catalog DVC/cơ quan có thẩm quyền, gắn với mã TTHC và thời điểm hiệu lực. Nếu mã chỉ xuất hiện trong một danh sách chưa có dòng tên xác minh, giao diện phải ghi rõ trạng thái chưa đối soát thay vì tự đặt tên.
