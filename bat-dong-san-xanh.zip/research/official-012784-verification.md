# Xác minh thủ tục 1.012784

## Nguồn chính thức đã kiểm tra

1. Báo Điện tử Chính phủ – Mẫu Đơn đề nghị tách thửa đất, hợp thửa đất:
   https://xaydungchinhsach.chinhphu.vn/mau-don-de-nghi-tach-thua-dat-hop-thua-dat-119240801152947547.htm
   - Nêu rõ mẫu được quy định tại Nghị định 101/2024/NĐ-CP ngày 29/7/2024.
   - Có liên kết tải DOCX trực tiếp: https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/don-17225006379202035387597.docx
   - Nội dung mẫu hiển thị là Mẫu số 01/ĐK, tiêu đề “Đơn đề nghị tách thửa đất, hợp thửa đất”.
   - Mẫu gồm thông tin người sử dụng đất, nội dung tách/hợp thửa, lý do, giấy tờ nộp kèm và phần xác nhận của Văn phòng đăng ký đất đai.

2. Báo Điện tử Chính phủ – Hướng dẫn thủ tục tách thửa hoặc hợp thửa đất:
   https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-tach-thua-hoac-hop-thua-dat-119240828053454684.htm
   - Ghi thủ tục theo Quyết định 2124/QĐ-BTNMT ngày 01/08/2024.
   - Thành phần hồ sơ gồm: Mẫu 01/ĐK; Bản vẽ tách/hợp thửa theo Mẫu 02/ĐK; Giấy chứng nhận; văn bản của cơ quan có thẩm quyền nếu có.
   - Căn cứ gồm Luật Đất đai 31/2024/QH15, Luật 43/2024/QH15 và Nghị định 101/2024/NĐ-CP.
   - Điều kiện còn phụ thuộc Điều 220 Luật Đất đai và quy định diện tích tối thiểu của UBND cấp tỉnh.

3. Phụ lục của Bộ Nông nghiệp và Môi trường:
   https://mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/3506/Ph%E1%BB%A5%20l%E1%BB%A5c.%20Danh%20m%E1%BB%A5c%20TTHC%20thu%E1%BB%99c%20ph%E1%BA%A1m%20vi%20qu%E1%BA%A3n%20l%C3%BD%20c%E1%BB%A7a%20B%E1%BB%99%20NNMT_tr%C3%ACnh__01042026111237_signed.pdf
   - Kết quả trích xuất cho thấy mã 1.012784 “Tách thửa hoặc hợp thửa đất” và Quyết định 2304/QĐ-BNNMT trong danh mục được công bố năm 2026.

## Kết luận sơ bộ

- Có nguồn chính thức xác nhận thủ tục 1.012784 và có file DOCX Mẫu 01/ĐK từ miền CDN thuộc hệ thống Báo Điện tử Chính phủ.
- File DOCX này phù hợp về tên mẫu và nội dung với thủ tục tách/hợp thửa; tuy nhiên cần tải bytes thực tế, kiểm tra MIME/độ mở được, tính SHA-256 và lưu provenance trước khi gắn “Official Template File”.
- Mẫu 02/ĐK là bản vẽ do Văn phòng đăng ký đất đai/Chi nhánh hoặc đơn vị đo đạc có giấy phép thực hiện; không nên coi một file mẫu chung là bản vẽ hoàn chỉnh cho thửa đất cụ thể.
- Mã thủ tục trong phụ lục Bộ là bằng chứng registry/procedure, không tự chứng minh file DOCX là binary Official nếu chưa lưu được file và checksum.

## Kiểm tra binary thực tế

File DOCX đã tải thành công từ liên kết CDN được dẫn trực tiếp trên trang Báo Điện tử Chính phủ. Kiểm tra hệ thống tệp nhận diện đây là Microsoft Word 2007+, dung lượng 21.312 bytes; SHA-256 là `7c1b2afc87f72b3cae065e1a6bbc1bb4c7089ae366a12e66c9380132162c42ff`. Nội dung XML bên trong xác nhận các dấu hiệu khớp: “Mẫu số 01/ĐK”, “ĐƠN ĐỀ NGHỊ TÁCH THỬA ĐẤT, HỢP THỬA ĐẤT”, nơi nhận là Văn phòng Đăng ký đất đai/Chi nhánh Văn phòng Đăng ký đất đai, trường Giấy chứng nhận và phần bản vẽ tách/hợp thửa.

Kết luận xác minh: file này đủ căn cứ để xếp là ứng viên `Official Template File` cho thủ tục 1.012784 về mặt nguồn công bố, định dạng, checksum và nội dung mẫu. Tuy nhiên, hệ thống vẫn phải lưu provenance chính xác là trang Báo Điện tử Chính phủ/CDN, liên kết trang mẫu, checksum và quan hệ với Mẫu 01/ĐK; không được gọi đây là hồ sơ đã hoàn chỉnh cho một thửa đất cụ thể. Mẫu 02/ĐK/bản vẽ và giấy tờ đất vẫn là thành phần riêng cần bổ sung theo hồ sơ thực tế.

## Đối chiếu thêm với DVC và Nghị định 151/2025

Nguồn Dịch vụ công Quốc gia cho mã 1.012784 xác định tên thủ tục là “Tách thửa hoặc hợp thửa đất”, dùng một bundle chung và phân nhánh theo lựa chọn của người dùng: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784

Theo thông tin tra cứu, thành phần hồ sơ mới cần đối chiếu gồm Đơn đề nghị tách/hợp thửa theo Mẫu số 21 và Bản vẽ tách/hợp thửa theo Mẫu số 22 kèm Nghị định 151/2025/NĐ-CP. Các liên kết tải được DVC công bố cần kiểm tra bytes thực tế, MIME và SHA-256 trước khi gắn Official:
- Mus21.docx: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fdb06d9eb2d9706
- Mus22.docx: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe83ad50e05ef58

Căn cứ Chính phủ: Nghị định 151/2025/NĐ-CP, số văn bản 151/2025/NĐ-CP, ban hành 12/06/2025, hiệu lực 01/07/2025: https://vanban.chinhphu.vn/?pageid=27160&docid=213927

Căn cứ Bộ Nông nghiệp và Môi trường: Phụ lục thủ tục hành chính kèm Quyết định 2304/QĐ-BNNMT, có liệt kê mã 1.012784 và các căn cứ Luật Đất đai 31/2024/QH15, Nghị định 101/2024/NĐ-CP, Nghị định 118/2025/NĐ-CP và Nghị định 151/2025/NĐ-CP: https://mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/3305/2.%20PHU%20LUC%20CHI%20TIET%20C%C3%81C%20THU%20TUC%20151.2025.N%C4%90-CP.pdf

Kết luận: không tách thành hai procedure registry riêng; giữ chung procedure 1.012784 và gắn `operation=tach_thua` hoặc `operation=hop_thua`. Mẫu 21/22 chỉ được nâng Official sau khi tải nguyên vẹn từ nguồn chính thức và đối chiếu nội dung. Các số diện tích tối thiểu và điều kiện thực hiện phải lấy theo UBND cấp tỉnh, không hardcode 36m² hoặc 50m² cho toàn quốc. Thời hạn tra cứu cần giữ theo bản ghi DVC/địa phương đang áp dụng, không mặc nhiên dùng một con số cho mọi nơi.

## Nguồn tổng hợp người dùng gửi
- Phân loại: nguồn tham khảo thứ cấp, không phải bản thân văn bản ban hành hoặc file mẫu gốc của cơ quan nhà nước.
- Có thể dùng làm candidate discovery cho các thủ tục cấp xã, Quyết định 2304/QĐ-BNNMT và Mẫu 15/Nghị định 151/2025.
- Không tự gắn Official từ nội dung bài. Cần mở văn bản gốc và file DOCX/PDF trên tên miền cơ quan nhà nước, sau đó kiểm tra mã thủ tục, nội dung, MIME và SHA-256.
- Điều kiện, cơ quan tiếp nhận và thời hạn trong bài phải đối chiếu theo từng mã thủ tục và địa phương trước khi đưa vào hồ sơ.
