import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const pageSource = readFileSync(resolve(process.cwd(), "client/src/pages/AiLandDossierPipeline.tsx"), "utf8");
const autoModuleSource = readFileSync(resolve(process.cwd(), "client/src/pages/AiLandDossierAutoModule.tsx"), "utf8");
const appSource = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
const layoutSource = readFileSync(resolve(process.cwd(), "client/src/components/DashboardLayout.tsx"), "utf8");

describe("AI land dossier pipeline module", () => {
  it("has its own route and dashboard menu entry", () => {
    expect(appSource).toContain("/ai-ho-so-dat-dai-tu-dong");
    expect(layoutSource).toContain('label: "Trợ lý AI", path: "/dashboard/ai"');
    expect(layoutSource).toContain("Chọn thủ tục & quét nguồn");
  });

  it("builds the workflow from procedure metadata instead of a fixed eight-step list", () => {
    expect(pageSource).toContain("trpc.legalKnowledge.searchOfficial.useQuery");
    expect(pageSource).toContain("official.data?.procedure as");
    expect(pageSource).toContain("procedureMeta?.workflowSteps?.length");
    expect(pageSource).toContain("procedureMeta?.requirements");
    expect(pageSource).toContain("return sourceSteps.map((step, index)");
  });

  it("does not enable Official export without a verified template binary", () => {
    expect(autoModuleSource).toContain("const canExportOfficial = isVerifiedBinaryAsset(officialStatusAsset);");
    expect(autoModuleSource).toContain("trpc.aiAutoDossier.discover.useMutation");
    expect(autoModuleSource).toContain("trpc.landDossierBuilder.ocr.useMutation");
    expect(autoModuleSource).toContain("trpc.landDossierBuilder.exportBundle.useMutation");
    expect(autoModuleSource).toContain("Chỉ có Draft/Reference");
    expect(autoModuleSource).toContain("Tải bản nháp DOCX");
    expect(autoModuleSource).toContain("không gọi bản nháp là Official");
  });
});
