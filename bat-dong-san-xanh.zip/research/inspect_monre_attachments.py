from __future__ import annotations

import re
from html import unescape
from urllib.parse import urljoin

import requests

URL = "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67"
response = requests.get(URL, timeout=20, headers={"User-Agent": "Mozilla/5.0"})
print(f"status={response.status_code} content_type={response.headers.get('content-type')}")
html = response.text
print(f"bytes={len(html.encode('utf-8'))}")
for match in re.finditer(r"(?is)<a\\b[^>]*href\\s*=\\s*([\\\"'])(.*?)\\1[^>]*>(.*?)</a>", html):
    href = unescape(match.group(2).strip())
    label = re.sub(r"<[^>]+>", " ", match.group(3))
    label = re.sub(r"\\s+", " ", unescape(label)).strip()
    if any(term in label.lower() for term in ("tải", "phiếu", "hợp đồng", "văn bản", "yeu cau", "phieu")):
        print(f"label={label!r} href={urljoin(URL, href)}")
