export type LandLegalReferenceKind = "legal_basis" | "reference_template";

export type LandLegalReferenceCandidate = {
  id: string;
  title: string;
  documentNumber: string;
  kind: LandLegalReferenceKind;
  format: "pdf" | "docx" | "html";
  sourceLayer: "government" | "public_reference";
  sourceUrl: string;
  discoveryUrl?: string;
  appliesWhen: string[];
  notes: string;
};

/**
 * Curated, auditable candidates. Government URLs are legal-basis sources;
 * public DOCX/PDF URLs are Reference candidates until downloaded, inspected,
 * checksummed and reviewed. No candidate is Official by catalog membership.
 */
export const LAND_LEGAL_REFERENCE_CATALOG: LandLegalReferenceCandidate[] = [
  {
    id: "nd-101-2024",
    title: "Nghị định 101/2024/NĐ-CP — đăng ký, cấp Giấy chứng nhận và hệ thống thông tin đất đai",
    documentNumber: "101/2024/NĐ-CP",
    kind: "legal_basis",
    format: "pdf",
    sourceLayer: "government",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791",
    appliesWhen: ["đăng ký", "giấy chứng nhận", "cấp sổ", "biến động", "thông tin đất đai"],
    notes: "Căn cứ pháp lý; không tự coi là file mẫu.",
  },
  {
    id: "nd-102-2024",
    title: "Nghị định 102/2024/NĐ-CP — quy định chi tiết thi hành Luật Đất đai",
    documentNumber: "102/2024/NĐ-CP",
    kind: "legal_basis",
    format: "html",
    sourceLayer: "government",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210795",
    appliesWhen: ["quy hoạch", "thu hồi", "giao đất", "cho thuê đất", "chuyển mục đích", "đất đai"],
    notes: "Trang văn bản Chính phủ; binary PDF chỉ được đánh dấu Official sau khi tải và xác minh.",
  },
  {
    id: "nd-103-2024",
    title: "Nghị định 103/2024/NĐ-CP — tiền sử dụng đất, tiền thuê đất",
    documentNumber: "103/2024/NĐ-CP",
    kind: "legal_basis",
    format: "html",
    sourceLayer: "government",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210797",
    appliesWhen: ["nghĩa vụ tài chính", "tiền sử dụng đất", "tiền thuê đất", "phiếu chuyển", "lệ phí"],
    notes: "Căn cứ nghĩa vụ tài chính; không thay thế biểu mẫu thuế hoặc phiếu chuyển của cơ quan tiếp nhận.",
  },
  {
    id: "nd-96-2024",
    title: "Nghị định 96/2024/NĐ-CP — quy định chi tiết Luật Kinh doanh bất động sản",
    documentNumber: "96/2024/NĐ-CP",
    kind: "legal_basis",
    format: "html",
    sourceLayer: "government",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210798&classid=1",
    appliesWhen: ["kinh doanh bất động sản", "môi giới", "sàn giao dịch", "hợp đồng kinh doanh"],
    notes: "Chỉ gắn cho workflow kinh doanh BĐS; không gắn mặc định cho mọi thủ tục đăng ký đất đai.",
  },
  {
    id: "nd-151-2025",
    title: "Nghị định 151/2025/NĐ-CP — phân định thẩm quyền và phân cấp trong lĩnh vực đất đai",
    documentNumber: "151/2025/NĐ-CP",
    kind: "legal_basis",
    format: "html",
    sourceLayer: "government",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=213927",
    discoveryUrl: "https://qldd.mae.gov.vn/so-tay-dien-tu/so-tay-dien-tu-huong-dan-ve-trinh-tu-thu-tuc-hanh-chinh-linh-vuc-dat-dai-thuoc-pham-vi-chuc-nang-quan-ly-nha-nuoc-cua-bo-nong-nghiep-va-moi-truong-3318.htm",
    appliesWhen: ["thẩm quyền", "nộp hồ sơ", "văn phòng đăng ký đất đai", "ubnd cấp xã", "địa phương"],
    notes: "Dùng để xác định cơ quan/địa bàn; không tự sinh biểu mẫu.",
  },
  {
    id: "mau-09-reference-public",
    title: "Mẫu số 09/ĐK — Đơn đăng ký biến động đất đai",
    documentNumber: "Mẫu 09/ĐK",
    kind: "reference_template",
    format: "docx",
    sourceLayer: "public_reference",
    sourceUrl: "https://cdn.thuvienphapluat.vn/uploads/DanLuat-BanAn/mau-09-dk.doc",
    appliesWhen: ["đăng ký biến động", "biến động", "chuyển nhượng", "tặng cho", "thừa kế", "mẫu 09", "mau09", "mus09"],
    notes: "Ứng viên công khai ngoài nguồn nhà nước; chỉ lưu Reference sau khi kiểm tra binary và nội dung.",
  },
  {
    id: "mau-10-reference-public",
    title: "Mẫu số 10/ĐK — Đơn đề nghị cấp lại Giấy chứng nhận",
    documentNumber: "Mẫu 10/ĐK",
    kind: "reference_template",
    format: "docx",
    sourceLayer: "public_reference",
    sourceUrl: "https://motcua.haiduong.gov.vn/public_dir/HAI_DUONG/giayto/2017_05/1494788949_Mau_so_10-DK_-_Don_de_nghi_cap_lai_Giay_chung_nhan.doc",
    appliesWhen: ["cấp lại giấy chứng nhận", "cấp lại sổ", "mẫu 10", "mau10", "mus10"],
    notes: "Ứng viên từ cổng địa phương; phải kiểm tra signature/content trước khi lưu Reference.",
  },
  {
    id: "mau-18-reference-public-doc",
    title: "Mẫu số 18 — Đơn đăng ký biến động đất đai, tài sản gắn liền với đất",
    documentNumber: "Mẫu 18",
    kind: "reference_template",
    format: "docx",
    sourceLayer: "public_reference",
    sourceUrl: "https://cdn.thuvienphapluat.vn/uploads/khoinghiep/2025/07/09/mau-so-18.doc",
    appliesWhen: ["đăng ký biến động", "biến động", "chuyển nhượng", "tặng cho", "thừa kế", "mẫu 18", "mus18"],
    notes: "Ứng viên công khai ngoài nguồn nhà nước; chỉ dùng làm Reference sau khi kiểm tra binary.",
  },
  {
    id: "mau-18-reference-public-docx",
    title: "Mẫu số 18 — bản DOCX tham khảo",
    documentNumber: "Mẫu 18",
    kind: "reference_template",
    format: "docx",
    sourceLayer: "public_reference",
    sourceUrl: "https://cdn.thuviennhadat.vn/upload/hinh-anh-bai-viet/TTMN/thang-6-2025/18-6-2025/mau-so-18.docx",
    appliesWhen: ["đăng ký biến động", "biến động", "chuyển nhượng", "tặng cho", "thừa kế", "mẫu 18", "mus18"],
    notes: "Ứng viên DOCX công khai; dùng làm Reference, không nâng Official.",
  },
  {
    id: "mau-14-danang",
    title: "Mẫu số 14 — Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai",
    documentNumber: "Mẫu 14",
    kind: "reference_template",
    format: "docx",
    sourceLayer: "public_reference",
    sourceUrl: "https://sxd.danang.gov.vn/documents/20121/43428/M%E1%BA%ABu%2014%20-%20Phi%E1%BA%BFu%20y%C3%AAu%20c%E1%BA%A7u%20cung%20c%E1%BA%A5p%20th%C3%B4ng%20tin,d%E1%BB%AF%20li%E1%BB%87u%20%C4%91%E1%BA%A5t%20%C4%91ai.docx",
    discoveryUrl: "https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-cung-cap-thong-tin-du-lieu-dat-dai-119250805161025964.htm",
    appliesWhen: ["1.012789", "2.002317", "cung cấp thông tin", "dữ liệu đất đai", "mẫu 14", "mus14", "mfs14"],
    notes: "File công khai dùng làm Reference; phải kiểm tra nội dung/mã mẫu trước khi ghép.",
  },
];

export function getReferencesForProcedure(input: { code: string; name: string; aliases?: string[] }) {
  const haystack = [input.code, input.name, ...(input.aliases ?? [])].join(" ").toLocaleLowerCase("vi-VN");
  return LAND_LEGAL_REFERENCE_CATALOG.filter(candidate => candidate.appliesWhen.some(token => haystack.includes(token.toLocaleLowerCase("vi-VN"))));
}
