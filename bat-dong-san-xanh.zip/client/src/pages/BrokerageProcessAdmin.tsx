import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import WorkflowFileManager from "@/components/WorkflowFileManager";
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  ClipboardCheck,
  Download,
  FileText,
  Loader2,
  MapPin,
  Paperclip,
  Search,
  Save,
  Upload,
} from "lucide-react";

export const BROKERAGE_PROCESS_TITLE = "QUY TRÌNH QUẢN LÝ BẤT ĐỘNG SẢN";
export const BROKERAGE_PROCESS_MENU_LABEL = "Quá trình môi giới 12 bước";
export const BROKERAGE_PROCESS_WORD_LABEL = "Xuất quy trình Word";
export const BROKERAGE_PROCESS_WORD_MIME = "application/msword;charset=utf-8";
export const BROKERAGE_PROCESS_WORD_EXTENSION = ".doc";

export const LOAN_ADVISORY_FIELDS = [
  "Nhu cầu vay dự kiến",
  "Vốn tự có",
  "Khoản vay dự kiến",
  "Thời hạn vay mong muốn",
  "Hồ sơ thu nhập",
  "Tài sản bảo đảm",
  "Ngân hàng/chuyên viên kết nối",
  "Trạng thái hồ sơ vay",
] as const;

export const PROCESS_STEPS = [
  { title: "Tiếp nhận thông tin BĐS", fields: ["Họ tên chủ nhà", "Số điện thoại", "Địa chỉ BĐS", "Loại BĐS", "Giá chủ nhà mong muốn", "Nhu cầu bán", "Người tiếp nhận"] },
  { title: "Khảo sát sơ bộ", fields: ["Diện tích", "Mặt tiền", "Hướng", "Đường giao thông", "Vị trí", "Hiện trạng nhà/đất", "Hình ảnh ban đầu"] },
  { title: "Khảo sát thực tế", fields: ["Đi thực địa", "Chụp ảnh/video", "Kiểm tra hiện trạng", "Đối chiếu thông tin chủ nhà", "Ưu điểm/nhược điểm"] },
  { title: "Kiểm tra quy hoạch", fields: ["Quy hoạch sử dụng đất", "Lộ giới", "Đường dự phóng", "Chỉ giới xây dựng", "Thông tin quy hoạch liên quan", "Tài liệu kiểm tra"] },
  { title: "Kiểm tra pháp lý", fields: ["Giấy chứng nhận", "Chủ sở hữu", "Diện tích trên giấy tờ", "Mục đích sử dụng đất", "Thời hạn sử dụng", "Thế chấp/tranh chấp", "Hồ sơ liên quan"] },
  { title: "Định giá BĐS", fields: ["Giá chủ nhà đưa ra", "Giá tham khảo thị trường", "BĐS so sánh", "Giá đề xuất", "Mức thương lượng dự kiến"] },
  { title: "Tiếp nhận ký gửi", fields: ["Thỏa thuận với chủ nhà", "Giá bán", "Phí môi giới", "Thời hạn ký gửi", "Người phụ trách", "Tình trạng hồ sơ"] },
  { title: "Đăng bán", fields: ["Tin BĐS", "Hình ảnh", "Video", "Mô tả", "Giá", "Vị trí", "Pháp lý đã xác minh", "Kênh đăng website/Facebook/Zalo"] },
  { title: "Quản lý khách mua", fields: ["Khách hàng", "Nhu cầu", "Ngân sách", "BĐS phù hợp", "Lịch liên hệ", "Lịch xem", "Tư vấn vay vốn", ...LOAN_ADVISORY_FIELDS] },
  { title: "Xem BĐS", fields: ["Đặt lịch", "Khách đã xem", "Ý kiến khách", "Mức độ quan tâm", "Khả năng thương lượng"] },
  { title: "Đàm phán & giao dịch", fields: ["Giá đề xuất", "Giá thương lượng", "Tiền đặt cọc", "Điều kiện giao dịch", "Trạng thái giao dịch"] },
  { title: "Hoàn tất", fields: ["Công chứng", "Thanh toán", "Sang tên", "Bàn giao hồ sơ", "Bàn giao tài sản", "Hoàn tất phí môi giới", "Lưu hồ sơ giao dịch"] },
] as const;

export const PROPERTY_PROFILE_OPTIONS = [
  { value: "land", label: "Đất nền" },
  { value: "apartment", label: "Căn hộ" },
  { value: "house", label: "Nhà phố" },
  { value: "agricultural", label: "Đất nông nghiệp" },
  { value: "villa_resort", label: "Villa / Resort" },
  { value: "industrial", label: "Đất khu công nghiệp" },
  { value: "project", label: "Đất dự án" },
  { value: "rental", label: "Bất động sản cho thuê" },
] as const;

export type PropertyProfileType = typeof PROPERTY_PROFILE_OPTIONS[number]["value"];

const PROFILE_FIELDS: Record<PropertyProfileType, Partial<Record<number, readonly string[]>>> = {
  land: {
    1: ["Số thửa", "Tờ bản đồ", "Mục đích sử dụng", "Thời hạn sử dụng"],
    2: ["Chiều sâu", "Đường vào thửa đất", "Cao độ nền", "Khả năng tách thửa"],
    4: ["Quy hoạch sử dụng đất", "Lộ giới", "Chỉ giới xây dựng", "Hành lang bảo vệ"],
    5: ["Số vào sổ", "Diện tích đất ở", "Diện tích đất khác", "Tình trạng sổ"],
    6: ["Đơn giá/m²", "Giá tham chiếu khu vực", "Khả năng tăng giá"],
  },
  apartment: {
    1: ["Tên dự án", "Tòa/tháp", "Tầng", "Mã căn"],
    2: ["Diện tích thông thủy", "Số phòng ngủ", "Số phòng tắm", "Ban công", "Hướng cửa"],
    4: ["Sổ hồng căn hộ", "Thời hạn sở hữu", "Phí bảo trì", "Phí quản lý"],
    6: ["Giá/m²", "Phí chuyển nhượng", "Nội thất bàn giao"],
    10: ["Lịch xem căn hộ", "Quy định ra vào dự án"],
  },
  house: {
    1: ["Số tầng", "Số phòng ngủ", "Số phòng tắm", "Loại đường trước nhà"],
    2: ["Diện tích xây dựng", "Diện tích sử dụng", "Kết cấu", "Năm hoàn công"],
    4: ["Sổ hồng nhà đất", "Hoàn công", "Lộ giới trước nhà", "Quy hoạch xây dựng"],
    6: ["Giá trị công trình", "Chi phí sửa chữa dự kiến"],
  },
  agricultural: {
    1: ["Loại cây trồng", "Nguồn nước", "Hiện trạng canh tác", "Thời hạn sử dụng"],
    2: ["Diện tích canh tác", "Đường vào đất", "Địa hình", "Hệ thống tưới"],
    4: ["Quy hoạch đất nông nghiệp", "Khả năng chuyển mục đích", "Hành lang thủy lợi"],
    5: ["Mục đích sử dụng trên sổ", "Hạn chế chuyển nhượng", "Tình trạng thế chấp"],
    6: ["Giá theo công/sào", "Năng suất tham khảo", "Chi phí canh tác"],
  },
  villa_resort: {
    1: ["Tên khu nghỉ dưỡng", "Diện tích villa", "Số phòng ngủ", "Đơn vị vận hành"],
    2: ["Diện tích đất", "Hồ bơi", "Sân vườn", "View", "Tiện ích nội khu"],
    4: ["Giấy chứng nhận", "Thời hạn sở hữu", "Hợp đồng vận hành", "Cam kết lợi nhuận"],
    6: ["Doanh thu cho thuê", "Phí vận hành", "Tỷ suất tham khảo"],
  },
  industrial: {
    1: ["Khu công nghiệp", "Diện tích lô", "Ngành nghề phù hợp", "Thời hạn thuê đất"],
    2: ["Mật độ xây dựng", "Điện sản xuất", "Cấp thoát nước", "Xe container vào"],
    4: ["Quy hoạch khu công nghiệp", "Giấy phép môi trường", "Pháp lý đất thuê"],
    6: ["Đơn giá thuê/m²", "Phí hạ tầng", "Thời gian miễn tiền thuê"],
    8: ["Hồ sơ năng lực doanh nghiệp", "Nhu cầu thuê diện tích"],
  },
  project: {
    1: ["Tên dự án", "Chủ đầu tư", "Phân khu", "Mã sản phẩm"],
    2: ["Diện tích lô/căn", "Tiến độ xây dựng", "Tiện ích dự án", "Phương thức thanh toán"],
    4: ["Quyết định chủ trương", "Giấy phép xây dựng", "Bảo lãnh ngân hàng", "Đủ điều kiện mở bán"],
    6: ["Giá niêm yết", "Chính sách bán hàng", "Chiết khấu", "Lịch thanh toán"],
    12: ["Bàn giao sổ", "Bàn giao nhà", "Bảo hành dự án"],
  },
  rental: {
    1: ["Loại hình cho thuê", "Thời hạn thuê", "Tiền cọc", "Giá thuê/tháng"],
    2: ["Diện tích sử dụng", "Nội thất", "Chỗ để xe", "Điện nước"],
    4: ["Giấy tờ chủ sở hữu", "Điều khoản hợp đồng", "Quy định sử dụng"],
    7: ["Phí quản lý", "Phí môi giới cho thuê", "Ngày bàn giao"],
    11: ["Thời hạn hợp đồng", "Điều kiện gia hạn", "Điều kiện hoàn cọc"],
  },
};

export function getProcessStepsForType(profileType: PropertyProfileType) {
  return PROCESS_STEPS.map((step, index) => ({
    ...step,
    fields: [...step.fields, ...(PROFILE_FIELDS[profileType]?.[index + 1] || [])],
  }));
}

export function normalizePropertyProfileType(value: unknown): PropertyProfileType {
  const normalized = String(value || "").toLowerCase();
  if (["apartment", "căn hộ", "can-ho"].includes(normalized)) return "apartment";
  if (["house", "nhà phố", "nha-pho"].includes(normalized)) return "house";
  if (["agricultural", "đất nông nghiệp", "dat-nong-nghiep"].includes(normalized)) return "agricultural";
  if (["villa", "resort", "villa_resort", "villa / resort"].includes(normalized)) return "villa_resort";
  if (["industrial", "đất khu công nghiệp", "dat-khu-cong-nghiep"].includes(normalized)) return "industrial";
  if (["project", "đất dự án", "dat-du-an"].includes(normalized)) return "project";
  if (["rental", "cho thuê", "bất động sản cho thuê"].includes(normalized)) return "rental";
  return "land";
}

const STATUS_META = {
  completed: { label: "Đã hoàn thành", className: "bg-emerald-100 text-emerald-800" },
  in_progress: { label: "Đang xử lý", className: "bg-amber-100 text-amber-800" },
  not_started: { label: "Chưa thực hiện", className: "bg-slate-100 text-slate-700" },
  needs_review: { label: "Cần kiểm tra lại", className: "bg-red-100 text-red-800" },
} as const;

type StepStatus = keyof typeof STATUS_META;

function formatDate(value: unknown) {
  return value ? new Date(value as string | number | Date).toLocaleDateString("vi-VN") : "—";
}

function escapeHtml(value: unknown) {
  return String(value ?? "").replace(/[&<>\"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#039;" })[char] || char);
}

function exportProcessWord(detail: any) {
  const title = detail?.property?.title || `Hồ sơ BĐS #${detail?.dossier?.id || ""}`;
  const profileType = normalizePropertyProfileType(detail?.property?.propertyType);
  const processSteps = getProcessStepsForType(profileType);
  const profileLabel = PROPERTY_PROFILE_OPTIONS.find(option => option.value === profileType)?.label || "Đất nền";
  const rows = processSteps.map((step, index) => {
    const saved = detail?.steps?.find((item: any) => item.stepNumber === index + 1);
    const status = STATUS_META[saved?.status as StepStatus]?.label || STATUS_META.not_started.label;
    return `<tr><td><strong>Bước ${index + 1}</strong><br>${escapeHtml(step.title)}<br><small>${step.fields.map(escapeHtml).join(" · ")}</small></td><td>${escapeHtml(status)}</td><td>${escapeHtml(saved?.details || "")}</td><td>${escapeHtml(saved?.notes || "")}</td></tr>`;
  }).join("");
  const html = `<html><head><meta charset="utf-8"><style>body{font-family:Arial;color:#18352D}h1{color:#1F5A4A}table{border-collapse:collapse;width:100%}th,td{border:1px solid #AFC5B6;padding:8px;vertical-align:top}th{background:#E8F0E8}small{color:#60766D}</style></head><body><h1>QUY TRÌNH QUẢN LÝ BẤT ĐỘNG SẢN</h1><h2>${escapeHtml(title)}</h2><p><strong>Loại BĐS:</strong> ${escapeHtml(profileLabel)}</p><p><strong>Địa chỉ:</strong> ${escapeHtml(detail?.property?.location || "—")}</p><p><strong>Cập nhật:</strong> ${formatDate(detail?.dossier?.updatedAt)}</p><table><thead><tr><th>Bước và trường thông tin</th><th>Trạng thái</th><th>Nội dung</th><th>Ghi chú</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  const blob = new Blob([`\ufeff${html}`], { type: BROKERAGE_PROCESS_WORD_MIME });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const safeTitle = title.replace(/[^a-zA-Z0-9À-ỹ -]/g, "-").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "") || "ho-so-bds";
  link.href = url;
  link.download = `${safeTitle}-quy-trinh-12-buoc${BROKERAGE_PROCESS_WORD_EXTENSION}`;
  link.rel = "noopener";
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

export default function BrokerageProcessAdmin() {
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [openStep, setOpenStep] = useState(0);
  const [manualProfileType, setManualProfileType] = useState<PropertyProfileType | null>(null);
  const dossiers = trpc.brokerage.dossiers.list.useQuery();
  const detail = trpc.brokerage.dossiers.get.useQuery({ id: selectedId ?? 1 }, { enabled: selectedId !== null });
  const utils = trpc.useUtils();
  const updateStep = trpc.brokerage.dossiers.updateStep.useMutation({
    onSuccess: () => { toast.success("Đã lưu thông tin bước"); utils.brokerage.dossiers.get.invalidate(); utils.brokerage.dossiers.list.invalidate(); },
    onError: error => toast.error(error.message),
  });
  const uploadDocument = trpc.brokerage.dossiers.uploadDocument.useMutation({
    onSuccess: () => { toast.success("Đã tải tài liệu lên bước"); utils.brokerage.dossiers.get.invalidate(); },
    onError: error => toast.error(error.message),
  });
  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();
    return (dossiers.data || []).filter((row: any) => `${row.property?.propertyCode || ""} ${row.property?.title || ""} ${row.property?.location || ""}`.toLowerCase().includes(query));
  }, [dossiers.data, search]);

  useEffect(() => {
    if (selectedId === null && filtered[0]?.dossier?.id) setSelectedId(filtered[0].dossier.id);
  }, [filtered, selectedId]);

  const savedSteps = detail.data?.steps || [];
  const completedCount = savedSteps.filter((step: any) => step.status === "completed").length;
  const selectedRow = filtered.find((row: any) => row.dossier.id === selectedId);
  const propertyProfileType = normalizePropertyProfileType(selectedRow?.property?.propertyType);
  const profileType = manualProfileType || propertyProfileType;
  const processSteps = useMemo(() => getProcessStepsForType(profileType), [profileType]);
  const profileLabel = PROPERTY_PROFILE_OPTIONS.find(option => option.value === profileType)?.label || "Đất nền";

  useEffect(() => {
    setManualProfileType(null);
  }, [selectedId]);

  const handleUpload = (stepNumber: number, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !selectedId) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      uploadDocument.mutate({ dossierId: selectedId, stepNumber, fileName: file.name, mimeType: file.type || "application/octet-stream", data: dataUrl.split(",")[1] || "" });
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  };

  return <DashboardLayout>
    <main className="min-h-screen bg-[#F5F2EA] p-4 text-[#18352D] sm:p-8">
      <div className="mx-auto max-w-[1400px]">
        <header className="rounded-[2rem] bg-[#18352D] p-6 text-white shadow-xl sm:p-9">
          <p className="text-xs font-bold uppercase tracking-[.2em] text-[#E6C478]">{BROKERAGE_PROCESS_MENU_LABEL}</p>
          <div className="mt-3 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
            <div><h1 className="font-serif text-4xl tracking-[-.04em] sm:text-5xl">{BROKERAGE_PROCESS_TITLE}</h1><p className="mt-3 max-w-3xl text-sm leading-6 text-white/75">Theo dõi hồ sơ từ tiếp nhận thông tin, khảo sát, pháp lý, ký gửi, đăng bán đến hoàn tất giao dịch.</p></div>
            <button type="button" onClick={() => selectedId && exportProcessWord(detail.data)} disabled={!detail.data} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#E6C478] px-5 py-3 text-sm font-bold text-[#18352D] transition hover:bg-[#F2D99E] disabled:cursor-not-allowed disabled:opacity-50"><Download size={18} /> {BROKERAGE_PROCESS_WORD_LABEL}</button>
          </div>
          <div className="mt-6 flex flex-wrap gap-2 text-xs text-white/80"><span className="rounded-full bg-white/10 px-3 py-2">12 bước nghiệp vụ</span><span className="rounded-full bg-white/10 px-3 py-2">Chỉ admin xem</span><span className="rounded-full bg-white/10 px-3 py-2">Tài liệu theo từng bước</span></div>
        </header>

        <div className="mt-6 grid gap-6 lg:grid-cols-[330px_1fr]">
          <aside className="rounded-2xl bg-white p-4 shadow-sm sm:p-5"><div className="flex items-center justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">CRM môi giới</p><h2 className="mt-1 font-serif text-2xl">Hồ sơ BĐS</h2></div><span className="rounded-full bg-[#F5F2EA] px-3 py-1 text-xs font-bold">{filtered.length}</span></div><label className="mt-4 flex min-h-11 items-center gap-2 rounded-xl border border-[#D9DED7] bg-[#FAFBF8] px-3"><Search size={16} className="shrink-0 text-[#60766D]" /><input aria-label="Tìm hồ sơ BĐS" value={search} onChange={event => setSearch(event.target.value)} placeholder="Tìm mã, tên hoặc vị trí..." className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#8A9991]" /></label><div className="mt-4 divide-y divide-[#E5E9E4] overflow-hidden rounded-xl border border-[#E5E9E4]">{dossiers.isLoading ? <p className="p-5 text-sm text-[#60766D]">Đang tải hồ sơ...</p> : !filtered.length ? <p className="p-6 text-center text-sm text-[#60766D]">Chưa có hồ sơ BĐS.</p> : filtered.map((row: any) => <button type="button" key={row.dossier.id} onClick={() => { setSelectedId(row.dossier.id); setOpenStep(0); }} className={`w-full p-4 text-left transition hover:bg-[#FAFBF8] ${selectedId === row.dossier.id ? "bg-[#EFF5F0]" : ""}`}><span className="block text-xs font-bold text-[#1F5A4A]">{row.property?.propertyCode || `BDS-${String(row.property?.id || row.dossier.propertyId).padStart(3, "0")}`}</span><span className="mt-1 block font-semibold leading-5">{row.property?.title || `BĐS #${row.dossier.propertyId}`}</span><span className="mt-1 block text-xs text-[#60766D]">{row.property?.location || "Chưa có địa chỉ"}</span><span className="mt-2 inline-flex rounded-full bg-[#E6C478]/35 px-2 py-1 text-[10px] font-bold">Bước {row.dossier.currentStep}/12</span></button>)}</div></aside>

          <section className="min-w-0 rounded-2xl bg-white p-4 shadow-sm sm:p-7">{detail.isLoading ? <div className="flex items-center gap-2 p-6 text-sm text-[#60766D]"><Loader2 className="animate-spin" size={17} /> Đang tải quy trình...</div> : !detail.data || !selectedRow ? <div className="p-8 text-center text-sm text-[#60766D]">Chọn một hồ sơ để bắt đầu quy trình.</div> : <>
            <div className="flex flex-col justify-between gap-4 border-b border-[#E5E9E4] pb-5 sm:flex-row sm:items-start"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">Hồ sơ BĐS · {selectedRow.property?.propertyCode || `BDS-${selectedRow.property?.id}`}</p><h2 className="mt-2 font-serif text-3xl leading-tight">{selectedRow.property?.title}</h2><p className="mt-2 flex items-center gap-1 text-sm text-[#60766D]"><MapPin size={15} /> {selectedRow.property?.location || "Chưa có địa chỉ"}</p></div><div className="text-left sm:text-right"><p className="text-2xl font-bold text-[#1F5A4A]">{completedCount}/12</p><p className="text-xs text-[#60766D]">bước hoàn thành</p></div></div>
            <div className="mt-5 h-3 overflow-hidden rounded-full bg-[#EFF5F0]"><div className="h-full rounded-full bg-[#E6C478] transition-all" style={{ width: `${(completedCount / 12) * 100}%` }} /></div>
            <div className="mt-5 rounded-2xl border border-[#D9DED7] bg-[#F6F8F2] p-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">Bộ dữ liệu theo loại BĐS</p><p className="mt-1 text-sm text-[#60766D]">Chọn loại để hiển thị đúng các trường thông tin cho toàn bộ 12 bước.</p></div><select aria-label="Loại bất động sản của hồ sơ" value={profileType} onChange={event => setManualProfileType(event.target.value as PropertyProfileType)} className="min-h-11 w-full rounded-xl border border-[#BFD0C3] bg-white px-3 text-sm font-semibold text-[#18352D] outline-none focus:ring-2 focus:ring-[#1F5A4A] sm:w-64">{PROPERTY_PROFILE_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select></div><p className="mt-3 text-xs font-semibold text-[#1F5A4A]">Đang dùng biểu mẫu: {profileLabel} · {processSteps.reduce((total, step) => total + step.fields.length, 0)} trường dữ liệu</p></div>
            <section className="mt-5 rounded-2xl border border-[#D8C48A] bg-[#FFF9E8] p-4 sm:p-5" aria-labelledby="loan-advisory-title"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-[#8A6A1F]">Tiện ích hỗ trợ khách mua</p><h3 id="loan-advisory-title" className="mt-1 text-lg font-bold text-[#18352D]">Tư vấn vay vốn</h3><p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">Thu thập thông tin vốn tự có, khoản vay, thời hạn và hồ sơ thu nhập để chuyên viên đánh giá sơ bộ và kết nối ngân hàng phù hợp.</p></div><span className="inline-flex shrink-0 rounded-full bg-white px-3 py-1 text-xs font-bold text-[#8A6A1F]">Trong bước 9/12</span></div><div className="mt-3 flex flex-wrap gap-2">{LOAN_ADVISORY_FIELDS.map(field => <span key={field} className="rounded-full bg-white px-2.5 py-1 text-[11px] font-semibold text-[#6F5A22]">{field}</span>)}</div><p className="mt-3 text-xs leading-5 text-[#7C6A3B]">Lưu ý: Đây là tư vấn sơ bộ, không phải cam kết phê duyệt khoản vay. Kết quả cuối cùng phụ thuộc vào ngân hàng và hồ sơ thực tế của khách hàng.</p></section>\n            <div className="mt-5 space-y-3">{processSteps.map((step, index) => { const saved = savedSteps.find((item: any) => item.stepNumber === index + 1); const status = (saved?.status || "not_started") as StepStatus; const isOpen = openStep === index; return <article key={step.title} className="overflow-hidden rounded-2xl border border-[#D9DED7] bg-[#FAFBF8]"><button type="button" onClick={() => setOpenStep(isOpen ? -1 : index)} className="flex w-full items-start gap-3 p-4 text-left sm:p-5"><span className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold ${status === "completed" ? "bg-emerald-100 text-emerald-800" : status === "in_progress" ? "bg-amber-100 text-amber-800" : status === "needs_review" ? "bg-red-100 text-red-800" : "bg-slate-200 text-slate-700"}`}>{status === "completed" ? <CheckCircle2 size={16} /> : index + 1}</span><span className="min-w-0 flex-1"><span className="block font-bold">Bước {index + 1} — {step.title}</span><span className="mt-1 block text-xs text-[#60766D]">{step.fields.join(" · ")}</span></span><span className={`hidden rounded-full px-2 py-1 text-[10px] font-bold sm:inline-flex ${STATUS_META[status].className}`}>{STATUS_META[status].label}</span>{isOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}</button>{isOpen && <div className="border-t border-[#D9DED7] p-4 sm:p-5"><div className="mb-4 flex flex-wrap gap-2">{step.fields.map(field => <span key={field} className="rounded-full bg-[#E8F0E8] px-2.5 py-1 text-[11px] font-semibold text-[#1F5A4A]">{field}</span>)}</div><div className="grid gap-4 md:grid-cols-[180px_1fr]"><label className="text-sm font-semibold">Trạng thái<select aria-label={`Trạng thái bước ${index + 1}`} defaultValue={status} onChange={event => { if (!saved?.id) return; updateStep.mutate({ id: saved.id, status: event.target.value as StepStatus, details: saved?.details || null, notes: saved?.notes || null }); }} className="mt-2 min-h-11 w-full rounded-xl border border-[#D9DED7] bg-white px-3 text-sm outline-none focus:ring-2 focus:ring-[#1F5A4A]"><option value="not_started">Chưa thực hiện</option><option value="in_progress">Đang xử lý</option><option value="completed">Đã hoàn thành</option><option value="needs_review">Cần kiểm tra lại</option></select></label><div className="space-y-4"><div className="grid gap-3 sm:grid-cols-2">{step.fields.map((field, fieldIndex) => <label key={field} className="block text-sm font-semibold">{field}<input data-step-field={`${index}-${fieldIndex}`} aria-label={`${field} bước ${index + 1}`} defaultValue="" placeholder={`Nhập ${field.toLowerCase()}`} className="mt-2 min-h-11 w-full rounded-xl border border-[#D9DED7] bg-white px-3 text-sm outline-none focus:ring-2 focus:ring-[#1F5A4A]" /></label>)}</div><label className="block text-sm font-semibold">Thông tin đã thực hiện<textarea aria-label={`Nội dung bước ${index + 1}`} defaultValue={saved?.details || ""} placeholder={`Nhập nội dung bổ sung cho bước: ${step.title}`} rows={5} className="mt-2 min-h-32 w-full resize-y rounded-xl border border-[#D9DED7] bg-white p-3 text-sm outline-none focus:ring-2 focus:ring-[#1F5A4A]" /></label><label className="block text-sm font-semibold">Ghi chú nội bộ<textarea aria-label={`Ghi chú bước ${index + 1}`} defaultValue={saved?.notes || ""} placeholder="Ghi chú, việc cần bổ sung hoặc cảnh báo..." rows={3} className="mt-2 w-full resize-y rounded-xl border border-[#D9DED7] bg-white p-3 text-sm outline-none focus:ring-2 focus:ring-[#1F5A4A]" /></label><div className="flex flex-wrap items-center gap-2"><button type="button" onClick={() => { const fieldValues = Array.from(document.querySelectorAll(`[data-step-field^="${index}-"]`)).map(input => { const element = input as HTMLInputElement; const label = element.getAttribute("aria-label") || ""; return `${label}: ${element.value}`; }).filter(value => !value.endsWith(": ")); const details = (document.querySelector(`[aria-label=\"Nội dung bước ${index + 1}\"]`) as HTMLTextAreaElement)?.value || ""; const notes = (document.querySelector(`[aria-label=\"Ghi chú bước ${index + 1}\"]`) as HTMLTextAreaElement)?.value || ""; if (saved?.id) updateStep.mutate({ id: saved.id, status, details, notes }); }} disabled={!saved?.id || updateStep.isPending} className="inline-flex min-h-10 items-center gap-2 rounded-xl bg-[#18352D] px-4 py-2 text-sm font-bold text-white hover:bg-[#1F5A4A] disabled:opacity-50"><Save size={16} /> Lưu bước</button><button type="button" onClick={() => { if (saved?.id && window.confirm("Xóa nội dung của bước này?")) updateStep.mutate({ id: saved.id, status: "not_started", details: null, notes: null }); }} disabled={!saved?.id || updateStep.isPending} className="inline-flex min-h-10 items-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-2 text-sm font-bold text-red-700 hover:bg-red-50 disabled:opacity-50">Xóa nội dung</button></div><WorkflowFileManager dossierId={selectedId || 0} stepNumber={index + 1} documents={(detail.data?.documents || []).filter((doc: any) => doc.stepNumber === index + 1)} onRefresh={() => { utils.brokerage.dossiers.get.invalidate(); utils.brokerage.dossiers.list.invalidate(); }} /></div></div></div>}</article>; })}</div>
          </>}</section>
        </div>
      </div>
    </main>
  </DashboardLayout>;
}
