import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("legal document scan contract", () => {
  const source = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
  it("supports scan-to-create and automatic legal archive storage", () => {
    expect(source).toContain("createDraft: z.boolean().optional()")
    expect(source).toContain("createdDraft: !input.propertyId")
    expect(source).toContain('category: "legal"')
    expect(source).toContain("createProperty({ title: `BĐS từ hồ sơ pháp lý")
  })

  it("does not add legal scan images to public propertyImages", () => {
    const analyzeStart = source.indexOf("analyze: adminProcedure");
    const confirmStart = source.indexOf("confirm: adminProcedure");
    const analyzeSource = source.slice(analyzeStart, confirmStart);
    expect(analyzeSource).not.toContain("createPropertyImage");
    expect(analyzeSource).toContain("isPublicImage: false");
    expect(analyzeSource).toContain("createLegalDocumentScan");
  });

  it("exposes protected scan lifecycle and legal-field confirmation", () => {
    expect(source).toContain("legalDocuments: router({");
    expect(source).toContain("analyze: adminProcedure");
    expect(source).toContain("confirm: adminProcedure");
    expect(source).toContain("reject: adminProcedure");
    expect(source).toContain("certificateArea");
    expect(source).toContain("legalSource");
    expect(source).toContain("Kết quả chỉ hỗ trợ nhập liệu");
  });
});
