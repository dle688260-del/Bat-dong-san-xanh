import { useRef, useState } from "react";
import { MapPin, Navigation, Search, StickyNote } from "lucide-react";
import { MapView } from "@/components/Map";

const DA_NANG_CENTER = { lat: 16.0544, lng: 108.2022 };

export default function CrmLocationSurvey() {
  const mapRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [status, setStatus] = useState("Nhập địa chỉ để định vị trên bản đồ.");
  const [mapError, setMapError] = useState(false);

  const locateAddress = () => {
    const query = address.trim();
    if (!query || !mapRef.current || !window.google) {
      setStatus("Cần nhập địa chỉ và chờ bản đồ tải xong.");
      return;
    }

    setStatus("Đang tìm vị trí…");
    new window.google.maps.Geocoder().geocode({ address: query, region: "VN" }, (results, geocodeStatus) => {
      const location = results?.[0]?.geometry.location;
      if (geocodeStatus !== "OK" || !location) {
        setStatus("Chưa tìm thấy vị trí. Hãy thử thêm phường/xã và tỉnh/thành.");
        return;
      }
      mapRef.current?.panTo(location);
      mapRef.current?.setZoom(16);
      markerRef.current?.setMap(null);
      markerRef.current = new window.google.maps.Marker({ map: mapRef.current, position: location, title: query });
      setStatus(`Đã định vị: ${results[0].formatted_address}`);
    });
  };

  return (
    <section data-responsive-section="CRM Location Survey" className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">Khảo sát khu vực</p>
          <h2 className="mt-2 font-serif text-2xl text-[#173b35]">Định vị BĐS & xem đường đi</h2>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">Ghim địa chỉ lên bản đồ để chuẩn bị khảo sát, ghi chú thực tế và xem nhanh khu vực xung quanh.</p>
        </div>
        <span className="flex items-center gap-2 rounded-full bg-[#e7f1e9] px-3 py-2 text-xs font-bold text-[#1e6a59]"><Navigation className="h-4 w-4" />Bản đồ trực tiếp</span>
      </div>

      <div className="mt-5 grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-[#527068]">Địa chỉ hoặc mã vị trí<input value={address} onChange={event => setAddress(event.target.value)} onKeyDown={event => event.key === "Enter" && locateAddress()} placeholder="Ví dụ: đường Nguyễn Văn Linh, Đà Nẵng" className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <button type="button" onClick={locateAddress} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#173f36] px-4 py-3 text-sm font-bold text-white transition-colors hover:bg-[#245b4d]"><Search className="h-4 w-4" />Định vị trên bản đồ</button>
          <div className="rounded-2xl bg-[#e7f1e9] p-4 text-sm leading-6 text-[#527068]"><div className="flex items-center gap-2 font-bold text-[#173b35]"><MapPin className="h-4 w-4 text-[#25725e]" />Trạng thái khảo sát</div><p className="mt-2">{status}</p></div>
          <label className="block text-sm font-semibold text-[#527068]"><span className="flex items-center gap-2"><StickyNote className="h-4 w-4 text-[#25725e]" />Ghi chú thực tế</span><textarea value={note} onChange={event => setNote(event.target.value)} rows={5} placeholder="Độ rộng đường, hướng tiếp cận, tiện ích gần đó, tình trạng thực tế…" className="mt-1.5 w-full resize-none rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
        </div>
        <div className="overflow-hidden rounded-2xl border border-[#dce7df] bg-[#edf5ef]">
          {mapError ? <div className="flex h-[360px] min-h-[360px] flex-col items-center justify-center px-8 text-center"><MapPin className="h-10 w-10 text-[#b48a36]" /><p className="mt-3 font-bold text-[#173b35]">Bản đồ trực tiếp chưa tải được</p><p className="mt-2 text-sm leading-6 text-[#688078]">Bạn vẫn có thể lưu địa chỉ và ghi chú khảo sát. Khi kết nối bản đồ hoạt động, hãy mở lại để định vị và xem tiện ích xung quanh.</p></div> : <MapView className="h-[360px] min-h-[360px]" initialCenter={DA_NANG_CENTER} initialZoom={12} onMapReady={map => { mapRef.current = map; setMapError(false); }} onMapError={() => { setMapError(true); setStatus("Bản đồ tạm thời không tải được; hãy lưu địa chỉ để kiểm tra sau."); }} />}
        </div>
      </div>
      <p className="mt-4 text-xs leading-5 text-[#688078]">Bản đồ và chỉ đường là công cụ hỗ trợ khảo sát. Độ rộng đường, hiện trạng xây dựng, khoảng cách thực tế và thông tin quy hoạch cần được môi giới kiểm tra tại hiện trường hoặc đối chiếu nguồn chính thức.</p>
    </section>
  );
}
