/**
 * Mã TTHC đất đai được trích từ Phụ lục công bố kèm Quyết định
 * 2304/QĐ-BNNMT ngày 23/06/2025 của Bộ Nông nghiệp và Môi trường.
 *
 * Đây là chỉ mục mã, không phải allowlist binary. Các mã này được đưa vào
 * catalog với trạng thái Pending cho tới khi tên, quy trình, thành phần và
 * tệp mẫu được đối chiếu đầy đủ từ trang chi tiết/nguồn chính thức.
 */
export const OFFICIAL_2304_PROCEDURE_CODES = [
  "1.012750", "1.012751", "1.012752", "1.012753", "1.012754", "1.012755",
  "1.012756", "1.012757", "1.012758", "1.012759", "1.012760", "1.012761",
  "1.012762", "1.012763", "1.012764", "1.012765", "1.012766", "1.012768",
  "1.012769", "1.012770", "1.012771", "1.012772", "1.012773", "1.012774",
  "1.012775", "1.012776", "1.012777", "1.012778", "1.012779", "1.012780",
  "1.012781", "1.012782", "1.012783", "1.012784", "1.012785", "1.012786",
  "1.012787", "1.012788", "1.012789", "1.012790", "1.012791", "1.012792",
  "1.012793", "1.012794", "1.012795", "1.012796", "1.012802", "1.012803",
  "1.012804", "1.012805", "1.012806", "1.012807", "1.012808", "1.012809",
  "1.012810", "1.012811", "1.012812", "1.012813", "1.012814", "1.012815",
  "1.012816", "1.012817", "1.012818", "1.012819", "1.012820", "1.012821",
] as const;

export const OFFICIAL_2304_SOURCE_URL =
  "https://mae.gov.vn/Pages/chitietvanbandh.aspx?ItemID=3305";

export const OFFICIAL_2304_CODE_INDEX_NOTICE =
  "Mã được xác nhận trong Phụ lục Quyết định 2304/QĐ-BNNMT; tên thủ tục và tệp mẫu vẫn cần đối soát trước khi dùng.";

/** Tên đã đối soát từ Phụ lục Quyết định 2304/QĐ-BNNMT. */
export const VERIFIED_2304_PROCEDURE_NAMES: Readonly<Record<string, string>> = {
  "1.012750": "Cung cấp thông tin, dữ liệu đất đai",
  "1.012751": "Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Nông nghiệp và Môi trường",
  "1.012752": "Giao đất, cho thuê đất không thông qua hình thức đấu giá quyền sử dụng đất, không đấu thầu lựa chọn nhà đầu tư thực hiện dự án có sử dụng đất đối với trường hợp thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư mà người xin giao đất, thuê đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012753": "Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất lần đầu đối với tổ chức đang sử dụng đất.",
  "1.012754": "Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất lần đầu đối với người gốc Việt Nam định cư ở nước ngoài",
  "1.012755": "Giao đất, cho thuê đất không thông qua hình thức đấu giá quyền sử dụng đất, không đấu thầu lựa chọn nhà đầu tư thực hiện dự án có sử dụng đất đối với trường hợp không thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo pháp luật về đầu tư mà người xin giao đất, thuê đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012756": "Đăng ký đất đai lần đầu đối với trường hợp được Nhà nước giao đất để quản lý",
  "1.012757": "Giao đất, cho thuê đất thông qua đấu thầu lựa chọn nhà đầu tư thực hiện dự án có sử dụng đất",
  "1.012758": "Cho phép chuyển mục đích sử dụng đất đối với trường hợp thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đầu tư mà người xin chuyển mục đích sử dụng đất là tổ chức trong nước",
  "1.012759": "Cho phép chuyển mục đích sử dụng đất đối với trường hợp không thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đầu tư mà người xin chuyển mục đích sử dụng đất là tổ chức trong nước",
  "1.012760": "Chuyển hình thức giao đất, cho thuê đất mà người sử dụng đất là tổ chức kinh tế, đơn vị sự nghiệp công lập, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài",
  "1.012761": "Giao đất, cho thuê đất từ quỹ đất do tổ chức, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài sử dụng đất quy định tại Điều 180 Luật Đất đai, do công ty nông, lâm trường quản lý, sử dụng quy định tại Điều 181 Luật Đất đai Đất đai mà người xin giao đất, cho thuê đất là tổ chức trong nước, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài",
  "1.012762": "Điều chỉnh quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất do thay đổi căn cứ quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất mà người sử dụng đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012763": "Điều chỉnh quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất do sai sót về ranh giới, vị trí, diện tích, mục đích sử dụng giữa bản đồ quy hoạch, bản đồ địa chính, quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất và số liệu bàn giao đất trên thực địa mà người sử dụng đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012764": "Chấp thuận tổ chức kinh tế nhận chuyển nhượng, thuê quyền sử dụng đất, nhận góp vốn bằng quyền sử dụng đất để thực hiện dự án",
  "1.012765": "Đăng ký biến động quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất trong các trường hợp chuyển đổi quyền sử dụng đất nông nghiệp mà không theo phương án dồn điền, đổi thửa, chuyển nhượng, thừa kế, tặng cho quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất, góp vốn bằng quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất; cho thuê, cho thuê lại quyền sử dụng đất trong dự án xây dựng kinh doanh kết cấu hạ tầng",
  "1.012766": "Xóa đăng ký thuê, cho thuê lại quyền sử dụng đất trong dự án xây dựng kinh doanh kết cấu hạ tầng",
  "1.012768": "Đăng ký biến động đối với trường hợp đổi tên hoặc thay đổi thông tin về người sử dụng đất, chủ sở hữu tài sản gắn liền với đất; thay đổi hạn chế quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất hoặc có thay đổi quyền đối với thửa đất liền kề; giảm diện tích thửa đất do sạt lở tự nhiên",
  "1.012769": "Đăng ký tài sản gắn liền với thửa đất đã được cấp Giấy chứng nhận hoặc đăng ký thay đổi về tài sản gắn liền với đất so với nội dung đã đăng ký",
  "1.012770": "Đăng ký biến động thay đổi quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất do chia, tách, hợp nhất, sáp nhập tổ chức hoặc chuyển đổi mô hình tổ chức",
  "1.012771": "Giao đất, cho thuê đất không thông qua hình thức đấu giá quyền sử dụng đất, không đấu thầu lựa chọn nhà đầu tư thực hiện dự án có sử dụng đất đối với trường hợp thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đầu tư mà người xin giao đất, thuê đất là cá nhân",
  "1.012772": "Đăng ký biến động đối với trường hợp thay đổi quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất theo thỏa thuận của các thành viên hộ gia đình hoặc của vợ và chồng; quyền sử dụng đất xây dựng công trình trên mặt đất phục vụ cho việc vận hành, khai thác sử dụng công trình ngầm, quyền sở hữu công trình ngầm; bán tài sản, điều chuyển, chuyển nhượng quyền sử dụng đất là tài sản công theo quy định của pháp luật về quản lý, sử dụng tài sản công; nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất theo kết quả giải quyết tranh chấp, khiếu nại, tố cáo về đất đai; nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất do xử lý tài sản thế chấp là quyền sử dụng đất, tài sản gắn liền với đất đã được đăng ký, bao gồm cả xử lý khoản nợ có nguồn gốc từ khoản nợ xấu của tổ chức tín dụng, chi nhánh ngân hàng nước ngoài",
  "1.012773": "Giao đất, cho thuê đất không thông qua hình thức đấu giá quyền sử dụng đất, không đấu thầu lựa chọn nhà đầu tư thực hiện dự án có sử dụng đất đối với trường hợp không thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đầu tư mà người xin giao đất, thuê đất là cá nhân",
  "1.012774": "Cho phép chuyển mục đích sử dụng đất đối với trường hợp thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đầu tư mà người xin giao đất, thuê đất là cá nhân",
  "1.012775": "Cho phép chuyển mục đích sử dụng đất đối với trường hợp không thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đất đai mà người xin chuyển mục đích sử dụng đất là hộ gia đình, cá nhân",
  "1.012776": "Chuyển hình thức giao đất, cho thuê đất mà người sử dụng đất là hộ gia đình, cá nhân",
  "1.012777": "Điều chỉnh quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất do thay đổi căn cứ quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất mà người sử dụng đất là hộ gia đình, cá nhân",
  "1.012778": "Điều chỉnh quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất do sai sót về ranh giới, vị trí, diện tích, mục đích sử dụng giữa bản đồ quy hoạch, bản đồ địa chính, quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất và số liệu bàn giao đất trên thực địa mà người sử dụng đất là hộ gia đình, cá nhân",
  "1.012779": "Giao đất, cho thuê đất mà người sử dụng đất là cá nhân, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài sử dụng đất quy định tại Điều 180 Luật Đất đai, do công ty nông, lâm trường quản lý, sử dụng quy định tại Điều 181 Luật Đất đai mà người xin giao đất, cho thuê đất là cá nhân",
  "1.012780": "Giao đất ở có thu tiền sử dụng đất không thông qua đấu giá, không đấu thầu lựa chọn nhà đầu tư thực hiện dự án có sử dụng đất đối với cá nhân là cán bộ, công chức, viên chức, sĩ quan tại ngũ, quân nhân chuyên nghiệp, công chức quốc phòng, công nhân và viên chức quốc phòng, sĩ quan, hạ sĩ quan, công nhân công an, người làm công tác cơ yếu và người làm công tác khác trong tổ chức cơ yếu hưởng lương từ ngân sách nhà nước mà chưa được giao đất ở, nhà ở; giáo viên, nhân viên y tế đang công tác tại các xã biên giới, hải đảo thuộc vùng có điều kiện kinh tế - xã hội khó khăn, vùng có điều kiện kinh tế - xã hội đặc biệt khó khăn nhưng chưa có đất ở, nhà ở tại nơi công tác hoặc chưa được hưởng chính sách hỗ trợ về nhà ở theo quy định của pháp luật về nhà ở; cá nhân thường trú tại xã mà không có đất ở và chưa được Nhà nước giao đất ở hoặc chưa được hưởng chính sách hỗ trợ về nhà ở theo quy định của pháp luật về nhà ở; cá nhân thường trú tại thị trấn thuộc vùng có điều kiện kinh tế - xã hội khó khăn, vùng có điều kiện kinh tế - xã hội đặc biệt khó khăn mà không có đất ở và chưa được Nhà nước giao đất ở",
  "1.012781": "Đăng ký, cấp Giấy chứng nhận đối với thửa đất có diện tích tăng thêm do thay đổi ranh giới so với Giấy chứng nhận đã cấp",
  "1.012782": "Đăng ký, cấp Giấy chứng nhận đối với trường hợp cá nhân, hộ gia đình đã được cấp Giấy chứng nhận một phần diện tích vào loại đất ở trước ngày 01 tháng 7 năm 2004, phần diện tích còn lại của thửa đất chưa được cấp Giấy chứng nhận",
  "1.012783": "Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất",
  "1.012784": "Tách thửa hoặc hợp thửa đất",
  "1.012785": "Đăng ký, cấp Giấy chứng nhận đối với trường hợp đã chuyển quyền sử dụng đất trước ngày 01 tháng 8 năm 2024 mà bên chuyển quyền đã được cấp Giấy chứng nhưng chưa thực hiện thủ tục chuyển quyền theo quy định",
  "1.012786": "Cấp lại Giấy chứng nhận do bị mất",
  "1.012787": "Đăng ký, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất cho người nhận chuyển nhượng quyền sử dụng đất, quyền sở hữu nhà ở, công trình xây dựng trong dự án bất động sản",
  "1.012788": "Đăng ký đất đai đối với trường hợp chuyển nhượng dự án bất động sản",
  "1.012789": "Cung cấp thông tin, dữ liệu đất đai",
  "1.012790": "Đính chính Giấy chứng nhận đã cấp",
  "1.012791": "Thu hồi Giấy chứng nhận đã cấp không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi",
  "1.012792": "Gia hạn sử dụng đất khi hết thời hạn sử dụng đất mà người xin gia hạn sử dụng đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012793": "Đăng ký biến động đối với trường hợp thành viên của hộ gia đình hoặc cá nhân đang sử dụng đất thành lập doanh nghiệp tư nhân và sử dụng đất vào hoạt động sản xuất kinh doanh của doanh nghiệp",
  "1.012794": "Đăng ký biến động đối với trường hợp điều chỉnh quy hoạch xây dựng chi tiết; cấp Giấy chứng nhận cho từng thửa đất theo quy hoạch xây dựng chi tiết cho chủ đầu tư dự án có nhu cầu",
  "1.012795": "Xóa ghi nợ tiền sử dụng đất, lệ phí trước bạ",
  "1.012796": "Đính chính Giấy chứng nhận đã cấp lần đầu có sai sót",
  "1.012802": "Điều chỉnh thời hạn sử dụng đất của dự án đầu tư mà người sử dụng đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012803": "Sử dụng đất kết hợp đa mục đích mà người sử dụng là tổ chức",
  "1.012804": "Giao đất, cho thuê đất, giao khu vực biển để thực hiện hoạt động lấn biển mà người xin giao đất, thuê đất là tổ chức trong nước, tổ chức tôn giáo, tổ chức tôn giáo trực thuộc, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài, tổ chức nước ngoài có chức năng ngoại giao",
  "1.012805": "Giải quyết tranh chấp đất đai thuộc thẩm quyền của Chủ tịch Ủy ban nhân dân cấp tỉnh",
  "1.012808": "Xác nhận tiếp tục sử dụng đất nông nghiệp của cá nhân khi hết hạn sử dụng đất.",
  "1.012806": "Giao đất, cho thuê đất, giao khu vực biển để thực hiện hoạt động lấn biển mà người xin giao đất, thuê đất là cá nhân",
  "1.012807": "Gia hạn sử dụng đất khi hết thời hạn sử dụng đất mà người xin gia hạn sử dụng đất là cá nhân, cộng đồng dân cư",
  "1.012809": "Điều chỉnh thời hạn sử dụng đất của dự án đầu tư mà người sử dụng đất là cá nhân, cộng đồng dân cư",
  "1.012810": "Sử dụng đất kết hợp đa mục đích mà người sử dụng là cá nhân",
  "1.012811": "Giải quyết tranh chấp đất đai thuộc thẩm quyền của Chủ tịch UBND cấp huyện",
  "1.012812": "Hòa giải tranh chấp đất đai thuộc thẩm quyền cấp xã",
  "1.012813": "Đăng ký đất đai, tài sản gắn liền với đất đối với trường hợp hộ gia đình, cá nhân đang sử dụng đất không đúng mục đích đã được Nhà nước giao đất, cho thuê đất, công nhận quyền sử dụng đất trước ngày 01 tháng 7 năm 2014",
  "1.012814": "Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất lần đầu đối với cá nhân, cộng đồng dân cư, hộ gia đình đang sử dụng đất",
  "1.012815": "Đăng ký chuyển mục đích sử dụng đất không phải xin phép cơ quan nhà nước có thẩm quyền",
  "1.012816": "Đăng ký, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất đối với trường hợp tặng cho quyền sử dụng đất cho Nhà nước hoặc cộng đòng dân cư hoặc mở rộng đường giao thông",
  "1.012817": "Xác định lại diện tích đất ở của hộ gia đình, cá nhân đã được cấp Giấy chứng nhận trước ngày 01 tháng 7 năm 2004",
  "1.012818": "Thu hồi Giấy chứng nhận đã cấp không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi",
  "1.012819": "Cấp lại Giấy chứng nhận do bị mất",
  "1.012820": "Bán hoặc góp vốn bằng tài sản gắn liền với đất thuê của Nhà nước theo hình thức thuê đất trả tiền hàng năm",
  "1.012821": "Thẩm định, phê duyệt phương án sử dụng đất",
};

export function getVerified2304ProcedureName(code: string): string | undefined {
  return VERIFIED_2304_PROCEDURE_NAMES[code.trim().replace(/\s+/g, "")];
}
