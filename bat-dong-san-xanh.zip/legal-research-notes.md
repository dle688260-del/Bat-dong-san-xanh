# Ghi chú khảo sát nguồn pháp lý đất đai — 2026-08-17

## Nguồn chính thức cần ưu tiên

1. Cổng Dịch vụ công Quốc gia — thủ tục Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất:
   https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978

2. Cổng Dịch vụ công Quốc gia — thủ tục Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất:
   https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783

3. Cổng Dịch vụ công Quốc gia — thủ tục Cung cấp thông tin, dữ liệu đất đai:
   https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789

4. Cổng Thông tin điện tử Chính phủ — hệ thống văn bản:
   https://chinhphu.vn/he-thong-van-ban

5. Cổng Xây dựng Chính sách, Pháp luật của Chính phủ — chuyên mục Luật Đất đai:
   https://xaydungchinhsach.chinhphu.vn/luat-dat-dai.html

6. Báo Điện tử Chính phủ — bài cập nhật một số quy định mới về đất đai, có đề cập Nghị định 226/2025/NĐ-CP sửa đổi, bổ sung một số nghị định hướng dẫn Luật Đất đai:
   https://baochinhphu.vn/mot-so-quy-dinh-moi-ve-dat-dai-10225081618150637.htm

## Ghi chú kiểm chứng

Kết quả tìm kiếm cho thấy có nhiều nguồn thứ cấp tổng hợp văn bản, nhưng hệ thống nên lấy bản gốc từ Cổng Dịch vụ công Quốc gia, Cổng Chính phủ, Cơ sở dữ liệu quốc gia về văn bản pháp luật và cổng dịch vụ công địa phương. Không dùng riêng bài tổng hợp thương mại làm nguồn pháp lý cuối cùng.

Cần lưu theo từng thủ tục: mã thủ tục, tên thủ tục, cơ quan tiếp nhận, địa bàn áp dụng, thành phần hồ sơ, biểu mẫu/URL tải xuống, văn bản căn cứ, ngày ban hành, ngày hiệu lực, ngày kiểm tra cuối cùng và trạng thái cần cán bộ rà soát.

## Kết luận sơ bộ

Có thể tích hợp lớp dữ liệu nguồn chính thức và cho AI dùng các nguồn đã kiểm duyệt để lập checklist, điền dự thảo và xuất file. File xuất ra phải gắn nguồn, phiên bản, ngày cập nhật và cảnh báo “bản dự thảo — cần rà soát, ký và đối chiếu yêu cầu của cơ quan tiếp nhận trước khi nộp”; không được tự tuyên bố là văn bản được cơ quan nhà nước chứng nhận.

## Kết quả đọc trực tiếp nguồn chính thức

Trang thủ tục của Cổng Dịch vụ công Quốc gia cho thủ tục đăng ký đất đai/cấp Giấy chứng nhận lần đầu hiển thị tên thủ tục, liên kết chi tiết, trình tự nhiều bước và yêu cầu hồ sơ số hóa từ bản chính hoặc bản sao công chứng/chứng thực khi nộp trực tuyến. Trang cũng nêu việc cơ quan tiếp nhận kiểm tra thành phần hồ sơ, cấp giấy tiếp nhận/hẹn trả kết quả và có thể yêu cầu bổ sung. Nội dung hiển thị viện dẫn các mẫu số 16, 17, 19 theo Nghị định 151/2025/NĐ-CP trong quy trình cụ thể. Điều này cho thấy ứng dụng phải lưu thủ tục theo mã và địa bàn, không chỉ lưu tên mẫu chung.

Nguồn Xây dựng Chính sách, Pháp luật của Chính phủ đang hiển thị nhiều văn bản cập nhật trong năm 2026, trong đó có Văn bản hợp nhất 73/2026/VBHN-NĐ-BNNMT về xử phạt vi phạm hành chính lĩnh vực đất đai, Văn bản 90/VBHN-BNNMT hợp nhất các nghị định hướng dẫn Luật Đất đai, Nghị định 49/2026/NĐ-CP, Nghị định 50/2026/NĐ-CP và các nội dung về Nghị định 226/2025/NĐ-CP. Danh mục này có thể thay đổi, vì vậy không được hardcode một danh sách cố định mà cần cơ chế kiểm duyệt và cập nhật phiên bản.

Nguồn đọc trực tiếp:
- https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
- https://xaydungchinhsach.chinhphu.vn/luat-dat-dai.html

## Kiểm chứng thêm trên Hệ thống văn bản Chính phủ

Luật số 31/2024/QH15 là Luật Đất đai, ban hành ngày 18-01-2024, có hiệu lực theo trang văn bản là 01-01-2025, cơ quan ban hành là Quốc hội, và có ba tệp PDF đính kèm trên trang chính thức: https://vanban.chinhphu.vn/?pageid=27160&docid=211189.

Một lần mở URL docid không đúng đã trả về Thông báo 333/TB-VPCP, không phải Nghị định 151/2025/NĐ-CP. Không dùng kết quả đó làm nguồn pháp lý. Cần lấy lại đúng URL Nghị định 151 từ kết quả tìm kiếm hoặc hệ thống văn bản trước khi tích hợp.

Nghị định số 151/2025/NĐ-CP trên Hệ thống văn bản Chính phủ: ban hành 12-06-2025, có hiệu lực 01-07-2025, cơ quan ban hành Chính phủ, trích yếu về phân định thẩm quyền chính quyền địa phương 02 cấp, phân quyền và phân cấp trong lĩnh vực đất đai; có tệp 151-ndcp.signed.pdf. URL: https://vanban.chinhphu.vn/?pageid=27160&docid=213927.

## Biểu mẫu và trình tự chính thức đã kiểm chứng — 17/08/2026

### 1) Đăng ký đất đai, cấp Giấy chứng nhận lần đầu
Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=385508

Trang chính thức nêu phương thức nộp, thời hạn theo trường hợp và yêu cầu hồ sơ. Thành phần có **Đơn đăng ký đất đai, tài sản gắn liền với đất**, tệp mẫu `Mus15DKLD.docx`, cùng giấy tờ theo trường hợp, giấy tờ đại diện, mảnh trích đo và chứng từ nghĩa vụ tài chính nếu có. Trình tự gồm nộp hồ sơ, kiểm tra/cấp phiếu tiếp nhận, chuyển cơ quan có thẩm quyền, xử lý và trả kết quả; hồ sơ trực tuyến phải được số hóa từ bản chính hoặc bản sao công chứng/chứng thực.

### 2) Tách thửa hoặc hợp thửa
Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784
Chi tiết: https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=348171

Nguồn chính thức yêu cầu **Đơn đề nghị tách thửa đất, hợp thửa đất theo Mẫu số 21** và **Bản vẽ tách thửa đất, hợp thửa đất theo Mẫu số 22**, ban hành kèm Nghị định 151/2025/NĐ-CP; trang có liên kết tải `Mus21.docx` và `Mus22.docx`. Hồ sơ còn có Giấy chứng nhận đã cấp và văn bản liên quan nếu có. Trình tự gồm nộp hồ sơ, kiểm tra/cấp phiếu tiếp nhận, kiểm tra điều kiện theo Điều 220 Luật Đất đai, xác nhận hoặc trả hồ sơ; điều kiện diện tích tối thiểu phải theo quy định UBND cấp tỉnh.

### 3) Đăng ký biến động do chuyển nhượng/cho thuê/thừa kế/tặng cho
Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410

Nguồn chính thức nêu **Đơn đăng ký biến động đất đai, tài sản gắn liền với đất theo Mẫu số 09/ĐK**, liên kết tệp `Mau so 09-DK.pdf`; hồ sơ tùy trường hợp còn có hợp đồng/văn bản chuyển quyền, bản gốc Giấy chứng nhận và giấy tờ bổ sung. Quy trình gồm nộp hồ sơ, kiểm tra/cấp phiếu tiếp nhận, kiểm tra điều kiện, gửi thông tin địa chính cho cơ quan thuế, xác nhận biến động/cấp Giấy chứng nhận, cập nhật cơ sở dữ liệu và trả kết quả.

### 4) Giao đất/cho thuê đất/chuyển mục đích trong thủ tục tương ứng
Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013949

Nguồn chính thức nêu trình tự nhiều bước gồm tiếp nhận, rà soát/kiểm tra, trình cấp có thẩm quyền, xác định nghĩa vụ tài chính, ban hành quyết định và cập nhật hồ sơ địa chính. Có các mẫu ban hành kèm Nghị định 151/2025/NĐ-CP như **Mẫu số 01, 06, 09, 19, 24, 25 và 26** tùy trường hợp. Cần phân loại đúng thủ tục và địa bàn trước khi chọn mẫu; không dùng chung các mẫu này cho mọi hồ sơ.

### Kết luận triển khai
Hệ thống phải lưu URL mẫu gốc hoặc liên kết tải gốc, số hiệu mẫu, văn bản ban hành, mã thủ tục, địa phương, ngày kiểm tra và trạng thái kiểm duyệt. AI có thể chọn thủ tục, dựng dữ liệu điền vào mẫu và ghép checklist/trình tự; người dùng phải xem, chỉnh sửa, xác nhận và đối chiếu bản gốc trước khi xuất bản in cuối. Không gọi bản AI dựng là văn bản nhà nước chứng nhận nếu chưa dùng đúng tệp mẫu chính thức và chưa hoàn tất chữ ký/xác nhận theo yêu cầu cơ quan tiếp nhận.
