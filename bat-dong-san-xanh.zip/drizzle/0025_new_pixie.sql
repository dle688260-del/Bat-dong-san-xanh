CREATE TABLE `property_3d_annotations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`propertyId` int NOT NULL,
	`assetUrl` text NOT NULL,
	`assetFileName` varchar(255),
	`title` varchar(160) NOT NULL,
	`body` text,
	`tag` varchar(80),
	`positionX` decimal(8,5) NOT NULL,
	`positionY` decimal(8,5) NOT NULL,
	`positionZ` decimal(8,5) NOT NULL,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `property_3d_annotations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `property_3d_annotations` ADD CONSTRAINT `property_3d_annotations_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_3d_annotations` ADD CONSTRAINT `property_3d_annotations_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;