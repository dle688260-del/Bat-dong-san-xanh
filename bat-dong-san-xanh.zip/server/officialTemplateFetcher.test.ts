import { describe, expect, it, vi, afterEach } from "vitest";
import { buildPublicTemplateSearchQueries, discoverOfficialTemplateFallbacks, downloadOfficialTemplateCandidate, downloadPublicReferenceCandidate, downloadTemplateWithPublicFallback } from "./officialTemplateFetcher";

afterEach(() => vi.restoreAllMocks());

describe("official template fallback discovery", () => {
  it("giữ file mẫu khớp mã Mẫu 14 và bỏ qua PDF pháp lý không khớp", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(`
      <a href="https://www.monre.gov.vn/files/Mau14.docx">Mẫu 14</a>
      <a href="https://www.monre.gov.vn/files/Nghi-dinh-101.pdf">Nghị định 101</a>
    `, { status: 200, headers: { "content-type": "text/html" } })));
    const result = await discoverOfficialTemplateFallbacks({
      sourceUrls: ["https://www.monre.gov.vn/"],
      procedureName: "Cung cấp thông tin dữ liệu đất đai",
      templateNames: ["Mẫu số 14"],
      templateCodes: ["14"],
    });
    expect(result.candidates).toHaveLength(1);
    expect(result.candidates[0]?.fileName).toBe("Mau14.docx");
    expect(result.candidates[0]?.discovery).toBe("official_fallback");
  });

  it("tải binary DOCX và tạo checksum SHA-256", async () => {
    const bytes = new Uint8Array([...new Uint8Array([0x50, 0x4b, 0x03, 0x04]), ...new TextEncoder().encode("[Content_Types].xml")]);
    vi.stubGlobal("fetch", vi.fn(async () => new Response(bytes, {
      status: 200,
      headers: { "content-type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document" },
    })));
    const result = await downloadOfficialTemplateCandidate({ candidateUrl: "https://datafiles.chinhphu.vn/mau14.docx" });
    expect(result.bytes.length).toBeGreaterThan(20);
    expect(result.checksum).toMatch(/^[a-f0-9]{64}$/);
    expect(result.fileName).toBe("mau14.docx");
  });

  it("sinh các truy vấn công khai cho MFS14 và không suy ra Official", () => {
    const queries = buildPublicTemplateSearchQueries({
      procedureCode: "1.012789",
      procedureName: "Cung cấp thông tin dữ liệu đất đai",
      componentName: "Phiếu yêu cầu cung cấp thông tin",
      templateNames: ["Mẫu số 14"],
      templateCodes: ["MFS14"],
    });
    expect(queries.some(query => query.includes("MFS14"))).toBe(true);
    expect(queries.some(query => query.includes("site:gov.vn"))).toBe(true);
    expect(new Set(queries).size).toBe(queries.length);
  });

  it("fallback sang file công khai khi nguồn Official trả 503 và giữ matched_reference", async () => {
    let calls = 0;
    vi.stubGlobal("fetch", vi.fn(async () => {
      calls += 1;
      if (calls === 1) return new Response("", { status: 503 });
      return new Response(new TextEncoder().encode("%PDF-1.7 public"), {
        status: 200,
        headers: { "content-type": "application/pdf" },
      });
    }));
    const result = await downloadTemplateWithPublicFallback({
      officialUrl: "https://vpcp.dichvucong.gov.vn/files/Mau14.pdf",
      publicUrls: ["https://cdn.example.org/Mau14.pdf"],
    });
    expect(result.status).toBe("matched_reference");
    expect(result.officialEligible).toBe(false);
    expect(calls).toBe(2);
  });

  it("đánh dấu file tìm từ web là reference_only, không đủ điều kiện Official", async () => {
    const bytes = new TextEncoder().encode("%PDF-1.7 reference");
    vi.stubGlobal("fetch", vi.fn(async () => new Response(bytes, {
      status: 200,
      headers: { "content-type": "application/pdf" },
    })));
    const result = await downloadPublicReferenceCandidate({ candidateUrl: "https://cdn.example.org/Mau14.pdf" });
    expect(result.provenance).toBe("reference_only");
    expect(result.officialEligible).toBe(false);
    expect(result.signatureOk).toBe(true);
  });
});


  it("cho phép CDN thuộc Cổng Chính phủ khi tải binary Official", async () => {
    const bytes = new Uint8Array([...new Uint8Array([0x50, 0x4b, 0x03, 0x04]), ...new TextEncoder().encode("[Content_Types].xml")]);
    vi.stubGlobal("fetch", vi.fn(async () => new Response(bytes, {
      status: 200,
      headers: { "content-type": "application/octet-stream" },
    })));
    const result = await downloadOfficialTemplateCandidate({ candidateUrl: "https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/11/don-17225006379202035387597.docx" });
    expect(result.sourceUrl).toContain("xdcs.cdnchinhphu.vn");
    expect(result.checksum).toMatch(/^[a-f0-9]{64}$/);
  });
