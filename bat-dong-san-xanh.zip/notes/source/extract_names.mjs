import fs from 'node:fs';

const input = '/home/ubuntu/upload/luatvietnam.vn_tai-nguyen_quyet-dinh-2304-qd-bnnmt-2025-cong-bo-thu-tuc-hanh-chinh-linh-vuc-dat-dai-_1787480522420.md';
const text = fs.readFileSync(input, 'utf8');
const rows = [];
const rowPattern = /\|\s*(?:\d+)?\s*\|\s*(1\\?\.012\d{3})\s*\|([\s\S]*?)\|/g;
for (const match of text.matchAll(rowPattern)) {
  const code = match[1].replace(/\\/g, '');
  const name = match[2].replace(/\\+/g, '').replace(/\s+/g, ' ').trim();
  if (name && !name.startsWith('---')) rows.push({ code, name });
}
const unique = [...new Map(rows.map((row) => [row.code, row])).values()];
fs.writeFileSync('/home/ubuntu/bat-dong-san-xanh/notes/source/2304-names-extracted.json', JSON.stringify(unique, null, 2) + '\n');
console.log(`extracted=${unique.length}`);
console.log(unique.map((row) => `${row.code}\t${row.name}`).join('\n'));
