CREATE TABLE `property_dossier_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`dossierId` int NOT NULL,
	`stepNumber` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`url` text NOT NULL,
	`storageKey` text NOT NULL,
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `property_dossier_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `property_dossier_steps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`dossierId` int NOT NULL,
	`stepNumber` int NOT NULL,
	`status` enum('completed','in_progress','not_started','needs_review') NOT NULL DEFAULT 'not_started',
	`details` text,
	`notes` text,
	`completedAt` timestamp,
	`updatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `property_dossier_steps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `property_dossiers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`propertyId` int NOT NULL,
	`status` enum('active','completed','paused') NOT NULL DEFAULT 'active',
	`currentStep` int NOT NULL DEFAULT 1,
	`assignedTo` int,
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `property_dossiers_id` PRIMARY KEY(`id`),
	CONSTRAINT `property_dossiers_propertyId_unique` UNIQUE(`propertyId`)
);
--> statement-breakpoint
ALTER TABLE `property_dossier_documents` ADD CONSTRAINT `property_dossier_documents_dossierId_property_dossiers_id_fk` FOREIGN KEY (`dossierId`) REFERENCES `property_dossiers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_dossier_documents` ADD CONSTRAINT `property_dossier_documents_uploadedBy_users_id_fk` FOREIGN KEY (`uploadedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_dossier_steps` ADD CONSTRAINT `property_dossier_steps_dossierId_property_dossiers_id_fk` FOREIGN KEY (`dossierId`) REFERENCES `property_dossiers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_dossier_steps` ADD CONSTRAINT `property_dossier_steps_updatedBy_users_id_fk` FOREIGN KEY (`updatedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_dossiers` ADD CONSTRAINT `property_dossiers_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_dossiers` ADD CONSTRAINT `property_dossiers_assignedTo_users_id_fk` FOREIGN KEY (`assignedTo`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_dossiers` ADD CONSTRAINT `property_dossiers_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;