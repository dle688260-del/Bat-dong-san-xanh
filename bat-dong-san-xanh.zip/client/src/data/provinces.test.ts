import { describe, expect, it } from "vitest";
import { PROVINCE_OPTIONS } from "./provinces";

describe("national province options", () => {
  it("contains the current 34 provincial-level units without duplicates", () => {
    expect(PROVINCE_OPTIONS).toHaveLength(34);
    expect(new Set(PROVINCE_OPTIONS).size).toBe(34);
    expect(PROVINCE_OPTIONS).toContain("Đà Nẵng");
    expect(PROVINCE_OPTIONS).toContain("Thành phố Hồ Chí Minh");
    expect(PROVINCE_OPTIONS).toContain("Tuyên Quang");
  });
});
