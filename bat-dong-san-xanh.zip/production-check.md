# Production verification

- Homepage: https://batdongsan-7bupubgw.manus.space/
- Management route: https://batdongsan-7bupubgw.manus.space/quan-ly
- Production `/quan-ly` without a session displays “Sign in to continue” and a Sign in button; no management data is exposed.
- The homepage check was performed before the new CTA changes were checkpointed, so the production homepage still reflects the prior checkpoint until the next checkpoint is saved.
