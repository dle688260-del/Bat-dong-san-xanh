import { describe, expect, it } from "vitest";
import { matchLegalTemplatesByEvidence } from "./legalTemplateMatcher";

const procedure = { id: 1, code: "TRANSFER", name: "Đăng ký biến động do chuyển nhượng", groupName: "Đất đai", aliases: "[\"sang tên\",\"chuyển nhượng\"]", authority: "Văn phòng đăng ký đất đai", defaultProvince: "Đà Nẵng", processingTime: null, feeNotes: null, conditions: "[\"hợp đồng chuyển nhượng\"]", workflow: "[\"công chứng\",\"nộp hồ sơ\"]", status: "active", sourceDocumentIds: "[10]", lastReviewedAt: null, createdAt: new Date(), updatedAt: new Date() } as const;
const requirements = [{ id: 1, procedureId: 1, sortOrder: 1, label: "Đơn đăng ký biến động", requirementType: "document", required: 1, fieldKey: null, sourceDocumentId: 10, notes: null, createdAt: new Date() }] as const;
const document = { id: 10, sourceId: 2, title: "Nghị định 101/2024/NĐ-CP", documentNumber: "101/2024/NĐ-CP", documentType: "Nghị định", issuingBody: "Chính phủ", sourceUrl: "https://vanban.chinhphu.vn", fileUrl: null, storageKey: null, mimeType: "application/pdf", contentText: "đăng ký biến động chuyển nhượng đơn đăng ký biến động", contentHash: "abc", status: "extracted", effectiveFrom: null, effectiveTo: null, checkedAt: new Date(), extractedBy: "test", warnings: null, createdAt: new Date(), updatedAt: new Date() } as const;

function template(overrides: Record<string, unknown> = {}) { return { id: 4, procedureId: 1, sourceId: 2, name: "Mẫu đơn đăng ký biến động", documentType: "Đơn đăng ký biến động", format: "pdf", sourceUrl: "https://vanban.chinhphu.vn/mau-09", storageKey: null, fileUrl: null, sourceDocumentId: 10, province: "Đà Nẵng", receivingAuthority: "Văn phòng đăng ký đất đai", jurisdictionScope: "provincial", provenance: "metadata_only", checksum: null, versionLabel: "2024", effectiveFrom: null, effectiveTo: null, status: "active", notes: null, createdAt: new Date(), updatedAt: new Date(), ...overrides } as const; }

describe("legalTemplateMatcher", () => {
  it("ranks a template from procedure and extracted legal evidence", () => {
    const [result] = matchLegalTemplatesByEvidence({ procedure, requirements, documents: [document], templates: [template()], province: "Đà Nẵng", receivingAuthority: "Văn phòng đăng ký đất đai" });
    expect(result.score).toBeGreaterThan(40);
    expect(result.matchedEvidence).toContain("dang");
    expect(result.eligibleForOfficial).toBe(false);
    expect(result.reason).toContain("binary");
  });

  it("never calls a metadata-only template Official even when text matches", () => {
    const [result] = matchLegalTemplatesByEvidence({ procedure, requirements, documents: [document], templates: [template({ provenance: "verified_binary", storageKey: "legal-templates/a.pdf", checksum: "sha256" })], province: "Đà Nẵng", receivingAuthority: "Văn phòng đăng ký đất đai" });
    expect(result.eligibleForOfficial).toBe(true);
  });
});
