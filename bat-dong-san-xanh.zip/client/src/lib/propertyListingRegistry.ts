export type ListingTransaction = "sale" | "rent";
export type ListingKind = "house" | "land" | "apartment" | "villa" | "industrial" | "commercial_land" | "agricultural" | "commercial" | "resort" | "project" | "rental";

export const LISTING_KIND_LABELS: Record<ListingKind, string> = {
  house: "Nhà phố",
  land: "Đất nền",
  apartment: "Căn hộ",
  villa: "Villa / Resort",
  industrial: "Khu công nghiệp",
  commercial_land: "Đất thương mại",
  agricultural: "Đất nông nghiệp",
  commercial: "Khu thương mại",
  resort: "Khu nghỉ dưỡng",
  project: "Đất dự án",
  rental: "Bất động sản cho thuê khác",
};

export type ListingField = {
  name: string;
  label: string;
  placeholder: string;
  kind?: "text" | "number" | "textarea";
  suffix?: string;
};

export type ListingProfile = {
  key: string;
  transaction: ListingTransaction;
  propertyType: ListingKind;
  label: string;
  eyebrow: string;
  titlePrefix: string;
  fields: ListingField[];
};

const commonLocation: ListingField[] = [
  { name: "location", label: "Vị trí", placeholder: "Địa chỉ/khu vực cụ thể" },
  { name: "area", label: "Diện tích", placeholder: "Ví dụ 200", kind: "number", suffix: "m²" },
  { name: "frontage", label: "Ngang", placeholder: "Ví dụ 5", kind: "number", suffix: "m" },
  { name: "depth", label: "Dài", placeholder: "Ví dụ 40", kind: "number", suffix: "m" },
  { name: "orientation", label: "Hướng", placeholder: "Đông, Tây Nam..." },
];

const listingFinanceFields: ListingField[] = [
  { name: "legalDocuments", label: "Hồ sơ pháp lý hỗ trợ vay", placeholder: "Sổ hồng/sổ đỏ, hợp đồng, giấy tờ liên quan", kind: "textarea" },
  { name: "legalVerification", label: "Tình trạng kiểm tra pháp lý", placeholder: "Đã kiểm tra, đang bổ sung hoặc cần xác minh" },
  { name: "planningVerification", label: "Quy hoạch", placeholder: "Thông tin quy hoạch hoặc nguồn xác minh" },
  { name: "loanSupport", label: "Hỗ trợ vay vốn", placeholder: "Ngân hàng liên kết, tỷ lệ vay dự kiến, hồ sơ cần chuẩn bị", kind: "textarea" },
  { name: "loanNeed", label: "Nhu cầu vay", placeholder: "Không vay, vay một phần hoặc vay theo phương án", },
];

const landFields: ListingField[] = [
  ...commonLocation,
  { name: "landUseType", label: "Loại đất", placeholder: "Đất ở, đất thương mại, đất nông nghiệp..." },
  { name: "legalStatus", label: "Pháp lý", placeholder: "Sổ hồng riêng..." },
  { name: "planningStatus", label: "Quy hoạch", placeholder: "Thông tin quy hoạch" },
];

export const LISTING_PROFILES: ListingProfile[] = [
  { key: "sale-house", transaction: "sale", propertyType: "house", label: "Bán nhà phố", eyebrow: "Nhà phố đang bán", titlePrefix: "BÁN NHÀ PHỐ", fields: [...commonLocation, { name: "floors", label: "Số tầng", placeholder: "Ví dụ 2", kind: "number" }, { name: "bedrooms", label: "Phòng ngủ", placeholder: "Ví dụ 3", kind: "number" }, { name: "bathrooms", label: "WC", placeholder: "Ví dụ 2", kind: "number" }, { name: "construction", label: "Kết cấu", placeholder: "Bê tông cốt thép" }, { name: "interior", label: "Nội thất", placeholder: "Mô tả nội thất", kind: "textarea" }] },
  { key: "sale-apartment", transaction: "sale", propertyType: "apartment", label: "Bán căn hộ", eyebrow: "Căn hộ đang bán", titlePrefix: "BÁN CĂN HỘ", fields: [...commonLocation, { name: "building", label: "Tòa nhà", placeholder: "Tên tòa/chung cư" }, { name: "floor", label: "Tầng", placeholder: "Ví dụ 12", kind: "number" }, { name: "bedrooms", label: "Phòng ngủ", placeholder: "Ví dụ 2", kind: "number" }, { name: "bathrooms", label: "WC", placeholder: "Ví dụ 2", kind: "number" }, { name: "interior", label: "Nội thất", placeholder: "Mô tả nội thất", kind: "textarea" }, { name: "managementFee", label: "Phí quản lý", placeholder: "Ví dụ 500000", kind: "number", suffix: "đ/tháng" }] },
  { key: "sale-land", transaction: "sale", propertyType: "land", label: "Bán đất nền", eyebrow: "Đất nền đang bán", titlePrefix: "BÁN ĐẤT NỀN", fields: landFields },
  { key: "sale-commercial-land", transaction: "sale", propertyType: "commercial_land", label: "Đất thương mại", eyebrow: "Đất thương mại đang bán", titlePrefix: "BÁN ĐẤT THƯƠNG MẠI", fields: [...landFields, { name: "businessPurpose", label: "Mục đích kinh doanh", placeholder: "Dịch vụ, thương mại, kho bãi..." }] },
  { key: "sale-agricultural", transaction: "sale", propertyType: "agricultural", label: "Đất nông nghiệp", eyebrow: "Đất nông nghiệp đang bán", titlePrefix: "BÁN ĐẤT NÔNG NGHIỆP", fields: [...landFields, { name: "cultivationType", label: "Loại canh tác", placeholder: "Cây lâu năm, lúa, trang trại..." }, { name: "waterAccess", label: "Nguồn nước", placeholder: "Kênh, giếng, thủy lợi..." }] },
  { key: "sale-commercial", transaction: "sale", propertyType: "commercial", label: "Khu thương mại", eyebrow: "Khu thương mại đang bán", titlePrefix: "BÁN KHU THƯƠNG MẠI", fields: [...commonLocation, { name: "businessModel", label: "Mô hình kinh doanh", placeholder: "Shophouse, mặt bằng, trung tâm..." }, { name: "floors", label: "Số tầng", placeholder: "Ví dụ 3", kind: "number" }, { name: "legalStatus", label: "Pháp lý", placeholder: "Tình trạng pháp lý" }, { name: "amenities", label: "Tiện ích", placeholder: "Bãi xe, PCCC, thang máy...", kind: "textarea" }] },
  { key: "sale-project", transaction: "sale", propertyType: "project", label: "Đất dự án", eyebrow: "Đất dự án đang bán", titlePrefix: "BÁN ĐẤT DỰ ÁN", fields: [...landFields, { name: "projectName", label: "Tên dự án", placeholder: "Tên dự án/khu đô thị" }, { name: "handoverDate", label: "Thời điểm bàn giao", placeholder: "Theo tiến độ dự án" }] },
  { key: "rent-house", transaction: "rent", propertyType: "house", label: "Cho thuê nhà", eyebrow: "Nhà cho thuê", titlePrefix: "CHO THUÊ NHÀ", fields: [...commonLocation, { name: "rentPrice", label: "Giá thuê", placeholder: "Ví dụ 15000000", kind: "number", suffix: "đ/tháng" }, { name: "bedrooms", label: "Phòng ngủ", placeholder: "Ví dụ 3", kind: "number" }, { name: "bathrooms", label: "WC", placeholder: "Ví dụ 2", kind: "number" }, { name: "interior", label: "Nội thất", placeholder: "Mô tả nội thất", kind: "textarea" }, { name: "deposit", label: "Tiền cọc", placeholder: "Ví dụ 2 tháng" }] },
  { key: "rent-apartment", transaction: "rent", propertyType: "apartment", label: "Cho thuê căn hộ", eyebrow: "Căn hộ cho thuê", titlePrefix: "CHO THUÊ CĂN HỘ", fields: [...commonLocation, { name: "building", label: "Tòa nhà", placeholder: "Tên tòa/chung cư" }, { name: "bedrooms", label: "Phòng ngủ", placeholder: "Ví dụ 2", kind: "number" }, { name: "bathrooms", label: "WC", placeholder: "Ví dụ 2", kind: "number" }, { name: "rentPrice", label: "Giá thuê", placeholder: "Giá thuê/tháng", kind: "number", suffix: "đ/tháng" }, { name: "managementFee", label: "Phí quản lý", placeholder: "Phí quản lý", kind: "number", suffix: "đ/tháng" }] },
  { key: "rent-industrial", transaction: "rent", propertyType: "industrial", label: "Cho thuê KCN", eyebrow: "Mặt bằng KCN cho thuê", titlePrefix: "CHO THUÊ KCN", fields: [{ name: "location", label: "Vị trí", placeholder: "Tên khu công nghiệp" }, { name: "area", label: "Diện tích", placeholder: "Ví dụ 5000", kind: "number", suffix: "m²" }, { name: "rentPrice", label: "Giá thuê", placeholder: "Giá thuê", kind: "number", suffix: "đ/tháng" }, { name: "industries", label: "Ngành nghề phù hợp", placeholder: "Sản xuất, kho vận..." }, { name: "leaseTerm", label: "Thời hạn thuê", placeholder: "Ví dụ 5 năm" }, { name: "infrastructure", label: "Hạ tầng", placeholder: "Điện, nước, đường, PCCC...", kind: "textarea" }] },
  { key: "rent-commercial", transaction: "rent", propertyType: "commercial", label: "Cho thuê khu thương mại", eyebrow: "Khu thương mại cho thuê", titlePrefix: "CHO THUÊ KHU THƯƠNG MẠI", fields: [...commonLocation, { name: "rentPrice", label: "Giá thuê", placeholder: "Giá thuê/tháng", kind: "number", suffix: "đ/tháng" }, { name: "businessModel", label: "Mô hình kinh doanh", placeholder: "Cửa hàng, showroom, văn phòng..." }, { name: "amenities", label: "Tiện ích", placeholder: "Bãi xe, PCCC, thang máy...", kind: "textarea" }, { name: "leaseTerm", label: "Thời hạn thuê", placeholder: "Ví dụ 3 năm" }] },
  { key: "rent-resort", transaction: "rent", propertyType: "resort", label: "Cho thuê khu nghỉ dưỡng", eyebrow: "Khu nghỉ dưỡng cho thuê", titlePrefix: "CHO THUÊ KHU NGHỈ DƯỠNG", fields: [...commonLocation, { name: "rentPrice", label: "Giá thuê", placeholder: "Giá thuê/tháng hoặc/năm", kind: "number", suffix: "đ" }, { name: "bedrooms", label: "Số phòng", placeholder: "Ví dụ 12", kind: "number" }, { name: "amenities", label: "Tiện ích", placeholder: "Hồ bơi, nhà hàng, bãi biển...", kind: "textarea" }, { name: "capacity", label: "Công suất", placeholder: "Ví dụ 50 khách" }, { name: "leaseTerm", label: "Thời hạn thuê", placeholder: "Ví dụ 5 năm" }] },
  { key: "sale-villa", transaction: "sale", propertyType: "villa", label: "Bán villa/resort", eyebrow: "Villa / Resort đang bán", titlePrefix: "BÁN VILLA / RESORT", fields: [...commonLocation, { name: "bedrooms", label: "Số phòng", placeholder: "Ví dụ 6", kind: "number" }, { name: "amenities", label: "Tiện ích", placeholder: "Hồ bơi, sân vườn...", kind: "textarea" }, { name: "capacity", label: "Công suất", placeholder: "Ví dụ 20 khách" }, { name: "legalStatus", label: "Pháp lý", placeholder: "Tình trạng pháp lý" }] },
  { key: "rent-other", transaction: "rent", propertyType: "rental", label: "Cho thuê loại khác", eyebrow: "Bất động sản cho thuê", titlePrefix: "CHO THUÊ BẤT ĐỘNG SẢN", fields: [...commonLocation, { name: "rentPrice", label: "Giá thuê", placeholder: "Giá thuê", kind: "number", suffix: "đ" }, { name: "businessPurpose", label: "Mục đích sử dụng", placeholder: "Mô tả mục đích sử dụng" }, { name: "leaseTerm", label: "Thời hạn thuê", placeholder: "Ví dụ 2 năm" }, { name: "description", label: "Mô tả", placeholder: "Thông tin thêm", kind: "textarea" }] },
];

export function getListingProfile(transaction: ListingTransaction, propertyType: ListingKind) {
  const profile = LISTING_PROFILES.find(item => item.transaction === transaction && item.propertyType === propertyType) || LISTING_PROFILES[0];
  return { ...profile, fields: [...profile.fields, ...listingFinanceFields] };
}

export function getListingDisplayTitle(input: { transaction: ListingTransaction; propertyType: ListingKind; area?: string; frontage?: string; depth?: string }) {
  const profile = getListingProfile(input.transaction, input.propertyType);
  const dimensions = input.frontage && input.depth ? ` · Ngang ${input.frontage} m × dài ${input.depth} m` : "";
  return `${profile.titlePrefix}${input.area ? ` · ${input.area} m²` : ""}${dimensions}`;
}
