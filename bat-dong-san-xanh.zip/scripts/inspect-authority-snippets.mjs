import fs from 'node:fs';
const file = fs.readFileSync('client/src/pages/LandDossierBuilder.tsx', 'utf8');
for (const needle of ['discoverReceivingAuthorities', 'receivingAuthorities', 'setReceivingAuthorities']) {
  let from = 0;
  console.log(`\n=== ${needle} ===`);
  for (let i = 0; i < 12; i++) {
    const index = file.indexOf(needle, from);
    if (index < 0) break;
    console.log(file.slice(Math.max(0, index - 260), Math.min(file.length, index + 520)).replace(/\n/g, '\\n'));
    from = index + needle.length;
  }
}
