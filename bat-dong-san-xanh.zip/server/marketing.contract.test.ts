import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { appRouter } from "./routers";

describe("marketing contract", () => {
  it("exposes campaign, content, channel, calendar and lead procedures", () => {
    const procedures = appRouter._def.procedures as Record<string, unknown>;
    expect(procedures).toHaveProperty("marketing.campaigns.list");
    expect(procedures).toHaveProperty("marketing.campaigns.create");
    expect(procedures).toHaveProperty("marketing.contents.list");
    expect(procedures).toHaveProperty("marketing.channels.list");
    expect(procedures).toHaveProperty("marketing.calendar.list");
    expect(procedures).toHaveProperty("marketing.captureLead");
  });

  it("keeps MarketingCenter connected to real queries and the dedicated AI route", () => {
    const source = readFileSync(new URL("../client/src/pages/MarketingCenter.tsx", import.meta.url), "utf8");
    expect(source).toContain("trpc.marketing.campaigns.list.useQuery()");
    expect(source).toContain("trpc.marketing.aiContent.generate.useMutation");
    expect(source).not.toContain("trpc.brokerage.analyzeDossier");
    expect(source).not.toContain("Mẫu tham khảo");
  });
});
