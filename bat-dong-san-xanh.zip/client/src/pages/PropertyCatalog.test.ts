import { describe, expect, it } from "vitest";
import { buildPropertyFilters, filterPropertiesByBounds, getPropertyCatalogState, getPropertyCoordinates, getPropertyResultLocation } from "./PropertyCatalog";

const draft = {
  q: "Thanh Khê", propertyType: "house", province: "Đà Nẵng", areaId: "3", minPrice: "5", maxPrice: "9",
  minArea: "80", maxArea: "150", minBedrooms: "2", maxBedrooms: "4", orientation: "Đông Nam", legalStatus: "Sổ đỏ", sort: "price_asc",
};

describe("PropertyCatalog search helpers", () => {
  it("maps the advanced form into typed query input", () => {
    expect(buildPropertyFilters(draft)).toEqual({ q: "Thanh Khê", propertyType: "house", province: "Đà Nẵng", areaId: 3, minPrice: 5, maxPrice: 9, minArea: 80, maxArea: 150, minBedrooms: 2, maxBedrooms: 4, orientation: "Đông Nam", legalStatus: "Sổ đỏ", sort: "price_asc" });
  });

  it("omits empty criteria and preserves the default sort", () => {
    expect(buildPropertyFilters({ ...draft, q: "", propertyType: "", province: "", areaId: "", minPrice: "", maxPrice: "", minArea: "", maxArea: "", minBedrooms: "", maxBedrooms: "", orientation: "", legalStatus: "", sort: "newest" })).toEqual({ sort: "newest" });
  });

  it("formats the filtered result card location", () => {
    expect(getPropertyResultLocation({ areaName: "Thanh Khê", areaProvince: "Đà Nẵng", location: "Đà Nẵng" })).toBe("Thanh Khê, Đà Nẵng");
    expect(getPropertyResultLocation({ areaName: null, areaProvince: null, location: "Sơn Trà, Đà Nẵng" })).toBe("Sơn Trà, Đà Nẵng");
  });

  it("parses valid coordinates and ignores missing coordinates", () => {
    expect(getPropertyCoordinates({ latitude: "16.05", longitude: 108.2 })).toEqual({ lat: 16.05, lng: 108.2 });
    expect(getPropertyCoordinates({ latitude: null, longitude: "108.2" })).toBeNull();
  });

  it("filters properties to the visible map bounds", () => {
    const properties = [
      { id: 1, latitude: 16.05, longitude: 108.2 } as any,
      { id: 2, latitude: 16.2, longitude: 108.4 } as any,
      { id: 3, latitude: null, longitude: null } as any,
    ];
    expect(filterPropertiesByBounds(properties, { north: 16.1, south: 16, east: 108.3, west: 108.1 }).map(property => property.id)).toEqual([1]);
    expect(filterPropertiesByBounds(properties, null).map(property => property.id)).toEqual([1, 2, 3]);
  });

  it("covers loading, error, results and empty states", () => {
    expect(getPropertyCatalogState({ isLoading: true, error: null })).toBe("loading");
    expect(getPropertyCatalogState({ isLoading: false, error: new Error("network") })).toBe("error");
    expect(getPropertyCatalogState({ isLoading: false, error: null, items: [{ id: 1 }] })).toBe("results");
    expect(getPropertyCatalogState({ isLoading: false, error: null, items: [] })).toBe("empty");
  });
});
