import { describe, expect, it } from "vitest";
import { buildPropertyBookingPayload, getPropertyCtaLinks } from "./PropertyDetail";

describe("PropertyDetail CTA links", () => {
  it("keeps the phone link and exposes the full display number", () => {
    const links = getPropertyCtaLinks("Đất nền Sơn Trà", "https://example.com/bat-dong-san/dat-son-tra");

    expect(links.phone).toBe("tel:0989682825");
    expect(links.phoneDisplay).toBe("0989 682 825");
    expect(links.zalo).toBe("https://zalo.me/0989682825");
    expect(links.messenger).toBe("https://m.me/");
  });

  it("builds a consultation payload for a requested viewing appointment", () => {
    expect(buildPropertyBookingPayload({ title: "Đất nền Sơn Trà", name: "Nguyễn An", phone: "0900000001", date: "2026-08-20", time: "09:30", message: "Xin xác nhận trước khi đến." })).toEqual({
      interest: "Đặt lịch xem: Đất nền Sơn Trà",
      name: "Nguyễn An",
      phone: "0900000001",
      message: "Thời gian mong muốn: 2026-08-20 lúc 09:30. Xin xác nhận trước khi đến.",
    });
  });

  it("encodes the title and share URL", () => {
    const links = getPropertyCtaLinks("Đất nền & nhà phố", "https://example.com/a?b=1");

    expect(links.viewing).toContain("%C4%90%E1%BA%A5t%20n%E1%BB%81n%20%26%20nh%C3%A0%20ph%E1%BB%91");
    expect(links.facebook).toContain(encodeURIComponent("https://example.com/a?b=1"));
  });
});
