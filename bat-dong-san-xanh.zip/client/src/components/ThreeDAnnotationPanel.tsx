import React, { FormEvent, useMemo, useRef, useState } from "react";
import { MapPin, Save, Tag, Trash2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

type Annotation = {
  id: number;
  propertyId: number;
  assetUrl: string;
  assetFileName: string | null;
  title: string;
  body: string | null;
  tag: string | null;
  positionX: string | number;
  positionY: string | number;
  positionZ: string | number;
};

type ModelViewerElement = HTMLElement & {
  positionAndNormalFromPoint?: (x: number, y: number) => { position?: { x: number; y: number; z: number } } | null;
};

export default function ThreeDAnnotationPanel({ propertyId, assetUrl, assetFileName }: { propertyId: number; assetUrl: string; assetFileName: string }) {
  const viewerRef = useRef<ModelViewerElement | null>(null);
  const [draftPosition, setDraftPosition] = useState<{ x: number; y: number; z: number } | null>(null);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [tag, setTag] = useState("");
  const annotations = trpc.brokerage.property3dAnnotations.list.useQuery({ propertyId, assetUrl });
  const createAnnotation = trpc.brokerage.property3dAnnotations.create.useMutation({
    onSuccess: () => { annotations.refetch(); setTitle(""); setBody(""); setTag(""); setDraftPosition(null); },
  });
  const deleteAnnotation = trpc.brokerage.property3dAnnotations.delete.useMutation({
    onSuccess: () => annotations.refetch(),
  });
  const markerAnnotations = useMemo(() => (annotations.data || []) as Annotation[], [annotations.data]);
  const pickPoint = (event: React.PointerEvent) => {
    const viewer = viewerRef.current;
    const point = viewer?.positionAndNormalFromPoint?.(event.clientX, event.clientY)?.position;
    if (point && [point.x, point.y, point.z].every(Number.isFinite)) setDraftPosition({ x: point.x, y: point.y, z: point.z });
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!draftPosition || !title.trim()) return;
    createAnnotation.mutate({ propertyId, assetUrl, assetFileName, title: title.trim(), body: body.trim() || undefined, tag: tag.trim() || undefined, positionX: draftPosition.x, positionY: draftPosition.y, positionZ: draftPosition.z });
  };
  const marker = (annotation: Annotation) => {
    const position = `${Number(annotation.positionX)}m ${Number(annotation.positionY)}m ${Number(annotation.positionZ)}m`;
    return <button key={annotation.id} type="button" slot={`hotspot-${annotation.id}`} data-position={position} data-normal="0m 1m 0m" className="group relative rounded-full bg-[#E6C478] px-2 py-1 text-[10px] font-bold text-[#18352D] shadow-md" title={annotation.title}><MapPin size={13} className="inline-block" /> <span className="ml-1 hidden group-hover:inline">{annotation.title}</span></button>;
  };
  return <div className="mt-3 rounded-xl border border-[#D7E2D9] bg-[#F7FAF7] p-3"><div className="mb-2 flex items-center justify-between gap-2"><div><p className="text-xs font-bold text-[#18352D]">Chú thích trực tiếp trên mô hình</p><p className="text-[11px] text-[#60766D]">Chạm vào một điểm trên mô hình để đặt marker, sau đó nhập nội dung và thẻ.</p></div><span className="rounded-full bg-white px-2 py-1 text-[10px] font-bold text-[#1F5A4A]">{markerAnnotations.length} thẻ</span></div><div className="relative overflow-hidden rounded-xl bg-[#EAF4ED]" onPointerDown={pickPoint}><div className="flex min-h-[240px] items-center justify-center">{React.createElement("model-viewer", { ref: viewerRef, src: assetUrl, alt: `Mô hình 3D ${assetFileName}`, "camera-controls": true, "auto-rotate": false, style: { width: "100%", height: "240px" } }, markerAnnotations.map(marker))}</div></div>{draftPosition && <form onSubmit={submit} className="mt-3 grid gap-2 sm:grid-cols-[1fr_1fr_140px_auto]"><input value={title} onChange={event => setTitle(event.target.value)} required placeholder="Tiêu đề chú thích" className="rounded-lg border border-[#C9D9CC] bg-white px-3 py-2 text-xs text-[#18352D]" /><input value={body} onChange={event => setBody(event.target.value)} placeholder="Mô tả: phòng khách, lỗi cần sửa…" className="rounded-lg border border-[#C9D9CC] bg-white px-3 py-2 text-xs text-[#18352D]" /><input value={tag} onChange={event => setTag(event.target.value)} placeholder="Thẻ" className="rounded-lg border border-[#C9D9CC] bg-white px-3 py-2 text-xs text-[#18352D]" /><button type="submit" disabled={createAnnotation.isPending} className="inline-flex items-center justify-center gap-1 rounded-lg bg-[#1F5A4A] px-3 py-2 text-xs font-bold text-white disabled:opacity-50"><Save size={13} /> Lưu</button></form>}<div className="mt-3 grid gap-2 sm:grid-cols-2">{markerAnnotations.map(annotation => <div key={annotation.id} className="flex items-start justify-between gap-2 rounded-lg bg-white px-3 py-2"><div className="min-w-0"><p className="truncate text-xs font-bold text-[#18352D]"><MapPin size={12} className="mr-1 inline" />{annotation.title}</p>{annotation.tag && <p className="mt-1 text-[10px] font-semibold text-[#8A6A1E]"><Tag size={11} className="mr-1 inline" />{annotation.tag}</p>}{annotation.body && <p className="mt-1 text-[11px] leading-4 text-[#60766D]">{annotation.body}</p>}</div><button type="button" aria-label={`Xóa chú thích ${annotation.title}`} onClick={() => deleteAnnotation.mutate({ id: annotation.id, propertyId })} className="shrink-0 rounded-full p-1.5 text-[#9A5B52] hover:bg-[#FFF0ED]"><Trash2 size={13} /></button></div>)}</div></div>;
}
