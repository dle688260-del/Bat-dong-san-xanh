// Compatibility entrypoint for runtimes that still invoke server/index.ts.
// The fullstack project server lives in _core/index.ts; importing it here
// ensures OAuth, tRPC, scheduled routes, storage proxy, and static serving are
// registered consistently in every production entrypoint.
import "./_core/index";

