import { describe, expect, it } from "vitest";
import { mergeLegalProcedureCatalog } from "./db";

describe("mergeLegalProcedureCatalog", () => {
  it("keeps database procedures and adds registry seed procedures without duplicate codes", () => {
    const rows = [
      { code: "9.999999", name: "Thủ tục ngoài nhóm kiểm chứng", groupName: "Đất đai" },
      { code: "1.012784", name: "Tên database ưu tiên", groupName: "Đất đai" },
    ];
    const registryRows = [
      { code: "1.012784", name: "Tên registry không thay thế database", groupName: "Đất đai" },
      { code: "2.000889", name: "Thủ tục registry bổ sung", groupName: "Đất đai" },
    ];

    const result = mergeLegalProcedureCatalog(rows, registryRows);

    expect(result.map(item => item.code).sort()).toEqual(["1.012784", "2.000889", "9.999999"].sort());
    expect(result.filter(item => item.code === "1.012784")).toHaveLength(1);
    expect(result.find(item => item.code === "1.012784")?.name).toBe("Tên database ưu tiên");
  });
});
