/* Design reminder: Biophilic editorial design for Bất động sản xanh — asymmetrical magazine layout, pine green #1F5A4A, warm sand, contour-line motifs, DM Serif Display + Manrope, calm conversion. */
import React, { FormEvent, useEffect, useRef, useState } from "react";
import {
  ArrowUp,
  ArrowUpRight,
  Bell,
  Building2,
  Check,
  Hotel,
  LandPlot,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Compass,
  Factory,
  Facebook,
  Home as HomeIcon,
  ImageIcon,
  Leaf,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Plus,
  SlidersHorizontal,
  Store,
  Search,
  Share2,
  ShieldCheck,
  Sparkles,
  Sprout,
  TreePine,
  Warehouse,
  Waves,
  X,
  KeyRound,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";
import { PropertyLocationMap } from "@/components/PropertyLocationMap";
import { PwaInstallButton } from "@/components/PwaInstallButton";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import type { ListingKind } from "@/lib/propertyListingRegistry";
import {
  getPropertyLayoutForCategory,
  PropertyLayoutRenderer,
  usePersistentPropertyLayoutConfig,
  type PropertyLayoutConfig,
} from "@/components/PropertyLayoutRenderer";

export const PUBLIC_CATALOG_LABEL = "Sản phẩm đang bán";
export const ALL_SUPPLY_PATH = "/bat-dong-san";
export const FEATURED_GRID_CLASS = "grid-cols-1 md:grid-cols-2 xl:grid-cols-4";
export const CATEGORY_SCROLL_FACTOR = 0.82;
export const CATEGORY_SCROLL_MIN_PX = 260;
export const CATEGORY_GROUP_SIZE = 1;
export const getCategoryScrollDistance = (
  containerWidth: number,
  direction: -1 | 1
) =>
  direction *
  Math.max(containerWidth * CATEGORY_SCROLL_FACTOR, CATEGORY_SCROLL_MIN_PX);
export function groupSupplyCategories<T>(
  items: readonly T[],
  groupSize = CATEGORY_GROUP_SIZE
): T[][] {
  if (groupSize < 1) return [Array.from(items)];
  const groups: T[][] = [];
  for (let index = 0; index < items.length; index += groupSize)
    groups.push(Array.from(items.slice(index, index + groupSize)));
  return groups;
}
export const getCategoryDragScrollLeft = (
  startScrollLeft: number,
  startX: number,
  currentX: number
) => Math.max(0, startScrollLeft + startX - currentX);
export const getNextCategoryScrollLeft = (
  scrollLeft: number,
  step: number,
  maxScrollLeft: number
) =>
  Math.min(
    Math.max(0, scrollLeft) + Math.max(0, step),
    Math.max(0, maxScrollLeft)
  );
export const shouldUseCustomCategoryDrag = (pointerType: string) =>
  pointerType === "mouse";
export const LOGIN_LABEL = "Đăng nhập";
export const CONSIGNMENT_INTEREST = "Ký gửi bất động sản";
export const consultationInterests = [
  "An cư tại Đà Nẵng",
  "Đầu tư bất động sản",
  "Đất ở / nhà vườn miền Trung",
  "Căn hộ",
  "Nhà phố",
  "BĐS khu công nghiệp",
  "Căn hộ chung cư",
  "Đất nền",
  "Khu nghỉ dưỡng / Resort",
  "Villa",
  "Đất nông nghiệp",
  "Tôi muốn trao đổi trước",
  CONSIGNMENT_INTEREST,
] as const;
export function requestLogin() {
  startLogin();
}
const logo =
  "/manus-storage/file_000000006cc08211987c04195acd563e_23163104.png";
const heroImage = "/manus-storage/bdsxanh-hero_5654cdae.jpg";
const coastalImage = "/manus-storage/bdsxanh-coastal_378c7f5f.jpg";
const landscapeImage = "/manus-storage/bdsxanh-landscape_21edd8cb.jpg";
const daNangCityCenterImage = "/manus-storage/da-nang-city-center_cea7f987.jpg";

export const propertyCategories = [
  {
    title: "Căn hộ",
    description: "Không gian tiện nghi cho an cư và đầu tư.",
    icon: Building2,
  },
  {
    title: "Nhà phố",
    description: "Nhà ở đô thị, vị trí thuận tiện, pháp lý rõ ràng.",
    icon: HomeIcon,
  },
  {
    title: "Đất nền",
    description: "Lựa chọn quỹ đất phù hợp nhu cầu và ngân sách.",
    icon: LandPlot,
  },
  {
    title: "Villa",
    description: "Không gian riêng tư cho nghỉ dưỡng hoặc đầu tư.",
    icon: TreePine,
  },
  {
    title: "Khu nghỉ dưỡng / Resort",
    description: "Cơ hội tại các điểm đến giàu tiềm năng du lịch.",
    icon: TreePine,
  },
  {
    title: "BĐS khu công nghiệp",
    description: "Mặt bằng và tài sản phục vụ sản xuất, kinh doanh.",
    icon: Factory,
  },
  {
    title: "Đất nông nghiệp",
    description:
      "Đất lúa, cây hàng năm, cây lâu năm và đất nuôi trồng thủy sản.",
    icon: Sprout,
  },
] as const;

export const LAND_SUPPLY_CHILDREN = [
  "Đất nền",
  "Đất nông nghiệp",
  "Đất khu công nghiệp",
  "Đất dự án",
] as const;

export const diverseSupplyCategories = [
  {
    title: "Nhà phố",
    description: "Nhà ở riêng lẻ, nhà mặt tiền và nhà trong khu dân cư.",
    icon: HomeIcon,
    image: daNangCityCenterImage,
    tone: "bg-[#1F5A4A] border-[#17483B] hover:bg-[#17483B]",
    accent: "text-white",
  },
  {
    title: "Căn hộ",
    description:
      "Căn hộ chung cư, căn hộ cao tầng và sản phẩm đang hoàn thiện.",
    icon: Building2,
    image: coastalImage,
    tone: "bg-[#DDECE5] border-[#B8D2C5] hover:bg-[#CFE3D8]",
    accent: "text-[#1F5A4A]",
  },
  {
    title: "Đất nền",
    description: "Đất ở, đất nền phân lô và các lô đất phù hợp đầu tư.",
    icon: LandPlot,
    image: landscapeImage,
    tone: "bg-[#F3E9CE] border-[#DCCB9A] hover:bg-[#EADDB9]",
    accent: "text-[#8A6415]",
  },
  {
    title: "Đất nông nghiệp",
    description: "Đất trồng cây, đất lúa và đất nuôi trồng thủy sản.",
    icon: Sprout,
    image: heroImage,
    tone: "bg-[#E7F0E6] border-[#C5D8C4] hover:bg-[#D9E8D8]",
    accent: "text-[#3B704E]",
  },
  {
    title: "Đất khu công nghiệp",
    description: "Đất và mặt bằng phục vụ sản xuất, kho vận, công nghiệp.",
    icon: Factory,
    image: daNangCityCenterImage,
    tone: "bg-[#DCEAF0] border-[#B8D2DD] hover:bg-[#CFE1E9]",
    accent: "text-[#2C5C70]",
  },
  {
    title: "Khu thương mại",
    description: "Mặt bằng kinh doanh, shophouse và tài sản thương mại.",
    icon: Store,
    image: coastalImage,
    tone: "bg-[#F0E9D8] border-[#D9CBA9] hover:bg-[#E7DCC3]",
    accent: "text-[#745B27]",
  },
  {
    title: "Resort · Villa",
    description:
      "Villa, resort và tài sản nghỉ dưỡng có thể khai thác lưu trú.",
    icon: Hotel,
    image: landscapeImage,
    tone: "bg-[#E3EEE8] border-[#BBD3C5] hover:bg-[#D5E6DC]",
    accent: "text-[#1F5A4A]",
  },
  {
    title: "Khu nghỉ dưỡng",
    description:
      "Đất và sản phẩm trong khu du lịch, nghỉ dưỡng ven biển hoặc sinh thái.",
    icon: Waves,
    image: coastalImage,
    tone: "bg-[#DCECEF] border-[#B6D4DA] hover:bg-[#D0E4E8]",
    accent: "text-[#2A6470]",
  },
  {
    title: "Đất dự án",
    description:
      "Đất thuộc dự án phát triển đô thị, khu dân cư hoặc quy hoạch mới.",
    icon: Compass,
    image: heroImage,
    tone: "bg-[#E8E8DF] border-[#CBCDBB] hover:bg-[#DDDED1]",
    accent: "text-[#4A5A50]",
  },
  {
    title: "Cho thuê",
    description: "Nhà, căn hộ, mặt bằng và đất đang có nhu cầu cho thuê.",
    icon: KeyRound,
    image: daNangCityCenterImage,
    tone: "bg-[#F1E4DE] border-[#DCC4B8] hover:bg-[#E9D6CD]",
    accent: "text-[#87564A]",
  },
] as const;

export const areas = [
  {
    number: "01",
    name: "Đà Nẵng",
    detail: "Trung tâm thành phố · An cư · Đầu tư",
    count: "Nguồn hàng cập nhật",
    image: daNangCityCenterImage,
  },
  {
    number: "02",
    name: "Quảng Nam",
    detail: "Đất ở · Nhà vườn",
    count: "Nguồn hàng cập nhật",
    image: coastalImage,
  },
  {
    number: "03",
    name: "Hội An",
    detail: "Nhà phố · Nghỉ dưỡng",
    count: "Nguồn hàng cập nhật",
    image: landscapeImage,
  },
  {
    number: "04",
    name: "Huế",
    detail: "Đất nền · Nhà vườn",
    count: "Nguồn hàng cập nhật",
    image: coastalImage,
  },
  {
    number: "05",
    name: "Miền Trung",
    detail: "Cơ hội · Kết nối",
    count: "Nguồn hàng cập nhật",
    image: landscapeImage,
  },
] as const;

export const showcaseListings = [
  {
    title: "Nhà phố ven sông · Bản tham khảo",
    location: "Sơn Trà, Đà Nẵng",
    price: "7,00",
    area: "200",
    type: "Nhà phố",
    image: daNangCityCenterImage,
  },
  {
    title: "Căn hộ hướng biển · Bản tham khảo",
    location: "Ngũ Hành Sơn, Đà Nẵng",
    price: "3,20",
    area: "75",
    type: "Căn hộ",
    image: coastalImage,
  },
  {
    title: "Đất vườn miền Trung · Bản tham khảo",
    location: "Điện Bàn, Quảng Nam",
    price: "2,40",
    area: "300",
    type: "Đất nền",
    image: landscapeImage,
  },
] as const;

export function filterAreas(query: string) {
  const normalize = (value: string) =>
    value
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  const normalizedQuery = normalize(query);
  return areas.filter(area =>
    normalize(`${area.name} ${area.detail}`).includes(normalizedQuery)
  );
}

export type ConsultationPayload = {
  interest: string;
  name: string;
  phone: string;
  message: string;
};

const CONSULTATION_DETAIL_FIELDS = [
  ["propertyType", "Loại BĐS"],
  ["budget", "Ngân sách"],
  ["address", "Địa chỉ BĐS"],
  ["location", "Khu vực"],
  ["minBudget", "Ngân sách từ"],
  ["maxBudget", "Ngân sách đến"],
  ["minArea", "Diện tích từ"],
  ["maxArea", "Diện tích đến"],
  ["purpose", "Mục đích"],
  ["bedrooms", "Số phòng"],
  ["legal", "Pháp lý"],
  ["priority", "Mức độ ưu tiên"],
  ["specialRequirements", "Yêu cầu đặc biệt"],
] as const;

export function buildConsultationPayload(data: FormData): ConsultationPayload {
  const baseMessage = String(data.get("message") || "").trim();
  const details = CONSULTATION_DETAIL_FIELDS.map(([key, label]) => ({
    label,
    value: String(data.get(key) || "").trim(),
  })).filter(item => item.value);
  const detailMessage = details.length
    ? `Thông tin chi tiết:\n${details.map(item => `- ${item.label}: ${item.value}`).join("\n")}`
    : "";
  return {
    interest: String(data.get("interest") || "").trim(),
    name: String(data.get("name") || "").trim(),
    phone: String(data.get("phone") || "").trim(),
    message: [baseMessage, detailMessage].filter(Boolean).join("\n\n"),
  };
}

export function submitConsultationForm(
  data: FormData,
  mutate: (payload: ConsultationPayload) => void
) {
  mutate(buildConsultationPayload(data));
}

export const FEATURED_REQUEST_TIMEOUT_MS = 1_500;

export function getFeaturedState(
  data: unknown[] | undefined,
  isLoading: boolean,
  isError = false
): "loading" | "items" | "empty" {
  // React Query can keep isLoading/isFetching true during a refetch. Once a
  // response exists, the screen must not hide it behind the initial loader.
  if (data !== undefined) return data.length ? "items" : "empty";
  if (isLoading && !isError) return "loading";
  return "empty";
}

export function filterFeaturedProperties(
  properties: FeaturedProperty[],
  categoryTitle: string | null
) {
  if (!categoryTitle) return properties;
  const normalized = (value: string) =>
    value
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/g, "d");
  const category = normalized(categoryTitle);
  return properties.filter(property => {
    const searchable = normalized(
      `${property.title} ${property.location} ${property.propertyType}`
    );
    if (category.includes("nha pho"))
      return (
        property.propertyType === "house" || searchable.includes("nha pho")
      );
    if (category.includes("can ho"))
      return (
        property.propertyType === "apartment" || searchable.includes("can ho")
      );
    if (category.includes("dat nen")) {
      const landChildMatch = LAND_SUPPLY_CHILDREN.some(child =>
        searchable.includes(normalized(child))
      );
      const landKeywordMatch = /\bdat\b|nong nghiep|cong nghiep|du an/.test(
        searchable
      );
      return (
        property.propertyType === "land" || landChildMatch || landKeywordMatch
      );
    }
    if (category.includes("dat nong nghiep"))
      return (
        searchable.includes("dat nong nghiep") ||
        searchable.includes("nong nghiep")
      );
    if (category.includes("dat khu cong nghiep"))
      return (
        searchable.includes("khu cong nghiep") ||
        searchable.includes("cong nghiep")
      );
    if (category.includes("khu thuong mai"))
      return (
        searchable.includes("khu thuong mai") ||
        searchable.includes("thuong mai")
      );
    if (category.includes("resort") || category.includes("villa"))
      return (
        property.propertyType === "villa" ||
        searchable.includes("resort") ||
        searchable.includes("villa")
      );
    if (category.includes("khu nghi duong"))
      return (
        property.propertyType === "villa" || searchable.includes("nghi duong")
      );
    if (category.includes("dat du an"))
      return searchable.includes("dat du an") || searchable.includes("du an");
    if (category.includes("cho thue"))
      return searchable.includes("cho thue") || searchable.includes("thue");
    return searchable.includes(category);
  });
}

export function getFeaturedCategoryKind(
  categoryTitle: string | null
): ListingKind | null {
  if (!categoryTitle) return null;
  const normalized = categoryTitle
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d");
  if (normalized.includes("nha pho")) return "house";
  if (normalized.includes("can ho")) return "apartment";
  if (normalized === "dat nen") return "land";
  if (normalized.includes("dat nong nghiep")) return "agricultural";
  if (normalized.includes("dat khu cong nghiep")) return "industrial";
  if (normalized.includes("khu thuong mai")) return "commercial";
  if (normalized.includes("dat du an")) return "project";
  if (normalized.includes("khu nghi duong")) return "resort";
  if (normalized.includes("resort") || normalized.includes("villa"))
    return "villa";
  return null;
}

export function getSupplyCategoryCount(
  properties: FeaturedProperty[],
  categoryTitle: string
) {
  return filterFeaturedProperties(properties, categoryTitle).length;
}

export type SupplyDemand = {
  propertyType: string;
  location: string;
  minBudget: string;
  maxBudget: string;
  minArea: string;
  maxArea: string;
  purpose: string;
  bedrooms: string;
  legal: string;
  specialRequirements: string;
  priority: string;
};

export type ScoredSupply = FeaturedProperty & {
  matchScore: number;
  matchReasons: string[];
};

function numericValue(value: string | number | null | undefined) {
  const parsed = Number(
    String(value ?? "")
      .replace(/,/g, ".")
      .replace(/[^0-9.\-]/g, "")
  );
  return Number.isFinite(parsed) ? parsed : null;
}

export function scoreSupplyDemand(
  properties: FeaturedProperty[],
  demand: SupplyDemand
): ScoredSupply[] {
  const normalized = (value: string) =>
    value
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\\u0300-\\u036f]/g, "")
      .replace(/đ/g, "d");
  const location = normalized(demand.location);
  const type = normalized(demand.propertyType);
  const minBudget = numericValue(demand.minBudget);
  const maxBudget = numericValue(demand.maxBudget);
  const minArea = numericValue(demand.minArea);
  const maxArea = numericValue(demand.maxArea);
  const requestedBedrooms = numericValue(demand.bedrooms);
  const legal = normalized(demand.legal);
  const special = normalized(demand.specialRequirements);
  return properties
    .map(property => {
      const searchable = normalized(
        `${property.title} ${property.location} ${property.propertyType} ${property.legalStatus || ""} ${property.listingDetails || ""} ${property.roadWidth || ""} ${property.orientation || ""}`
      );
      const propertyType = normalized(property.propertyType);
      const price = numericValue(property.price);
      const area = numericValue(property.area);
      let score = 42;
      const reasons: string[] = [];
      if (
        type &&
        (searchable.includes(type) ||
          (type.includes("nha") && property.propertyType === "house") ||
          (type.includes("can ho") && property.propertyType === "apartment") ||
          (type.includes("dat") && property.propertyType === "land"))
      ) {
        score += 20;
        reasons.push("Đúng loại BĐS");
      }
      if (location && searchable.includes(location)) {
        score += 18;
        reasons.push("Đúng khu vực");
      }
      if (
        price !== null &&
        (minBudget === null || price >= minBudget) &&
        (maxBudget === null || price <= maxBudget)
      ) {
        score += 12;
        reasons.push("Trong ngân sách");
      }
      if (
        area !== null &&
        (minArea === null || area >= minArea) &&
        (maxArea === null || area <= maxArea)
      ) {
        score += 10;
        reasons.push("Đúng diện tích");
      }
      if (
        requestedBedrooms !== null &&
        property.bedrooms !== null &&
        property.bedrooms !== undefined &&
        property.bedrooms >= requestedBedrooms
      ) {
        score += 6;
        reasons.push("Đủ số phòng");
      }
      if (legal && searchable.includes(legal)) {
        score += 8;
        reasons.push("Phù hợp pháp lý");
      }
      if (
        special &&
        special
          .split(/[,;\\s]+/)
          .filter(Boolean)
          .some(term => searchable.includes(term))
      ) {
        score += 5;
        reasons.push("Có yêu cầu đặc biệt");
      }
      return {
        ...property,
        matchScore: Math.min(99, score),
        matchReasons: reasons.length ? reasons : ["Cần tư vấn thêm"],
      };
    })
    .sort((a, b) => b.matchScore - a.matchScore);
}

export function getPropertyDetailPath(slug: string) {
  return `/bat-dong-san/${encodeURIComponent(slug)}`;
}

export const services = [
  {
    icon: Compass,
    title: "Tìm đúng BĐS",
    text: "Lựa chọn theo nhu cầu & ngân sách.",
  },
  {
    icon: ShieldCheck,
    title: "Kiểm tra thông tin",
    text: "Hỗ trợ kiểm tra hồ sơ, pháp lý.",
  },
  {
    icon: Sparkles,
    title: "Tư vấn giá",
    text: "Tham khảo giá & hỗ trợ thương lượng.",
  },
  {
    icon: Leaf,
    title: "Hỗ trợ giao dịch",
    text: "Đồng hành từ xem nhà đến hoàn tất.",
  },
];

type FeaturedProperty = {
  id: number;
  slug: string;
  title: string;
  location: string;
  price: string;
  area: string;
  propertyType: ListingKind;
  imageUrl?: string | null;
  imageUrls?: string[];
  description?: string | null;
  buildArea?: string | null;
  bedrooms?: number | null;
  bathrooms?: number | null;
  latitude?: string | number | null;
  longitude?: string | number | null;
  mapVisibility?: "approximate" | "exact" | "private";
  brokerPhone?: string | null;
  brokerZalo?: string | null;
  listingDetails?: string | null;
  legalStatus?: string | null;
  planningStatus?: string | null;
  mortgageStatus?: string | null;
  orientation?: string | null;
  roadWidth?: string | null;
};

type ListingDimensions = {
  frontage?: string;
  orientation?: string;
  roadWidth?: string;
  depth?: string;
  floors?: string;
  legalDocuments?: string;
  legalVerification?: string;
  planningVerification?: string;
  loanSupport?: string;
  loanNeed?: string;
};

function readListingDetails(value?: string | null): ListingDimensions {
  if (!value) return {};
  try {
    const parsed = JSON.parse(value) as Record<string, unknown>;
    const pick = (...keys: string[]) => {
      const found = keys.find(
        key =>
          parsed[key] !== undefined &&
          parsed[key] !== null &&
          String(parsed[key]).trim()
      );
      return found ? String(parsed[found]) : undefined;
    };
    return {
      frontage: pick("frontage", "width", "landWidth", "ngang"),
      orientation: pick("orientation", "direction", "huong"),
      roadWidth: pick("roadWidth", "road", "duong"),
      depth: pick("depth", "length", "landLength", "dai"),
      floors: pick("floors", "floorCount", "soTang"),
      legalDocuments: pick("legalDocuments"),
      legalVerification: pick("legalVerification"),
      planningVerification: pick("planningVerification"),
      loanSupport: pick("loanSupport"),
      loanNeed: pick("loanNeed"),
    };
  } catch {
    return {};
  }
}

function formatPricePerSquareMeter(
  price: string | number,
  area: string | number
) {
  const priceInBillion = Number(price);
  const squareMeters = Number(area);
  if (
    !Number.isFinite(priceInBillion) ||
    !Number.isFinite(squareMeters) ||
    squareMeters <= 0
  )
    return "—";
  const millionPerSquareMeter = (priceInBillion * 1000) / squareMeters;
  return `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 }).format(millionPerSquareMeter)} triệu/m²`;
}

export function SourceDashboard({ propertyCount }: { propertyCount: number }) {
  const [query, setQuery] = useState("");
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const stats = [
    {
      title: "Tôi",
      value: propertyCount || "Đang cập nhật",
      tone: "border-[#5A8DEE] bg-[#EEF5FF]",
      icon: HomeIcon,
      color: "text-[#2171D8]",
    },
    {
      title: "Cộng tác",
      value: "Đang cập nhật",
      tone: "border-[#B7A5F4] bg-[#F4F0FF]",
      icon: HandshakeIcon,
      color: "text-[#7251D5]",
    },
    {
      title: "Thị trường",
      value: "Đang cập nhật",
      tone: "border-[#A9DCC8] bg-[#F0FBF5]",
      icon: GlobeIcon,
      color: "text-[#1A9A6B]",
    },
    {
      title: "Nổi bật",
      value: propertyCount || "Đang cập nhật",
      tone: "border-[#F1C6A7] bg-[#FFF5EC]",
      icon: Sparkles,
      color: "text-[#E38332]",
    },
    {
      title: "Yêu thích",
      value: "Đang cập nhật",
      tone: "border-[#F1B4C2] bg-[#FFF0F4]",
      icon: HeartIcon,
      color: "text-[#E34E73]",
    },
  ];
  return (
    <section
      id="dashboard-nguon-hang"
      className="border-b border-[#E5EAF3] bg-[linear-gradient(135deg,#F7FAFF_0%,#F4F7FD_55%,#F8FBFF_100%)] px-2 py-2 text-[#0B4F3A] sm:px-4 sm:py-3 lg:px-6 lg:py-4"
    >
      <div className="mx-auto max-w-[1500px]">
        <div>
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.16em] text-[#2874D8] sm:text-[10px]">
                <span className="h-1.5 w-1.5 rounded-full bg-[#2874D8]" /> Quản
                lý nguồn hàng
              </p>
              <h1 className="mt-0.5 truncate text-xl font-extrabold tracking-[-.04em] sm:text-2xl">
                Nguồn hàng
              </h1>
              <p className="hidden text-xs text-[#5C6B84] sm:block">
                Quản lý, khai thác và chia sẻ nguồn hàng BĐS hiệu quả.
              </p>
            </div>
          </div>
          <div className="mt-1.5 flex min-w-0 items-center gap-0.5 overflow-hidden">
            <a
              href="/quan-ly-moi-gioi"
              className="inline-flex min-h-6 min-w-0 flex-1 items-center justify-center gap-0.5 rounded-md bg-[#1976E8] px-1 text-[7px] font-bold text-white shadow-[0_3px_8px_rgba(25,118,232,.14)] transition hover:bg-[#135FC0] sm:text-[10px]"
            >
              <Plus size={11} />
              <span className="truncate sm:hidden">Thêm</span>
              <span className="hidden truncate sm:inline">Thêm nguồn hàng</span>
            </a>
            <a
              href="/quan-ly-moi-gioi"
              className="inline-flex min-h-6 min-w-0 flex-1 items-center justify-center gap-0.5 rounded-md border border-[#DCE4F0] bg-white px-1 text-[7px] font-bold text-[#17498D] shadow-sm transition hover:border-[#8DB5EF] hover:bg-[#F4F8FF] sm:text-[10px]"
            >
              <Building2 size={11} />
              <span className="truncate sm:hidden">Kho</span>
              <span className="hidden truncate sm:inline">Kho nguồn hàng</span>
            </a>
            <a
              href="#dashboard-nguon-hang-search"
              className="inline-flex min-h-6 min-w-0 flex-1 items-center justify-center gap-0.5 rounded-md border border-[#DCE4F0] bg-white px-1 text-[7px] font-bold text-[#17498D] shadow-sm transition hover:border-[#8DB5EF] hover:bg-[#F4F8FF] sm:text-[10px]"
            >
              <Search size={11} />
              <span className="truncate sm:hidden">Tìm</span>
              <span className="hidden truncate sm:inline">Tìm nguồn hàng</span>
            </a>
            <a
              href="#ky-gui"
              className="inline-flex min-h-6 min-w-0 flex-1 items-center justify-center gap-0.5 rounded-md border border-[#DCE4F0] bg-white px-1 text-[7px] font-bold text-[#17498D] shadow-sm transition hover:border-[#8DB5EF] hover:bg-[#F4F8FF] sm:text-[10px]"
            >
              <SlidersHorizontal size={11} />{" "}
              <span className="truncate">Thêm</span>
            </a>
            <a
              href="/quan-ly"
              aria-label="Thông báo tư vấn"
              title="Thông báo tư vấn"
              className="relative inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-[#F1C9C9] bg-[#FFF0F0] text-[#D94A4A] shadow-sm transition hover:bg-[#FFE5E5]"
            >
              <Bell size={11} />
              <span className="absolute -right-0.5 -top-0.5 flex h-2.5 min-w-2.5 items-center justify-center rounded-full bg-[#D94A4A] px-0.5 text-[6px] font-bold text-white">
                {isAdmin ? "!" : "—"}
              </span>
            </a>
          </div>
          <div className="mt-1 grid min-w-0 grid-cols-5 gap-0.5">
            {stats.map(item => (
              <a
                key={item.title}
                href="#noi-bat"
                className={`group flex min-w-0 items-center gap-0.5 rounded-md border px-1 py-1 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${item.tone}`}
              >
                <div
                  className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-white shadow-sm ${item.color}`}
                >
                  <item.icon size={9} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[7px] font-bold leading-3 text-[#0B4F3A] sm:text-[8px]">
                    {item.title}
                  </p>
                  <strong className="block truncate text-[8px] font-extrabold tracking-[-.03em] text-[#0B4F3A]">
                    {item.value}
                    {typeof item.value === "number" ? " BĐS" : ""}
                  </strong>
                </div>
                <span className="hidden text-xs leading-none text-[#52709A] transition group-hover:translate-x-0.5 sm:inline">
                  ›
                </span>
              </a>
            ))}
          </div>
          <div
            id="dashboard-nguon-hang-search"
            className="mt-1.5 grid min-w-0 grid-cols-[minmax(0,2.1fr)_repeat(5,minmax(0,1fr))_minmax(24px,auto)] gap-0.5 overflow-hidden"
          >
            <form
              id="dashboard-source-search"
              action="/bat-dong-san"
              method="get"
              className="relative min-w-0"
              onSubmit={event => {
                if (!query.trim()) event.preventDefault();
              }}
            >
              <Search
                className="pointer-events-none absolute left-1.5 top-1/2 -translate-y-1/2 text-[#7890B2]"
                size={11}
              />
              <label className="sr-only" htmlFor="dashboard-source-query">
                Tìm kiếm nguồn hàng
              </label>
              <input
                id="dashboard-source-query"
                name="q"
                value={query}
                onChange={event => setQuery(event.target.value)}
                placeholder="Đường..."
                className="min-h-7 w-full min-w-0 rounded-md border border-[#DCE4F0] bg-white pl-5 pr-1 text-[8px] text-[#0B4F3A] shadow-sm outline-none placeholder:text-[#8A99AE] focus:border-[#4E8FE8] focus:ring-1 focus:ring-[#4E8FE8]/20 sm:text-[10px]"
              />
            </form>
            {["Loại", "Khu vực", "Giá", "DT", "Pháp lý"].map(label => (
              <button
                key={label}
                type="button"
                className="inline-flex min-h-7 min-w-0 items-center justify-center gap-0.5 overflow-hidden rounded-md border border-[#DCE4F0] bg-white px-0.5 text-[7px] font-semibold text-[#40516B] shadow-sm transition hover:border-[#8DB5EF] hover:text-[#17498D] sm:justify-between sm:px-1.5 sm:text-[10px]"
              >
                <span className="truncate">{label}</span>
                <ChevronDown className="shrink-0" size={10} />
              </button>
            ))}
            <button
              type="submit"
              form="dashboard-source-search"
              aria-label="Tìm kiếm"
              className="inline-flex min-h-7 min-w-0 items-center justify-center rounded-md bg-[#1976E8] px-1 text-[8px] font-bold text-white shadow-[0_4px_10px_rgba(25,118,232,.16)] transition hover:bg-[#135FC0]"
            >
              <Search size={12} />
              <span className="hidden sm:inline">Tìm</span>
            </button>
          </div>
          <div className="mt-3 flex items-center justify-between gap-3 border-b border-[#DCE4F0] pb-2 text-xs sm:text-sm">
            <div className="flex gap-4 overflow-x-auto whitespace-nowrap [scrollbar-width:none]">
              <button
                type="button"
                className="border-b-2 border-[#1976E8] pb-2 font-bold text-[#1976E8]"
              >
                Tất cả ({propertyCount || "—"})
              </button>
              <button type="button" className="pb-2 text-[#66758C]">
                Đang bán
              </button>
              <button type="button" className="pb-2 text-[#66758C]">
                Đã bán
              </button>
              <button type="button" className="pb-2 text-[#66758C]">
                Tạm ẩn
              </button>
            </div>
            <button
              type="button"
              className="hidden items-center gap-2 rounded-lg border border-[#DCE4F0] bg-white px-3 py-1.5 font-semibold text-[#40516B] shadow-sm sm:inline-flex"
            >
              Mới nhất <ChevronDown size={15} />
            </button>
          </div>
          {!propertyCount && (
            <div className="mt-5 rounded-xl border border-dashed border-[#D7E1EE] bg-white/80 px-5 py-10 text-center shadow-sm sm:py-12">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#EEF5FF] text-[#2171D8]">
                <Building2 size={30} />
              </div>
              <h2 className="mt-4 text-lg font-extrabold tracking-[-.03em] text-[#0B4F3A]">
                Chưa có nguồn hàng nào
              </h2>
              <p className="mx-auto mt-1 max-w-sm text-sm leading-6 text-[#718096]">
                Hãy thêm nguồn hàng đầu tiên để bắt đầu quản lý và khai thác
                hiệu quả.
              </p>
              <a
                href="/quan-ly-moi-gioi"
                className="mt-5 inline-flex min-h-10 items-center justify-center gap-2 rounded-lg bg-[#1976E8] px-5 text-sm font-bold text-white shadow-[0_6px_14px_rgba(25,118,232,.18)]"
              >
                <Plus size={17} /> Thêm nguồn hàng
              </a>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function AdminConsultationNoticePanel({
  compact = false,
}: {
  compact?: boolean;
}) {
  const consultationList = trpc.consultations?.list;
  if (!consultationList?.useQuery)
    return (
      <div className="mt-3 rounded-lg bg-[#F7FAFC] p-3 text-xs leading-5 text-[#718096]">
        Mở mục Yêu cầu tư vấn để xem thông báo chi tiết.
      </div>
    );
  const consultationNotices = consultationList.useQuery(undefined, {
    staleTime: 30_000,
  });
  const newRequests =
    consultationNotices.data?.filter(item => item.status === "new") ?? [];
  return (
    <div className={compact ? "mt-2 space-y-1.5" : "mt-3 space-y-2"}>
      {newRequests.slice(0, compact ? 1 : 2).map(item => (
        <a
          key={item.id}
          href="/quan-ly"
          className="block rounded-lg border border-[#EEF1F5] bg-[#FAFBFD] p-2 transition hover:border-[#9BBCEB]"
        >
          <div className="flex items-start justify-between gap-2">
            <p className="truncate text-[11px] font-bold text-[#1B3155]">
              {item.name}
            </p>
            <span className="text-[9px] text-[#98A2B3]">Mới</span>
          </div>
          <p className="mt-0.5 line-clamp-1 text-[10px] leading-4 text-[#64748B]">
            {item.interest}
            {item.message ? ` · ${item.message}` : ""}
          </p>
        </a>
      ))}
      {!newRequests.length && (
        <p className="rounded-lg bg-[#F7FAFC] p-2 text-[10px] leading-4 text-[#718096]">
          Chưa có yêu cầu mới.
        </p>
      )}
      <a
        href="/quan-ly"
        className="inline-flex w-full items-center justify-center gap-1 rounded-lg border border-[#B6CBEA] px-2 py-1.5 text-[10px] font-bold text-[#2166B1] transition hover:bg-[#F1F6FF]"
      >
        Xem yêu cầu tư vấn <ArrowUpRight size={12} />
      </a>
    </div>
  );
}

function HandshakeIcon(props: { size?: number }) {
  return <span {...props}>🤝</span>;
}
function GlobeIcon(props: { size?: number }) {
  return <span {...props}>◉</span>;
}
function HeartIcon(props: { size?: number }) {
  return <span {...props}>♡</span>;
}

function FeaturedGallery({
  images,
  title,
  detailPath,
  location,
  latitude,
  longitude,
  mapVisibility,
}: {
  images: string[];
  title: string;
  detailPath: string;
  location: string;
  latitude?: string | number | null;
  longitude?: string | number | null;
  mapVisibility?: "approximate" | "exact" | "private";
}) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [mapOpen, setMapOpen] = useState(false);
  const [failedImages, setFailedImages] = useState<number[]>([]);
  const [retryTokens, setRetryTokens] = useState<Record<number, number>>({});
  const safeImages = images.length ? images : [];
  const retryImage = (index: number) => {
    setFailedImages(current => current.filter(item => item !== index));
    setRetryTokens(current => ({
      ...current,
      [index]: (current[index] ?? 0) + 1,
    }));
  };
  const hasImages = safeImages.length > 0;
  const mapCenter = { lat: Number(latitude), lng: Number(longitude) };
  const hasMap =
    Number.isFinite(mapCenter.lat) &&
    Number.isFinite(mapCenter.lng) &&
    mapVisibility !== "private";
  const goTo = (nextIndex: number) => {
    if (!safeImages.length) return;
    setActiveIndex((nextIndex + safeImages.length) % safeImages.length);
  };
  return (
    <div className="order-1 relative aspect-[4/3] shrink-0 overflow-hidden bg-[#E6EFEA] sm:aspect-[16/10]">
      {mapOpen ? (
        <div className="absolute inset-0 bg-[#E6EFEA]">
          <MapView
            className="!h-full !w-full"
            initialCenter={mapCenter}
            initialZoom={15}
            onMapReady={map => {
              new google.maps.Marker({ map, position: mapCenter, title });
            }}
          />
          <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#102F27]/80 to-transparent px-3 pb-3 pt-8 text-white">
            <p className="text-xs font-black sm:text-sm">
              Vị trí {mapVisibility === "approximate" ? "gần đúng" : "bài đăng"}
            </p>
            <p className="mt-0.5 truncate text-[10px] font-semibold text-white/85 sm:text-xs">
              {location}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setMapOpen(false)}
            className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-3 py-1.5 text-[10px] font-black text-[#1F5A4A] shadow-md transition hover:bg-[#F4D06F] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4D06F]"
            aria-label="Quay lại ảnh"
          >
            ← Ảnh
          </button>
        </div>
      ) : (
        <>
          {hasImages && !failedImages.includes(activeIndex) ? (
            <img
              key={`${safeImages[activeIndex]}-${retryTokens[activeIndex] ?? 0}`}
              src={safeImages[activeIndex]}
              alt={`${title} - ảnh ${activeIndex + 1}`}
              loading="lazy"
              decoding="async"
              fetchPriority="low"
              onError={() =>
                setFailedImages(current =>
                  current.includes(activeIndex)
                    ? current
                    : [...current, activeIndex]
                )
              }
              className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.02]"
            />
          ) : (
            <div className="flex h-full flex-col items-center justify-center gap-2 bg-[#E6EFEA] px-4 text-center text-xs font-semibold text-[#718078]">
              <ImageIcon size={28} />
              <span>
                {hasImages ? "Ảnh đang được cập nhật" : "Chưa có hình ảnh"}
              </span>
              {hasImages && (
                <button
                  type="button"
                  onClick={() => retryImage(activeIndex)}
                  className="inline-flex items-center gap-1 rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-black text-[#1F5A4A] shadow-sm"
                  aria-label={`Tải lại ảnh ${activeIndex + 1}`}
                >
                  <RotateCcw size={13} /> Tải lại ảnh
                </button>
              )}
            </div>
          )}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#102F27]/45 via-transparent to-[#102F27]/10" />
          <span className="absolute left-3 top-3 rounded-full bg-[#F4D06F] px-2.5 py-1 text-[9px] font-bold text-[#123C2F] shadow-sm sm:text-[10px]">
            Ảnh {hasImages ? `${activeIndex + 1}/${safeImages.length}` : "—"}
          </span>
          {hasMap ? (
            <button
              type="button"
              onClick={() => setMapOpen(true)}
              aria-label={`Hiển thị bản đồ vị trí ${title}`}
              className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-2.5 py-1.5 text-[10px] font-bold text-[#1F5A4A] shadow-sm transition hover:bg-[#F4D06F] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4D06F]"
              title={`Hiển thị bản đồ vị trí ${location}`}
            >
              <MapPin size={13} /> Vị trí
            </button>
          ) : (
            <a
              href={detailPath}
              aria-label={`Xem vị trí ${title}`}
              className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-2.5 py-1.5 text-[10px] font-bold text-[#1F5A4A] shadow-sm transition hover:bg-[#F4D06F]"
              title={`Xem vị trí ${location}`}
            >
              <MapPin size={13} /> Vị trí
            </a>
          )}
          {safeImages.length > 1 ? (
            <>
              <button
                type="button"
                aria-label="Ảnh trước"
                onClick={() => goTo(activeIndex - 1)}
                className="absolute left-2 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-[#17483B] shadow-md transition hover:scale-105 hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4D06F]"
              >
                <ChevronLeft size={17} />
              </button>
              <button
                type="button"
                aria-label="Ảnh tiếp theo"
                onClick={() => goTo(activeIndex + 1)}
                className="absolute right-2 top-1/2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-[#17483B] shadow-md transition hover:scale-105 hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4D06F]"
              >
                <ChevronRight size={17} />
              </button>
              <div
                className="absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-1 rounded-full bg-[#102F27]/60 px-2 py-1"
                aria-label="Chọn ảnh"
              >
                {safeImages.slice(0, 7).map((image, index) => (
                  <button
                    key={`${image}-${index}`}
                    type="button"
                    aria-label={`Xem ảnh ${index + 1}`}
                    aria-current={activeIndex === index}
                    onClick={() => goTo(index)}
                    className={`h-1.5 rounded-full transition-all ${activeIndex === index ? "w-4 bg-white" : "w-1.5 bg-white/60"}`}
                  />
                ))}
              </div>
            </>
          ) : null}
        </>
      )}
    </div>
  );
}

export function FeaturedPropertySection({
  state,
  properties,
  allProperties = properties,
  selectedCategory,
  onSelectCategory,
  onDemandSubmit,
  layoutConfig: suppliedLayoutConfig,
}: {
  state: "loading" | "items" | "empty";
  properties: FeaturedProperty[];
  allProperties?: FeaturedProperty[];
  selectedCategory: string | null;
  onSelectCategory: (category: string | null) => void;
  onDemandSubmit?: (payload: ConsultationPayload) => void;
  layoutConfig?: PropertyLayoutConfig;
}) {
  const [demandOpen, setDemandOpen] = useState(false);
  const [demandSubmitted, setDemandSubmitted] = useState(false);
  const [demandResults, setDemandResults] = useState<ScoredSupply[]>([]);
  const localLayout = usePersistentPropertyLayoutConfig();
  const layoutConfig = suppliedLayoutConfig ?? localLayout.config;
  const categoryTrackRef = useRef<HTMLDivElement>(null);
  const categoryDragRef = useRef<{
    pointerId: number;
    startX: number;
    startScrollLeft: number;
    moved: boolean;
  } | null>(null);
  const suppressCategoryClickRef = useRef(false);
  const categoryGroups = groupSupplyCategories(diverseSupplyCategories);
  const getCategoryGroupStep = (track: HTMLDivElement) => {
    const group = track.querySelector<HTMLElement>("[data-category-group]");
    if (!group) return getCategoryScrollDistance(track.clientWidth, 1);
    const gap = Number.parseFloat(
      window.getComputedStyle(track).columnGap || "0"
    );
    return (
      group.getBoundingClientRect().width + (Number.isFinite(gap) ? gap : 0)
    );
  };
  const snapCategoriesToGroup = () => {
    const track = categoryTrackRef.current;
    if (!track) return;
    const step = getCategoryGroupStep(track);
    track.scrollTo({
      left: Math.round(track.scrollLeft / step) * step,
      behavior: "smooth",
    });
  };
  const scrollCategories = () => {
    const track = categoryTrackRef.current;
    if (!track) return;
    const nextLeft = getNextCategoryScrollLeft(
      track.scrollLeft,
      getCategoryGroupStep(track),
      track.scrollWidth - track.clientWidth
    );
    track.scrollTo({ left: nextLeft, behavior: "smooth" });
  };
  const handleCategoryPointerDown = (
    event: React.PointerEvent<HTMLDivElement>
  ) => {
    if (!shouldUseCustomCategoryDrag(event.pointerType) || event.button !== 0)
      return;
    const track = event.currentTarget;
    categoryDragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startScrollLeft: track.scrollLeft,
      moved: false,
    };
    track.style.scrollBehavior = "auto";
    track.setPointerCapture(event.pointerId);
  };
  const handleCategoryPointerMove = (
    event: React.PointerEvent<HTMLDivElement>
  ) => {
    const drag = categoryDragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const distance = Math.abs(event.clientX - drag.startX);
    if (distance <= 4) return;
    drag.moved = true;
    suppressCategoryClickRef.current = true;
    event.preventDefault();
    event.currentTarget.scrollLeft = getCategoryDragScrollLeft(
      drag.startScrollLeft,
      drag.startX,
      event.clientX
    );
  };
  const finishCategoryPointer = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = categoryDragRef.current;
    if (drag?.pointerId === event.pointerId) {
      const moved = drag.moved;
      if (event.currentTarget.hasPointerCapture(event.pointerId))
        event.currentTarget.releasePointerCapture(event.pointerId);
      categoryDragRef.current = null;
      event.currentTarget.style.scrollBehavior = "smooth";
      if (moved) window.requestAnimationFrame(snapCategoriesToGroup);
    }
  };
  const handleCategoryClickCapture = (
    event: React.MouseEvent<HTMLDivElement>
  ) => {
    if (!suppressCategoryClickRef.current) return;
    event.preventDefault();
    event.stopPropagation();
    suppressCategoryClickRef.current = false;
  };
  const typeLabel = (type: FeaturedProperty["propertyType"]) =>
    type === "house"
      ? "Nhà phố"
      : type === "apartment"
        ? "Căn hộ"
        : type === "land"
          ? "Đất nền"
          : type === "industrial"
            ? "Khu công nghiệp"
            : "Resort · Villa";
  return (
    <section
      id="noi-bat"
      className="bg-white px-2 py-4 text-[#123C2F] sm:px-3 sm:py-5 lg:px-4 lg:py-6"
    >
      <div className="mx-auto max-w-[1440px]">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 sm:gap-5">
          <div className="min-w-0">
            <p className="flex items-center gap-1 text-[8px] font-bold uppercase tracking-[.14em] text-[#B28A37] sm:text-[9px]">
              <span className="h-px w-4 bg-[#B28A37]" /> Nguồn hàng chính chủ
            </p>
            <h2 className="mt-1 font-serif text-xl font-bold leading-none tracking-[-.04em] text-[#123E31] sm:text-2xl lg:text-3xl">
              Bất động sản nổi bật
            </h2>
            {selectedCategory ? (
              <p className="mt-1 text-xs font-semibold text-[#1F5A4A]">
                Đang xem: {selectedCategory}
              </p>
            ) : null}
          </div>
          <div className="flex min-w-0 shrink-0 flex-col items-stretch gap-1">
            <button
              type="button"
              onClick={() => {
                setDemandOpen(true);
                setDemandSubmitted(false);
              }}
              className="inline-flex shrink-0 items-center justify-center gap-1 rounded-lg bg-[#1F5A4A] px-2 py-1.5 text-[9px] font-extrabold text-white shadow-sm transition hover:bg-[#17483B] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4D06F] sm:px-2.5 sm:text-[10px]"
              aria-label="Tìm nguồn hàng theo nhu cầu"
            >
              <Search size={12} />{" "}
              <span className="hidden sm:inline">AI khách hàng tìm hàng</span>
              <span className="sm:hidden text-[8px] leading-3">
                AI khách hàng tìm hàng
              </span>
            </button>
            <a
              href={ALL_SUPPLY_PATH}
              className="inline-flex shrink-0 items-center justify-center gap-0.5 text-[10px] font-bold text-[#1F5A4A] sm:text-xs"
            >
              Xem tất cả nguồn hàng <ArrowUpRight size={13} />
            </a>
          </div>
        </div>
        <div
          data-testid="featured-category-panel"
          className="mt-4 border-y border-[#E4EEE7] bg-[#F8FBF8] py-3 sm:py-4"
          aria-label="Khu vực chọn danh mục bất động sản"
        >
          <div className="flex items-end justify-between gap-3 px-1 sm:px-2">
            <div>
              <p className="text-[9px] font-black uppercase tracking-[.16em] text-[#B28A37] sm:text-[10px]">
                01 · Chọn nhóm nguồn hàng
              </p>
              <p className="mt-1 text-xs font-semibold leading-5 text-[#60766D] sm:text-sm">
                Chạm một nhóm để lọc bài đăng ở khu vực riêng bên dưới.
              </p>
            </div>
            <span className="shrink-0 rounded-full bg-white px-2.5 py-1 text-[10px] font-black text-[#1F5A4A] shadow-sm sm:px-3 sm:text-xs">
              {diverseSupplyCategories.length} nhóm
            </span>
          </div>
          <div
            className="relative mt-2.5 w-full"
            aria-label="Danh mục bất động sản nổi bật"
          >
            <div
              ref={categoryTrackRef}
              onPointerDown={handleCategoryPointerDown}
              onPointerMove={handleCategoryPointerMove}
              onPointerUp={finishCategoryPointer}
              onPointerCancel={finishCategoryPointer}
              onClickCapture={handleCategoryClickCapture}
              className="isolate flex snap-x snap-mandatory scroll-smooth touch-pan-x touch-pan-y overscroll-x-contain gap-2 overflow-x-auto px-0 py-1 pr-9 select-none [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:gap-3 sm:px-2 sm:pr-12"
              aria-label="Kéo ngang để xem từng danh mục bất động sản"
            >
              {categoryGroups.map((group, groupIndex) => (
                <div
                  key={`category-group-${groupIndex}`}
                  data-category-group
                  className="flex min-h-[88px] w-[calc(100%-0.25rem)] min-w-[calc(100%-0.25rem)] shrink-0 snap-start overflow-hidden rounded-[18px] border border-[#C9DDD2] bg-[#FCFDFB] shadow-sm sm:min-h-[104px] sm:w-full sm:min-w-full sm:rounded-[22px]"
                  aria-label={`Danh mục ${groupIndex + 1}`}
                >
                  {group.map(category => (
                    <button
                      key={category.title}
                      type="button"
                      aria-pressed={selectedCategory === category.title}
                      onClick={() =>
                        onSelectCategory(
                          selectedCategory === category.title
                            ? null
                            : category.title
                        )
                      }
                      title={category.description}
                      className={`group grid min-h-[88px] w-full grid-cols-[108px_minmax(0,1fr)_auto] items-center gap-2 px-2 py-2 text-left transition hover:bg-[#F3F8F4] focus-visible:z-10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#1F5A4A] sm:min-h-[104px] sm:grid-cols-[124px_minmax(0,1fr)_auto] sm:gap-3 sm:px-3 sm:py-2.5 ${selectedCategory === category.title ? "bg-[#E7F2EB]" : "bg-[#FCFDFB]"}`}
                    >
                      <span
                        className="relative h-[74px] w-[108px] overflow-hidden rounded-[14px] bg-[#DDECE5] sm:h-[86px] sm:w-[124px] sm:rounded-[17px]"
                        aria-hidden="true"
                      >
                        <img
                          src={category.image}
                          alt=""
                          draggable="false"
                          loading="lazy"
                          decoding="async"
                          fetchPriority="low"
                          onError={event => {
                            event.currentTarget.style.display = "none";
                          }}
                          className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.04]"
                        />
                        <span className="absolute inset-0 bg-gradient-to-t from-[#102F27]/30 via-transparent to-transparent" />
                        <span className="absolute bottom-1 left-1 inline-flex h-6 w-6 items-center justify-center rounded-full bg-white/95 text-[#1F5A4A] shadow-sm sm:bottom-1.5 sm:left-1.5 sm:h-7 sm:w-7">
                          <category.icon size={14} strokeWidth={1.9} />
                        </span>
                      </span>
                      <span className="min-w-0 text-[#123C2F]">
                        <span className="line-clamp-2 break-words text-sm font-black leading-tight sm:text-lg">
                          {category.title}
                        </span>
                        <span className="mt-1 line-clamp-2 text-[10px] font-semibold leading-tight text-[#6A7D74] sm:text-xs">
                          {category.description}
                        </span>
                      </span>
                      <span className="flex min-w-[58px] flex-col items-end gap-1 text-right sm:min-w-[76px]">
                        <span
                          className="inline-flex items-center gap-1 rounded-full bg-[#EAF4ED] px-2 py-1 text-[10px] font-black leading-none text-[#1F5A4A] sm:px-2.5 sm:text-xs"
                          aria-label={`${getSupplyCategoryCount(allProperties, category.title)} bài đăng`}
                        >
                          <category.icon size={12} strokeWidth={1.9} />
                          {getSupplyCategoryCount(
                            allProperties,
                            category.title
                          )}
                        </span>
                        <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-[#1F5A4A] sm:text-[10px]">
                          Xem <ArrowUpRight size={12} />
                        </span>
                      </span>
                    </button>
                  ))}
                </div>
              ))}
              <a
                href={ALL_SUPPLY_PATH}
                aria-label="Xem tất cả danh mục bất động sản"
                className="flex min-h-[88px] w-[calc(100%-0.25rem)] min-w-[calc(100%-0.25rem)] shrink-0 snap-start items-center justify-center gap-2 rounded-[18px] border-2 border-dashed border-[#B8D8C5] bg-[#F3FAF5] px-4 text-center text-[#1F5A4A] transition hover:border-[#1F5A4A] hover:bg-[#E3F0EA] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1F5A4A] sm:min-h-[104px] sm:rounded-[22px] sm:px-5"
              >
                <span className="inline-flex h-10 w-10 items-center justify-center rounded-full bg-white text-[#1F5A4A] shadow-sm sm:h-12 sm:w-12">
                  <ArrowUpRight size={21} />
                </span>
                <span className="flex flex-col items-start gap-1">
                  <span className="text-base font-black leading-tight sm:text-xl">
                    Xem tất cả
                  </span>
                  <span className="text-[11px] font-semibold text-[#60766D] sm:text-sm">
                    Toàn bộ danh mục
                  </span>
                </span>
              </a>
            </div>
            <button
              type="button"
              onClick={scrollCategories}
              aria-label="Xem danh mục tiếp theo"
              className="absolute right-1 top-1/2 z-10 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full border border-[#D7E4DA] bg-white/95 text-[#1F5A4A] shadow-sm transition hover:bg-[#EEF7F0] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1F5A4A] sm:h-9 sm:w-9"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
        {demandOpen ? (
          <div
            className="fixed inset-0 z-50 flex items-end justify-center bg-[#123C2F]/45 p-2 sm:items-center sm:p-6"
            role="dialog"
            aria-modal="true"
            aria-label="Tìm nguồn hàng theo nhu cầu"
          >
            <div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-[#FFFDF7] p-4 text-[#123C2F] shadow-2xl sm:p-6">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-[.16em] text-[#B28A37]">
                    🔎 AI khách hàng tìm hàng
                  </p>
                  <h3 className="mt-1 text-xl font-black sm:text-2xl">
                    AI tìm hàng cho khách hàng
                  </h3>
                  <p className="mt-1 text-xs leading-5 text-[#60766D]">
                    Nhập nhu cầu một lần; hệ thống sẽ phân tích, lọc kho hàng và
                    xếp hạng mức độ phù hợp.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setDemandOpen(false)}
                  className="rounded-full p-2 text-[#60766D] hover:bg-[#EEF6F1]"
                  aria-label="Đóng"
                >
                  <X size={18} />
                </button>
              </div>
              <form
                className="mt-4 grid gap-3 sm:grid-cols-2"
                onSubmit={event => {
                  event.preventDefault();
                  const data = new FormData(event.currentTarget);
                  const demand: SupplyDemand = {
                    propertyType: String(data.get("propertyType") || ""),
                    location: String(data.get("location") || ""),
                    minBudget: String(data.get("minBudget") || ""),
                    maxBudget: String(data.get("maxBudget") || ""),
                    minArea: String(data.get("minArea") || ""),
                    maxArea: String(data.get("maxArea") || ""),
                    purpose: String(data.get("purpose") || ""),
                    bedrooms: String(data.get("bedrooms") || ""),
                    legal: String(data.get("legal") || ""),
                    specialRequirements: String(
                      data.get("specialRequirements") || ""
                    ),
                    priority: String(data.get("priority") || ""),
                  };
                  setDemandResults(
                    scoreSupplyDemand(allProperties, demand).slice(0, 6)
                  );
                  setDemandSubmitted(true);
                  onDemandSubmit?.({
                    interest: "Tìm nguồn hàng theo nhu cầu",
                    name: String(
                      data.get("name") || "Khách hàng chưa nhập tên"
                    ),
                    phone: String(data.get("phone") || "Chưa cung cấp"),
                    message: JSON.stringify(demand),
                  });
                }}
              >
                <label className="text-xs font-bold">
                  Loại BĐS
                  <select
                    name="propertyType"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  >
                    <option value="">Tất cả loại</option>
                    <option>Đất</option>
                    <option>Nhà</option>
                    <option>Căn hộ</option>
                    <option>Mặt bằng</option>
                    <option>Villa / Resort</option>
                  </select>
                </label>
                <label className="text-xs font-bold">
                  Khu vực
                  <input
                    name="location"
                    placeholder="Quận/huyện, phường/xã"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <label className="text-xs font-bold">
                  Ngân sách từ (tỷ)
                  <input
                    name="minBudget"
                    inputMode="decimal"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <label className="text-xs font-bold">
                  Ngân sách đến (tỷ)
                  <input
                    name="maxBudget"
                    inputMode="decimal"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <label className="text-xs font-bold">
                  Diện tích từ (m²)
                  <input
                    name="minArea"
                    inputMode="numeric"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <label className="text-xs font-bold">
                  Diện tích đến (m²)
                  <input
                    name="maxArea"
                    inputMode="numeric"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <label className="text-xs font-bold">
                  Mục đích
                  <select
                    name="purpose"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  >
                    <option>Ở</option>
                    <option>Đầu tư</option>
                    <option>Kinh doanh</option>
                  </select>
                </label>
                <label className="text-xs font-bold">
                  Số phòng
                  <input
                    name="bedrooms"
                    placeholder="Nếu là nhà/căn hộ"
                    inputMode="numeric"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <label className="text-xs font-bold">
                  Pháp lý
                  <select
                    name="legal"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  >
                    <option value="">Không yêu cầu</option>
                    <option>Sổ riêng</option>
                    <option>Sổ hồng</option>
                    <option>Đang chờ</option>
                  </select>
                </label>
                <label className="text-xs font-bold">
                  Mức độ ưu tiên
                  <select
                    name="priority"
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  >
                    <option>Cao</option>
                    <option>Vừa</option>
                    <option>Thấp</option>
                  </select>
                </label>
                <label className="text-xs font-bold sm:col-span-2">
                  Yêu cầu đặc biệt
                  <textarea
                    name="specialRequirements"
                    rows={2}
                    placeholder="Đường ô tô, hướng, gần trường..."
                    className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                  />
                </label>
                <div className="grid gap-3 sm:grid-cols-2 sm:col-span-2">
                  <label className="text-xs font-bold">
                    Tên khách
                    <input
                      required
                      name="name"
                      className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                    />
                  </label>
                  <label className="text-xs font-bold">
                    Số điện thoại
                    <input
                      required
                      name="phone"
                      inputMode="tel"
                      pattern="(?:\+84|0)(?:3|5|7|8|9)[0-9]{8}"
                      title="Nhập số điện thoại Việt Nam hợp lệ"
                      className="mt-1 w-full rounded-lg border border-[#D7E4DA] bg-white p-2.5 font-normal"
                    />
                  </label>
                </div>
                <button
                  type="submit"
                  disabled={false}
                  className="sm:col-span-2 inline-flex min-h-11 items-center justify-center gap-2 rounded-lg bg-[#1F5A4A] px-4 text-sm font-black text-white hover:bg-[#17483B] disabled:opacity-60"
                >
                  <Sparkles size={16} /> Phân tích và tìm nguồn hàng
                </button>
              </form>
              {demandSubmitted ? (
                <div className="mt-5 rounded-xl border border-[#CFE2D4] bg-[#EEF7F0] p-3">
                  <p className="text-xs font-black uppercase tracking-[.12em] text-[#1F5A4A]">
                    AI đã phân tích · {demandResults.length} nguồn hàng phù hợp
                    nhất
                  </p>
                  <div className="mt-2 grid gap-2 sm:grid-cols-2">
                    {demandResults.map(result => (
                      <a
                        key={result.id}
                        href={getPropertyDetailPath(result.slug)}
                        className="rounded-lg bg-white p-3 shadow-sm"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate text-sm font-black">
                            {result.title}
                          </p>
                          <span className="shrink-0 rounded-full bg-[#D9F0DF] px-2 py-1 text-[10px] font-black text-[#1F5A4A]">
                            {result.matchScore}%
                          </span>
                        </div>
                        <p className="mt-1 text-xs text-[#60766D]">
                          {result.location} · {result.price} tỷ · {result.area}{" "}
                          m²
                        </p>
                        <p className="mt-1 text-[10px] font-semibold text-[#1F5A4A]">
                          {result.matchReasons.join(" · ")}
                        </p>
                      </a>
                    ))}
                  </div>
                  {!demandResults.length ? (
                    <p className="mt-2 text-xs text-[#60766D]">
                      Chưa có nguồn hàng đủ dữ liệu; yêu cầu đã được chuyển vào
                      mục Tư vấn để môi giới tiếp nhận.
                    </p>
                  ) : null}
                </div>
              ) : null}
            </div>
          </div>
        ) : null}
        <div data-testid="featured-listings-panel" className="mt-6">
          <div className="flex flex-col gap-2 border-b border-[#E4EEE7] pb-3 sm:flex-row sm:items-end sm:justify-between sm:pb-4">
            <div>
              <p className="text-[9px] font-black uppercase tracking-[.16em] text-[#B28A37] sm:text-[10px]">
                02 · Bài đăng đang hiển thị
              </p>
              <h3 className="mt-1 font-serif text-xl font-bold tracking-[-.035em] text-[#123E31] sm:text-2xl">
                {selectedCategory
                  ? `Nguồn hàng ${selectedCategory}`
                  : "Nguồn hàng mới cập nhật"}
              </h3>
              <p className="mt-1 text-xs leading-5 text-[#60766D] sm:text-sm">
                Thông tin, ảnh, giá và liên hệ của từng bất động sản được hiển
                thị riêng, dễ theo dõi.
              </p>
            </div>
            <span className="w-fit shrink-0 rounded-full bg-[#EAF4ED] px-3 py-1.5 text-xs font-black text-[#1F5A4A]">
              {state === "items"
                ? `${properties.length} bài đăng`
                : "Đang cập nhật"}
            </span>
          </div>
          {state === "loading" ? (
            <div
              data-testid="featured-loading"
              className="py-12 text-center text-sm text-[#737373]"
            >
              Đang tải nguồn hàng...
            </div>
          ) : state === "items" ? (
            <div data-testid="featured-items" className="mt-3">
              <PropertyLayoutRenderer
                items={properties}
                layout={getPropertyLayoutForCategory(
                  layoutConfig,
                  getFeaturedCategoryKind(selectedCategory)
                )}
                className={
                  properties.length === 1 ? "mx-auto w-full max-w-[1120px]" : ""
                }
                itemKey={property => property.id}
                renderItem={(property, _index, density) => {
                  const dimensions = readListingDetails(
                    property.listingDetails
                  );
                  const phone = property.brokerPhone || "0989682825";
                  const zalo =
                    property.brokerZalo ||
                    `https://zalo.me/${phone.replace(/[^0-9]/g, "")}`;
                  const hasMap =
                    property.latitude !== null &&
                    property.latitude !== undefined &&
                    property.longitude !== null &&
                    property.longitude !== undefined &&
                    property.mapVisibility !== "private";
                  const galleryImages = Array.from(
                    new Set(
                      [
                        ...(property.imageUrls ?? []),
                        ...(property.imageUrl ? [property.imageUrl] : []),
                      ].filter(Boolean)
                    )
                  ) as string[];
                  const detailItems = [
                    {
                      label: "Ngang × dài",
                      value:
                        dimensions.frontage && dimensions.depth
                          ? `${dimensions.frontage} × ${dimensions.depth} m`
                          : "Đang cập nhật",
                    },
                    {
                      label: "Hướng",
                      value:
                        property.orientation ||
                        dimensions.orientation ||
                        "Đang cập nhật",
                    },
                    {
                      label: "Đường",
                      value:
                        property.roadWidth || dimensions.roadWidth
                          ? `${property.roadWidth || dimensions.roadWidth} m`
                          : "Đang cập nhật",
                    },
                    {
                      label: "Phòng ngủ",
                      value: property.bedrooms
                        ? `${property.bedrooms} phòng`
                        : "Đang cập nhật",
                    },
                    {
                      label: "Phòng vệ sinh",
                      value: property.bathrooms
                        ? `${property.bathrooms} phòng`
                        : "Đang cập nhật",
                    },
                    ...(dimensions.floors
                      ? [
                          {
                            label: "Số tầng",
                            value: `${dimensions.floors} tầng`,
                          },
                        ]
                      : []),
                  ];
                  const legalItems = [
                    property.legalStatus ||
                    dimensions.legalVerification ||
                    dimensions.legalDocuments
                      ? `Pháp lý: ${property.legalStatus || dimensions.legalVerification || dimensions.legalDocuments}`
                      : null,
                    property.planningStatus || dimensions.planningVerification
                      ? `Quy hoạch: ${property.planningStatus || dimensions.planningVerification}`
                      : null,
                    dimensions.loanSupport ||
                    dimensions.loanNeed ||
                    property.mortgageStatus
                      ? `Vay vốn: ${dimensions.loanSupport || dimensions.loanNeed || property.mortgageStatus}`
                      : null,
                  ].filter(Boolean) as string[];
                  const primaryLegalItems = legalItems.filter(item =>
                    /^(Pháp lý|Vay vốn)/i.test(item)
                  );
                  const secondaryLegalItems = legalItems.filter(
                    item => !/^(Pháp lý|Vay vốn)/i.test(item)
                  );
                  return (
                    <article
                      key={property.id}
                      className={`group flex h-full min-w-0 flex-col overflow-hidden rounded-2xl border border-[#DCE9E1] bg-white shadow-[0_8px_24px_rgba(18,62,49,.08)] transition duration-200 hover:-translate-y-1 hover:border-[#A8CDBA] hover:shadow-[0_16px_34px_rgba(18,62,49,.16)] focus-within:border-[#1F5A4A] ${density === "compact" ? "[&_.featured-title]:text-[21px] [&_.featured-price]:text-[28px]" : ""}`}
                    >
                      <div className="order-1 flex min-w-0 flex-1 flex-col p-3 max-[359px]:p-2 sm:p-3.5">
                        <div className="relative flex items-start gap-2">
                          <div className="min-w-0 flex-1 pr-20 sm:pr-24">
                            <p className="flex line-clamp-2 items-start gap-1.5 break-words text-[13px] font-black leading-4 text-[#42675A] max-[359px]:text-[12px] max-[359px]:leading-4 sm:text-[15px] sm:leading-5">
                              <MapPin
                                size={17}
                                strokeWidth={2.4}
                                className="mt-0.5 shrink-0 text-[#1F5A4A]"
                              />
                              <span>{property.location}</span>
                            </p>
                            <a
                              href={getPropertyDetailPath(property.slug)}
                              aria-label={`Xem chi tiết ${property.title}`}
                            >
                              <h3 className="featured-title mt-1 line-clamp-2 text-[24px] font-black leading-[1.05] tracking-[-.035em] text-[#123C2F] max-[359px]:text-[21px] sm:text-[29px] sm:leading-[1.08]">
                                {property.title}
                              </h3>
                            </a>
                          </div>
                          <span className="absolute right-0 top-0 shrink-0 rounded-full bg-[#F4D06F] px-3 py-1.5 text-[11px] font-black text-[#123C2F] sm:text-[13px]">
                            {typeLabel(property.propertyType)}
                          </span>
                        </div>
                        <div className="mt-2 flex items-end justify-between gap-2">
                          <div>
                            <strong className="featured-price block text-[32px] font-black leading-none tracking-[-.055em] text-[#1F5A4A] max-[359px]:text-[28px] sm:text-[38px]">
                              {property.price} tỷ
                            </strong>
                            <span className="mt-1 block text-[13px] font-black leading-4 text-[#687A72] max-[359px]:text-[11px] max-[359px]:leading-3.5 sm:text-[15px]">
                              Giá/m² ·{" "}
                              {formatPricePerSquareMeter(
                                property.price,
                                property.area
                              )}
                            </span>
                          </div>
                          <span className="rounded-xl bg-[#EDF6F0] px-3 py-1.5 text-[15px] font-black leading-tight text-[#17483B] max-[359px]:rounded-lg max-[359px]:px-2 max-[359px]:py-1 max-[359px]:text-[13px] sm:text-[17px]">
                            {property.area} m²
                          </span>
                        </div>
                        <div
                          className={`mt-2.5 grid gap-x-1.5 gap-y-1 border-b border-[#DCE7E0] pb-2.5 max-[359px]:mt-2 max-[359px]:gap-x-1 max-[359px]:gap-y-0.5 max-[359px]:pb-2 sm:gap-x-2 ${property.propertyType === "house" ? "grid-cols-5 sm:grid-cols-5" : "grid-cols-2 sm:grid-cols-4"}`}
                        >
                          {detailItems
                            .slice(0, property.propertyType === "house" ? 5 : 4)
                            .map(item => (
                              <div key={item.label} className="min-w-0">
                                <p className="truncate text-[9px] font-semibold leading-[1.15] text-[#65766E] max-[359px]:text-[8px] sm:text-[11px]">
                                  {item.label}
                                </p>
                                <p className="mt-0 truncate text-[12px] font-black leading-[1.15] text-[#123C2F] max-[359px]:text-[11px] sm:text-[15px]">
                                  {item.value}
                                </p>
                              </div>
                            ))}
                        </div>
                        {primaryLegalItems.length ? (
                          <div
                            className="mt-2 flex flex-nowrap items-center gap-1.5 overflow-x-auto pb-1 [scrollbar-width:thin]"
                            aria-label="Pháp lý và vay vốn"
                          >
                            {primaryLegalItems.map(item => (
                              <span
                                key={item}
                                className="inline-flex shrink-0 items-center rounded-full bg-[#EEF6F1] px-2.5 py-1 text-[10px] font-bold leading-[1.15] text-[#1F5A4A] max-[359px]:px-2 max-[359px]:py-0.5 max-[359px]:text-[9px] sm:text-[12px]"
                              >
                                {item}
                              </span>
                            ))}
                          </div>
                        ) : null}
                        {secondaryLegalItems.length ? (
                          <div
                            className="mt-1.5 flex flex-wrap gap-1.5"
                            aria-label="Thông tin quy hoạch"
                          >
                            {secondaryLegalItems.map(item => (
                              <span
                                key={item}
                                className="inline-flex max-w-full items-center rounded-full bg-[#EEF6F1] px-2.5 py-1 text-[10px] font-bold leading-[1.15] text-[#1F5A4A] max-[359px]:px-2 max-[359px]:py-0.5 max-[359px]:text-[9px] sm:text-[12px]"
                              >
                                {item}
                              </span>
                            ))}
                          </div>
                        ) : null}
                        <FeaturedGallery
                          images={galleryImages}
                          title={property.title}
                          detailPath={getPropertyDetailPath(property.slug)}
                          location={property.location}
                          latitude={property.latitude}
                          longitude={property.longitude}
                          mapVisibility={property.mapVisibility}
                        />
                        <div className="order-2 mt-2 flex w-full flex-nowrap items-center gap-1.5">
                          <a
                            href={getPropertyDetailPath(property.slug)}
                            className="inline-flex min-h-10 min-w-0 flex-1 items-center justify-center gap-1 rounded-full bg-[#1F5A4A] px-2 text-[13px] font-black text-white transition hover:bg-[#17483B]"
                          >
                            Xem chi tiết <ArrowUpRight size={15} />
                          </a>
                          <a
                            href={`tel:${phone}`}
                            aria-label="Gọi điện"
                            className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[#1F5A4A] transition hover:bg-[#F4F8F5]"
                            title="Gọi điện"
                          >
                            <Phone size={17} />
                          </a>
                          <a
                            href={
                              zalo.startsWith("http")
                                ? zalo
                                : `https://zalo.me/${zalo.replace(/[^0-9]/g, "")}`
                            }
                            target="_blank"
                            rel="noreferrer"
                            aria-label="Zalo"
                            className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[12px] font-black text-[#1F5A4A] transition hover:bg-[#F4F8F5]"
                            title="Zalo"
                          >
                            Zalo
                          </a>
                          <a
                            href="https://m.me/"
                            target="_blank"
                            rel="noreferrer"
                            aria-label="Messenger"
                            className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[#1F5A4A] transition hover:bg-[#F4F8F5]"
                            title="Messenger"
                          >
                            <MessageCircle size={17} />
                          </a>
                          <a
                            href="https://facebook.com/"
                            target="_blank"
                            rel="noreferrer"
                            aria-label="Facebook"
                            className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[#1F5A4A] transition hover:bg-[#F4F8F5]"
                            title="Facebook"
                          >
                            <Facebook size={17} />
                          </a>
                        </div>
                      </div>
                    </article>
                  );
                }}
              />
            </div>
          ) : (
            <div data-testid="featured-empty" className="mt-5">
              <div className="border border-dashed border-[#C9D8D0] bg-[#FFFEFA] p-6 text-center sm:p-8">
                <p className="text-xl font-bold text-[#123C2F]">
                  Sản phẩm thật đang được cập nhật.
                </p>
                <p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-[#737373]">
                  Nguồn hàng công khai sẽ xuất hiện tại đây sau khi môi giới
                  hoàn tất đăng bài và được duyệt.
                </p>
                <a
                  href="/bat-dong-san"
                  className="mt-5 inline-flex rounded-full bg-[#1F5A4A] px-5 py-3 text-sm font-bold text-white"
                >
                  Khám phá danh mục
                </a>
              </div>
            </div>
          )}
        </div>
        <BackToTopButton />
      </div>
    </section>
  );
}

function BackToTopButton() {
  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      className="mt-8 inline-flex items-center gap-2 rounded-full border border-[#1F5A4A]/20 bg-white/80 px-4 py-2 text-xs font-bold text-[#1F5A4A] shadow-sm transition hover:-translate-y-0.5 hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1F5A4A]"
    >
      <ArrowUp size={14} />
      Về đầu trang
    </button>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [formSent, setFormSent] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  useEffect(() => {
    const value = new URLSearchParams(window.location.search).get("authError");
    if (!value) return;
    setAuthError(value);
    window.history.replaceState(
      {},
      "",
      window.location.pathname + window.location.hash
    );
  }, []);
  const [consultationMode, setConsultationMode] = useState<
    "buy" | "consign" | null
  >(null);
  const [contactOpen, setContactOpen] = useState(false);
  const [areaSearch, setAreaSearch] = useState("");
  const [areaSaved, setAreaSaved] = useState(false);
  const [selectedSupplyCategory, setSelectedSupplyCategory] = useState<
    string | null
  >(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const localLayout = usePersistentPropertyLayoutConfig();
  const remoteLayout = trpc.propertyLayoutSettings?.public?.useQuery?.(
    undefined,
    { staleTime: 60_000 }
  ) ?? { data: undefined };
  const publicLayoutConfig: PropertyLayoutConfig = remoteLayout.data
    ? {
        defaultLayout: remoteLayout.data
          .defaultLayout as PropertyLayoutConfig["defaultLayout"],
        byCategory: remoteLayout.data
          .overrides as PropertyLayoutConfig["byCategory"],
      }
    : localLayout.config;
  const visibleAreas = filterAreas(areaSearch);
  const openConsultation = (mode: "buy" | "consign") => {
    setFormSent(false);
    setConsultationMode(mode);
    setContactOpen(false);
    setMenuOpen(false);
  };
  const openContact = () => {
    setContactOpen(true);
    setMenuOpen(false);
  };
  const shareWebsite = async () => {
    const shareData = {
      title: "Bất động sản xanh Đà Nẵng · Miền Trung · Toàn quốc",
      text: "Khám phá nguồn hàng và nhận tư vấn bất động sản từ Bất động sản xanh.",
      url: window.location.href,
    };

    try {
      if (typeof navigator.share === "function") {
        await navigator.share(shareData);
        return;
      }
      await navigator.clipboard.writeText(shareData.url);
      toast.success("Đã sao chép liên kết website", {
        description: "Bạn có thể dán liên kết vào mạng xã hội hoặc tin nhắn.",
      });
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      toast.error("Chưa thể chia sẻ tự động", {
        description: "Vui lòng sao chép đường dẫn trên thanh địa chỉ để gửi.",
      });
    }
  };
  const openAreaSection = () => {
    setMenuOpen(false);
    window.setTimeout(() => {
      document.getElementById("khu-vuc-noi-bat")?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 0);
  };
  const featuredProperties = trpc.properties.latest.useQuery(undefined, {
    // Giữ bộ đếm danh mục đồng bộ với các bài đăng vừa được công khai.
    // Polling nhẹ là cơ chế dự phòng an toàn khi trang không có WebSocket/SSE.
    refetchInterval: 15_000,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    retry: 1,
    staleTime: 10_000,
  });
  const [featuredTimedOut, setFeaturedTimedOut] = useState(false);
  useEffect(() => {
    if (!featuredProperties.isLoading) {
      setFeaturedTimedOut(false);
      return;
    }
    const timer = window.setTimeout(
      () => setFeaturedTimedOut(true),
      FEATURED_REQUEST_TIMEOUT_MS
    );
    return () => window.clearTimeout(timer);
  }, [featuredProperties.isLoading]);
  const filteredFeaturedProperties = featuredProperties.data
    ? filterFeaturedProperties(featuredProperties.data, selectedSupplyCategory)
    : [];
  const featuredState = getFeaturedState(
    featuredProperties.data === undefined
      ? undefined
      : filteredFeaturedProperties,
    featuredProperties.isLoading && !featuredTimedOut,
    featuredProperties.isError
  );
  const createConsultation = trpc.consultations.create.useMutation({
    onSuccess: () => {
      setFormSent(true);
      setConsultationMode(null);
      toast.success("Đã nhận đăng ký tư vấn", {
        description:
          "Thông tin đã được lưu trên website. Lê Văn Tiến sẽ gọi lại để tiếp nhận và tư vấn sớm.",
      });
    },
    onError: () =>
      toast.error("Chưa thể lưu yêu cầu", {
        description: "Vui lòng kiểm tra lại thông tin hoặc gọi 0989 682 825.",
      }),
  });

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (createConsultation.isPending) return;
    const data = new FormData(event.currentTarget);
    submitConsultationForm(data, payload => createConsultation.mutate(payload));
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#F8FAF7] text-[#123C2F]">
      {authError && (
        <div
          role="alert"
          className="border-b border-[#E7C978] bg-[#FFF8E7] px-4 py-3 text-center text-sm text-[#6F5520]"
        >
          {authError === "oauth_unavailable"
            ? "Dịch vụ đăng nhập đang tạm thời gián đoạn. Vui lòng thử lại sau ít phút."
            : "Đăng nhập chưa hoàn tất. Vui lòng thử lại."}
          <button
            type="button"
            className="ml-3 font-bold underline"
            onClick={() => setAuthError(null)}
          >
            Đóng
          </button>
        </div>
      )}
      <header className="relative z-50 border-b border-[#E8ECE9] bg-white text-[#123E31] shadow-[0_2px_14px_rgba(18,62,49,.04)]">
        <div className="mx-auto flex min-h-[52px] max-w-[1320px] items-center justify-between gap-3 px-3 py-1.5 sm:min-h-[60px] sm:px-6 sm:py-1.5 lg:px-10">
          <a
            href="#top"
            className="group flex min-w-0 items-center"
            aria-label="Bất động sản xanh - về đầu trang"
          >
            <img
              src="/manus-storage/file_000000006cc08211987c04195acd563e_23163104.png"
              alt="Bất động sản xanh"
              className="h-9 w-auto max-w-[145px] object-contain sm:h-11 sm:max-w-[185px]"
            />
          </a>

          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2.5">
            <button
              type="button"
              onClick={openContact}
              aria-label="Gọi tư vấn"
              title="Gọi tư vấn"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-[#1F5A4A]/20 bg-[#F7F8F5] text-[#1F5A4A] shadow-sm transition hover:border-[#1F5A4A] hover:bg-[#1F5A4A] hover:text-white active:scale-95 sm:h-10 sm:w-10"
            >
              <Phone size={18} strokeWidth={2.4} />
            </button>
            <button
              type="button"
              onClick={shareWebsite}
              aria-label="Chia sẻ website"
              title="Chia sẻ website"
              data-testid="public-share-button"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-[#1F5A4A]/20 bg-[#F7F8F5] text-[#1F5A4A] shadow-sm transition hover:border-[#1F5A4A] hover:bg-[#1F5A4A] hover:text-white active:scale-95 sm:h-10 sm:w-10"
            >
              <Share2 size={18} strokeWidth={2.4} />
            </button>
            <button
              type="button"
              onClick={() => setMenuOpen(value => !value)}
              aria-label={menuOpen ? "Đóng menu" : "Mở menu"}
              aria-expanded={menuOpen}
              data-testid="public-menu-toggle"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-[#0B4F3A] text-white shadow-sm transition hover:bg-[#1F5A4A] active:scale-95 sm:h-10 sm:w-10"
            >
              {menuOpen ? (
                <X size={19} aria-hidden="true" />
              ) : (
                <Menu size={19} aria-hidden="true" />
              )}
            </button>
          </div>
        </div>

        <div
          className={
            menuOpen
              ? "mx-3 mb-3 rounded-2xl border border-[#0B4F3A]/10 bg-white p-4 text-[#0B4F3A] shadow-xl sm:mx-6 sm:p-5 lg:mx-auto lg:max-w-[1320px] lg:px-10"
              : "hidden"
          }
        >
          <div className="grid gap-2 text-sm font-semibold sm:grid-cols-2 lg:grid-cols-4 lg:items-center">
            <button
              type="button"
              onClick={openAreaSection}
              className="rounded-xl px-3 py-3 text-left transition hover:bg-[#F5F7F4]"
            >
              Khu vực
            </button>
            <a
              href="/bat-dong-san"
              onClick={() => setMenuOpen(false)}
              className="rounded-xl px-3 py-3 transition hover:bg-[#F5F7F4]"
            >
              {PUBLIC_CATALOG_LABEL}
            </a>
            <a
              href="#dich-vu"
              onClick={() => setMenuOpen(false)}
              className="rounded-xl px-3 py-3 transition hover:bg-[#F5F7F4]"
            >
              Dịch vụ
            </a>
            <button
              type="button"
              onClick={openContact}
              className="rounded-xl px-3 py-3 text-left transition hover:bg-[#F5F7F4]"
            >
              Tư vấn liên hệ
            </button>
            <a
              href="/crm/login"
              onClick={() => setMenuOpen(false)}
              aria-label="Đăng nhập CRM"
              className="inline-flex items-center gap-2 rounded-xl bg-[#D9B44A] px-3 py-3 font-bold text-[#153F34] transition hover:bg-[#C8A238]"
            >
              <ShieldCheck size={17} aria-hidden="true" />
              Đăng nhập CRM
            </a>
            <button
              type="button"
              className="rounded-xl px-3 py-3 text-left font-bold text-[#9B7020] transition hover:bg-[#FFF8E7]"
              onClick={() => openConsultation("consign")}
            >
              Chủ nhà ký gửi
            </button>
            <PwaInstallButton
              appName="Website bán hàng"
              className="text-[#1F5A4A]"
            />
          </div>
        </div>
      </header>
      <nav
        aria-label="Điều hướng nhanh"
        className="sticky top-0 z-20 grid grid-cols-4 border-b border-white/10 bg-[#0B4F3A] text-white shadow-lg"
      >
        <a
          href="/bat-dong-san"
          className="flex min-h-[52px] flex-col items-center justify-center gap-0.5 border-b-2 border-[#D9B75D] bg-[#0F6B4F] px-1 py-1 text-[.62rem] font-extrabold text-white shadow-inner transition hover:bg-[#1A7A5A] sm:min-h-[66px] sm:gap-1 sm:px-2 sm:py-2 sm:text-sm lg:min-h-[62px] lg:py-2 lg:text-sm"
        >
          <Building2 className="h-6 w-6 text-[#D9B75D] sm:h-9 sm:w-9" />
          Nguồn hàng
        </a>
        <button
          type="button"
          onClick={() => openConsultation("buy")}
          className="flex min-h-[52px] flex-col items-center justify-center gap-0.5 px-1 py-1 text-[.62rem] font-extrabold text-white transition hover:bg-[#0F6B4F] hover:text-[#D9B75D] sm:min-h-[66px] sm:gap-1 sm:px-2 sm:py-2 sm:text-sm lg:min-h-[62px] lg:py-2 lg:text-sm"
        >
          <HomeIcon className="h-6 w-6 text-[#7ED6C5] sm:h-9 sm:w-9" />
          Mua BĐS
        </button>
        <button
          type="button"
          onClick={() => openConsultation("consign")}
          className="flex min-h-[52px] flex-col items-center justify-center gap-0.5 px-1 py-1 text-[.62rem] font-extrabold text-white transition hover:bg-[#0F6B4F] hover:text-[#D9B75D] sm:min-h-[66px] sm:gap-1 sm:px-2 sm:py-2 sm:text-sm lg:min-h-[62px] lg:py-2 lg:text-sm"
        >
          <Leaf className="h-6 w-6 text-[#D9B75D] sm:h-9 sm:w-9" />
          Ký gửi
        </button>
        <button
          type="button"
          onClick={openContact}
          className="flex min-h-[52px] flex-col items-center justify-center gap-0.5 px-1 py-1 text-[.62rem] font-extrabold text-white transition hover:bg-[#0F6B4F] hover:text-[#D9B75D] sm:min-h-[66px] sm:gap-1 sm:px-2 sm:py-2 sm:text-sm lg:min-h-[62px] lg:py-2 lg:text-sm"
        >
          <Phone className="h-6 w-6 text-[#F3B7A8] sm:h-9 sm:w-9" />
          Tư vấn
        </button>
      </nav>

      <section
        id="tim-kiem"
        className="border-b border-[#0B4F3A]/10 bg-[#0B4F3A] px-3 py-2.5 sm:px-6 sm:py-3 lg:px-10"
      >
        <div className="mx-auto max-w-[1320px]">
          <button
            type="button"
            onClick={() => setSearchOpen(value => !value)}
            aria-expanded={searchOpen}
            aria-controls="quick-search-panel"
            className="flex min-h-10 w-full items-center justify-center gap-2 rounded-xl bg-[#1F6B53] px-4 text-sm font-extrabold text-white shadow-[0_6px_18px_rgba(0,0,0,.12)] transition hover:bg-[#2B8065] active:scale-[.99]"
          >
            <Search size={17} aria-hidden="true" />
            {searchOpen ? "Thu gọn tìm kiếm" : "Tìm kiếm nguồn hàng"}
            <ChevronDown
              size={16}
              className={
                searchOpen
                  ? "rotate-180 transition-transform"
                  : "transition-transform"
              }
              aria-hidden="true"
            />
          </button>
          {searchOpen && (
            <form
              id="quick-search-panel"
              action="/bat-dong-san"
              method="get"
              aria-label="Tìm kiếm bất động sản nhanh"
              className="mt-2 grid gap-2 rounded-xl bg-white p-2.5 sm:grid-cols-3 sm:p-3"
            >
              <label className="sr-only" htmlFor="quick-property-type">
                Loại bất động sản
              </label>
              <select
                id="quick-property-type"
                name="propertyType"
                className="min-h-10 rounded-lg border border-[#D9E1DD] bg-white px-3 text-sm font-semibold text-[#123C2F] outline-none focus:border-[#1F5A4A] focus:ring-2 focus:ring-[#1F5A4A]/20"
              >
                <option value="">Loại BĐS</option>
                <option value="house">Nhà ở</option>
                <option value="land">Đất</option>
                <option value="apartment">Căn hộ</option>
                <option value="villa">Villa</option>
                <option value="resort">Resort / Khu nghỉ dưỡng</option>
                <option value="industrial">BĐS khu công nghiệp</option>
                <option value="agricultural">Đất nông nghiệp</option>
              </select>
              <label className="sr-only" htmlFor="quick-area">
                Khu vực
              </label>
              <select
                id="quick-area"
                name="area"
                className="min-h-10 rounded-lg border border-[#D9E1DD] bg-white px-3 text-sm font-semibold text-[#123C2F] outline-none focus:border-[#1F5A4A] focus:ring-2 focus:ring-[#1F5A4A]/20"
              >
                <option value="">Khu vực</option>
                <option>Đà Nẵng</option>
                <option>Quảng Nam</option>
                <option>Thừa Thiên Huế</option>
                <option>Miền Trung</option>
              </select>
              <label className="sr-only" htmlFor="quick-max-price">
                Giá tối đa
              </label>
              <input
                id="quick-max-price"
                name="maxPrice"
                inputMode="decimal"
                placeholder="Giá tối đa"
                className="min-h-10 rounded-lg border border-[#D9E1DD] bg-white px-3 text-sm outline-none placeholder:text-[#9AA7A0] focus:border-[#1F5A4A] focus:ring-2 focus:ring-[#1F5A4A]/20"
              />
              <button
                type="submit"
                className="min-h-10 rounded-lg bg-[#1F5A4A] px-4 text-sm font-bold text-white transition hover:bg-[#123E31] sm:col-span-3"
              >
                Xem kết quả
              </button>
            </form>
          )}
        </div>
      </section>

      <FeaturedPropertySection
        state={featuredState}
        properties={filteredFeaturedProperties}
        allProperties={featuredProperties.data || []}
        selectedCategory={selectedSupplyCategory}
        onSelectCategory={setSelectedSupplyCategory}
        onDemandSubmit={payload => createConsultation.mutate(payload)}
        layoutConfig={publicLayoutConfig}
      />

      {/* Khu vực Quản lý nguồn hàng đã được tách khỏi trang đầu; khách hàng truy cập nguồn hàng qua menu công khai. */}
      <section
        id="top"
        className="relative overflow-hidden border-b border-[#1F5A4A]/10 bg-[#F7F8F5] text-[#123E31]"
      >
        <img
          src={heroImage}
          alt="Không gian đô thị xanh"
          className="absolute right-[-14%] top-0 h-full w-[68%] object-cover opacity-45 [mask-image:linear-gradient(90deg,transparent_0%,black_32%,black_100%)] sm:right-[-4%] sm:w-[54%]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#F7F8F5] via-[#F7F8F5]/95 to-[#F7F8F5]/35" />
        <div className="relative mx-auto max-w-[1320px] px-4 pb-7 pt-8 sm:px-6 sm:pb-9 sm:pt-10 lg:px-10 lg:pb-12 lg:pt-14">
          <div className="max-w-[680px]">
            <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#B28A37] sm:text-xs">
              <span className="h-px w-7 bg-[#B28A37]" /> Đà Nẵng · Miền Trung
            </p>
            <h1 className="mt-3 max-w-[620px] font-serif text-[2.55rem] font-bold leading-[.95] tracking-[-.055em] text-[#123E31] sm:text-5xl lg:text-7xl">
              Nguồn hàng
              <br />
              <em className="font-normal text-[#1F5A4A]">đa dạng</em>
            </h1>
            <p className="mt-4 max-w-[520px] text-sm leading-6 text-[#5D6863] sm:text-base">
              Khám phá hàng ngàn bất động sản chính chủ, pháp lý rõ ràng và được
              cập nhật mỗi ngày.
            </p>
            <p className="mt-6 max-w-[420px] border-l-2 border-[#D9B75D] pl-4 text-sm font-semibold leading-6 text-[#45665A] sm:mt-8">
              Địa phương trước, bán hàng sau — chọn một hướng đi phù hợp, phần
              tìm kiếm nằm ngay phía trên.
            </p>
          </div>
        </div>
      </section>

      <section
        id="vi-sao"
        className="bg-white px-6 py-14 text-[#0B4F3A] lg:px-10 lg:py-20"
      >
        <div className="mx-auto max-w-[1320px]">
          <div className="flex items-end justify-between gap-5">
            <div>
              <p className="section-kicker text-[#B58B2E]">
                <span className="bg-[#B58B2E]" /> Giá trị đồng hành
              </p>
              <h2 className="mt-4 font-serif text-4xl tracking-[-.04em] sm:text-5xl">
                Vì sao chọn chúng tôi?
              </h2>
            </div>
            <a
              href="#dich-vu"
              className="hidden items-center gap-2 text-sm font-bold text-[#1F5A4A] sm:inline-flex"
            >
              Xem cách làm việc <ArrowUpRight size={16} />
            </a>
          </div>
          <div className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[
              { icon: ShieldCheck, title: "Nguồn hàng chính chủ" },
              { icon: ShieldCheck, title: "Pháp lý minh bạch" },
              { icon: MessageCircle, title: "Tư vấn tận tâm chuyên nghiệp" },
              { icon: Phone, title: "Hỗ trợ nhanh mọi lúc" },
            ].map((item, index) => (
              <div
                key={item.title}
                className="rounded-2xl border border-[#0B4F3A]/10 bg-[#F8F8F5] p-5 text-center sm:p-7"
              >
                <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-[#0B4F3A]/15 bg-white text-[#0B4F3A]">
                  <item.icon size={24} />
                </span>
                <h3 className="mt-4 text-sm font-bold leading-5 sm:text-base">
                  {item.title}
                </h3>
              </div>
            ))}
          </div>
          <BackToTopButton />
        </div>
      </section>

      <section
        id="khu-vuc-noi-bat"
        className="scroll-mt-20 bg-[#F5F7F4] px-6 py-12 lg:px-10 lg:py-20"
      >
        <div className="mx-auto max-w-[1120px]">
          <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
            <div>
              <p className="section-kicker">
                <span /> Khu vực nổi bật
              </p>
              <h2 className="mt-4 max-w-2xl font-serif text-4xl leading-[.98] tracking-[-.04em] text-[#123C2F] sm:text-5xl">
                Bất động sản
                <br />
                <em className="font-normal text-[#1F5A4A]">theo địa điểm.</em>
              </h2>
            </div>
            <a
              href="#khu-vuc-noi-bat"
              className="inline-flex items-center gap-1.5 text-sm font-bold text-[#1F5A4A] transition hover:text-[#0E3B30] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1F5A4A]"
            >
              Xem tất cả khu vực <ArrowUpRight size={16} />
            </a>
          </div>
          <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4 lg:gap-5">
            {areas.map(area => (
              <a
                key={area.number}
                href="#khu-vuc-noi-bat"
                className={`group relative min-h-[186px] overflow-hidden rounded-xl bg-[#123C2F] shadow-[0_8px_20px_rgba(20,40,74,.1)] transition duration-200 hover:-translate-y-1 hover:shadow-[0_14px_28px_rgba(20,40,74,.16)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1F5A4A] sm:min-h-[210px] sm:rounded-2xl lg:min-h-[238px]`}
              >
                <img
                  src={area.image}
                  alt={`Bất động sản tại ${area.name}`}
                  className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B2530]/90 via-[#102F3D]/35 to-[#102F3D]/10" />
                <div className="relative flex h-full flex-col justify-end p-3.5 text-white sm:p-5">
                  <span className="mb-1 text-[10px] font-bold uppercase tracking-[.12em] text-[#F2D99E] sm:text-xs">
                    {area.count}
                  </span>
                  <h3 className="font-sans text-lg font-extrabold tracking-[-.02em] sm:text-2xl">
                    {area.name}
                  </h3>
                  <p className="mt-0.5 text-[11px] font-semibold leading-4 text-white/85 sm:text-sm">
                    {area.detail}
                  </p>
                </div>
              </a>
            ))}
          </div>
          <BackToTopButton />
        </div>
      </section>

      <section className="border-b border-[#123C2F]/10 bg-[#F8FAF7]">
        <div className="mx-auto grid max-w-[1320px] gap-8 px-6 py-8 sm:grid-cols-3 lg:px-10">
          <div className="flex items-center gap-3">
            <span className="text-2xl font-serif text-[#1F5A4A]">01</span>
            <span className="text-sm text-[#486058]">
              Am hiểu địa bàn
              <br />
              <strong className="text-[#123C2F]">Đà Nẵng & miền Trung</strong>
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-2xl font-serif text-[#1F5A4A]">02</span>
            <span className="text-sm text-[#486058]">
              Tư vấn 1–1
              <br />
              <strong className="text-[#123C2F]">Rõ ràng & tận tâm</strong>
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-2xl font-serif text-[#1F5A4A]">03</span>
            <span className="text-sm text-[#486058]">
              Kết nối đúng nhu cầu
              <br />
              <strong className="text-[#123C2F]">Không gây áp lực</strong>
            </span>
          </div>
        </div>
      </section>

      <section
        id="dich-vu"
        className="bg-[#E8E5D9] px-5 py-12 sm:px-6 sm:py-14 lg:px-10 lg:py-16"
      >
        <div className="mx-auto max-w-[1320px]">
          <div className="grid gap-5 lg:grid-cols-[1fr_.85fr] lg:items-center lg:gap-10">
            <div>
              <p className="section-kicker text-[10px] sm:text-[11px]">
                <span /> Cách chúng tôi làm việc và đồng hành
              </p>
              <h2 className="mt-3 max-w-lg font-serif text-2xl leading-[1.04] tracking-[-.04em] text-[#123C2F] sm:text-3xl">
                Tận tâm, minh bạch,
                <br />
                <em className="font-normal text-[#1F5A4A]">
                  đồng hành đến cùng.
                </em>
              </h2>
            </div>
            <div className="lg:justify-self-end">
              <p className="max-w-sm text-xs leading-5 text-[#60766D] sm:text-sm">
                Quy trình rõ ràng, hỗ trợ đúng nhu cầu từ xem nhà đến giao dịch.
              </p>
              <a
                href="#lien-he"
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#1F5A4A] px-4 py-2.5 text-xs font-bold text-white transition hover:bg-[#123C2F] active:scale-[.97] sm:text-sm"
              >
                Đăng ký tư vấn <ArrowUpRight size={16} />
              </a>
            </div>
          </div>
          <div className="mt-7 grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:mt-8 lg:gap-3">
            {services.map((service, i) => (
              <div
                key={service.title}
                className="min-h-[146px] rounded-lg border border-[#123C2F]/12 bg-[#F8FAF7]/70 p-3.5 transition hover:-translate-y-0.5 hover:bg-[#F8FAF7] sm:min-h-[158px] sm:p-4"
              >
                <div className="flex items-center justify-between">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-[#1F5A4A] shadow-sm sm:h-9 sm:w-9">
                    <service.icon size={17} strokeWidth={1.7} />
                  </span>
                  <span className="font-serif text-lg text-[#9AAB9D]">
                    0{i + 1}
                  </span>
                </div>
                <h3 className="mt-4 font-serif text-lg text-[#123C2F] sm:text-xl">
                  {service.title}
                </h3>
                <p className="mt-1.5 text-[11px] leading-4 text-[#60766D] sm:text-xs">
                  {service.text}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-[#123C2F]/15 pt-4 text-xs sm:text-sm">
            <span className="mr-2 font-semibold text-[#60766D]">
              Trao đổi nhanh:
            </span>
            <a
              href="tel:0989682825"
              className="inline-flex items-center gap-2 rounded-full bg-[#1F5A4A] px-4 py-2.5 font-bold text-white transition hover:bg-[#123C2F] active:scale-[.97]"
            >
              <Phone size={15} /> 0989 682 825
            </a>
            <a
              href="https://zalo.me/0989682825"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-[#1F5A4A] px-4 py-2.5 font-bold text-[#1F5A4A] transition hover:bg-[#1F5A4A] hover:text-white active:scale-[.97]"
            >
              Zalo
            </a>
            <a
              href="https://m.me/"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-[#1F5A4A] px-4 py-2.5 font-bold text-[#1F5A4A] transition hover:bg-[#1F5A4A] hover:text-white active:scale-[.97]"
            >
              <MessageCircle size={15} /> Messenger
            </a>
          </div>
          <BackToTopButton />
        </div>
      </section>

      <section
        id="lien-he"
        className="relative overflow-hidden bg-[#1F5A4A] px-4 py-9 text-white sm:px-5 sm:py-12 lg:px-8 lg:py-14"
      >
        <div className="absolute right-[-120px] top-[-180px] h-[420px] w-[420px] rounded-full border border-white/10" />
        <div className="relative mx-auto grid max-w-[960px] gap-6 lg:grid-cols-[.82fr_1.18fr] lg:items-start lg:gap-8">
          <div>
            <p className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-[.2em] text-[#D9B75D]">
              <span className="h-px w-7 bg-[#D9B75D]" /> Tư vấn riêng
            </p>
            <h2 className="mt-3 max-w-sm font-serif text-3xl leading-[1.02] tracking-[-.05em] sm:text-4xl">
              Bắt đầu từ một{" "}
              <em className="font-normal text-[#D9B75D]">cuộc trò chuyện.</em>
            </h2>
            <p className="mt-3 max-w-sm text-xs leading-5 text-white/70 sm:text-sm">
              Để lại thông tin, Lê Văn Tiến sẽ liên hệ để hiểu nhu cầu và gợi ý
              bước tiếp theo phù hợp.
            </p>
            <div className="mt-4 grid gap-1.5 text-xs text-white/80 sm:text-sm">
              <a
                href="tel:0989682825"
                className="flex items-center gap-3 transition-colors hover:text-[#D9B75D]"
              >
                <Phone size={16} className="text-[#D9B75D]" /> 0989 682 825
              </a>
              <div className="flex items-center gap-3">
                <MapPin size={16} className="text-[#D9B75D]" /> Đà Nẵng, Việt
                Nam
              </div>
            </div>
            <div className="mt-4 flex flex-wrap gap-1.5">
              <a
                href="tel:0989682825"
                className="inline-flex items-center gap-1.5 rounded-full bg-[#D9B75D] px-3 py-2 text-[11px] font-bold text-[#123C2F] transition hover:bg-white active:scale-[.97]"
              >
                <Phone size={14} /> Gọi ngay
              </a>
              <a
                href="https://zalo.me/0989682825"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-full border border-white/35 px-3 py-2 text-[11px] font-bold text-white transition hover:border-white hover:bg-white hover:text-[#123C2F] active:scale-[.97]"
              >
                Zalo
              </a>
              <a
                href="https://www.facebook.com/"
                target="_blank"
                rel="noreferrer"
                aria-label="Liên hệ tư vấn qua Facebook"
                className="inline-flex items-center gap-1.5 rounded-full border border-white/35 px-3 py-2 text-[11px] font-bold text-white transition hover:border-white hover:bg-white hover:text-[#123C2F] active:scale-[.97]"
              >
                <Facebook size={14} /> Facebook
              </a>
            </div>
          </div>
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl bg-[#F8FAF7] p-4 text-[#123C2F] shadow-xl sm:p-5"
          >
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-serif text-xl tracking-[-.03em]">
                Đăng ký tư vấn
              </h3>
              <span className="text-xs font-semibold text-[#60766D]">
                Miễn phí
              </span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#60766D] sm:col-span-2">
                Nhu cầu của bạn
                <select
                  name="interest"
                  className="mt-1 w-full rounded-lg border border-[#123C2F]/15 bg-white/60 px-3 py-2 text-xs font-medium outline-none focus:border-[#1F5A4A] sm:text-sm"
                >
                  {consultationInterests.map(interest => (
                    <option key={interest}>{interest}</option>
                  ))}
                </select>
              </label>
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#60766D]">
                Tên của bạn
                <input
                  name="name"
                  required
                  className="mt-1 w-full rounded-lg border border-[#123C2F]/15 bg-white/60 px-3 py-2 text-xs outline-none placeholder:text-[#9AAB9D] focus:border-[#1F5A4A] sm:text-sm"
                  placeholder="Nguyễn Văn A"
                />
              </label>
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#60766D]">
                Số điện thoại
                <input
                  name="phone"
                  required
                  type="tel"
                  className="mt-1 w-full rounded-lg border border-[#123C2F]/15 bg-white/60 px-3 py-2 text-xs outline-none placeholder:text-[#9AAB9D] focus:border-[#1F5A4A] sm:text-sm"
                  placeholder="09xx xxx xxx"
                  inputMode="tel"
                  pattern="(?:\+84|0)(?:3|5|7|8|9)[0-9]{8}"
                  title="Nhập số điện thoại Việt Nam hợp lệ, ví dụ 0989 682 825"
                />
              </label>
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#60766D] sm:col-span-2">
                Lời nhắn{" "}
                <span className="font-normal normal-case tracking-normal">
                  (không bắt buộc)
                </span>
                <textarea
                  name="message"
                  rows={2}
                  className="mt-1 w-full resize-none rounded-lg border border-[#123C2F]/15 bg-white/60 px-3 py-2 text-xs outline-none placeholder:text-[#9AAB9D] focus:border-[#1F5A4A] sm:text-sm"
                  placeholder="Bạn muốn tìm hiểu khu vực hoặc nhu cầu nào?"
                />
              </label>
            </div>
            <button
              disabled={createConsultation.isPending}
              type="submit"
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-[#123C2F] px-3 py-2.5 text-xs font-bold text-white transition-all hover:bg-[#1F5A4A] disabled:cursor-wait disabled:opacity-60 active:scale-[.98] sm:text-sm"
            >
              {createConsultation.isPending
                ? "Đang gửi…"
                : formSent
                  ? "Đã gửi yêu cầu"
                  : "Gửi đăng ký tư vấn"}{" "}
              <ArrowUpRight size={16} />
            </button>
            <p className="mt-3 text-center text-[11px] text-[#60766D]">
              Thông tin chỉ dùng để liên hệ tư vấn.
            </p>
          </form>
          <BackToTopButton />
        </div>
      </section>

      {contactOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="contact-modal-title"
          className="fixed inset-0 z-50 flex items-end justify-center bg-[#0B4F3A]/70 p-0 backdrop-blur-sm sm:items-center sm:p-5"
        >
          <div className="w-full max-w-md rounded-t-[2rem] bg-[#F8FAF7] p-6 text-[#0B4F3A] shadow-2xl sm:rounded-[2rem] sm:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.2em] text-[#B58B2E]">
                  Liên hệ Bất động sản xanh
                </p>
                <h2
                  id="contact-modal-title"
                  className="mt-2 font-serif text-3xl leading-tight"
                >
                  Bạn muốn liên hệ bằng cách nào?
                </h2>
                <p className="mt-2 text-sm leading-6 text-[#60766D]">
                  Chọn kênh thuận tiện nhất hoặc để lại thông tin để được tư
                  vấn.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setContactOpen(false)}
                aria-label="Đóng cửa sổ liên hệ"
                className="rounded-full border border-[#0B4F3A]/15 p-2"
              >
                <X size={20} />
              </button>
            </div>
            <div className="mt-6 grid gap-3">
              <a
                href="tel:0989682825"
                className="flex items-center gap-4 rounded-2xl bg-[#0B4F3A] px-4 py-4 text-white transition hover:bg-[#0F6B4F]"
              >
                <span className="rounded-full bg-white/15 p-3">
                  <Phone size={21} />
                </span>
                <span>
                  <strong className="block text-base">Gọi điện tư vấn</strong>
                  <span className="text-sm text-white/70">0989 682 825</span>
                </span>
                <ArrowUpRight className="ml-auto" size={18} />
              </a>
              <a
                href="https://zalo.me/0989682825"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-4 rounded-2xl bg-[#E7F3FF] px-4 py-4 text-[#075985] transition hover:bg-[#D5ECFF]"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-[#0EA5E9] text-sm font-black text-white">
                  Z
                </span>
                <span>
                  <strong className="block text-base">Nhắn Zalo</strong>
                  <span className="text-sm text-[#075985]/70">
                    Chat trực tiếp với chuyên viên
                  </span>
                </span>
                <ArrowUpRight className="ml-auto" size={18} />
              </a>
              <a
                href="https://m.me/"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-4 rounded-2xl bg-[#EEF2FF] px-4 py-4 text-[#3730A3] transition hover:bg-[#E0E7FF]"
              >
                <span className="rounded-full bg-[#4F46E5] p-3 text-white">
                  <MessageCircle size={21} />
                </span>
                <span>
                  <strong className="block text-base">Nhắn Messenger</strong>
                  <span className="text-sm text-[#3730A3]/70">
                    Gửi tin nhắn qua Facebook
                  </span>
                </span>
                <ArrowUpRight className="ml-auto" size={18} />
              </a>
              <div className="rounded-2xl border border-[#B58B2E]/35 bg-white p-4">
                <div className="flex items-center gap-3">
                  <span className="rounded-full bg-[#B58B2E]/15 p-3 text-[#A87A24]">
                    <MessageCircle size={20} />
                  </span>
                  <div>
                    <strong className="block text-base">Đăng ký tư vấn</strong>
                    <span className="text-sm text-[#60766D]">
                      Thông tin sẽ được lưu để môi giới liên hệ.
                    </span>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => openConsultation("buy")}
                    className="rounded-xl bg-[#B58B2E] px-3 py-3 text-sm font-extrabold text-white transition hover:bg-[#A87A24]"
                  >
                    Mua BĐS
                  </button>
                  <button
                    type="button"
                    onClick={() => openConsultation("consign")}
                    className="rounded-xl border border-[#B58B2E] px-3 py-3 text-sm font-extrabold text-[#A87A24] transition hover:bg-[#FFF8E7]"
                  >
                    Ký gửi
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {consultationMode && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="consultation-modal-title"
          className="fixed inset-0 z-50 flex items-end justify-center bg-[#0B4F3A]/70 p-0 backdrop-blur-sm sm:items-center sm:p-5"
        >
          <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-[2rem] bg-[#F8FAF7] p-5 text-[#0B4F3A] shadow-2xl sm:rounded-[2rem] sm:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.2em] text-[#B58B2E]">
                  {consultationMode === "buy"
                    ? "Khách hàng mua BĐS"
                    : "Chủ nhà ký gửi"}
                </p>
                <h2
                  id="consultation-modal-title"
                  className="mt-2 font-serif text-3xl leading-tight sm:text-4xl"
                >
                  {consultationMode === "buy"
                    ? "Đăng ký nhu cầu mua BĐS"
                    : "Đăng ký ký gửi bất động sản"}
                </h2>
                <p className="mt-2 text-sm leading-6 text-[#60766D]">
                  Thông tin sẽ được lưu trong mục{" "}
                  <strong>Đăng ký tư vấn</strong> để môi giới tiếp nhận và liên
                  hệ.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setConsultationMode(null)}
                aria-label="Đóng cửa sổ"
                className="rounded-full border border-[#0B4F3A]/15 p-2"
              >
                <X size={20} />
              </button>
            </div>
            <form
              className="mt-7 grid gap-4 sm:grid-cols-2"
              onSubmit={handleSubmit}
            >
              <input
                type="hidden"
                name="interest"
                value={
                  consultationMode === "buy"
                    ? "Khách hàng mua BĐS"
                    : CONSIGNMENT_INTEREST
                }
              />
              <label className="text-xs font-bold uppercase tracking-wider text-[#60766D]">
                Họ và tên
                <input
                  required
                  name="name"
                  className="mt-1.5 w-full rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                  placeholder="Nguyễn Văn A"
                />
              </label>
              <label className="text-xs font-bold uppercase tracking-wider text-[#60766D]">
                Số điện thoại
                <input
                  required
                  name="phone"
                  type="tel"
                  className="mt-1.5 w-full rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                  placeholder="0989 682 825"
                />
              </label>
              {consultationMode === "buy" ? (
                <>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#60766D]">
                    Loại BĐS cần mua
                    <select
                      name="propertyType"
                      className="mt-1.5 w-full rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                    >
                      <option>Căn hộ</option>
                      <option>Nhà phố</option>
                      <option>Đất nền</option>
                      <option>Villa / Resort</option>
                      <option>Đất nông nghiệp</option>
                    </select>
                  </label>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#60766D]">
                    Ngân sách dự kiến
                    <input
                      name="budget"
                      className="mt-1.5 w-full rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                      placeholder="Ví dụ: 3 tỷ"
                    />
                  </label>
                </>
              ) : (
                <>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#60766D]">
                    Địa chỉ BĐS
                    <input
                      name="address"
                      className="mt-1.5 w-full rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                      placeholder="Quận/huyện, tỉnh/thành"
                    />
                  </label>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#60766D]">
                    Loại BĐS
                    <select
                      name="propertyType"
                      className="mt-1.5 w-full rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                    >
                      <option>Nhà phố</option>
                      <option>Đất nền</option>
                      <option>Căn hộ</option>
                      <option>Villa / Resort</option>
                      <option>Đất nông nghiệp</option>
                    </select>
                  </label>
                </>
              )}
              <label className="text-xs font-bold uppercase tracking-wider text-[#60766D] sm:col-span-2">
                Nội dung cần trao đổi
                <textarea
                  name="message"
                  rows={3}
                  className="mt-1.5 w-full resize-none rounded-xl border border-[#0B4F3A]/15 bg-white px-4 py-3 text-sm font-normal outline-none focus:border-[#B58B2E]"
                  placeholder={
                    consultationMode === "buy"
                      ? "Khu vực mong muốn, thời gian mua, yêu cầu khác..."
                      : "Diện tích, giá mong muốn, tình trạng giấy tờ..."
                  }
                />
              </label>
              <button
                type="submit"
                disabled={createConsultation.isPending}
                className="sm:col-span-2 inline-flex items-center justify-center gap-2 rounded-xl bg-[#B58B2E] px-5 py-4 text-base font-extrabold text-white transition hover:bg-[#A87A24] disabled:opacity-60"
              >
                {createConsultation.isPending
                  ? "Đang gửi…"
                  : "Gửi đăng ký tư vấn"}{" "}
                <ArrowUpRight size={18} />
              </button>
              <p className="sm:col-span-2 text-center text-xs text-[#60766D]">
                Chúng tôi chỉ dùng thông tin để liên hệ tư vấn và tiếp nhận nhu
                cầu.
              </p>
            </form>
          </div>
        </div>
      )}

      <section className="mx-auto mt-12 max-w-[1320px] px-6 lg:px-10">
        <PropertyLocationMap />
      </section>

      <footer className="bg-[#123C2F] px-6 py-8 text-white/60 lg:px-10">
        <div className="mx-auto flex max-w-[1320px] flex-col justify-between gap-5 text-xs sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <img src={logo} alt="" className="h-7 w-7 object-contain" />
            <span className="font-serif text-lg text-white">
              Bất động sản xanh
            </span>
          </div>
          <p>© 2026 Bất động sản xanh · Đà Nẵng & miền Trung</p>
          <div className="flex items-center gap-5">
            <a
              href="/quan-ly"
              className="transition-colors hover:text-[#1F5A4A]"
            >
              Quản lý yêu cầu
            </a>
            <a
              href="#top"
              className="flex items-center gap-2 transition-colors hover:text-[#D9B75D]"
            >
              Về đầu trang <Search size={13} className="rotate-45" />
            </a>
          </div>
        </div>
      </footer>
    </main>
  );
}
