import { describe, expect, it } from "vitest";
import { normalizeStorageKey } from "./storage";

describe("storage key normalization", () => {
  it("returns an ASCII-safe key for Vietnamese filenames", () => {
    const key = normalizeStorageKey("dvc-official/monre.gov.vn/abc-Mẫu đơn đất đai (bản chính).docx");
    expect(key).toBe("dvc-official/monre.gov.vn/abc-Mau__on__at__ai_ban_chinh_.docx");
    expect(key).toMatch(/^[\x00-\x7F]+$/);
    expect(key).not.toContain(" ");
  });

  it("keeps path separators and removes leading or repeated separators", () => {
    const key = normalizeStorageKey("///legal///Mẫu 14?.pdf");
    expect(key).toBe("legal/Mau_14_.pdf");
    expect(key).not.toContain("//");
  });
});
