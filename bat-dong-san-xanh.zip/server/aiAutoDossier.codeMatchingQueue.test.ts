import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { searchOfficialLandProcedures } from "./officialLandProcedureRegistry";

describe("AI dossier code matching queue", () => {
  it("exposes a non-destructive queue endpoint and never promises automatic Official status", () => {
    const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(routerSource).toContain("queueCodeMatching: protectedProcedure");
    expect(routerSource).toContain("status: candidates.length ? \"queued\" as const : \"unmatched\" as const");
    expect(routerSource).toContain("chưa tự gắn thủ tục");
  });

  it("can propose registry candidates for a document containing a known procedure code", () => {
    const candidates = searchOfficialLandProcedures("2.002317");
    expect(candidates.some(item => item.code === "2.002317")).toBe(true);
  });

  it("merges database procedures into the shared AI catalog", () => {
    const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(routerSource).toContain("const databaseItems = await listLegalProcedures(query);");
    expect(routerSource).toContain("catalogCount: items.length");
    expect(routerSource).toContain("không tự tạo mã từ tên file");
  });

  it("keeps the dossier admin selector on the dynamic catalog contract", () => {
    const source = readFileSync(new URL("../client/src/pages/AIDossierAdmin.tsx", import.meta.url), "utf8");
    expect(source).toContain("aiAutoDossier.catalog");
    expect(source).not.toContain("const landProcedures = [");
  });
});
