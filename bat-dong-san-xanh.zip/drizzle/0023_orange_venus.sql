CREATE TABLE `legal_scan_queue` (
	`id` int AUTO_INCREMENT NOT NULL,
	`procedureCode` varchar(32) NOT NULL,
	`province` varchar(120),
	`status` enum('queued','running','succeeded','pending','failed') NOT NULL DEFAULT 'queued',
	`attempts` int NOT NULL DEFAULT 0,
	`lastHttpStatus` int,
	`lastSourceUrl` text,
	`lastError` text,
	`nextAttemptAt` timestamp,
	`lockedAt` timestamp,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_scan_queue_id` PRIMARY KEY(`id`),
	CONSTRAINT `legal_scan_queue_procedure_province_unique` UNIQUE(`procedureCode`,`province`)
);
--> statement-breakpoint
CREATE INDEX `legal_scan_queue_next_attempt_idx` ON `legal_scan_queue` (`status`,`nextAttemptAt`);