import { useEffect, useMemo, useRef, useState } from "react";
import { Compass, MapPin, Search } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";

type NearbyProperty = { id: number; title: string; slug: string; price: string | number; area: string | number; location: string; latitude: string | number | null; longitude: string | number | null };
type Point = { lat: number; lng: number };

export function haversineKm(from: Point, to: Point) {
  const earthRadius = 6371;
  const dLat = (to.lat - from.lat) * Math.PI / 180;
  const dLng = (to.lng - from.lng) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(from.lat * Math.PI / 180) * Math.cos(to.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return earthRadius * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const getPoint = (property: NearbyProperty): Point | null => {
  const lat = Number(property.latitude);
  const lng = Number(property.longitude);
  return Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : null;
};
const money = (value: string | number) => `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 }).format(Number(value))} tỷ`;

export default function CrmNearbyProperties() {
  const [lat, setLat] = useState("16.0544");
  const [lng, setLng] = useState("108.2022");
  const [radius, setRadius] = useState("5");
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const queryInput = useMemo(() => ({ sort: "newest" as const }), []);
  const propertiesQuery = trpc.properties.list.useQuery(queryInput, { staleTime: 60_000 });
  const center = useMemo(() => ({ lat: Number(lat) || 0, lng: Number(lng) || 0 }), [lat, lng]);
  const nearby = useMemo(() => (propertiesQuery.data as NearbyProperty[] | undefined ?? []).map(property => { const point = getPoint(property); return point ? { property, distance: haversineKm(center, point) } : null; }).filter((item): item is { property: NearbyProperty; distance: number } => item !== null && item.distance <= Math.max(0, Number(radius) || 0)).sort((a, b) => a.distance - b.distance), [propertiesQuery.data, center, radius]);

  useEffect(() => {
    if (!mapRef.current || !window.google) return;
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = nearby.map(({ property }) => { const point = getPoint(property); return new window.google!.maps.Marker({ map: mapRef.current!, position: point!, title: property.title }); });
    return () => { markersRef.current.forEach(marker => marker.setMap(null)); markersRef.current = []; };
  }, [nearby]);

  return <section data-responsive-section="CRM Nearby Properties" className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">Nguồn hàng lân cận</p><h2 className="mt-2 font-serif text-2xl text-[#173b35]">Tìm BĐS xung quanh</h2><p className="mt-1 text-sm leading-6 text-[#688078]">Lọc những bài đăng có tọa độ trong bán kính quanh vị trí đang khảo sát để chọn sản phẩm so sánh hoặc giới thiệu thêm cho khách.</p></div><Compass className="h-7 w-7 text-[#25725e]" /></div>
    <div className="mt-5 grid gap-3 sm:grid-cols-3"><label className="text-sm font-semibold text-[#527068]">Vĩ độ<input inputMode="decimal" value={lat} onChange={event => setLat(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35]" /></label><label className="text-sm font-semibold text-[#527068]">Kinh độ<input inputMode="decimal" value={lng} onChange={event => setLng(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35]" /></label><label className="text-sm font-semibold text-[#527068]">Bán kính (km)<input inputMode="decimal" value={radius} onChange={event => setRadius(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35]" /></label></div>
    <div className="mt-4 grid gap-4 xl:grid-cols-[1.15fr_0.85fr]"><div className="overflow-hidden rounded-2xl border border-[#dce7df] bg-[#edf5ef]"><MapView className="h-[320px] min-h-[320px]" initialCenter={center.lat && center.lng ? center : { lat: 16.0544, lng: 108.2022 }} initialZoom={12} onMapReady={map => { mapRef.current = map; }} /></div><div className="space-y-3"><div className="flex items-center justify-between rounded-2xl bg-[#e7f1e9] px-4 py-3 text-sm"><span className="font-bold text-[#173b35]">Kết quả có tọa độ</span><span className="font-bold text-[#1e6a59]">{nearby.length}</span></div>{propertiesQuery.isLoading ? <p className="rounded-2xl bg-white p-4 text-sm text-[#688078]">Đang tải nguồn hàng…</p> : nearby.length === 0 ? <p className="rounded-2xl border border-dashed border-[#cfe1d7] bg-white p-4 text-sm leading-6 text-[#688078]">Chưa có BĐS có tọa độ trong bán kính này. Hãy nhập tọa độ khác hoặc bổ sung vị trí cho nguồn hàng.</p> : nearby.slice(0, 6).map(({ property, distance }) => <a key={property.id} href={`/bat-dong-san/${property.slug}`} className="block rounded-2xl border border-[#dce7df] bg-white p-4 transition-colors hover:border-[#a9cdb9]"><div className="flex items-start gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#25725e]" /><div className="min-w-0"><p className="truncate text-sm font-bold text-[#173b35]">{property.title}</p><p className="mt-1 text-xs text-[#688078]">{property.location}</p><p className="mt-2 text-xs font-semibold text-[#1e6a59]">{distance.toFixed(1)} km · {money(property.price)} · {property.area} m²</p></div></div></a>)}</div></div><p className="mt-4 flex items-start gap-2 text-xs leading-5 text-[#688078]"><Search className="mt-0.5 h-3.5 w-3.5 shrink-0" />Chỉ các nguồn hàng có tọa độ hợp lệ mới được tính khoảng cách. Kết quả phụ thuộc dữ liệu đã lưu và không thay thế khảo sát thực tế.</p>
  </section>;
}
