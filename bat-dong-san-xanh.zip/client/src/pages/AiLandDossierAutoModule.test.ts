import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { upsertUploadedDossierFile } from "@/lib/uploadedDossierFiles";

const pageSource = readFileSync(
  resolve(process.cwd(), "client/src/pages/AiLandDossierPipeline.tsx"),
  "utf8"
);
const autoModuleSource = readFileSync(
  resolve(process.cwd(), "client/src/pages/AiLandDossierAutoModule.tsx"),
  "utf8"
);
const appSource = readFileSync(
  resolve(process.cwd(), "client/src/App.tsx"),
  "utf8"
);
const layoutSource = readFileSync(
  resolve(process.cwd(), "client/src/components/DashboardLayout.tsx"),
  "utf8"
);

const uploadedFile = (
  id: string,
  extractedFields: { label: string; value: string }[] = []
) => ({
  id,
  fileName: "giay-to.jpg",
  componentId: "general",
  componentName: "Tài liệu bổ sung chung",
  mimeType: "image/jpeg",
  extractedFields,
});

describe("uploaded dossier file identity", () => {
  it("keeps one row when the same file is selected again and refreshes OCR fields", () => {
    const first = uploadedFile("general-giay-to.jpg-123", []);
    const refreshed = uploadedFile("general-giay-to.jpg-123", [
      { label: "Diện tích", value: "10012" },
    ]);
    const result = upsertUploadedDossierFile([first, first], refreshed);

    expect(result).toHaveLength(1);
    expect(result[0]?.extractedFields).toEqual([
      { label: "Diện tích", value: "10012" },
    ]);
  });

  it("preserves different files and components as separate rows", () => {
    const result = upsertUploadedDossierFile(
      [uploadedFile("general-a-1")],
      uploadedFile("identity-b-2")
    );

    expect(result.map(file => file.id)).toEqual([
      "general-a-1",
      "identity-b-2",
    ]);
  });
});

describe("AI land dossier pipeline module", () => {
  it("has its own route and dashboard menu entry", () => {
    expect(appSource).toContain("/ai-ho-so-dat-dai-tu-dong");
    expect(layoutSource).toContain('label: "Trợ lý AI", path: "/dashboard/ai"');
    expect(layoutSource).toContain("Chọn thủ tục & quét nguồn");
  });

  it("builds the workflow from procedure metadata instead of a fixed eight-step list", () => {
    expect(pageSource).toContain("trpc.legalKnowledge.searchOfficial.useQuery");
    expect(pageSource).toContain("official.data?.procedure as");
    expect(pageSource).toContain("procedureMeta?.workflowSteps?.length");
    expect(pageSource).toContain("procedureMeta?.requirements");
    expect(pageSource).toContain("return sourceSteps.map((step, index)");
  });

  it("explains that component readiness and file classification use different units", () => {
    expect(autoModuleSource).toContain("thành phần sẵn sàng");
    expect(autoModuleSource).toContain(
      "Official/Reference/Pending bên dưới được đếm theo từng tệp"
    );
  });

  it("syncs the full catalog instead of truncating it to 66 procedures", () => {
    expect(autoModuleSource).toContain(
      "const procedures = retryCodes?.length ? availableProcedures.filter"
    );
    expect(autoModuleSource).toContain(": availableProcedures;");
    expect(autoModuleSource).not.toContain("availableProcedures.slice(0, 66)");
  });

  it("does not enable Official export without a verified template binary", () => {
    expect(autoModuleSource).toContain(
      "const officialStatusAsset = official.data?.templateFile?.items?.[0]"
    );
    expect(autoModuleSource).toContain(
      "const canExportOfficial = isVerifiedBinaryAsset(officialStatusAsset);"
    );
    expect(autoModuleSource).toContain(
      "trpc.aiAutoDossier.discover.useMutation"
    );
    expect(autoModuleSource).toContain(
      "trpc.landDossierBuilder.ocr.useMutation"
    );
    expect(autoModuleSource).toContain(
      "trpc.landDossierBuilder.exportBundle.useMutation"
    );
    expect(autoModuleSource).toContain("Chỉ có Draft/Reference");
    expect(autoModuleSource).toContain("Tải bản nháp DOCX");
    expect(autoModuleSource).toContain("không gọi bản nháp là Official");
  });
});

it("requires a real verified binary before showing Official readiness", () => {
  expect(autoModuleSource).toContain(
    "export const isVerifiedBinaryAsset = (asset: unknown): boolean"
  );
  expect(autoModuleSource).toContain(
    "/^[a-f0-9]{64}$/i.test(candidate.checksum.trim())"
  );
  expect(autoModuleSource).toContain(
    'candidate.status === "verified_binary" || candidate.verified === true'
  );
  expect(autoModuleSource).toContain(
    "/^https?:\\/\\//i.test(candidate.sourceUrl.trim())"
  );
  expect(autoModuleSource).toContain(
    'templateProvenance: canExportOfficial ? "verified-binary" : "metadata-only"'
  );
});

it("renders a concise preview with explicit Official/Reference labels and pre-submission checks", () => {
  expect(autoModuleSource).toContain("Tổng hợp thành phần hồ sơ");
  expect(autoModuleSource).toContain("Xem bản Official");
  expect(autoModuleSource).toContain("Tải mẫu để đối chiếu");
  expect(autoModuleSource).toContain("Kiểm tra trước khi nộp cơ quan");
  expect(autoModuleSource).toContain(
    "Chưa có binary Official; không gắn nhãn Official cho bản nháp."
  );
  expect(autoModuleSource).toContain("readyForSubmissionReview");
});

it("supports a procedure outside the eleven seeded procedures without reclassifying files", () => {
  expect(autoModuleSource).toContain(
    "const official = trpc.legalKnowledge.officialStatus.useQuery({ code: selectedCode"
  );
  expect(autoModuleSource).toContain(
    "const legalBundleQuery = trpc.legalKnowledge.bundle.useQuery({ code: selectedCode });"
  );
  expect(autoModuleSource).toContain("const persisted = legalBundleQuery.data");
  expect(autoModuleSource).toContain(
    'item.provenance === "verified_binary" || item.provenance === "official"'
  );
  expect(autoModuleSource).toContain(
    "Boolean(item.checksum) && Boolean(item.storageKey || item.fileUrl)"
  );
  expect(autoModuleSource).toContain(
    "const dvcBundle = generatedPlan?.procedureBundle;"
  );
  expect(autoModuleSource).toContain('file.status === "verified_binary"');
  expect(autoModuleSource).toContain(
    "const previewOfficialTemplate = isVerifiedBinaryAsset(officialStatusAsset) ? officialStatusAsset : undefined;"
  );
  expect(autoModuleSource).toContain('file.status === "matched_reference"');
  expect(autoModuleSource).toContain('status: "needs_file"');
  expect(autoModuleSource).toContain(
    "const procedures = retryCodes?.length ? availableProcedures.filter"
  );
});

it("keeps the 2912 alias on the persisted 2.000889 legal bundle path", () => {
  const registrySource = readFileSync(
    resolve(process.cwd(), "server/officialLandProcedureRegistry.ts"),
    "utf8"
  );
  const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
  expect(registrySource).toContain('code: "2.000889"');
  expect(registrySource).toContain('externalCodes: ["2912"]');
  expect(dbSource).toContain("getLegalProcedureBundle");
  expect(autoModuleSource).toContain("legalBundleQuery.data");
  expect(autoModuleSource).toContain('status: "verified_binary" as const');
});

it("enforces the new source-first workflow before AI analysis", () => {
  const procedureStep = autoModuleSource.indexOf("Tìm thủ tục");
  const provinceStep = autoModuleSource.indexOf("Tỉnh/thành áp dụng");
  const uploadStep = autoModuleSource.indexOf("Chụp/tải");
  const bundleGate = autoModuleSource.indexOf("Chưa có bundle cho mã này");
  expect(procedureStep).toBeGreaterThanOrEqual(0);
  expect(provinceStep).toBeGreaterThan(procedureStep);
  expect(uploadStep).toBeGreaterThan(provinceStep);
  expect(bundleGate).toBeGreaterThanOrEqual(0);
  expect(autoModuleSource).toContain("Kho AI pháp lý");
  expect(autoModuleSource).toContain(
    "disabled={analyzeDossier.isPending || !procedureBundle || buildPlan.isPending}"
  );
});

it("puts profile input before upload and OCR", () => {
  const profileStep = autoModuleSource.indexOf('stage === "profile"');
  const profileHeading = autoModuleSource.indexOf("Thông tin điền vào");
  const uploadStep = autoModuleSource.indexOf('stage === "upload"');
  const uploadHeading = autoModuleSource.indexOf(
    "Chụp/tải giấy tờ ngay trong phần Điền thông tin"
  );
  expect(profileStep).toBeGreaterThanOrEqual(0);
  expect(profileHeading).toBeGreaterThan(profileStep);
  expect(uploadStep).toBeGreaterThan(profileStep);
  expect(uploadHeading).toBeGreaterThan(uploadStep);
  expect(autoModuleSource).toContain('choose: "profile", analyze: "profile"');
  expect(autoModuleSource).toContain("profile: 2, upload: 3");
});

it("auto-loads the legal bundle before advancing from selection or analysis", () => {
  expect(autoModuleSource).toContain(
    '(stage === "choose" || stage === "analyze") && !procedureBundle'
  );
  expect(autoModuleSource).toContain(
    "const requestKey = `${selectedCode}::${province.trim()}`"
  );
  expect(autoModuleSource).toContain(
    "discover.mutate({ procedureCode: selectedCode, province: province.trim() || undefined })"
  );
  expect(autoModuleSource).toContain(
    "trpcUtils.legalKnowledge.bundle.invalidate({ code: variables.procedureCode })"
  );
  expect(autoModuleSource).toContain("Đã tự động nạp nguồn Kho AI pháp lý");
  expect(autoModuleSource).toContain("await legalBundleQuery.refetch()");
  expect(autoModuleSource).toContain(
    'value={canExportOfficial ? String(officialTemplates.length) : "0"}'
  );
  expect(autoModuleSource).toContain('stage === "choose"');
});

it("uses the discover snapshot to build the plan once instead of refetching the same external sources", () => {
  expect(autoModuleSource).toContain("setGeneratedPlan(data.plan)");
  expect(autoModuleSource).not.toContain(
    "buildPlan.mutate({ procedureCode: variables.procedureCode"
  );
  const routerSource = readFileSync(
    resolve(process.cwd(), "server/routers.ts"),
    "utf8"
  );
  expect(routerSource).toContain(
    "plan: buildPlanFromWorkflow(input, workflow)"
  );
  expect(routerSource).toContain("function buildPlanFromWorkflow");
});

describe("procedure selection interaction", () => {
  it("keeps the procedure row clickable and reflects the selected code", () => {
    expect(autoModuleSource).toContain(
      "onClick={() => setSelectedCode(item.code)}"
    );
    expect(autoModuleSource).toContain(
      'item.code === selectedCode ? "border-[#1f5a4a] bg-[#eef7e9]"'
    );
  });
});

describe("safe API list normalization", () => {
  it("sends every uploaded document and its OCR fields into dossier analysis", () => {
    const routerSource = readFileSync(
      resolve(process.cwd(), "server/routers.ts"),
      "utf8"
    );
    expect(autoModuleSource).toContain("uploadedDocuments: files.map(file =>");
    expect(autoModuleSource).toContain(
      "extractedFields: file.extractedFields || []"
    );
    expect(routerSource).toContain("uploadedDocuments: z.array(z.object");
    expect(routerSource).toContain(
      "Không bỏ qua tài liệu nào đã được cung cấp"
    );
  });

  it("normalizes optional catalog, bundle, attachment, component, and input lists before filtering or mapping", () => {
    expect(autoModuleSource).toContain(
      "const asArray = <T,>(value: unknown): T[] => Array.isArray(value) ? value as T[] : [];"
    );
    expect(autoModuleSource).toContain(
      "asArray<ProcedureInputField>(getProcedureInputSchema"
    );
    expect(autoModuleSource).toContain(
      "asArray<{ id: string; name: string; kind?: string"
    );
    expect(autoModuleSource).toContain('kind: item.kind || "file"');
    expect(autoModuleSource).toContain('status: item.status || "pending"');
    expect(autoModuleSource).toContain(
      "asArray<{ id: string; name: string; required?: boolean"
    );
    expect(autoModuleSource).toContain(
      "const safeFields = Array.isArray(data?.fields) ? data.fields : [];"
    );
    expect(autoModuleSource).toContain(
      "const ocrResult = await ocr.mutateAsync"
    );
    expect(autoModuleSource).toContain(
      "setFiles(current => upsertUploadedDossierFile(current"
    );
  });
});

describe("auto dossier bundle progress table", () => {
  it("renders detailed source, checksum, and Official verification states in the auto module", () => {
    expect(autoModuleSource).toContain("Tiến độ nạp và xác minh nguồn");
    expect(autoModuleSource).toContain("Đang tải nguồn");
    expect(autoModuleSource).toContain("Đang kiểm SHA-256");
    expect(autoModuleSource).toContain("Official binary verified");
    expect(autoModuleSource).toContain("metadata-only");
    expect(autoModuleSource).toContain("Bộ nguồn tự động · {selectedCode}");
  });

  it("keeps failed and active progress states visible instead of an indefinite spinner", () => {
    expect(autoModuleSource).toContain("Không tải được bundle; hãy thử lại.");
    expect(autoModuleSource).toContain("Đang đối chiếu checksum của binary.");
    expect(autoModuleSource).toContain('aria-label="Đang xử lý"');
    expect(autoModuleSource).toContain('row.status === "failed"');
  });
});

it("explains that an unauthorized bundle request requires login", () => {
  expect(autoModuleSource).toContain(
    "Cần đăng nhập để đọc bundle Kho AI pháp lý và xác minh Official."
  );
  expect(autoModuleSource).toContain(
    "Phiên đăng nhập chưa có hoặc đã hết hạn; hãy đăng nhập để nạp bundle."
  );
  expect(autoModuleSource).toContain(
    'legalBundleQuery.error?.message === "Please login (10001)"'
  );
});

it("maps the primary automatic land dossier route to the auto module", () => {
  expect(appSource).toContain('path="/ai-ho-so-dat-dai-tu-dong"');
  expect(appSource).toContain("component={AiLandDossierAutoModule}");
});

it("uses the persisted bundle components as the AI dossier source of truth", () => {
  expect(autoModuleSource).toContain(
    "dossierComponents: bundledComponents.map"
  );
  expect(autoModuleSource).toContain("Bộ nguồn Kho AI pháp lý tự nạp theo mã");
  expect(autoModuleSource).toContain("Đã tự nạp bundle");
  expect(autoModuleSource).not.toContain("Nạp nguồn vào hồ sơ");
});

it("labels unresolved catalog names without inventing an official procedure name", () => {
  expect(autoModuleSource).toContain('item.title.startsWith("Cần đối soát")');
  expect(autoModuleSource).toContain("Cần đối soát tên");
  expect(autoModuleSource).toContain("không được suy đoán tên chính thức");
});

describe("production coverage report", () => {
  it("queries the full catalog and labels Official-ready versus Reference/Pending without inventing Official status", () => {
    expect(autoModuleSource).toContain(
      "const coverageCodes = useMemo(() => availableProcedures.map(item => item.code).sort(), [availableProcedures]);"
    );
    expect(autoModuleSource).toContain(
      "trpc.aiAutoDossier.pendingStatuses.useQuery({ procedureCodes: coverageCodes }"
    );
    expect(autoModuleSource).toContain(
      "const officialReady = productionCoverage.data?.officialReadyCodes.length ?? 0"
    );
    expect(autoModuleSource).toContain("Official-ready");
    expect(autoModuleSource).toContain("Reference/Pending");
    expect(autoModuleSource).toContain("không tự gắn Official");
  });
});

describe("discover failure recovery", () => {
  it("does not reset the auto-discover key after an error and exposes an explicit retry action", () => {
    expect(autoModuleSource).toContain(
      "Nạp nguồn thất bại: ${error.message}. Bạn có thể thử lại."
    );
    expect(autoModuleSource).toContain(
      'if (syncRunState !== "running") toast.error'
    );
    expect(autoModuleSource).toContain(
      'if (!selectedCode || syncRunState === "running") return;'
    );
    expect(autoModuleSource).toContain("const retryDiscover = () =>");
    expect(autoModuleSource).toContain(
      "autoDiscoverKeyRef.current = requestKey;"
    );
    expect(autoModuleSource).toContain("Thử lại</Button>");
  });
});

describe("analysis error presentation", () => {
  it("maps technical validation and upstream errors to concise retry guidance", () => {
    expect(autoModuleSource).toContain(
      "export function formatDossierAnalysisError"
    );
    expect(autoModuleSource).toContain("dossierComponents");
    expect(autoModuleSource).toContain("Hãy bấm Thử lại");
    expect(autoModuleSource).toContain("Nguồn AI đang tạm thời không phản hồi");
    expect(autoModuleSource).toContain("formatDossierAnalysisError(error)");
  });
});

describe("document capture and upload progress", () => {
  it("exposes explicit capture, file-reading, upload/OCR, success, and error states", () => {
    expect(autoModuleSource).toContain(
      "setUploadStatusMessage(`Đang đọc ${picked.length} tệp đã chọn..."
    );
    expect(autoModuleSource).toContain(
      "setUploadStatusMessage(`Đang chuẩn bị ${file.name}"
    );
    expect(autoModuleSource).toContain("Đang tải lên và đọc OCR");
    expect(autoModuleSource).toContain("uploadStatusMessage");
    expect(autoModuleSource).toContain("Không thể xử lý tệp");
  });

  it("prevents duplicate capture or file selection while a document is processing", () => {
    expect(autoModuleSource).toContain("disabled={ocr.isPending}");
    expect(autoModuleSource).toContain(
      'ocr.isPending ? "Đang tải lên..." : "Tải ảnh/tệp"'
    );
    expect(autoModuleSource).toContain("setUploadStatusMessage");
  });
});
