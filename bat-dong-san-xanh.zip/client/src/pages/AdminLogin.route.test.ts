import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("admin login destination", () => {
  const source = readFileSync(resolve(process.cwd(), "client/src/pages/AdminLogin.tsx"), "utf8");

  it("returns the administrator to the full dashboard after the legacy login", () => {
    expect(source).toContain('navigate(isCrmLogin ? "/crm" : "/dashboard")');
    expect(source).not.toContain('navigate("/ai-ho-so-dat-dai-tu-dong")');
  });

  it("provides a dedicated CRM login entry and return path", () => {
    expect(source).toContain('const normalizedPath = window.location.pathname.replace');
    expect(source).toContain('normalizedPath === "/crm/login" || normalizedPath === "/dang-nhap-quan-tri"');
    expect(source).toContain('isCrmLogin ? "/crm" : "/dashboard"');
  });

  it("exposes the yellow password-change entry point and protected mutation", () => {
    expect(source).toContain('Đổi mật khẩu');
    expect(source).toContain('trpc.auth.changePasswordFromLogin.useMutation');
    expect(source).toContain('bg-[#e7b93f]');
    expect(source).toContain('currentPassword');
    expect(source).toContain('confirmPassword');
  });

  it("keeps public and admin entry points separate", () => {
    const app = readFileSync(resolve(process.cwd(), "client/src/App.tsx"), "utf8");
    expect(app).toContain('<Route path="/" component={Home} />');
    expect(app).toContain('<Route path="/dashboard" component={CrmDashboard} />');
    expect(app).toContain('<Route path="/dang-nhap-quan-tri" component={AdminLogin} />');
    expect(app).toContain('<Route path="/crm/login" component={AdminLogin} />');
  });
});
