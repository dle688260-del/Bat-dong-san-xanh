import { describe, expect, it } from "vitest";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { confirmPropertyDeletion, findAutomaticArea, filterAreasByProvince, getBrokerageErrorMessage, getPropertyDeleteDescription, getSoldDossierRoute, getSoldPropertyToastAction, isAcceptedProperty3DFile, isAcceptedPropertyImageUrl, MEDIA_PREPARATION_ACTIONS, getPropertySubmission, normalizePropertyArea, normalizePropertyMeasure, normalizePropertyType, PropertyTable, removeUploadedImage, submitPropertyForm, getGalleryLayout, getSourceCreationContext, getWorkflowStepResponsibility, getSourceWorkflowStepSchema, readSourceWorkflowStepAiLogs, readSourceWorkflowFiles, readSourceWorkflowOcrPreview, formatSourceWorkflowFileSize, matchOcrFieldId, mapSourceWorkflowOcrFields, getSourceIntakeFieldValue, SourceSpecificIntake, SOURCE_INTAKE_FIELDS, SOURCE_CHANNELS, SOURCE_CREATION_PHASES, SOURCE_PROPERTY_CATEGORIES, SOURCE_COMMON_STEP_FIELDS } from "./BrokerageAdmin";

const values: Record<string, string> = {
  title: "Nhà 2 tầng Thanh Khê", slug: "nha-2-tang-thanh-khe", propertyType: "house", price: "7.9", area: "95", buildArea: "180", bedrooms: "4", bathrooms: "3", constructionYear: "2020", location: "Thanh Khê, Đà Nẵng", areaId: "3", orientation: "Đông Nam", legalStatus: "Sổ đỏ", certificateType: "Giấy chứng nhận quyền sử dụng đất", certificateArea: "95", landUsePurpose: "Đất ở đô thị", planningStatus: "Không vướng quy hoạch theo hồ sơ", mortgageStatus: "Không thế chấp", legalSource: "Chủ nhà cung cấp", brokerageFee: "1%", depositTerms: "Đặt cọc theo thỏa thuận", transactionTerms: "Công chứng trong 30 ngày", propertyCode: "BDS-TK-001", brokerName: "Lê Văn Tiến", brokerPhone: "0989682825", brokerZalo: "https://zalo.me/0989682825", imageFront: "https://example.com/front.jpg", imageLivingRoom: "https://example.com/living-room.jpg", imageBedroom: "https://example.com/bedroom.jpg", imageKitchen: "https://example.com/kitchen.jpg", imageOutdoor: "https://example.com/outdoor.jpg", imageRoad: "https://example.com/road.jpg", imageLegal: "https://example.com/legal.jpg", ownerName: "Chủ nhà Thanh Khê", ownerPhone: "0900000000", description: "Nhà sáng, công năng đủ." 
};
const text = (key: string) => values[key] || "";
const num = (key: string) => Number(values[key] || 0);

describe("BrokerageAdmin property payload", () => {
  it("explains how to resolve permission errors", () => {
    expect(getBrokerageErrorMessage("You do not have required permission (10002)")).toContain("role admin");
    expect(getBrokerageErrorMessage("Please login (10001)")).toContain("đăng nhập");
  });
  it("describes the destructive delete confirmation with the property title", () => {
    expect(getPropertyDeleteDescription("Nhà ven sông Hòa Xuân")).toContain("Nhà ven sông Hòa Xuân");
    expect(getPropertyDeleteDescription("Nhà ven sông Hòa Xuân")).toContain("không thể hoàn tác");
  });
  it("only invokes delete mutation after confirmation", () => {
    const onDelete = (id: number) => calls.push(id);
    const calls: number[] = [];
    confirmPropertyDeletion(21, false, onDelete);
    expect(calls).toEqual([]);
    confirmPropertyDeletion(21, true, onDelete);
    expect(calls).toEqual([21]);
  });
  it("renders an accessible delete action in the property table", () => {
    const html = renderToStaticMarkup(React.createElement(PropertyTable, { data: [{ id: 21, title: "Nhà mẫu Sơn Trà", location: "Sơn Trà", price: "5.2", area: "80", status: "draft" }], onStatus: () => undefined, onDelete: () => undefined }));
    expect(html).toContain("Xóa Nhà mẫu Sơn Trà");
    expect(html).toContain("Xóa");
  });
  it("renders bulk selection and warehouse actions for multiple records", () => {
    const html = renderToStaticMarkup(React.createElement(PropertyTable, {
      data: [
        { id: 21, title: "Nhà mẫu Sơn Trà", location: "Sơn Trà", price: "5.2", area: "80", status: "draft" },
        { id: 22, title: "Đất nền Hòa Xuân", location: "Cẩm Lệ", price: "3.1", area: "100", status: "reserved" },
      ],
      onStatus: () => undefined,
      onDelete: () => undefined,
      selectedIds: [21, 22],
      onToggleSelect: () => undefined,
      onToggleSelectAll: () => undefined,
      onBulkStatus: () => undefined,
    }));
    expect(html).toContain("Chọn tất cả hồ sơ trong nhóm");
    expect(html).toContain("Chọn hồ sơ Nhà mẫu Sơn Trà");
    expect(html).toContain("Duyệt &amp; công khai");
    expect(html).toContain("Chuyển đặt chỗ");
    expect(html).toContain("Chuyển đã bán");
  });
  it("exposes the video and 3D preparation actions with safe file extensions", () => {
    expect(MEDIA_PREPARATION_ACTIONS.map(action => action.label)).toEqual(["Quay/Tải video", "Quét 3D"]);
    expect(isAcceptedProperty3DFile("scan.usdz")).toBe(true);
    expect(isAcceptedProperty3DFile("model.glb")).toBe(true);
    expect(isAcceptedProperty3DFile("notes.pdf")).toBe(false);
  });
  it("removes one uploaded image without changing the remaining order", () => {
    expect(removeUploadedImage(["/manus-storage/a.jpg", "/manus-storage/b.jpg"], "/manus-storage/a.jpg")).toEqual(["/manus-storage/b.jpg"]);
    expect(isAcceptedPropertyImageUrl("/manus-storage/a.jpg")).toBe(true);
    expect(isAcceptedPropertyImageUrl("data:image/png;base64,broken")).toBe(false);
  });
  it("updates gallery layout from the selected image count", () => {
    expect(getGalleryLayout(0)).toEqual({ columns: 1, label: "1 ảnh" });
    expect(getGalleryLayout(1)).toEqual({ columns: 1, label: "1 ảnh" });
    expect(getGalleryLayout(2)).toEqual({ columns: 2, label: "2 ảnh" });
    expect(getGalleryLayout(3)).toEqual({ columns: 2, label: "3 ảnh" });
    expect(getGalleryLayout(8)).toEqual({ columns: 3, label: "3+ ảnh" });
  });
  it("automatically chooses a province and matching area from the location", () => {
    expect(findAutomaticArea("Thanh Khê, Đà Nẵng", [{ id: 3, name: "Thanh Khê", province: "Đà Nẵng" }])).toEqual({ province: "Đà Nẵng", areaId: 3 });
  });
  it("filters detailed areas by the selected province and keeps all areas when empty", () => {
    const areas = [{ id: 1, name: "Thanh Khê", province: "Đà Nẵng" }, { id: 2, name: "Hải Châu", province: "Đà Nẵng" }, { id: 3, name: "Sơn Trà", province: "Quảng Nam" }];
    expect(filterAreasByProvince(areas, "Đà Nẵng")).toEqual([areas[0], areas[1]]);
    expect(filterAreasByProvince(areas, "")).toEqual(areas);
  });
  it("keeps no more than eight accepted image URLs in the payload", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("imageUrls", Array.from({ length: 3 }, (_, index) => `/manus-storage/upload-${index}.jpg`).join("\n"));
    const payload = getPropertySubmission(formData);
    expect(payload.imageUrls).toHaveLength(8);
    expect(payload.imageUrls.every(isAcceptedPropertyImageUrl)).toBe(true);
  });
  it("normalizes Vietnamese property labels to backend enum values", () => {
    expect(normalizePropertyType("Nhà ở")).toBe("house");
    expect(normalizePropertyType("Đất nền")).toBe("land");
    expect(normalizePropertyType("Căn hộ chung cư")).toBe("apartment");
    expect(normalizePropertyType("Biệt thự nghỉ dưỡng")).toBe("villa");
  });
  it("exposes dedicated profiles and fields for the expanded property catalog", async () => {
    const { LISTING_PROFILES } = await import("@/lib/propertyListingRegistry");
    const profile = (transaction: string, propertyType: string) => LISTING_PROFILES.find(item => item.transaction === transaction && item.propertyType === propertyType);
    expect(profile("sale", "commercial_land")?.fields.map(field => field.name)).toContain("businessPurpose");
    expect(profile("sale", "agricultural")?.fields.map(field => field.name)).toContain("cultivationType");
    expect(profile("rent", "commercial")?.fields.map(field => field.name)).toContain("leaseTerm");
    expect(profile("rent", "resort")?.fields.map(field => field.name)).toContain("capacity");
    expect(profile("sale", "project")?.fields.map(field => field.name)).toContain("projectName");
    expect(profile("rent", "rental")?.fields.map(field => field.name)).toContain("businessPurpose");
  });
  it("normalizes OCR area values with m² and Vietnamese thousand separators", () => {
    expect(normalizePropertyArea("10.012 m²")).toBe("10012");
    expect(normalizePropertyArea("95,5 m2")).toBe("95.5");
    expect(normalizePropertyArea("120.25")).toBe("120.25");
  });
  it("normalizes road width and certificate area values before submission", () => {
    expect(normalizePropertyMeasure("5 m")).toBe("5");
    expect(normalizePropertyMeasure("3,5 mét")).toBe("3.5");
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("roadWidth", "5 m");
    formData.set("certificateArea", "10.012 m²");
    const payload = getPropertySubmission(formData);
    expect(payload.roadWidth).toBe("5");
    expect(payload.certificateArea).toBe("10012");
  });
  it("persists the selected gallery layout in listingDetails", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("galleryLayout", "mosaic");
    const payload = getPropertySubmission(formData);
    expect(JSON.parse(String(payload.listingDetails)).galleryLayout).toBe("mosaic");
  });
  it("falls back to the safe gallery layout when the selection is invalid", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("galleryLayout", "invalid");
    const payload = getPropertySubmission(formData);
    expect(JSON.parse(String(payload.listingDetails)).galleryLayout).toBe("single");
  });
  it("stores type-specific listing fields separately in listingDetails", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("listingType", "rent");
    formData.set("propertyType", "industrial");
    formData.set("industries", "Kho vận, sản xuất");
    formData.set("infrastructure", "Điện 3 pha, đường container");
    formData.set("leaseTerm", "50 năm");
    const payload = getPropertySubmission(formData);
    const details = JSON.parse(String(payload.listingDetails));
    expect(details).toMatchObject({ industries: "Kho vận, sản xuất", infrastructure: "Điện 3 pha, đường container", leaseTerm: "50 năm" });
  });
  it("implements the source structure from the uploaded reference file", () => {
    expect(SOURCE_CHANNELS).toHaveLength(8);
    expect(SOURCE_CHANNELS.map(item => item.label)).toEqual([
      "Môi giới nội bộ",
      "Cộng tác viên",
      "Chủ nhà / chủ đất",
      "Nguồn thị trường",
      "Đối tác",
      "Dự án",
      "AI tìm kiếm",
      "Sale tư vấn",
    ]);
    expect(SOURCE_PROPERTY_CATEGORIES).toHaveLength(9);
    expect(SOURCE_CREATION_PHASES).toHaveLength(11);
    expect(SOURCE_CREATION_PHASES.slice(0, 5)).toEqual(["Chọn nguồn", "Loại giao dịch", "Chọn danh mục BĐS", "Chọn loại BĐS", "Mục đích sử dụng"]);
    expect(SOURCE_CHANNELS.every(item => item.workflow.includes("Vào kho"))).toBe(true);
  });
  it("creates the correct workflow context and rejects incomplete source selections", () => {
    const context = getSourceCreationContext("owner", "sale", "land", "Đất nền");
    expect(context).toMatchObject({
      sourceLabel: "Chủ nhà / chủ đất",
      propertyCategory: "Đất",
      propertySubtype: "Đất nền",
      propertyKind: "land",
    });
    expect(context?.workflow).toContain("Hợp đồng ký gửi");
    expect(getSourceCreationContext("owner", "sale", "land", "Nhà phố")).toBeNull();
    expect(getSourceCreationContext("partner", "rent", "commercial", "Mặt bằng")?.propertyKind).toBe("commercial");
    expect(getSourceCreationContext("partner", "", "commercial", "Mặt bằng")).toBeNull();
    expect(getSourceCreationContext("sale_advisor", "buy", "investment", "housing", "Nhà phố")?.usePurposeLabel).toBe("Đầu tư");
  });
  it("provides the complete shared intake form contract for every workflow step", () => {
    expect(SOURCE_COMMON_STEP_FIELDS.map(field => field.label)).toEqual(expect.arrayContaining(["Tên nguồn / tên tài sản", "Người cung cấp", "Khu vực tài sản", "Mục đích giao dịch", "Mã nguồn", "Người phụ trách", "Hạn xử lý"]));
    expect(SOURCE_COMMON_STEP_FIELDS.find(field => field.id === "assetName")?.required).toBe(true);
    expect(SOURCE_COMMON_STEP_FIELDS.find(field => field.id === "processingDeadline")?.type).toBe("date");
  });
  it("classifies each workflow step between AI analysis and human confirmation", () => {
    expect(getWorkflowStepResponsibility("Phân tích thị trường", "market")).toMatchObject({ mode: "hybrid", label: "AI phân tích · Người kiểm tra" });
    expect(getWorkflowStepResponsibility("Pháp lý", "owner").mode).toBe("hybrid");
    expect(getWorkflowStepResponsibility("Kiểm duyệt", "partner").mode).toBe("human");
    expect(getSourceWorkflowStepSchema("Khảo sát thực tế", "owner").fields.some(field => field.id === "currentArea")).toBe(true);
    expect(getWorkflowStepResponsibility("Vào kho", "owner").warehouseCondition).toContain("Đủ trường bắt buộc");
  });
  it("persists source origin, BĐS category and generated workflow with the draft", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("sourceType", "collaborator");
    formData.set("sourceLabel", "Cộng tác viên");
    formData.set("transactionPurpose", "sale");
    formData.set("transactionPurposeLabel", "Bán");
    formData.set("sourcePropertyCategory", "Nhà ở");
    formData.set("sourcePropertySubtype", "Nhà phố");
    formData.set("sourceWorkflow", "Tiếp nhận → Hồ sơ CTV → Kiểm duyệt → Vào kho");
    const details = JSON.parse(String(getPropertySubmission(formData).listingDetails));
    expect(details).toMatchObject({
      sourceType: "collaborator",
      sourceLabel: "Cộng tác viên",
      transactionPurpose: "sale",
      transactionPurposeLabel: "Bán",
      propertyCategory: "Nhà ở",
      propertySubtype: "Nhà phố",
    });
    expect(details.sourceWorkflow).toContain("Hồ sơ CTV");
  });
  it("persists the intake warehouse, AI post sync and sales warehouse stages", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("sourceType", "sale_advisor");
    formData.set("sourceLabel", "Sale tư vấn");
    formData.set("sourceCode", "SRC-2026-0008");
    formData.set("sourceWorkflow", "Tiếp nhận → Xác minh → Tạo mã → Vào kho");
    formData.set("sourceWarehouseStage", "post_draft");
    formData.set("sourcePostSyncStatus", "AI đã tạo bài đăng nháp để Sale kiểm tra");
    formData.set("sourceWorkflowStepValues", JSON.stringify({ intakeStatus: "Đã xác nhận", verificationStatus: "AI đạt" }));
    const details = JSON.parse(String(getPropertySubmission(formData).listingDetails));
    expect(details).toMatchObject({
      sourceCode: "SRC-2026-0008",
      warehouseStage: "post_draft",
      postSyncStatus: "AI đã tạo bài đăng nháp để Sale kiểm tra",
      workflowStepValues: JSON.stringify({ intakeStatus: "Đã xác nhận", verificationStatus: "AI đạt" }),
    });
    expect(details.sourceWorkflow).toContain("Tạo mã");
  });
  it("keeps standard post, legal, transaction and image fields", () => {
    const formData = new FormData();
    Object.entries(values).forEach(([key, value]) => formData.set(key, value));
    formData.set("negotiable", "on");
    let submitted: ReturnType<typeof getPropertySubmission> | undefined;
    submitPropertyForm(formData, payload => { submitted = payload; });
    const payload = submitted!;
    expect(payload).toMatchObject({ title: values.title, propertyType: "house", area: "95", certificateArea: "95", propertyCode: "BDS-TK-001", certificateType: values.certificateType, depositTerms: values.depositTerms, transactionTerms: values.transactionTerms, ownerName: values.ownerName, ownerPhone: values.ownerPhone, negotiable: true, imageUrls: ["https://example.com/front.jpg", "https://example.com/living-room.jpg", "https://example.com/bedroom.jpg", "https://example.com/kitchen.jpg", "https://example.com/outdoor.jpg", "https://example.com/road.jpg", "https://example.com/legal.jpg"] });
  });
});


describe("sold property workflow", () => {
  it("builds a valid land dossier route with the property id", () => {
    expect(getSoldDossierRoute(42)).toBe("/ai-ho-so-dat-dai?propertyId=42");
    expect(getSoldDossierRoute(42)).not.toContain("/hs-dat-dai-ai");
  });
  it("builds popup actions for the new or linked transaction", () => {
    expect(getSoldPropertyToastAction(42, 118)).toEqual({ label: "Xem giao dịch", href: "/dashboard/giao-dich?dealId=118" });
    expect(getSoldPropertyToastAction(42, null)).toEqual({ label: "Mở hồ sơ AI", href: "/ai-ho-so-dat-dai?propertyId=42" });
  });
  it("renders explicit sold toggle and archived sold section", () => {
    const html = renderToStaticMarkup(React.createElement(PropertyTable, {
      data: [
        { id: 1, title: "Nhà chưa bán", location: "Hải Châu", price: "6.5", area: "80", status: "published" },
        { id: 2, title: "Nhà đã bán", location: "Sơn Trà", price: "8.2", area: "100", status: "sold" },
      ],
      onStatus: () => undefined,
      onDelete: () => undefined,
      onScan: () => undefined,
      onEdit: () => undefined,
      onPreview: () => undefined,
    }));
    expect(html).toContain("Đã bán");
    expect(html).toContain("Chưa bán");
    expect(html).toContain("BĐS đã bán · lưu trữ");
    expect(html).toContain("1 bài");
  });
});

describe("source workflow AI logs", () => {
  it("reads structured logs by step and safely ignores invalid snapshots", () => {
    const log = { id: "legal-ai-1", timestamp: "2026-09-10T00:00:00.000Z", step: "Pháp lý", checkType: "Đối chiếu hồ sơ", inputData: "Sổ đỏ: đã tải", result: "Đã phân tích", severity: "warning", recommendation: "Reviewer đối chiếu bản gốc", reviewerStatus: "pending" } as const;
    expect(readSourceWorkflowStepAiLogs({ "legal-aiLogs": JSON.stringify([log]) }, "legal")).toEqual([log]);
    expect(readSourceWorkflowStepAiLogs({ "legal-aiLogs": "không phải json" }, "legal")).toEqual([]);
  });
  it("keeps reviewer confirmation metadata in the persisted log shape", () => {
    const log = { id: "survey-ai-1", timestamp: "2026-09-10T00:00:00.000Z", step: "Khảo sát", checkType: "Kiểm tra ảnh", inputData: "Ảnh: 6", result: "Đạt", severity: "info", recommendation: "Có thể chuyển bước", reviewerStatus: "confirmed", reviewedAt: "2026-09-10T00:05:00.000Z", reviewerNotes: "Đã đối chiếu hồ sơ gốc" };
    const parsed = readSourceWorkflowStepAiLogs({ "survey-aiLogs": JSON.stringify([log]) }, "survey")[0];
    expect(parsed.reviewerStatus).toBe("confirmed");
    expect(parsed.reviewedAt).toBe("2026-09-10T00:05:00.000Z");
    expect(parsed.reviewerNotes).toContain("đối chiếu");
  });
});

describe("source workflow step transition", () => {
  it("advances the active source workflow step and records completion audit", async () => {
    const fs = await import("node:fs/promises");
    const source = await fs.readFile(new URL("./BrokerageAdmin.tsx", import.meta.url), "utf8");
    expect(source).toContain("const advanceWorkflowStep = (schema: SourceWorkflowStepSchema, index: number)");
    expect(source).toContain("setActiveWorkflowStep(nextStep)");
    expect(source).toContain("`${schema.id}-completedAt`");
    expect(source).toContain("Đã hoàn tất · Đã chuyển bước");
  });

  it("keeps a final-step completion branch for every source workflow", async () => {
    const fs = await import("node:fs/promises");
    const source = await fs.readFile(new URL("./BrokerageAdmin.tsx", import.meta.url), "utf8");
    expect(source).toContain("source.workflow.indexOf(activeWorkflowStep) === source.workflow.length - 1");
    expect(SOURCE_CHANNELS.every(item => item.workflow.length > 1 && item.workflow.includes("Vào kho"))).toBe(true);
  });
});

describe("source workflow OCR autofill", () => {
  it("maps OCR keys and Vietnamese labels back to intake fields", () => {
    const fields = [
      { id: "ownerName", label: "Tên chủ nhà" },
      { id: "ownerPhone", label: "Số điện thoại chủ nhà" },
      { id: "currentArea", label: "Diện tích hiện trạng" },
    ];
    expect(matchOcrFieldId(fields, { key: "Tên chủ nhà", label: "" })).toBe("ownerName");
    expect(matchOcrFieldId(fields, { key: "owner_phone", label: "" })).toBe("ownerPhone");
    expect(matchOcrFieldId(fields, { key: "", label: "Diện tích hiện trạng (m²)" })).toBe("currentArea");
  });
});

describe("source workflow step forms by source", () => {
  it("generates a non-intake business form for every non-initial step of all eight sources", () => {
    const nonIntakeSteps = SOURCE_CHANNELS.flatMap(source => source.workflow.slice(1).map(step => ({ source, step })));
    expect(nonIntakeSteps).toHaveLength(SOURCE_CHANNELS.reduce((total, source) => total + source.workflow.length - 1, 0));
    for (const { source, step } of nonIntakeSteps) {
      const schema = getSourceWorkflowStepSchema(step, source.key);
      expect(schema.title).toBe(step);
      expect(schema.fields.length).toBeGreaterThanOrEqual(6);
      expect(schema.fields.some(field => field.id === "stepStatus" && field.required)).toBe(true);
      expect(schema.fields.some(field => field.id === "responsiblePerson" && field.required)).toBe(true);
      expect(schema.condition).toContain(source.shortLabel);
    }
  });

  it("exposes specialized fields for the main nghiệp vụ steps", () => {
    expect(getSourceWorkflowStepSchema("Khảo sát thực tế", "owner").fields.map(field => field.id)).toEqual(expect.arrayContaining(["currentArea", "currentImages", "surveyDate"]));
    expect(getSourceWorkflowStepSchema("Quy hoạch", "market").fields.map(field => field.id)).toEqual(expect.arrayContaining(["parcelReference", "planningResult"]));
    expect(getSourceWorkflowStepSchema("Pháp lý", "partner").fields.map(field => field.id)).toEqual(expect.arrayContaining(["legalDocument", "legalStatus"]));
    expect(getSourceWorkflowStepSchema("Định giá", "collaborator").fields.map(field => field.id)).toEqual(expect.arrayContaining(["askingPrice", "recommendedPrice", "ctvProfile"]));
    expect(getSourceWorkflowStepSchema("Hợp đồng ký gửi", "owner").fields.map(field => field.id)).toEqual(expect.arrayContaining(["agreedPrice", "agreementPeriod", "ownerMandate"]));
    expect(getSourceWorkflowStepSchema("AI phân tích", "ai").fields.map(field => field.id)).toEqual(expect.arrayContaining(["searchCriteria", "aiScore", "aiSourcePolicy"]));
  });
});


describe("source workflow OCR autofill integration", () => {
  it("passes source-specific intake fields to OCR and writes matched values into intake state", async () => {
    const fs = await import("node:fs/promises");
    const source = await fs.readFile(new URL("./BrokerageAdmin.tsx", import.meta.url), "utf8");
    expect(source).toContain("const intakeFields = (sourceType ? SOURCE_INTAKE_FIELDS[sourceType] : [])");
    expect(source).toContain("const fields = Array.from(new Map([...stepFields, ...intakeFields]");
    expect(source).toContain("setIntakeValues(current => ({ ...current, ...intakeAutofilledValues }))");
    expect(source).toContain("OCR đã đọc được nội dung nhưng chưa khớp trường form");
  });
});


describe("Source workflow OCR and file package", () => {
  it("reads every uploaded file from the active workflow step", () => {
    const files = [
      { id: "step-1-a", name: "so-do.pdf", size: 2048, mimeType: "application/pdf", status: "ocr_complete", uploadedAt: "2026-09-17T01:00:00.000Z", url: "https://storage.test/so-do.pdf" },
      { id: "step-1-b", name: "mat-tien.jpg", size: 10240, mimeType: "image/jpeg", status: "stored", uploadedAt: "2026-09-17T01:01:00.000Z" },
    ];
    expect(readSourceWorkflowFiles({ "step-1-fileEntries": JSON.stringify(files) }, "step-1")).toEqual(files);
  });

  it("keeps compatibility with the legacy single-file snapshot", () => {
    expect(readSourceWorkflowFiles({ "step-1-files": "legacy.pdf" }, "step-1")).toMatchObject([{ name: "legacy.pdf", status: "stored", mimeType: "" }]);
  });

  it("reads structured OCR preview records by step", () => {
    const preview = [{ id: "ocr-1", label: "Diện tích", value: "95 m²", fieldId: "currentArea", confidence: 0.94, evidence: "Trang 1" }];
    expect(readSourceWorkflowOcrPreview({ "survey-ocrPreview": JSON.stringify(preview) }, "survey")).toEqual(preview);
    expect(readSourceWorkflowOcrPreview({ "survey-ocrPreview": "invalid" }, "survey")).toEqual([]);
  });

  it("formats uploaded file sizes for the file list", () => {
    expect(formatSourceWorkflowFileSize(0)).toContain("chưa lưu");
    expect(formatSourceWorkflowFileSize(1024)).toBe("1 KB");
    expect(formatSourceWorkflowFileSize(1024 * 1024)).toBe("1.0 MB");
  });
});


describe("Source intake OCR binding", () => {
  it("maps OCR results to both workflow and source-specific intake state", () => {
    const stepFields = [{ id: "assetAddress", label: "Địa chỉ chi tiết" }];
    const intakeFields = SOURCE_INTAKE_FIELDS.owner.map(({ id, label }) => ({ id, label }));
    const mapped = mapSourceWorkflowOcrFields(stepFields, intakeFields, [
      { key: "ownerName", label: "Tên chủ nhà / chủ đất", value: "Nguyễn Văn A", confidence: 0.93, evidence: "Dòng 1" },
      { key: "assetAddress", label: "Địa chỉ chi tiết", value: "12 Trần Phú, Đà Nẵng", confidence: 0.88, evidence: "Dòng 2" },
    ]);
    expect(mapped.workflowValues).toEqual({ assetAddress: "12 Trần Phú, Đà Nẵng" });
    expect(mapped.intakeValues).toEqual({ ownerName: "Nguyễn Văn A" });
    expect(mapped.filledFieldIds).toEqual(["assetAddress", "ownerName"]);
    expect(mapped.preview.find(item => item.fieldId === "ownerName")?.value).toBe("Nguyễn Văn A");
  });

  it("renders an OCR value from workflow snapshot in the visible source intake form", () => {
    const html = renderToStaticMarkup(React.createElement(SourceSpecificIntake, {
      sourceType: "owner",
      values: {},
      workflowValues: { ownerName: "Nguyễn Văn A" },
      onChange: () => undefined,
    }));
    expect(html).toContain('value="Nguyễn Văn A"');
    expect(getSourceIntakeFieldValue({}, { ownerName: "Nguyễn Văn A" }, "ownerName")).toBe("Nguyễn Văn A");
  });
});
