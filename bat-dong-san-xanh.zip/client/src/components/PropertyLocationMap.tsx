import React, { useRef, useState } from "react";
import { MapPin, Search } from "lucide-react";
import { toast } from "sonner";
import { MapView } from "@/components/Map";
import { trpc } from "@/lib/trpc";

export function PropertyLocationMap() {
  const mapRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);
  const [address, setAddress] = useState("");
  const [selected, setSelected] = useState<{ label: string; latitude: string; longitude: string } | null>(null);
  const geocodeProcedure = (trpc.properties as typeof trpc.properties & { geocode?: { useQuery?: typeof trpc.properties.list.useQuery } }).geocode;
  const geocode = geocodeProcedure?.useQuery
    ? geocodeProcedure.useQuery({ address }, { enabled: false })
    : { isFetching: false, refetch: async () => ({ data: [] as Array<{ label: string; latitude: string; longitude: string }> }) };

  const searchAddress = async () => {
    if (address.trim().length < 3) {
      toast.error("Vui lòng nhập địa chỉ từ 3 ký tự trở lên.");
      return;
    }
    const result = await geocode.refetch();
    const first = result.data?.[0];
    if (!first) {
      toast.error("Không tìm thấy vị trí. Hãy nhập địa chỉ đầy đủ hơn.");
      return;
    }
    setSelected(first);
    const position = { lat: Number(first.latitude), lng: Number(first.longitude) };
    mapRef.current?.setCenter(position);
    mapRef.current?.setZoom(16);
    markerRef.current?.setMap(null);
    if (mapRef.current) markerRef.current = new google.maps.Marker({ map: mapRef.current, position, title: first.label });
  };

  return <section className="rounded-[2rem] border border-[#14284A]/10 bg-white p-5 shadow-sm sm:p-7">
    <div className="mb-5 flex items-start gap-3"><div className="rounded-2xl bg-[#EAF2ED] p-3 text-[#1F5A4A]"><MapPin size={22} /></div><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#B98A2E]">Tìm vị trí sản phẩm</p><h2 className="mt-1 font-serif text-3xl text-[#14284A]">Bản đồ BĐS Đà Nẵng</h2><p className="mt-1 text-sm text-[#60766D]">Nhập địa chỉ để tìm vị trí, sau đó dùng tọa độ cho hồ sơ và bài đăng.</p></div></div>
    <div className="mb-4 flex flex-col gap-2 sm:flex-row"><input value={address} onChange={event => setAddress(event.target.value)} onKeyDown={event => { if (event.key === "Enter") void searchAddress(); }} placeholder="Ví dụ: 12 Nguyễn Văn Linh, Hải Châu, Đà Nẵng" className="min-h-12 flex-1 rounded-xl border border-[#14284A]/15 px-4 text-sm outline-none focus:border-[#B98A2E]" aria-label="Nhập địa chỉ sản phẩm" /><button type="button" onClick={() => void searchAddress()} disabled={geocode.isFetching} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#C49736] px-5 font-bold text-white hover:bg-[#A87A24] disabled:opacity-60"><Search size={17} />{geocode.isFetching ? "Đang tìm…" : "Tìm vị trí"}</button></div>
    {selected && <div className="mb-4 rounded-xl bg-[#F4F8F5] p-3 text-sm text-[#1F5A4A]"><strong>Đã tìm thấy:</strong> {selected.label}<span className="mt-1 block text-xs text-[#60766D]">Tọa độ: {Number(selected.latitude).toFixed(7)}, {Number(selected.longitude).toFixed(7)}</span></div>}
    <MapView className="h-[380px] overflow-hidden rounded-2xl" initialCenter={{ lat: 16.0544, lng: 108.2022 }} initialZoom={12} onMapReady={map => { mapRef.current = map; }} />
    <p className="mt-3 text-xs leading-5 text-[#60766D]">Vị trí trên bản đồ là dữ liệu hỗ trợ. Khi đăng công khai, nên dùng vị trí gần đúng để bảo vệ thông tin riêng tư của chủ nhà.</p>
  </section>;
}

export default PropertyLocationMap;
