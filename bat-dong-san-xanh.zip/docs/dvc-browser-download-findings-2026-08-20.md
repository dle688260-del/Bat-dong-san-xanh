# DVC browser download findings — 2026-08-20

Trang `https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789` đã được extraction thành công và trả về thủ tục “Cung cấp thông tin, dữ liệu đất đai”, liên kết chi tiết `ma_thu_tuc=348167`, cùng phần “Trình tự thực hiện”.

Khi mở lại trang bằng browser sandbox, trang bị extension chặn với `ERR_BLOCKED_BY_CLIENT`; endpoint tải trực tiếp trước đó cũng không thể dùng như bằng chứng browser session của người dùng. Vì vậy chưa thể lấy cookie/redirect từ phiên trình duyệt của người dùng. Kết quả này giải thích vì sao server fetch có thể gặp 503 dù người dùng tải được bằng trình duyệt của họ: hai môi trường không chia sẻ phiên và có thể khác cơ chế chống tải tự động.

Không được chuyển trạng thái Official chỉ dựa trên tên file hoặc URL metadata. Cần nhận byte DOCX/PDF thật, checksum, fillability và provenance DVC.
