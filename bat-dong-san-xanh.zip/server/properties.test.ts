import { describe, expect, it, vi } from "vitest";

vi.mock("./db", () => ({
  createBuyerLead: vi.fn(), createConsultationRequest: vi.fn(), createOwner: vi.fn(), createProperty: vi.fn(),
  getPublishedPropertyWithImages: vi.fn(async (slug: string) => slug === "nha-son-tra" ? { property: { id: 1, slug, title: "Nhà Sơn Trà", propertyType: "house", price: "4.50", area: "120.00", location: "Sơn Trà, Đà Nẵng", orientation: "Đông Nam", legalStatus: "Sổ riêng", description: "Thông tin nguồn hàng" }, images: [{ id: 1, propertyId: 1, url: "https://example.com/house.jpg", altText: "Nhà Sơn Trà", sortOrder: 0 }] } : undefined),
  PUBLIC_PROPERTY_STATUS: "published", isPublicPropertyStatus: (status: string) => status === "published", listBuyerLeads: vi.fn(async () => []), listConsultationRequests: vi.fn(async () => []), listDeals: vi.fn(async () => []), listLegalChecks: vi.fn(async () => []), listOwners: vi.fn(async () => []), listProperties: vi.fn(async () => []), listPublishedProperties: vi.fn(async (filters: unknown) => [{ id: 9, title: "Nhà Sơn Trà", filters }]), listSurveys: vi.fn(async () => []), listValuations: vi.fn(async () => []), updateConsultationStatus: vi.fn(), updatePropertyStatus: vi.fn(),
}));

import { appRouter } from "./routers";
import { isPublicPropertyStatus, listPublishedProperties } from "./db";
import type { TrpcContext } from "./_core/context";

const context = { user: null, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] } satisfies TrpcContext;
const adminContext = { user: { id: 7, openId: "admin", name: "Admin", role: "admin" }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] } satisfies TrpcContext;

describe("properties contract", () => {
  it("exposes only published listings to the public catalog", () => {
    expect(isPublicPropertyStatus("draft")).toBe(false);
    expect(isPublicPropertyStatus("published")).toBe(true);
    expect(isPublicPropertyStatus("sold")).toBe(false);
  });
  it("rejects an empty detail slug", async () => {
    await expect(appRouter.createCaller(context).properties.detail({ slug: "" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("returns a published property with its image references", async () => {
    const result = await appRouter.createCaller(context).properties.detail({ slug: "nha-son-tra" });
    expect(result?.property.title).toBe("Nhà Sơn Trà");
    expect(result?.images[0]?.url).toContain("house.jpg");
  });

  it("returns no result for an unpublished or unknown slug", async () => {
    await expect(appRouter.createCaller(context).properties.detail({ slug: "khong-ton-tai" })).resolves.toBeUndefined();
  });

  it("passes advanced search criteria to the published property query", async () => {
    const result = await appRouter.createCaller(context).properties.list({
      q: "SH-001",
      propertyType: "house",
      areaId: 3,
      province: "Đà Nẵng",
      minPrice: 4,
      maxPrice: 9,
      minArea: 80,
      maxArea: 150,
      minBedrooms: 2,
      maxBedrooms: 4,
      orientation: "Đông Nam",
      legalStatus: "Sổ",
      sort: "price_asc",
    });
    expect(result[0]?.id).toBe(9);
    expect(vi.mocked(listPublishedProperties)).toHaveBeenCalledWith(expect.objectContaining({ q: "SH-001", minBedrooms: 2, legalStatus: "Sổ", sort: "price_asc" }));
  });

  it("rejects invalid advanced filter values", async () => {
    await expect(appRouter.createCaller(context).properties.list({ minBedrooms: -1 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(appRouter.createCaller(context).properties.list({ sort: "random" as never })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects invalid new property fields before calling the database", async () => {
    const input = { title: "Nhà mẫu", slug: "nha-mau", propertyType: "house" as const, price: "sai", area: "120", location: "Sơn Trà" };
    await expect(appRouter.createCaller(adminContext).properties.create(input)).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(appRouter.createCaller(adminContext).properties.create({ ...input, price: "4.5", imageUrls: ["not-a-url"] })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(appRouter.createCaller(adminContext).properties.create({ ...input, price: "4.5", constructionYear: 1700 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(vi.mocked((await import("./db")).createProperty)).not.toHaveBeenCalled();
  });
});
