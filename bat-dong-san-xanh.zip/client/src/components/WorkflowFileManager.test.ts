import { describe, expect, it } from "vitest";
import { MAX_WORKFLOW_FILE_SIZE, WORKFLOW_FILE_ACCEPT, WORKFLOW_OCR_ACCEPT, isWorkflowMedia, isWorkflowVideo } from "./WorkflowFileManager";

describe("WorkflowFileManager file rules", () => {
  it("accepts image and video MIME types as previewable workflow media", () => {
    expect(isWorkflowMedia("image/jpeg")).toBe(true);
    expect(isWorkflowMedia("video/mp4")).toBe(true);
    expect(isWorkflowMedia("application/pdf")).toBe(false);
  });

  it("distinguishes videos and keeps the 10MB upload limit", () => {
    expect(isWorkflowVideo("video/webm")).toBe(true);
    expect(isWorkflowVideo("image/png")).toBe(false);
    expect(MAX_WORKFLOW_FILE_SIZE).toBe(10 * 1024 * 1024);
    expect(WORKFLOW_FILE_ACCEPT).toContain("image/*");
    expect(WORKFLOW_FILE_ACCEPT).toContain("video/*");
    expect(WORKFLOW_OCR_ACCEPT).toContain("image/jpeg");
    expect(WORKFLOW_OCR_ACCEPT).toContain("image/png");
    expect(WORKFLOW_OCR_ACCEPT).toContain("image/webp");
  });
});
