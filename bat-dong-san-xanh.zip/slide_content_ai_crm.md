# AI trong CRM & Hồ sơ điện tử

## Cover
AI trong CRM & Hồ sơ điện tử
Từ dữ liệu BĐS đến quyết định môi giới có kiểm soát
Bất động sản xanh · Đà Nẵng & miền Trung

## Slide 1
### AI nằm ở đâu trong hệ thống?
- **CRM** quản lý nguồn hàng, chủ nhà, khách mua, lịch hẹn và giao dịch.
- **Hồ sơ điện tử** là nơi tập trung dữ liệu, tài liệu và tiến độ của từng BĐS.
- **AI** hỗ trợ đọc, tìm, tóm tắt và phát hiện thiếu sót — không thay thế xác minh pháp lý.

## Slide 2
### Một hồ sơ BĐS, một nguồn dữ liệu thống nhất
- Mỗi BĐS có một mã hồ sơ duy nhất.
- Dữ liệu từ 12 bước được tổng hợp vào Hồ sơ điện tử.
- Tài liệu, ảnh, ghi chú và trạng thái được gắn đúng BĐS và đúng bước.
- Nhân viên nhìn thấy cùng một phiên bản thông tin khi xử lý, đăng bán hoặc giao dịch.

## Slide 3
### 12 bước tạo thành xương sống CRM
- **Tiếp nhận → Khảo sát → Quy hoạch → Pháp lý → Định giá**
- **Ký gửi → Đăng bán → Khách mua → Xem BĐS**
- **Đàm phán → Công chứng/Sang tên → Hoàn tất**
- Mỗi bước có trường dữ liệu, trạng thái, tài liệu và người phụ trách.

## Slide 4
### Dữ liệu thay đổi theo loại BĐS
- Chọn **Đất nền**: mặt tiền, chiều sâu, lộ giới, mục đích sử dụng, quy hoạch.
- Chọn **Căn hộ**: diện tích thông thủy, tầng, phòng ngủ, phí quản lý, thời hạn sở hữu.
- Chọn **Nhà phố/Villa/Resort**: hiện trạng xây dựng, công năng, giấy phép, nội thất.
- Chọn **Đất nông nghiệp/Khu công nghiệp/Cho thuê**: trường chuyên biệt theo mục đích và điều kiện sử dụng.

## Slide 5
### Camera + OCR biến giấy tờ thành dữ liệu
- Chọn BĐS và nhóm tài liệu: **Pháp lý, Quy hoạch, Khảo sát, Định giá hoặc Giao dịch**.
- Chụp sổ đỏ, sổ hồng hoặc tải PDF/ảnh lên Hồ sơ AI.
- AI trích xuất thông tin có thể đọc được: người đứng tên, diện tích, số thửa, mục đích sử dụng.
- Nhân viên đối chiếu bản gốc trước khi xác nhận và đưa vào hồ sơ chính thức.

## Slide 6
### AI tra cứu giúp tìm thông tin nhanh hơn
- Hỏi: “Hồ sơ này còn thiếu giấy tờ nào?”
- Hỏi: “Đối chiếu diện tích trong giấy chứng nhận với dữ liệu đã nhập.”
- Hỏi: “Tóm tắt ưu điểm, hạn chế và việc cần làm tiếp theo.”
- Yêu cầu AI tách rõ: **đã xác minh · đang xử lý · chưa có dữ liệu**.

## Slide 7
### Hồ sơ điện tử là màn hình điều hành
- **Tổng quan:** thông tin BĐS, chủ nhà, giá, vị trí và trạng thái.
- **Tiến độ:** 12 bước, người phụ trách, việc đang chờ.
- **Tài liệu:** file pháp lý, ảnh khảo sát, phiếu định giá và hợp đồng.
- **Khách hàng & lịch sử:** nhu cầu, lịch xem, ghi chú và cập nhật gần nhất.

## Slide 8
### AI hỗ trợ môi giới chăm sóc khách hàng
- Phân loại khách theo loại BĐS, khu vực, ngân sách và mục đích mua.
- Ghép nhu cầu khách với nguồn hàng phù hợp trong CRM.
- Soạn nháp Zalo/SMS, lịch nhắc gọi lại và tin nhắn xác nhận lịch xem.
- Nhân viên kiểm tra và duyệt trước khi gửi; tôn trọng yêu cầu dừng nhận tin.

## Slide 9
### Quy trình vận hành hằng ngày
- **Bước 1:** tạo hồ sơ BĐS và chọn đúng loại tài sản.
- **Bước 2:** nhập dữ liệu 12 bước, tải tài liệu và cập nhật trạng thái.
- **Bước 3:** dùng OCR/AI để đọc, tìm và tóm tắt; kiểm tra lại với bản gốc.
- **Bước 4:** xem Tổng hợp tự động, hoàn thiện bài đăng và cập nhật CRM sau mỗi lần liên hệ.

## Slide 10
### Kiểm soát AI để bảo vệ chất lượng hồ sơ
- Không đưa dữ liệu chưa xác minh vào nội dung cam kết với khách hàng.
- Không xem kết quả OCR là kết luận pháp lý.
- Giới hạn quyền xem Hồ sơ AI theo vai trò nhân viên.
- Lưu lịch sử thay đổi, người duyệt và thời điểm xác nhận.
- AI đề xuất; **nhân viên chịu trách nhiệm kiểm tra và quyết định**.

## Slide 11
### Bắt đầu nhỏ, kiểm soát chặt
Chọn một BĐS và hoàn thiện đủ 12 bước, tài liệu cùng kết quả AI trước khi mở rộng.

Đo lường ba điều: **dữ liệu có đủ không · tài liệu có đúng không · bước tiếp theo là gì**.

Khi vận hành ổn định, hệ thống giúp giảm thời gian tìm hồ sơ, phát hiện dữ liệu thiếu, giảm nhập liệu lặp lại và giữ nhất quán từ tiếp nhận nguồn hàng đến hoàn tất giao dịch.

Bất động sản xanh · Quản lý minh bạch · Đồng hành có kiểm soát
