import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { getOfficialLandProcedure } from "./officialLandProcedureRegistry";

describe("legal official materialization contract", () => {
  it("maps DVC alias 2912 to canonical registry code 2.000889", () => {
    const procedure = getOfficialLandProcedure("2912");
    expect(procedure?.code).toBe("2.000889");
    expect(procedure?.externalCodes).toContain("2912");
    expect(procedure?.verifiedTemplates?.some(item => item.checksum === "c589d04cf6b0e6f6f82574d4e806194291077459c2a7d86d0b2f79e0e2057dc2")).toBe(true);
  });

  it("keeps materialization strict and connected to both interactive and scheduled sync", () => {
    const routers = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    const scheduled = readFileSync(new URL("./scheduledLegalSync.ts", import.meta.url), "utf8");
    expect(routers).toContain("materializeRegistryOfficialTemplates");
    expect(routers).toContain("downloaded.checksum !== official.checksum");
    expect(routers).toContain("legal-official/${registry.code}");
    expect(scheduled).toContain("ensureLegalProcedureFromRegistry(procedure.code)");
    expect(scheduled).toContain("downloaded.checksum !== official.checksum");
  });
});
