# Ghi nhận nguồn catalog thủ tục đất đai

Ngày rà soát: 2026-08-21.

Nguồn chính thức của Bộ Nông nghiệp và Môi trường có trang Sổ tay điện tử hướng dẫn trình tự, thủ tục hành chính lĩnh vực đất đai: https://mae.gov.vn/so-tay-dien-tu-huong-dan-ve-trinh-tu-thu-tuc-hanh-chinh-linh-vuc-dat-dai-thuoc-pham-vi-chuc-nang-quan-ly-nha-nuoc-cua-bo-nong-nghiep-va-moi-truong-19066.htm.

Cổng Dịch vụ công Quốc gia có các trang chi tiết theo mã. Trang đã kiểm tra: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013949. Trang hiển thị một thủ tục giao đất/cho thuê đất/chuyển mục đích sử dụng đất, quy trình nhiều bước, cơ quan cấp xã, Văn phòng đăng ký đất đai/Chi nhánh và các mẫu theo Nghị định 151/2025/NĐ-CP (Mẫu 25, 06, 09, 19). Đây là bằng chứng rằng một mã thủ tục có thể bao gồm quy trình, cơ quan, điều kiện và nhiều thành phần/file; catalog cần lưu các trường này theo từng mã thay vì chỉ lưu tên thủ tục.

Kết luận triển khai: số 11 hiện là số mã đã nạp trong registry, không phải tổng số thủ tục đất đai. Có thể mở rộng bằng cách nhập danh mục mã từ nguồn chính thức; không được tự tạo mã hoặc coi các kết quả tìm kiếm không có mã là thủ tục hợp lệ. Sau khi nhập, workflow dùng chung có thể chạy từng mã và mapping từng thành phần.


Bổ sung từ trang Cục Quản lý đất đai: bài viết ngày 24/07/2025 cho biết Sổ tay đã bổ sung sơ đồ cho **48 thủ tục hành chính về đất đai** và 10 thủ tục nội bộ; trang cung cấp các thư mục Google Drive chính thức cho TTHC cấp Trung ương, cấp tỉnh, cấp xã và nội bộ. Các liên kết cần dùng làm nguồn nhập catalog là:

- Trung ương: https://drive.google.com/drive/folders/1oxvmBtTmJ3jEtDMkzN-4FL_5DKXjX1u0c?usp=sharing
- Cấp tỉnh: https://drive.google.com/drive/folders/1OWX_co3__UjeNlT6JIykZpZrrBhS05Or?usp=sharing
- Cấp xã: https://drive.google.com/drive/folders/1oBu3P8lxOTDK92FUho4jD2BZxUY7k3tL?usp=sharing
- Nội bộ: https://drive.google.com/drive/folders/13qbgnsfzOOZxm9Dc50gXWVrCbpw6MG_L?usp=sharing
- Sổ tay PDF: https://qldd.mae.gov.vn/noidung/Lists/ListTinTuc/Attachments/3318/So%20tay%20huong%20dan%20cong%20tac%20quan%20ly%20Nha%20nuoc%20trong%20linh%20vuc%20dat%20dai%20%28V3%29.pdf

Đây là căn cứ chính thức để mở catalog vượt 11 mã. Cần phân biệt 48 TTHC dành cho người dân/doanh nghiệp với 10 thủ tục nội bộ; không trộn hai nhóm nếu người dùng đang làm hồ sơ dân sự/doanh nghiệp.
