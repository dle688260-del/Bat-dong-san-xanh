# Hướng dẫn vận hành AI Kho pháp lý

## Mục đích

`/ai-kho-phap-ly` là màn hình quản trị để xây dựng cơ sở dữ liệu tri thức cho AI Hồ sơ đất đai. Hệ thống tiếp nhận nội dung đã lấy từ nguồn được phép truy cập, dùng LLM trích xuất có cấu trúc thành văn bản, thủ tục, thành phần hồ sơ và biểu mẫu, sau đó lưu vào MySQL.

## Quy trình nạp nguồn

Quản trị viên mở **AI Kho pháp lý**, chọn tab **AI đọc văn bản**, nhập tên nguồn, loại nguồn, URL nguồn, URL văn bản/thủ tục, tiêu đề, số hiệu, địa phương và dán nội dung văn bản. Nội dung nên được đối chiếu với bản gốc trước khi gửi. Hệ thống yêu cầu tối thiểu 200 ký tự và gọi API `legalKnowledge.ingestText` bằng structured JSON.

Kết quả được lưu thành `legal_sources`, `legal_documents`, `legal_procedures`, `legal_procedure_requirements` và `legal_templates`. Các thủ tục mới được đặt ở trạng thái `needs_review`; biểu mẫu mới luôn đặt `provenance = metadata_only`. Hệ thống không tự nâng thành `verified_binary` hoặc `official` chỉ dựa trên câu trả lời của AI.

## Quy trình rà soát

Quản trị viên kiểm tra tên thủ tục, mã thủ tục, nhóm thủ tục, cơ quan, thời hạn, điều kiện, thành phần hồ sơ và URL nguồn trong các tab **CSDL thủ tục** và **Kho biểu mẫu**. Nếu nguồn có thay đổi hoặc không còn hiệu lực, cần cập nhật trạng thái văn bản/thủ tục và không dùng bản đó để tạo hồ sơ mới cho đến khi đối chiếu.

AI Hồ sơ đất đai chỉ nên dùng các bản ghi đã được người quản trị kiểm tra. Người dùng cuối vẫn phải xem lại dữ liệu OCR, xác nhận hai lớp và đối chiếu với cơ quan tiếp nhận địa phương trước khi in, ký hoặc nộp.

## Quy tắc an toàn pháp lý

> Dữ liệu do AI trích xuất là dữ liệu hỗ trợ và không phải xác nhận của cơ quan nhà nước. Nhãn `Official` chỉ được dùng khi tệp binary chính thức đã được kiểm tra provenance, checksum, magic bytes, URL HTTPS và phiên bản hiệu lực.

Không nhập dữ liệu cá nhân không cần thiết vào văn bản nguồn. Không coi cảnh báo “Cần rà soát” là kết luận hồ sơ hợp lệ hoặc không hợp lệ. Thời hạn, phí, cơ quan tiếp nhận và yêu cầu địa phương phải được xác minh lại tại Cổng Dịch vụ công hoặc cơ quan có thẩm quyền trước khi nộp.

## Các API chính

| API | Mục đích | Quyền |
|---|---|---|
| `legalKnowledge.sources` | Liệt kê nguồn pháp lý | Admin |
| `legalKnowledge.procedures` | Tìm thủ tục theo tên, mã hoặc alias | Người dùng đã đăng nhập |
| `legalKnowledge.templates` | Liệt kê biểu mẫu và provenance | Admin |
| `legalKnowledge.bundle` | Lấy thủ tục, requirements, templates và documents | Người dùng đã đăng nhập |
| `legalKnowledge.ingestText` | AI phân tích và lưu nguồn mới | Admin |

## Phạm vi hiện tại và bước tiếp theo

CSDL nền tảng, ingest có cấu trúc, provenance và giao diện quản trị đã được triển khai. Bảng `legal_sync_runs` đã sẵn sàng cho lịch sử đồng bộ; bước mở rộng tiếp theo là kết nối job đồng bộ có kiểm soát, deduplicate theo checksum và giao diện lịch sử thay đổi trước khi bật tự động hóa nguồn bên ngoài.
