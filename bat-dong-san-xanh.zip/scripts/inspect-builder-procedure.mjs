import fs from "node:fs";
const s=fs.readFileSync("client/src/pages/LandDossierBuilder.tsx","utf8");
for (const needle of ["const procedureSync", "const localSource", "const selected =", "autoDiscoverDvcBinaryCandidates.mutate", "setProvince(event.target.value)"]) {
 const i=s.indexOf(needle); console.log(`\n=== ${needle} @ ${i} ===`); if(i>=0) console.log(s.slice(Math.max(0,i-700),i+2600));
}
