# Xác minh Heartbeat đồng bộ pháp lý — 2026-08-23

- Job: `land-dossier-official-sync-6h`
- Task UID: `EcZLeMSzGSq9Ktpx7R6hXa`
- Callback: `/api/scheduled/sync-legal-sources`
- Lịch: `0 0 2 * * *` UTC, đang bật.
- Lần chạy gần nhất được liệt kê: `2026-08-23T02:04:22Z`; lần tiếp theo: `2026-08-24T02:00:00Z`.
- Lịch sử có các lần trả HTTP 200 với trạng thái `success` và có ít nhất một lần lỗi HTTP 403 do `permission error for cron cookie`.
- Một lần chạy thành công trong log trả `procedureCount: 11`, `discoveredCount: 241`, `officialFiles: 2`, `referenceFiles: 0`, `pendingFiles: 21`; trong kết quả mẫu, mã `2.000889` có 4 tệp pending và không có official file.
- Kết luận: Heartbeat đã tồn tại và có chạy thành công, nhưng chưa đủ bằng chứng để đánh dấu hoàn tất độ phủ toàn bộ catalog hiện hành hoặc gắn Official cho toàn bộ mã. Cần đối soát thêm với catalog hiện hành và xử lý/giám sát lỗi quyền 403.

## Cập nhật log mới nhất

Phần đầu lịch sử chạy gần nhất cho thấy callback production vẫn chưa ổn định: lúc `2026-08-23T02:04:21Z` trả HTTP `503`; trước đó có các lần `404` và `500` trong khoảng `01:15–01:39Z`. Vì vậy job đang bật nhưng chưa thể coi là đồng bộ production hoàn chỉnh. Cần kiểm tra route callback đã được deploy đúng phiên bản và xác thực cron trước khi chạy lại toàn catalog.
