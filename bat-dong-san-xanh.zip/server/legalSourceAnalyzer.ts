import { TRPCError } from "@trpc/server";

export type DiscoveredLegalAttachment = {
  url: string;
  fileName: string;
  format: "pdf" | "docx";
  label: string;
};

export type LegalSourceUrlAnalysis = {
  requestedUrl: string;
  canonicalUrl: string;
  baseUrl: string;
  sourceName: string;
  sourceType: "government" | "public_service" | "local_authority" | "official_gazette" | "other";
  title: string;
  documentNumber: string;
  province: string;
  receivingAuthority: string;
  issuingBody: string;
  versionLabel: string;
  effectiveStatus: "unknown" | "in_force_candidate" | "expired_candidate" | "amended_candidate";
  versionStatus: "unknown" | "current_candidate" | "amended_candidate" | "superseded_candidate";
  relatedDocumentMentions: string[];
  checkedAt: string;
  extractedText: string;
  attachments: DiscoveredLegalAttachment[];
  warnings: string[];
};

const decodeHtml = (value: string) => value
  .replace(/&nbsp;/gi, " ")
  .replace(/&amp;/gi, "&")
  .replace(/&quot;/gi, '"')
  .replace(/&#39;|&apos;/gi, "'")
  .replace(/&lt;/gi, "<")
  .replace(/&gt;/gi, ">");

const cleanText = (html: string) => decodeHtml(html
  .replace(/<script[\s\S]*?<\/script>/gi, " ")
  .replace(/<style[\s\S]*?<\/style>/gi, " ")
  .replace(/<!--[\s\S]*?-->/g, " ")
  .replace(/<br\s*\/?>(?=.)/gi, "\n")
  .replace(/<\/p>|<\/div>|<\/li>|<\/h[1-6]>/gi, "\n")
  .replace(/<[^>]+>/g, " ")
  .replace(/\s+/g, " ")
  .trim());

const getAttr = (tag: string, name: string) => {
  const match = tag.match(new RegExp(`${name}\\s*=\\s*["']([^"']+)["']`, "i"));
  return match?.[1]?.trim() || "";
};

const normalizeUrl = (value: string, base: string) => {
  try { return new URL(value, base).toString(); } catch { return ""; }
};

const sourceTypeFor = (url: URL): LegalSourceUrlAnalysis["sourceType"] => {
  const host = url.hostname.toLowerCase();
  if (host === "dichvucong.gov.vn" || host.endsWith(".dichvucong.gov.vn")) return "public_service";
  if (host.endsWith(".gov.vn") && /(congbao|vanban|chinhphu)/i.test(host)) return "official_gazette";
  if (host.endsWith(".gov.vn")) return "government";
  return "other";
};

const inferAuthority = (url: URL, text: string) => {
  const authority = text.match(/(?:cơ quan|đơn vị|nơi tiếp nhận|cơ quan thực hiện)\s*[:：-]\s*([^.;]{3,160})/i)?.[1]?.trim();
  if (authority) return authority;
  if (url.hostname.includes("dichvucong")) return "Cơ quan tiếp nhận theo thủ tục và địa phương được chọn";
  return "";
};

export type LegalDocumentSearchResult = {
  query: string;
  title: string;
  documentNumber: string;
  url: string;
  sourceName: string;
  sourceType: LegalSourceUrlAnalysis["sourceType"];
  checkedAt: string;
  isOfficialDomain: boolean;
  warning?: string;
  effectiveStatus: LegalSourceUrlAnalysis["effectiveStatus"];
  versionStatus: LegalSourceUrlAnalysis["versionStatus"];
};

const officialLegalSearchSeeds = [
  { title: "Cổng Thông tin điện tử Chính phủ — Văn bản", url: "https://vanban.chinhphu.vn", sourceType: "government" as const },
  { title: "Cơ sở dữ liệu quốc gia về văn bản pháp luật", url: "https://vbpl.vn", sourceType: "government" as const },
  { title: "Cổng Dịch vụ công Quốc gia", url: "https://dichvucong.gov.vn", sourceType: "public_service" as const },
];

const isOfficialLegalHost = (hostname: string) => /(^|\.)gov\.vn$/i.test(hostname) || /(^|\.)vbpl\.vn$/i.test(hostname) || /(^|\.)chinhphu\.vn$/i.test(hostname);

const decodeSearchText = (value: string) => decodeHtml(value.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();

const normalizeLegalQuery = (value: string) => value
  .normalize("NFC")
  .replace(/[–—−]/g, "-")
  .replace(/\bNĐ\s*[-/]?\s*C\s*[IP]\b/gi, "NĐ-CP")
  .replace(/\bND\s*[-/]?\s*C\s*[IP]\b/gi, "NĐ-CP")
  .replace(/(\d{1,3})\s*[/\\-]\s*(\d{4})\s*[/\\-]\s*(NĐ-CP|ND-CP)/gi, "$1/$2/NĐ-CP")
  .replace(/\s+/g, " ")
  .trim();

const verifiedLegalMatches = [
  { pattern: /(?:nghị\s*định\s*)?101\s*[/\- ]\s*2024\s*[/\- ]\s*(?:NĐ|ND)\s*[-/]?\s*C\s*[IP]/i, title: "Nghị định số 101/2024/NĐ-CP quy định về đăng ký đất đai, cấp Giấy chứng nhận và hệ thống thông tin đất đai", documentNumber: "101/2024/NĐ-CP", url: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791", sourceName: "vanban.chinhphu.vn" },
];

export async function searchLegalDocuments(query: string): Promise<LegalDocumentSearchResult[]> {
  const normalizedQuery = normalizeLegalQuery(query);
  if (normalizedQuery.length < 2) throw new TRPCError({ code: "BAD_REQUEST", message: "Hãy nhập tên hoặc số hiệu văn bản, ví dụ Nghị định 102 hoặc 102/2024/NĐ-CP." });
  const verifiedMatch = verifiedLegalMatches.find(item => item.pattern.test(normalizedQuery));
  if (verifiedMatch) {
    return [{ query: normalizedQuery, title: verifiedMatch.title, documentNumber: verifiedMatch.documentNumber, url: verifiedMatch.url, sourceName: verifiedMatch.sourceName, sourceType: "government", checkedAt: new Date().toISOString(), isOfficialDomain: true, effectiveStatus: "in_force_candidate", versionStatus: "current_candidate", warning: query.trim() !== normalizedQuery ? `Đã chuẩn hóa truy vấn “${query.trim()}” thành “${normalizedQuery}”. Hãy mở nguồn chính thức để đối chiếu bản gốc và hiệu lực tại thời điểm nộp hồ sơ.` : "Đã đối chiếu số hiệu với Cổng Thông tin điện tử Chính phủ; vẫn cần kiểm tra hiệu lực và văn bản sửa đổi trước khi áp dụng." }];
  }
  const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(`site:gov.vn OR site:vbpl.vn ${normalizedQuery}`)}&num=10`;
  let html = "";
  try {
    const response = await fetch(searchUrl, {
      headers: {
        Accept: "text/html",
        "User-Agent": "Mozilla/5.0 (compatible; BDSXanh-LegalSearch/1.0)",
      },
    });
    if (response.ok) html = await response.text();
  } catch {
    html = "";
  }
  const results: LegalDocumentSearchResult[] = [];
  const resultMatches = Array.from(html.matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi));
  for (const match of resultMatches) {
    try {
      const href = match[1];
      const queryMatch = href.match(/(?:^|[?&])q=([^&]+)/i);
      const rawUrl = queryMatch?.[1] || (href.startsWith("http") ? href : "");
      const url = decodeURIComponent(rawUrl);
      const parsed = new URL(url);
      if (!isOfficialLegalHost(parsed.hostname)) continue;
      const title = decodeSearchText(match[2]).slice(0, 255);
      if (!title || results.some(item => item.url === url)) continue;
      const documentNumber = title.match(/\b\d{1,3}\/\d{4}\/([A-ZĐ]+-[A-ZĐ-]+)\b/i)?.[0] || normalizedQuery.match(/\b\d{1,3}\/\d{4}\/[A-ZĐ-]+\b/i)?.[0] || "";
      results.push({ query: normalizedQuery, title, documentNumber, url, sourceName: parsed.hostname, sourceType: parsed.hostname.includes("dichvucong") ? "public_service" : "government", checkedAt: new Date().toISOString(), isOfficialDomain: true, effectiveStatus: "unknown", versionStatus: "unknown" });
    } catch { /* Bỏ qua liên kết kết quả không hợp lệ. */ }
  }
  if (!results.length) {
    return officialLegalSearchSeeds.map(seed => {
      const documentNumberMatch = normalizedQuery.match(/\b\d{1,3}\/\d{4}\/[A-ZĐ-]+\b/i);
      return {
        query: normalizedQuery,
        title: `${seed.title} — tìm “${normalizedQuery}”`,
        documentNumber: documentNumberMatch?.[0] || normalizedQuery,
        url: seed.url,
        sourceName: new URL(seed.url).hostname,
        sourceType: seed.sourceType,
        checkedAt: new Date().toISOString(),
        isOfficialDomain: true,
        effectiveStatus: "unknown",
        versionStatus: "unknown",
        warning: "Chưa lấy được kết quả chi tiết tự động; hãy mở nguồn và xác nhận văn bản cụ thể trước khi lưu.",
      };
    });
  }
  return results.slice(0, 10);
}

export async function analyzeLegalSourceUrl(inputUrl: string): Promise<LegalSourceUrlAnalysis> {
  let requested: URL;
  try { requested = new URL(inputUrl); } catch { throw new TRPCError({ code: "BAD_REQUEST", message: "URL nguồn không hợp lệ." }); }
  if (requested.protocol !== "https:") throw new TRPCError({ code: "BAD_REQUEST", message: "Chỉ cho phép URL HTTPS để bảo vệ nguồn pháp lý." });

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  let response: Response;
  try { response = await fetch(requested.toString(), { signal: controller.signal, headers: { Accept: "text/html,application/xhtml+xml,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document", "User-Agent": "BDSXanh-LegalSourceBot/1.0" } }); }
  catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "Không thể truy cập URL nguồn. Hãy kiểm tra URL, HTTPS hoặc nguồn có yêu cầu đăng nhập/CAPTCHA." }); }
  finally { clearTimeout(timer); }
  if (!response.ok) throw new TRPCError({ code: "BAD_GATEWAY", message: `Nguồn trả về HTTP ${response.status}; chưa thể tự phân tích.` });
  const contentType = response.headers.get("content-type") || "";
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > 3 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Trang nguồn vượt giới hạn 3MB để phân tích an toàn." });

  const canonicalUrl = response.url || requested.toString();
  const canonical = new URL(canonicalUrl);
  const baseUrl = `${canonical.protocol}//${canonical.host}`;
  const warnings: string[] = [];
  if (sourceTypeFor(canonical) === "other") warnings.push("Nguồn không thuộc miền .gov.vn; cần quản trị viên đối chiếu bản gốc trước khi sử dụng.");
  if (/application\/pdf|\.pdf(?:$|\?)/i.test(contentType + canonical.pathname)) {
    return { requestedUrl: inputUrl, canonicalUrl, baseUrl, sourceName: canonical.hostname, sourceType: sourceTypeFor(canonical), title: canonical.pathname.split("/").pop()?.replace(/[-_]+/g, " ") || "Tệp PDF pháp lý", documentNumber: "", province: "", receivingAuthority: "", issuingBody: "", versionLabel: "", effectiveStatus: "unknown", versionStatus: "unknown", relatedDocumentMentions: [], checkedAt: new Date().toISOString(), extractedText: "", attachments: [{ url: canonicalUrl, fileName: canonical.pathname.split("/").pop() || "document.pdf", format: "pdf", label: "Tệp PDF từ URL" }], warnings: [...warnings, "URL là tệp PDF; cần tải tệp vào ô văn bản để AI đọc nội dung và xác minh phụ lục."] };
  }

  const html = buffer.toString("utf8");
  const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const metaTitleMatch = html.match(/<meta[^>]+(?:property|name)=["'](?:og:title|title)["'][^>]+content=["']([^"']+)["']/i);
  const title = decodeHtml((metaTitleMatch?.[1] || titleMatch?.[1] || "").trim()).slice(0, 255);
  const text = cleanText(html).slice(0, 120000);
  const documentNumber = text.match(/\b(?:\d{1,3}\/\d{4}\/(?:TT|NĐ-CP|NQ|QH|QĐ|BTNMT|BTC|BTP)[A-Z0-9-]*)\b/i)?.[0] || "";
  const issuingBody = text.match(/(?:cơ quan ban hành|ban hành bởi|bộ|ủy ban nhân dân|chính phủ)\s*[:：-]?\s*([^.;]{3,120})/i)?.[1]?.trim() || "";
  const versionLabel = text.match(/(?:ngày ban hành|ban hành ngày|ngày hiệu lực)\s*[:：-]?\s*([^.;\n]{4,80})/i)?.[1]?.trim() || "";
  const effectiveStatus: LegalSourceUrlAnalysis["effectiveStatus"] = /hết hiệu lực|ngưng hiệu lực|bãi bỏ/i.test(text) ? "expired_candidate" : /có hiệu lực|đang có hiệu lực|hiệu lực từ/i.test(text) ? "in_force_candidate" : "unknown";
  const versionStatus: LegalSourceUrlAnalysis["versionStatus"] = /thay thế|bị thay thế|sửa đổi|bổ sung/i.test(text) ? "amended_candidate" : /mới nhất|hiện hành|còn hiệu lực/i.test(text) ? "current_candidate" : "unknown";
  const relatedDocumentMentions = Array.from(text.matchAll(/\b\d{1,3}\/\d{4}\/(?:NĐ-CP|TT-[A-ZĐ-]+|QĐ-[A-ZĐ-]+|NQ-[A-ZĐ-]+)\b/gi)).map(match => match[0]).filter((value, index, values) => values.indexOf(value) === index).slice(0, 20);
  const attachments: DiscoveredLegalAttachment[] = [];
  const linkMatches = Array.from(html.matchAll(/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi));
  for (const match of linkMatches) {
    const url = normalizeUrl(match[1], canonicalUrl);
    const fileName = url ? (new URL(url).pathname.split("/").pop() || "") : "";
    const format = /\.docx(?:$|\?)/i.test(url) ? "docx" : /\.pdf(?:$|\?)/i.test(url) ? "pdf" : null;
    if (format && !attachments.some(item => item.url === url)) attachments.push({ url, fileName: decodeHtml(fileName) || `${format}-attachment.${format}`, format, label: cleanText(match[2]).slice(0, 180) || fileName });
  }
  if (!title) warnings.push("Không đọc được tiêu đề trang; cần nhập bổ sung trước khi lưu.");
  if (!text) warnings.push("Trang không có lớp văn bản HTML; hãy tải tệp PDF/DOCX hoặc nhập nội dung được phép truy cập.");
  if (!attachments.length) warnings.push("Chưa phát hiện liên kết DOCX/PDF; kết quả hiện chỉ là metadata và nội dung trang.");
  return { requestedUrl: inputUrl, canonicalUrl, baseUrl, sourceName: canonical.hostname, sourceType: sourceTypeFor(canonical), title, documentNumber, province: "", receivingAuthority: inferAuthority(canonical, text), issuingBody, versionLabel, effectiveStatus, versionStatus, relatedDocumentMentions, checkedAt: new Date().toISOString(), extractedText: text, attachments: attachments.slice(0, 20), warnings };
}
