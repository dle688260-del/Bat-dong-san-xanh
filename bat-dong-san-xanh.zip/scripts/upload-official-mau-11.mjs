import { readFile } from "node:fs/promises";
import { storagePut } from "../server/storage.ts";

const filePath = "/home/ubuntu/webdev-static-assets/mau-11-dk.docx";
const bytes = await readFile(filePath);
const uploaded = await storagePut(
  `official-land-templates/mau-11-dk-nd101-2024.docx`,
  bytes,
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
);
console.log(JSON.stringify({ ...uploaded, bytes: bytes.byteLength }, null, 2));
