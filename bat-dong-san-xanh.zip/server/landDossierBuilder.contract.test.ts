import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("land dossier builder contract", () => {
  const source = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");

  it("exposes protected OCR with storage and structured extraction", () => {
    expect(source).toContain("landDossierBuilder: router({");
    expect(source).toContain("ocr: adminProcedure");
    expect(source).toContain("storagePut(`land-dossier-builder/");
    expect(source).toContain("land_dossier_ocr");
    expect(source).toContain("overallConfidence");
    expect(source).toContain("12 * 1024 * 1024");
  });

  it("supports separate transfer dossier documents", () => {
    expect(source).toContain('"transfer-contract"');
    expect(source).toContain('"variation-form"');
    expect(source).toContain('"pit-tax"');
    expect(source).toContain('"registration-fee"');
    expect(source).toContain('"checklist"');
    expect(source).toContain("HỢP ĐỒNG CHUYỂN NHƯỢNG QUYỀN SỬ DỤNG ĐẤT");
    expect(source).toContain("ĐƠN ĐĂNG KÝ BIẾN ĐỘNG ĐẤT ĐAI");
  });

  it("uses a server-only verified template allowlist", () => {
    expect(source).toContain("getVerifiedLandTemplate(input.documentType, input.format)");
    expect(source).toContain("storageGetSignedUrl(verifiedAsset.storageKey)");
    expect(source).toContain('templateProvenance: "metadata-only" as const');
    expect(source).toContain('status: "confirmed-draft" as const');
  });

  it("emits readable binary formats with stable per-document names", () => {
    expect(source).toContain("Packer.toBuffer(document)");
    expect(source).toContain("await pdf.save()");
    expect(source).toContain("safeFileStem");
    expect(source).toContain("-ban-nhap.docx");
    expect(source).toContain("-ban-nhap.pdf");
    expect(source).toContain("pdf.addPage([595, 842])");
    expect(source).toContain("if (y < 48)");
  });

  it("connects the Builder to the canonical legal bundle and full AI analysis input", () => {
    const builder = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(builder).toContain("trpc.legalKnowledge.bundle.useQuery");
    expect(builder).toContain("trpc.legalKnowledge.templates.useQuery");
    expect(builder).toContain("template.checksum");
    expect(builder).toContain("template.sourceUrl");
    expect(builder).toContain("analyzeDossier.mutateAsync");
    expect(builder).toContain("dossierComponents: selectedBundle.map");
    expect(builder).toContain("ocrFields: fields.map");
  });

  it("requires confirmed OCR fields before producing DOCX/PDF draft", () => {
    expect(source).toContain("exportBundle: adminProcedure");
    expect(source).toContain("PRECONDITION_FAILED");
    expect(source).toContain("field.confirmed");
    expect(source).toContain("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    expect(source).toContain('mimeType: "application/pdf"');
    expect(source).toContain('templateProvenance: z.enum(["metadata-only", "verified-binary"])');
    expect(source).toContain('Trạng thái: CONFIRMED DRAFT — bản tham khảo do AI dựng, chưa phải mẫu Official');
    expect(source).toContain('status: "confirmed-draft" as const');
    expect(source).toContain('templateProvenance: "metadata-only" as const');
  });
});
