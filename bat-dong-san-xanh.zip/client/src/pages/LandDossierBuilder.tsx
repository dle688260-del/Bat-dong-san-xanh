import DashboardLayout from "@/components/DashboardLayout";
import { LegalSourceRegistryPanel } from "@/components/LegalSourceRegistryPanel";
import { PROVINCE_OPTIONS } from "@/data/provinces";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle, CheckCircle2, ChevronRight, ClipboardCheck, FileCheck2, FileText, LockKeyhole, Search, Sparkles, UploadCloud, Loader2, Download, Printer, Camera, Video, X, Square } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import JSZip from "jszip";
import { auditLandDossierLegalSources, legalSourceAuditSummary } from "@/lib/legalSourceAudit";
import { EMPTY_LAND_DOSSIER_INPUT, landDossierWorkflowState, mergeConfirmedOcrIntoInput, type LandDossierInput, type LandDossierOcrField } from "@/lib/landDossierContract";

export const LAND_DOSSIER_BUILDER_ROUTE = "/ai-lap-ho-so-dat-dai";
export function landBundleStatusLabel(input: { isLoading: boolean; timedOut: boolean; hasError: boolean; hasData: boolean; hasMetadata?: boolean; hasOfficialBinary?: boolean }) {
  if (input.isLoading) return input.timedOut ? "Bundle đang chậm · nguồn phụ vẫn hoạt động riêng" : "Đang nạp bundle pháp lý…";
  if (input.hasError) return input.hasMetadata ? "Metadata đã nạp · bundle Official đang được đối chiếu" : "Bundle chưa nạp được · có thể thử lại";
  if (input.hasOfficialBinary) return "Official binary verified";
  if (input.hasMetadata) return "Metadata đã nạp · chưa có Official binary";
  if (input.hasData) return "Bundle pháp lý đã nạp";
  return "Đang dùng dữ liệu tham chiếu";
}
export const PUBLIC_POST_CHANNELS = [
  ["website", "Website"],
  ["facebook-personal", "Facebook cá nhân"],
  ["zalo-personal", "Zalo cá nhân"],
] as const;
export function buildPublicPostText(data: { landAddress?: string; area?: string; transferPrice?: string; landUse?: string }, caption = "") {
  return [
    data.landAddress ? `Bất động sản tại ${data.landAddress}` : "Bất động sản xanh",
    data.area ? `Diện tích: ${data.area} m²` : "",
    data.transferPrice ? `Giá: ${data.transferPrice}` : "",
    data.landUse ? `Mục đích sử dụng: ${data.landUse}` : "",
    caption.trim(),
  ].filter(Boolean).join("\\n");
}

export const LAND_DOSSIER_BUILDER_PROCEDURES = [
  ["certificate", "Cấp Giấy chứng nhận", "Đăng ký đất đai, cấp giấy chứng nhận lần đầu"],
  ["variation", "Đăng ký biến động đất đai", "Thay đổi chủ sử dụng, thông tin hoặc căn cứ quyền sử dụng"],
  ["transfer", "Chuyển nhượng quyền sử dụng đất", "Hợp đồng, thuế và đăng ký sang tên"],
  ["gift", "Tặng cho quyền sử dụng đất", "Văn bản tặng cho và hồ sơ đăng ký biến động"],
  ["inheritance", "Thừa kế quyền sử dụng đất", "Văn bản thừa kế, nhân thân và sang tên"],
  ["purpose", "Chuyển mục đích sử dụng đất", "Kiểm tra quy hoạch, điều kiện và nghĩa vụ tài chính"],
  ["split", "Tách thửa", "Phương án tách, bản vẽ và điều kiện thửa đất"],
  ["merge", "Hợp thửa", "Các thửa liền kề, bản vẽ và giấy chứng nhận"],
  ["mortgage", "Đăng ký thế chấp / xóa thế chấp", "Hồ sơ đăng ký hoặc giải chấp quyền sử dụng đất"],
  ["lease", "Cho thuê / cho thuê lại đất", "Hợp đồng cho thuê, đăng ký biến động và nghĩa vụ tài chính liên quan"],
  ["sale-house", "Sang tên khi mua bán nhà, đất", "Bộ hồ sơ mua bán nhà đất, công chứng, thuế phí và đăng ký sang tên"],
  ["correction", "Đính chính, cập nhật thông tin đất đai", "Sửa thông tin người sử dụng đất, giấy chứng nhận hoặc hồ sơ địa chính"],
  ["first-registration", "Đăng ký đất đai lần đầu", "Chuẩn bị hồ sơ đăng ký, cấp giấy chứng nhận và giấy tờ nguồn gốc"],
  ["data-request", "Xin cung cấp thông tin, dữ liệu đất đai", "Đề nghị trích lục, cung cấp thông tin hoặc dữ liệu thửa đất"],
  ["certificate-renewal", "Cấp đổi Giấy chứng nhận", "Đổi Giấy chứng nhận do thay đổi thông tin, rách hỏng hoặc nhu cầu cấp đổi"],
  ["certificate-reissue", "Cấp lại Giấy chứng nhận bị mất", "Chuẩn bị hồ sơ khai báo mất và đề nghị cấp lại Giấy chứng nhận"],
  ["capital-contribution", "Góp vốn bằng quyền sử dụng đất", "Hợp đồng góp vốn, đăng ký biến động và nghĩa vụ liên quan"],
  ["special-transfer", "Chuyển quyền trong trường hợp đặc biệt", "Rà soát căn cứ chuyển quyền và giấy tờ chứng minh theo trường hợp"],
  ["parcel-change", "Đăng ký thay đổi diện tích thửa đất", "Cập nhật diện tích, kích thước hoặc kết quả đo đạc mới"],
  ["user-change", "Thay đổi thông tin người sử dụng đất", "Cập nhật họ tên, giấy tờ nhân thân hoặc chủ sử dụng"],
  ["address-change", "Thay đổi địa chỉ thửa đất", "Cập nhật địa chỉ hành chính hoặc địa chỉ liên hệ trên hồ sơ"],
  ["attached-asset", "Đăng ký tài sản gắn liền với đất", "Đăng ký nhà ở, công trình hoặc tài sản gắn liền với thửa đất"],
  ["purpose-change", "Đăng ký thay đổi mục đích sử dụng đất", "Cập nhật mục đích sử dụng theo hồ sơ và quyết định liên quan"],
  ["purpose-finance", "Nghĩa vụ tài chính khi chuyển mục đích", "Tổng hợp tiền sử dụng đất, thuế và phí cần rà soát"],
  ["allocation", "Giao đất", "Hồ sơ đề nghị giao đất và kiểm tra điều kiện, quy hoạch"],
  ["lease-extension", "Gia hạn sử dụng đất", "Hồ sơ gia hạn thời hạn sử dụng đất hoặc hợp đồng thuê"],
  ["term-adjustment", "Điều chỉnh thời hạn sử dụng đất", "Rà soát căn cứ điều chỉnh thời hạn trên Giấy chứng nhận"],
  ["recovery", "Thu hồi đất", "Hồ sơ, thông báo và quyền lợi cần kiểm tra khi thu hồi đất"],
  ["compensation", "Bồi thường, hỗ trợ, tái định cư", "Tổng hợp giấy tờ về đất, tài sản và phương án bồi thường"],
  ["map-extract", "Trích lục bản đồ địa chính", "Đề nghị cung cấp trích lục bản đồ và thông tin thửa đất"],
  ["survey", "Trích đo địa chính", "Yêu cầu đo đạc, lập bản trích đo phục vụ thủ tục"],
  ["boundary", "Xác định ranh giới, diện tích", "Chuẩn bị hồ sơ xác định mốc giới và diện tích thực tế"],
  ["cadastre-update", "Chỉnh lý hồ sơ địa chính", "Cập nhật biến động vào bản đồ và hồ sơ địa chính"],
  ["planning", "Tra cứu quy hoạch", "Tra cứu thông tin quy hoạch liên quan đến thửa đất"],
  ["land-plan", "Thông tin kế hoạch sử dụng đất", "Kiểm tra kế hoạch sử dụng đất theo địa phương"],
  ["planning-status", "Xác định tình trạng quy hoạch thửa đất", "Tổng hợp yêu cầu cung cấp thông tin quy hoạch"],
  ["pit-tax", "Thuế thu nhập cá nhân khi chuyển nhượng", "Tờ khai và hồ sơ xác định thuế hoặc miễn giảm"],
  ["registration-fee", "Lệ phí trước bạ", "Tờ khai và dữ liệu tính lệ phí trước bạ nhà đất"],
  ["land-use-money", "Tiền sử dụng đất", "Rà soát nghĩa vụ tiền sử dụng đất theo trường hợp"],
  ["land-rent", "Tiền thuê đất", "Rà soát tiền thuê đất, thời hạn và phương thức nộp"],
  ["other-fees", "Phí, lệ phí đất đai liên quan", "Tổng hợp các khoản phí cần kiểm tra theo thủ tục"],
  ["transaction-dossier", "Bộ hồ sơ giao dịch bất động sản", "Kiểm tra pháp lý, quy hoạch, hợp đồng, thuế phí và sang tên"],
] as const;

export type LandProcedureTreeNode = { id: string; label: string; description: string; procedureIds: readonly string[] };

export const LAND_PROCEDURE_TREE: readonly LandProcedureTreeNode[] = [
  { id: "registration-certificate", label: "1. Đăng ký đất đai – cấp Giấy chứng nhận", description: "Đăng ký lần đầu, cấp/cấp đổi/cấp lại, biến động và đính chính thông tin.", procedureIds: ["first-registration", "certificate", "variation", "correction"] },
  { id: "land-rights-transfer", label: "2. Chuyển quyền sử dụng đất", description: "Chuyển nhượng, tặng cho, thừa kế và các trường hợp chuyển quyền liên quan.", procedureIds: ["transfer", "sale-house", "gift", "inheritance", "capital-contribution"] },
  { id: "parcel-information", label: "3. Thay đổi hiện trạng/thông tin thửa đất", description: "Tách/hợp thửa, thay đổi diện tích, địa chỉ, người sử dụng và tài sản gắn liền.", procedureIds: ["split", "merge", "parcel-change", "user-change", "address-change", "attached-asset"] },
  { id: "land-use-purpose", label: "4. Mục đích sử dụng đất", description: "Chuyển hoặc đăng ký thay đổi mục đích và rà soát nghĩa vụ tài chính.", procedureIds: ["purpose", "purpose-change", "purpose-finance"] },
  { id: "allocation-lease-recovery", label: "5. Giao đất – cho thuê đất – thu hồi đất", description: "Giao, thuê, gia hạn, điều chỉnh thời hạn, thu hồi và bồi thường hỗ trợ.", procedureIds: ["allocation", "lease", "lease-extension", "term-adjustment", "recovery", "compensation"] },
  { id: "survey-cadastre", label: "6. Đo đạc – địa chính", description: "Trích lục, trích đo, xác định ranh giới và chỉnh lý hồ sơ địa chính.", procedureIds: ["map-extract", "survey", "boundary", "cadastre-update"] },
  { id: "planning-information", label: "7. Quy hoạch – kế hoạch sử dụng đất", description: "Tra cứu quy hoạch, kế hoạch và cung cấp thông tin thửa đất.", procedureIds: ["planning", "land-plan", "planning-status", "data-request"] },
  { id: "financial-obligations", label: "8. Nghĩa vụ tài chính", description: "Thuế TNCN, lệ phí trước bạ, tiền sử dụng đất, tiền thuê đất và khoản phí liên quan.", procedureIds: ["pit-tax", "registration-fee", "land-use-money", "land-rent", "other-fees"] },
  { id: "real-estate-transaction", label: "9. Hồ sơ giao dịch bất động sản", description: "Ghép kiểm tra pháp lý, quy hoạch, hợp đồng, thuế phí, sang tên và nhận kết quả.", procedureIds: ["transaction-dossier", "sale-house", "transfer", "lease"] },
] as const;

export type LandDossierTemplate = { id: string; label: string; fileName: string; sourceUrl: string; legalBasis: string; status: "verified-reference" | "needs-local-review"; provenance: "metadata-only" | "verified-binary" };

export const LAND_DOSSIER_TEMPLATE_REGISTRY: Record<string, LandDossierTemplate[]> = {
  certificate: [{ id: "m15-dkld", label: "Đơn đăng ký đất đai, tài sản gắn liền với đất", fileName: "Mus15DKLD.docx", sourceUrl: "https://dichvucong.hungyen.gov.vn/block/phieu-huong-dan/thu-tuc/67161", legalBasis: "Nghị định 151/2025/NĐ-CP · Mẫu 15", status: "needs-local-review", provenance: "metadata-only" }, { id: "m16-dkld", label: "Tờ khai/phiếu thông tin liên quan theo bộ thủ tục", fileName: "Mẫu 16", sourceUrl: "https://phuly.ninhbinh.gov.vn/thu-tuc-hanh-chinh/dang-ky-dat-dai-tai-san-gan-lien-voi-dat-cap-giay-chung-nhan-quyen-su-dung-dat-quyen-so-huu-tai-san-gan-lien-voi-dat-lan-dau-doi-voi-ho-gia-dinh-ca-nhan-cong-dong-dan-cu-nguoi-goc-viet-nam-dinh-cu-o-nuoc-ngoai", legalBasis: "Nghị định 151/2025/NĐ-CP · Mẫu 16", status: "needs-local-review", provenance: "metadata-only" }],
  variation: [{ id: "m09-dk", label: "Đơn đăng ký biến động đất đai", fileName: "Mẫu 09/ĐK", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · thủ tục đăng ký biến động", status: "needs-local-review", provenance: "metadata-only" }],
  transfer: [{ id: "m09-dk-transfer", label: "Đơn đăng ký biến động do chuyển nhượng", fileName: "Mẫu 09/ĐK", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · đăng ký biến động", status: "needs-local-review", provenance: "metadata-only" }],
  gift: [{ id: "m09-dk-gift", label: "Đơn đăng ký biến động do tặng cho", fileName: "Mẫu 09/ĐK", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · đăng ký biến động", status: "needs-local-review", provenance: "metadata-only" }],
  inheritance: [{ id: "m09-dk-inheritance", label: "Đơn đăng ký biến động do thừa kế", fileName: "Mẫu 09/ĐK", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · đăng ký biến động", status: "needs-local-review", provenance: "metadata-only" }],
  purpose: [{ id: "purpose-application", label: "Đơn xin chuyển mục đích sử dụng đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · chuyển mục đích sử dụng đất", status: "needs-local-review", provenance: "metadata-only" }],
  split: [{ id: "split-application", label: "Đơn đề nghị tách thửa", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · tách thửa", status: "needs-local-review", provenance: "metadata-only" }],
  merge: [{ id: "merge-application", label: "Đơn đề nghị hợp thửa", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Luật Đất đai 2024 · hợp thửa", status: "needs-local-review", provenance: "metadata-only" }],
  mortgage: [{ id: "mortgage-registration", label: "Đơn đăng ký thế chấp/xóa thế chấp", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Thủ tục đăng ký biện pháp bảo đảm", status: "needs-local-review", provenance: "metadata-only" }],
  lease: [{ id: "lease-application", label: "Hồ sơ đăng ký/ghi nhận cho thuê, cho thuê lại đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Đăng ký biến động do cho thuê/cho thuê lại", status: "needs-local-review", provenance: "metadata-only" }],
  "sale-house": [{ id: "sale-house-variation", label: "Đơn đăng ký biến động do mua bán nhà, đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Đăng ký biến động và sang tên", status: "needs-local-review", provenance: "metadata-only" }],
  correction: [{ id: "correction-application", label: "Đơn đề nghị đính chính/cập nhật thông tin", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Đính chính thông tin đất đai", status: "needs-local-review", provenance: "metadata-only" }],
  "first-registration": [{ id: "first-registration-application", label: "Đơn đăng ký đất đai, cấp Giấy chứng nhận lần đầu", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://csdl.dichvucong.gov.vn/", legalBasis: "Đăng ký đất đai và cấp Giấy chứng nhận", status: "needs-local-review", provenance: "metadata-only" }],
  "data-request": [{ id: "land-data-request", label: "Văn bản đề nghị cung cấp thông tin, dữ liệu đất đai", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67", legalBasis: "Cung cấp thông tin, dữ liệu đất đai", status: "needs-local-review", provenance: "metadata-only" }],
};

/** Nguồn thủ tục được kiểm tra lần gần nhất. URL chỉ dùng để đối chiếu; không suy ra binary Official. */
export const LAND_DOSSIER_OFFICIAL_SOURCES = {
  "variation-2.000889": {
    procedureCode: "2.000889",
    title: "Đăng ký biến động quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889",
    sourceName: "Cổng Dịch vụ công Quốc gia",
    issuingAgency: "Cơ quan đăng ký đất đai theo thẩm quyền",
    lastCheckedAt: "18/08/2026",
    status: "verified-reference" as const,
    note: "Đối chiếu thủ tục, thành phần hồ sơ và biểu mẫu theo địa phương; chưa xác minh tệp binary ổn định để gắn Official."
  },
  "government-decree-151": {
    procedureCode: "N/A",
    title: "Nghị định 151/2025/NĐ-CP",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=213927",
    sourceName: "Hệ thống văn bản Chính phủ",
    issuingAgency: "Chính phủ",
    lastCheckedAt: "18/08/2026",
    status: "verified-reference" as const,
    note: "Nguồn căn cứ để đối chiếu thẩm quyền và trình tự; không phải bản biểu mẫu để tải trực tiếp."
  }
} as const;

export function landDossierBuilderOfficialSource(procedureId: string) {
  if (["variation", "transfer", "gift", "inheritance", "sale-house", "lease"].includes(procedureId)) return LAND_DOSSIER_OFFICIAL_SOURCES["variation-2.000889"];
  return LAND_DOSSIER_OFFICIAL_SOURCES["government-decree-151"];
}

export type LandDossierBundleItem = { id: string; label: string; category: "form" | "supporting" | "tax" | "authority"; required: boolean; condition?: string };

export const LAND_DOSSIER_BUNDLE_REGISTRY: Record<string, LandDossierBundleItem[]> = {
  variation: [
    { id: "m09", label: "Mẫu 09/ĐK — Đơn đăng ký biến động", category: "form", required: true },
    { id: "certificate-original", label: "Bản gốc Giấy chứng nhận đã cấp", category: "supporting", required: true },
    { id: "legal-basis", label: "Hợp đồng/văn bản làm căn cứ biến động", category: "supporting", required: false, condition: "Tùy nguyên nhân biến động" },
    { id: "tax-info", label: "Thông tin xác định nghĩa vụ tài chính", category: "tax", required: false, condition: "Khi phát sinh" },
    { id: "authority-guide", label: "Hướng dẫn cơ quan tiếp nhận theo địa phương", category: "authority", required: true },
  ],
  transfer: [
    { id: "m09-transfer", label: "Mẫu 09/ĐK — Đơn đăng ký biến động do chuyển nhượng", category: "form", required: true },
    { id: "transfer-contract", label: "Hợp đồng chuyển nhượng/văn bản chuyển quyền", category: "supporting", required: true },
    { id: "certificate-original-transfer", label: "Bản gốc Giấy chứng nhận đã cấp", category: "supporting", required: true },
    { id: "pit-declaration", label: "Tờ khai thuế thu nhập cá nhân", category: "tax", required: false, condition: "Khi giao dịch phát sinh nghĩa vụ hoặc cần xác định miễn giảm" },
    { id: "registration-fee-declaration", label: "Tờ khai lệ phí trước bạ", category: "tax", required: false, condition: "Khi phát sinh nghĩa vụ hoặc cần xác định miễn giảm" },
    { id: "tax-supporting", label: "Giấy tờ chứng minh miễn/giảm thuế, lệ phí", category: "tax", required: false, condition: "Nếu người nộp yêu cầu miễn/giảm" },
    { id: "authority-guide-transfer", label: "Thông tin cơ quan tiếp nhận và hướng dẫn nộp", category: "authority", required: true },
  ],
  gift: [
    { id: "m09-gift", label: "Mẫu 09/ĐK — Đơn đăng ký biến động do tặng cho", category: "form", required: true },
    { id: "gift-contract", label: "Hợp đồng/văn bản tặng cho", category: "supporting", required: true },
    { id: "certificate-original-gift", label: "Bản gốc Giấy chứng nhận đã cấp", category: "supporting", required: true },
    { id: "tax-fee-review-gift", label: "Nhóm tờ khai thuế, lệ phí và giấy tờ miễn giảm", category: "tax", required: false, condition: "Theo quan hệ tặng cho và quy định miễn/giảm" },
    { id: "authority-guide-gift", label: "Thông tin cơ quan tiếp nhận và hướng dẫn nộp", category: "authority", required: true },
  ],
  lease: [
    { id: "lease-contract", label: "Hợp đồng cho thuê/cho thuê lại đất", category: "form", required: true },
    { id: "lease-variation", label: "Hồ sơ đăng ký biến động do cho thuê/cho thuê lại", category: "form", required: true },
    { id: "certificate-original-lease", label: "Giấy chứng nhận và giấy tờ quyền sử dụng đất", category: "supporting", required: true },
    { id: "lease-tax-fee", label: "Tờ khai và nghĩa vụ tài chính liên quan", category: "tax", required: false, condition: "Theo trường hợp và chủ thể cho thuê" },
    { id: "authority-guide-lease", label: "Hướng dẫn cơ quan tiếp nhận", category: "authority", required: true },
  ],
  "sale-house": [
    { id: "sale-house-contract", label: "Hợp đồng mua bán/chuyển nhượng nhà, đất", category: "form", required: true },
    { id: "sale-house-variation", label: "Đơn đăng ký biến động/sang tên", category: "form", required: true },
    { id: "sale-house-pit", label: "Tờ khai thuế thu nhập cá nhân", category: "tax", required: false, condition: "Nếu phát sinh hoặc cần xác định miễn giảm" },
    { id: "sale-house-fee", label: "Tờ khai lệ phí trước bạ", category: "tax", required: false, condition: "Nếu phát sinh hoặc cần xác định miễn giảm" },
    { id: "sale-house-supporting", label: "Giấy tờ nhà ở, giấy chứng nhận và nhân thân", category: "supporting", required: true },
    { id: "authority-guide-sale-house", label: "Quy trình công chứng, thuế và nộp sang tên", category: "authority", required: true },
  ],
  split: [
    { id: "split-application", label: "Đơn đề nghị tách thửa", category: "form", required: true },
    { id: "split-certificate", label: "Bản gốc Giấy chứng nhận và giấy tờ thửa đất", category: "supporting", required: true },
    { id: "split-survey", label: "Bản vẽ/trích đo địa chính phục vụ tách thửa", category: "supporting", required: true },
    { id: "authority-guide-split", label: "Điều kiện diện tích, kích thước và cơ quan tiếp nhận", category: "authority", required: true },
  ],
  merge: [
    { id: "merge-application", label: "Đơn đề nghị hợp thửa", category: "form", required: true },
    { id: "merge-certificates", label: "Bản gốc Giấy chứng nhận của các thửa đất", category: "supporting", required: true },
    { id: "merge-survey", label: "Bản vẽ/trích đo địa chính phục vụ hợp thửa", category: "supporting", required: true },
    { id: "authority-guide-merge", label: "Điều kiện thửa liền kề và cơ quan tiếp nhận", category: "authority", required: true },
  ],
  correction: [
    { id: "correction-application", label: "Đơn đề nghị đính chính/cập nhật", category: "form", required: true },
    { id: "correction-certificate", label: "Giấy chứng nhận và tài liệu chứng minh thông tin đúng", category: "supporting", required: true },
    { id: "authority-guide-correction", label: "Hướng dẫn cơ quan tiếp nhận", category: "authority", required: true },
  ],
  "first-registration": [
    { id: "first-registration-form", label: "Đơn đăng ký đất đai/cấp Giấy chứng nhận", category: "form", required: true },
    { id: "first-registration-origin", label: "Giấy tờ nguồn gốc, sử dụng đất và tài sản", category: "supporting", required: true },
    { id: "first-registration-tax", label: "Tờ khai nghĩa vụ tài chính", category: "tax", required: false, condition: "Theo kết quả xác định nghĩa vụ" },
    { id: "authority-guide-first-registration", label: "Quy trình đăng ký và cấp giấy", category: "authority", required: true },
  ],
  "data-request": [
    { id: "land-data-request-form", label: "Văn bản đề nghị cung cấp dữ liệu đất đai", category: "form", required: true },
    { id: "land-data-request-id", label: "Giấy tờ nhân thân/ủy quyền", category: "supporting", required: true },
    { id: "authority-guide-data-request", label: "Nơi nộp và cách nhận dữ liệu", category: "authority", required: true },
  ],
  inheritance: [
    { id: "m09-inheritance", label: "Mẫu 09/ĐK — Đơn đăng ký biến động do thừa kế", category: "form", required: true },
    { id: "inheritance-document", label: "Văn bản thừa kế/khai nhận hoặc phân chia di sản", category: "supporting", required: true },
    { id: "certificate-original-inheritance", label: "Bản gốc Giấy chứng nhận đã cấp", category: "supporting", required: true },
    { id: "relationship-proof", label: "Giấy tờ nhân thân và chứng minh quan hệ", category: "supporting", required: false, condition: "Theo trường hợp thừa kế" },
    { id: "tax-fee-review-inheritance", label: "Nhóm tờ khai thuế, lệ phí và giấy tờ miễn giảm", category: "tax", required: false, condition: "Theo đối tượng và căn cứ miễn/giảm" },
    { id: "authority-guide-inheritance", label: "Thông tin cơ quan tiếp nhận và hướng dẫn nộp", category: "authority", required: true },
  ],
};

export function landDossierBuilderTemplates(procedureId: string) { return LAND_DOSSIER_TEMPLATE_REGISTRY[procedureId] ?? []; }
export function landDossierBuilderBundle(procedureId: string) { return LAND_DOSSIER_BUNDLE_REGISTRY[procedureId] ?? [{ id: "main-form", label: "Biểu mẫu chính theo thủ tục", category: "form", required: true }, { id: "supporting-documents", label: "Giấy tờ chứng minh và tài liệu thửa đất", category: "supporting", required: true }, { id: "tax-review", label: "Thuế, lệ phí và nghĩa vụ tài chính", category: "tax", required: false, condition: "Nếu phát sinh" }, { id: "authority-guide-generic", label: "Hướng dẫn cơ quan tiếp nhận", category: "authority", required: true }]; };

/** Chuẩn hóa tiếng Việt để tìm tên thủ tục gần đúng nhưng vẫn trả về đúng mã đã chọn. */
export function normalizeLandProcedureSearch(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("vi").replace(/đ/g, "d").replace(/[^a-z0-9]+/g, " ").trim();
}

export function landProcedureMatchesSearch(values: string[], query: string) {
  const normalizedQuery = normalizeLandProcedureSearch(query);
  if (!normalizedQuery) return true;
  const haystack = values.map(normalizeLandProcedureSearch).join(" ");
  if (haystack.includes(normalizedQuery)) return true;
  const stopWords = new Set(["khi", "xin", "cho", "cua", "của", "va", "và", "de", "để", "toi", "tôi", "muon", "muốn"]);
  const tokens = normalizedQuery.split(/\s+/).filter(token => token.length > 1 && !stopWords.has(token));
  return tokens.length > 0 && tokens.every(token => haystack.includes(token));
}

export function landDossierProcedureSyncSnapshot(procedureId: string, province: string, procedureName?: string) {
  const procedure = LAND_DOSSIER_BUILDER_PROCEDURES.find(([id]) => id === procedureId);
  const title = procedureName || procedure?.[1] || procedureId;
  const description = procedure?.[2] || "Thủ tục trong catalog pháp lý AI; cần đối chiếu bundle nguồn theo mã đã chọn.";
  return { procedureId, procedureTitle: title, province, templates: landDossierBuilderTemplates(procedureId), bundle: landDossierBuilderBundle(procedureId), query: `${title} · ${description}${province ? ` · ${province}` : ""}` };
}

export type NextLandProcedureRecommendation = {
  procedureId: string;
  reason: string;
  confidence: "Cao" | "Vừa";
  legalSources: Array<{ label: string; url: string }>;
};

const NEXT_PROCEDURE_RECOMMENDATIONS: Record<string, NextLandProcedureRecommendation[]> = {
  transfer: [
    { procedureId: "inheritance", reason: "Nếu chủ sử dụng mới qua đời hoặc quyền sử dụng đất chuyển cho người thừa kế, cần lập hồ sơ thừa kế và đăng ký biến động tiếp theo.", confidence: "Cao", legalSources: [{ label: "Nghị định 101/2024/NĐ-CP", url: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791" }, { label: "Cổng Dịch vụ công quốc gia", url: "https://dichvucong.gov.vn/" }] },
    { procedureId: "variation", reason: "Sau khi ký hợp đồng, có thể cần hoàn thiện đăng ký biến động/sang tên tại cơ quan tiếp nhận địa phương.", confidence: "Cao", legalSources: [{ label: "Thủ tục đăng ký biến động", url: "https://vpcp.dichvucong.gov.vn/" }] },
    { procedureId: "registration-fee", reason: "Hệ thống đề xuất rà soát lệ phí trước bạ nếu hồ sơ chuyển nhượng phát sinh nghĩa vụ tài chính.", confidence: "Vừa", legalSources: [{ label: "Cổng Dịch vụ công Bộ Tài chính", url: "https://dichvucong.mof.gov.vn/" }] },
  ],
  gift: [{ procedureId: "inheritance", reason: "Nếu bên nhận tặng cho đã mất hoặc phát sinh người thừa kế, cần chuyển sang hồ sơ thừa kế để tiếp tục đăng ký biến động.", confidence: "Vừa", legalSources: [{ label: "Nghị định 101/2024/NĐ-CP", url: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791" }] }],
  "sale-house": [{ procedureId: "variation", reason: "Sau hợp đồng mua bán nhà đất, bước thường gặp là đăng ký biến động và sang tên.", confidence: "Cao", legalSources: [{ label: "Cổng Dịch vụ công quốc gia", url: "https://dichvucong.gov.vn/" }] }],
  split: [{ procedureId: "certificate", reason: "Sau khi tách thửa được chấp thuận và đo đạc hoàn tất, cần rà soát cấp Giấy chứng nhận cho các thửa mới.", confidence: "Vừa", legalSources: [{ label: "Cổng Dịch vụ công quốc gia", url: "https://dichvucong.gov.vn/" }] }],
  merge: [{ procedureId: "certificate", reason: "Sau khi hợp thửa, cần cập nhật/cấp Giấy chứng nhận theo thửa mới và kết quả đo đạc.", confidence: "Vừa", legalSources: [{ label: "Cổng Dịch vụ công quốc gia", url: "https://dichvucong.gov.vn/" }] }],
};

export function landDossierNextProcedureRecommendations(procedureId: string): NextLandProcedureRecommendation[] {
  return NEXT_PROCEDURE_RECOMMENDATIONS[procedureId] ?? [{ procedureId: "variation", reason: "Rà soát đăng ký biến động để bảo đảm thay đổi mới nhất đã được cập nhật vào hồ sơ địa chính.", confidence: "Vừa", legalSources: [{ label: "Cổng Dịch vụ công quốc gia", url: "https://dichvucong.gov.vn/" }] }];
}

export function landDossierRecommendationDocuments(procedureId: string) {
  return (landDossierBuilderTemplates(procedureId).length ? landDossierBuilderTemplates(procedureId) : []).map(template => ({ label: template.label, fileName: template.fileName, url: template.sourceUrl, status: template.provenance === "verified-binary" ? "Official đã xác minh" : "Nguồn tham chiếu · cần rà soát" }));
}

export function landDossierRecommendationTitle(procedureId: string, procedureName?: string) {
  return procedureName || LAND_DOSSIER_BUILDER_PROCEDURES.find(([id]) => id === procedureId)?.[1] || procedureId;
}

export function landDossierRecommendationHint(procedureId: string) {
  return LAND_DOSSIER_BUILDER_PROCEDURES.find(([id]) => id === procedureId)?.[2] ?? "Thủ tục tiếp theo cần đối chiếu theo hồ sơ thực tế";
}

export function landDossierBinarySearchKeywords(procedureId: string, input: string) {
  const manual = input.split(",").map(item => item.trim()).filter(Boolean);
  if (manual.length > 0) return manual.slice(0, 12);
  const procedureTitle = landDossierRecommendationTitle(procedureId);
  const guidance = landDossierBuilderGuidance(procedureId);
  const templateLabels = landDossierBuilderTemplates(procedureId).slice(0, 2).flatMap(template => [template.fileName, template.label]);
  return Array.from(new Set([procedureTitle, guidance.code, ...templateLabels].map(item => item.trim()).filter(Boolean))).slice(0, 12);
}

const additionalTemplateRegistry: Record<string, LandDossierTemplate[]> = {
  "certificate-renewal": [{ id: "certificate-renewal-application", label: "Đơn đề nghị cấp đổi Giấy chứng nhận", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Luật Đất đai 2024 và thủ tục địa phương", status: "needs-local-review", provenance: "metadata-only" }],
  "certificate-reissue": [{ id: "certificate-reissue-application", label: "Đơn đề nghị cấp lại Giấy chứng nhận bị mất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Luật Đất đai 2024 và thủ tục địa phương", status: "needs-local-review", provenance: "metadata-only" }],
  "capital-contribution": [{ id: "capital-contribution-contract", label: "Hợp đồng góp vốn bằng quyền sử dụng đất", fileName: "Mẫu tham khảo nội bộ", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Thủ tục đăng ký biến động và giao dịch quyền sử dụng đất", status: "needs-local-review", provenance: "metadata-only" }],
  "parcel-change": [{ id: "parcel-change-application", label: "Đơn đăng ký thay đổi diện tích thửa đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Hồ sơ đo đạc, chỉnh lý và đăng ký biến động", status: "needs-local-review", provenance: "metadata-only" }],
  "user-change": [{ id: "user-change-application", label: "Đơn đăng ký thay đổi thông tin người sử dụng đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Đăng ký biến động thông tin người sử dụng đất", status: "needs-local-review", provenance: "metadata-only" }],
  "address-change": [{ id: "address-change-application", label: "Đơn đề nghị cập nhật địa chỉ", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Đăng ký thay đổi địa chỉ hành chính", status: "needs-local-review", provenance: "metadata-only" }],
  "attached-asset": [{ id: "attached-asset-application", label: "Đơn đăng ký tài sản gắn liền với đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Đăng ký tài sản gắn liền với đất", status: "needs-local-review", provenance: "metadata-only" }],
  "purpose-change": [{ id: "purpose-change-application", label: "Đơn đăng ký thay đổi mục đích sử dụng đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Luật Đất đai 2024 và quyết định cho phép chuyển mục đích", status: "needs-local-review", provenance: "metadata-only" }],
  allocation: [{ id: "allocation-application", label: "Đơn đề nghị giao đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Hồ sơ giao đất theo thẩm quyền", status: "needs-local-review", provenance: "metadata-only" }],
  "lease-extension": [{ id: "lease-extension-application", label: "Đơn đề nghị gia hạn sử dụng đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Gia hạn sử dụng đất/thuê đất", status: "needs-local-review", provenance: "metadata-only" }],
  "term-adjustment": [{ id: "term-adjustment-application", label: "Đơn đề nghị điều chỉnh thời hạn sử dụng đất", fileName: "Mẫu theo thủ tục địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Điều chỉnh thời hạn trên hồ sơ đất đai", status: "needs-local-review", provenance: "metadata-only" }],
  recovery: [{ id: "recovery-application", label: "Hồ sơ và thông báo thu hồi đất", fileName: "Bộ tài liệu theo quyết định thu hồi", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Thu hồi đất và quyết định của cơ quan có thẩm quyền", status: "needs-local-review", provenance: "metadata-only" }],
  compensation: [{ id: "compensation-application", label: "Hồ sơ bồi thường, hỗ trợ, tái định cư", fileName: "Bộ tài liệu theo phương án được duyệt", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Phương án bồi thường, hỗ trợ, tái định cư", status: "needs-local-review", provenance: "metadata-only" }],
  "map-extract": [{ id: "map-extract-request", label: "Văn bản đề nghị trích lục bản đồ địa chính", fileName: "Mẫu theo địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Cung cấp trích lục bản đồ địa chính", status: "needs-local-review", provenance: "metadata-only" }],
  survey: [{ id: "survey-request", label: "Đơn yêu cầu trích đo địa chính", fileName: "Mẫu theo đơn vị đo đạc/địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Đo đạc, lập bản trích đo", status: "needs-local-review", provenance: "metadata-only" }],
  boundary: [{ id: "boundary-request", label: "Biên bản xác định ranh giới, diện tích", fileName: "Mẫu phối hợp đo đạc", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Xác định ranh giới và diện tích thực tế", status: "needs-local-review", provenance: "metadata-only" }],
  "cadastre-update": [{ id: "cadastre-update-request", label: "Đề nghị chỉnh lý hồ sơ địa chính", fileName: "Mẫu theo địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Cập nhật biến động vào hồ sơ địa chính", status: "needs-local-review", provenance: "metadata-only" }],
  planning: [{ id: "planning-request", label: "Phiếu đề nghị cung cấp thông tin quy hoạch", fileName: "Mẫu theo địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Tra cứu quy hoạch sử dụng đất", status: "needs-local-review", provenance: "metadata-only" }],
  "land-plan": [{ id: "land-plan-request", label: "Đề nghị cung cấp thông tin kế hoạch sử dụng đất", fileName: "Mẫu theo địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Thông tin kế hoạch sử dụng đất", status: "needs-local-review", provenance: "metadata-only" }],
  "planning-status": [{ id: "planning-status-request", label: "Văn bản xác định tình trạng quy hoạch thửa đất", fileName: "Mẫu theo địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Xác định tình trạng quy hoạch", status: "needs-local-review", provenance: "metadata-only" }],
  "pit-tax": [{ id: "pit-tax-declaration", label: "Tờ khai thuế thu nhập cá nhân khi chuyển nhượng", fileName: "Mẫu do cơ quan thuế xác nhận", sourceUrl: "https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx", legalBasis: "Nghĩa vụ thuế khi chuyển nhượng", status: "needs-local-review", provenance: "metadata-only" }],
  "registration-fee": [{ id: "registration-fee-declaration", label: "Tờ khai lệ phí trước bạ nhà, đất", fileName: "Mẫu do cơ quan thuế xác nhận", sourceUrl: "https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx", legalBasis: "Nghĩa vụ lệ phí trước bạ", status: "needs-local-review", provenance: "metadata-only" }],
  "land-use-money": [{ id: "land-use-money-review", label: "Phiếu rà soát tiền sử dụng đất", fileName: "Tài liệu nghĩa vụ tài chính", sourceUrl: "https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx", legalBasis: "Tiền sử dụng đất theo trường hợp", status: "needs-local-review", provenance: "metadata-only" }],
  "land-rent": [{ id: "land-rent-review", label: "Phiếu rà soát tiền thuê đất", fileName: "Tài liệu nghĩa vụ tài chính", sourceUrl: "https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx", legalBasis: "Tiền thuê đất theo trường hợp", status: "needs-local-review", provenance: "metadata-only" }],
  "other-fees": [{ id: "other-fees-review", label: "Bảng rà soát phí, lệ phí đất đai", fileName: "Bảng tham khảo theo địa phương", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Phí, lệ phí theo thủ tục và địa phương", status: "needs-local-review", provenance: "metadata-only" }],
  "transaction-dossier": [{ id: "transaction-dossier-checklist", label: "Bộ kiểm tra giao dịch bất động sản", fileName: "Checklist hồ sơ giao dịch", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html", legalBasis: "Ghép kiểm tra pháp lý, quy hoạch, giao dịch và nghĩa vụ tài chính", status: "needs-local-review", provenance: "metadata-only" }],
};
Object.assign(LAND_DOSSIER_TEMPLATE_REGISTRY, additionalTemplateRegistry);

export type LandExportDocumentType = "bundle" | "transfer-contract" | "variation-form" | "pit-tax" | "registration-fee" | "checklist" | "gift-contract" | "inheritance-document" | "lease-contract" | "lease-variation" | "purpose-application" | "split-application" | "merge-application" | "mortgage-registration" | "correction-application" | "first-registration-application" | "land-data-request";
export type LandProcedureGuidance = { code: string; authority: string; submission: string; processingTime: string; steps: string[]; requirements: string[]; sources: Array<{ label: string; url: string }> };
const LAND_PROCEDURE_GUIDANCE: Record<string, LandProcedureGuidance> = {
  transfer: { code: "2.000889", authority: "Văn phòng đăng ký đất đai/Chi nhánh hoặc nơi tiếp nhận do UBND cấp tỉnh quy định; hộ gia đình, cá nhân có thể nộp tại UBND cấp xã nếu có nhu cầu.", submission: "Trực tiếp hoặc trên môi trường điện tử theo khả năng tiếp nhận của địa phương.", processingTime: "Không quá 10 ngày kể từ khi nhận đủ hồ sơ hợp lệ đối với chuyển nhượng; không tính thời gian thực hiện nghĩa vụ tài chính và các khoảng thời gian loại trừ theo thủ tục.", steps: ["Kiểm tra Giấy chứng nhận, thông tin các bên, tình trạng hôn nhân và điều kiện chuyển nhượng.", "Lập và ký hợp đồng/văn bản chuyển nhượng theo yêu cầu công chứng, chứng thực.", "Chuẩn bị Mẫu 09/ĐK, bản gốc Giấy chứng nhận và giấy tờ liên quan; nộp tại cơ quan tiếp nhận.", "Cơ quan đăng ký kiểm tra, gửi thông tin địa chính sang cơ quan thuế khi có nghĩa vụ tài chính.", "Nộp thuế, lệ phí theo thông báo; bổ sung bản chính theo yêu cầu và nhận kết quả sang tên."], requirements: ["Mẫu số 09/ĐK — bản chính 01 bản.", "Hợp đồng/văn bản chuyển nhượng theo quy định.", "Bản gốc Giấy chứng nhận đã cấp.", "Giấy tờ nhân thân, hôn nhân và giấy tờ bổ sung theo trường hợp cụ thể.", "Tờ khai nghĩa vụ tài chính chỉ là bản dự thảo hỗ trợ; số tiền và miễn giảm phải theo thông báo của cơ quan thuế."], sources: [{ label: "Cổng Dịch vụ công — thủ tục 2.000889", url: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889" }, { label: "Mẫu số 09/ĐK trên Cổng DVC", url: "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe4648992ad74c2" }, { label: "Nghị định 101/2024/NĐ-CP", url: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791" }] },
  variation: { code: "2.000889", authority: "Văn phòng đăng ký đất đai/Chi nhánh hoặc cơ quan tiếp nhận theo quy định địa phương.", submission: "Trực tiếp hoặc điện tử nếu địa phương đã cung cấp dịch vụ.", processingTime: "Thời hạn phụ thuộc trường hợp biến động và quy định địa phương; cần đối chiếu hồ sơ thủ tục trước khi nộp.", steps: ["Xác định đúng lý do biến động và giấy tờ làm căn cứ.", "Điền Mẫu 09/ĐK theo lý do biến động, không tự suy đoán các trường bắt buộc.", "Nộp hồ sơ, nhận phiếu tiếp nhận và bổ sung nếu cơ quan tiếp nhận thông báo thiếu.", "Thực hiện nghĩa vụ tài chính nếu phát sinh và nhận kết quả chỉnh lý/cấp giấy."], requirements: ["Mẫu số 09/ĐK.", "Bản gốc Giấy chứng nhận đã cấp.", "Giấy tờ chứng minh nội dung biến động.", "Giấy tờ nhân thân và tài liệu địa phương yêu cầu nếu có."], sources: [{ label: "Cổng Dịch vụ công — thủ tục 2.000889", url: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889" }, { label: "Nghị định 101/2024/NĐ-CP", url: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791" }] }
};
export function landDossierBuilderGuidance(procedureId: string) { return LAND_PROCEDURE_GUIDANCE[procedureId] ?? { code: landDossierBuilderOfficialSource(procedureId).procedureCode, authority: "Cơ quan tiếp nhận theo Cổng Dịch vụ công và quy định của địa phương.", submission: "Thực hiện theo phương thức được công bố tại thủ tục tương ứng.", processingTime: "Cần đối chiếu thời hạn trên trang thủ tục chính thức tại thời điểm nộp.", steps: ["Xác định đúng thủ tục và địa phương.", "Chuẩn bị giấy tờ theo thành phần hồ sơ chính thức.", "Nhập dữ liệu, đối chiếu bản gốc và xác nhận bản nháp.", "Nộp hồ sơ, thực hiện nghĩa vụ tài chính nếu có và theo dõi kết quả."], requirements: ["Biểu mẫu chính theo thủ tục.", "Giấy tờ chứng minh quyền sử dụng đất hoặc tài sản.", "Giấy tờ nhân thân và tài liệu bổ sung theo trường hợp."], sources: [{ label: "Cổng Dịch vụ công quốc gia", url: "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html" }] }; }
const steps = ["Chọn thủ tục", "Nhập giấy tờ", "AI phân tích", "Rà soát bộ hồ sơ", "Xuất để nộp"];

export function landDossierBuilderLocalSource(province: string, procedureId: string) {
  const source = landDossierBuilderOfficialSource(procedureId);
  if (!province) return { label: "Chưa chọn địa phương", status: "required" as const, detail: "Cần chọn tỉnh/thành để đối chiếu cơ quan tiếp nhận và mã thủ tục địa phương.", source };
  return { label: `Nguồn thủ tục ${province}`, status: "review" as const, detail: `Đã gắn địa phương cho thủ tục ${procedureId}; mã tham chiếu ${source.procedureCode}. Cần kiểm tra cơ quan tiếp nhận, phiên bản biểu mẫu và yêu cầu hiện hành tại ${province}.`, source };
}

export type LandDossierPipelineStatus = "idle" | "analyzing" | "needs-review" | "ready-to-review";
export type LandDossierPipelineItem = {
  id: string;
  label: string;
  category: LandDossierBundleItem["category"];
  required: boolean;
  template: LandDossierTemplate | null;
  canAutoFill: boolean;
  status: "verified-binary" | "metadata-only" | "missing-template";
  reason: string;
};

/**
 * Lập kế hoạch end-to-end nhưng không tự gắn nhãn Official khi kho chưa có binary đã xác minh.
 * Đây là lớp quyết định an toàn: UI có thể tự chọn và dựng bản nháp, còn việc tự điền mẫu gốc
 * chỉ được mở khi backend registry trả về provenance=verified-binary.
 */
export function landDossierBuilderPipelinePlan(procedureId: string, province: string): {
  status: LandDossierPipelineStatus;
  procedureId: string;
  province: string;
  selectedProcedure: string;
  source: ReturnType<typeof landDossierBuilderOfficialSource>;
  items: LandDossierPipelineItem[];
  missingLocalContext: boolean;
  autoFillEnabled: boolean;
} {
  const procedure = LAND_DOSSIER_BUILDER_PROCEDURES.find(([id]) => id === procedureId) ?? LAND_DOSSIER_BUILDER_PROCEDURES[0];
  const templates = landDossierBuilderTemplates(procedureId);
  const templateFor = (item: LandDossierBundleItem, index: number) => {
    const exact = templates.find(template => template.id === item.id || template.id.includes(item.id));
    return exact ?? templates[index] ?? templates[0] ?? null;
  };
  const items = landDossierBuilderBundle(procedureId).map((item, index) => {
    const template = item.category === "form" || item.category === "tax" ? templateFor(item, index) : null;
    const canAutoFill = template?.provenance === "verified-binary";
    return {
      ...item,
      template,
      canAutoFill,
      status: template ? (canAutoFill ? "verified-binary" : "metadata-only") : "missing-template",
      reason: canAutoFill
        ? "Mẫu binary đã xác minh; có thể tự điền sau khi dữ liệu được người dùng xác nhận."
        : template
          ? "Mới có thông tin tham chiếu; chưa được phép tự điền vào mẫu Official."
          : "Chưa có mẫu tương ứng trong kho; cần bổ sung hoặc rà soát theo địa phương.",
    } satisfies LandDossierPipelineItem;
  });
  const hasBlockingItem = items.some(item => item.required && !item.canAutoFill && item.category === "form");
  return {
    status: hasBlockingItem || !province ? "needs-review" : "ready-to-review",
    procedureId,
    province,
    selectedProcedure: procedure[1],
    source: landDossierBuilderOfficialSource(procedureId),
    items,
    missingLocalContext: !province,
    autoFillEnabled: !hasBlockingItem && Boolean(province),
  };
}

const LAND_PROCEDURE_SYNONYMS: Record<string, string[]> = {
  transfer: ["sang ten", "sang tên", "mua ban", "mua bán", "chuyen nhuong", "chuyển nhượng", "ban nha", "bán nhà"],
  "sale-house": ["sang ten", "sang tên", "mua ban nha", "mua bán nhà", "mua dat", "mua đất", "nha dat", "nhà đất"],
  lease: ["cho thue", "cho thuê", "thue dat", "thuê đất", "cho thue lai", "cho thuê lại"],
  gift: ["tang cho", "tặng cho", "cho nguoi than", "cho người thân"],
  inheritance: ["thua ke", "thừa kế", "khai nhan di san", "khai nhận di sản"],
  certificate: ["cap so", "cấp sổ", "cap giay chung nhan", "cấp giấy chứng nhận", "lam so hong", "làm sổ hồng"],
  variation: ["bien dong", "biến động", "cap nhat chu", "cập nhật chủ", "doi thong tin", "đổi thông tin"],
  purpose: ["doi muc dich", "đổi mục đích", "chuyen muc dich", "chuyển mục đích"],
  split: ["tach thua", "tách thửa", "chia thua", "chia thửa"],
  merge: ["hop thua", "hợp thửa", "gop thua", "gộp thửa"],
  mortgage: ["the chap", "thế chấp", "giai chap", "giải chấp", "xoa the chap", "xóa thế chấp"],
  correction: ["dinh chinh", "đính chính", "sua thong tin", "sửa thông tin"],
  "first-registration": ["dang ky lan dau", "đăng ký lần đầu", "cap so lan dau", "cấp sổ lần đầu"],
  "data-request": ["trich luc", "trích lục", "trich luc ban do", "trích lục bản đồ", "ban do dia chinh", "bản đồ địa chính", "cung cap du lieu", "cung cấp dữ liệu", "thong tin dat dai", "thông tin đất đai"],
};

export function landDossierBuilderFindProcedures(query: string) {
  const normalized = normalizeLandProcedureSearch(query);
  if (!normalized) return LAND_DOSSIER_BUILDER_PROCEDURES;
  return LAND_DOSSIER_BUILDER_PROCEDURES.filter(([id, title, hint]) => landProcedureMatchesSearch([id, title, hint, ...(LAND_PROCEDURE_SYNONYMS[id] ?? [])], normalized));
}

export type LandDossierInputField = { key: string; label: string; placeholder: string; required: boolean };

/** Tạo trường nhập theo thủ tục, không ép mọi hồ sơ vào form chuyển nhượng. */
export function landDossierInputFields(procedureId: string, procedureTitle: string, bundle: readonly LandDossierBundleItem[]): LandDossierInputField[] {
  const common: LandDossierInputField[] = [
    { key: "applicantName", label: "Họ tên người yêu cầu", placeholder: "Nhập họ tên theo giấy tờ", required: true },
    { key: "applicantId", label: "CCCD/Mã định danh", placeholder: "Nhập số định danh hoặc mã tổ chức", required: true },
    { key: "applicantAddress", label: "Địa chỉ liên hệ", placeholder: "Nhập địa chỉ hiện tại", required: true },
    { key: "landAddress", label: "Địa chỉ thửa đất", placeholder: "Nhập địa chỉ thửa đất", required: true },
    { key: "parcelNumber", label: "Số thửa", placeholder: "Nhập số thửa", required: false },
    { key: "mapSheet", label: "Tờ bản đồ số", placeholder: "Nhập tờ bản đồ", required: false },
    { key: "area", label: "Diện tích", placeholder: "Nhập diện tích và đơn vị m²", required: false },
    { key: "certificateNumber", label: "Số Giấy chứng nhận", placeholder: "Nhập số phát hành/số vào sổ", required: false },
  ];
  const normalized = normalizeLandProcedureSearch(`${procedureId} ${procedureTitle}`);
  const legacyTransferFields: LandDossierInputField[] = normalized.includes("chuyen nhuong") || normalized.includes("sang ten")
    ? [{ key: "sellerName", label: "Họ tên bên chuyển nhượng", placeholder: "Nhập họ tên bên chuyển nhượng", required: true }, { key: "buyerName", label: "Họ tên bên nhận chuyển nhượng", placeholder: "Nhập họ tên bên nhận", required: true }, { key: "transferPrice", label: "Giá trị chuyển nhượng", placeholder: "Nhập giá trị theo hợp đồng", required: false }]
    : [];
  const extras: LandDossierInputField[] = normalized.includes("trich luc") || normalized.includes("du lieu") || normalized.includes("ban do")
    ? [{ key: "requestedData", label: "Nội dung dữ liệu/bản đồ cần trích lục", placeholder: "Mô tả loại bản đồ hoặc dữ liệu cần cung cấp", required: true }, { key: "purposeOfRequest", label: "Mục đích yêu cầu", placeholder: "Nhập mục đích sử dụng thông tin", required: true }]
    : normalized.includes("tach thua") || normalized.includes("hop thua")
      ? [{ key: "parcelChangeReason", label: "Nội dung tách/hợp thửa", placeholder: "Mô tả các thửa và phương án dự kiến", required: true }, { key: "proposedArea", label: "Diện tích/phương án sau thay đổi", placeholder: "Nhập diện tích dự kiến", required: true }]
      : normalized.includes("quy hoach") || normalized.includes("ke hoach")
        ? [{ key: "planningQuestion", label: "Nội dung cần tra cứu quy hoạch", placeholder: "Nhập câu hỏi hoặc phạm vi cần tra cứu", required: true }]
        : normalized.includes("thue") || normalized.includes("le phi") || normalized.includes("tien su dung")
          ? [{ key: "declaredValue", label: "Giá trị/tài sản làm căn cứ", placeholder: "Nhập giá trị theo hồ sơ, nếu có", required: true }, { key: "exemptionBasis", label: "Căn cứ miễn/giảm", placeholder: "Nhập căn cứ hoặc ghi không có", required: false }]
          : [{ key: "requestDetails", label: "Nội dung và lý do thực hiện thủ tục", placeholder: "Mô tả yêu cầu cụ thể", required: true }];
  const bundleFields = bundle.filter(item => item.required).slice(0, 5).map(item => ({ key: `evidence_${item.id}`, label: `Thông tin cho: ${item.label}`, placeholder: `Nhập hoặc mô tả ${item.label.toLowerCase()}`, required: false }));
  return [...common, ...legacyTransferFields, ...extras, ...bundleFields].filter((field, index, all) => all.findIndex(item => item.key === field.key) === index);
}

export function landDossierBuilderProcedureTitles() {
  return LAND_DOSSIER_BUILDER_PROCEDURES.map(([, title]) => title);
}

export function LandDossierBuilder() {
  const { loading: authLoading, isAuthenticated } = useAuth();
  const [procedureId, setProcedureId] = useState(() => {
    const requested = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("procedure") : null;
    return requested || "variation";
  });
  const [query, setQuery] = useState("");
  const [province, setProvince] = useState("");
  const [receivingAuthorities, setReceivingAuthorities] = useState<Array<{ id: string; province: string; district?: string; ward?: string; procedureCode: string; name: string; role: "receiving" | "processing" | "one-stop"; sourceUrl: string; checkedAt: string; confidence: "high" | "medium"; requiresUserConfirmation: boolean; note: string }>>([]);
  const [authorityNotice, setAuthorityNotice] = useState("");
  const [notes, setNotes] = useState("");
  const [manualData, setManualData] = useState<LandDossierInput>(() => ({ ...EMPTY_LAND_DOSSIER_INPUT, procedureFields: {} }));
  const [files, setFiles] = useState<File[]>([]);
  type PublicMedia = { id: string; file: File; url: string; kind: "image" | "video" };
  const [publicMedia, setPublicMedia] = useState<PublicMedia[]>([]);
  const [postCaption, setPostCaption] = useState("");
  const [postChannel, setPostChannel] = useState<"website" | "facebook-personal" | "zalo-personal">("website");
  const [cameraOpen, setCameraOpen] = useState(false);
  const [recording, setRecording] = useState(false);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordingChunksRef = useRef<Blob[]>([]);
  const [analysisStarted, setAnalysisStarted] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<{ warnings: string[]; missingComponents: string[]; legalNotes: string[]; verifiedTemplateCount: number } | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [ocrFields, setOcrFields] = useState<LandDossierOcrField[]>([]);
  const [ocrWarnings, setOcrWarnings] = useState<string[]>([]);
  const [bundleTimedOut, setBundleTimedOut] = useState(false);
  const [authorityTimedOut, setAuthorityTimedOut] = useState(false);
  const [previewDocument, setPreviewDocument] = useState<{ type: string; label: string } | null>(null);
  const [readyDownload, setReadyDownload] = useState<{ url: string; fileName: string } | null>(null);
  const [isGeneratingDownload, setIsGeneratingDownload] = useState(false);
  const [downloadError, setDownloadError] = useState("");
  const [pipelineStatus, setPipelineStatus] = useState<LandDossierPipelineStatus>("idle");
  const [pipelineStarted, setPipelineStarted] = useState(false);
  const legalQueriesEnabled = Boolean(!authLoading && isAuthenticated);
  const dynamicProcedureCatalog = trpc.legalKnowledge.procedures.useQuery({}, { enabled: legalQueriesEnabled, staleTime: 5 * 60_000, gcTime: 15 * 60_000, refetchOnWindowFocus: false, retry: 1 });
  const ocr = trpc.landDossierBuilder.ocr.useMutation();
  const analyzeDossier = trpc.aiAutoDossier.analyzeDossier.useMutation();
  const exportBundle = trpc.landDossierBuilder.exportBundle.useMutation();
  const findBinaryCandidates = trpc.legalKnowledge.findBinaryCandidates.useMutation();
  const autoDiscoverBinaryCandidates = trpc.legalKnowledge.autoDiscoverBinaryCandidates.useMutation();
  const autoDiscoverDvcBinaryCandidates = trpc.legalKnowledge.autoDiscoverDvcBinaryCandidates.useMutation();
  const receivingAuthorityInput = useMemo(() => ({ province, procedureId }), [province, procedureId]);
  // Đây là nguồn phụ có thể chậm; không để chặn bundle pháp lý chuẩn.
  const discoverReceivingAuthorities = trpc.legalKnowledge.discoverReceivingAuthorities.useQuery(receivingAuthorityInput, { enabled: false, staleTime: 5 * 60_000, gcTime: 15 * 60_000, refetchOnWindowFocus: false, retry: 0 });
  const downloadBinaryCandidate = trpc.legalKnowledge.downloadBinaryCandidate.useMutation();
  const approveBinaryCandidate = trpc.legalKnowledge.approveBinaryCandidate.useMutation();
  const createDossier = trpc.landDossiers.create.useMutation();
  const updateDossier = trpc.landDossiers.update.useMutation();
  const [savedDossierId, setSavedDossierId] = useState<number | null>(null);
  const [saveMessage, setSaveMessage] = useState("");
  const [selectedDbTemplateId, setSelectedDbTemplateId] = useState<number | null>(null);
  const [binarySourceUrl, setBinarySourceUrl] = useState("");
  const [binaryKeywords, setBinaryKeywords] = useState("");
  const [binaryCandidates, setBinaryCandidates] = useState<Array<{ url: string; fileName: string; format: "docx" | "doc" | "pdf"; score: number }>>([]);
  const [dvcDossierComponents, setDvcDossierComponents] = useState<Array<{ id: string; name: string; required: boolean; evidence: string }>>([]);
  const [dvcAttachments, setDvcAttachments] = useState<Array<{ id: string; name: string; url: string; kind: string; status: string; evidence: string }>>([]);
  const [binaryTargetTemplateId, setBinaryTargetTemplateId] = useState<number | null>(null);
  const [binaryNotice, setBinaryNotice] = useState("");

  useEffect(() => () => {
    if (readyDownload?.url) URL.revokeObjectURL(readyDownload.url);
  }, [readyDownload?.url]);

  const dynamicProcedureOptions = useMemo(() => (dynamicProcedureCatalog.data || []).map(row => [row.code, row.name, row.groupName] as [string, string, string]), [dynamicProcedureCatalog.data]);
  const selected = dynamicProcedureOptions.find(([id]) => id === procedureId) ?? LAND_DOSSIER_BUILDER_PROCEDURES.find(([id]) => id === procedureId) ?? (/^\d(?:\.\d)+$/.test(procedureId) ? [procedureId, `Đang nạp thủ tục ${procedureId}`, "Catalog động"] as [string, string, string] : LAND_DOSSIER_BUILDER_PROCEDURES[0]);
  const procedureSync = useMemo(() => landDossierProcedureSyncSnapshot(procedureId, province), [procedureId, province]);
  const workflowStage = landDossierWorkflowState({ procedureId, province, hasInput: Object.values(manualData).some(value => typeof value === "string" && value.trim().length > 0) || Object.values(manualData.procedureFields).some(value => value.trim().length > 0), hasOcr: ocrFields.length > 0, confirmed });
  const workflowSteps = [
    ["select-procedure", "1. Chọn thủ tục"],
    ["select-province", "2. Chọn tỉnh/thành"],
    ["input-documents", "3. Nhập hoặc chụp/tải giấy tờ"],
    ["ai-review", "4. AI đọc và rà soát"],
    ["confirmed", "5. Xem trước và xác nhận"],
  ] as const;
  useEffect(() => {
    setReceivingAuthorities([]);
    setAuthorityNotice("");
    setAuthorityTimedOut(false);
  }, [province, procedureId]);
  useEffect(() => {
    if (!discoverReceivingAuthorities.isFetching) {
      setAuthorityTimedOut(false);
      return;
    }
    const timer = window.setTimeout(() => {
      setAuthorityTimedOut(true);
      setAuthorityNotice("Chưa nhận diện được cơ quan tiếp nhận từ nguồn phụ; bạn vẫn có thể tiếp tục với bundle pháp lý chuẩn và xác nhận nơi nộp sau.");
    }, 10000);
    return () => window.clearTimeout(timer);
  }, [discoverReceivingAuthorities.isFetching, province, procedureId]);
  useEffect(() => {
    if (discoverReceivingAuthorities.data) {
      setReceivingAuthorities(discoverReceivingAuthorities.data.items);
      setAuthorityNotice(discoverReceivingAuthorities.data.notice);
    }
    if (discoverReceivingAuthorities.error) {
      setAuthorityNotice("Chưa tự nhận diện được cơ quan tiếp nhận: " + discoverReceivingAuthorities.error.message);
    }
  }, [discoverReceivingAuthorities.data, discoverReceivingAuthorities.error]);
  const officialProcedureSource = useMemo(() => landDossierBuilderOfficialSource(procedureId), [procedureId]);
  // Catalog động trả về mã canonical dạng số (ví dụ 2.002317). Không được
  // đưa mã đó qua mapping legacy, vì mapping cũ chỉ phục vụ các key như
  // "variation" và sẽ rơi về N/A, làm bundle persisted bị bỏ qua.
  const officialProcedureCode = useMemo(() => /^\d(?:\.\d)+$/.test(procedureId) ? procedureId : officialProcedureSource.procedureCode, [officialProcedureSource.procedureCode, procedureId]);
  const legalBundleQuery = trpc.legalKnowledge.bundle.useQuery({ code: officialProcedureCode }, { enabled: Boolean(procedureId && legalQueriesEnabled), staleTime: 2 * 60_000, gcTime: 10 * 60_000, refetchOnWindowFocus: false, refetchOnReconnect: true, retry: 2, retryDelay: attempt => Math.min(1000 * 2 ** attempt, 4000) });
  useEffect(() => {
    if (!legalBundleQuery.isLoading) {
      setBundleTimedOut(false);
      return;
    }
    const timer = window.setTimeout(() => setBundleTimedOut(true), 12000);
    return () => window.clearTimeout(timer);
  }, [legalBundleQuery.isLoading, officialProcedureCode]);
  const legalTemplatesQuery = trpc.legalKnowledge.templates.useQuery({ province: province || undefined, procedureCode: officialProcedureCode }, { enabled: Boolean(procedureId && legalQueriesEnabled), staleTime: 2 * 60_000, gcTime: 10 * 60_000, refetchOnWindowFocus: false, refetchOnReconnect: true, retry: 2, retryDelay: attempt => Math.min(1000 * 2 ** attempt, 4000) });
  const dbTemplates = useMemo(() => legalTemplatesQuery.data || [], [legalTemplatesQuery.data]);
  const dbVerifiedTemplates = useMemo(() => dbTemplates.filter(item => (item.template.provenance === "verified_binary" || item.template.provenance === "official") && Boolean(item.template.storageKey || item.template.fileUrl) && ["docx", "pdf"].includes(item.template.format)), [dbTemplates]);
  const officialStatusInput = useMemo(() => ({ code: officialProcedureCode, province: province || undefined }), [officialProcedureCode, province]);
  const officialStatusQuery = trpc.legalKnowledge.officialStatus.useQuery(officialStatusInput, { enabled: Boolean(procedureId && legalQueriesEnabled && legalBundleQuery.isSuccess), staleTime: 2 * 60_000, gcTime: 10 * 60_000, refetchOnWindowFocus: false, retry: 1 });
  useEffect(() => {
    if (!legalBundleQuery.isSuccess || !province || !procedureId) return;
    void discoverReceivingAuthorities.refetch();
  }, [legalBundleQuery.isSuccess, province, procedureId, discoverReceivingAuthorities.refetch]);
  const officialLegalSources = useMemo(() => landDossierBuilderGuidance(procedureId).sources.filter(source => /vanban\.chinhphu\.vn|quochoi\.vn|moj\.gov\.vn|mae\.gov\.vn|monre\.gov\.vn/i.test(source.url)), [procedureId]);
  const hasOfficialProcedureUrl = Boolean(officialStatusQuery.data?.procedure.verified || (officialProcedureSource.sourceUrl && officialProcedureSource.status === "verified-reference"));
  const hasOfficialLegalDocument = Boolean(officialStatusQuery.data?.legalDocuments.verified || officialLegalSources.length > 0);
  const hasOfficialTemplateFile = Boolean(officialStatusQuery.data?.templateFile.verified || dbVerifiedTemplates.length > 0);
  const officialProcedureUrl = officialStatusQuery.data?.procedure.sourceUrl || officialProcedureSource.sourceUrl;
  const officialLegalDocumentItems = officialStatusQuery.data?.legalDocuments.items || [];
  const officialTemplateCount = officialStatusQuery.data?.templateFile.count ?? dbVerifiedTemplates.length;
  const selectedDbTemplate = dbVerifiedTemplates.find(item => item.template.id === selectedDbTemplateId) || null;
  const pipelinePlan = useMemo(() => landDossierBuilderPipelinePlan(procedureId, province), [procedureId, province]);
  // Không dùng data cũ của React Query khi người dùng vừa đổi thủ tục.
  // Bundle chỉ hợp lệ nếu mã trả về khớp mã canonical đang được chọn.
  const backendBundle = legalBundleQuery.data?.procedure?.code === officialProcedureCode
    ? legalBundleQuery.data
    : undefined;
  const bundleStatusLabel = landBundleStatusLabel({
    isLoading: legalBundleQuery.isLoading,
    timedOut: bundleTimedOut,
    hasError: Boolean(legalBundleQuery.error),
    hasData: Boolean(backendBundle),
    hasMetadata: Boolean(backendBundle || dbTemplates.length > 0 || dvcDossierComponents.length > 0 || dvcAttachments.length > 0),
    hasOfficialBinary: dbVerifiedTemplates.length > 0 || Boolean(officialStatusQuery.data?.templateFile.verified),
  });
  const selectedTemplates = useMemo(() => {
    // Mục Nộp cho cơ quan phải ưu tiên mẫu đã lọc theo tỉnh/thẩm quyền,
    // sau đó mới dùng mẫu trong bundle chung của đúng mã thủ tục.
    if (legalTemplatesQuery.isSuccess && dbTemplates.length) return dbTemplates.map(({ template }) => ({
      id: String(template.id),
      label: template.name,
      fileName: template.name,
      sourceUrl: template.sourceUrl,
      legalBasis: `${template.documentType} · ${template.format.toUpperCase()}${template.checksum ? ` · SHA-256 ${template.checksum}` : ""}`,
      status: template.provenance === "verified_binary" || template.provenance === "official" ? "verified-reference" as const : "needs-local-review" as const,
      provenance: template.provenance === "verified_binary" || template.provenance === "official" ? "verified-binary" as const : "metadata-only" as const,
      checksum: template.checksum || undefined,
      fileUrl: template.fileUrl || undefined,
    }));
    if (backendBundle?.templates?.length) return backendBundle.templates.map(template => ({
      id: String(template.id),
      label: template.name,
      fileName: template.name,
      sourceUrl: template.sourceUrl,
      legalBasis: `${template.documentType} · ${template.format.toUpperCase()}${template.checksum ? ` · SHA-256 ${template.checksum}` : ""}`,
      status: template.provenance === "verified_binary" || template.provenance === "official" ? "verified-reference" as const : "needs-local-review" as const,
      provenance: template.provenance === "verified_binary" || template.provenance === "official" ? "verified-binary" as const : "metadata-only" as const,
      checksum: template.checksum || undefined,
      fileUrl: template.fileUrl || undefined,
    }));
    return procedureSync.templates;
  }, [backendBundle?.templates, dbTemplates, legalTemplatesQuery.isSuccess, procedureSync.templates]);
  const selectedBundle = useMemo(() => {
    if (backendBundle?.requirements?.length) return backendBundle.requirements.map(requirement => ({
      id: String(requirement.id),
      label: requirement.label,
      required: Boolean(requirement.required),
      category: requirement.requirementType === "fee" ? "tax" as const : requirement.requirementType === "document" ? "form" as const : "supporting" as const,
      condition: requirement.notes || undefined,
      fieldKey: requirement.fieldKey || undefined,
    }));
    return procedureSync.bundle;
  }, [backendBundle?.requirements, procedureSync.bundle]);
  const procedureInputFields = useMemo(() => landDossierInputFields(procedureId, selected[1], selectedBundle), [procedureId, selected, selectedBundle]);
  const nextProcedureRecommendations = useMemo(() => landDossierNextProcedureRecommendations(procedureId).map(item => ({ ...item, title: landDossierRecommendationTitle(item.procedureId), hint: landDossierRecommendationHint(item.procedureId), documents: landDossierRecommendationDocuments(item.procedureId) })), [procedureId]);
  const localSource = landDossierBuilderLocalSource(province, procedureId);
  const bundleDocuments = backendBundle?.documents || [];
  const bundleSourceUrl = bundleDocuments.find(document => /^https:\/\//i.test(document.sourceUrl))?.sourceUrl;
  const legalSourceAudit = useMemo(() => auditLandDossierLegalSources({
    province,
    sourceUrl: pipelinePlan.source.sourceUrl ?? localSource.source.sourceUrl,
    sourceCheckedAt: pipelinePlan.source.lastCheckedAt,
    templateProvenance: selectedTemplates.some(item => item.provenance === "verified-binary") ? "verified-binary" : "metadata-only",
    requiredTemplateCount: selectedBundle.filter(item => item.required && (item.category === "form" || item.category === "tax")).length,
    verifiedTemplateCount: selectedTemplates.filter(item => item.provenance === "verified-binary").length,
  }), [localSource.source.sourceUrl, pipelinePlan.source.sourceUrl, pipelinePlan.source.lastCheckedAt, province, selectedBundle, selectedTemplates]);
  const exportDocuments = useMemo(() => {
    const byProcedure: Record<string, Array<[LandExportDocumentType, string]>> = {
      transfer: [["transfer-contract", "Hợp đồng chuyển nhượng quyền sử dụng đất"], ["variation-form", "Mẫu 09/ĐK — Đơn đăng ký biến động/sang tên"], ["pit-tax", "Tờ khai thuế thu nhập cá nhân"], ["registration-fee", "Tờ khai lệ phí trước bạ"], ["checklist", "Checklist hồ sơ chuyển nhượng"]],
      "sale-house": [["transfer-contract", "Hợp đồng mua bán nhà, đất"], ["variation-form", "Mẫu 09/ĐK — Đơn đăng ký biến động/sang tên"], ["pit-tax", "Tờ khai thuế thu nhập cá nhân"], ["registration-fee", "Tờ khai lệ phí trước bạ"], ["checklist", "Checklist hồ sơ mua bán nhà đất"]],
      gift: [["gift-contract", "Hợp đồng/văn bản tặng cho"], ["variation-form", "Đơn đăng ký biến động do tặng cho"], ["pit-tax", "Tờ khai thuế và giấy tờ miễn giảm"], ["registration-fee", "Tờ khai lệ phí trước bạ và giấy tờ miễn giảm"], ["checklist", "Checklist hồ sơ tặng cho"]],
      inheritance: [["inheritance-document", "Văn bản thừa kế/khai nhận di sản"], ["variation-form", "Đơn đăng ký biến động do thừa kế"], ["pit-tax", "Tờ khai thuế và giấy tờ miễn giảm"], ["registration-fee", "Tờ khai lệ phí trước bạ và giấy tờ miễn giảm"], ["checklist", "Checklist hồ sơ thừa kế"]],
      lease: [["lease-contract", "Hợp đồng cho thuê/cho thuê lại đất"], ["lease-variation", "Đơn đăng ký biến động do cho thuê đất"], ["pit-tax", "Tờ khai nghĩa vụ thuế cho thuê đất"], ["registration-fee", "Tờ khai lệ phí/phí liên quan"], ["checklist", "Checklist hồ sơ cho thuê đất"]],
      purpose: [["purpose-application", "Đơn xin chuyển mục đích sử dụng đất"], ["registration-fee", "Tờ khai nghĩa vụ tài chính dự kiến"], ["checklist", "Checklist hồ sơ chuyển mục đích"]],
      split: [["split-application", "Đơn đề nghị tách thửa"], ["checklist", "Checklist hồ sơ tách thửa"]],
      merge: [["merge-application", "Đơn đề nghị hợp thửa"], ["checklist", "Checklist hồ sơ hợp thửa"]],
      mortgage: [["mortgage-registration", "Đơn đăng ký/xóa đăng ký thế chấp"], ["checklist", "Checklist hồ sơ thế chấp"]],
      correction: [["correction-application", "Đơn đề nghị đính chính/cập nhật thông tin"], ["checklist", "Checklist hồ sơ đính chính"]],
      certificate: [["first-registration-application", "Đơn đăng ký đất đai, cấp Giấy chứng nhận lần đầu"], ["registration-fee", "Tờ khai lệ phí trước bạ/nghĩa vụ tài chính"], ["checklist", "Checklist hồ sơ cấp Giấy chứng nhận"]],
      "first-registration": [["first-registration-application", "Đơn đăng ký đất đai, cấp Giấy chứng nhận lần đầu"], ["registration-fee", "Tờ khai lệ phí trước bạ/nghĩa vụ tài chính"], ["checklist", "Checklist hồ sơ đăng ký lần đầu"]],
      variation: [["variation-form", "Đơn đăng ký biến động đất đai"], ["checklist", "Checklist hồ sơ đăng ký biến động"]],
      "data-request": [["land-data-request", "Văn bản đề nghị cung cấp thông tin đất đai"], ["checklist", "Checklist hồ sơ xin dữ liệu đất đai"]],
    };
    return byProcedure[procedureId] ?? [["variation-form", "Biểu mẫu chính theo thủ tục"], ["checklist", "Checklist giấy tờ cần chuẩn bị và nộp"]];
  }, [procedureId]);
  const filtered = useMemo(() => {
    const normalized = normalizeLandProcedureSearch(query);
    if (!dynamicProcedureOptions.length) return landDossierBuilderFindProcedures(query);
    if (!normalized) return dynamicProcedureOptions;
    const isMapExtractRequest = normalized.includes("trich luc") && (normalized.includes("ban do") || normalized.includes("dia chinh") || normalized.includes("thong tin"));
    const matches = dynamicProcedureOptions.filter(([id, name, groupName]) => {
      const values = [id, name, groupName];
      if (landProcedureMatchesSearch(values, normalized)) return true;
      if (isMapExtractRequest) {
        const haystack = values.map(normalizeLandProcedureSearch).join(" ");
        return haystack.includes("cung cap") || haystack.includes("du lieu") || haystack.includes("trich luc") || haystack.includes("thong tin dat dai");
      }
      return false;
    });
    return matches.length > 0 ? matches : landDossierBuilderFindProcedures(query);
  }, [dynamicProcedureOptions, query]);
  const filteredProcedureIds = useMemo(() => new Set(filtered.map(([id]) => id)), [filtered]);
  const visibleProcedureGroups = useMemo(() => {
    if (dynamicProcedureOptions.length) {
      const groups = new Map<string, Array<readonly [string, string, string]>>();
      for (const option of filtered) { const group = option[2] || "Thủ tục đất đai"; groups.set(group, [...(groups.get(group) || []), option]); }
      return Array.from(groups, ([id, procedures]) => ({ id, label: id, description: "Catalog động từ nguồn pháp lý đã đăng ký", procedures }));
    }
    return LAND_PROCEDURE_TREE.map(group => ({
      ...group,
      procedures: group.procedureIds.map(id => LAND_DOSSIER_BUILDER_PROCEDURES.find(item => item[0] === id)).filter((item): item is (typeof LAND_DOSSIER_BUILDER_PROCEDURES)[number] => Boolean(item)).filter(item => filteredProcedureIds.has(item[0])),
    })).filter(group => group.procedures.length > 0);
  }, [dynamicProcedureOptions, filtered, filteredProcedureIds]);

  useEffect(() => {
    // Đổi thủ tục là một phiên hồ sơ mới: xóa kết quả OCR, mẫu đã chọn,
    // binary ứng viên và file đã tạo để không trộn hồ sơ chuyển nhượng với hợp thửa.
    resetDraft();
    setSavedDossierId(null);
    setSaveMessage("");
    setPreviewDocument(null);
    setReadyDownload(previous => { if (previous?.url) URL.revokeObjectURL(previous.url); return null; });
    setDownloadError("");
    setSelectedDbTemplateId(null);
    setBinarySourceUrl("");
    setBinaryKeywords("");
    setBinaryCandidates([]);
    setBinaryTargetTemplateId(null);
    setBinaryNotice(`Đã chuyển sang thủ tục “${selected[1]}”. AI đang nạp lại căn cứ pháp lý, checklist và mẫu phù hợp.`);
  }, [procedureId]);

  useEffect(() => {
    // Đổi tỉnh/cơ quan làm mới phạm vi mẫu Official nhưng giữ dữ liệu hồ sơ đang nhập.
    setSelectedDbTemplateId(null);
    setBinaryCandidates([]);
    setBinaryTargetTemplateId(null);
    setBinaryNotice(province ? `Đã đổi địa phương sang ${province}. Mẫu Official sẽ được lọc lại theo địa phương này.` : "");
  }, [province]);

  useEffect(() => () => {
    cameraStreamRef.current?.getTracks().forEach(track => track.stop());
    publicMedia.forEach(item => URL.revokeObjectURL(item.url));
  }, []);
  function selectProcedure(id: string) {
    if (!id || id === procedureId) return;
    setProcedureId(id);
    setQuery("");
    window.setTimeout(() => document.getElementById("dossier-select-province")?.scrollIntoView({ behavior: "smooth", block: "start" }), 0);
  }

  function resetDraft() {
    publicMedia.forEach(item => URL.revokeObjectURL(item.url));
    setPublicMedia([]);
    setPostCaption("");
    setCameraOpen(false);
    setRecording(false);
    cameraStreamRef.current?.getTracks().forEach(track => track.stop());
    cameraStreamRef.current = null;
    setAnalysisStarted(false);
    setAnalysisResult(null);
    setPipelineStarted(false);
    setPipelineStatus("idle");
    setConfirmed(false);
    setFiles([]);
    setOcrFields([]);
    setOcrWarnings([]);
  }

  function handlePublicMedia(event: React.ChangeEvent<HTMLInputElement>) {
    const selectedFiles = Array.from(event.target.files ?? []).filter(file => file.type.startsWith("image/") || file.type.startsWith("video/"));
    if (selectedFiles.length) {
      setPublicMedia(current => [...current, ...selectedFiles.map(file => ({ id: `${file.name}-${file.lastModified}-${Math.random()}`, file, url: URL.createObjectURL(file), kind: file.type.startsWith("video/") ? "video" as const : "image" as const }))]);
      setConfirmed(false);
    }
    event.target.value = "";
  }
  function removePublicMedia(id: string) {
    setPublicMedia(current => {
      const item = current.find(media => media.id === id);
      if (item) URL.revokeObjectURL(item.url);
      return current.filter(media => media.id !== id);
    });
  }
  async function openCamera() {
    if (!navigator.mediaDevices?.getUserMedia) return;
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: true });
    cameraStreamRef.current?.getTracks().forEach(track => track.stop());
    cameraStreamRef.current = stream;
    setCameraOpen(true);
    requestAnimationFrame(() => {
      if (cameraVideoRef.current) {
        cameraVideoRef.current.srcObject = stream;
        void cameraVideoRef.current.play();
      }
    });
  }
  function closeCamera() {
    cameraStreamRef.current?.getTracks().forEach(track => track.stop());
    cameraStreamRef.current = null;
    setCameraOpen(false);
    setRecording(false);
  }
  function capturePhoto() {
    const video = cameraVideoRef.current;
    if (!video || video.videoWidth === 0) return;
    const canvas = document.createElement("canvas");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d")?.drawImage(video, 0, 0);
    canvas.toBlob(blob => {
      if (!blob) return;
      const file = new File([blob], `ho-so-${Date.now()}.jpg`, { type: "image/jpeg" });
      setPublicMedia(current => [...current, { id: `${file.name}-${file.lastModified}`, file, url: URL.createObjectURL(file), kind: "image" }]);
      setConfirmed(false);
    }, "image/jpeg", 0.92);
  }
  function toggleRecording() {
    if (recording) {
      recorderRef.current?.stop();
      setRecording(false);
      return;
    }
    const stream = cameraStreamRef.current;
    if (!stream || typeof MediaRecorder === "undefined") return;
    recordingChunksRef.current = [];
    const mimeType = MediaRecorder.isTypeSupported("video/webm") ? "video/webm" : undefined;
    const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    recorder.ondataavailable = event => { if (event.data.size) recordingChunksRef.current.push(event.data); };
    recorder.onstop = () => {
      const file = new File(recordingChunksRef.current, `ho-so-video-${Date.now()}.webm`, { type: "video/webm" });
      setPublicMedia(current => [...current, { id: `${file.name}-${file.lastModified}`, file, url: URL.createObjectURL(file), kind: "video" }]);
      setConfirmed(false);
    };
    recorderRef.current = recorder;
    recorder.start();
    setRecording(true);
  }
  async function openPersonalComposer() {
    const details = buildPublicPostText(manualData, postCaption);
    if (navigator.clipboard) await navigator.clipboard.writeText(details);
    const target = postChannel === "facebook-personal" ? `https://www.facebook.com/sharer/sharer.php?quote=${encodeURIComponent(details)}` : "https://zalo.me/";
    window.open(target, "_blank", "noopener,noreferrer");
  }
  function handleFiles(event: React.ChangeEvent<HTMLInputElement>) {
    const selectedFiles = Array.from(event.target.files ?? []);
    if (selectedFiles.length) {
      setFiles(current => [...current, ...selectedFiles]);
      setConfirmed(false);
      setPipelineStarted(false);
      setPipelineStatus("idle");
      setAnalysisStarted(false);
      setOcrFields([]);
    }
  }

  async function fileToBase64(file: File) {
    const buffer = await file.arrayBuffer();
    let binary = "";
    const bytes = new Uint8Array(buffer);
    for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]);
    return btoa(binary);
  }

  async function runAnalysis() {
    setConfirmed(false);
    setPipelineStarted(true);
    setPipelineStatus("analyzing");
    if (!province) {
      setPipelineStatus("needs-review");
      return;
    }
    const file = files.find(item => ["application/pdf", "image/jpeg", "image/png", "image/webp"].includes(item.type));
    let fields: LandDossierOcrField[] = [];
    let warnings: string[] = [];
    if (!file) {
      fields = procedureInputFields.filter(field => (manualData.procedureFields[field.key] || "").trim()).map(field => ({ key: field.key, label: field.label, value: manualData.procedureFields[field.key].trim(), confidence: 1, evidence: "Người dùng nhập trực tiếp", confirmed: false }));
      warnings = procedureInputFields.filter(field => field.required && !(manualData.procedureFields[field.key] || "").trim()).map(field => `Chưa nhập: ${field.label}`);
    } else {
      const result = await ocr.mutateAsync({ procedureId, province, fileName: file.name, mimeType: file.type as "image/jpeg" | "image/png" | "image/webp" | "application/pdf", data: await fileToBase64(file) });
      fields = (result.fields || []).map((field: LandDossierOcrField) => ({ ...field, confirmed: false }));
      warnings = result.warnings || [];
    }
    setOcrFields(fields);
    setOcrWarnings(warnings);
    const profile: Record<string, string> = {};
    Object.entries(manualData).forEach(([key, value]) => {
      if (key !== "procedureFields" && typeof value === "string" && value.trim()) profile[key] = value;
    });
    Object.entries(manualData.procedureFields).forEach(([key, value]) => {
      if (value.trim()) profile[key] = value;
    });
    const analysis = await analyzeDossier.mutateAsync({
      procedureCode: procedureId,
      province,
      profile,
      ocrFields: fields.map(field => ({ key: field.key, label: field.label, value: field.value, evidence: field.evidence, confidence: field.confidence })),
      dossierComponents: selectedBundle.map(item => ({ id: item.id, name: item.label, required: item.required, evidence: item.condition || "Bundle legalKnowledge" })),
    });
    const aiFields = (analysis.fields || []).map((field: { key: string; label: string; value: string; confidence: number; source: string; evidence: string }) => ({ key: field.key, label: field.label, value: field.value, confidence: field.confidence, evidence: `${field.source}: ${field.evidence}`, confirmed: false }));
    const merged = [...fields, ...aiFields.filter((field: { key: string; label: string }) => !fields.some(existing => existing.key === field.key || existing.label === field.label))];
    setOcrFields(merged);
    setOcrWarnings([...warnings, ...(analysis.warnings || []), ...(analysis.missingComponents || []).map((item: string) => `Thiếu thành phần: ${item}`)]);
    setAnalysisResult({ warnings: analysis.warnings || [], missingComponents: analysis.missingComponents || [], legalNotes: analysis.legalNotes || [], verifiedTemplateCount: analysis.verifiedTemplateCount || 0 });
    setAnalysisStarted(true);
    setPipelineStatus(pipelinePlan.status);
  }

  async function runEndToEndPipeline() {
    setPipelineStarted(true);
    setPipelineStatus("analyzing");
    setConfirmed(false);
    try {
      await runAnalysis();
    } catch (error) {
      setPipelineStatus("needs-review");
      throw error;
    }
  }

  async function saveElectronicDossier() {
    if (!province) {
      setSaveMessage("Hãy chọn tỉnh/thành phố trước khi lưu hồ sơ.");
      return;
    }
    setSaveMessage("");
    const stepLabels = [
      "Chọn địa phương và xác định thủ tục",
      "Đối chiếu căn cứ pháp lý và nguồn chính thức",
      "Thông tin người sử dụng đất và các bên giao dịch",
      "Thông tin thửa đất, Giấy chứng nhận và tài sản",
      "Thông tin giao dịch và nghĩa vụ tài chính",
      "Tải giấy tờ và đối chiếu OCR",
      "Kiểm tra đủ/thiếu và tính nhất quán",
      "Xác định thành phần hồ sơ có căn cứ",
      "Chọn biểu mẫu và rà soát trường bắt buộc",
      "Tạo bản DOCX/PDF sau khi xác nhận",
      "In, tải và lưu phiên bản hồ sơ",
      "Kiểm tra lại với cơ quan tiếp nhận trước khi nộp",
    ];
    const checklist = (stepNumber: number) => {
      const status: "completed" | "verify" | "missing" = stepNumber === 1 && province && procedureId ? "completed" : stepNumber <= 6 && pipelineStarted ? "verify" : "missing";
      return [{ label: stepLabels[stepNumber - 1], status, note: status === "completed" ? "Đã chọn trong Builder." : "Cần đối chiếu trước khi hoàn tất." }];
    };
    const steps = stepLabels.map((title, index) => ({
      stepNumber: index + 1,
      title,
      checklist: checklist(index + 1),
      relatedTemplates: selectedBundle.slice(0, 4).map(item => item.label),
    }));
    const answers: Record<string, string> = {
      province,
      procedureId,
      procedureTitle: selected[1],
      manualData: JSON.stringify(manualData),
      ocrFields: JSON.stringify(ocrFields),
      uploadedFiles: JSON.stringify(files.map(file => ({ name: file.name, type: file.type, size: file.size }))),
      legalSourceAudit: JSON.stringify(legalSourceAudit),
      confirmed: String(confirmed),
    };
    try {
      if (savedDossierId) {
        await updateDossier.mutateAsync({ id: savedDossierId, currentStep: confirmed ? 11 : pipelineStarted ? 7 : 1, status: confirmed ? "in_progress" : "draft", answers, notes: notes || undefined });
        setSaveMessage(`Đã cập nhật hồ sơ điện tử V${confirmed ? 2 : 1} · #${savedDossierId}.`);
      } else {
        const result = await createDossier.mutateAsync({ procedureType: procedureId, title: selected[1], answers, steps });
        setSavedDossierId(result.id);
        setSaveMessage(`Đã lưu hồ sơ điện tử #${result.id}. Bạn có thể tiếp tục chỉnh sửa và cập nhật phiên bản.`);
      }
    } catch (error) {
      console.error("[LandDossierBuilder] save dossier failed", error);
      setSaveMessage("Chưa lưu được hồ sơ. Vui lòng đăng nhập và thử lại.");
    }
  }

  function printConfirmedDossier() {
    if (!confirmed || !legalSourceAudit.canExportDraftOrPrint) {
      setDownloadError(legalSourceAuditSummary(legalSourceAudit));
      return;
    }
    window.print();
  }

  function verifiedTemplateForDocument(documentType: LandExportDocumentType) {
    if (!selectedDbTemplate) return undefined;
    if (documentType === "bundle") return selectedDbTemplate;
    const key = `${documentType} ${selectedDbTemplate.template.name} ${selectedDbTemplate.template.documentType}`.toLowerCase();
    const matches = legalTemplatesQuery.data?.filter(item => item.template.status === "active" && Boolean(item.template.storageKey || item.template.fileUrl)).filter(item => {
      const text = `${item.template.name} ${item.template.documentType} ${item.template.format}`.toLowerCase();
      const aliases: Record<string, string[]> = {
        "registration-form": ["09/đk", "09-dk", "đăng ký biến động", "biến động"],
        "tax-declaration": ["thuế", "tncn", "thu nhập cá nhân"],
        "registration-fee": ["trước bạ", "lệ phí trước bạ"],
        "application": ["đơn", "tờ khai", "phiếu"],
      };
      return (aliases[documentType] ?? [documentType]).some(alias => text.includes(alias));
    });
    return matches?.[0] ?? (key.includes(documentType) ? selectedDbTemplate : undefined);
  }

  async function createExportBlob(format: "docx" | "pdf", documentType: LandExportDocumentType = "bundle", documentLabel?: string) {
    if (!confirmed || !ocrFields.length) return null;
    if (!legalSourceAudit.canExportDraftOrPrint) throw new Error(legalSourceAuditSummary(legalSourceAudit));
    const verifiedTemplate = verifiedTemplateForDocument(documentType);
    if (selectedDbTemplate && documentType !== "bundle" && !verifiedTemplate) throw new Error(`Chưa có binary đã xác minh phù hợp cho tài liệu ${documentLabel ?? documentType}. Không thể ghép bộ hồ sơ Official.`);
    const template = selectedTemplates.find(item => item.id.includes(documentType) || item.fileName.toLowerCase().includes(documentType.replace(/-/g, " "))) ?? selectedTemplates[0];
    const guidance = landDossierBuilderGuidance(procedureId);
    const source = template?.sourceUrl ?? guidance.sources[0]?.url ?? "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html";
    const result = await exportBundle.mutateAsync({ procedureTitle: selected[1], province, fields: ocrFields.map(field => ({ label: field.label, value: field.value, confirmed: field.confirmed })), format, documentType, documentLabel, templateName: verifiedTemplate ? `${verifiedTemplate.template.name} — mẫu DB đã xác minh` : template ? `${template.fileName} — ${template.label}` : `Mẫu tham chiếu cho ${selected[1]}`, templateSource: verifiedTemplate?.template.sourceUrl || source, sourceCheckedAt: verifiedTemplate?.template.updatedAt ? new Date(verifiedTemplate.template.updatedAt).toLocaleDateString("vi-VN") : new Date().toLocaleDateString("vi-VN"), templateProvenance: verifiedTemplate ? "verified-binary" : template?.provenance ?? "metadata-only", templateId: verifiedTemplate?.template.id });
    const binary = Uint8Array.from(atob(result.data), character => character.charCodeAt(0));
    return { blob: new Blob([binary], { type: result.mimeType }), fileName: result.fileName };
  }

  function prepareDownload(blob: Blob, fileName: string) {
    const url = URL.createObjectURL(blob);
    setReadyDownload(previous => {
      if (previous?.url) URL.revokeObjectURL(previous.url);
      return { url, fileName };
    });
    // Thử tải ngay trên desktop; trên Chrome mobile, liên kết hiển thị bên dưới
    // sẽ cho phép người dùng bấm trực tiếp sau khi máy chủ tạo xong file.
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    link.rel = "noopener";
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  async function downloadExport(format: "docx" | "pdf", documentType: LandExportDocumentType = "bundle", documentLabel?: string) {
    if (isGeneratingDownload) return;
    setIsGeneratingDownload(true); setDownloadError("");
    try {
      const result = await createExportBlob(format, documentType, documentLabel);
      if (result) prepareDownload(result.blob, result.fileName);
    } catch (error) {
      console.error("[LandDossierBuilder] export failed", error);
      setDownloadError("Không tạo được file. Vui lòng kiểm tra lại dữ liệu và thử lại.");
    } finally { setIsGeneratingDownload(false); }
  }

  async function downloadAllZip() {
    if (!confirmed || !ocrFields.length || isGeneratingDownload) return;
    setIsGeneratingDownload(true); setDownloadError("");
    try {
      const zip = new JSZip();
      const manifest: Array<{ documentType: string; label: string; format: string; fileName: string; status: string; template: string }> = [];
      for (const [type, label] of exportDocuments) {
        const docx = await createExportBlob("docx", type, label);
        if (docx) { zip.file(`documents/${docx.fileName}`, docx.blob); manifest.push({ documentType: type, label, format: "docx", fileName: `documents/${docx.fileName}`, status: selectedDbTemplate ? "official-verified-binary" : "confirmed-draft", template: verifiedTemplateForDocument(type)?.template.name ?? "" }); }
        const pdf = await createExportBlob("pdf", type, label);
        if (pdf) { zip.file(`documents/${pdf.fileName}`, pdf.blob); manifest.push({ documentType: type, label, format: "pdf", fileName: `documents/${pdf.fileName}`, status: selectedDbTemplate ? "official-verified-binary" : "confirmed-draft", template: verifiedTemplateForDocument(type)?.template.name ?? "" }); }
      }
      zip.file("metadata/manifest.json", JSON.stringify({ procedureId, procedureTitle: selected[1], province, generatedAt: new Date().toISOString(), dossierStatus: selectedDbTemplate ? "official-verified-binary" : "confirmed-draft", documents: manifest }, null, 2));
      zip.file("metadata/legal-traceability.json", JSON.stringify({ audit: legalSourceAudit, sources: LAND_DOSSIER_OFFICIAL_SOURCES, selectedTemplate: selectedDbTemplate?.template ?? null, note: "Đối chiếu nguồn pháp lý và mẫu gốc trước khi ký, in và nộp cho cơ quan tiếp nhận." }, null, 2));
      const zipBlob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
      prepareDownload(zipBlob, `bo-ho-so-${procedureId}-${Date.now()}.zip`);
    } catch (error) {
      console.error("[LandDossierBuilder] zip export failed", error);
      setDownloadError("Không tạo được file ZIP. Vui lòng thử lại với mạng ổn định.");
    } finally { setIsGeneratingDownload(false); }
  }

  return (
    <DashboardLayout>
      <main className="min-h-screen bg-[#F6F8F4] px-3 py-4 text-[#18352D] sm:px-5 lg:px-7">
        <div className="mx-auto max-w-[1440px]">
          <header className="rounded-2xl bg-[#163D34] px-4 py-5 text-white shadow-sm sm:px-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.22em] text-[#D6B65B]">Phân hệ độc lập · không liên quan CRM</p>
                <h1 className="mt-2 text-2xl font-black tracking-tight sm:text-3xl">AI trợ lý lập hồ sơ và thủ tục đất đai</h1>
                <p className="mt-2 max-w-3xl text-sm leading-6 text-[#DCEAE1]">Mô tả nhu cầu hoặc chọn thủ tục. AI tự tìm nhóm thủ tục liên quan, hỏi dữ liệu cần thiết, dựng bộ hồ sơ tham khảo, checklist và hướng dẫn để bạn kiểm tra, in, ký rồi nộp.</p>
              </div>
              <div className="flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold text-[#F4E6B8]"><LockKeyhole className="h-4 w-4" />Chỉ xuất sau khi xác nhận</div>
            </div>
          </header>

          <section className="mt-4 rounded-2xl border border-[#D8E4DC] bg-white p-3 shadow-sm sm:p-4" data-testid="dossier-workflow-steps" aria-label="Quy trình lập hồ sơ">
            <div className="flex flex-wrap items-center gap-2">
              {workflowSteps.map(([id, label], index) => <div key={id} className={`flex min-h-10 items-center gap-2 rounded-full px-3 py-2 text-[11px] font-black ${workflowStage === id ? "bg-[#1F5A4A] text-white" : workflowSteps.findIndex(([stepId]) => stepId === workflowStage) > index ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#F3F8F4] text-[#71847A]"}`}><span>{label}</span>{index < workflowSteps.length - 1 && <span aria-hidden="true">→</span>}</div>)}
            </div>
            <p className="mt-2 text-xs leading-5 text-[#63776D]">Bạn có thể nhập tay hoặc chụp/tải ảnh trong bước 3. AI chỉ tạo bản nháp; hãy đối chiếu giấy tờ gốc trước khi xác nhận và in.</p>
          </section>

          <div className="mt-4">
            <LegalSourceRegistryPanel procedureId={procedureId} title="Nguồn pháp lý dùng chung cho hồ sơ đất đai" />
          </div>

          <div className="mt-4 grid gap-4 xl:grid-cols-[minmax(0,1.05fr)_minmax(380px,.95fr)]">
            <section className="rounded-2xl border border-[#D8E4DC] bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-3"><div><p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">Bước 1</p><h2 className="mt-1 text-xl font-black">Nêu nhu cầu hoặc chọn thủ tục</h2></div><ClipboardCheck className="h-6 w-6 text-[#1F5A4A]" /></div>
              <div className="relative mt-4"><Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-[#71847A]" /><Input value={query} onChange={event => setQuery(event.target.value)} className="pl-9" placeholder="Ví dụ: sang tên khi mua bán nhà, cho thuê đất, tách thửa… AI sẽ tìm thủ tục liên quan" aria-label="Tìm thủ tục đất đai" /></div>
              <p className="mt-3 rounded-xl bg-[#F3F8F4] px-3 py-2 text-xs leading-5 text-[#1F5A4A]">AI tìm theo mô tả và từ đồng nghĩa. Ví dụ “sang tên khi mua nhà” sẽ gợi ý nhóm mua bán nhà đất, chuyển nhượng, đăng ký biến động, thuế và lệ phí.</p>              <div className="mt-3 space-y-3">
                {visibleProcedureGroups.map(group => <details key={group.id} open={Boolean(query) || group.procedures.some(item => item[0] === procedureId)} className="rounded-xl border border-[#E2EBE4] bg-[#FBFDFC] p-3">
                  <summary className="cursor-pointer list-none"><div className="flex items-start gap-2"><ChevronRight className="mt-0.5 h-4 w-4 shrink-0 text-[#1F5A4A]" /><div><p className="text-sm font-black text-[#18352D]">{group.label}</p><p className="mt-1 text-xs leading-5 text-[#6B7D74]">{group.description}</p></div><span className="ml-auto shrink-0 rounded-full bg-[#EAF3EC] px-2 py-1 text-[10px] font-black text-[#1F5A4A]">{group.procedures.length}</span></div></summary>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">{group.procedures.map(([id, title, hint]) => <button key={id} type="button" onClick={() => selectProcedure(id)} aria-label={`Chọn thủ tục ${title}`} aria-pressed={procedureId === id} data-testid={`procedure-option-${id}`} className={`min-h-11 w-full rounded-xl border p-3 text-left transition touch-manipulation ${procedureId === id ? "border-[#1F5A4A] bg-[#EAF3EC] ring-1 ring-[#1F5A4A]" : "border-[#E2EBE4] bg-white hover:border-[#A8C8B2]"}`}><div className="flex items-start justify-between gap-2"><span className="text-sm font-black">{title}</span><span className="flex shrink-0 items-center gap-1 text-[10px] font-black text-[#1F5A4A]">{procedureId === id ? <><CheckCircle2 className="h-4 w-4" />Đã chọn</> : "Chọn"}</span></div><p className="mt-1 text-xs leading-5 text-[#6B7D74]">{hint}</p></button>)}</div>
                </details>)}
                {!visibleProcedureGroups.length && <div className="rounded-xl border border-dashed border-[#C9D8D0] p-4 text-center text-xs text-[#60766D]">Chưa tìm thấy thủ tục phù hợp. Hãy mô tả thêm nhu cầu, ví dụ: “xin trích lục bản đồ”, “cấp lại sổ bị mất” hoặc “gia hạn thuê đất”.</div>}
              </div>
              <div id="dossier-select-province" className="mt-4 grid gap-3 scroll-mt-4 sm:grid-cols-2"><label className="text-xs font-bold text-[#52675D]">Tỉnh/thành phố áp dụng<select value={province} onChange={event => { setProvince(event.target.value); setConfirmed(false); }} className="mt-1 h-10 w-full rounded-md border border-input bg-background px-3 text-sm font-normal text-foreground" aria-label="Chọn tỉnh thành phố"><option value="">Chọn tỉnh/thành phố</option>{PROVINCE_OPTIONS.map(item => <option key={item} value={item}>{item}</option>)}</select></label><div className={`rounded-xl p-3 text-xs leading-5 ${localSource.status === "required" ? "bg-[#FFF9EA] text-[#6F5520]" : "bg-[#F3F8F4] text-[#1F5A4A]"}`}><strong>{localSource.label}:</strong> {localSource.detail}<span className="mt-1 block font-black">{localSource.status === "required" ? "Chưa đủ dữ liệu để lập hồ sơ địa phương" : `Nguồn: ${localSource.source.sourceName} · kiểm tra ${localSource.source.lastCheckedAt} · ${localSource.source.status === "verified-reference" ? "đã xác minh trang tham chiếu" : "cần rà soát"}`}</span></div></div>
              <div className="mt-3 rounded-xl border border-[#D8E4DC] bg-[#FBFDFC] p-3" data-testid="receiving-authorities-panel"><div className="flex items-center justify-between gap-2"><p className="text-xs font-black uppercase tracking-wide text-[#1F5A4A]">Cơ quan tiếp nhận AI nhận diện</p>{discoverReceivingAuthorities.isFetching && !authorityTimedOut && <Loader2 className="h-4 w-4 animate-spin text-[#1F5A4A]" />}</div><p className="mt-1 text-[11px] leading-5 text-[#63776D]">Đối chiếu theo tỉnh/thành và thủ tục đã chọn. Bạn cần xác nhận lại nơi nộp hồ sơ theo thông tin công bố tại thời điểm nộp.</p>{discoverReceivingAuthorities.data?.checkedAt && <p className="mt-1 text-[10px] text-[#71847A]">Đã quét nguồn lúc {new Date(discoverReceivingAuthorities.data.checkedAt).toLocaleString("vi-VN")} · <a href={discoverReceivingAuthorities.data.sourceUrl} target="_blank" rel="noreferrer" className="font-semibold underline">Mở trang DVC</a></p>}{discoverReceivingAuthorities.data?.scan?.warnings?.map(warning => <p key={warning} className="mt-1 rounded-md bg-[#FFF4F0] p-2 text-[10px] leading-4 text-[#8B4C39]">{warning}</p>)}{authorityNotice && <p className="mt-2 rounded-lg bg-[#FFF9EA] p-2 text-[11px] leading-5 text-[#6F5520]">{authorityNotice}</p>}{receivingAuthorities.length > 0 && <div className="mt-2 space-y-2">{receivingAuthorities.map((authority, index) => <a key={`${authority.name}-${index}`} href={authority.sourceUrl} target="_blank" rel="noreferrer" className="block rounded-lg border border-[#D8E4DC] bg-white p-2"><div className="flex items-start justify-between gap-2"><div><p className="text-xs font-black text-[#18352D]">{authority.name}</p><p className="mt-1 text-[11px] text-[#71847A]">{authority.role === "receiving" ? "Cơ quan tiếp nhận/xử lý" : authority.role === "processing" ? "Cơ quan xử lý" : "Nơi tiếp nhận hồ sơ"}{authority.district || authority.ward ? ` · ${[authority.ward, authority.district].filter(Boolean).join(", ")}` : ""}</p></div><span className="shrink-0 rounded-full bg-[#EAF3EC] px-2 py-1 text-[10px] font-black text-[#1F5A4A]">{authority.confidence === "high" ? "Độ tin cậy cao" : "Cần xác nhận địa phương"}</span></div>{authority.note && <p className="mt-1 text-[10px] leading-4 text-[#7A6A42]">{authority.note}</p>}<p className="mt-1 truncate text-[10px] text-[#71847A]">Nguồn Cổng DVC</p></a>)}</div>}{!discoverReceivingAuthorities.isFetching && !receivingAuthorities.length && !authorityNotice && <p className="mt-2 rounded-lg bg-[#F3F8F4] p-2 text-[11px] leading-5 text-[#52675D]">Chưa có dữ liệu cơ quan tiếp nhận từ nguồn phụ. Bạn vẫn có thể tiếp tục; bundle chuẩn đã lấy theo mã thủ tục và tỉnh.</p>}</div>
            </section>
            <section className="rounded-2xl border border-[#D8E4DC] bg-white p-4 shadow-sm sm:p-5"><p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">Bộ nguồn chuẩn tự động từ Kho AI pháp lý</p><h2 className="mt-1 text-xl font-black">{selected[1]}</h2><p className="mt-2 text-sm leading-6 text-[#63776D]">AI sẽ tự ghép các thủ tục liên quan, bộ giấy tờ, nghĩa vụ tài chính và hướng dẫn thực hiện. Đây là hồ sơ tham khảo để bạn kiểm tra, chỉnh sửa, in, ký và nộp; không phải văn bản Official của cơ quan nhà nước.</p><div className="mt-3 rounded-xl border border-[#B8D2C1] bg-[#F3F8F4] p-3" data-testid="legal-bundle-audit"><div className="flex flex-wrap items-center justify-between gap-2"><p className="text-xs font-black uppercase tracking-wide text-[#1F5A4A]">Nguồn bundle pháp lý chuẩn</p><span className="rounded-full bg-white px-2 py-1 text-[10px] font-black text-[#1F5A4A]">{bundleStatusLabel}</span></div><p className="mt-2 text-[11px] leading-5 text-[#52675D]">{selectedBundle.length} thành phần hồ sơ · {selectedTemplates.length} mẫu/metadata · {dbVerifiedTemplates.length} binary Official có thể đối chiếu. AI sẽ dùng requirements, templates, documents và dữ liệu người dùng trong cùng một lần phân tích.</p>{bundleSourceUrl && <a href={bundleSourceUrl} target="_blank" rel="noreferrer" className="mt-2 block break-all text-[10px] font-semibold text-[#1F5A4A] underline">Mở URL nguồn pháp lý: {bundleSourceUrl}</a>}</div><div className="mt-4 space-y-2">{selectedTemplates.map(template => <a key={template.id} href={template.sourceUrl} target="_blank" rel="noreferrer" className="block rounded-xl border border-[#D8E4DC] bg-[#FBFDFC] p-3 hover:border-[#A8C8B2]"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-black text-[#1F5A4A]">{template.fileName} · {template.label}</p><p className="mt-1 text-[11px] leading-5 text-[#71847A]">{template.legalBasis}</p></div><span className="shrink-0 rounded-full bg-[#FFF9EA] px-2 py-1 text-[10px] font-black text-[#7A6A42]">{template.provenance === "verified-binary" ? "Official · binary đã xác minh" : template.status === "verified-reference" ? "Reference · nguồn đã xác minh" : "Pending · cần rà soát"}</span></div></a>)}</div><div className="mt-4 rounded-xl border-2 border-[#1F5A4A] bg-[#F3F8F4] p-3" data-testid="next-procedure-recommendations"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Bước tiếp theo AI đề xuất</p><p className="mt-1 text-[11px] leading-5 text-[#52675D]">Dựa trên thủ tục đang chọn, AI gợi ý các bước liên quan để bạn kiểm tra. Mỗi đề xuất có căn cứ và mẫu riêng; không tự coi là kết luận pháp lý.</p></div><Sparkles className="h-5 w-5 text-[#1F5A4A]" /></div><div className="mt-3 space-y-2">{nextProcedureRecommendations.map(recommendation => <div key={recommendation.procedureId} className="rounded-xl bg-white p-3"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-sm font-black text-[#18352D]">{recommendation.title}</p><p className="mt-1 text-xs leading-5 text-[#52675D]">{recommendation.reason}</p></div><span className={`rounded-full px-2 py-1 text-[10px] font-black ${recommendation.confidence === "Cao" ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#7A6A42]"}`}>Phù hợp: {recommendation.confidence}</span></div><p className="mt-2 text-[11px] text-[#71847A]">{recommendation.hint}</p><div className="mt-2 flex flex-wrap gap-2">{recommendation.documents.map(document => <a key={document.fileName} href={document.url} target="_blank" rel="noreferrer" className="rounded-md bg-[#F7FAF7] px-2 py-1 text-[10px] font-bold text-[#1F5A4A] underline underline-offset-2">Tải/đối chiếu {document.fileName} · {document.status}</a>)}{recommendation.legalSources.map(source => <a key={source.url} href={source.url} target="_blank" rel="noreferrer" className="rounded-md bg-[#F7FAF7] px-2 py-1 text-[10px] font-bold text-[#1F5A4A] underline underline-offset-2">Căn cứ: {source.label}</a>)}</div><Button type="button" variant="outline" className="mt-3" onClick={() => { setProcedureId(recommendation.procedureId); setQuery(recommendation.title); setConfirmed(false); }}>Mở hồ sơ thủ tục này <ChevronRight className="ml-1 h-3.5 w-3.5" /></Button></div>)}</div></div><div className="mt-4 rounded-xl border-2 border-[#1F5A4A] bg-[#F7FAF7] p-3"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Mẫu gốc theo tỉnh/cơ quan</p><p className="mt-1 text-[11px] leading-5 text-[#52675D]">Chỉ mẫu có binary DOCX/PDF và trạng thái Đã xác minh mới được chọn để xuất. Nếu chưa có, Builder giữ mẫu tham chiếu và không giả mạo Official.</p></div><span className="rounded-full bg-white px-2 py-1 text-[10px] font-black text-[#1F5A4A]">{officialStatusQuery.isLoading || legalTemplatesQuery.isLoading ? "Đang tải" : `${officialTemplateCount} file mẫu Official đã xác minh`}</span></div><div className="mt-3 grid gap-2" data-testid="official-source-statuses"><div className={`rounded-lg p-3 text-xs ${hasOfficialProcedureUrl ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#6F5520]"}`}><p className="font-black">{hasOfficialProcedureUrl ? "🟢" : "🟡"} Nguồn thủ tục đã xác minh</p>{hasOfficialProcedureUrl ? <a href={officialProcedureUrl} target="_blank" rel="noreferrer" className="mt-1 block break-all underline underline-offset-2">{officialProcedureUrl}</a> : <p className="mt-1">Chưa có URL thủ tục chính thức phù hợp.</p>}</div><div className={`rounded-lg p-3 text-xs ${hasOfficialLegalDocument ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#6F5520]"}`}><p className="font-black">{hasOfficialLegalDocument ? "🟢" : "🟡"} Văn bản pháp lý đã xác minh</p>{hasOfficialLegalDocument ? <div className="mt-1 space-y-1">{officialLegalDocumentItems.length > 0 ? officialLegalDocumentItems.map(source => <a key={source.sourceUrl} href={source.sourceUrl} target="_blank" rel="noreferrer" className="block break-all underline underline-offset-2">{source.title}</a>) : officialLegalSources.map(source => <a key={source.url} href={source.url} target="_blank" rel="noreferrer" className="block break-all underline underline-offset-2">{source.label}</a>)}</div> : <p className="mt-1">Chưa tìm thấy URL văn bản pháp lý chính thức trong registry.</p>}</div><div className={`rounded-lg p-3 text-xs ${hasOfficialTemplateFile ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#6F5520]"}`}><p className="font-black">{hasOfficialTemplateFile ? "🟢" : "🟡"} File mẫu Official DOCX/PDF</p><p className="mt-1">{hasOfficialTemplateFile ? `${officialTemplateCount} file đã xác minh checksum và khả năng điền.` : "Chưa tìm thấy file mẫu Official đã xác minh; hồ sơ tham khảo vẫn hoạt động."}</p>{!hasOfficialTemplateFile && <Button type="button" className="mt-2 w-fit bg-[#1F5A4A] text-white hover:bg-[#174638]" disabled={autoDiscoverDvcBinaryCandidates.isPending || autoDiscoverBinaryCandidates.isPending} onClick={() => { autoDiscoverBinaryCandidates.mutate({ procedureId, province: province || undefined, receivingAuthority: landDossierBuilderGuidance(procedureId).authority }, { onSuccess: data => { setBinarySourceUrl(data.procedure.sourceUrl); setBinaryCandidates(data.candidates); setBinaryNotice(`${data.notice} AI đã tự sàng lọc theo thủ tục ${data.procedure.name}.`); }, onError: error => setBinaryNotice("Không thể tự tìm file mẫu Official: " + error.message) }); }}>🤖 AI tìm file mẫu Official</Button>}</div></div>{dbVerifiedTemplates.length > 0 ? <div className="mt-3 space-y-2">{dbVerifiedTemplates.map(item => <label key={item.template.id} className="flex cursor-pointer items-start gap-3 rounded-lg bg-white p-3 text-xs"><input type="radio" name="verified-db-template" checked={selectedDbTemplateId === item.template.id} onChange={() => setSelectedDbTemplateId(item.template.id)} className="mt-0.5 h-4 w-4 accent-[#1F5A4A]"/><span className="min-w-0"><span className="block font-black text-[#18352D]">{item.template.name}</span><span className="mt-1 block text-[10px] leading-4 text-[#60766D]">{item.template.format.toUpperCase()} · {item.template.province || province} · {item.template.receivingAuthority || "Cơ quan chưa ghi nhận"}{item.template.versionLabel ? ` · ${item.template.versionLabel}` : ""}</span></span><span className="ml-auto shrink-0 rounded-full bg-[#EAF3EC] px-2 py-1 text-[10px] font-black text-[#1F5A4A]">Đã xác minh</span></label>)}</div> : <p className="mt-3 rounded-lg bg-[#FFF9EA] p-3 text-[11px] leading-5 text-[#6F5520]">Chưa tìm thấy file mẫu Official đã xác minh phù hợp. Bạn vẫn có thể xem nguồn thủ tục và văn bản pháp lý ở trên; chỉ chức năng xuất mẫu cơ quan mới cần binary đã xác minh.</p>}</div><div className="mt-4 grid gap-2 sm:grid-cols-2">{["Cổng Dịch vụ công · thủ tục tương ứng", "Luật Đất đai 2024 · căn cứ chung", "Nghị định và văn bản hướng dẫn", "Mẫu đơn, tờ khai, bản vẽ liên quan", localSource.label].map(source => <div key={source} className="flex items-start gap-2 rounded-xl bg-[#F3F8F4] p-3 text-xs font-bold text-[#1F5A4A]"><FileCheck2 className="mt-0.5 h-4 w-4 shrink-0" />{source}</div>)}</div><div className="mt-4 rounded-xl border border-[#D8E4DC] bg-[#F7FAF7] p-3"><div className="flex items-center justify-between gap-2"><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Bộ hồ sơ AI sẽ gom</p><span className="rounded-full bg-white px-2 py-1 text-[10px] font-black text-[#1F5A4A]">{selectedBundle.length} nhóm giấy tờ</span></div><div className="mt-2 grid gap-2 sm:grid-cols-2">{selectedBundle.map(item => <div key={item.id} className="rounded-lg bg-white p-2.5 text-xs"><div className="flex items-start gap-2"><CheckCircle2 className={`mt-0.5 h-4 w-4 shrink-0 ${item.required ? "text-[#1F5A4A]" : "text-[#B38321]"}`} /><div><p className="font-bold text-[#18352D]">{item.label}</p><p className="mt-0.5 text-[10px] text-[#71847A]">{item.required ? "Cần có" : "Theo điều kiện"}{item.condition ? ` · ${item.condition}` : ""}</p></div></div></div>)}</div><p className="mt-2 text-[11px] leading-5 text-[#6F5520]">Thuế thu nhập cá nhân và lệ phí trước bạ chỉ được đưa vào bộ hồ sơ khi xác định có phát sinh hoặc cần chứng minh miễn/giảm.</p></div><p className="mt-4 text-xs leading-5 text-[#7A6A42]">Nguồn được hiển thị để kiểm tra trước khi in. AI không thay thế xác nhận của cơ quan tiếp nhận.</p><div className="mt-4 rounded-xl border-2 border-[#1F5A4A] bg-[#F7FAF7] p-3" data-testid="legal-source-audit"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Kiểm toán nguồn pháp lý</p><p className="mt-1 text-xs leading-5 text-[#52675D]">AI chỉ cho phép xuất/in khi đã kiểm tra địa phương, URL, ngày rà soát, độ mới nguồn và mẫu binary.</p></div><span className={`rounded-full px-2 py-1 text-[10px] font-black ${legalSourceAudit.canExportOrPrint ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#7A6A42]"}`}>{legalSourceAudit.canExportOrPrint ? "Đủ điều kiện xuất/in" : legalSourceAudit.canReview ? "Đã đối chiếu · chờ mẫu gốc" : "Chưa đủ căn cứ"}</span></div><div className="mt-3 grid gap-2 sm:grid-cols-2">{legalSourceAudit.checks.map(check => <div key={check.id} className={`rounded-lg p-2.5 text-xs ${check.passed ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#6F5520]"}`}><div className="flex items-start gap-2"><span className="font-black">{check.passed ? "✓" : "!"}</span><div><p className="font-bold">{check.label}</p><p className="mt-0.5 leading-5">{check.detail}</p></div></div></div>)}</div><p className="mt-3 text-[11px] leading-5 text-[#6F5520]">{legalSourceAuditSummary(legalSourceAudit)}</p></div><div className="mt-4 rounded-xl border-2 border-dashed border-[#B38321] bg-[#FFF9EA] p-3" data-testid="official-binary-candidates"><div className="flex flex-wrap items-start justify-between gap-2"><div><p className="text-xs font-black uppercase tracking-wide text-[#7A6A42]">Binary mẫu gốc cần xác minh</p><p className="mt-1 text-[11px] leading-5 text-[#6F5520]">AI tự tìm và tải ứng viên DOCX/PDF từ nguồn nhà nước được phép. Tệp chỉ nằm ở trạng thái chờ rà soát, chưa phải Official.</p></div><span className="rounded-full bg-white px-2 py-1 text-[10px] font-black text-[#7A6A42]">Cần duyệt</span></div><div className="mt-3 grid gap-2"><input value={binarySourceUrl} onChange={event => setBinarySourceUrl(event.target.value)} placeholder="URL trang thủ tục chính thức (.gov.vn)" className="min-h-10 rounded-lg border border-[#D8C98E] bg-white px-3 text-xs text-[#18352D]"/><input value={binaryKeywords} onChange={event => setBinaryKeywords(event.target.value)} placeholder="Từ khóa: 09/ĐK, đăng ký biến động, đơn" className="min-h-10 rounded-lg border border-[#D8C98E] bg-white px-3 text-xs text-[#18352D]"/><select value={binaryTargetTemplateId ?? ""} onChange={event => setBinaryTargetTemplateId(event.target.value ? Number(event.target.value) : null)} className="min-h-10 rounded-lg border border-[#D8C98E] bg-white px-3 text-xs text-[#18352D]"><option value="">Chọn mẫu đích trong kho</option>{(legalTemplatesQuery.data || []).map(item => <option key={item.template.id} value={item.template.id}>{item.template.name} · {item.template.status}</option>)}</select><div className="flex flex-wrap gap-2"><Button type="button" className="w-fit bg-[#1F5A4A] text-white hover:bg-[#174638]" disabled={autoDiscoverDvcBinaryCandidates.isPending} onClick={() => { autoDiscoverDvcBinaryCandidates.mutate({ procedureId, province: province || undefined, receivingAuthority: landDossierBuilderGuidance(procedureId).authority }, { onSuccess: data => { setBinarySourceUrl(data.sources[0]?.sourceUrl || ""); setBinaryCandidates(data.candidates); setDvcDossierComponents(data.dossierComponents || []); setDvcAttachments(data.attachments || []); setBinaryNotice(data.notice); }, onError: error => setBinaryNotice("Không thể quét Cổng Dịch vụ công: " + error.message) }); }}>{autoDiscoverDvcBinaryCandidates.isPending ? "AI đang quét DVC…" : "AI quét Cổng DVC theo tỉnh"}</Button><Button type="button" variant="outline" className="w-fit" disabled={autoDiscoverBinaryCandidates.isPending} onClick={() => { autoDiscoverBinaryCandidates.mutate({ procedureId, province: province || undefined, receivingAuthority: landDossierBuilderGuidance(procedureId).authority }, { onSuccess: data => { setBinarySourceUrl(data.procedure.sourceUrl); setBinaryCandidates(data.candidates); setBinaryNotice(`${data.notice} AI đã tự sàng lọc theo thủ tục ${data.procedure.name}.`); }, onError: error => setBinaryNotice("Không thể tự quét mẫu theo thủ tục: " + error.message) }); }}>{autoDiscoverBinaryCandidates.isPending ? "AI đang quét nguồn…" : "Quét nguồn trong registry"}</Button><Button type="button" className="w-fit bg-[#7A6A42] text-white hover:bg-[#624F31]" disabled={!binarySourceUrl || findBinaryCandidates.isPending} onClick={() => { const keywords = landDossierBinarySearchKeywords(procedureId, binaryKeywords); findBinaryCandidates.mutate({ sourceUrl: binarySourceUrl, keywords }, { onSuccess: data => { setBinaryCandidates(data.candidates); setBinaryNotice(`${data.notice} Từ khóa: ${keywords.join(", ")}`); }, onError: error => setBinaryNotice("Không thể tìm mẫu gốc: " + error.message) }); }}>{findBinaryCandidates.isPending ? "Đang tìm binary…" : "Tìm lại từ URL"}</Button></div></div>{binaryNotice && <p className="mt-2 rounded-lg bg-white p-2 text-[11px] leading-5 text-[#6F5520]">{binaryNotice}</p>}{(dvcDossierComponents.length > 0 || dvcAttachments.length > 0) && <div className="mt-3 grid gap-3 md:grid-cols-2"><div className="rounded-lg bg-white p-3"><p className="text-[11px] font-black uppercase tracking-wide text-[#1F5A4A]">Thành phần hồ sơ trích từ Hướng dẫn DVC</p><div className="mt-2 space-y-1.5">{dvcDossierComponents.map((item, index) => <p key={item.id} className="text-xs leading-5 text-[#52675D]"><span className="font-black text-[#1F5A4A]">{index + 1}. </span>{item.name}{item.required ? "" : " · tùy trường hợp"}</p>)}</div></div><div className="rounded-lg bg-white p-3"><p className="text-[11px] font-black uppercase tracking-wide text-[#B38321]">File phát hiện · Pending xác minh</p><div className="mt-2 space-y-2">{dvcAttachments.map(item => <div key={item.id} className="border-b border-[#E7EFE8] pb-2 last:border-0"><p className="text-xs font-bold text-[#18352D]">{item.name}</p><p className="mt-1 break-all text-[10px] text-[#71847A]">{item.url}</p><span className="mt-1 inline-block rounded-full bg-[#FFF4D8] px-2 py-1 text-[10px] font-black text-[#8B671B]">{item.kind.toUpperCase()} · {item.status === "pending" ? "Chưa xác minh" : item.status}</span></div>)}</div></div></div>}{binaryCandidates.length > 0 && <div className="mt-3 space-y-2">{binaryCandidates.map(candidate => <div key={candidate.url} className="rounded-lg bg-white p-3 text-xs"><div className="flex flex-wrap items-start justify-between gap-2"><div className="min-w-0"><p className="truncate font-black text-[#18352D]">{candidate.fileName}</p><p className="mt-1 break-all text-[10px] text-[#71847A]">{candidate.url}</p></div><span className="rounded-full bg-[#EAF3EC] px-2 py-1 text-[10px] font-black text-[#1F5A4A]">{candidate.format.toUpperCase()} · điểm {candidate.score}</span></div><div className="mt-2 flex flex-wrap gap-2"><Button type="button" variant="outline" disabled={!binaryTargetTemplateId || downloadBinaryCandidate.isPending} onClick={() => binaryTargetTemplateId && downloadBinaryCandidate.mutate({ templateId: binaryTargetTemplateId, candidateUrl: candidate.url, sourceUrl: binarySourceUrl, fileName: candidate.fileName, province: province || undefined, receivingAuthority: landDossierBuilderGuidance(procedureId).authority }, { onSuccess: data => setBinaryNotice(data.notice), onError: error => setBinaryNotice(error.message) })}>{downloadBinaryCandidate.isPending ? "Đang tải…" : "Tải vào khu chờ xác minh"}</Button><Button type="button" className="bg-[#1F5A4A] text-white hover:bg-[#164637]" disabled={!binaryTargetTemplateId || approveBinaryCandidate.isPending} onClick={() => binaryTargetTemplateId && approveBinaryCandidate.mutate({ templateId: binaryTargetTemplateId, notes: `Đối chiếu thủ công file ${candidate.fileName} từ ${candidate.url}` }, { onSuccess: data => setBinaryNotice(`Đã gắn Verified Binary. Checksum: ${data.checksum}`), onError: error => setBinaryNotice(`Chưa thể gắn Official: ${error.message}`) })}>{approveBinaryCandidate.isPending ? "Đang kiểm tra…" : "Kiểm tra & gắn Official"}</Button></div></div>)}</div>}</div><div className="mt-4 rounded-xl border border-[#BCD0C1] bg-[#F7FAF7] p-3"><div className="flex flex-wrap items-center justify-between gap-2"><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Hướng dẫn theo nguồn chính thức</p><span className="rounded-full bg-white px-2 py-1 text-[10px] font-black text-[#1F5A4A]">Mã {landDossierBuilderGuidance(procedureId).code}</span></div><p className="mt-2 text-xs leading-5 text-[#52675D]"><strong>Cơ quan:</strong> {landDossierBuilderGuidance(procedureId).authority}</p><p className="mt-1 text-xs leading-5 text-[#52675D]"><strong>Cách nộp:</strong> {landDossierBuilderGuidance(procedureId).submission}</p><p className="mt-1 text-xs leading-5 text-[#52675D]"><strong>Thời hạn tham chiếu:</strong> {landDossierBuilderGuidance(procedureId).processingTime}</p><div className="mt-3 grid gap-2 sm:grid-cols-2">{landDossierBuilderGuidance(procedureId).steps.map((item, index) => <div key={item} className="rounded-lg bg-white p-2.5 text-xs"><span className="font-black text-[#1F5A4A]">{index + 1}. </span>{item}</div>)}</div><div className="mt-3"><p className="text-[11px] font-black uppercase tracking-wide text-[#1F5A4A]">Thành phần cần đối chiếu</p><div className="mt-2 space-y-1">{landDossierBuilderGuidance(procedureId).requirements.map(item => <p key={item} className="text-xs leading-5 text-[#52675D]">• {item}</p>)}</div></div><div className="mt-3 flex flex-wrap gap-2">{landDossierBuilderGuidance(procedureId).sources.map(source => <a key={source.url} href={source.url} target="_blank" rel="noreferrer" className="text-[11px] font-bold text-[#1F5A4A] underline underline-offset-2">{source.label}</a>)}</div></div></section>
          </div>

                        <section className="mt-4 rounded-2xl border border-[#D8E4DC] bg-white p-4 shadow-sm sm:p-5"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">Bước 2</p><h2 className="mt-1 text-xl font-black">Nhập thông tin hồ sơ hoặc tải giấy tờ</h2><p className="mt-1 text-xs text-[#71847A]">Bạn có thể lập hồ sơ chỉ bằng cách nhập dữ liệu; tải file là tùy chọn để OCR đối chiếu. AI sẽ dùng các trường chung và ghi nhận câu hỏi bổ sung theo thủ tục đã chọn.</p></div><label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-[#BCD0C1] px-4 py-2 text-sm font-bold text-[#1F5A4A] hover:bg-[#F1F7F2]"><UploadCloud className="h-4 w-4" />Tải ảnh/PDF<input type="file" multiple accept="image/*,.pdf,.doc,.docx" className="hidden" onChange={handleFiles} /></label></div>              <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{procedureInputFields.map(field => <label key={field.key} className="text-xs font-bold text-[#52675D]">{field.label}{field.required && <span className="ml-1 text-[#A33A3A]">*</span>}<Input value={manualData.procedureFields[field.key] || ""} onChange={event => { setManualData(current => ({ ...current, procedureFields: { ...current.procedureFields, [field.key]: event.target.value } })); setConfirmed(false); setAnalysisStarted(false); }} className="mt-1" placeholder={field.placeholder} /></label>)}</div><Textarea value={notes} onChange={event => { setNotes(event.target.value); setConfirmed(false); }} className="mt-4 min-h-28" placeholder="Ghi chú thêm: tình trạng hôn nhân, miễn giảm thuế, đồng sở hữu, ủy quyền hoặc yêu cầu cần xử lý..." />{files.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{files.map((file, index) => <span key={`${file.name}-${index}`} className="rounded-full bg-[#EAF3EC] px-3 py-1.5 text-xs font-bold text-[#1F5A4A]">{file.name}</span>)}</div>}<div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><p className="text-xs text-[#71847A]">Dữ liệu chỉ là bản nháp đầu vào; hãy đối chiếu bản gốc trước khi xác nhận.</p><Button type="button" onClick={() => void runEndToEndPipeline()} disabled={ocr.isPending || !province} className="bg-[#1F5A4A] hover:bg-[#164637]">{ocr.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}{ocr.isPending ? "Đang OCR và phân tích…" : "AI phân tích và lập hồ sơ"}</Button></div><div className="mt-4 rounded-xl border-2 border-[#1F5A4A] bg-[#F7FAF7] p-4" data-testid="land-dossier-pipeline"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-black uppercase tracking-[0.16em] text-[#B38321]">AI Land Dossier Pipeline</p><h3 className="mt-1 text-base font-black text-[#18352D]">Phân tích → chọn mẫu → tự điền bản nháp → rà soát → in</h3><p className="mt-1 text-xs leading-5 text-[#63776D]">AI sẽ chọn bộ giấy tờ theo thủ tục và địa phương. Mẫu chỉ được tự điền ở chế độ Official khi kho có tệp DOCX/PDF binary đã xác minh; nếu chưa có, hệ thống vẫn dựng bản nháp tham khảo để bạn rà soát.</p></div><span className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-black ${pipelineStatus === "ready-to-review" ? "bg-[#EAF3EC] text-[#1F5A4A]" : pipelineStatus === "analyzing" ? "bg-[#FFF9EA] text-[#7A6A42]" : "bg-[#FDECEC] text-[#A33A3A]"}`}>{pipelineStatus === "idle" ? "Chưa chạy" : pipelineStatus === "analyzing" ? "Đang phân tích" : pipelineStatus === "ready-to-review" ? "Sẵn sàng rà soát" : "Cần rà soát"}</span></div><div className="mt-3 grid gap-2 sm:grid-cols-5">{["Phân tích", "Chọn mẫu", "Tự điền", "Rà soát", "In/Xuất"].map((label, index) => <div key={label} className={`rounded-lg px-2 py-2 text-center text-[10px] font-black ${pipelineStarted && index < 2 ? "bg-[#1F5A4A] text-white" : pipelineStarted && index === 2 && pipelinePlan.autoFillEnabled ? "bg-[#B38321] text-white" : pipelineStarted && index >= 3 ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-white text-[#71847A]"}`}>{index + 1}. {label}</div>)}</div><div className="mt-3 grid gap-2 sm:grid-cols-2">{pipelinePlan.items.slice(0, 6).map(item => <div key={item.id} className="rounded-lg bg-white p-2.5"><div className="flex items-start gap-2"><span className="mt-0.5">{item.status === "verified-binary" ? <CheckCircle2 className="h-4 w-4 text-[#1F5A4A]" /> : <AlertTriangle className="h-4 w-4 text-[#B38321]" />}</span><div className="min-w-0"><p className="text-xs font-bold text-[#18352D]">{item.label}</p><p className="mt-1 text-[10px] leading-4 text-[#71847A]">{item.template ? item.template.fileName + " · " : "Chưa có tệp mẫu · "}{item.reason}</p></div></div></div>)}</div>{pipelinePlan.items.length > 6 && <p className="mt-2 text-[10px] text-[#71847A]">+ {pipelinePlan.items.length - 6} nhóm giấy tờ khác sẽ được gom trong bộ hồ sơ.</p>}<div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><p className="text-[11px] leading-5 text-[#6F5520]">{pipelinePlan.autoFillEnabled ? "Có thể tự điền vào mẫu binary đã xác minh sau khi đủ dữ liệu." : "Hiện chưa có binary xác minh cho mẫu chính; AI không giả mạo mẫu Official và sẽ khóa tự điền mẫu gốc."}</p><Button type="button" onClick={() => void runEndToEndPipeline()} disabled={ocr.isPending || !province} className="bg-[#1F5A4A] hover:bg-[#164637]">{ocr.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}{ocr.isPending ? "Đang dựng bộ hồ sơ…" : "AI lập bộ hồ sơ end-to-end"}</Button></div></div></section>

          <section className="mt-4 rounded-2xl border border-[#D8E4DC] bg-white p-4 shadow-sm sm:p-5"><div className="flex items-center justify-between gap-3"><div><p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">Bước 3–5</p><h2 className="mt-1 text-xl font-black">Rà soát bộ hồ sơ trước khi in</h2></div><FileText className="h-6 w-6 text-[#1F5A4A]" /></div><div className="mt-4 grid gap-2 md:grid-cols-5">{steps.map((step, index) => <div key={step} className={`rounded-xl p-3 text-xs font-bold ${analysisStarted && index < 4 ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#F4F6F3] text-[#71847A]"}`}><span className="block text-[10px] uppercase tracking-wide">0{index + 1}</span>{step}</div>)}</div>{analysisStarted ? <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_280px]"><div className="rounded-xl bg-[#F7FAF7] p-4"><h3 className="font-black">Bộ hồ sơ dự kiến · {selected[1]}</h3><div className={`mt-2 rounded-lg p-2 text-xs leading-5 ${selectedTemplates[0]?.provenance === "verified-binary" ? "bg-[#EAF3EC] text-[#1F5A4A]" : "bg-[#FFF9EA] text-[#6F5520]"}`}><strong>{selectedTemplates[0]?.provenance === "verified-binary" ? "Verified binary template" : "Metadata-only template"}</strong> · {selectedTemplates[0]?.provenance === "verified-binary" ? "Đã tích hợp file gốc đã xác minh." : "Đang dùng metadata và nguồn tham chiếu; chưa được gắn nhãn Official."}</div>{ocrWarnings.length > 0 && <div className="mt-3 rounded-lg bg-[#FFF9EA] p-3 text-xs leading-5 text-[#6F5520]">{ocrWarnings.map(warning => <p key={warning}>• {warning}</p>)}</div>}{ocrFields.length > 0 && <div className="mt-3 space-y-2"><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Kết quả OCR — xác nhận từng trường</p>{ocrFields.map((field, index) => <label key={field.key} className="block rounded-lg border border-[#D8E4DC] bg-white p-2 text-xs"><span className="font-bold">{field.label} · {Math.round(field.confidence * 100)}%</span><input value={field.value} onChange={event => { setOcrFields(current => current.map((item, itemIndex) => itemIndex === index ? { ...item, value: event.target.value, confirmed: false } : item)); setConfirmed(false); }} className="mt-1 w-full rounded-md border border-input px-2 py-1.5 text-sm" /><span className="mt-1 flex items-center gap-2 text-[#71847A]"><input type="checkbox" checked={field.confirmed} onChange={event => { const nextField = { ...field, confirmed: event.target.checked }; setOcrFields(current => current.map((item, itemIndex) => itemIndex === index ? nextField : item)); setManualData(current => mergeConfirmedOcrIntoInput(current, [nextField])); setConfirmed(false); }} /> Đã đối chiếu với bản gốc</span></label>)}</div>}<div className="mt-3 grid gap-2 sm:grid-cols-2">{["Đơn/mẫu thủ tục chính", "Giấy tờ nhân thân và quyền sử dụng", "Tài liệu thửa đất, bản vẽ hoặc trích đo", "Tờ khai thuế, lệ phí nếu phát sinh", "Checklist thành phần hồ sơ", "Hướng dẫn cơ quan tiếp nhận"].map(item => <div key={item} className="flex gap-2 text-sm text-[#52675D]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#1F5A4A]" />{item}</div>)}</div><div className="mt-4 rounded-lg border border-[#D8E4DC] bg-white p-3"><p className="text-xs font-black uppercase tracking-wide text-[#B38321]">Các file AI sẽ tạo riêng</p><p className="mt-1 text-[11px] leading-5 text-[#71847A]">Mỗi dòng là một file riêng. Hãy ưu tiên tải DOCX để mở và chỉnh sửa; PDF dùng để xem/in sau khi đã kiểm tra.</p><div className="mt-3 space-y-2">{exportDocuments.map(([type, label]) => <div key={type} className="flex flex-col gap-2 rounded-lg border border-[#E2EBE4] p-2.5 sm:flex-row sm:items-center sm:justify-between"><span className="text-xs font-bold text-[#18352D]">{label}</span><div className="grid grid-cols-3 gap-2"><Button type="button" size="sm" variant="outline" disabled={!confirmed} onClick={() => setPreviewDocument({ type, label })}>Xem</Button><Button type="button" size="sm" variant="outline" disabled={!confirmed || isGeneratingDownload} onClick={() => void downloadExport("docx", type, label)}><Download className="mr-1 h-3.5 w-3.5" />DOCX</Button><Button type="button" size="sm" variant="outline" disabled={!confirmed || isGeneratingDownload} onClick={() => void downloadExport("pdf", type, label)}><FileText className="mr-1 h-3.5 w-3.5" />PDF</Button></div></div>)}</div></div>{previewDocument && <div className="mt-4 rounded-lg border-2 border-[#1F5A4A] bg-white p-4" id="land-dossier-preview"><div className="flex items-start justify-between gap-3"><div><p className="text-[10px] font-black uppercase tracking-wide text-[#B38321]">Bản xem trước</p><h4 className="mt-1 text-base font-black text-[#18352D]">{previewDocument.label}</h4><p className="mt-1 text-[11px] text-[#71847A]">Bản nháp hỗ trợ rà soát · {province} · Chưa phải văn bản được cơ quan nhà nước chứng nhận.</p></div><Button type="button" size="sm" variant="outline" onClick={printConfirmedDossier}><Printer className="mr-1 h-3.5 w-3.5" />In bản xem</Button></div><div className="mt-3 space-y-1 border-t border-[#E2EBE4] pt-3 text-xs text-[#52675D]">{ocrFields.map(field => <p key={`${previewDocument.type}-${field.key}`}><strong>{field.label}:</strong> {field.value || "(chưa có dữ liệu)"}</p>)}</div><p className="mt-3 rounded-md bg-[#FFF9EA] p-2 text-[11px] leading-5 text-[#6F5520]">Đối chiếu bản gốc, chỉnh sửa bản tải xuống nếu cần, ký và nộp theo yêu cầu của Bộ phận một cửa.</p></div>}<p className="mt-4 rounded-lg bg-[#FFF9EA] p-3 text-xs leading-5 text-[#6F5520]">Mẫu cơ quan chỉ được xuất khi có binary DOCX/PDF đã xác minh theo đúng thủ tục, tỉnh và cơ quan. Nếu chưa có, chỉ dùng nút bản nháp AI để tham khảo; bản nháp không phải mẫu nộp chính thức.</p></div><div className="rounded-xl border border-[#D8E4DC] p-4"><p className="text-sm font-black">Xác nhận người dùng</p><p className="mt-2 text-xs leading-5 text-[#71847A]">Bạn xác nhận đã đối chiếu thông tin với giấy tờ gốc và hiểu rằng cơ quan tiếp nhận có thể yêu cầu bổ sung.</p><Button type="button" onClick={() => setConfirmed(true)} disabled={confirmed || (ocrFields.length > 0 && ocrFields.some(field => !field.confirmed))} className="mt-4 w-full bg-[#1F5A4A]">{confirmed ? "Đã xác nhận bản nháp" : "Xác nhận bản nháp"}</Button><Button type="button" onClick={() => void saveElectronicDossier()} disabled={!province || createDossier.isPending || updateDossier.isPending} variant="outline" className="mt-2 w-full"><ClipboardCheck className="mr-2 h-4 w-4" />{createDossier.isPending || updateDossier.isPending ? "Đang lưu hồ sơ…" : savedDossierId ? `Cập nhật hồ sơ #${savedDossierId}` : "Lưu hồ sơ điện tử"}</Button>{saveMessage && <p className="mt-2 rounded-lg bg-[#EAF3EC] p-3 text-xs leading-5 text-[#1F5A4A]">{saveMessage}</p>}<div className="mt-2 grid grid-cols-2 gap-2"><Button type="button" disabled={!confirmed || isGeneratingDownload || !selectedDbTemplate} onClick={() => void downloadExport("docx")} variant="outline"><Download className="mr-2 h-4 w-4" />{isGeneratingDownload ? "Đang tạo…" : selectedDbTemplate ? "DOCX mẫu cơ quan" : "DOCX mẫu cơ quan · chưa có binary"}</Button><Button type="button" disabled={!confirmed || isGeneratingDownload || !selectedDbTemplate} onClick={() => void downloadExport("pdf")} variant="outline"><FileText className="mr-2 h-4 w-4" />{selectedDbTemplate ? "PDF mẫu cơ quan" : "PDF mẫu cơ quan · chưa có binary"}</Button><Button type="button" disabled={!confirmed || isGeneratingDownload} onClick={printConfirmedDossier} variant="outline" className="col-span-2"><Printer className="mr-2 h-4 w-4" />In hồ sơ đã xác nhận</Button><Button type="button" disabled={!confirmed || isGeneratingDownload || !selectedDbTemplate} onClick={() => void downloadAllZip()} variant="outline" className="col-span-2"><Download className="mr-2 h-4 w-4" />{isGeneratingDownload ? "Đang tạo bộ hồ sơ…" : selectedDbTemplate ? "Tải bộ hồ sơ mẫu cơ quan (ZIP)" : "ZIP mẫu cơ quan · chưa có binary"}</Button><Button type="button" disabled={!confirmed || isGeneratingDownload} onClick={() => void downloadExport("docx")} variant="ghost" className="col-span-2 text-[#6F5520]">Tải bản nháp AI (DOCX) — chỉ để tham khảo</Button></div>{readyDownload && <div className="mt-3 rounded-lg border border-[#B8D2C1] bg-[#EAF3EC] p-3 text-xs leading-5 text-[#1F5A4A]"><p className="font-bold">File đã tạo xong. Nếu điện thoại chưa tự tải, hãy bấm trực tiếp:</p><a href={readyDownload.url} download={readyDownload.fileName} className="mt-2 inline-flex min-h-11 w-full items-center justify-center rounded-lg bg-[#1F5A4A] px-3 py-2 text-center font-black text-white underline-offset-2 hover:underline">Tải {readyDownload.fileName}</a></div>}{downloadError && <p className="mt-3 rounded-lg bg-[#FDECEC] p-3 text-xs leading-5 text-[#A33A3A]">{downloadError}</p>}{!confirmed && <p className="mt-2 text-center text-[11px] text-[#71847A]">{ocrFields.length > 0 ? "Xác nhận tất cả trường OCR trước khi xuất." : "Khóa xuất đến khi bạn xác nhận dữ liệu và bản nháp."}</p>}</div></div> : <div className="mt-4 rounded-xl border border-dashed border-[#BCD0C1] p-8 text-center text-sm text-[#71847A]"><Sparkles className="mx-auto mb-2 h-6 w-6 text-[#B38321]" />Chưa có bản phân tích. Hãy nhập dữ liệu hoặc tải giấy tờ rồi bấm AI phân tích.</div>}</section>

          <section className="mt-6 rounded-2xl border border-[#B8D2C1] bg-[#F5FAF6] p-4 shadow-sm" id="dossier-multi-channel-publishing">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div><p className="text-[10px] font-black uppercase tracking-[0.18em] text-[#B38321]">Đăng bài từ hồ sơ điện tử</p><h2 className="mt-1 text-xl font-black text-[#18352D]">Ảnh, video và đăng đa kênh</h2><p className="mt-1 max-w-2xl text-xs leading-5 text-[#71847A]">Media ở khu vực này là nội dung công khai cho bài đăng. Tệp pháp lý đã tải ở phía trên vẫn được tách riêng, không tự động đưa lên Facebook, Zalo hoặc Website.</p></div><span className="inline-flex w-fit items-center gap-1 rounded-full bg-[#EAF3EC] px-3 py-1 text-[11px] font-black text-[#1F5A4A]"><Camera className="h-3.5 w-3.5" />Media công khai</span></div>
            <div className="mt-4 grid gap-4 lg:grid-cols-[1.05fr_0.95fr]">
              <div className="rounded-xl border border-[#D8E4DC] bg-white p-4">
                <div className="flex flex-wrap gap-2">
                  <label className="inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-lg bg-[#1F5A4A] px-4 py-2 text-xs font-black text-white hover:bg-[#164637]"><UploadCloud className="h-4 w-4" />Tải ảnh/video<input type="file" accept="image/*,video/*" multiple className="sr-only" onChange={handlePublicMedia} /></label>
                  <Button type="button" variant="outline" onClick={() => void openCamera()}><Camera className="mr-2 h-4 w-4" />Mở camera</Button>
                </div>
                {cameraOpen && <div className="mt-3 overflow-hidden rounded-xl border border-[#B8D2C1] bg-[#18352D] p-2"><video ref={cameraVideoRef} muted playsInline className="aspect-video w-full rounded-lg object-cover" /><div className="mt-2 flex flex-wrap gap-2"><Button type="button" onClick={capturePhoto} className="bg-white text-[#18352D] hover:bg-[#EAF3EC]"><Camera className="mr-2 h-4 w-4" />Chụp ảnh</Button><Button type="button" onClick={toggleRecording} className={recording ? "bg-[#A33A3A] text-white hover:bg-[#8A2E2E]" : "bg-[#B38321] text-white hover:bg-[#956E18]"}>{recording ? <Square className="mr-2 h-4 w-4" /> : <Video className="mr-2 h-4 w-4" />}{recording ? "Dừng quay" : "Quay video"}</Button><Button type="button" variant="outline" onClick={closeCamera} className="border-white bg-transparent text-white hover:bg-white/10"><X className="mr-2 h-4 w-4" />Đóng</Button></div></div>}
                {publicMedia.length > 0 ? <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">{publicMedia.map(media => <div key={media.id} className="relative overflow-hidden rounded-xl border border-[#D8E4DC] bg-[#F8FBF8]"><div className="aspect-square">{media.kind === "video" ? <video src={media.url} controls className="h-full w-full object-cover" /> : <img src={media.url} alt={media.file.name} className="h-full w-full object-cover" />}</div><button type="button" aria-label={`Xóa ${media.file.name}`} onClick={() => removePublicMedia(media.id)} className="absolute right-1.5 top-1.5 rounded-full bg-[#18352D]/85 p-1.5 text-white"><X className="h-3.5 w-3.5" /></button><p className="truncate px-2 py-1.5 text-[10px] font-bold text-[#52675D]">{media.file.name}</p></div>)}</div> : <div className="mt-4 rounded-xl border border-dashed border-[#BCD0C1] p-6 text-center text-xs text-[#71847A]">Chưa có ảnh/video công khai. Bạn có thể tải từ máy hoặc chụp/quay bằng camera.</div>}
              </div>
              <div className="rounded-xl border border-[#D8E4DC] bg-white p-4"><p className="text-sm font-black text-[#18352D]">Soạn bài đăng</p><label className="mt-3 block text-xs font-bold text-[#52675D]">Kênh chuẩn bị bài<select value={postChannel} onChange={event => setPostChannel(event.target.value as typeof postChannel)} className="mt-1 h-10 w-full rounded-lg border border-[#D8E4DC] bg-white px-3 text-sm font-semibold text-[#18352D]"><option value="website">Website</option><option value="facebook-personal">Facebook cá nhân · Mở để đăng</option><option value="zalo-personal">Zalo cá nhân · Mở để đăng</option></select></label><Textarea value={postCaption} onChange={event => setPostCaption(event.target.value)} className="mt-3 min-h-36" placeholder="Viết mô tả ngắn, điểm nổi bật, thông tin liên hệ..." /><div className="mt-3 rounded-lg bg-[#EAF3EC] p-3 text-[11px] leading-5 text-[#1F5A4A]"><p className="font-black">Bản xem trước</p><p className="mt-1 whitespace-pre-line">{postCaption || "Nội dung sẽ kết hợp thông tin hồ sơ đã nhập và phần mô tả của bạn."}</p><p className="mt-2">Media đính kèm: {publicMedia.length} tệp</p></div><Button type="button" onClick={() => void openPersonalComposer()} disabled={postChannel === "website" || publicMedia.length === 0} className="mt-3 w-full bg-[#1F5A4A] hover:bg-[#164637]">{postChannel === "facebook-personal" ? "Mở Facebook để đăng" : postChannel === "zalo-personal" ? "Mở Zalo để đăng" : "Chọn kênh cá nhân để tiếp tục"}</Button><p className="mt-2 text-[10px] leading-4 text-[#71847A]">Khi mở kênh cá nhân, hệ thống sao chép nội dung để bạn dán và tự bấm đăng. Không tự đăng thay bạn.</p></div>
            </div>
          </section>
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-[#71847A]"><ChevronRight className="h-4 w-4" />Mục này chỉ lập hồ sơ đất đai để người dùng rà soát, in, ký và nộp; không thay đổi Hồ sơ AI, Kho biểu mẫu, Hồ sơ đất đai AI cũ hoặc các phân hệ CRM.</div>
        </div>
      </main>
    </DashboardLayout>
  );
}

export default LandDossierBuilder;
