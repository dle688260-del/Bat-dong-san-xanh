import { listOfficialLandProcedures } from "../server/officialLandProcedureRegistry.ts";
import { scanDvcProcedureSource } from "../server/dvcSourceRegistry.ts";
import { discoverOfficialTemplateFallbacks, downloadOfficialTemplateCandidate } from "../server/officialTemplateFetcher.ts";
import { writeFile } from "node:fs/promises";

const REPORT_TIMEOUT_MS = 25_000;
const withTimeout = (promise, label) => Promise.race([
  promise,
  new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timeout sau ${REPORT_TIMEOUT_MS}ms`)), REPORT_TIMEOUT_MS)),
]);

async function processProcedure(procedure) {
  const sourceUrls = [
    ...(procedure.legalDocuments ?? []).map(item => item.sourceUrl),
    procedure.baseUrl,
  ];
  const row = { code: procedure.code, name: procedure.name, dvc: "not_checked", fallbackCandidates: 0, directDownloads: [], warnings: [] };
  try {
    const snapshot = await withTimeout(scanDvcProcedureSource({ procedureCode: procedure.code }), `DVC ${procedure.code}`);
    row.dvc = snapshot.attachments.some(item => item.status === "verified_binary") ? "verified_binary" : "no_verified_binary";
    row.warnings.push(...snapshot.warnings.slice(0, 3));
  } catch (error) {
    row.dvc = "failed";
    row.warnings.push(error instanceof Error ? error.message : "DVC scan failed");
  }
  try {
    const fallback = await withTimeout(discoverOfficialTemplateFallbacks({
      sourceUrls,
      procedureName: procedure.name,
      procedureAliases: procedure.aliases,
      templateNames: procedure.referenceTemplates?.map(item => item.name),
      templateCodes: procedure.referenceTemplates?.flatMap(item => item.name.match(/(?:mẫu|mau|form|phụ lục|phu luc)\s*(?:số\s*)?[A-Za-z0-9/-]+/gi) ?? []),
    }), `fallback ${procedure.code}`);
    row.fallbackCandidates = fallback.candidates.length;
    row.fallbackSources = fallback.sources.map(source => ({ sourceUrl: source.sourceUrl, candidates: source.candidates.length }));
    const directUrls = (procedure.referenceTemplates ?? []).filter(item => /\.(?:docx?|pdf)(?:\?|$)/i.test(item.sourceUrl));
    for (const item of directUrls) {
      try {
        const downloaded = await withTimeout(downloadOfficialTemplateCandidate({ candidateUrl: item.sourceUrl, originalFileName: item.name }), `direct ${procedure.code}`);
        row.directDownloads.push({ name: item.name, sourceUrl: downloaded.sourceUrl, bytes: downloaded.bytes.length, checksum: downloaded.checksum, status: "verified_binary" });
      } catch (error) {
        row.directDownloads.push({ name: item.name, sourceUrl: item.sourceUrl, status: "failed", error: error instanceof Error ? error.message : "direct download failed" });
      }
    }
    row.fallbackCandidates += row.directDownloads.filter(item => item.status === "verified_binary").length;
  } catch (error) {
    row.warnings.push(error instanceof Error ? error.message : "Fallback scan failed");
  }
  return row;
}

const procedures = listOfficialLandProcedures();
const report = await Promise.all(procedures.map(processProcedure));
await writeFile("docs/official-source-batch-report.json", JSON.stringify({ generatedAt: new Date().toISOString(), total: report.length, report }, null, 2));
console.log(JSON.stringify({ total: report.length, verifiedDvc: report.filter(row => row.dvc === "verified_binary").length, failedDvc: report.filter(row => row.dvc === "failed").length, fallbackCandidates: report.reduce((sum, row) => sum + row.fallbackCandidates, 0), directVerified: report.reduce((sum, row) => sum + row.directDownloads.filter(item => item.status === "verified_binary").length, 0) }, null, 2));
