import { useState } from "react";
import { Camera, CheckCircle2, FileImage, Loader2, RefreshCw, ShieldAlert, Upload } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export type ListingOcrData = {
  title?: string | null;
  propertyType?: string | null;
  location?: string | null;
  province?: string | null;
  area?: string | null;
  price?: string | null;
  buildArea?: string | null;
  roadWidth?: string | null;
  bedrooms?: number | null;
  bathrooms?: number | null;
  orientation?: string | null;
  legalStatus?: string | null;
  certificateType?: string | null;
  certificateArea?: string | null;
  landUsePurpose?: string | null;
  planningStatus?: string | null;
  mortgageStatus?: string | null;
  ownerName?: string | null;
  ownerPhone?: string | null;
  propertyCode?: string | null;
  description?: string | null;
  confidence?: number;
  notes?: string | null;
};

type Props = { onApply: (data: ListingOcrData, sourceUrl: string) => void };

export function getListingOcrFormValues(data: ListingOcrData) {
  const values: Record<string, string> = {};
  const keys: Array<keyof ListingOcrData> = ["title", "propertyType", "location", "price", "area", "buildArea", "roadWidth", "orientation", "legalStatus", "certificateType", "certificateArea", "landUsePurpose", "planningStatus", "mortgageStatus", "ownerName", "ownerPhone", "propertyCode", "description"];
  keys.forEach(key => {
    const value = data[key];
    if (value !== null && value !== undefined && value !== "") values[key] = String(value);
  });
  return values;
}

const editableFields: Array<{ key: keyof ListingOcrData; label: string }> = [
  { key: "title", label: "Tiêu đề" },
  { key: "propertyType", label: "Loại BĐS" },
  { key: "location", label: "Địa chỉ/khu vực" },
  { key: "province", label: "Tỉnh/thành phố" },
  { key: "area", label: "Diện tích (m²)" },
  { key: "price", label: "Giá (tỷ đồng)" },
  { key: "buildArea", label: "Diện tích xây dựng" },
  { key: "roadWidth", label: "Đường trước nhà" },
  { key: "orientation", label: "Hướng" },
  { key: "legalStatus", label: "Tình trạng pháp lý" },
  { key: "certificateType", label: "Loại giấy chứng nhận" },
  { key: "certificateArea", label: "Diện tích trên giấy" },
  { key: "landUsePurpose", label: "Mục đích sử dụng" },
  { key: "planningStatus", label: "Quy hoạch" },
  { key: "mortgageStatus", label: "Thế chấp/tranh chấp" },
  { key: "ownerName", label: "Tên chủ nhà" },
  { key: "ownerPhone", label: "Số điện thoại chủ nhà" },
  { key: "propertyCode", label: "Mã BĐS" },
  { key: "description", label: "Mô tả" },
];

export default function ListingDocumentAutofill({ onApply }: Props) {
  const [extracted, setExtracted] = useState<ListingOcrData | null>(null);
  const [sourceUrl, setSourceUrl] = useState("");
  const [fileName, setFileName] = useState("");
  const analyze = trpc.properties.analyzeListingDocument.useMutation({
    onSuccess: result => {
      setExtracted(result.extracted as ListingOcrData);
      setSourceUrl(result.imageUrl);
      toast.success("AI đã đọc xong. Vui lòng kiểm tra các trường trước khi áp dụng.");
    },
    onError: error => toast.error(error.message),
  });

  const handleFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Hãy chọn ảnh JPG, PNG hoặc WEBP.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Ảnh không được vượt quá 10MB.");
      return;
    }
    const data = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
      reader.onerror = () => reject(new Error("Không thể đọc ảnh"));
      reader.readAsDataURL(file);
    }).catch(() => "");
    if (!data) {
      toast.error("Không thể đọc tệp. Vui lòng thử lại.");
      return;
    }
    setFileName(file.name);
    setExtracted(null);
    analyze.mutate({ fileName: file.name, mimeType: file.type as "image/jpeg" | "image/png" | "image/webp", data });
  };

  const update = (key: keyof ListingOcrData, value: string) => setExtracted(current => current ? { ...current, [key]: value || null } : current);
  const apply = () => {
    if (!extracted || !sourceUrl) return;
    onApply(extracted, sourceUrl);
    toast.success("Đã điền dữ liệu AI vào biểu mẫu. Bạn vẫn cần rà soát trước khi lưu.");
  };

  return <section className="md:col-span-2 rounded-2xl border-2 border-[#E6C478] bg-[#FFF8E7] p-4 sm:p-5">
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[.16em] text-[#8A6A1E]"><FileImage size={15} /> AI đọc ảnh và tự điền</p>
        <h3 className="mt-1 text-lg font-bold text-[#18352D]">Chụp giấy tờ hoặc chọn ảnh trong máy</h3>
        <p className="mt-1 text-xs leading-5 text-[#60766D]">AI chỉ đề xuất thông tin nhìn thấy rõ từ ảnh. Kết quả luôn ở trạng thái cần rà soát, không tự chuyển bài sang Công khai.</p>
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <label className="inline-flex min-h-12 cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#1F5A4A] px-4 py-3 text-sm font-bold text-white hover:bg-[#174638]">
          <Camera size={17} /> Chụp bằng camera
          <input type="file" accept="image/*" capture="environment" onChange={handleFile} className="absolute h-px w-px overflow-hidden opacity-0" />
        </label>
        <label className="inline-flex min-h-12 cursor-pointer items-center justify-center gap-2 rounded-xl border border-[#1F5A4A] bg-white px-4 py-3 text-sm font-bold text-[#1F5A4A] hover:bg-[#E8F1EC]">
          <Upload size={17} /> Chọn ảnh trong máy
          <input type="file" accept="image/*" onChange={handleFile} className="absolute h-px w-px overflow-hidden opacity-0" />
        </label>
      </div>
    </div>
    {analyze.isPending && <p className="mt-4 flex items-center gap-2 rounded-xl bg-white p-3 text-sm text-[#1F5A4A]"><Loader2 size={17} className="animate-spin" /> Đang tải ảnh an toàn và để AI đọc thông tin…</p>}
    {!extracted && !analyze.isPending && fileName && <p className="mt-3 flex items-center gap-2 text-xs text-[#60766D]"><Upload size={14} /> Đã nhận: {fileName}</p>}
    {extracted && <div className="mt-4 rounded-xl bg-white p-4 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2"><strong className="text-[#18352D]">Kết quả OCR cần kiểm tra</strong><span className="rounded-full bg-[#E8F1EC] px-3 py-1 text-xs font-bold text-[#1F5A4A]">Độ tin cậy: {Math.round(extracted.confidence || 0)}%</span></div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">{editableFields.map(field => <label key={field.key} className="text-xs font-bold text-[#60766D]">{field.label}<input value={String(extracted[field.key] ?? "")} onChange={event => update(field.key, event.target.value)} className="mt-1 w-full rounded-lg border border-[#D7E5DE] bg-white p-2.5 text-sm font-normal text-[#18352D]" /></label>)}</div>
      {extracted.notes && <p className="mt-3 text-xs leading-5 text-[#60766D]">Ghi chú AI: {extracted.notes}</p>}
      <p className="mt-4 flex gap-2 rounded-xl bg-[#FFF8E7] p-3 text-xs leading-5 text-[#765B18]"><ShieldAlert size={16} className="mt-0.5 shrink-0" /> Không dùng kết quả OCR thay cho kiểm tra bản gốc. Hãy sửa các trường sai hoặc bỏ trống trước khi đăng.</p>
      <div className="mt-4 flex flex-wrap gap-2"><button type="button" onClick={apply} className="inline-flex items-center gap-2 rounded-lg bg-[#1F5A4A] px-4 py-2.5 text-sm font-bold text-white"><CheckCircle2 size={16} /> Áp dụng vào biểu mẫu</button><button type="button" onClick={() => { setExtracted(null); setSourceUrl(""); setFileName(""); }} className="inline-flex items-center gap-2 rounded-lg border border-[#D7E5DE] px-4 py-2.5 text-sm font-bold text-[#18352D]"><RefreshCw size={16} /> Đọc ảnh khác</button></div>
    </div>}
  </section>;
}
