# Visual checks — dải BĐS nổi bật

- Mobile 390×844: thẻ danh mục hiển thị một mục mỗi lượt; chỉ còn mũi tên kế tiếp ở mép phải; phần sản phẩm xuất hiện ngay sau dải danh mục.
- Desktop 1280×720: thẻ ngang giữ chiều rộng gọn khoảng một nửa vùng nội dung; không còn mũi tên trái; mũi tên phải không che nội dung chính.
- Các khu vực header, thanh tìm kiếm, AI khách hàng tìm hàng và thẻ sản phẩm vẫn render bình thường.
- Dev server đang chạy; TypeScript không có lỗi. Vitest đạt 401/401.
- Cảnh báo `baseline-browser-mapping` chỉ là cảnh báo phụ thuộc cũ, không phải lỗi runtime của thay đổi này.
