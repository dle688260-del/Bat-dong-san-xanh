import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  createConsultationRequest: vi.fn(),
  updateConsultationStatus: vi.fn(),
  listConsultationRequests: vi.fn(),
  updateConsultationAi: vi.fn(),
  listPublishedProperties: vi.fn(),
  notifyOwner: vi.fn().mockResolvedValue(true),
}));
vi.mock("./db", () => mocks);
vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn().mockResolvedValue({ choices: [{ message: { content: JSON.stringify({ propertyType: null, area: "Sơn Trà", budgetMin: null, budgetMax: null, purpose: "Đầu tư", minArea: null, bedrooms: null, timeline: null, priority: "reference", summary: "Khách quan tâm đầu tư tại Sơn Trà.", missingInfo: ["Ngân sách"] }) } }] }) }));
vi.mock("./_core/notification", () => ({ notifyOwner: mocks.notifyOwner }));

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const baseContext = (role: "admin" | "user" = "user"): TrpcContext => ({
  user: { id: 1, openId: "test-user", name: "Test", email: "test@example.com", loginMethod: "test", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("consultations success paths", () => {
  beforeEach(() => { vi.clearAllMocks(); mocks.listPublishedProperties.mockResolvedValue([]); });

  it("returns the id after saving a valid request", async () => {
    mocks.createConsultationRequest.mockResolvedValue({ id: 42 });
    mocks.updateConsultationAi.mockResolvedValue({ success: true });
    const result = await appRouter.createCaller(baseContext()).consultations.create({ interest: "Đầu tư bất động sản", name: "Khách hàng", phone: "0989682825", message: "Quan tâm Sơn Trà" });
    expect(result).toEqual({ id: 42 });
    expect(mocks.createConsultationRequest).toHaveBeenCalledWith({ interest: "Đầu tư bất động sản", name: "Khách hàng", phone: "0989682825", message: "Quan tâm Sơn Trà" });
    expect(mocks.notifyOwner).toHaveBeenCalledWith(expect.objectContaining({ title: "🔔 Yêu cầu tư vấn mới", content: expect.stringContaining("0989682825") }));
  });

  it("persists AI handoff context and routes the lead by area", async () => {
    mocks.createConsultationRequest.mockResolvedValue({ id: 43 });
    mocks.updateConsultationAi.mockResolvedValue({ success: true });
    await appRouter.createCaller(baseContext()).consultations.create({ name: "Khách Thanh Khê", phone: "0989682825", interest: "Mua đất khoảng 2 tỷ ở Thanh Khê", message: "Muốn xem trong tháng này", conversationHistory: "Khách: Tôi cần mua đất ở Thanh Khê\\nAI: Bạn dự kiến ngân sách bao nhiêu?", propertyIds: [12, 15] });
    expect(mocks.updateConsultationAi).toHaveBeenCalledWith(43, expect.objectContaining({ aiArea: "Sơn Trà", routingStage: "area_queue", conversationHistory: expect.stringContaining("Khách: Tôi cần mua đất") }));
  });

  it("normalizes a formatted Vietnamese phone number before persisting", async () => {
    mocks.createConsultationRequest.mockResolvedValue({ id: 44 });
    mocks.updateConsultationAi.mockResolvedValue({ success: true });
    await appRouter.createCaller(baseContext()).consultations.create({ interest: "Căn hộ", name: "Khách có định dạng", phone: "0989 682 825", message: "Cần tư vấn" });
    expect(mocks.createConsultationRequest).toHaveBeenCalledWith(expect.objectContaining({ phone: "0989682825" }));
  });

  it("updates a request status for an admin", async () => {
    mocks.updateConsultationStatus.mockResolvedValue({ success: true });
    const result = await appRouter.createCaller(baseContext("admin")).consultations.updateStatus({ id: 42, status: "contacted" });
    expect(result).toEqual({ success: true });
    expect(mocks.updateConsultationStatus).toHaveBeenCalledWith(42, "contacted");
  });
});
