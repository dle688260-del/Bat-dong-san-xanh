import { and, asc, count, desc, eq, getTableColumns, gte, gt, isNull, like, lte, ne, not, or, sum } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { areas, buyerLeads, consultationRequests, deals, InsertConsultationRequest, InsertProperty, legalChecks, legalDocumentScans, properties, propertyImages, propertyOwners, surveys, valuations, InsertUser, users, propertyDossiers, propertyDossierSteps, propertyDossierDocuments, propertyArchiveFiles, landDossiers, landDossierSteps, legalSources, legalDocuments, legalProcedures, legalProcedureRequirements, legalTemplates, legalTemplateFields, legalSyncRuns, legalProcedureVersions, legalTemplateMappings, landDossierAudits, adminAuthSettings, manusConnectionSettings, manusChangeRequests, legalScanQueue, propertyLayoutSettings, property3dAnnotations, marketingCampaigns, marketingChannels, marketingContents, marketingContentCalendar } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { matchLegalTemplatesByEvidence } from "./legalTemplateMatcher";
import { getOfficialLandProcedure, listOfficialLandProcedures } from "./officialLandProcedureRegistry";
import { OFFICIAL_2304_PROCEDURE_CODES, OFFICIAL_2304_CODE_INDEX_NOTICE, getVerified2304ProcedureName } from "./officialLandProcedureCodeIndex";

let _db: ReturnType<typeof drizzle> | null = null;

export async function listLandDossiers(createdBy: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(landDossiers).where(eq(landDossiers.createdBy, createdBy)).orderBy(desc(landDossiers.updatedAt)); }
export async function getLandDossier(id: number, createdBy: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const dossier = await db.select().from(landDossiers).where(and(eq(landDossiers.id, id), eq(landDossiers.createdBy, createdBy))).limit(1); if (!dossier[0]) return undefined; const steps = await db.select().from(landDossierSteps).where(eq(landDossierSteps.dossierId, id)).orderBy(asc(landDossierSteps.stepNumber)); return { dossier: dossier[0], steps }; }
export async function createLandDossier(input: typeof landDossiers.$inferInsert, steps: Array<typeof landDossierSteps.$inferInsert>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(landDossiers).values(input); const id = Number(result[0].insertId); if (steps.length) await db.insert(landDossierSteps).values(steps.map(step => ({ ...step, dossierId: id }))); return { id }; }
export async function updateLandDossier(id: number, createdBy: number, data: Partial<typeof landDossiers.$inferInsert>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(landDossiers).set(data).where(and(eq(landDossiers.id, id), eq(landDossiers.createdBy, createdBy))); return { success: true } as const; }
export async function deleteLandDossier(id: number, createdBy: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const owner = await db.select({ id: landDossiers.id }).from(landDossiers).where(and(eq(landDossiers.id, id), eq(landDossiers.createdBy, createdBy))).limit(1); if (!owner[0]) return { success: false } as const; await db.delete(landDossierSteps).where(eq(landDossierSteps.dossierId, id)); await db.delete(landDossiers).where(and(eq(landDossiers.id, id), eq(landDossiers.createdBy, createdBy))); return { success: true } as const; }
export async function updateLandDossierStep(id: number, dossierId: number, createdBy: number, data: Partial<typeof landDossierSteps.$inferInsert>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const owner = await db.select({ id: landDossiers.id }).from(landDossiers).where(and(eq(landDossiers.id, dossierId), eq(landDossiers.createdBy, createdBy))).limit(1); if (!owner[0]) return { success: false } as const; await db.update(landDossierSteps).set(data).where(and(eq(landDossierSteps.id, id), eq(landDossierSteps.dossierId, dossierId))); return { success: true } as const; }

export async function listProperty3dAnnotations(propertyId: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(property3dAnnotations).where(eq(property3dAnnotations.propertyId, propertyId)).orderBy(asc(property3dAnnotations.createdAt));
}

export async function createProperty3dAnnotation(input: typeof property3dAnnotations.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(property3dAnnotations).values(input);
  const id = Number(result[0].insertId);
  const rows = await db.select().from(property3dAnnotations).where(eq(property3dAnnotations.id, id)).limit(1);
  return rows[0];
}

export async function updateProperty3dAnnotation(id: number, propertyId: number, data: Partial<typeof property3dAnnotations.$inferInsert>) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(property3dAnnotations).set(data).where(and(eq(property3dAnnotations.id, id), eq(property3dAnnotations.propertyId, propertyId)));
  const rows = await db.select().from(property3dAnnotations).where(eq(property3dAnnotations.id, id)).limit(1);
  return rows[0];
}

export async function deleteProperty3dAnnotation(id: number, propertyId: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.delete(property3dAnnotations).where(and(eq(property3dAnnotations.id, id), eq(property3dAnnotations.propertyId, propertyId)));
  return { success: true } as const;
}

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function getPropertyLayoutSettings(userId: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(propertyLayoutSettings).where(eq(propertyLayoutSettings.userId, userId)).limit(1);
  const row = rows[0];
  if (!row) return { defaultLayout: "auto" as const, overrides: {} as Record<string, string> };
  let overrides: Record<string, string> = {};
  try {
    const parsed = row.overridesJson ? JSON.parse(row.overridesJson) : {};
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      overrides = Object.fromEntries(Object.entries(parsed).filter((entry): entry is [string, string] => typeof entry[0] === "string" && typeof entry[1] === "string"));
    }
  } catch { overrides = {}; }
  return { ...row, overrides };
}

export async function upsertPropertyLayoutSettings(userId: number, input: { defaultLayout: string; overrides: Record<string, string> }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: propertyLayoutSettings.id }).from(propertyLayoutSettings).where(eq(propertyLayoutSettings.userId, userId)).limit(1);
  const values = { userId, defaultLayout: input.defaultLayout, overridesJson: JSON.stringify(input.overrides) };
  if (existing[0]) await db.update(propertyLayoutSettings).set(values).where(eq(propertyLayoutSettings.id, existing[0].id));
  else await db.insert(propertyLayoutSettings).values(values);
  return getPropertyLayoutSettings(userId);
}

export async function getPublicPropertyLayoutSettings() {
  if (!ENV.ownerOpenId) return { defaultLayout: "auto" as const, overrides: {} as Record<string, string> };
  const owner = await getUserByOpenId(ENV.ownerOpenId);
  return owner ? getPropertyLayoutSettings(owner.id) : { defaultLayout: "auto" as const, overrides: {} as Record<string, string> };
}

export async function getAdminAuthSettings(username: string) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(adminAuthSettings).where(eq(adminAuthSettings.username, username)).limit(1);
  return rows[0];
}

export async function upsertAdminAuthSettings(username: string, passwordHash: string) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const existing = await getAdminAuthSettings(username);
  if (existing) {
    await db.update(adminAuthSettings).set({ passwordHash, passwordVersion: existing.passwordVersion + 1, changedAt: new Date() }).where(eq(adminAuthSettings.id, existing.id));
    return { ...existing, passwordHash, passwordVersion: existing.passwordVersion + 1 };
  }
  await db.insert(adminAuthSettings).values({ username, passwordHash, passwordVersion: 1 });
  return getAdminAuthSettings(username);
}

export async function getManusConnectionState() {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(manusConnectionSettings).where(eq(manusConnectionSettings.id, 1)).limit(1);
  if (rows[0]) return rows[0];
  await db.insert(manusConnectionSettings).values({ id: 1, status: "disconnected", lastSyncStatus: "never" });
  const created = await db.select().from(manusConnectionSettings).where(eq(manusConnectionSettings.id, 1)).limit(1);
  return created[0];
}

export async function updateManusConnectionState(input: { status?: "connected" | "disconnected"; lastSyncStatus?: "never" | "pending" | "success" | "failed"; lastSyncMessage?: string | null; lastSyncVersion?: string | null }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await getManusConnectionState();
  const now = new Date();
  const data: Record<string, unknown> = { ...input };
  if (input.status === "connected") data.connectedAt = now;
  if (input.status === "disconnected") data.disconnectedAt = now;
  if (input.lastSyncStatus === "success") data.lastSyncedAt = now;
  await db.update(manusConnectionSettings).set(data).where(eq(manusConnectionSettings.id, 1));
  return getManusConnectionState();
}

export async function createManusChangeRequest(input: typeof manusChangeRequests.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(manusChangeRequests).values(input);
  await updateManusConnectionState({ lastSyncStatus: "pending", lastSyncMessage: "Đã lưu yêu cầu, chờ đồng bộ." });
  return { id: Number(result[0].insertId) };
}

export async function listManusChangeRequests(limit = 30) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(manusChangeRequests).orderBy(desc(manusChangeRequests.updatedAt)).limit(limit);
}

export async function markManusChangeSynced(id: number, syncSummary: string, localDraft?: string | null) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(manusChangeRequests).set({ status: "synced", syncSummary, localDraft: localDraft ?? null, syncedAt: new Date() }).where(eq(manusChangeRequests.id, id));
  await updateManusConnectionState({ lastSyncStatus: "success", lastSyncMessage: syncSummary, lastSyncVersion: `local-sync-${Date.now()}` });
  return { success: true } as const;
}

export async function approveManusChange(id: number, approvedBy: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(manusChangeRequests).set({ status: "approved", approvedBy, approvedAt: new Date() }).where(and(eq(manusChangeRequests.id, id), eq(manusChangeRequests.status, "synced")));
  return { success: true } as const;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  values.lastSignedIn = user.lastSignedIn ?? new Date(); updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb(); if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1); return result[0];
}

export async function createConsultationRequest(input: InsertConsultationRequest) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(consultationRequests).values(input); return { id: Number(result[0].insertId) };
}

export async function findRecentMarketingConsultation(input: { phone: string; marketingCampaignId?: number; marketingPropertyId?: number; since: Date }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const filters = [eq(consultationRequests.phone, input.phone), gte(consultationRequests.createdAt, input.since)];
  if (input.marketingCampaignId) filters.push(eq(consultationRequests.marketingCampaignId, input.marketingCampaignId));
  if (input.marketingPropertyId) filters.push(eq(consultationRequests.marketingPropertyId, input.marketingPropertyId));
  const rows = await db.select().from(consultationRequests).where(and(...filters)).orderBy(desc(consultationRequests.createdAt)).limit(1);
  return rows[0];
}

export async function listMarketingCampaigns() {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(marketingCampaigns).orderBy(desc(marketingCampaigns.updatedAt));
}

export async function getPublishedPropertyById(id: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(properties).where(and(eq(properties.id, id), eq(properties.status, "published"))).limit(1);
  return rows[0];
}

export async function getMarketingCampaign(id: number) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(marketingCampaigns).where(eq(marketingCampaigns.id, id)).limit(1);
  return rows[0];
}

export async function createMarketingCampaign(input: typeof marketingCampaigns.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(marketingCampaigns).values(input);
  const rows = await db.select().from(marketingCampaigns).where(eq(marketingCampaigns.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function updateMarketingCampaign(id: number, data: Partial<typeof marketingCampaigns.$inferInsert>) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(marketingCampaigns).set(data).where(eq(marketingCampaigns.id, id));
  return getMarketingCampaign(id);
}

export async function listMarketingChannels() {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(marketingChannels).orderBy(asc(marketingChannels.channelType), asc(marketingChannels.name));
}

export async function createMarketingChannel(input: typeof marketingChannels.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(marketingChannels).values(input);
  const rows = await db.select().from(marketingChannels).where(eq(marketingChannels.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function updateMarketingChannel(id: number, data: Partial<typeof marketingChannels.$inferInsert>) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(marketingChannels).set(data).where(eq(marketingChannels.id, id));
  const rows = await db.select().from(marketingChannels).where(eq(marketingChannels.id, id)).limit(1);
  return rows[0];
}

export async function listMarketingContents() {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(marketingContents).orderBy(desc(marketingContents.updatedAt));
}

export async function createMarketingContent(input: typeof marketingContents.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(marketingContents).values(input);
  const rows = await db.select().from(marketingContents).where(eq(marketingContents.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function updateMarketingContent(id: number, data: Partial<typeof marketingContents.$inferInsert>) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(marketingContents).set(data).where(eq(marketingContents.id, id));
  const rows = await db.select().from(marketingContents).where(eq(marketingContents.id, id)).limit(1);
  return rows[0];
}

export async function listMarketingCalendar() {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(marketingContentCalendar).orderBy(asc(marketingContentCalendar.scheduledAt));
}

export async function createMarketingCalendarItem(input: typeof marketingContentCalendar.$inferInsert) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const result = await db.insert(marketingContentCalendar).values(input);
  const rows = await db.select().from(marketingContentCalendar).where(eq(marketingContentCalendar.id, Number(result[0].insertId))).limit(1);
  return rows[0];
}

export async function updateMarketingCalendarItem(id: number, data: Partial<typeof marketingContentCalendar.$inferInsert>) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(marketingContentCalendar).set(data).where(eq(marketingContentCalendar.id, id));
  const rows = await db.select().from(marketingContentCalendar).where(eq(marketingContentCalendar.id, id)).limit(1);
  return rows[0];
}
export async function listConsultationRequests() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(consultationRequests).orderBy(desc(consultationRequests.createdAt)); }
export async function updateConsultationAi(id: number, data: { aiStatus: "pending" | "analyzed" | "failed"; aiPriority?: "high" | "potential" | "reference"; aiSummary?: string | null; aiProfile?: string | null; aiMatches?: string | null; aiAnalyzedAt?: Date | null; aiArea?: string | null; aiScore?: number | null; routingStage?: "unassigned" | "area_queue" | "backup_queue" | "admin_queue"; assignedTo?: number | null; conversationHistory?: string | null }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(consultationRequests).set(data).where(eq(consultationRequests.id, id)); return { success: true } as const; }
export async function getConsultationRequest(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select().from(consultationRequests).where(eq(consultationRequests.id, id)).limit(1); return rows[0]; }
export async function updateConsultationStatus(id: number, status: "new" | "contacted" | "closed") { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(consultationRequests).set({ status }).where(eq(consultationRequests.id, id)); return { success: true } as const; }
export async function deleteConsultationRequest(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const row = await db.select({ id: consultationRequests.id, status: consultationRequests.status }).from(consultationRequests).where(eq(consultationRequests.id, id)).limit(1); if (!row[0]) return { success: false, reason: "not_found" } as const; if (row[0].status === "new") return { success: false, reason: "not_handled" } as const; await db.delete(consultationRequests).where(and(eq(consultationRequests.id, id), or(eq(consultationRequests.status, "contacted"), eq(consultationRequests.status, "closed")))); return { success: true } as const; }

export type PropertyFilters = {
  q?: string;
  propertyType?: "house" | "land" | "apartment" | "villa" | "industrial" | "commercial_land" | "agricultural" | "commercial" | "resort" | "project" | "rental";
  areaId?: number;
  province?: string;
  location?: string;
  minPrice?: number;
  maxPrice?: number;
  minArea?: number;
  maxArea?: number;
  minBedrooms?: number;
  maxBedrooms?: number;
  orientation?: string;
  legalStatus?: string;
  sort?: "newest" | "price_asc" | "price_desc" | "area_desc";
};
const propertyColumns = getTableColumns(properties);
export const PUBLIC_PROPERTY_STATUS = "published" as const;
export function isPublicPropertyStatus(status: string) { return status === PUBLIC_PROPERTY_STATUS; }

/** Chỉ trả ảnh marketing/hiển thị; URL đã đăng ký trong legalDocumentScans luôn bị loại khỏi public. */
async function getPublicImagesForProperty(propertyId: number, db: NonNullable<Awaited<ReturnType<typeof getDb>>>, limit?: number) {
  const [images, legalScans] = await Promise.all([
    db.select({ url: propertyImages.url }).from(propertyImages).where(eq(propertyImages.propertyId, propertyId)).orderBy(propertyImages.sortOrder),
    db.select({ imageUrl: legalDocumentScans.imageUrl }).from(legalDocumentScans).where(eq(legalDocumentScans.propertyId, propertyId)),
  ]);
  const legalUrls = new Set(legalScans.map(scan => scan.imageUrl).filter((url): url is string => Boolean(url)));
  const publicImages = images.filter(image => !legalUrls.has(image.url));
  return limit === undefined ? publicImages : publicImages.slice(0, limit);
}

export async function listPublishedProperties(filters: PropertyFilters = {}) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const conditions = [eq(properties.status, PUBLIC_PROPERTY_STATUS), gt(properties.price, "0"), gt(properties.area, "0"), ne(properties.title, "unknown"), ne(properties.title, "Chưa xác định"), ne(properties.location, "unknown"), ne(properties.location, "Unknown"), ne(properties.location, "Chưa xác định"), ne(properties.location, "Chưa cập nhật")];
  if (filters.propertyType) conditions.push(eq(properties.propertyType, filters.propertyType));
  if (filters.areaId !== undefined) conditions.push(eq(properties.areaId, filters.areaId));
  if (filters.province) conditions.push(like(areas.province, `%${filters.province}%`));
  if (filters.location) conditions.push(like(properties.location, `%${filters.location}%`));
  if (filters.q) {
    const query = `%${filters.q}%`;
    conditions.push(or(like(properties.title, query), like(properties.propertyCode, query), like(properties.location, query), like(properties.description, query))!);
  }
  if (filters.minBedrooms !== undefined) conditions.push(gte(properties.bedrooms, filters.minBedrooms));
  if (filters.maxBedrooms !== undefined) conditions.push(lte(properties.bedrooms, filters.maxBedrooms));
  if (filters.orientation) conditions.push(like(properties.orientation, `%${filters.orientation}%`));
  if (filters.legalStatus) conditions.push(like(properties.legalStatus, `%${filters.legalStatus}%`));
  if (filters.minPrice !== undefined) conditions.push(gte(properties.price, String(filters.minPrice)));
  if (filters.maxPrice !== undefined) conditions.push(lte(properties.price, String(filters.maxPrice)));
  if (filters.minArea !== undefined) conditions.push(gte(properties.area, String(filters.minArea)));
  if (filters.maxArea !== undefined) conditions.push(lte(properties.area, String(filters.maxArea)));
  const orderBy = filters.sort === "price_asc"
    ? [asc(properties.price)]
    : filters.sort === "price_desc"
      ? [desc(properties.price)]
      : filters.sort === "area_desc"
        ? [desc(properties.area)]
        : [desc(properties.featured), desc(properties.createdAt)];
  const rows = await db.select({ ...propertyColumns, areaName: areas.name, areaProvince: areas.province }).from(properties).leftJoin(areas, eq(properties.areaId, areas.id)).where(and(...conditions)).orderBy(...orderBy);
  return Promise.all(rows.map(async row => {
    const images = await getPublicImagesForProperty(row.id, db, 4);
    return { ...row, imageUrl: images[0]?.url || null, imageUrls: images.map(image => image.url) };
  }));
}
async function hydratePropertyImages<T extends { id: number }>(rows: T[], db: NonNullable<Awaited<ReturnType<typeof getDb>>>) {
  return Promise.all(rows.map(async row => {
    const images = await getPublicImagesForProperty(row.id, db, 4);
    return { ...row, imageUrl: images[0]?.url || null, imageUrls: images.map(image => image.url) };
  }));
}
export async function listFeaturedProperties(limit = 6) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select({ ...propertyColumns, areaName: areas.name, areaProvince: areas.province }).from(properties).leftJoin(areas, eq(properties.areaId, areas.id)).where(and(eq(properties.status, PUBLIC_PROPERTY_STATUS), gt(properties.price, "0"), gt(properties.area, "0"), ne(properties.title, "unknown"), ne(properties.title, "Chưa xác định"), ne(properties.location, "unknown"), ne(properties.location, "Unknown"), ne(properties.location, "Chưa xác định"), ne(properties.location, "Chưa cập nhật"), eq(properties.featured, 1))).orderBy(desc(properties.createdAt)).limit(limit); return hydratePropertyImages(rows, db); }
export async function listLatestPublishedProperties(limit = 6) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select({ ...propertyColumns, areaName: areas.name, areaProvince: areas.province }).from(properties).leftJoin(areas, eq(properties.areaId, areas.id)).where(and(eq(properties.status, PUBLIC_PROPERTY_STATUS), gt(properties.price, "0"), gt(properties.area, "0"), ne(properties.title, "unknown"), ne(properties.title, "Chưa xác định"), ne(properties.location, "unknown"), ne(properties.location, "Unknown"), ne(properties.location, "Chưa xác định"), ne(properties.location, "Chưa cập nhật"))).orderBy(desc(properties.createdAt)).limit(limit); return hydratePropertyImages(rows, db); }
export async function listAreas() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(areas).orderBy(areas.province, areas.name); }
export async function getPublishedProperty(slug: string) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.select().from(properties).where(and(eq(properties.slug, slug), eq(properties.status, PUBLIC_PROPERTY_STATUS), gt(properties.price, "0"), gt(properties.area, "0"), ne(properties.title, "unknown"), ne(properties.title, "Chưa xác định"), ne(properties.location, "unknown"), ne(properties.location, "Unknown"), ne(properties.location, "Chưa xác định"), ne(properties.location, "Chưa cập nhật"))).limit(1); return result[0]; }
export async function getPublishedPropertyWithImages(slug: string) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const property = await getPublishedProperty(slug); if (!property) return undefined; const publicImages = await getPublicImagesForProperty(property.id, db); const publicUrls = new Set(publicImages.map(image => image.url)); const images = (await db.select().from(propertyImages).where(eq(propertyImages.propertyId, property.id)).orderBy(propertyImages.sortOrder)).filter(image => publicUrls.has(image.url)); return { property, images }; }
export async function listProperties() { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select({ ...propertyColumns, areaName: areas.name, areaProvince: areas.province }).from(properties).leftJoin(areas, eq(properties.areaId, areas.id)).orderBy(desc(properties.createdAt)); return hydratePropertyImages(rows, db); }
export async function listPropertiesByCreator(createdBy: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select({ ...propertyColumns, areaName: areas.name, areaProvince: areas.province }).from(properties).leftJoin(areas, eq(properties.areaId, areas.id)).where(eq(properties.createdBy, createdBy)).orderBy(desc(properties.createdAt)); return hydratePropertyImages(rows, db); }
export async function listLegalDocumentScans(propertyId: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(legalDocumentScans).where(eq(legalDocumentScans.propertyId, propertyId)).orderBy(desc(legalDocumentScans.createdAt)); }
export async function createLegalDocumentScan(input: typeof legalDocumentScans.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalDocumentScans).values(input); return { id: Number(result[0].insertId) }; }
export async function confirmLegalDocumentScan(id: number, propertyId: number, data: { legalStatus?: string | null; certificateType?: string | null; certificateArea?: string | null; landUsePurpose?: string | null; planningStatus?: string | null; mortgageStatus?: string | null; legalSource?: string | null }, reviewedBy: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const scan = await db.select({ id: legalDocumentScans.id }).from(legalDocumentScans).where(and(eq(legalDocumentScans.id, id), eq(legalDocumentScans.propertyId, propertyId))).limit(1); if (!scan[0]) return { success: false, reason: "not_found" } as const; await db.update(properties).set(data).where(eq(properties.id, propertyId)); await db.update(legalDocumentScans).set({ status: "confirmed", reviewedBy, reviewedAt: new Date() }).where(eq(legalDocumentScans.id, id)); return { success: true } as const; }
export async function rejectLegalDocumentScan(id: number, propertyId: number, reviewedBy: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(legalDocumentScans).set({ status: "rejected", reviewedBy, reviewedAt: new Date() }).where(and(eq(legalDocumentScans.id, id), eq(legalDocumentScans.propertyId, propertyId))); return { success: true } as const; }
export function buildPropertyCode(id: number) { return `BDS-${String(id).padStart(6, "0")}`; }

export async function createProperty(input: InsertProperty) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(properties).values(input); const id = Number(result[0].insertId); const propertyCode = input.propertyCode?.trim() || buildPropertyCode(id); if (!input.propertyCode?.trim()) await db.update(properties).set({ propertyCode }).where(eq(properties.id, id)); return { id, propertyCode }; }
export async function updateProperty(id: number, requesterId: number | undefined, input: Partial<InsertProperty>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const current = await db.select({ id: properties.id, createdBy: properties.createdBy }).from(properties).where(eq(properties.id, id)).limit(1); if (!current[0]) return { success: false, reason: "not_found" } as const; if (requesterId !== undefined && current[0].createdBy !== requesterId) return { success: false, reason: "forbidden" } as const; await db.update(properties).set({ ...input, updatedAt: new Date() }).where(eq(properties.id, id)); return { success: true } as const; }
export async function createPropertyImage(input: { propertyId: number; url: string; mediaType?: "image" | "video"; altText?: string | null; sortOrder?: number }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.insert(propertyImages).values({ propertyId: input.propertyId, url: input.url, altText: input.altText || null, sortOrder: input.sortOrder || 0 }); return { success: true } as const; }
export async function updatePropertyStatus(id: number, status: "draft" | "published" | "reserved" | "sold") { const db = await getDb(); if (!db) throw new Error("Database is not available"); if (status === "published") { const row = (await db.select({ title: properties.title, price: properties.price, area: properties.area, location: properties.location }).from(properties).where(eq(properties.id, id)).limit(1))[0]; if (!row) return { success: false, reason: "not_found" } as const; const normalizedLocation = row.location.trim().toLowerCase(); const incomplete = Number(row.price) <= 0 || Number(row.area) <= 0 || !normalizedLocation || ["unknown", "chưa xác định", "chưa cập nhật"].some(value => normalizedLocation === value || normalizedLocation.startsWith(`${value} ·`)); if (incomplete) return { success: false, reason: "incomplete" } as const; } const featured = status === "published" ? 1 : 0; await db.update(properties).set({ status, featured }).where(eq(properties.id, id)); return { success: true, featured } as const; }
export async function deleteProperty(id: number, requesterId?: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const property = await db.select({ id: properties.id, createdBy: properties.createdBy, status: properties.status }).from(properties).where(eq(properties.id, id)).limit(1); const row = property[0]; if (!row) return { success: false, reason: "not_found" } as const; if (requesterId !== undefined && (row.createdBy !== requesterId || row.status !== "draft")) return { success: false, reason: "forbidden" } as const; const [linkedDeal, linkedLegal, linkedValuation, linkedSurvey] = await Promise.all([db.select({ id: deals.id }).from(deals).where(eq(deals.propertyId, id)).limit(1), db.select({ id: legalChecks.id }).from(legalChecks).where(eq(legalChecks.propertyId, id)).limit(1), db.select({ id: valuations.id }).from(valuations).where(eq(valuations.propertyId, id)).limit(1), db.select({ id: surveys.id }).from(surveys).where(eq(surveys.propertyId, id)).limit(1)]); if (linkedDeal[0] || linkedLegal[0] || linkedValuation[0] || linkedSurvey[0]) return { success: false, reason: "linked_records" } as const; await db.delete(propertyImages).where(eq(propertyImages.propertyId, id)); await db.delete(properties).where(eq(properties.id, id)); return { success: true } as const; }
export async function listOwners() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(propertyOwners).orderBy(desc(propertyOwners.createdAt)); }
export async function createOwner(input: typeof propertyOwners.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(propertyOwners).values(input); return { id: Number(result[0].insertId) }; }
export async function listBuyerLeads() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(buyerLeads).orderBy(desc(buyerLeads.createdAt)); }
export async function createBuyerLead(input: typeof buyerLeads.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(buyerLeads).values(input); return { id: Number(result[0].insertId) }; }
export async function listSurveys() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(surveys).orderBy(desc(surveys.createdAt)); }
export async function createSurvey(input: typeof surveys.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(surveys).values(input); return { id: Number(result[0].insertId) }; }
export async function listLegalChecks() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(legalChecks).orderBy(desc(legalChecks.createdAt)); }
export async function createLegalCheck(input: typeof legalChecks.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalChecks).values(input); return { id: Number(result[0].insertId) }; }
export async function listValuations() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select().from(valuations).orderBy(desc(valuations.assessedAt)); }
export async function createValuation(input: typeof valuations.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(valuations).values(input); return { id: Number(result[0].insertId) }; }
export async function listDeals() { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select({ deal: deals, property: properties, dossier: propertyDossiers }).from(deals).innerJoin(properties, eq(deals.propertyId, properties.id)).leftJoin(propertyDossiers, eq(propertyDossiers.propertyId, properties.id)).orderBy(desc(deals.updatedAt)); return rows.map(row => ({ ...row.deal, property: row.property, dossier: row.dossier })); }
export async function ensureDealForSoldProperty(propertyId: number, assignedTo: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const property = (await db.select({ id: properties.id, propertyCode: properties.propertyCode, title: properties.title, price: properties.price, location: properties.location, ownerName: properties.ownerName }).from(properties).where(and(eq(properties.id, propertyId), eq(properties.status, "sold"))).limit(1))[0]; if (!property) return { success: false, reason: "not_sold" } as const; const existing = (await db.select({ id: deals.id, transactionCode: deals.transactionCode, stage: deals.stage }).from(deals).where(and(eq(deals.propertyId, propertyId), ne(deals.stage, "cancelled"))).orderBy(desc(deals.updatedAt)).limit(1))[0]; if (existing) return { success: true, created: false, dealId: existing.id, transactionCode: existing.transactionCode, stage: existing.stage } as const; const result = await db.insert(deals).values({ propertyId, assignedTo, stage: "new", agreedPrice: property.price, ownerId: null, notes: "Tự động nhận từ BĐS đã bán trong phần bán hàng." }); const dealId = Number(result[0].insertId); const transactionCode = "GD-" + new Date().getFullYear() + "-" + String(dealId).padStart(5, "0"); await db.update(deals).set({ transactionCode }).where(eq(deals.id, dealId)); return { success: true, created: true, dealId, transactionCode, stage: "new" as const, propertyCode: property.propertyCode, title: property.title, location: property.location, ownerName: property.ownerName } as const; }
export async function listSoldPropertiesForTransaction() { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select({ property: properties, dossier: propertyDossiers }).from(properties).leftJoin(propertyDossiers, eq(propertyDossiers.propertyId, properties.id)).where(eq(properties.status, "sold")).orderBy(desc(properties.updatedAt)); return rows.map(row => ({ ...row.property, dossier: row.dossier })); }
export async function createDeal(input: typeof deals.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const property = await db.select({ id: properties.id, status: properties.status }).from(properties).where(eq(properties.id, input.propertyId)).limit(1); if (!property[0]) throw new Error("Không tìm thấy BĐS trong Nguồn hàng."); if (input.stage !== "cancelled") { const active = await db.select({ id: deals.id }).from(deals).where(and(eq(deals.propertyId, input.propertyId), ne(deals.stage, "completed"), ne(deals.stage, "cancelled"))).limit(1); if (active[0]) throw new Error("BĐS này đã có giao dịch đang xử lý."); } const result = await db.insert(deals).values(input); const id = Number(result[0].insertId); const transactionCode = input.transactionCode?.trim() || `GD-${new Date().getFullYear()}-${String(id).padStart(5, "0")}`; if (!input.transactionCode?.trim()) await db.update(deals).set({ transactionCode }).where(eq(deals.id, id)); if (input.stage === "completed") await db.update(properties).set({ status: "sold" }).where(eq(properties.id, input.propertyId)); return { id, transactionCode }; }
export async function getDeal(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select().from(deals).where(eq(deals.id, id)).limit(1); return rows[0]; }
export async function updateDeal(id: number, input: Partial<typeof deals.$inferInsert>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const existing = await db.select({ id: deals.id, propertyId: deals.propertyId }).from(deals).where(eq(deals.id, id)).limit(1); if (!existing[0]) return { success: false, reason: "not_found" } as const; await db.update(deals).set({ ...input, updatedAt: new Date() }).where(eq(deals.id, id)); if (input.stage === "completed") await db.update(properties).set({ status: "sold" }).where(eq(properties.id, existing[0].propertyId)); return { success: true } as const; }

export async function listPropertyDossiers() { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select({ dossier: propertyDossiers, property: properties }).from(propertyDossiers).innerJoin(properties, eq(propertyDossiers.propertyId, properties.id)).orderBy(desc(propertyDossiers.updatedAt)); }
export async function listPropertyDossiersForUser(input: { userId: number; isAdmin: boolean }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); return db.select({ dossier: propertyDossiers, property: properties }).from(propertyDossiers).innerJoin(properties, eq(propertyDossiers.propertyId, properties.id)).where(input.isAdmin ? undefined : eq(properties.createdBy, input.userId)).orderBy(desc(propertyDossiers.updatedAt)); }
export async function getPropertyDossier(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const dossier = await db.select({ dossier: propertyDossiers, property: properties }).from(propertyDossiers).innerJoin(properties, eq(propertyDossiers.propertyId, properties.id)).where(eq(propertyDossiers.id, id)).limit(1); if (!dossier[0]) return undefined; const [steps, documents] = await Promise.all([db.select().from(propertyDossierSteps).where(eq(propertyDossierSteps.dossierId, id)).orderBy(propertyDossierSteps.stepNumber), db.select().from(propertyDossierDocuments).where(eq(propertyDossierDocuments.dossierId, id)).orderBy(desc(propertyDossierDocuments.createdAt))]); return { ...dossier[0], steps, documents }; }
export async function createPropertyDossier(input: { propertyId: number; createdBy: number; assignedTo?: number | null }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(propertyDossiers).values(input); const dossierId = Number(result[0].insertId); await db.insert(propertyDossierSteps).values(Array.from({ length: 12 }, (_, index) => ({ dossierId, stepNumber: index + 1, status: "not_started" as const }))); return { id: dossierId }; }
export async function ensurePropertyDossier(input: { propertyId: number; createdBy: number; assignedTo?: number | null }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const existing = await db.select({ id: propertyDossiers.id }).from(propertyDossiers).where(eq(propertyDossiers.propertyId, input.propertyId)).limit(1); if (existing[0]) return { id: existing[0].id, created: false as const }; try { const result = await db.insert(propertyDossiers).values(input); const dossierId = Number(result[0].insertId); await db.insert(propertyDossierSteps).values(Array.from({ length: 12 }, (_, index) => ({ dossierId, stepNumber: index + 1, status: "not_started" as const }))); return { id: dossierId, created: true as const }; } catch (error) { const duplicateKey = typeof error === "object" && error !== null && "errno" in error && (error as { errno?: unknown }).errno === 1062; if (!duplicateKey) throw error; const concurrent = await db.select({ id: propertyDossiers.id }).from(propertyDossiers).where(eq(propertyDossiers.propertyId, input.propertyId)).limit(1); if (concurrent[0]) return { id: concurrent[0].id, created: false as const }; throw error; } }
export async function updatePropertyDossier(id: number, input: { status?: "active" | "completed" | "paused"; currentStep?: number; assignedTo?: number | null; notes?: string | null }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(propertyDossiers).set(input).where(eq(propertyDossiers.id, id)); return { success: true } as const; }
export async function deletePropertyDossier(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const existing = await db.select({ id: propertyDossiers.id }).from(propertyDossiers).where(eq(propertyDossiers.id, id)).limit(1); if (!existing[0]) return { success: false, reason: "not_found" } as const; const documents = await db.select({ storageKey: propertyDossierDocuments.storageKey }).from(propertyDossierDocuments).where(eq(propertyDossierDocuments.dossierId, id)); await db.delete(propertyDossierDocuments).where(eq(propertyDossierDocuments.dossierId, id)); for (const document of documents) await db.delete(propertyArchiveFiles).where(eq(propertyArchiveFiles.storageKey, document.storageKey)); await db.delete(propertyDossierSteps).where(eq(propertyDossierSteps.dossierId, id)); await db.delete(propertyDossiers).where(eq(propertyDossiers.id, id)); return { success: true } as const; }
export async function updatePropertyDossierStep(id: number, input: { status: "completed" | "in_progress" | "not_started" | "needs_review"; details?: string | null; notes?: string | null; updatedBy: number }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(propertyDossierSteps).set({ ...input, completedAt: input.status === "completed" ? new Date() : null }).where(eq(propertyDossierSteps.id, id)); return { success: true } as const; }
export async function createPropertyDossierDocument(input: typeof propertyDossierDocuments.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const dossier = await db.select({ propertyId: propertyDossiers.propertyId }).from(propertyDossiers).where(eq(propertyDossiers.id, input.dossierId)).limit(1); if (!dossier[0]) throw new Error("Dossier not found"); const result = await db.insert(propertyDossierDocuments).values(input); const category = input.stepNumber >= 11 ? "transaction" : input.stepNumber === 4 || input.stepNumber === 5 ? "legal" : input.stepNumber === 6 ? "valuation" : input.stepNumber >= 8 ? "marketing" : "property"; await db.insert(propertyArchiveFiles).values({ propertyId: dossier[0].propertyId, category, documentType: `Quy trình 12 bước · Bước ${input.stepNumber}`, fileName: input.fileName, mimeType: input.mimeType, url: input.url, storageKey: input.storageKey, uploadedBy: input.uploadedBy ?? null }); return { id: Number(result[0].insertId) }; }
export async function deletePropertyDossierDocument(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const existing = await db.select({ storageKey: propertyDossierDocuments.storageKey }).from(propertyDossierDocuments).where(eq(propertyDossierDocuments.id, id)).limit(1); if (!existing[0]) return { success: false, reason: "not_found" } as const; await db.delete(propertyDossierDocuments).where(eq(propertyDossierDocuments.id, id)); await db.delete(propertyArchiveFiles).where(eq(propertyArchiveFiles.storageKey, existing[0].storageKey)); return { success: true } as const; }

export async function updatePropertyLocation(id: number, input: { location: string; latitude: string | null; longitude: string | null; mapVisibility: "approximate" | "exact" | "private" }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(properties).set(input).where(eq(properties.id, id)); return { success: true } as const; }
export async function listPropertyArchiveFiles(input?: { propertyId?: number; category?: "property" | "legal" | "valuation" | "marketing" | "transaction"; search?: string }) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const filters = []; if (input?.propertyId) filters.push(eq(propertyArchiveFiles.propertyId, input.propertyId)); if (input?.category) filters.push(eq(propertyArchiveFiles.category, input.category)); if (input?.search) filters.push(or(like(propertyArchiveFiles.fileName, `%${input.search}%`), like(propertyArchiveFiles.documentType, `%${input.search}%`))); return db.select({ file: propertyArchiveFiles, property: properties }).from(propertyArchiveFiles).innerJoin(properties, eq(propertyArchiveFiles.propertyId, properties.id)).where(filters.length ? and(...filters) : undefined).orderBy(desc(propertyArchiveFiles.updatedAt)); }
export async function createPropertyArchiveFile(input: typeof propertyArchiveFiles.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(propertyArchiveFiles).values(input); return { id: Number(result[0].insertId) }; }
export async function renamePropertyArchiveFile(id: number, fileName: string, documentType?: string) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(propertyArchiveFiles).set({ fileName, ...(documentType ? { documentType } : {}) }).where(eq(propertyArchiveFiles.id, id)); return { success: true } as const; }
export async function deletePropertyArchiveFile(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.delete(propertyArchiveFiles).where(eq(propertyArchiveFiles.id, id)); return { success: true } as const; }

export async function getDashboardSummary() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const now = new Date();
  const startOfDay = new Date(now);
  startOfDay.setHours(0, 0, 0, 0);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const [
    propertyStatusRows,
    buyerTotalRows,
    buyerNewRows,
    dealStageRows,
    dealValueRows,
    completedDealValueRows,
    dossierStatusRows,
    todayConsultations,
    todayBuyerLeads,
    todayDeals,
    qualifiedBuyerLeads,
    activeDossiers,
  ] = await Promise.all([
    db.select({ status: properties.status, count: count() }).from(properties).groupBy(properties.status),
    db.select({ count: count() }).from(buyerLeads),
    db.select({ count: count() }).from(buyerLeads).where(gte(buyerLeads.createdAt, startOfMonth)),
    db.select({ stage: deals.stage, count: count() }).from(deals).groupBy(deals.stage),
    db.select({ value: sum(deals.agreedPrice) }).from(deals).where(ne(deals.stage, "cancelled")),
    db.select({ value: sum(deals.agreedPrice) }).from(deals).where(eq(deals.stage, "completed")),
    db.select({ status: propertyDossiers.status, count: count() }).from(propertyDossiers).groupBy(propertyDossiers.status),
    db.select({ id: consultationRequests.id, name: consultationRequests.name, interest: consultationRequests.interest, createdAt: consultationRequests.createdAt }).from(consultationRequests).where(and(eq(consultationRequests.status, "new"), gte(consultationRequests.createdAt, startOfDay))).orderBy(desc(consultationRequests.createdAt)).limit(5),
    db.select({ id: buyerLeads.id, name: buyerLeads.name, propertyType: buyerLeads.propertyType, preferredArea: buyerLeads.preferredArea, status: buyerLeads.status, createdAt: buyerLeads.createdAt }).from(buyerLeads).where(gte(buyerLeads.createdAt, startOfDay)).orderBy(desc(buyerLeads.createdAt)).limit(5),
    db.select({ id: deals.id, propertyId: deals.propertyId, stage: deals.stage, updatedAt: deals.updatedAt }).from(deals).where(and(ne(deals.stage, "completed"), ne(deals.stage, "cancelled"), gte(deals.updatedAt, startOfDay))).orderBy(desc(deals.updatedAt)).limit(5),
    db.select({ id: buyerLeads.id, name: buyerLeads.name, propertyType: buyerLeads.propertyType, preferredArea: buyerLeads.preferredArea, status: buyerLeads.status, budget: buyerLeads.budget }).from(buyerLeads).where(or(eq(buyerLeads.status, "qualified"), eq(buyerLeads.status, "viewing"))).orderBy(desc(buyerLeads.updatedAt)).limit(3),
    db.select({ id: propertyDossiers.id, propertyId: propertyDossiers.propertyId, currentStep: propertyDossiers.currentStep, status: propertyDossiers.status, updatedAt: propertyDossiers.updatedAt }).from(propertyDossiers).where(eq(propertyDossiers.status, "active")).orderBy(desc(propertyDossiers.updatedAt)).limit(5),
  ]);

  const statusCount = (rows: Array<{ status: string; count: number }>, status: string) => Number(rows.find(row => row.status === status)?.count ?? 0);
  const stageCount = (stage: string) => Number(dealStageRows.find(row => row.stage === stage)?.count ?? 0);
  const tasks = [
    ...todayConsultations.map(item => ({ id: `consultation-${item.id}`, title: `Gọi lại khách ${item.name}`, meta: `Tư vấn · ${item.interest}`, createdAt: item.createdAt, tone: "rose" as const })),
    ...todayBuyerLeads.map(item => ({ id: `buyer-${item.id}`, title: `Chăm sóc khách ${item.name}`, meta: `Khách mua · ${item.propertyType || "Chưa chọn loại BĐS"}${item.preferredArea ? ` · ${item.preferredArea}` : ""}`, createdAt: item.createdAt, tone: "green" as const })),
    ...todayDeals.map(item => ({ id: `deal-${item.id}`, title: `Theo dõi giao dịch BĐS #${item.propertyId}`, meta: `Giao dịch · ${item.stage}`, createdAt: item.updatedAt, tone: "gold" as const })),
  ].sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()).slice(0, 6);

  return {
    updatedAt: now.toISOString(),
    stats: {
      propertiesForSale: statusCount(propertyStatusRows, "published"),
      customers: Number(buyerTotalRows[0]?.count ?? 0),
      newCustomersThisMonth: Number(buyerNewRows[0]?.count ?? 0),
      activeDeals: Number(dealStageRows.reduce((total, row) => row.stage === "completed" || row.stage === "cancelled" ? total : total + Number(row.count), 0)),
      expectedRevenue: Number(dealValueRows[0]?.value ?? 0),
      completedRevenue: Number(completedDealValueRows[0]?.value ?? 0),
    },
    pipeline: [
      { label: "Tiếp nhận", value: stageCount("new") },
      { label: "Kiểm tra", value: statusCount(dossierStatusRows, "active") },
      { label: "Ký gửi", value: statusCount(propertyStatusRows, "reserved") },
      { label: "Tìm khách", value: stageCount("new") },
      { label: "Đàm phán", value: stageCount("negotiating") },
      { label: "Đặt cọc", value: stageCount("deposit") },
      { label: "Công chứng", value: stageCount("contracted") },
      { label: "Hoàn tất", value: stageCount("completed") },
    ],
    tasks,
    suggestions: qualifiedBuyerLeads.map(item => ({ title: item.name, text: `${item.status === "viewing" ? "Đang xem BĐS" : "Đã đủ điều kiện"}${item.preferredArea ? ` tại ${item.preferredArea}` : ""}. Nên tiếp tục chăm sóc theo nhu cầu đã ghi nhận.`, tag: item.propertyType ? `Nhu cầu ${item.propertyType}` : "Khách tiềm năng" })),
    activeDossiers,
  };
}


export async function listLegalSources() {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  return db.select().from(legalSources).orderBy(desc(legalSources.lastCheckedAt), asc(legalSources.name));
}
export async function touchLegalSource(id: number, checkedAt = new Date()) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  await db.update(legalSources).set({ lastCheckedAt: checkedAt }).where(eq(legalSources.id, id));
  return { success: true } as const;
}

export function mergeLegalProcedureCatalog<T extends { code: string; name: string; groupName: string | null }>(rows: T[], registryRows: T[]) {
  const registryByCode = new Map(registryRows.map(row => [row.code, row]));
  const mergedRows = rows.map(row => {
    const registryRow = registryByCode.get(row.code);
    const hasPlaceholderName = !row.name.trim() || /cần đối soát tên thủ tục|mã tthc/i.test(row.name);
    if (!registryRow || !hasPlaceholderName) return row;
    return { ...row, name: registryRow.name, groupName: row.groupName ?? registryRow.groupName } as T;
  });
  const dbCodes = new Set(rows.map(row => row.code));
  return [...mergedRows, ...registryRows.filter(row => !dbCodes.has(row.code))]
    .sort((a, b) => `${a.groupName ?? ""}:${a.name}`.localeCompare(`${b.groupName ?? ""}:${b.name}`, "vi"));
}

export async function listLegalProcedures(query?: string) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const normalizedQuery = query?.trim().toLocaleLowerCase("vi");
  const rows = normalizedQuery ? await db.select().from(legalProcedures).where(or(like(legalProcedures.name, `%${query!.trim()}%`), like(legalProcedures.code, `%${query!.trim()}%`), like(legalProcedures.aliases, `%${query!.trim()}%`))).orderBy(asc(legalProcedures.groupName), asc(legalProcedures.name)) : await db.select().from(legalProcedures).where(eq(legalProcedures.status, "active")).orderBy(asc(legalProcedures.groupName), asc(legalProcedures.name));

  // The registry is a verification seed, not the complete catalog. Always
  // merge its entries into the database catalog so the selector can expose
  // every materialized land procedure while retaining the 11-code regression
  // set even before those rows are materialized.
  const registryRows = listOfficialLandProcedures()
    .filter(item => !normalizedQuery || [item.code, item.name, ...item.aliases].some(value => value.toLocaleLowerCase("vi").includes(normalizedQuery)))
    .map((item, index) => ({
      id: -(index + 1),
      code: item.code,
      name: item.name,
      groupName: item.groupName,
      aliases: JSON.stringify(item.aliases),
      authority: item.authority,
      defaultProvince: null,
      processingTime: null,
      feeNotes: null,
      conditions: null,
      workflow: JSON.stringify(item.workflowSteps ?? []),
      status: "active" as const,
      sourceDocumentIds: null,
      lastReviewedAt: new Date(item.checkedAt),
      createdAt: new Date(item.checkedAt),
      updatedAt: new Date(item.checkedAt),
    }));
  const registryCodes = new Set(registryRows.map(row => row.code));
  const appendixRows = OFFICIAL_2304_PROCEDURE_CODES
    .filter(code => !registryCodes.has(code))
    .filter(code => {
      const verifiedName = getVerified2304ProcedureName(code);
      return !normalizedQuery || code.toLocaleLowerCase("vi").includes(normalizedQuery) || verifiedName?.toLocaleLowerCase("vi").includes(normalizedQuery);
    })
    .map((code, index) => ({
      id: -(registryRows.length + index + 1),
      code,
      name: getVerified2304ProcedureName(code) ?? `Thủ tục đất đai mã ${code} — cần đối soát tên chính thức`,
      groupName: "Đất đai — Phụ lục 2304",
      aliases: JSON.stringify([]),
      authority: "Bộ Nông nghiệp và Môi trường",
      defaultProvince: null,
      processingTime: null,
      feeNotes: null,
      conditions: null,
      workflow: JSON.stringify([]),
      status: "active" as const,
      sourceDocumentIds: null,
      lastReviewedAt: null,
      createdAt: new Date(0),
      updatedAt: new Date(0),
      catalogNotice: OFFICIAL_2304_CODE_INDEX_NOTICE,
    }));
  return mergeLegalProcedureCatalog(rows, [...registryRows, ...appendixRows]);
}

export async function getLegalProcedureBundle(code: string) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const normalizedCode = code.trim().replace(/\s+/g, "");
  const registryProcedure = getOfficialLandProcedure(normalizedCode);
  const canonicalCode = registryProcedure?.code || normalizedCode;
  const externalCodes = registryProcedure && "externalCodes" in registryProcedure ? registryProcedure.externalCodes ?? [] : [];
  const procedureCodes = Array.from(new Set([canonicalCode, normalizedCode, ...externalCodes].filter((item): item is string => Boolean(item))));
  const procedureRows = await db.select().from(legalProcedures).where(or(...procedureCodes.map(item => eq(legalProcedures.code, item))));
  const procedure = procedureRows.find(item => item.code === registryProcedure?.code) ?? procedureRows[0];
  if (!procedure) return undefined;
  // The selected procedure is canonical. Alias rows are used only to resolve
  // the code; they must not contribute legacy requirements/templates to the
  // active bundle, otherwise old sources can intermittently replace or mix
  // with the current procedure data.
  const canonicalProcedureId = procedure.id;
  const requirements = await db.select().from(legalProcedureRequirements)
    .where(eq(legalProcedureRequirements.procedureId, canonicalProcedureId))
    .orderBy(asc(legalProcedureRequirements.sortOrder));
  const templates = await db.select().from(legalTemplates)
    .where(and(eq(legalTemplates.procedureId, canonicalProcedureId), eq(legalTemplates.status, "active")))
    .orderBy(asc(legalTemplates.name));
  const sourceDocumentIds = Array.from(new Set([
    ...(procedure.sourceDocumentIds ? JSON.parse(procedure.sourceDocumentIds) as number[] : []),
    ...requirements.map(item => item.sourceDocumentId).filter((id): id is number => Boolean(id)),
    ...templates.map(item => item.sourceDocumentId).filter((id): id is number => Boolean(id)),
  ]));
  const documents = sourceDocumentIds.length ? await db.select().from(legalDocuments).where(or(...sourceDocumentIds.map(id => eq(legalDocuments.id, id)))) : [];
  const sourceIds = Array.from(new Set([...templates.map(item => item.sourceId), ...documents.map(item => item.sourceId)]));
  const sources = sourceIds.length ? await db.select().from(legalSources).where(or(...sourceIds.map(id => eq(legalSources.id, id)))) : [];
  return { procedure, requirements, templates, documents, sources };
}

export async function listLegalTemplates(filters?: { province?: string; receivingAuthority?: string; jurisdictionScope?: "national" | "provincial" | "district" | "commune" | "agency_specific"; procedureId?: number; procedureCode?: string; query?: string }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const conditions = [];
  if (filters?.procedureCode && !filters.procedureId) {
    const registryProcedure = getOfficialLandProcedure(filters.procedureCode);
    const externalCodes = registryProcedure && "externalCodes" in registryProcedure ? registryProcedure.externalCodes ?? [] : [];
    const procedureCodes = Array.from(new Set([filters.procedureCode.trim().replace(/\s+/g, ""), registryProcedure?.code, ...externalCodes].filter((code): code is string => Boolean(code))));
    const procedures = await db.select({ id: legalProcedures.id, code: legalProcedures.code }).from(legalProcedures).where(or(...procedureCodes.map(code => eq(legalProcedures.code, code))));
    const canonicalProcedure = procedures.find(procedure => procedure.code === registryProcedure?.code) ?? procedures[0];
    if (canonicalProcedure) conditions.push(eq(legalTemplates.procedureId, canonicalProcedure.id));
    else return [];
  }
  if (filters?.province) conditions.push(or(eq(legalTemplates.province, filters.province), eq(legalTemplates.jurisdictionScope, "national")));
  if (filters?.receivingAuthority) conditions.push(or(eq(legalTemplates.receivingAuthority, filters.receivingAuthority), eq(legalTemplates.jurisdictionScope, "national")));
  if (filters?.jurisdictionScope) conditions.push(eq(legalTemplates.jurisdictionScope, filters.jurisdictionScope));
  if (filters?.procedureId) conditions.push(eq(legalTemplates.procedureId, filters.procedureId));
  if (filters?.query) conditions.push(or(like(legalTemplates.name, `%${filters.query}%`), like(legalTemplates.documentType, `%${filters.query}%`)));
  const where = conditions.length ? and(...conditions) : undefined;
  return db.select({ template: legalTemplates, sourceName: legalSources.name }).from(legalTemplates).leftJoin(legalSources, eq(legalTemplates.sourceId, legalSources.id)).where(where).orderBy(desc(legalTemplates.updatedAt));
}

export async function suggestLegalTemplates(input: { procedureId: number; province?: string; receivingAuthority?: string }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const procedure = (await db.select().from(legalProcedures).where(eq(legalProcedures.id, input.procedureId)).limit(1))[0];
  if (!procedure) return [];
  const requirements = await db.select().from(legalProcedureRequirements).where(eq(legalProcedureRequirements.procedureId, input.procedureId)).orderBy(asc(legalProcedureRequirements.sortOrder));
  const templates = await db.select().from(legalTemplates).where(and(eq(legalTemplates.procedureId, input.procedureId), eq(legalTemplates.status, "active")));
  const sourceIds = Array.from(new Set([...(procedure.sourceDocumentIds ? JSON.parse(procedure.sourceDocumentIds) as number[] : []), ...requirements.map(item => item.sourceDocumentId).filter((id): id is number => Boolean(id)), ...templates.map(item => item.sourceDocumentId).filter((id): id is number => Boolean(id))]));
  const documents = sourceIds.length ? await db.select().from(legalDocuments).where(or(...sourceIds.map(id => eq(legalDocuments.id, id)))) : [];
  return matchLegalTemplatesByEvidence({ procedure, requirements, documents, templates, province: input.province, receivingAuthority: input.receivingAuthority });
}

export async function createLegalSource(input: typeof legalSources.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalSources).values(input); return { id: Number(result[0].insertId) }; }
export async function upsertLegalSource(input: { name: string; baseUrl: string; sourceType: "government" | "public_service" | "local_authority" | "official_gazette" | "other"; jurisdiction?: string; notes?: string }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: legalSources.id }).from(legalSources).where(eq(legalSources.baseUrl, input.baseUrl)).limit(1);
  const values = { ...input, jurisdiction: input.jurisdiction ?? null, notes: input.notes ?? null, active: 1 as const };
  if (existing[0]) { await db.update(legalSources).set(values).where(eq(legalSources.id, existing[0].id)); return { id: existing[0].id, created: false } as const; }
  const result = await db.insert(legalSources).values(values); return { id: Number(result[0].insertId), created: true } as const;
}
export async function createLegalProcedure(input: typeof legalProcedures.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalProcedures).values(input); return { id: Number(result[0].insertId) }; }

/** Materialize một thủ tục đã có trong registry để các template Official có khóa ngoại thật. */
export async function ensureLegalProcedureFromRegistry(code: string) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const normalizedCode = code.trim().replace(/\s+/g, "");
  const registryItem = getOfficialLandProcedure(normalizedCode);
  const canonicalCode = registryItem?.code || normalizedCode;
  const item = listOfficialLandProcedures().find(entry => entry.code === canonicalCode || ("externalCodes" in entry && entry.externalCodes?.includes(normalizedCode)));
  const appendixCode = OFFICIAL_2304_PROCEDURE_CODES.find(entry => entry === canonicalCode || entry === normalizedCode);
  const verifiedName = item?.name ?? registryItem?.name ?? (appendixCode ? getVerified2304ProcedureName(appendixCode) : undefined);
  const existing = await db.select().from(legalProcedures).where(or(eq(legalProcedures.code, canonicalCode), eq(legalProcedures.code, normalizedCode))).limit(1);
  if (existing[0]) {
    const currentName = existing[0].name?.trim() || "";
    const isPlaceholder = !currentName || /^(Mã TTHC|Thủ tục đất đai mã).*cần đối soát/i.test(currentName);
    if (verifiedName && isPlaceholder) {
      await db.update(legalProcedures).set({ name: verifiedName, groupName: item?.groupName ?? existing[0].groupName, aliases: JSON.stringify(item?.aliases ?? registryItem?.aliases ?? []), authority: item?.authority ?? registryItem?.authority ?? existing[0].authority, workflow: JSON.stringify(item?.workflowSteps ?? registryItem?.workflowSteps ?? []), lastReviewedAt: new Date(item?.checkedAt ?? registryItem?.checkedAt ?? new Date().toISOString()) }).where(eq(legalProcedures.id, existing[0].id));
      const refreshed = await db.select().from(legalProcedures).where(eq(legalProcedures.id, existing[0].id)).limit(1);
      return refreshed[0] ?? existing[0];
    }
    return existing[0];
  }
  if (!item && !appendixCode) return undefined;
  const result = await db.insert(legalProcedures).values(item ? {
    code: item.code,
    name: item.name,
    groupName: item.groupName,
    aliases: JSON.stringify(item.aliases),
    authority: item.authority,
    workflow: JSON.stringify(item.workflowSteps ?? []),
    status: "active",
    lastReviewedAt: new Date(item.checkedAt),
  } : {
    code: appendixCode!,
    name: getVerified2304ProcedureName(appendixCode!) ?? `Thủ tục đất đai mã ${appendixCode} — cần đối soát tên chính thức`,
    groupName: "Đất đai — Phụ lục 2304",
    aliases: JSON.stringify([]),
    authority: "Bộ Nông nghiệp và Môi trường",
    workflow: JSON.stringify([]),
    status: "active",
    lastReviewedAt: null,
  });
  const inserted = await db.select().from(legalProcedures).where(eq(legalProcedures.id, Number(result[0].insertId))).limit(1);
  return inserted[0];
}
export async function createLegalTemplate(input: typeof legalTemplates.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalTemplates).values(input); return { id: Number(result[0].insertId) }; }
export async function updateLegalTemplateBinary(id: number, data: Pick<typeof legalTemplates.$inferInsert, "storageKey" | "fileUrl" | "checksum" | "format" | "provenance" | "status" | "notes" | "province" | "receivingAuthority" | "versionLabel" | "effectiveFrom" | "effectiveTo">) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(legalTemplates).set(data).where(eq(legalTemplates.id, id)); return { success: true } as const; }
export async function upsertOfficialLegalTemplate(input: { procedureId: number; sourceId: number; name: string; documentType: string; format: "docx" | "pdf"; sourceUrl: string; storageKey: string; fileUrl: string; checksum: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: legalTemplates.id }).from(legalTemplates).where(and(eq(legalTemplates.procedureId, input.procedureId), eq(legalTemplates.sourceUrl, input.sourceUrl))).limit(1);
  const values = { ...input, provenance: "official" as const, status: "active" as const, notes: input.notes ?? "Binary đã tải từ nguồn nhà nước, kiểm tra định dạng và SHA-256; vẫn cần đối chiếu địa phương khi nộp." };
  if (existing[0]) { await db.update(legalTemplates).set(values).where(eq(legalTemplates.id, existing[0].id)); return { id: existing[0].id, created: false } as const; }
  const result = await db.insert(legalTemplates).values(values);
  return { id: Number(result[0].insertId), created: true } as const;
}

export async function upsertOfficialLegalTemplateMapping(input: { procedureId: number; requirementId?: number; templateId: number; componentLabel: string; confidence?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const confidence = input.confidence ?? 80;
  const existing = input.requirementId
    ? await db.select({ id: legalTemplateMappings.id }).from(legalTemplateMappings).where(and(eq(legalTemplateMappings.procedureId, input.procedureId), eq(legalTemplateMappings.requirementId, input.requirementId), eq(legalTemplateMappings.templateId, input.templateId))).limit(1)
    : await db.select({ id: legalTemplateMappings.id }).from(legalTemplateMappings).where(and(eq(legalTemplateMappings.procedureId, input.procedureId), eq(legalTemplateMappings.templateId, input.templateId))).limit(1);
  const values = { procedureId: input.procedureId, requirementId: input.requirementId ?? null, templateId: input.templateId, mappingJson: JSON.stringify({ source: "official_binary", componentLabel: input.componentLabel }), confidence, status: "suggested" as const };
  if (existing[0]) { await db.update(legalTemplateMappings).set(values).where(eq(legalTemplateMappings.id, existing[0].id)); return { id: existing[0].id, created: false } as const; }
  const result = await db.insert(legalTemplateMappings).values(values);
  return { id: Number(result[0].insertId), created: true } as const;
}

export async function upsertUserUploadLegalTemplate(input: { userId: number; procedureId: number; name: string; documentType: string; format: "docx" | "doc" | "pdf" | "scan"; storageKey: string; fileUrl: string; checksum: string; componentLabel?: string; requirementId?: number; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const baseUrl = `user-upload://${input.userId}`;
  const sourceName = `Tệp người dùng tải lên #${input.userId}`;
  const existingSource = await db.select({ id: legalSources.id }).from(legalSources).where(and(eq(legalSources.name, sourceName), eq(legalSources.baseUrl, baseUrl))).limit(1);
  let sourceId = existingSource[0]?.id;
  if (!sourceId) {
    const createdSource = await db.insert(legalSources).values({ name: sourceName, baseUrl, sourceType: "other", jurisdiction: null, active: 1, lastCheckedAt: new Date(), notes: "Nguồn do người dùng tải lên; không phải nguồn Official Nhà nước." });
    sourceId = Number(createdSource[0].insertId);
  }
  const sourceUrl = `${baseUrl}/${input.checksum}`;
  const existing = await db.select({ id: legalTemplates.id }).from(legalTemplates).where(and(eq(legalTemplates.procedureId, input.procedureId), eq(legalTemplates.sourceUrl, sourceUrl))).limit(1);
  const notes = ["Tệp người dùng tải lên; dùng cho tham khảo và tự động dựng hồ sơ.", input.componentLabel ? `Thành phần: ${input.componentLabel}` : "", input.notes ?? "", "Không được gắn Official Nhà nước nếu chưa xác minh provenance chính thức."].filter(Boolean).join(" ");
  const values = { procedureId: input.procedureId, sourceId, name: input.name, documentType: input.documentType, format: input.format, sourceUrl, storageKey: input.storageKey, fileUrl: input.fileUrl, checksum: input.checksum, provenance: "metadata_only" as const, status: "active" as const, notes };
  let templateId: number;
  if (existing[0]) {
    templateId = existing[0].id;
    await db.update(legalTemplates).set(values).where(eq(legalTemplates.id, templateId));
  } else {
    const result = await db.insert(legalTemplates).values(values);
    templateId = Number(result[0].insertId);
  }
  if (input.requirementId) {
    const existingMapping = await db.select({ id: legalTemplateMappings.id }).from(legalTemplateMappings).where(and(eq(legalTemplateMappings.procedureId, input.procedureId), eq(legalTemplateMappings.requirementId, input.requirementId), eq(legalTemplateMappings.templateId, templateId))).limit(1);
    if (!existingMapping[0]) await db.insert(legalTemplateMappings).values({ procedureId: input.procedureId, requirementId: input.requirementId, templateId, mappingJson: JSON.stringify({ source: "user_upload", componentLabel: input.componentLabel ?? null }), confidence: 90, status: "suggested" });
  }
  return { templateId, sourceId, sourceUrl, provenance: "metadata_only" as const, status: "active" as const };
}

export async function upsertReferenceLegalTemplate(input: { procedureId: number; sourceId: number; name: string; documentType: string; format: "docx" | "doc" | "pdf" | "scan"; sourceUrl: string; storageKey?: string; fileUrl?: string; checksum?: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: legalTemplates.id }).from(legalTemplates).where(and(eq(legalTemplates.procedureId, input.procedureId), eq(legalTemplates.sourceUrl, input.sourceUrl))).limit(1);
  const values = { ...input, storageKey: input.storageKey ?? null, fileUrl: input.fileUrl ?? null, checksum: input.checksum ?? null, provenance: "metadata_only" as const, status: "active" as const, notes: input.notes ?? "Bản tham khảo; chưa đủ điều kiện Official Nhà nước." };
  if (existing[0]) { await db.update(legalTemplates).set(values).where(eq(legalTemplates.id, existing[0].id)); return { id: existing[0].id, created: false } as const; }
  const result = await db.insert(legalTemplates).values(values);
  return { id: Number(result[0].insertId), created: true } as const;
}

export async function getLegalTemplateWithFields(id: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const template = await db.select().from(legalTemplates).where(eq(legalTemplates.id, id)).limit(1); if (!template[0]) return undefined; const fields = await db.select().from(legalTemplateFields).where(eq(legalTemplateFields.templateId, id)).orderBy(asc(legalTemplateFields.id)); return { template: template[0], fields }; }
export async function createLegalRequirement(input: typeof legalProcedureRequirements.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalProcedureRequirements).values(input); return { id: Number(result[0].insertId) }; }

/** Materialize snapshot DVC vào các bảng mà bundle production đọc trực tiếp. Idempotent theo procedureId + label. */
export async function materializeLegalProcedureSnapshot(input: {
  procedureId: number;
  workflow: unknown;
  dossierComponents: Array<{ id?: string; name: string; required?: boolean; evidence?: string }>;
  sourceDocumentId?: number | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(legalProcedures).set({ workflow: JSON.stringify(input.workflow) }).where(eq(legalProcedures.id, input.procedureId));
  const existing = await db.select().from(legalProcedureRequirements).where(eq(legalProcedureRequirements.procedureId, input.procedureId));
  let inserted = 0;
  let updated = 0;
  for (let index = 0; index < input.dossierComponents.length; index += 1) {
    const component = input.dossierComponents[index];
    const label = component.name.trim();
    if (!label) continue;
    const current = existing.find(row => row.label.trim().toLocaleLowerCase() === label.toLocaleLowerCase());
    const values = {
      procedureId: input.procedureId,
      sortOrder: index,
      label: label.slice(0, 255),
      requirementType: "document" as const,
      required: component.required === false ? 0 : 1,
      fieldKey: component.id ? component.id.slice(0, 100) : null,
      sourceDocumentId: input.sourceDocumentId ?? null,
      notes: component.evidence ? component.evidence.slice(0, 2000) : "Thành phần được materialize từ snapshot DVC; cần đối chiếu khi nộp hồ sơ.",
    };
    if (current) {
      await db.update(legalProcedureRequirements).set(values).where(eq(legalProcedureRequirements.id, current.id));
      updated += 1;
    } else {
      await db.insert(legalProcedureRequirements).values(values);
      inserted += 1;
    }
  }
  return { inserted, updated, total: inserted + updated };
}
export async function createLegalSyncRun(input: typeof legalSyncRuns.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalSyncRuns).values(input); return { id: Number(result[0].insertId) }; }
export async function finishLegalSyncRun(id: number, data: Partial<typeof legalSyncRuns.$inferInsert>) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(legalSyncRuns).set(data).where(eq(legalSyncRuns.id, id)); return { success: true } as const; }
export async function updateLegalSyncRunProgress(id: number, progress: unknown) { const db = await getDb(); if (!db) throw new Error("Database is not available"); await db.update(legalSyncRuns).set({ summary: JSON.stringify(progress) }).where(eq(legalSyncRuns.id, id)); return { success: true } as const; }
export async function getLatestLegalSyncRun() { const db = await getDb(); if (!db) throw new Error("Database is not available"); const rows = await db.select().from(legalSyncRuns).orderBy(desc(legalSyncRuns.startedAt)).limit(1); return rows[0] ?? null; }
export async function enqueueLegalScanItems(procedureCodes: string[], province?: string) { const db = await getDb(); if (!db || procedureCodes.length === 0) return; for (const procedureCode of procedureCodes) { await db.insert(legalScanQueue).values({ procedureCode, province: province ?? null, status: "queued", nextAttemptAt: new Date() }).onDuplicateKeyUpdate({ set: { procedureCode } }); } }
export async function listDueLegalScanItems(limit = 3) { const db = await getDb(); if (!db) return []; const now = new Date(); return db.select().from(legalScanQueue).where(or(eq(legalScanQueue.status, "queued"), and(eq(legalScanQueue.status, "pending"), lte(legalScanQueue.nextAttemptAt, now)), and(eq(legalScanQueue.status, "failed"), lte(legalScanQueue.nextAttemptAt, now)))).orderBy(asc(legalScanQueue.nextAttemptAt)).limit(limit); }
export async function updateLegalScanItem(procedureCode: string, province: string | undefined, data: Partial<typeof legalScanQueue.$inferInsert>) { const db = await getDb(); if (!db) return; await db.update(legalScanQueue).set(data).where(and(eq(legalScanQueue.procedureCode, procedureCode), province ? eq(legalScanQueue.province, province) : isNull(legalScanQueue.province))); }

export async function createLegalDocument(input: typeof legalDocuments.$inferInsert) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const result = await db.insert(legalDocuments).values(input); return { id: Number(result[0].insertId) }; }
export async function upsertLegalDocument(input: { sourceId: number; title: string; documentNumber?: string; documentType?: string; issuingBody?: string; sourceUrl: string; mimeType?: string; warnings?: string; status?: "metadata_only" | "extracted" | "verified" | "superseded" | "needs_review" }) {
  const db = await getDb(); if (!db) throw new Error("Database is not available");
  const existing = await db.select({ id: legalDocuments.id }).from(legalDocuments).where(and(eq(legalDocuments.sourceId, input.sourceId), eq(legalDocuments.sourceUrl, input.sourceUrl))).limit(1);
  const values = { ...input, documentNumber: input.documentNumber ?? null, documentType: input.documentType ?? null, issuingBody: input.issuingBody ?? null, mimeType: input.mimeType ?? null, warnings: input.warnings ?? null, status: input.status ?? "metadata_only" as const, checkedAt: new Date() };
  if (existing[0]) { await db.update(legalDocuments).set(values).where(eq(legalDocuments.id, existing[0].id)); return { id: existing[0].id, created: false } as const; }
  const result = await db.insert(legalDocuments).values(values); return { id: Number(result[0].insertId), created: true } as const;
}


export async function saveLegalProcedureVersion(input: typeof legalProcedureVersions.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(legalProcedureVersions).values(input);
  return { id: Number(result[0].insertId) };
}

export async function listLegalProcedureVersions(procedureId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(legalProcedureVersions).where(eq(legalProcedureVersions.procedureId, procedureId)).orderBy(desc(legalProcedureVersions.discoveredAt));
}

export async function saveLegalTemplateMappings(values: Array<typeof legalTemplateMappings.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  if (!values.length) return [];
  const result = await db.insert(legalTemplateMappings).values(values);
  return { inserted: values.length, firstId: Number(result[0].insertId) };
}

export async function listLegalTemplateMappings(procedureId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(legalTemplateMappings).where(eq(legalTemplateMappings.procedureId, procedureId)).orderBy(desc(legalTemplateMappings.updatedAt));
}

export async function appendLandDossierAudit(input: typeof landDossierAudits.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(landDossierAudits).values(input);
  return { id: Number(result[0].insertId) };
}

export async function listLandDossierAudits(dossierId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(landDossierAudits).where(eq(landDossierAudits.dossierId, dossierId)).orderBy(desc(landDossierAudits.createdAt));
}
