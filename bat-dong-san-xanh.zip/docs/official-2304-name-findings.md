# Kết quả đối soát tên mã thủ tục 2304

## Nguồn 1: Cổng hành chính công An Giang
URL: https://dichvucong1.angiang.gov.vn/dich-vu-cong/tra-cuu/chi-tiet-thu-tuc?ma-thu-tuc=41099

Trang hiển thị mã địa phương **1.012820.H01** và tên: **Bán hoặc góp vốn bằng tài sản gắn liền với đất thuê của Nhà nước theo hình thức thuê đất trả tiền hàng năm (Cấp Tỉnh)**. Trang nêu cơ quan thực hiện gồm Văn phòng đăng ký đất đai và Chi nhánh Văn phòng đăng ký đất đai; lĩnh vực Đất đai; hồ sơ 01 bộ. Nguồn này là biến thể địa phương của mã trung ương 1.012820 và cần giữ mapping mã địa phương về mã gốc, không gán nhầm toàn bộ mã tỉnh thành mã trung ương.

## Nguồn 2: Cổng thông tin phường Xuân Phương, Hà Nội
URL: https://xuanphuong.hanoi.gov.vn/danh-muc-tthc/danh-muc-thu-tuc-hanh-chinh-linh-vuc-dat-dai-2793250729091712587.htm

Bảng danh mục công khai ngày 29/07/2025, căn cứ dữ liệu đến 06/07/2025, hiển thị:

- **1.012818.H26** — **Thu hồi Giấy chứng nhận đã cấp lần đầu không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi**. Chi tiết DVC: https://thutuc.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=357513
- **1.012817.H26** — **Xác định lại diện tích đất ở của hộ gia đình, cá nhân đã được cấp Giấy chứng nhận trước ngày 01 tháng 7 năm 2004**. Chi tiết DVC: https://thutuc.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=357511
- **1.012812.H26** — **Hòa giải tranh chấp đất đai**. Chi tiết DVC: https://thutuc.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=357519

## Kết luận triển khai
Các tên trên được lấy từ trang hành chính công và có thể dùng để bổ sung mapping cho mã gốc tương ứng sau khi xác nhận quan hệ mã địa phương `.H26`/`.H01` với mã trung ương. Chưa ghi nhận tên chính thức cho 1.012819 và 1.012821 trong phần dữ liệu đã trích xuất; hai mã này tiếp tục giữ trạng thái cần đối soát, không tự đặt tên và không gắn Official chỉ dựa trên chỉ mục mã.

## Bổ sung đối soát mã 1.012819 và 1.012821

Nguồn An Giang: https://dichvucong1.angiang.gov.vn/dichvucong/tra-cuu/chi-tiet-thu-tuc?ma-thu-tuc=40635

- **1.012819.H01** — **Cấp lại Giấy chứng nhận do bị mất**. Trang nêu cơ quan thực hiện gồm Chi nhánh Văn phòng đăng ký đất đai và UBND cấp xã; hồ sơ có Đơn đăng ký biến động theo Mẫu số 11/ĐK. Trang cũng công khai tệp Mẫu số 11.docx.

Nguồn UBND tỉnh Đắk Lắk, Phụ lục Quyết định 1586/QĐ-UBND: https://vpubnd.daklak.gov.vn/CMS/Content/VanBan/2025/THANG%207/1586_QD-UBND%20pl.pdf

- **1.012821** — **Thẩm định, phê duyệt phương án sử dụng đất**. Phụ lục ghi đây là thủ tục cấp tỉnh; cơ quan thực hiện gồm Chủ tịch UBND cấp tỉnh và cơ quan có chức năng quản lý đất đai cấp tỉnh.

Các tên này đã được lấy từ nguồn cơ quan nhà nước. Việc có tệp Official hay không vẫn là kiểm tra độc lập bằng binary và SHA-256; tên chính thức không tự nâng trạng thái mẫu.
