import { describe, expect, it } from "vitest";
import {
  CRM_NAV_ITEMS,
  CRM_PRIMARY_NAV_ITEMS,
  CRM_QUICK_ACTIONS,
  CRM_OPERATING_LAYERS,
  SOURCE_CREATION_STEPS,
  SOURCE_FORM_FIELDS,
  getOperatingPipelineHref,
  getOperatingTaskHref,
} from "./CrmDashboard";

describe("CRM dashboard navigation", () => {
  it("exposes the compact primary CRM navigation in working order", () => {
    expect(CRM_PRIMARY_NAV_ITEMS.map(item => item.label)).toEqual([
      "Trang CRM",
      "Trung tâm điều hành",
      "Nguồn hàng & BĐS",
      "Marketing",
      "Khách hàng & Lead",
      "AI Matching & Trợ lý",
      "Đàm phán & Giao dịch",
      "Hồ sơ & Tài liệu",
      "Báo cáo & Quản trị",
    ]);
    expect(CRM_PRIMARY_NAV_ITEMS.map(item => item.href)).toEqual([
      "/crm",
      "/dashboard",
      "/quan-ly-moi-gioi",
      "/dashboard/marketing",
      "/dashboard/khach-hang",
      "/dashboard/ai",
      "/dashboard/giao-dich",
      "/ho-so-dien-tu",
      "/dashboard/bao-cao",
    ]);
  });

  it("keeps the CRM dashboard entry and existing operational module routes", () => {
    expect(CRM_NAV_ITEMS.map(item => item.label)).toEqual([
      "Trang CRM",
      "Trung tâm điều hành",
      "Nguồn hàng & BĐS",
      "Marketing",
      "Khách hàng & Lead",
      "AI Matching & Trợ lý",
      "Đàm phán & Giao dịch",
      "Hồ sơ & Tài liệu",
      "Báo cáo & Quản trị",
    ]);

    expect(CRM_NAV_ITEMS.find(item => item.label === "Trang CRM")?.href).toBe(
      "/crm"
    );
    expect(
      CRM_NAV_ITEMS.find(item => item.label === "Trung tâm điều hành")?.href
    ).toBe("/dashboard");
    expect(
      CRM_NAV_ITEMS.find(item => item.label === "Nguồn hàng & BĐS")?.href
    ).toBe("/quan-ly-moi-gioi");
    expect(
      CRM_NAV_ITEMS.find(item => item.label === "Hồ sơ & Tài liệu")?.href
    ).toBe("/ho-so-dien-tu");
    expect(
      CRM_NAV_ITEMS.find(item => item.label === "AI Matching & Trợ lý")?.href
    ).toBe("/dashboard/ai");
    expect(
      CRM_NAV_ITEMS.find(item => item.label === "Đàm phán & Giao dịch")?.href
    ).toBe("/dashboard/giao-dich");
  });
});

it("exposes mobile-first quick actions without fake data", () => {
  expect(CRM_QUICK_ACTIONS.map(item => item.label)).toEqual([
    "1 · Tạo nguồn hàng",
    "2 · Tạo sản phẩm",
    "3 · Thu Lead",
    "4 · Matching AI",
    "5 · Dẫn khách",
    "6 · Tạo giao dịch",
  ]);
  expect(CRM_QUICK_ACTIONS.map(item => item.href)).toEqual([
    "/quan-ly-moi-gioi",
    "/quan-ly-moi-gioi",
    "/dashboard/marketing",
    "/dashboard/ai",
    "/dashboard/khach-hang",
    "/dashboard/giao-dich",
  ]);
});

it("exposes the ordered CRM workflow centers", async () => {
  const { CRM_WORKFLOW_CENTERS } = await import("./CrmDashboard");
  expect(CRM_WORKFLOW_CENTERS.map(item => item.order)).toEqual([
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
  ]);
  expect(CRM_WORKFLOW_CENTERS[1].label).toBe("Tạo nguồn hàng");
  expect(CRM_WORKFLOW_CENTERS[8].href).toBe("/dashboard/giao-dich");
});

it("detects horizontal overflow with a small tolerance", async () => {
  const { getResponsiveMetrics } = await import("./CrmDashboard");
  expect(getResponsiveMetrics(390, 390)).toEqual({
    viewportWidth: 390,
    documentWidth: 390,
    horizontalOverflow: false,
    overflowPixels: 0,
  });
  expect(getResponsiveMetrics(390, 392).horizontalOverflow).toBe(false);
  expect(getResponsiveMetrics(390, 430)).toEqual({
    viewportWidth: 390,
    documentWidth: 430,
    horizontalOverflow: true,
    overflowPixels: 40,
  });
});

describe("Operating Center command screen", () => {
  it("keeps the four-layer operating structure in order", () => {
    expect(CRM_OPERATING_LAYERS.map(layer => layer.key)).toEqual([
      "status",
      "urgent",
      "workflow",
      "ai",
    ]);
    expect(CRM_OPERATING_LAYERS.map(layer => layer.order)).toEqual([
      1, 2, 3, 4,
    ]);
    expect(CRM_OPERATING_LAYERS[0].label).toBe("Trạng thái sàn");
    expect(CRM_OPERATING_LAYERS[3].href).toBe("/dashboard/ai");
  });

  it("exposes the source inventory groups and creation workflow", async () => {
    const fs = await import("node:fs/promises");
    const source = await fs.readFile(
      new URL("./CrmDashboard.tsx", import.meta.url),
      "utf8"
    );
    expect(source).toContain("Nguồn hàng thị trường");
    expect(source).toContain("Nguồn hàng cộng tác");
    expect(source).toContain("Nguồn hàng tồn kho");
    expect(source).toContain("Nguồn hàng đã bán");
    expect(source).toContain("Nguồn hàng đang khảo sát");
    expect(source).toContain('data-operating-section="source-buckets"');
    expect(source).toContain(
      'data-operating-section="source-creation-workspace"'
    );
    expect(source).not.toContain('data-operating-section="source-workflow"');
    expect(source).toContain('label === "Tạo nguồn hàng"');
    expect(SOURCE_CREATION_STEPS).toHaveLength(8);
    expect(SOURCE_CREATION_STEPS.map(step => step.label)).toEqual([
      "Tiếp nhận",
      "Khảo sát",
      "Quy hoạch",
      "Pháp lý",
      "Định giá",
      "Đàm phán chủ nhà",
      "Ký gửi",
      "Tạo bài đăng sản phẩm",
    ]);
    expect(source).toContain("Tiếp nhận");
    expect(source).toContain("Khảo sát");
    expect(source).toContain("Quy hoạch");
    expect(source).toContain("Pháp lý");
    expect(source).toContain("Định giá");
    expect(source).toContain("Đàm phán chủ nhà");
    expect(source).toContain("Ký gửi");
    expect(source).toContain("Tạo bài đăng sản phẩm");
    expect(source).toContain("/quan-ly-moi-gioi?process=listing");
    expect(source).toContain("/quan-ly-moi-gioi?process=intake");
    expect(source).toContain("/quan-ly-moi-gioi?process=legal");
    expect(source).toContain("AI chỉ hỗ trợ nhận diện/OCR và đề xuất");
    expect(source).toContain("Lưu nháp");
    expect(source).toContain("Lưu hồ sơ");
    expect(source).toContain("Nhận diện/OCR");
    expect(source).toContain("PDF, DOCX");
    expect(source).toContain('data-source-intake-wizard');
    expect(source).toContain("Chọn nguồn");
    expect(source).toContain("Chọn loại BĐS");
    expect(source).toContain("Tải ảnh hoặc chụp ảnh");
    expect(source).toContain("Tải hoặc quay video");
    expect(source).toContain("Đọc giấy tờ bằng OCR");
    expect(source).toContain("chờ xác nhận");
    expect(source).toContain("Bản nháp · chưa công khai");
  });

  it("defines a separate data form for every source-creation step", () => {
    expect(Object.keys(SOURCE_FORM_FIELDS)).toEqual([
      "Tiếp nhận",
      "Khảo sát",
      "Quy hoạch",
      "Pháp lý",
      "Định giá",
      "Đàm phán chủ nhà",
      "Ký gửi",
      "Tạo bài đăng sản phẩm",
    ]);
    for (const fields of Object.values(SOURCE_FORM_FIELDS)) {
      expect(fields.length).toBeGreaterThanOrEqual(3);
      expect(fields.some(field => field.wide)).toBe(true);
    }
  });

  it("routes urgent tasks and pipeline stages to their responsible modules", () => {
    expect(getOperatingTaskHref("consultation-12")).toBe("/quan-ly");
    expect(getOperatingTaskHref("buyer-34")).toBe(
      "/dashboard/khach-hang?filter=new"
    );
    expect(getOperatingTaskHref("deal-56")).toBe("/dashboard/giao-dich");
    expect(getOperatingTaskHref("unknown")).toBe("/dashboard/bao-cao");
    expect(getOperatingPipelineHref("Đàm phán")).toBe(
      "/dashboard/giao-dich?stage=%C4%90%C3%A0m%20ph%C3%A1n"
    );
  });
});

describe("CRM dashboard responsive layout", () => {
  it("keeps module cards separated and mobile-safe", async () => {
    const fs = await import("node:fs/promises");
    const source = await fs.readFile(
      new URL("./CrmDashboard.tsx", import.meta.url),
      "utf8"
    );
    expect(source).toContain("grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4");
    expect(source).toContain(
      "min-w-0 gap-5 xl:grid-cols-[minmax(0,1.35fr)_minmax(18rem,0.65fr)]"
    );
    expect(source).toContain(
      "flex min-w-0 min-h-[7rem] flex-col justify-between"
    );
    expect(source).toContain("flex flex-wrap items-center justify-end");
    expect(source).toContain('data-operating-layer="status"');
    expect(source).toContain('data-operating-layer="urgent"');
    expect(source).toContain('data-operating-layer="workflow"');
    expect(source).toContain('data-operating-layer="ai"');
    expect(source).toContain("AI chỉ là trợ lý điều phối");
  });
});
