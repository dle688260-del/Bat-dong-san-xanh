# Production check 2026-08-23

- URL production: https://batdongsan-7bupubgw.manus.space/
- URL admin: https://batdongsan-7bupubgw.manus.space/dang-nhap-quan-tri
- Admin route tải được và hiển thị form tên đăng nhập/mật khẩu, không nhập credentials.
- Trang chủ trong sandbox browser từng hiển thị trắng với title đúng; chưa kết luận lỗi production vì route admin vẫn tải được.
- Ca kiểm thử được chọn: mã 2.000889, chưa chạy end-to-end.
- Registry resolver vừa được chuẩn hóa để nhận canonical 2.000889 và alias external 2912; checkpoint sửa registry: 8fffed6c.
- Không có thao tác đăng nhập, gửi dữ liệu, xuất hồ sơ hoặc thay đổi production trong lần kiểm tra này.

Nguồn kiểm tra: https://batdongsan-7bupubgw.manus.space/dang-nhap-quan-tri
