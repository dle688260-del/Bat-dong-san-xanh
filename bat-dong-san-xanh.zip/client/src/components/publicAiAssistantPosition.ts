export type AssistantPosition = { left: number; top: number };

type AssistantDimensions = { width: number; height: number; bottomOffset: number };

const VIEWPORT_GUTTER = 16;

function getAssistantDimensions(): AssistantDimensions {
  if (typeof window === "undefined" || window.innerWidth < 640) {
    return { width: 118, height: 40, bottomOffset: 88 };
  }
  return { width: 132, height: 44, bottomOffset: 96 };
}

export function getDefaultAssistantPosition(): AssistantPosition {
  if (typeof window === "undefined") return { left: VIEWPORT_GUTTER, top: VIEWPORT_GUTTER };
  const { width, height, bottomOffset } = getAssistantDimensions();
  return {
    left: Math.max(VIEWPORT_GUTTER, window.innerWidth - width - VIEWPORT_GUTTER),
    top: Math.max(VIEWPORT_GUTTER, window.innerHeight - height - bottomOffset),
  };
}

export function clampAssistantPosition(position: AssistantPosition): AssistantPosition {
  if (typeof window === "undefined") return position;
  const { width, height } = getAssistantDimensions();
  return {
    left: Math.min(Math.max(VIEWPORT_GUTTER, position.left), Math.max(VIEWPORT_GUTTER, window.innerWidth - width - VIEWPORT_GUTTER)),
    top: Math.min(Math.max(VIEWPORT_GUTTER, position.top), Math.max(VIEWPORT_GUTTER, window.innerHeight - height - VIEWPORT_GUTTER)),
  };
}
