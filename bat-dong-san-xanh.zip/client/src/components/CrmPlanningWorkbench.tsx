import { useMemo, useState } from "react";
import { Calculator, CircleDollarSign, Info, Landmark } from "lucide-react";

export type LoanPlan = {
  propertyPrice: number;
  ownCapital: number;
  loanAmount: number;
  ltv: number;
  monthlyPayment: number;
  totalRepayment: number;
  totalInterest: number;
};

export function calculateLoanPlan(propertyPrice: number, ownCapital: number, annualRatePercent: number, termYears: number): LoanPlan {
  const price = Math.max(0, propertyPrice);
  const capital = Math.min(price, Math.max(0, ownCapital));
  const loanAmount = Math.max(0, price - capital);
  const months = Math.max(1, Math.round(termYears * 12));
  const monthlyRate = Math.max(0, annualRatePercent) / 100 / 12;
  const monthlyPayment = monthlyRate === 0
    ? loanAmount / months
    : loanAmount * monthlyRate * (1 + monthlyRate) ** months / ((1 + monthlyRate) ** months - 1);
  const totalRepayment = monthlyPayment * months;

  return {
    propertyPrice: price,
    ownCapital: capital,
    loanAmount,
    ltv: price ? loanAmount / price * 100 : 0,
    monthlyPayment,
    totalRepayment,
    totalInterest: Math.max(0, totalRepayment - loanAmount),
  };
}

export function calculateComparableValuation(pricePerM2Million: number, areaM2: number, adjustmentPercent: number) {
  const base = Math.max(0, pricePerM2Million) * Math.max(0, areaM2) / 1000;
  return base * (1 + adjustmentPercent / 100);
}

const formatBillion = (value: number) => `${value.toLocaleString("vi-VN", { maximumFractionDigits: 2 })} tỷ`;
const formatMillion = (value: number) => `${Math.round(value * 1000).toLocaleString("vi-VN")} triệu/tháng`;

export default function CrmPlanningWorkbench() {
  const [propertyPrice, setPropertyPrice] = useState("2");
  const [ownCapital, setOwnCapital] = useState("0.8");
  const [annualRate, setAnnualRate] = useState("9");
  const [termYears, setTermYears] = useState("20");
  const [comparablePricePerM2, setComparablePricePerM2] = useState("55");
  const [landArea, setLandArea] = useState("100");
  const [adjustmentPercent, setAdjustmentPercent] = useState("0");
  const plan = useMemo(() => calculateLoanPlan(Number(propertyPrice) || 0, Number(ownCapital) || 0, Number(annualRate) || 0, Number(termYears) || 1), [propertyPrice, ownCapital, annualRate, termYears]);
  const valuation = useMemo(() => calculateComparableValuation(Number(comparablePricePerM2) || 0, Number(landArea) || 0, Number(adjustmentPercent) || 0), [comparablePricePerM2, landArea, adjustmentPercent]);

  return (
    <section data-responsive-section="CRM Planning Workbench" className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">Trợ lý phân tích giao dịch</p>
          <h2 className="mt-2 font-serif text-2xl text-[#173b35]">Định giá nhanh & mô phỏng vay</h2>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">Nhập số liệu của BĐS đang tư vấn để xem nhanh vốn tự có, tỷ lệ vay và khoản trả dự kiến.</p>
        </div>
        <div className="flex items-center gap-2 rounded-full bg-[#e7f1e9] px-3 py-2 text-xs font-bold text-[#1e6a59]"><Calculator className="h-4 w-4" />Phân tích tại chỗ</div>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1fr_1.15fr]">
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm font-semibold text-[#527068]">Giá BĐS (tỷ)<input inputMode="decimal" value={propertyPrice} onChange={event => setPropertyPrice(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <label className="text-sm font-semibold text-[#527068]">Vốn tự có (tỷ)<input inputMode="decimal" value={ownCapital} onChange={event => setOwnCapital(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <label className="text-sm font-semibold text-[#527068]">Lãi suất năm (%)<input inputMode="decimal" value={annualRate} onChange={event => setAnnualRate(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <label className="text-sm font-semibold text-[#527068]">Thời hạn (năm)<input inputMode="numeric" value={termYears} onChange={event => setTermYears(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <label className="text-sm font-semibold text-[#527068]">Giá so sánh (triệu/m²)<input inputMode="decimal" value={comparablePricePerM2} onChange={event => setComparablePricePerM2(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <label className="text-sm font-semibold text-[#527068]">Diện tích (m²)<input inputMode="decimal" value={landArea} onChange={event => setLandArea(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
          <label className="text-sm font-semibold text-[#527068]">Điều chỉnh (%)<input inputMode="decimal" value={adjustmentPercent} onChange={event => setAdjustmentPercent(event.target.value)} className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35] outline-none focus:border-[#2d8069]" /></label>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl bg-[#173f36] p-4 text-white"><div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[#e8c96d]"><Landmark className="h-4 w-4" />Khoản vay</div><p className="mt-3 text-2xl font-bold">{formatBillion(plan.loanAmount)}</p><p className="mt-1 text-xs text-white/70">Tỷ lệ vay {plan.ltv.toFixed(1)}%</p></div>
          <div className="rounded-2xl bg-[#e2f1e8] p-4 text-[#173b35]"><div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[#25725e]"><CircleDollarSign className="h-4 w-4" />Trả dự kiến</div><p className="mt-3 text-2xl font-bold">{formatMillion(plan.monthlyPayment)}</p><p className="mt-1 text-xs text-[#527068]">Tổng lãi {formatBillion(plan.totalInterest)}</p></div>
          <div className="rounded-2xl bg-[#fff1ca] p-4 text-[#5f4816] sm:col-span-2"><div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.12em] text-[#9d751f]"><Calculator className="h-4 w-4" />Giá tham khảo</div><p className="mt-3 text-2xl font-bold">{formatBillion(valuation)}</p><p className="mt-1 text-xs text-[#7b652d]">Theo giá so sánh và hệ số điều chỉnh</p></div>
          <div className="rounded-2xl border border-[#dce7df] bg-white p-4 sm:col-span-2"><div className="flex items-center justify-between gap-3"><p className="text-sm font-bold text-[#173b35]">Tóm tắt phương án</p><span className="text-xs font-semibold text-[#688078]">Vốn tự có {formatBillion(plan.ownCapital)}</span></div><div className="mt-3 grid gap-2 text-sm text-[#527068] sm:grid-cols-3"><span>Giá BĐS: <b className="text-[#173b35]">{formatBillion(plan.propertyPrice)}</b></span><span>Tổng trả: <b className="text-[#173b35]">{formatBillion(plan.totalRepayment)}</b></span><span>Kỳ hạn: <b className="text-[#173b35]">{Math.max(1, Number(termYears) || 1)} năm</b></span></div></div>
        </div>
      </div>

      <p className="mt-4 flex items-start gap-2 text-xs leading-5 text-[#688078]"><Info className="mt-0.5 h-4 w-4 shrink-0 text-[#b48a36]" />Đây là mô phỏng tham khảo theo lãi suất cố định do người dùng nhập, chưa bao gồm phí, bảo hiểm, thay đổi lãi suất hoặc điều kiện xét duyệt của ngân hàng.</p>
    </section>
  );
}
