Nguồn chính thức: https://xaydungchinhsach.chinhphu.vn/chi-tiet-34-don-vi-hanh-chinh-cap-tinh-tu-12-6-2025-119250612141845533.htm

Kết luận: từ ngày 12/6/2025, Việt Nam có 34 đơn vị hành chính cấp tỉnh, gồm 28 tỉnh và 6 thành phố. Chính quyền địa phương sau sắp xếp hoạt động từ 1/7/2025. Bộ chọn tỉnh/thành của website cần ưu tiên danh sách 34 đơn vị hiện hành, trong đó Đà Nẵng là thành phố mới sau sắp xếp cùng Quảng Nam.
