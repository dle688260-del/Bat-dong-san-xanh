# Đối soát tên thủ tục theo mã

Nguồn đã mở: Cổng Dịch vụ công Quốc gia, URL https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012775

Mã: 1.012775
Tên chính thức: Cho phép chuyển mục đích sử dụng đất đối với trường hợp không thuộc diện chấp thuận chủ trương đầu tư, chấp thuận nhà đầu tư theo quy định của pháp luật về đất đai mà người xin chuyển mục đích sử dụng đất là hộ gia đình, cá nhân.

Trang chi tiết cũng có phần Trình tự thực hiện và mô tả vai trò cơ quan quản lý đất đai, Văn phòng đăng ký đất đai, cơ quan thuế và UBND cấp huyện. Không dùng tên placeholder cho mã này khi hiển thị trong bộ chọn.

Ghi chú: Cần tiếp tục đối soát các mã 1.012776–1.012779 và toàn bộ mã appendix từ các trang chi tiết chính thức; chỉ lưu tên khi nguồn xác minh được.

## Bổ sung đối soát từ Cổng Dịch vụ công Quốc gia

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012776
- Mã 1.012776: Chuyển hình thức giao đất, cho thuê đất mà người sử dụng đất là hộ gia đình, cá nhân.

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012777
- Mã 1.012777: Điều chỉnh quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất do thay đổi căn cứ quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất mà người sử dụng đất là hộ gia đình, cá nhân.

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012778
- Mã 1.012778: Điều chỉnh quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất do sai sót về ranh giới, vị trí, diện tích, mục đích sử dụng giữa bản đồ quy hoạch, bản đồ địa chính, quyết định giao đất, cho thuê đất, cho phép chuyển mục đích sử dụng đất và số liệu bàn giao đất trên thực địa mà người sử dụng đất là hộ gia đình, cá nhân.

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012779
- Mã 1.012779: Giao đất, cho thuê đất từ quỹ đất do tổ chức, người gốc Việt Nam định cư ở nước ngoài, tổ chức kinh tế có vốn đầu tư nước ngoài sử dụng đất quy định tại Điều 180 Luật Đất đai, do công ty nông, lâm trường quản lý, sử dụng quy định tại Điều 181 Luật Đất đai mà người xin giao đất, cho thuê đất là cá nhân.

Các tên trên được trích từ tiêu đề trang DVC tương ứng; cần giữ nguyên dấu câu và đối chiếu thêm mã 1.012775 đã ghi ở phần trước.

## Đối soát tiếp theo từ Cổng Dịch vụ công Quốc gia

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784
- Mã 1.012784: **Tách thửa hoặc hợp thửa đất.** Trang chi tiết liên kết mã nội bộ 348171; có Mẫu số 21 và Mẫu số 22.

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012785
- Mã 1.012785: **Đăng ký, cấp Giấy chứng nhận đối với trường hợp đã chuyển quyền sử dụng đất trước ngày 01 tháng 8 năm 2024 mà bên chuyển quyền đã được cấp Giấy chứng nhận nhưng chưa thực hiện thủ tục chuyển quyền theo quy định.** Trang chi tiết liên kết mã nội bộ 348172.

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012786
- Trang trả về nội dung đăng nhập, chưa lấy được tên thủ tục xác minh; **không suy đoán tên**.

Nguồn: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012787
- Mã 1.012787: **Đăng ký, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất cho người nhận chuyển nhượng quyền sử dụng đất, quyền sở hữu nhà ở, công trình xây dựng trong dự án bất động sản.** Trang chi tiết liên kết mã nội bộ 348174.

Các tên trên được lấy từ tiêu đề trang DVC tương ứng; chỉ mã 1.012786 còn giữ trạng thái cần đối soát.
