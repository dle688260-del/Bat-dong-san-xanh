import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsMobile } from "@/hooks/useMobile";
import { trpc } from "@/lib/trpc";
import {
  Activity,
  ArrowLeft,
  Bell,
  BookOpen,
  Bot,
  ChevronDown,
  CircleDollarSign,
  ClipboardCheck,
  ClipboardList,
  Database,
  FileCheck2,
  FolderOpen,
  Grid2X2,
  Handshake,
  LayoutDashboard,
  LogIn,
  LogOut,
  MessageCircle,
  PanelLeft,
  Search,
  ShieldAlert,
  Sparkles,
  Users,
  X,
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export const DASHBOARD_MENU_ITEMS = [
  { icon: LayoutDashboard, label: "CRM tổng quan", path: "/crm" },
  {
    icon: LayoutDashboard,
    label: "Trung tâm điều hành KPI",
    path: "/dashboard",
  },
  { icon: Users, label: "1. Nguồn hàng & BĐS", path: "/quan-ly-moi-gioi" },
  { icon: MessageCircle, label: "2. Tư vấn & ký gửi", path: "/quan-ly" },
  { icon: Sparkles, label: "3. Marketing", path: "/dashboard/marketing" },
  { icon: Users, label: "4. Khách hàng & Lead", path: "/dashboard/khach-hang" },
  { icon: Bot, label: "5. AI Matching & Trợ lý", path: "/dashboard/ai" },
  {
    icon: ClipboardCheck,
    label: "6. Quy trình môi giới",
    path: "/quy-trinh-moi-gioi",
  },
  { icon: Handshake, label: "7. Giao dịch", path: "/dashboard/giao-dich" },
  { icon: ClipboardList, label: "8. Hồ sơ điện tử", path: "/ho-so-dien-tu" },
  { icon: FileCheck2, label: "9. Hồ sơ đất đai AI", path: "/hs-dat-dai-ai" },
  {
    icon: Database,
    label: "10. AI Kho pháp lý hồ sơ",
    path: "/ai-kho-phap-ly",
  },
  { icon: FolderOpen, label: "11. Kho lưu trữ", path: "/kho-luu-tru" },
  {
    icon: CircleDollarSign,
    label: "12. Báo cáo & Quản trị",
    path: "/dashboard/bao-cao",
  },
  { icon: LayoutDashboard, label: "Quản trị Module", path: "/quan-tri-module" },
  { icon: LayoutDashboard, label: "Trang chủ", path: "/" },
];

export function isDashboardPathActive(currentPath: string, targetPath: string) {
  return currentPath === targetPath || currentPath.startsWith(`${targetPath}?`);
}

const menuItemsByPath = (paths: string[]) =>
  DASHBOARD_MENU_ITEMS.filter(item => paths.includes(item.path));

export const DASHBOARD_MENU_GROUPS = [
  {
    id: "overview",
    label: "1 · Trung tâm điều hành",
    description: "KPI, cảnh báo và toàn cảnh vận hành",
    items: menuItemsByPath(["/crm", "/dashboard"]),
  },
  {
    id: "inventory",
    label: "2 · Nguồn hàng & BĐS",
    description: "Tiếp nhận, khảo sát, pháp lý, định giá và ký gửi",
    items: menuItemsByPath(["/quan-ly-moi-gioi", "/quan-ly"]),
  },
  {
    id: "marketing",
    label: "3 · Marketing",
    description: "Nội dung, chiến dịch, kênh và chuyển đổi",
    items: menuItemsByPath(["/dashboard/marketing"]),
  },
  {
    id: "customers",
    label: "4 · Khách hàng & Lead",
    description: "Lead, tư vấn, phân loại và chăm sóc",
    items: menuItemsByPath(["/dashboard/khach-hang"]),
  },
  {
    id: "ai",
    label: "5 · AI Matching & Trợ lý",
    description: "Ghép khách, phân tích nhu cầu và đề xuất bước tiếp theo",
    items: menuItemsByPath(["/dashboard/ai"]),
  },
  {
    id: "process",
    label: "6 · Quy trình môi giới",
    description: "Checklist, nhiệm vụ và tự động hóa theo giai đoạn",
    items: menuItemsByPath(["/quy-trinh-moi-gioi"]),
  },
  {
    id: "transactions",
    label: "7 · Giao dịch",
    description: "Đàm phán, đặt cọc, công chứng, sang tên và bàn giao",
    items: menuItemsByPath(["/dashboard/giao-dich"]),
  },
  {
    id: "dossiers",
    label: "8 · Hồ sơ điện tử",
    description: "Hợp đồng, biểu mẫu, tài liệu và bộ hồ sơ",
    items: menuItemsByPath(["/ho-so-dien-tu"]),
  },
  {
    id: "ai-production",
    label: "9 · AI pháp lý & Hồ sơ đất đai",
    description: "Tạo, phân tích và kiểm tra hồ sơ theo thủ tục",
    items: menuItemsByPath(["/hs-dat-dai-ai", "/ai-kho-phap-ly"]),
  },
  {
    id: "storage",
    label: "10 · Kho lưu trữ",
    description: "Tài liệu BĐS, pháp lý, quy hoạch và giao dịch",
    items: menuItemsByPath(["/kho-luu-tru"]),
  },
  {
    id: "reports",
    label: "11 · Báo cáo & Quản trị",
    description: "Doanh số, hoa hồng, hiệu suất và kiểm soát",
    items: menuItemsByPath(["/dashboard/bao-cao", "/quan-tri-module"]),
  },
  {
    id: "storefront",
    label: "Website bán hàng",
    description: "Xem trải nghiệm công khai",
    items: menuItemsByPath(["/"]),
  },
];

export const DASHBOARD_MENU_SUBITEMS: Record<
  string,
  Array<{ label: string; path: string }>
> = {
  "/crm": [
    { label: "Tổng quan CRM", path: "/crm" },
    { label: "Khách hàng & lead", path: "/dashboard/khach-hang" },
    { label: "Nguồn hàng", path: "/quan-ly-moi-gioi" },
    { label: "Quản trị Module", path: "/quan-tri-module" },
    { label: "Hồ sơ & AI", path: "/ho-so-dien-tu" },
    {
      label: "Hồ sơ đất đai AI · Tạo & phân tích",
      path: "/hs-dat-dai-ai?tab=create",
    },
    { label: "AI Kho hồ sơ pháp lý", path: "/ai-kho-phap-ly" },
  ],
  "/dashboard": [
    { label: "Tổng quan KPI", path: "/dashboard" },
    { label: "Lead từ AI", path: "/dashboard/khach-hang" },
    { label: "Hoạt động gần đây", path: "/dashboard" },
  ],
  "/": [
    { label: "Nguồn hàng nổi bật", path: "/bat-dong-san" },
    { label: "Danh mục BĐS", path: "/bat-dong-san" },
    { label: "Tư vấn nhanh", path: "/quan-ly" },
  ],
  "/bat-dong-san": [
    { label: "Tất cả nguồn hàng", path: "/bat-dong-san" },
    { label: "Nhà phố & căn hộ", path: "/bat-dong-san" },
    { label: "Đất nền & đất dự án", path: "/bat-dong-san" },
    { label: "Cho thuê & nghỉ dưỡng", path: "/bat-dong-san" },
  ],
  "/quan-ly-moi-gioi": [
    { label: "Danh sách nguồn hàng", path: "/quan-ly-moi-gioi" },
    { label: "Đăng sản phẩm mới", path: "/quan-ly-moi-gioi" },
    { label: "Chỉnh sửa & công khai", path: "/quan-ly-moi-gioi" },
    { label: "Hồ sơ tài sản", path: "/kho-luu-tru" },
  ],
  "/dashboard/khach-hang": [
    { label: "Lead mới", path: "/dashboard/khach-hang" },
    { label: "Lead AI đã phân tích", path: "/dashboard/khach-hang" },
    { label: "Phân công môi giới", path: "/dashboard/khach-hang" },
  ],
  "/quan-ly": [
    { label: "Đăng ký tư vấn", path: "/quan-ly" },
    { label: "Ký gửi bất động sản", path: "/quan-ly" },
    { label: "Đặt lịch xem", path: "/quan-ly" },
  ],
  "/quy-trinh-moi-gioi": [
    { label: "12 bước môi giới", path: "/quy-trinh-moi-gioi" },
    { label: "Công việc đang chờ", path: "/quy-trinh-moi-gioi" },
  ],
  "/dashboard/giao-dich": [
    { label: "Pipeline giao dịch", path: "/dashboard/giao-dich" },
    { label: "Đặt cọc & công chứng", path: "/dashboard/giao-dich" },
    { label: "Hoàn tất & bàn giao", path: "/dashboard/giao-dich" },
  ],
  "/dashboard/marketing": [
    { label: "Đăng đa kênh", path: "/ho-so-dien-tu" },
    { label: "Website", path: "/dashboard/marketing" },
    { label: "Facebook", path: "/dashboard/marketing" },
    { label: "Zalo", path: "/dashboard/marketing" },
  ],
  "/ho-so-dien-tu": [
    { label: "Hồ sơ điện tử AI", path: "/ho-so-dien-tu" },
    { label: "Đăng đa kênh", path: "/ho-so-dien-tu" },
    { label: "Quy trình 12 bước", path: "/ho-so-dien-tu" },
  ],
  "/ho-so-ai": [
    { label: "Danh sách hồ sơ AI", path: "/ho-so-ai" },
    { label: "Tạo hồ sơ mới", path: "/ho-so-ai" },
    { label: "Tiến độ xử lý", path: "/ho-so-ai" },
  ],
  "/hs-dat-dai-ai": [
    {
      label: "Mục 1 · Tạo hồ sơ & AI phân tích",
      path: "/hs-dat-dai-ai?tab=create",
    },
    { label: "Mục 2 · Hồ sơ của tôi", path: "/hs-dat-dai-ai?tab=mine" },
    {
      label: "Mục 3 · AI chuyên trách đất đai",
      path: "/hs-dat-dai-ai?tab=specialized",
    },
  ],
  "/ai-ho-so-dat-dai": [
    {
      label: "Mục 1 · Tạo hồ sơ & AI phân tích",
      path: "/hs-dat-dai-ai?tab=create",
    },
    { label: "Mục 2 · Hồ sơ của tôi", path: "/hs-dat-dai-ai?tab=mine" },
    {
      label: "Mục 3 · AI chuyên trách đất đai",
      path: "/hs-dat-dai-ai?tab=specialized",
    },
  ],
  "/ai-lap-ho-so-dat-dai": [
    { label: "Tạo bộ hồ sơ", path: "/ai-lap-ho-so-dat-dai" },
    { label: "Điền biểu mẫu", path: "/ai-lap-ho-so-dat-dai" },
    { label: "Xem trước & tải xuống", path: "/ai-lap-ho-so-dat-dai" },
  ],
  "/ai-ho-so-dat-dai-tu-dong": [
    { label: "Chọn thủ tục & quét nguồn", path: "/ai-ho-so-dat-dai-tu-dong" },
    { label: "AI phân tích & ghép mẫu", path: "/ai-ho-so-dat-dai-tu-dong" },
    { label: "Nhập dữ liệu & tải giấy tờ", path: "/ai-ho-so-dat-dai-tu-dong" },
    { label: "Kiểm tra & xem bộ hồ sơ", path: "/ai-ho-so-dat-dai-tu-dong" },
  ],
  "/ai-ho-so-dat-dai-tu-dong-moi": [
    { label: "Tôi muốn làm thủ tục", path: "/ai-ho-so-dat-dai-tu-dong-moi" },
    {
      label: "AI tự quét nguồn chính thức",
      path: "/ai-ho-so-dat-dai-tu-dong-moi",
    },
    {
      label: "Workflow & thành phần hồ sơ",
      path: "/ai-ho-so-dat-dai-tu-dong-moi",
    },
    {
      label: "OCR, kiểm tra & xuất hồ sơ",
      path: "/ai-ho-so-dat-dai-tu-dong-moi",
    },
  ],
  "/ai-ho-so-dat-dai-van-hanh": [
    { label: "Nguồn & đồng bộ crawler", path: "/ai-ho-so-dat-dai-van-hanh" },
    {
      label: "Lịch sử phiên bản quy trình",
      path: "/ai-ho-so-dat-dai-van-hanh",
    },
    { label: "Mapping biểu mẫu", path: "/ai-ho-so-dat-dai-van-hanh" },
    { label: "Audit hồ sơ", path: "/ai-ho-so-dat-dai-van-hanh" },
  ],
  "/ai-kho-phap-ly": [
    { label: "Kho biểu mẫu chính thức", path: "/ai-kho-phap-ly" },
    { label: "Nguồn luật & nghị định", path: "/ai-kho-phap-ly" },
    { label: "Đối chiếu nguồn pháp lý", path: "/ai-kho-phap-ly" },
    { label: "AI lập hồ sơ đất đai", path: "/ai-lap-ho-so-dat-dai" },
    { label: "AI hồ sơ đất đai tự động", path: "/ai-ho-so-dat-dai-tu-dong" },
    {
      label: "AI hồ sơ đất đai tự động nâng cao",
      path: "/ai-ho-so-dat-dai-tu-dong-moi",
    },
    {
      label: "AI vận hành & kiểm tra hồ sơ",
      path: "/ai-ho-so-dat-dai-van-hanh",
    },
  ],
  "/dashboard/ai": [
    { label: "Trợ lý AI", path: "/dashboard/ai" },
    { label: "AI Kho pháp lý hồ sơ AI", path: "/ai-kho-phap-ly" },
    {
      label: "Hồ sơ đất đai AI · Tạo & phân tích",
      path: "/hs-dat-dai-ai?tab=create",
    },
    { label: "Điều phối lead", path: "/dashboard/khach-hang" },
    { label: "Phân tích nhu cầu", path: "/dashboard/ai" },
  ],
  "/dashboard/bao-cao": [
    { label: "Báo cáo nguồn hàng", path: "/dashboard/bao-cao" },
    { label: "Báo cáo khách hàng", path: "/dashboard/bao-cao" },
    { label: "Báo cáo giao dịch", path: "/dashboard/bao-cao" },
  ],
  "/kho-luu-tru": [
    { label: "Hồ sơ bất động sản", path: "/kho-luu-tru" },
    { label: "Pháp lý & quy hoạch", path: "/kho-luu-tru" },
    { label: "Định giá & thị trường", path: "/kho-luu-tru" },
    { label: "Marketing & giao dịch", path: "/kho-luu-tru" },
  ],
};

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;

export function getStoredSidebarWidth(
  storage: Pick<Storage, "getItem"> | undefined,
  fallback = DEFAULT_WIDTH
) {
  const saved = storage?.getItem(SIDEBAR_WIDTH_KEY);
  const parsed = saved ? Number.parseInt(saved, 10) : Number.NaN;
  return Number.isFinite(parsed) && parsed >= MIN_WIDTH && parsed <= MAX_WIDTH
    ? parsed
    : fallback;
}

export default function DashboardLayout({
  children,
  allowNonAdmin = false,
}: {
  children: React.ReactNode;
  /** Cho phép tài khoản đã đăng nhập dùng các thao tác Nháp ở module nguồn hàng. */
  allowNonAdmin?: boolean;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(DEFAULT_WIDTH);
  const { loading, user } = useAuth();

  useEffect(() => {
    setSidebarWidth(
      getStoredSidebarWidth(
        typeof window === "undefined" ? undefined : window.localStorage
      )
    );
  }, []);

  useEffect(() => {
    window.localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) {
    return <DashboardLayoutSkeleton />;
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-8 p-8 max-w-md w-full">
          <div className="flex flex-col items-center gap-6">
            <h1 className="text-2xl font-semibold tracking-tight text-center">
              {window.location.pathname.startsWith("/crm")
                ? "Đăng nhập CRM"
                : "Sign in to continue"}
            </h1>
            <p className="text-sm text-muted-foreground text-center max-w-sm">
              Khu vực này dành cho quản trị viên. Khách hàng có thể xem các bất
              động sản đang công khai mà không cần đăng nhập.
            </p>
          </div>
          <Button
            onClick={() => {
              window.location.href = "/crm/login";
            }}
            size="lg"
            className="w-full shadow-lg hover:shadow-xl transition-all"
          >
            Đăng nhập quản trị
          </Button>
        </div>
      </div>
    );
  }

  if (user.role !== "admin" && !allowNonAdmin) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f5f7f4] px-5 py-10 text-[#123d32]">
        <section
          className="w-full max-w-lg rounded-[32px] bg-white p-7 text-center shadow-[0_24px_70px_rgba(20,64,50,0.14)] ring-1 ring-[#dce7df] sm:p-10"
          aria-labelledby="forbidden-title"
        >
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-[26px] bg-[#fff5e3] text-[#b27b17] ring-8 ring-[#fffaf1]">
            <ShieldAlert size={40} strokeWidth={1.8} aria-hidden="true" />
          </div>
          <p className="mt-7 text-xs font-black uppercase tracking-[0.22em] text-[#b27b17]">
            Lỗi 403 · Không có quyền
          </p>
          <h1
            id="forbidden-title"
            className="mt-3 text-3xl font-black tracking-tight sm:text-4xl"
          >
            Trang này dành cho quản trị viên
          </h1>
          <p className="mx-auto mt-4 max-w-md text-sm leading-7 text-[#63746d] sm:text-base">
            Tài khoản hiện tại chưa được cấp quyền truy cập khu vực quản lý nội
            bộ. Bạn có thể đăng nhập bằng tài khoản admin hoặc tiếp tục xem các
            bất động sản đang bán.
          </p>
          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            <Button
              type="button"
              onClick={() => {
                window.location.href = "/crm/login";
              }}
              className="min-h-12 rounded-xl bg-[#1f5a4a] font-bold text-white hover:bg-[#164638]"
            >
              <LogIn size={18} className="mr-2" aria-hidden="true" />
              Đăng nhập admin
            </Button>
            <a
              href="/bat-dong-san"
              className="inline-flex min-h-12 items-center justify-center rounded-xl border border-[#cbdad2] px-4 text-sm font-bold text-[#1f5a4a] transition hover:bg-[#eef6f0]"
            >
              <ArrowLeft size={18} className="mr-2" aria-hidden="true" />
              Về Mua BĐS
            </a>
          </div>
          <p className="mt-6 text-xs text-[#8a9992]">
            Nếu bạn cho rằng đây là nhầm lẫn, hãy liên hệ chủ website để được
            cấp quyền.
          </p>
        </section>
      </main>
    );
  }

  return (
    <SidebarProvider
      defaultOpen={false}
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}

type DashboardLayoutContentProps = {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
};

export type ConsignmentNotification = {
  id: number;
  name: string;
  phone: string;
  interest: string;
  message: string | null;
  createdAt: Date | string | number;
  status: "new" | "contacted" | "closed";
};

export const NOTIFICATION_READ_STORAGE_KEY = "bdsxanh-crm-read-notifications";

export function filterNewConsignmentRequests(
  requests: ConsignmentNotification[]
) {
  return requests.filter(
    request =>
      request.status === "new" && request.interest === "Ký gửi bất động sản"
  );
}

export function filterNewConsultationRequests(
  requests: ConsignmentNotification[]
) {
  return requests.filter(request => request.status === "new");
}

export function getConsultationNotificationLabel(interest: string) {
  if (interest === "Ký gửi bất động sản") return "Yêu cầu ký gửi mới";
  if (interest.startsWith("Đặt lịch xem:")) return "Yêu cầu đặt lịch xem";
  return "Yêu cầu tư vấn mới";
}

export function getReadNotificationIds() {
  if (typeof window === "undefined") return new Set<number>();
  try {
    const stored = JSON.parse(
      window.localStorage.getItem(NOTIFICATION_READ_STORAGE_KEY) ?? "[]"
    );
    return new Set<number>(
      Array.isArray(stored)
        ? stored.filter(value => Number.isInteger(value))
        : []
    );
  } catch {
    return new Set<number>();
  }
}

export function markNotificationsAsRead(ids: number[]) {
  if (typeof window === "undefined" || ids.length === 0) return;
  const merged = new Set<number>(
    Array.from(getReadNotificationIds()).concat(ids)
  );
  window.localStorage.setItem(
    NOTIFICATION_READ_STORAGE_KEY,
    JSON.stringify(Array.from(merged))
  );
  window.dispatchEvent(new CustomEvent("bdsxanh-notifications-read"));
}

export function countUnreadNotifications(requests: ConsignmentNotification[]) {
  const readIds = getReadNotificationIds();
  return requests.filter(request => !readIds.has(request.id)).length;
}

function NotificationBell({
  count,
  requests,
  onOpen,
}: {
  count: number;
  requests: ConsignmentNotification[];
  onOpen: () => void;
}) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="relative h-9 w-9 rounded-full text-foreground hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={
            count > 0 ? `${count} yêu cầu tư vấn mới` : "Thông báo tư vấn"
          }
        >
          <Bell className="h-5 w-5" />
          {count > 0 ? (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1 text-[11px] font-bold leading-none text-destructive-foreground">
              {count > 99 ? "99+" : count}
            </span>
          ) : null}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-2">
        <div className="px-2 py-2 text-sm font-bold text-foreground">
          Thông báo tư vấn
        </div>
        {requests.length === 0 ? (
          <div className="px-2 py-4 text-sm text-muted-foreground">
            Chưa có yêu cầu tư vấn mới.
          </div>
        ) : (
          requests.map(request => (
            <DropdownMenuItem
              key={request.id}
              className="cursor-pointer items-start gap-3 rounded-lg p-3"
              onClick={() => {
                markNotificationsAsRead(requests.map(request => request.id));
                onOpen();
              }}
            >
              <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-destructive" />
              <span className="min-w-0">
                <span className="block truncate font-semibold">
                  {request.name}
                </span>
                <span className="block truncate text-xs text-muted-foreground">
                  {request.phone} ·{" "}
                  {getConsultationNotificationLabel(request.interest)}
                </span>
              </span>
            </DropdownMenuItem>
          ))
        )}
        <DropdownMenuItem
          className="mt-1 cursor-pointer justify-center font-semibold text-primary"
          onClick={() => {
            markNotificationsAsRead(requests.map(request => request.id));
            onOpen();
          }}
        >
          Xem danh sách đăng ký tư vấn
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const [launcherOpen, setLauncherOpen] = useState(false);
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const changePasswordMutation = trpc.auth.changePassword.useMutation({
    onSuccess: () => {
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setChangePasswordOpen(false);
    },
  });
  const [expandedMenuGroups, setExpandedMenuGroups] = useState<
    Record<string, boolean>
  >({ overview: true });
  const [expandedMenuItems, setExpandedMenuItems] = useState<
    Record<string, boolean>
  >({});
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeMenuItem = DASHBOARD_MENU_ITEMS.find(
    item => item.path === location
  );
  const isMobile = useIsMobile();
  const consultationQuery = trpc.consultations.list.useQuery(undefined, {
    enabled: user?.role === "admin",
    refetchInterval: user?.role === "admin" ? 30_000 : false,
    staleTime: 15_000,
  });
  const newConsultationRequests = filterNewConsultationRequests(
    consultationQuery.data ?? []
  );
  const [readNotificationVersion, setReadNotificationVersion] = useState(0);
  const unreadConsultationRequests = newConsultationRequests.filter(
    request => !getReadNotificationIds().has(request.id)
  );
  void readNotificationVersion;

  useEffect(() => {
    const handleNotificationsRead = () =>
      setReadNotificationVersion(version => version + 1);
    window.addEventListener(
      "bdsxanh-notifications-read",
      handleNotificationsRead
    );
    return () =>
      window.removeEventListener(
        "bdsxanh-notifications-read",
        handleNotificationsRead
      );
  }, []);

  useEffect(() => {
    if (isCollapsed) {
      setIsResizing(false);
    }
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;

      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar
          collapsible="icon"
          className="border-r-0 bg-[#0B4F3A] text-white"
          disableTransition={isResizing}
        >
          <SidebarHeader className="h-[72px] justify-center border-b border-white/10 bg-[#0B4F3A]">
            <div className="flex items-center gap-3 px-3 transition-all w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center rounded-lg text-white/80 transition-colors hover:bg-white/12 focus:outline-none focus-visible:ring-2 focus-visible:ring-white shrink-0"
                aria-label="Toggle navigation"
              >
                <PanelLeft className="h-4 w-4" />
              </button>
              {!isCollapsed ? (
                <div className="flex items-center gap-2 min-w-0">
                  <span className="truncate text-base font-bold tracking-tight text-foreground">
                    BĐS CRM
                  </span>
                </div>
              ) : null}
              <NotificationBell
                count={unreadConsultationRequests.length}
                requests={newConsultationRequests}
                onOpen={() => setLocation("/quan-ly")}
              />
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0 bg-[#0B4F3A] px-2 py-4">
            <SidebarMenu className="px-0 py-1">
              {DASHBOARD_MENU_ITEMS.map(item => {
                const isActive = isDashboardPathActive(location, item.path);
                return (
                  <SidebarMenuItem key={item.path}>
                    <SidebarMenuButton
                      isActive={isActive}
                      onClick={() => setLocation(item.path)}
                      tooltip={item.label}
                      className={`h-11 rounded-lg text-[14px] font-medium tracking-[0.01em] text-white/80 transition-all hover:bg-white/12 hover:text-white data-[active=true]:bg-[#0F6B4F] data-[active=true]:font-bold data-[active=true]:text-white`}
                    >
                      <item.icon
                        className={`h-5 w-5 shrink-0 ${isActive ? "text-white" : "text-white/70"}`}
                      />
                      <span>{item.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="border-t border-white/10 bg-[#0B4F3A] p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 rounded-lg px-1 py-1 hover:bg-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <Avatar className="h-9 w-9 border shrink-0">
                    <AvatarFallback className="text-xs font-medium">
                      {user?.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                    <p className="text-sm font-medium truncate leading-none">
                      {user?.name || "-"}
                    </p>
                    <p className="text-xs text-muted-foreground truncate mt-1.5">
                      {user?.email || "-"}
                    </p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem
                  onClick={() => {
                    changePasswordMutation.reset();
                    setChangePasswordOpen(true);
                  }}
                  className="cursor-pointer"
                >
                  <ShieldAlert className="mr-2 h-4 w-4" />
                  <span>Đổi mật khẩu</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={logout}
                  className="cursor-pointer text-destructive focus:text-destructive"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sign out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => {
            if (isCollapsed) return;
            setIsResizing(true);
          }}
          style={{ zIndex: 50 }}
        />
      </div>

      {changePasswordOpen && (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/35 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="change-password-title"
        >
          <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl">
            <div className="mb-4 flex items-start justify-between gap-4">
              <div>
                <h2
                  id="change-password-title"
                  className="text-lg font-semibold text-slate-900"
                >
                  Đổi mật khẩu quản trị
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Mật khẩu mới được lưu dưới dạng hash, không lưu dạng văn bản.
                </p>
              </div>
              <button
                type="button"
                className="rounded-md p-1 text-slate-500 hover:bg-slate-100"
                onClick={() => setChangePasswordOpen(false)}
                aria-label="Đóng"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form
              className="space-y-3"
              onSubmit={event => {
                event.preventDefault();
                changePasswordMutation.mutate({
                  currentPassword,
                  newPassword,
                  confirmPassword,
                });
              }}
            >
              <label className="block text-sm font-medium text-slate-700">
                Mật khẩu hiện tại
                <Input
                  className="mt-1"
                  type="password"
                  value={currentPassword}
                  onChange={event => setCurrentPassword(event.target.value)}
                  autoComplete="current-password"
                  required
                />
              </label>
              <label className="block text-sm font-medium text-slate-700">
                Mật khẩu mới
                <Input
                  className="mt-1"
                  type="password"
                  value={newPassword}
                  onChange={event => setNewPassword(event.target.value)}
                  autoComplete="new-password"
                  minLength={8}
                  required
                />
              </label>
              <label className="block text-sm font-medium text-slate-700">
                Nhập lại mật khẩu mới
                <Input
                  className="mt-1"
                  type="password"
                  value={confirmPassword}
                  onChange={event => setConfirmPassword(event.target.value)}
                  autoComplete="new-password"
                  minLength={8}
                  required
                />
              </label>
              {changePasswordMutation.error && (
                <p className="text-sm text-red-600" role="alert">
                  {changePasswordMutation.error.message}
                </p>
              )}
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setChangePasswordOpen(false)}
                >
                  Hủy
                </Button>
                <Button
                  type="submit"
                  disabled={changePasswordMutation.isPending}
                  className="bg-[#0F6B4F] hover:bg-[#0B4F3A]"
                >
                  {changePasswordMutation.isPending
                    ? "Đang lưu…"
                    : "Lưu mật khẩu"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <SidebarInset className="bg-[#F8FAF7]">
        {!isMobile && (
          <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-[#DCE9E1] bg-white px-3 sm:px-4">
            <div className="flex items-center gap-3 text-sm text-slate-500">
              <SidebarTrigger className="h-8 w-8 rounded-md text-slate-600 hover:bg-slate-100" />
              <span className="text-[#0F6B4F]">Bất động sản</span>
              <span>/</span>
              <span className="font-semibold text-slate-800">
                {activeMenuItem?.label ?? "Hồ sơ BĐS"}
              </span>
            </div>
            <div className="flex items-center gap-5">
              <div className="hidden h-10 w-[320px] items-center gap-2 rounded-full border border-slate-200 px-4 text-sm text-slate-400 lg:flex">
                <Search className="h-4 w-4" />
                <span>Tìm kiếm BĐS, khách hàng...</span>
              </div>
              <button
                type="button"
                onClick={() => setLauncherOpen(open => !open)}
                aria-expanded={launcherOpen}
                aria-controls="workspace-launcher"
                className={`hidden items-center gap-2 rounded-lg border px-3 py-2 text-xs font-bold transition lg:inline-flex ${launcherOpen ? "border-[#0F6B4F] bg-[#EAF3EE] text-[#0F6B4F]" : "border-slate-200 bg-white text-slate-600 hover:border-[#9DC7B1] hover:bg-[#F3F8F4]"}`}
              >
                <Grid2X2 className="h-4 w-4" />
                Tất cả cửa sổ
              </button>
              <NotificationBell
                count={unreadConsultationRequests.length}
                requests={newConsultationRequests}
                onOpen={() => setLocation("/quan-ly")}
              />
              <div className="flex items-center gap-2 border-l border-slate-200 pl-4">
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-[#EAF3EE] text-[#0F6B4F]">
                    {user?.name?.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden text-left sm:block">
                  <p className="text-sm font-semibold text-slate-800">
                    {user?.name || "Môi giới"}
                  </p>
                  <p className="text-xs text-slate-500">Môi giới</p>
                </div>
              </div>
            </div>
          </header>
        )}
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-2 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setLauncherOpen(open => !open)}
                aria-expanded={launcherOpen}
                aria-controls="workspace-launcher"
                aria-label="Mở tất cả cửa sổ làm việc"
                className={`inline-flex h-9 w-9 items-center justify-center rounded-lg border transition ${launcherOpen ? "border-[#0F6B4F] bg-[#EAF3EE] text-[#0F6B4F]" : "border-slate-200 bg-white text-slate-600"}`}
              >
                <Grid2X2 className="h-4 w-4" />
              </button>
              <SidebarTrigger className="h-9 w-9 rounded-lg bg-background" />

              <NotificationBell
                count={unreadConsultationRequests.length}
                requests={newConsultationRequests}
                onOpen={() => setLocation("/quan-ly")}
              />
              <div className="flex items-center gap-3">
                <div className="flex flex-col gap-1">
                  <span className="tracking-tight text-foreground">
                    {activeMenuItem?.label ?? "Menu"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
        {launcherOpen ? (
          <div
            id="workspace-launcher"
            role="dialog"
            aria-label="Bảng điều khiển cửa sổ làm việc"
            className="fixed right-3 top-16 z-50 w-[min(94vw,720px)] rounded-2xl border border-[#CFE1D6] bg-white p-4 shadow-[0_24px_70px_rgba(15,75,55,0.2)] sm:right-6 sm:top-[4.5rem] sm:p-5"
          >
            <div className="flex items-start justify-between gap-4 border-b border-[#E6EFE9] pb-3">
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.18em] text-[#B27B17]">
                  Trung tâm điều hướng
                </p>
                <h2 className="mt-1 text-lg font-black text-[#123D32]">
                  Tất cả cửa sổ làm việc
                </h2>
                <p className="mt-1 text-xs leading-5 text-[#6B7F76]">
                  Chọn một mục để mở trực tiếp khu vực quản lý tương ứng.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setLauncherOpen(false)}
                aria-label="Đóng bảng điều khiển"
                className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[#6B7F76] hover:bg-[#F1F6F2] hover:text-[#123D32]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-4 max-h-[min(66vh,520px)] space-y-2 overflow-y-auto pr-1">
              {DASHBOARD_MENU_GROUPS.map(group => {
                const isExpanded = Boolean(expandedMenuGroups[group.id]);
                const hasActiveItem = group.items.some(item =>
                  isDashboardPathActive(location, item.path)
                );
                return (
                  <section
                    key={group.id}
                    className={`overflow-hidden rounded-xl border ${hasActiveItem ? "border-[#9DC7B1] bg-[#F5FAF6]" : "border-[#E6EFE9] bg-[#FBFDFC]"}`}
                  >
                    <button
                      type="button"
                      aria-expanded={isExpanded}
                      aria-controls={`menu-group-${group.id}`}
                      onClick={() =>
                        setExpandedMenuGroups(previous => ({
                          ...previous,
                          [group.id]: !isExpanded,
                        }))
                      }
                      className="flex w-full items-center justify-between gap-3 px-3 py-3 text-left hover:bg-[#F1F8F3]"
                    >
                      <span className="min-w-0">
                        <span className="flex items-center gap-2 text-sm font-black text-[#123D32]">
                          <span
                            className={`h-2 w-2 rounded-full ${hasActiveItem ? "bg-[#B27B17]" : "bg-[#9DC7B1]"}`}
                          />
                          {group.label}
                          <span className="text-[11px] font-bold text-[#789087]">
                            {group.items.length}
                          </span>
                        </span>
                        <span className="mt-1 block pl-4 text-[11px] text-[#6B7F76]">
                          {group.description}
                        </span>
                      </span>
                      <ChevronDown
                        className={`h-4 w-4 shrink-0 text-[#6F9A80] transition-transform ${isExpanded ? "rotate-180" : ""}`}
                      />
                    </button>
                    {isExpanded ? (
                      <div
                        id={`menu-group-${group.id}`}
                        className="grid grid-cols-2 gap-2 border-t border-[#E6EFE9] p-2 sm:grid-cols-3"
                      >
                        {group.items.map(item => {
                          const isActive = isDashboardPathActive(
                            location,
                            item.path
                          );
                          const subItems =
                            DASHBOARD_MENU_SUBITEMS[item.path] ?? [];
                          const isSubmenuExpanded = Boolean(
                            expandedMenuItems[item.path]
                          );
                          return (
                            <div
                              key={`launcher-${item.path}`}
                              className={`rounded-lg border ${isActive ? "border-[#9DC7B1] bg-[#F5FAF6]" : "border-[#E6EFE9] bg-white"}`}
                            >
                              <div className="flex min-h-[78px] items-start gap-2 p-2.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setLauncherOpen(false);
                                    setLocation(item.path);
                                  }}
                                  className={`group flex min-w-0 flex-1 flex-col items-start justify-between text-left transition active:scale-[.98] ${isActive ? "text-[#0F6B4F]" : "text-[#315B4B]"}`}
                                >
                                  <item.icon
                                    className={`h-4 w-4 ${isActive ? "text-[#0F6B4F]" : "text-[#6F9A80]"}`}
                                  />
                                  <span className="mt-2 text-[11px] font-bold leading-4">
                                    {item.label}
                                  </span>
                                </button>
                                {subItems.length > 0 ? (
                                  <button
                                    type="button"
                                    aria-label={`${isSubmenuExpanded ? "Thu gọn" : "Mở"} menu phụ ${item.label}`}
                                    aria-expanded={isSubmenuExpanded}
                                    onClick={() =>
                                      setExpandedMenuItems(previous => ({
                                        ...previous,
                                        [item.path]: !isSubmenuExpanded,
                                      }))
                                    }
                                    className="rounded-md p-1 text-[#6F9A80] hover:bg-[#EAF3EE] hover:text-[#0F6B4F]"
                                  >
                                    <ChevronDown
                                      className={`h-4 w-4 transition-transform ${isSubmenuExpanded ? "rotate-180" : ""}`}
                                    />
                                  </button>
                                ) : null}
                              </div>
                              {isSubmenuExpanded ? (
                                <div className="border-t border-[#E6EFE9] px-2 pb-2 pt-1">
                                  {subItems.map(subItem => (
                                    <button
                                      key={`${item.path}-${subItem.label}`}
                                      type="button"
                                      onClick={() => {
                                        setLauncherOpen(false);
                                        setLocation(subItem.path);
                                      }}
                                      className="block w-full rounded-md px-2 py-1.5 text-left text-[10px] font-semibold text-[#527068] hover:bg-[#EAF3EE] hover:text-[#0F6B4F]"
                                    >
                                      {subItem.label}
                                    </button>
                                  ))}
                                </div>
                              ) : null}
                            </div>
                          );
                        })}
                      </div>
                    ) : null}
                  </section>
                );
              })}
            </div>
          </div>
        ) : null}
        <main className="internal-compact-shell flex-1 p-2 sm:p-3 md:p-4">
          {children}
        </main>
      </SidebarInset>
    </>
  );
}
