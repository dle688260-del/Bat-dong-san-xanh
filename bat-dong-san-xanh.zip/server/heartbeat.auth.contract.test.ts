import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("Heartbeat authentication transport", () => {
  it("accepts the platform session header before browser Authorization fallback", () => {
    const source = readFileSync(resolve(process.cwd(), "server/_core/sdk.ts"), "utf8");
    const headerIndex = source.indexOf('req.headers["x-manus-user-session"]');
    const platformResolveIndex = source.indexOf("this.getUserInfoWithJwt(heartbeatSession)");
    const verifyIndex = source.indexOf("const session = await this.verifySession(sessionToken)");

    expect(headerIndex).toBeGreaterThan(-1);
    expect(platformResolveIndex).toBeGreaterThan(headerIndex);
    expect(verifyIndex).toBeGreaterThan(platformResolveIndex);
    expect(source.slice(headerIndex, verifyIndex)).toContain("Cron session missing task_uid");
  });
});
