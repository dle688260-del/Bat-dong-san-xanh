from pathlib import Path
import re

path = Path('/home/ubuntu/bat-dong-san-xanh/client/src/pages/AIDossierAdmin.tsx')
text = path.read_text()

if 'LegalSourceRegistryPanel' not in text:
    text = text.replace(
        'import { LandProcedureGuidanceStep } from "@/components/LandProcedureGuidanceStep";\n',
        'import { LandProcedureGuidanceStep } from "@/components/LandProcedureGuidanceStep";\nimport { LegalSourceRegistryPanel } from "@/components/LegalSourceRegistryPanel";\n',
        1,
    )

pattern = re.compile(
    r'<div className="mt-3 rounded-xl border border-\[#D8E4DC\] bg-\[#F7FBF7\] p-3">'
    r'<div className="flex items-center justify-between gap-2">'
    r'<p className="text-xs font-black uppercase tracking-\[0\.12em\] text-\[#1F5A4A\]">Bộ nguồn AI tự gom theo thủ tục</p>'
    r'.*?</details></div>',
    re.S,
)
replacement = '<LegalSourceRegistryPanel procedureId={adminToBuilderProcedure[procedure.id] ?? procedure.id} title="Nguồn pháp lý từ AI Kho pháp lý hồ sơ AI" />'
text, count = pattern.subn(replacement, text, count=1)
if count != 1:
    raise SystemExit(f'Expected one duplicated legal source block, replaced {count}')

path.write_text(text)
print('Merged shared legal source registry into AIDossierAdmin and removed duplicated source panel.')
