import { describe, expect, it } from "vitest";
import { allDossiersAIGroups, allDossiersAIPlaceholder, landDossierToHubItem } from "./AllDossiersAI";

describe("All dossiers AI workspace", () => {
  it("exposes the complete cross-source dossier groups", () => {
    expect(allDossiersAIGroups()).toEqual([
      "all",
      "customer",
      "owner",
      "property",
      "legal",
      "tax",
      "transaction",
      "notary",
      "brokerage",
      "land",
    ]);
  });

  it("uses a cross-source search prompt rather than a legal-template prompt", () => {
    expect(allDossiersAIPlaceholder()).toContain("Hồ sơ chuyển nhượng đất");
  });

  it("maps a land dossier into the shared dossier hub", () => {
    expect(landDossierToHubItem({ id: 12, title: "Hồ sơ chuyển nhượng", dossierCode: "HS-ABC123", procedureType: "Đăng ký biến động", status: "completed", propertyId: 44 })).toEqual({
      id: "land-12",
      group: "land",
      title: "Hồ sơ chuyển nhượng",
      subtitle: "HS-ABC123 · Đăng ký biến động · BĐS #44",
      status: "Đã hoàn tất",
      propertyId: 44,
      icon: "file",
    });
  });
});
