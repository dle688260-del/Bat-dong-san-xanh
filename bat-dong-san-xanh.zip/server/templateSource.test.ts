import { describe, expect, it } from "vitest";
import { normalizeTemplateSource } from "./routers";

describe("templateSource normalization for land dossier export", () => {
  it("keeps a valid government URL", () => {
    expect(normalizeTemplateSource(" https://dichvucong.gov.vn/thu-tuc ")).toBe("https://dichvucong.gov.vn/thu-tuc");
  });

  it("falls back instead of rejecting malformed metadata", () => {
    expect(normalizeTemplateSource("not-a-url")).toBe("https://dichvucong.gov.vn");
    expect(normalizeTemplateSource("https://")).toBe("https://dichvucong.gov.vn");
  });

  it("rejects non-http protocols", () => {
    expect(normalizeTemplateSource("javascript:alert(1)")).toBe("https://dichvucong.gov.vn");
  });
});
