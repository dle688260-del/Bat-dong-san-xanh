import { describe, expect, it } from "vitest";
import { haversineKm } from "./CrmNearbyProperties";

describe("haversineKm", () => {
  it("returns zero for the same coordinate", () => {
    expect(haversineKm({ lat: 16.0544, lng: 108.2022 }, { lat: 16.0544, lng: 108.2022 })).toBe(0);
  });

  it("calculates a realistic short distance", () => {
    const distance = haversineKm({ lat: 16.0544, lng: 108.2022 }, { lat: 16.0600, lng: 108.2100 });
    expect(distance).toBeGreaterThan(0.5);
    expect(distance).toBeLessThan(2);
  });
});
