import { describe, expect, it } from "vitest";
import { canAccessSensitiveDossier, permissionMessage, sensitiveArchiveCategories } from "./permissions";

describe("sensitive dossier permissions", () => {
  it("only allows administrators to access sensitive dossiers", () => {
    expect(canAccessSensitiveDossier("admin", "view")).toBe(true);
    expect(canAccessSensitiveDossier("admin", "download")).toBe(true);
    expect(canAccessSensitiveDossier("admin", "manage")).toBe(true);
    expect(canAccessSensitiveDossier("user", "view")).toBe(false);
    expect(canAccessSensitiveDossier("user", "download")).toBe(false);
    expect(canAccessSensitiveDossier("user", "manage")).toBe(false);
  });

  it("keeps legal and transaction as protected archive categories", () => {
    expect(sensitiveArchiveCategories).toEqual(["legal", "transaction"]);
  });

  it("returns a clear denial message", () => {
    expect(permissionMessage("user", "download")).toContain("không được phép tải xuống");
    expect(permissionMessage("admin", "view")).toBe("Được phép");
  });
});
