import { OFFICIAL_2304_PROCEDURE_CODES, OFFICIAL_2304_SOURCE_URL, getVerified2304ProcedureName } from "./officialLandProcedureCodeIndex";

export interface OfficialLandProcedureRegistryEntry {
  code: string;
  /** Mã được nguồn ngoài dùng sau khi đã đối chiếu với mã catalog. */
  externalCodes?: string[];
  name: string;
  aliases: string[];
  groupName: string;
  sourceName: string;
  sourceType: "government" | "public_service";
  sourceUrl: string;
  baseUrl: string;
  checkedAt: string;
  authority: string;
  legalDocuments?: Array<{
    title: string;
    documentNumber: string;
    sourceUrl: string;
    issuingBody: string;
    status: "verified";
    documentRole?: "procedure_source" | "legal_basis";
    storageKey?: string;
    storageUrl?: string;
    checksum?: string;
  }>;
  referenceTemplates: Array<{
    name: string;
    documentType: string;
    format: "docx" | "pdf" | "doc" | "scan";
    sourceUrl: string;
    discoveryUrl?: string;
    provenance: "metadata_only";
    status: "needs_review";
  }>;
  verifiedTemplates?: Array<{
    name: string;
    documentType: string;
    format: "docx" | "pdf";
    sourceUrl: string;
    discoveryUrl?: string;
    checksum: string;
    provenance: "official_source";
    status: "verified_binary";
    notes: string;
  }>;
  workflowSteps?: Array<{ id: string; title: string; description: string; requiresInput?: boolean }>;
  requirements?: Array<{ id: string; label: string; source: string; status: "discovered" | "needs_review" }>;
  notes: string;
};

export type OfficialProcedureReference = OfficialLandProcedureRegistryEntry;

/**
 * Curated references checked against official public sources.
 * These entries are discovery metadata only: no entry is treated as an
 * Official binary until the file is downloaded, inspected, checksummed, and
 * added to the server allowlist.
 */
export const OFFICIAL_LAND_PROCEDURE_REGISTRY: OfficialProcedureReference[] = [
  {
    code: "2.000889",
    externalCodes: ["2912"],
    name: "Đăng ký biến động quyền sử dụng đất do chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn",
    aliases: ["chuyển nhượng quyền sử dụng đất", "sang tên", "đăng ký biến động", "tặng cho", "thừa kế", "cho thuê đất", "góp vốn bằng quyền sử dụng đất"],
    groupName: "Đăng ký biến động và chuyển quyền",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=2912&open_popup=1",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Văn phòng đăng ký đất đai hoặc cơ quan tiếp nhận theo địa phương",
    legalDocuments: [
      { title: "Luật Đất đai năm 2024", documentNumber: "31/2024/QH15", sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=211189&classid=1&orggroupid=1", issuingBody: "Quốc hội", status: "verified" },
      { title: "Nghị định quy định chi tiết thi hành một số điều của Luật Đất đai", documentNumber: "101/2024/NĐ-CP", sourceUrl: "https://vbpl.moj.gov.vn/botainguyen/Pages/vbpq-toanvan.aspx?ItemID=169188", issuingBody: "Chính phủ", status: "verified" },
    ],
    verifiedTemplates: [
      { name: "Đơn đăng ký biến động đất đai, tài sản gắn liền với đất — Mẫu 09/ĐK (mau so09.docx)", documentType: "land_change_registration", format: "docx", sourceUrl: "https://vptt-nhabe.tphcm.gov.vn/kiosk/Areas/Admin/Content/files/mau%20so09.docx", discoveryUrl: "https://vptt-nhabe.tphcm.gov.vn/kiosk/KioskThuTucHanhChinh/LoadPartialThongTinThuTucChiTiet?ThuTucID=1268", checksum: "c589d04cf6b0e6f6f82574d4e806194291077459c2a7d86d0b2f79e0e2057dc2", provenance: "official_source", status: "verified_binary", notes: "Binary DOCX tải trực tiếp từ trang thủ tục của Văn phòng đăng ký đất đai/điểm tiếp nhận Nhà Bè; đã kiểm tra loại file và SHA-256 ngày 2026-08-22." },
    ],
    referenceTemplates: [
      { name: "Đơn đăng ký biến động đất đai, tài sản gắn liền với đất — Mẫu 09/ĐK", documentType: "land_change_registration", format: "docx", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=2912&open_popup=1", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=2912&open_popup=1", provenance: "metadata_only", status: "needs_review" },
      { name: "Hợp đồng/văn bản chuyển quyền sử dụng đất — mẫu tham khảo Bộ Tư pháp (.doc)", documentType: "land_transfer_agreement", format: "doc", sourceUrl: "https://htpldn.moj.gov.vn/noidung/tintuc/Lists/Phobienphapluatkinh/Attachments/24/%5BM%E1%BA%ABu%20tham%20kh%E1%BA%A3o%5D%20H%C4%90%20chuy%E1%BB%83n%20nh%C6%B0%E1%BB%A3ng%20QSDD%20v%C3%A0%20TS%20tr%C3%AAn%20%C4%91%E1%BA%A5t.doc", discoveryUrl: "https://htpldn.moj.gov.vn/Pages/chi-tiet-tin.aspx?ItemID=24&l=Phobienphapluatkinh", provenance: "metadata_only", status: "needs_review" },
      { name: "Tờ khai thuế thu nhập cá nhân và lệ phí trước bạ", documentType: "tax_fee_declaration", format: "pdf", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=2912&open_popup=1", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=2912&open_popup=1", provenance: "metadata_only", status: "needs_review" },
    ],
    notes: "Thời hạn và thành phần hồ sơ phải rà soát theo địa phương, thời điểm và trường hợp cụ thể.",
  },
  {
    code: "1.012789",
    name: "Cung cấp thông tin, dữ liệu đất đai",
    aliases: ["cung cấp thông tin đất đai", "xin dữ liệu đất đai", "phiếu yêu cầu thông tin đất đai"],
    groupName: "Khai thác và cung cấp dữ liệu đất đai",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh; có thể là UBND cấp xã theo phân cấp",
    legalDocuments: [
      { title: "Trang thủ tục chính thức Cổng Dịch vụ công Quốc gia", documentNumber: "1.012789", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789", issuingBody: "Văn phòng Chính phủ", status: "verified" },
      { title: "Quy định thủ tục cung cấp thông tin, dữ liệu đất đai", documentNumber: "2304/QĐ-BNNMT", sourceUrl: "https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-cung-cap-thong-tin-du-lieu-dat-dai-119250805161025964.htm", issuingBody: "Bộ Nông nghiệp và Môi trường / Cổng TTĐT Chính phủ", status: "verified" },
    ],
    referenceTemplates: [
      { name: "Mẫu số 14/14a/14b/14c/14d/14đ — Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai", documentType: "land_information_request", format: "docx", sourceUrl: "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fd87368b77cb67c", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789", provenance: "metadata_only", status: "needs_review" },
      { name: "Mẫu số 14 — Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai (nguồn địa phương tham chiếu)", documentType: "land_information_request_local_reference", format: "docx", sourceUrl: "https://sxd.danang.gov.vn/documents/20121/43428/M%E1%BA%ABu%2014%20-%20Phi%E1%BA%BFu%20y%C3%AAu%20c%E1%BA%A7u%20cung%20c%E1%BA%A5p%20th%C3%B4ng%20tin,d%E1%BB%AF%20li%E1%BB%87u%20%C4%91%E1%BA%A5t%20%C4%91ai.docx", discoveryUrl: "https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-cung-cap-thong-tin-du-lieu-dat-dai-119250805161025964.htm", provenance: "metadata_only", status: "needs_review" },
      { name: "Bản Word chi tiết thủ tục 1.012789 — cần phân tích nội dung", documentType: "dvc_procedure_detail", format: "docx", sourceUrl: "https://vpcp.dichvucong.gov.vn/jsp/tthc/export/export_word_detail_tthc.jsp?maTTHC=1.012789&idTTHC=348167", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=348167", provenance: "metadata_only", status: "needs_review" },
    ],
    workflowSteps: [
      { id: "submit-request", title: "Nộp phiếu hoặc văn bản yêu cầu", description: "Xác định nội dung thông tin, dữ liệu đất đai cần cung cấp và kênh nộp hồ sơ.", requiresInput: true },
      { id: "receive-and-schedule", title: "Tiếp nhận và cấp giấy tiếp nhận/hẹn trả", description: "Cơ quan tiếp nhận kiểm tra hồ sơ và thông báo tiếp nhận hoặc hẹn trả.", requiresInput: false },
      { id: "process-and-notify-fee", title: "Xử lý yêu cầu và thông báo phí/giá", description: "Cơ quan cung cấp tìm kiếm, tập hợp hoặc phân tích dữ liệu và thông báo phí nếu có.", requiresInput: false },
      { id: "pay-fee", title: "Nộp phí nếu phát sinh", description: "Chỉ ghi nhận khoản phí sau khi có thông báo chính thức; không tự suy đoán số tiền.", requiresInput: true },
      { id: "receive-data", title: "Nhận thông tin hoặc dữ liệu đất đai", description: "Nhận kết quả theo hình thức trực tiếp hoặc trực tuyến và thời hạn được công bố.", requiresInput: false },
    ],
    requirements: [
      { id: "request-content", label: "Phiếu hoặc văn bản yêu cầu cung cấp thông tin, dữ liệu đất đai", source: "Hướng dẫn thủ tục DVC 1.012789", status: "discovered" },
      { id: "identity", label: "Thông tin người yêu cầu/giấy tờ nhân thân theo trường hợp", source: "Hướng dẫn thủ tục DVC 1.012789; cần lấy chi tiết từ trang/Word", status: "needs_review" },
    ],
    notes: "Thời hạn, phí/giá và thành phần hồ sơ chi tiết phải lấy từ trang chi tiết hoặc bản Word; không tự điền số phí cố định.",
  },
  {
    code: "1.013978",
    name: "Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận lần đầu",
    aliases: ["đăng ký đất đai lần đầu", "cấp sổ lần đầu", "cấp giấy chứng nhận lần đầu", "cấp sổ đỏ lần đầu"],
    groupName: "Đăng ký đất đai và cấp Giấy chứng nhận",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-18",
    authority: "Trung tâm Phục vụ hành chính công, UBND cấp xã và cơ quan đăng ký đất đai theo phân cấp",
    legalDocuments: [
      {
        title: "Nghị định 101/2024/NĐ-CP — bản PDF ký số từ Cổng Thông tin điện tử Chính phủ",
        documentNumber: "101/2024/NĐ-CP",
        sourceUrl: "https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf",
        issuingBody: "Chính phủ / Cổng Thông tin điện tử Chính phủ",
        status: "verified",
        documentRole: "legal_basis",
        storageKey: "legal-official/nghi-dinh-101-2024/dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e_b6a4c498.pdf",
        storageUrl: "/manus-storage/legal-official/nghi-dinh-101-2024/dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e_b6a4c498.pdf",
        checksum: "dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e",
      },
    ],
    referenceTemplates: [
      { name: "Đơn đăng ký đất đai, tài sản gắn liền với đất — Mẫu 15/ĐK", documentType: "first_land_registration", format: "docx", sourceUrl: "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978", provenance: "metadata_only", status: "needs_review" },
      { name: "Các biểu mẫu xác nhận và phiếu chuyển nghĩa vụ tài chính liên quan — Mẫu 16, 17, 19", documentType: "land_registration_supporting_forms", format: "pdf", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978", provenance: "metadata_only", status: "needs_review" },
    ],
    notes: "Nguồn tham chiếu mô tả quy trình đăng ký lần đầu; mẫu tệp gốc phải kiểm tra hash trước khi cho phép điền trực tiếp.",
  },
  {
    code: "1.012783",
    name: "Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất",
    aliases: ["cấp đổi sổ đỏ", "cấp đổi giấy chứng nhận", "sổ bị rách", "sổ bị nhòe"],
    groupName: "Đăng ký đất đai và cấp Giấy chứng nhận",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-18",
    authority: "Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh",
    referenceTemplates: [
      { name: "Đơn đăng ký biến động/cấp đổi Giấy chứng nhận theo trường hợp", documentType: "certificate_exchange", format: "docx", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783", provenance: "metadata_only", status: "needs_review" },
      { name: "Phiếu chuyển thông tin xác định nghĩa vụ tài chính — Mẫu 19", documentType: "financial_obligation_transfer", format: "pdf", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783", provenance: "metadata_only", status: "needs_review" },
    ],
    notes: "Thời hạn phụ thuộc trường hợp cấp đổi và địa bàn; cần rà soát yêu cầu địa phương.",
  },
  {
    code: "1.011441",
    name: "Đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, tài sản gắn liền với đất",
    aliases: ["đăng ký thế chấp quyền sử dụng đất", "đăng ký biện pháp bảo đảm đất đai", "đăng ký giao dịch bảo đảm bằng quyền sử dụng đất"],
    groupName: "Đăng ký biện pháp bảo đảm",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Văn phòng đăng ký đất đai hoặc cơ quan tiếp nhận theo phân cấp",
    legalDocuments: [
      { title: "Trang thủ tục chính thức Cổng Dịch vụ công Quốc gia", documentNumber: "1.011441", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441", issuingBody: "Văn phòng Chính phủ", status: "verified", documentRole: "procedure_source" },
    ],
    referenceTemplates: [
      { name: "Phiếu yêu cầu đăng ký biện pháp bảo đảm", documentType: "security_interest_registration_request", format: "docx", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441", provenance: "metadata_only", status: "needs_review" },
    ],
    notes: "Chưa gắn Official binary khi chưa tải được tệp thực tế và đối chiếu checksum từ nguồn được phép.",
  },
  {
    code: "1.011443",
    name: "Xóa đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, tài sản gắn liền với đất",
    aliases: ["xóa thế chấp quyền sử dụng đất", "xóa đăng ký biện pháp bảo đảm", "giải chấp quyền sử dụng đất"],
    groupName: "Đăng ký biện pháp bảo đảm",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011443",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Văn phòng đăng ký đất đai hoặc cơ quan tiếp nhận theo phân cấp",
    legalDocuments: [
      { title: "Trang thủ tục chính thức Cổng Dịch vụ công Quốc gia", documentNumber: "1.011443", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011443", issuingBody: "Văn phòng Chính phủ", status: "verified", documentRole: "procedure_source" },
    ],
    referenceTemplates: [
      { name: "Phiếu yêu cầu xóa đăng ký biện pháp bảo đảm", documentType: "security_interest_cancellation_request", format: "docx", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011443", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011443", provenance: "metadata_only", status: "needs_review" },
    ],
    notes: "Chưa gắn Official binary khi chưa tải được tệp thực tế và đối chiếu checksum từ nguồn được phép.",
  },
  {
    code: "2.000410",
    name: "Đăng ký chuyển quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất",
    aliases: ["chuyển quyền sử dụng đất", "chuyển quyền sở hữu tài sản", "đăng ký chuyển quyền"],
    groupName: "Đăng ký biến động và chuyển quyền",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Văn phòng đăng ký đất đai hoặc cơ quan tiếp nhận theo địa phương",
    referenceTemplates: [
      { name: "Đơn đăng ký biến động đất đai — Mẫu số 09/ĐK", documentType: "land_change_registration", format: "pdf", sourceUrl: "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe998b4cf4ed90a", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410", provenance: "metadata_only", status: "needs_review" },
      { name: "Đơn đề nghị cấp lại, cấp đổi Giấy chứng nhận — Mẫu số 10/ĐK", documentType: "certificate_reissue_exchange", format: "pdf", sourceUrl: "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe2f78f7bc72401", discoveryUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410", provenance: "metadata_only", status: "needs_review" },
    ],
    notes: "Mã thủ tục và URL lấy từ trang DVC Quốc gia; binary Mẫu 09/ĐK và Mẫu 10/ĐK phải tải, kiểm MIME/nội dung và tính SHA-256 trước khi gắn Official.",
  },
  {
    code: "1.013949",
    name: "Giao đất, cho thuê đất, chuyển mục đích sử dụng đất đối với trường hợp thuộc thẩm quyền",
    aliases: ["giao đất", "cho thuê đất", "chuyển mục đích sử dụng đất"],
    groupName: "Giao đất, cho thuê đất và chuyển mục đích",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013949",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Ủy ban nhân dân/cơ quan chuyên môn theo thẩm quyền",
    referenceTemplates: [],
    notes: "Mã thủ tục và URL lấy từ trang DVC Quốc gia; không suy đoán mẫu khi chưa quét phần Thành phần hồ sơ.",
  },
  {
    code: "2.002317",
    name: "Cung cấp thông tin, dữ liệu đất đai",
    aliases: ["thông tin đất đai", "dữ liệu đất đai", "phiếu yêu cầu thông tin đất đai"],
    groupName: "Khai thác và cung cấp dữ liệu đất đai",
    sourceName: "Hệ thống dịch vụ công trực tuyến Bộ Nông nghiệp và Môi trường",
    sourceType: "public_service",
    sourceUrl: "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67",
    baseUrl: "https://dichvucong.monre.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Cơ quan quản lý đất đai theo nguồn công bố",
    referenceTemplates: [],
    verifiedTemplates: [
      { name: "Phiếu yêu cầu cung cấp dữ liệu đất đai — Mẫu số 01/PYC", documentType: "land_information_request", format: "docx", sourceUrl: "https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/0ff8d095-1ea7-4567-a475-781d46b3c9bf", discoveryUrl: "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67", checksum: "3e68adcddb6e249af61fa2a3bdc883b73ad5800fd5af6c89e3b31b4e03fccbb2", provenance: "official_source", status: "verified_binary", notes: "DOCX tải qua nút Tải về công khai trên trang DVC Bộ; nội dung xác nhận Mẫu số 01/PYC theo Thông tư 34/2014/TT-BTNMT. Cần đối chiếu hiệu lực biểu mẫu tại thời điểm nộp hồ sơ." },
      { name: "Hợp đồng cung cấp dữ liệu đất đai — Mẫu số 02", documentType: "land_information_contract", format: "docx", sourceUrl: "https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/13f2af36-a65a-426a-99dd-e098de8d091e", discoveryUrl: "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67", checksum: "d5853a5ee35f4d115e3011007f23364670fed45d9ed95549d5982f5309706dce", provenance: "official_source", status: "verified_binary", notes: "DOCX tải qua nút Tải về công khai trên trang DVC Bộ; nội dung xác nhận Hợp đồng cung cấp dữ liệu đất đai — Mẫu số 02 theo Thông tư 34/2014/TT-BTNMT." },
      { name: "Phiếu yêu cầu cung cấp dữ liệu đất đai — bản DOCX công bố", documentType: "land_information_request", format: "docx", sourceUrl: "https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/0b362fa7-818b-48ae-ba54-9ce7fd2332b4", discoveryUrl: "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67", checksum: "3e68adcddb6e249af61fa2a3bdc883b73ad5800fd5af6c89e3b31b4e03fccbb2", provenance: "official_source", status: "verified_binary", notes: "Binary trùng SHA-256 với Mẫu số 01/PYC; giữ riêng candidate vì Cổng Bộ công bố qua nhãn tệp khác." },
    ],
    notes: "Mã thủ tục và URL lấy từ danh mục lĩnh vực Đất đai của hệ thống DVC Bộ Nông nghiệp và Môi trường; các candidate verified chỉ được dùng sau khi scheduled sync tải lại và đối chiếu checksum.",
  },
  {
    code: "1.004278",
    name: "Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng",
    aliases: ["tranh chấp đất đai", "giải quyết tranh chấp đất"],
    groupName: "Giải quyết tranh chấp và khiếu nại đất đai",
    sourceName: "Hệ thống dịch vụ công trực tuyến Bộ Nông nghiệp và Môi trường",
    sourceType: "public_service",
    sourceUrl: "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=69",
    baseUrl: "https://dichvucong.monre.gov.vn",
    checkedAt: "2026-08-20",
    authority: "Bộ Nông nghiệp và Môi trường theo thẩm quyền",
    referenceTemplates: [],
    notes: "Mã thủ tục và URL lấy từ danh mục lĩnh vực Đất đai của hệ thống DVC Bộ Nông nghiệp và Môi trường.",
  },
  {
    code: "1.012784",
    name: "Tách thửa hoặc hợp thửa đất",
    aliases: ["tách thửa", "hợp thửa", "tách hợp thửa", "chia thửa", "gộp thửa"],
    groupName: "Thay đổi hiện trạng thửa đất",
    sourceName: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceType: "public_service",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784",
    baseUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-18",
    authority: "Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh",
    legalDocuments: [
      { title: "Nghị định 101/2024/NĐ-CP — đăng ký đất đai, cấp Giấy chứng nhận và hồ sơ địa chính", documentNumber: "101/2024/NĐ-CP", sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=210791", issuingBody: "Chính phủ / Cổng Thông tin điện tử Chính phủ", status: "verified", documentRole: "legal_basis" },
      { title: "Nghị định 151/2025/NĐ-CP — phân định thẩm quyền chính quyền địa phương 02 cấp trong lĩnh vực đất đai", documentNumber: "151/2025/NĐ-CP", sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=213927", issuingBody: "Chính phủ / Cổng Thông tin điện tử Chính phủ", status: "verified", documentRole: "legal_basis" },
      { title: "Quyết định 61/2024/QĐ-UBND — điều kiện tách thửa tại Hà Nội", documentNumber: "61/2024/QĐ-UBND", sourceUrl: "https://sonnmt.hanoi.gov.vn/index.php/tin-t-c/d-t-dai/20689-t-7-10-2024-d-t-nh-hon-50m2-ha-n-i-khong-du-c-tach-th-a", issuingBody: "UBND thành phố Hà Nội / Sở Nông nghiệp và Môi trường Hà Nội", status: "verified", documentRole: "legal_basis" },
      { title: "Quyết định 100/2024/QĐ-UBND — điều kiện tách, hợp thửa tại Thành phố Hồ Chí Minh", documentNumber: "100/2024/QĐ-UBND", sourceUrl: "https://vpub.hochiminhcity.gov.vn/portal/pages/2024-11-1/Ban-hanh-Quy-dinh-ve-dieu-kien-tach-hop-thua-dat-vgqjvhnjhexyf.aspx", issuingBody: "UBND Thành phố Hồ Chí Minh", status: "verified", documentRole: "legal_basis" },
      { title: "Quy định diện tích tối thiểu và điều kiện tách/hợp thửa tại Đà Nẵng", documentNumber: "LOCAL-DANANG-PARCEL-SPLIT-MERGE", sourceUrl: "https://danang.gov.vn/w/dien-tich-toi-thieu-va-dieu-kien-khi-tach-thua-dat-hop-thua-dat-doi-voi-cac-loai-dat-tren-dia-ban-thanh-pho-i", issuingBody: "UBND thành phố Đà Nẵng", status: "verified", documentRole: "legal_basis" },
    ],
    requirements: [
      { id: "access-road", label: "Thửa đất sau tách/hợp phải bảo đảm lối đi và kết nối với đường giao thông công cộng", source: "Điều 220 Luật Đất đai 2024; cần đối chiếu hồ sơ và quy hoạch địa phương", status: "needs_review" },
      { id: "local-minimum-area", label: "Diện tích tối thiểu, kích thước và điều kiện cụ thể theo quyết định của UBND cấp tỉnh", source: "Quy định địa phương nơi có đất; không suy đoán một mức chung toàn quốc", status: "needs_review" },
      { id: "land-use-compatibility", label: "Các thửa hợp phải được kiểm tra về giấy chứng nhận, mục đích sử dụng, tranh chấp và quy hoạch", source: "Cổng DVC Quốc gia và cơ quan đăng ký đất đai địa phương", status: "needs_review" },
    ],
    referenceTemplates: [
      { name: "Đơn đề nghị tách thửa hoặc hợp thửa — Mẫu 01/ĐK", documentType: "parcel_split_merge_request", format: "docx", sourceUrl: "https://xaydungchinhsach.chinhphu.vn/mau-don-de-nghi-tach-thua-dat-hop-thua-dat-119240801152947547.htm", discoveryUrl: "https://xaydungchinhsach.chinhphu.vn/mau-don-de-nghi-tach-thua-dat-hop-thua-dat-119240801152947547.htm", provenance: "metadata_only", status: "needs_review" },
      { name: "Bản vẽ tách thửa hoặc hợp thửa — thành phần cần đối chiếu theo địa phương", documentType: "parcel_split_merge_drawing", format: "pdf", sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784", provenance: "metadata_only", status: "needs_review" },
    ],
    verifiedTemplates: [
      { name: "Đơn đề nghị tách thửa đất, hợp thửa đất — Mẫu số 01/ĐK", documentType: "parcel_split_merge_request", format: "docx", sourceUrl: "https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/don-17225006379202035387597.docx", discoveryUrl: "https://xaydungchinhsach.chinhphu.vn/mau-don-de-nghi-tach-thua-dat-hop-thua-dat-119240801152947547.htm", checksum: "7c1b2afc87f72b3cae065e1a6bbc1bb4c7089ae366a12e66c9380132162c42ff", provenance: "official_source", status: "verified_binary", notes: "DOCX tải từ CDN thuộc hệ thống Cổng TTĐT Chính phủ; nội dung xác nhận Mẫu số 01/ĐK và đúng tên thủ tục tách/hợp thửa. Không thay thế bản vẽ hoặc giấy tờ đất thực tế." },
    ],
    notes: "Điều kiện diện tích tối thiểu và quy định cụ thể phải đối chiếu quyết định của UBND cấp tỉnh.",
  },
  {
    code: "1.012750",
    name: "Cung cấp thông tin, dữ liệu đất đai",
    aliases: ["cung cấp dữ liệu đất đai cấp Bộ", "phiếu yêu cầu cung cấp thông tin đất đai", "mẫu 14 dữ liệu đất đai"],
    groupName: "Khai thác và cung cấp dữ liệu đất đai",
    sourceName: "Bộ Nông nghiệp và Môi trường / Cục Quản lý đất đai",
    sourceType: "government",
    sourceUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf",
    baseUrl: "https://qldd.mae.gov.vn",
    checkedAt: "2026-08-21",
    authority: "Trung tâm Dữ liệu và Thông tin đất đai thuộc Cục Quản lý đất đai",
    legalDocuments: [
      { title: "Quy trình nội bộ giải quyết TTHC lĩnh vực đất đai", documentNumber: "4052/QĐ-BNNMT", sourceUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf", issuingBody: "Bộ Nông nghiệp và Môi trường", status: "verified", documentRole: "procedure_source" },
    ],
    referenceTemplates: [
      { name: "Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai — Mẫu 14, 14a, 14b, 14c, 14d, 14đ", documentType: "land_information_request", format: "docx", sourceUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf", discoveryUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf", provenance: "metadata_only", status: "needs_review" },
    ],
    workflowSteps: [
      { id: "request", title: "Nộp phiếu yêu cầu", description: "Tiếp nhận phiếu yêu cầu hoặc văn bản yêu cầu cung cấp dữ liệu đất đai." },
      { id: "review", title: "Kiểm tra và báo phí", description: "Kiểm tra dữ liệu, xác định khả năng cung cấp và thông báo phí nếu có." },
      { id: "deliver", title: "Cung cấp kết quả", description: "Đóng gói dữ liệu và trả kết quả theo hình thức đã đăng ký." },
    ],
    notes: "Mã và quy trình được đối chiếu từ tài liệu Bộ. Chưa gắn Official cho biểu mẫu vì chưa có binary được tải, kiểm tra và đưa vào allowlist SHA-256.",
  },
  {
    code: "1.012751",
    name: "Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Nông nghiệp và Môi trường",
    aliases: ["giải quyết tranh chấp đất đai cấp Bộ", "tranh chấp đất đai thuộc thẩm quyền Bộ trưởng"],
    groupName: "Giải quyết tranh chấp và khiếu nại đất đai",
    sourceName: "Bộ Nông nghiệp và Môi trường / Cục Quản lý đất đai",
    sourceType: "government",
    sourceUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf",
    baseUrl: "https://qldd.mae.gov.vn",
    checkedAt: "2026-08-21",
    authority: "Bộ trưởng Bộ Nông nghiệp và Môi trường; Cục Quản lý đất đai thực hiện theo phân công",
    legalDocuments: [
      { title: "Quy trình nội bộ giải quyết TTHC lĩnh vực đất đai", documentNumber: "4052/QĐ-BNNMT", sourceUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf", issuingBody: "Bộ Nông nghiệp và Môi trường", status: "verified", documentRole: "procedure_source" },
    ],
    referenceTemplates: [
      { name: "Hồ sơ, văn bản và tài liệu giải quyết tranh chấp đất đai theo thủ tục chính thức", documentType: "land_dispute_resolution", format: "pdf", sourceUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf", discoveryUrl: "https://qldd.mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/76/4052-Q%C4%90-BNNMT-PL.pdf", provenance: "metadata_only", status: "needs_review" },
    ],
    workflowSteps: [
      { id: "submit", title: "Tiếp nhận hồ sơ tranh chấp", description: "Tiếp nhận đơn và tài liệu chứng minh quyền, lợi ích liên quan." },
      { id: "verify", title: "Xác minh và xử lý", description: "Kiểm tra thẩm quyền, xác minh nội dung và thu thập tài liệu theo quy trình." },
      { id: "decision", title: "Ban hành kết quả", description: "Cơ quan có thẩm quyền ban hành và trả kết quả theo thủ tục." },
    ],
    notes: "Mã được đối chiếu từ danh mục quy trình nội bộ của Bộ. Đây là metadata/Pending; không suy đoán biểu mẫu Official khi chưa có binary và checksum hợp lệ.",
  },
];
function getCatalogRegistryEntries(province?: string) {
  const byCode = new Map<string, ReturnType<typeof getOfficialLandProcedure>>();
  for (const item of OFFICIAL_LAND_PROCEDURE_REGISTRY) {
    const resolved = getOfficialLandProcedure(item.code, province);
    if (resolved) byCode.set(resolved.code, resolved);
  }
  for (const code of OFFICIAL_2304_PROCEDURE_CODES) {
    const resolved = getOfficialLandProcedure(code, province);
    if (resolved) byCode.set(resolved.code, resolved);
  }
  return Array.from(byCode.values()).filter((item): item is NonNullable<typeof item> => Boolean(item));
}
export function listOfficialLandProcedures(province?: string) {
  return getCatalogRegistryEntries(province);
}
export function searchOfficialLandProcedures(query = "", province?: string) {
  const normalized = query.trim().toLocaleLowerCase("vi");
  return getCatalogRegistryEntries(province)
    .filter(item => !normalized || [item.code, item.name, ...item.aliases].some(value => value.toLocaleLowerCase("vi").includes(normalized)));
}

const VERIFIED_2304_NAME_OVERRIDES: Record<string, { name: string; sourceUrl: string; aliases: string[] }> = {
  "1.012818": {
    name: "Thu hồi Giấy chứng nhận đã cấp lần đầu không đúng quy định của pháp luật đất đai do người sử dụng đất, chủ sở hữu tài sản gắn liền với đất phát hiện và cấp lại Giấy chứng nhận sau khi thu hồi",
    sourceUrl: "https://thutuc.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=357513",
    aliases: ["thu hồi giấy chứng nhận đã cấp lần đầu", "cấp lại giấy chứng nhận sau khi thu hồi", "1.012818.H26"],
  },
  "1.012819": {
    name: "Cấp lại Giấy chứng nhận do bị mất",
    sourceUrl: "https://dichvucong1.angiang.gov.vn/dichvucong/tra-cuu/chi-tiet-thu-tuc?ma-thu-tuc=40635",
    aliases: ["cấp lại sổ đỏ do bị mất", "mất giấy chứng nhận", "1.012819.H01"],
  },
  "1.012820": {
    name: "Bán hoặc góp vốn bằng tài sản gắn liền với đất thuê của Nhà nước theo hình thức thuê đất trả tiền hàng năm",
    sourceUrl: "https://dichvucong1.angiang.gov.vn/dich-vu-cong/tra-cuu/chi-tiet-thu-tuc?ma-thu-tuc=41099",
    aliases: ["bán tài sản gắn liền với đất thuê", "góp vốn bằng tài sản gắn liền với đất thuê", "thuê đất trả tiền hàng năm", "1.012820.H01"],
  },
  "1.012821": {
    name: "Thẩm định, phê duyệt phương án sử dụng đất",
    sourceUrl: "https://vpubnd.daklak.gov.vn/CMS/Content/VanBan/2025/THANG%207/1586_QD-UBND%20pl.pdf",
    aliases: ["thẩm định phương án sử dụng đất", "phê duyệt phương án sử dụng đất"],
  },
};

export function getOfficialLandProcedure(code: string, province?: string) {
  // Mã thủ tục là khóa toàn quốc; province chỉ bổ sung ngữ cảnh hiển thị,
  // tuyệt đối không được làm mất một entry hợp lệ khỏi registry.
  const normalizedCode = code.trim().replace(/\s+/g, "");
  const item = OFFICIAL_LAND_PROCEDURE_REGISTRY.find(entry => entry.code === normalizedCode || entry.externalCodes?.includes(normalizedCode));
  if (item) return { ...item, province: province?.trim() || null, verifiedBinaryAvailable: Boolean(item.verifiedTemplates?.length) };

  // Các mã trong phụ lục 2304 đã là mã chính thức nhưng chưa có metadata chi tiết
  // trong registry curated. Gắn chúng vào cùng pipeline bằng URL chi tiết DVC theo mẫu đã có trong registry;
  // tên/thành phần và binary vẫn phải được discovery đối soát từ nguồn thật; không tạo Official giả.
  if ((OFFICIAL_2304_PROCEDURE_CODES as readonly string[]).includes(normalizedCode)) {
    const override = VERIFIED_2304_NAME_OVERRIDES[normalizedCode];
    const sourceUrl = override?.sourceUrl || `https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=${encodeURIComponent(normalizedCode)}`;
    return {
      code: normalizedCode,
      name: getVerified2304ProcedureName(normalizedCode) || override?.name || `Mã TTHC ${normalizedCode} — cần đối soát tên thủ tục`,
      aliases: [normalizedCode, ...(override?.aliases || []), ...(getVerified2304ProcedureName(normalizedCode) ? [getVerified2304ProcedureName(normalizedCode)!] : [])],
      groupName: "Danh mục đất đai theo Quyết định 2304/QĐ-BNNMT",
      sourceName: "Cổng Dịch vụ công Quốc gia / Phụ lục Quyết định 2304/QĐ-BNNMT",
      sourceType: "public_service",
      sourceUrl,
      baseUrl: "https://vpcp.dichvucong.gov.vn",
      checkedAt: "2026-08-22",
      authority: "Cơ quan tiếp nhận theo thủ tục và địa phương",
      legalDocuments: [{ title: "Phụ lục danh mục thủ tục đất đai", documentNumber: "2304/QĐ-BNNMT", sourceUrl: OFFICIAL_2304_SOURCE_URL, issuingBody: "Bộ Nông nghiệp và Môi trường", status: "verified", documentRole: "legal_basis" }],
      referenceTemplates: [],
      verifiedTemplates: [],
      workflowSteps: [],
      requirements: [],
      notes: override || getVerified2304ProcedureName(normalizedCode)
        ? "Tên đã đối soát từ cổng hành chính công nhà nước; thành phần hồ sơ, biểu mẫu và binary SHA-256 vẫn phải được kiểm tra riêng trước khi phân loại Official."
        : "Mã đã xác nhận trong phụ lục 2304/QĐ-BNNMT; tên, thành phần và binary vẫn cần đối soát từ nguồn chính thức trước khi phân loại Official.",
      province: province?.trim() || null,
      verifiedBinaryAvailable: false,
    };
  }
  return undefined;
}

export const officialRegistryCheckedAt = "2026-08-18";
