ALTER TABLE `consultation_requests` ADD `aiArea` varchar(255);--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `aiScore` int;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `routingStage` enum('unassigned','area_queue','backup_queue','admin_queue') DEFAULT 'unassigned' NOT NULL;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `assignedTo` int;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `conversationHistory` text;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD CONSTRAINT `consultation_requests_assignedTo_users_id_fk` FOREIGN KEY (`assignedTo`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;