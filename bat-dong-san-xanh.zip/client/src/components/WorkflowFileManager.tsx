import { useState } from "react";
import { Download, Eye, FileUp, Loader2, ScanLine, Trash2, Video } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type WorkflowDocument = {
  id: number;
  fileName: string;
  mimeType: string;
  url: string;
  stepNumber: number;
};

type OcrField = { key: string; label: string };
type OcrResult = { fields: Record<string, unknown>; summary: string; confidence: number; warnings: string[] };

export const MAX_WORKFLOW_FILE_SIZE = 10 * 1024 * 1024;
export const WORKFLOW_FILE_ACCEPT = "image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.txt";
export const WORKFLOW_OCR_ACCEPT = "image/jpeg,image/png,image/webp";

export function isWorkflowMedia(mimeType: string) {
  return mimeType.startsWith("image/") || mimeType.startsWith("video/");
}

export function isWorkflowVideo(mimeType: string) {
  return mimeType.startsWith("video/");
}

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || "").split(",")[1] || "");
    reader.onerror = () => reject(new Error(`Không thể đọc ${file.name}`));
    reader.readAsDataURL(file);
  });
}

export default function WorkflowFileManager({
  dossierId,
  stepNumber,
  documents,
  onRefresh,
  compact = false,
  ocrFields = [],
  onOcrApplied,
}: {
  dossierId: number;
  stepNumber: number;
  documents: WorkflowDocument[];
  onRefresh?: () => void;
  compact?: boolean;
  ocrFields?: OcrField[];
  onOcrApplied?: (result: OcrResult) => void;
}) {
  const [preview, setPreview] = useState<WorkflowDocument | null>(null);
  const [ocrResult, setOcrResult] = useState<OcrResult | null>(null);
  const upload = trpc.brokerage.dossiers.uploadDocument.useMutation({
    onSuccess: () => { toast.success("Đã tải tệp lên bước nghiệp vụ"); onRefresh?.(); },
    onError: error => toast.error(error.message),
  });
  const analyze = trpc.brokerage.dossiers.analyzeStepImage.useMutation({
    onSuccess: result => { setOcrResult(result); toast.success("AI đã đọc biên bản. Vui lòng kiểm tra trước khi áp dụng."); onRefresh?.(); },
    onError: error => toast.error(error.message),
  });
  const remove = trpc.brokerage.dossiers.deleteDocument.useMutation({
    onSuccess: () => { toast.success("Đã xóa tệp"); onRefresh?.(); },
    onError: error => toast.error(error.message),
  });

  const handleFiles = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    event.target.value = "";
    for (const file of files) {
      if (file.size > MAX_WORKFLOW_FILE_SIZE) { toast.error(`${file.name} vượt quá 10MB.`); continue; }
      if (!file.type.startsWith("image/") && !file.type.startsWith("video/") && !/^(application|text)\//.test(file.type)) {
        toast.error(`${file.name} không thuộc định dạng được hỗ trợ.`); continue;
      }
      try {
        const data = await fileToBase64(file);
        await upload.mutateAsync({ dossierId, stepNumber, fileName: file.name, mimeType: file.type || "application/octet-stream", data });
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Không thể tải tệp lên.");
      }
    }
  };

  const handleOcr = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file || !ocrFields.length) return;
    if (file.size > MAX_WORKFLOW_FILE_SIZE) { toast.error("Ảnh biên bản không được vượt quá 10MB."); return; }
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) { toast.error("OCR hiện hỗ trợ ảnh JPG, PNG hoặc WebP."); return; }
    try {
      const data = await fileToBase64(file);
      await analyze.mutateAsync({ dossierId, stepNumber, fileName: file.name, mimeType: file.type as "image/jpeg" | "image/png" | "image/webp", data, fields: ocrFields });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không thể phân tích biên bản.");
    }
  };

  return <div className={compact ? "space-y-3" : "mt-6 border-t border-[#D9DED7] pt-5"}>
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div><h4 className="font-semibold text-[#18352D]">Ảnh & video của bước {stepNumber}</h4><p className="mt-1 text-xs text-[#60766D]">Tệp gốc được lưu trong Hồ sơ điện tử. Bạn có thể dùng AI đọc ảnh biên bản rồi kiểm tra trước khi điền vào biểu mẫu.</p></div>
      <div className="flex flex-wrap gap-2">
        <label className="inline-flex min-h-10 cursor-pointer items-center gap-2 rounded-lg border border-[#1F5A4A] bg-white px-3 py-2 text-xs font-bold text-[#1F5A4A] hover:bg-[#EFF5F0]"><FileUp size={15} />Tải ảnh/video<input type="file" className="sr-only" multiple accept={WORKFLOW_FILE_ACCEPT} capture="environment" onChange={handleFiles} disabled={upload.isPending || analyze.isPending} /></label>
        {ocrFields.length > 0 && <label className="inline-flex min-h-10 cursor-pointer items-center gap-2 rounded-lg bg-[#D45C50] px-3 py-2 text-xs font-bold text-white hover:bg-[#B9483E]"><ScanLine size={15} />Chụp biên bản & AI điền<input type="file" className="sr-only" accept={WORKFLOW_OCR_ACCEPT} capture="environment" onChange={handleOcr} disabled={upload.isPending || analyze.isPending} /></label>}
        {(upload.isPending || analyze.isPending) && <span className="inline-flex items-center gap-2 text-xs font-semibold text-[#60766D]"><Loader2 size={15} className="animate-spin" />{analyze.isPending ? "AI đang đọc..." : "Đang tải..."}</span>}
      </div>
    </div>
    {documents.length ? <div className="grid gap-2 sm:grid-cols-2">{documents.map(doc => <div key={doc.id} className="flex min-w-0 items-center gap-2 rounded-xl border border-[#E4EAE5] bg-white p-2.5">
      <button type="button" onClick={() => isWorkflowMedia(doc.mimeType) ? setPreview(doc) : window.open(doc.url, "_blank", "noopener,noreferrer")} className="flex min-w-0 flex-1 items-center gap-2 text-left" title="Xem tệp"><span className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-[#EFF5F0] text-[#1F5A4A]">{doc.mimeType.startsWith("image/") ? <img src={doc.url} alt="" className="h-full w-full object-cover" /> : isWorkflowVideo(doc.mimeType) ? <Video size={18} /> : <Eye size={18} />}</span><span className="min-w-0"><span className="block truncate text-xs font-semibold text-[#315B4B]">{doc.fileName}</span><span className="mt-0.5 block text-[10px] text-[#70847A]">{isWorkflowVideo(doc.mimeType) ? "Video" : doc.mimeType.startsWith("image/") ? "Hình ảnh" : "Tài liệu"}</span></span></button>
      <div className="flex shrink-0 items-center gap-1"><a href={doc.url} download={doc.fileName} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-[#D9E2DA] text-[#1F5A4A] hover:bg-[#EFF5F0]" aria-label={`Tải xuống ${doc.fileName}`}><Download size={14} /></a><button type="button" onClick={() => { if (window.confirm(`Xóa tệp ${doc.fileName}?`)) remove.mutate({ id: doc.id }); }} disabled={remove.isPending} className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-red-200 text-red-700 hover:bg-red-50 disabled:opacity-50" aria-label={`Xóa ${doc.fileName}`}><Trash2 size={14} /></button></div>
    </div>)}</div> : <p className="rounded-xl border border-dashed border-[#C8D3C9] bg-white/60 p-4 text-xs text-[#70847A]">Chưa có ảnh, video hoặc tài liệu ở bước này.</p>}
    {ocrResult && <div className="mt-4 rounded-2xl border border-[#E6C478] bg-[#FFF9E9] p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-[.14em] text-[#8A6415]">Bản nháp OCR</p><p className="mt-1 text-sm font-semibold text-[#18352D]">Độ tin cậy: {ocrResult.confidence}%</p></div><button type="button" onClick={() => setOcrResult(null)} className="text-xs font-bold text-[#60766D] underline">Bỏ bản nháp</button></div><p className="mt-2 text-xs leading-5 text-[#60766D]">{ocrResult.summary || "AI chưa tạo tóm tắt."}</p><div className="mt-3 grid gap-2 sm:grid-cols-2">{ocrFields.map(field => <div key={field.key} className="rounded-lg bg-white/80 p-2"><p className="text-[10px] font-bold uppercase text-[#70847A]">{field.label}</p><p className="mt-1 text-sm text-[#18352D]">{String(ocrResult.fields[field.key] || "Chưa nhận diện")}</p></div>)}</div>{ocrResult.warnings.length > 0 && <p className="mt-3 text-xs text-[#8A6415]">Lưu ý: {ocrResult.warnings.join("; ")}</p>}<button type="button" onClick={() => { onOcrApplied?.(ocrResult); setOcrResult(null); }} className="mt-4 inline-flex min-h-10 items-center justify-center rounded-lg bg-[#1F5A4A] px-4 py-2 text-xs font-bold text-white">Kiểm tra và áp dụng vào bước</button></div>}
    {preview && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#18352D]/70 p-4" role="dialog" aria-modal="true" aria-label={`Xem trước ${preview.fileName}`} onClick={() => setPreview(null)}><div className="max-h-[90vh] w-full max-w-3xl rounded-2xl bg-white p-3 shadow-2xl sm:p-5" onClick={event => event.stopPropagation()}><div className="flex items-center justify-between gap-3"><h5 className="min-w-0 truncate font-bold text-[#18352D]">{preview.fileName}</h5><button type="button" onClick={() => setPreview(null)} className="rounded-lg px-3 py-1 text-sm font-bold text-[#60766D] hover:bg-[#EFF5F0]">Đóng</button></div>{preview.mimeType.startsWith("image/") ? <img src={preview.url} alt={preview.fileName} className="mt-4 max-h-[72vh] w-full rounded-xl object-contain" /> : <video src={preview.url} controls className="mt-4 max-h-[72vh] w-full rounded-xl" />}</div></div>}
  </div>;
}
