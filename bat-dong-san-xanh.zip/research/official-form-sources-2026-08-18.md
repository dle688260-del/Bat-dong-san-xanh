# Nguồn tra cứu biểu mẫu pháp lý

Ngày tra cứu: 2026-08-18.

- Cổng Dịch vụ công Quốc gia, kết quả thủ tục có nêu “Đơn đăng ký biến động đất đai, tài sản gắn liền với đất theo Mẫu số 09/ĐK” và có liên kết “Mẫu 09.docx”: https://dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc
- Cổng Thông tin điện tử Chính phủ, kết quả tra cứu liên quan bảng giá tính lệ phí trước bạ đối với nhà: https://vanban.chinhphu.vn/he-thong-van-ban?classid
- Cổng VPCP, nội dung phản ánh có nhắc Mẫu 09/ĐK và Tờ khai lệ phí trước bạ Mẫu 01/LPTB, nhưng đây không phải bản binary mẫu dùng để tự động điền: https://vpcp.dichvucong.gov.vn/p/phananhkiennghi/pakn-detail.html?id

Ghi chú kiểm soát: kết quả tìm kiếm/snippet chỉ là metadata tham chiếu. Chỉ đưa tệp vào allowlist tự động điền sau khi tải từ nguồn chính thức, kiểm tra nội dung, checksum, phiên bản, phạm vi địa phương/cơ quan và lưu provenance đầy đủ. Không gắn nhãn Official hoặc tự động tải mẫu chỉ dựa trên snippet.
