import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("legal scan queue contract", () => {
  const schema = readFileSync(resolve(process.cwd(), "drizzle/schema.ts"), "utf8");
  const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
  const syncSource = readFileSync(resolve(process.cwd(), "server/scheduledLegalSync.ts"), "utf8");

  it("persists per-procedure status and retry metadata", () => {
    expect(schema).toContain('mysqlTable("legal_scan_queue"');
    expect(schema).toContain("lastHttpStatus");
    expect(schema).toContain("nextAttemptAt");
    expect(schema).toContain("procedureProvinceUnique");
    expect(dbSource).toContain("enqueueLegalScanItems");
    expect(dbSource).toContain("updateLegalScanItem");
  });

  it("seeds the queue and records 503 retry state", () => {
    expect(syncSource).toContain("await enqueueLegalScanItems(allProcedures.map(item => item.code)");
    expect(syncSource).toContain('status: "running"');
    expect(syncSource).toContain("lastHttpStatus");
    expect(syncSource).toContain("retryAt(6)");
    expect(syncSource).toContain("/503/.test");
  });

  it("keeps Official materialization behind the verified registry", () => {
    expect(syncSource).toContain("getOfficialLandProcedure(procedure.code)");
    expect(syncSource).toContain("downloadOfficialTemplateCandidate");
    expect(syncSource).toContain("Checksum binary không khớp allowlist Official.");
    expect(syncSource).toContain("downloadPublicReferenceCandidate");
    expect(syncSource).not.toContain("fallbackOfficialTemplate");
  });
});
