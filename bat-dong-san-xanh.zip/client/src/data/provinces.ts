export const NATIONAL_PROVINCES = [
  "An Giang", "Bắc Ninh", "Cà Mau", "Cao Bằng", "Đắk Lắk", "Điện Biên", "Đồng Nai", "Đồng Tháp", "Gia Lai", "Hà Tĩnh", "Hải Phòng", "Hà Nội", "Hưng Yên", "Huế", "Khánh Hòa", "Lai Châu", "Lạng Sơn", "Lào Cai", "Lâm Đồng", "Nghệ An", "Ninh Bình", "Phú Thọ", "Quảng Ngãi", "Quảng Ninh", "Quảng Trị", "Sơn La", "Tây Ninh", "Thái Nguyên", "Thanh Hóa", "Thành phố Hồ Chí Minh", "Đà Nẵng", "Cần Thơ", "Vĩnh Long", "Tuyên Quang"
] as const;

export const PROVINCE_OPTIONS = Array.from(new Set(NATIONAL_PROVINCES)).sort((a, b) => a.localeCompare(b, "vi"));
