import { describe, expect, it } from "vitest";
import { buildPropertyCode } from "./db";

describe("buildPropertyCode", () => {
  it("creates a stable human-readable code from the database id", () => {
    expect(buildPropertyCode(1)).toBe("BDS-000001");
    expect(buildPropertyCode(42)).toBe("BDS-000042");
    expect(buildPropertyCode(1234567)).toBe("BDS-1234567");
  });
});
