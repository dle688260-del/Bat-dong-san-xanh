import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("Heartbeat callback route", () => {
  it("mounts both canonical and trailing-slash callback paths", () => {
    const source = readFileSync(resolve(process.cwd(), "server/_core/index.ts"), "utf8");
    expect(source).toContain('app.all("/api/scheduled/sync-legal-sources", scheduledLegalSyncHandler)');
    expect(source).toContain('app.all("/api/scheduled/sync-legal-sources/", scheduledLegalSyncHandler)');
  });
});
