import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("aiAutoDossier pending status contract", () => {
  const source = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");

  it("exposes a protected server query for persistent pending statuses", () => {
    expect(source).toContain("pendingStatuses: protectedProcedure");
    expect(source).toContain("procedureCodes: z.array(z.string().trim().min(2).max(80)).max(200).default([])");
    expect(source).toContain("pendingCodes: pending.map(item => item.procedureCode)");
    expect(source).toContain("officialReadyCodes: officialReady.map(item => item.procedureCode)");
    expect(source).toContain("referenceCodes: details.filter(item => item.classification === \"Reference\")");
    expect(source).toContain("metadataPendingCodes: details.filter(item => item.classification === \"Metadata/Pending\")");
    expect(source).toContain("details,\ checkedAt");
  });

  it("distinguishes missing bundle, binary, checksum, and Official verification", () => {
    expect(source).toContain("Chưa có bundle thủ tục trong kho");
    expect(source).toContain("Chưa tải được binary DOCX/PDF");
    expect(source).toContain("Binary tham khảo chưa có SHA-256");
    expect(source).toContain("Binary chưa đạt xác minh Official");
    expect(source).toContain("Chưa tải được binary DOCX/PDF; chỉ có metadata/discovery");
  });
});
