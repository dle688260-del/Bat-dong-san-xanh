# Nguồn tìm mẫu 09/ĐK

Ngày kiểm tra: 2026-08-22.

Các nguồn được tìm thấy để tiếp tục đối chiếu và tải binary:

- Cổng Dịch vụ công Quốc gia/Văn phòng Chính phủ, mã 2.000889: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889
- Cổng DVC địa phương Nhà Bè, TP.HCM: https://vptt-nhabe.tphcm.gov.vn/kiosk/KioskThuTucHanhChinh/LoadPartialThongTinThuTucChiTiet?ThuTucID=1268 — kết quả tìm kiếm ghi nhận thành phần “Đơn đăng ký biến động ... Mẫu số 09/ĐK” và tên tệp “mau so09.docx”; cần mở nguồn và kiểm tra tệp thật trước khi dùng.
- Cổng DVC Tiền Giang: https://dichvucong.tiengiang.gov.vn/block/phieu-huong-dan/thu-tuc/26334 — kết quả tìm kiếm ghi nhận “Mẫu số 09” và tệp DOCX; cần xác minh trực tiếp nguồn, phạm vi địa phương và checksum.
- Cổng DVC Tiền Giang: https://dichvucong.tiengiang.gov.vn/block/phieu-huong-dan/thu-tuc/26667 — kết quả tương tự, cần xác minh trực tiếp.
- Cổng Thông tin điện tử Chính phủ, Nghị định 101/2024/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=210791

Lưu ý: kết quả tìm kiếm/snippet chỉ là đầu mối. Chỉ binary tải thành công từ nguồn phù hợp, đúng mẫu và có SHA-256/provenance mới được ghi Official trong Kho AI pháp lý.

## Bằng chứng binary đã kiểm tra ngày 2026-08-22

Nguồn Văn phòng đăng ký đất đai/điểm tiếp nhận Nhà Bè hiển thị Mẫu 09/ĐK trong bảng thành phần hồ sơ:

- Trang thủ tục: https://vptt-nhabe.tphcm.gov.vn/kiosk/KioskThuTucHanhChinh/LoadPartialThongTinThuTucChiTiet?ThuTucID=1268
- Liên kết binary: https://vptt-nhabe.tphcm.gov.vn/kiosk/Areas/Admin/Content/files/mau%20so09.docx
- Tên file: `mau so09.docx`
- Loại file tải thực tế: Microsoft Word 2007+ (DOCX)
- SHA-256 quan sát được: `c589d04cf6b0e6f6f82574d4e806194291077459c2a7d86d0b2f79e0e2057dc2`
- Kích thước tải thực tế: 26 KB

File chỉ được gắn Official trong ứng dụng sau khi pipeline tải vào storage, lưu metadata dưới đúng mã thủ tục, đối chiếu thành phần và ghi nhận provenance/checksum trong database.
