import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getAdminAuthSettings, upsertAdminAuthSettings, getPropertyLayoutSettings, getPublicPropertyLayoutSettings, upsertPropertyLayoutSettings, listProperty3dAnnotations, createProperty3dAnnotation, updateProperty3dAnnotation, deleteProperty3dAnnotation, getDeal, updateDeal } from "./db";
import { hashAdminPassword, validateAdminPassword, verifyAdminPassword } from "./adminAuth";
import { sdk } from "./_core/sdk";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { canAccessSensitiveDossier } from "@shared/permissions";
import { Document, HeadingLevel, Packer, Paragraph, TextRun } from "docx";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { fillVerifiedTemplate, inspectVerifiedTemplate } from "./landTemplateEngine";
import { getVerifiedLandTemplate } from "./verifiedLandTemplates";
import { storageGetSignedUrl } from "./storage";
import { getOfficialLandProcedure, listOfficialLandProcedures, officialRegistryCheckedAt, searchOfficialLandProcedures } from "./officialLandProcedureRegistry";
import { OFFICIAL_2304_CODE_INDEX_NOTICE, OFFICIAL_2304_PROCEDURE_CODES, OFFICIAL_2304_SOURCE_URL, getVerified2304ProcedureName } from "./officialLandProcedureCodeIndex";
import { analyzeLegalSourceUrl, searchLegalDocuments } from "./legalSourceAnalyzer";
import { downloadOfficialTemplateCandidate, downloadPublicReferenceCandidate, findOfficialTemplateCandidates, discoverOfficialTemplateCandidates, discoverOfficialTemplateFallbacks } from "./officialTemplateFetcher";
import { assembleDvcProcedureBundle, confirmReferenceForPersonalUse, discoverDvcReceivingAuthorities, DVC_PROVINCE_COVERAGE, DVC_SOURCE_REGISTRY, getDvcSourcesForProcedure, listRegisteredDvcProvinces, mergeDvcReferenceBinaries, scanDvcProcedureSource } from "./dvcSourceRegistry";

const OFFICIAL_DISCOVERY_PROCEDURE_CODES: Record<string, string> = {
  transfer: "2.000889", "sale-house": "2.000889", variation: "2.000889", gift: "2.000889", inheritance: "2.000889",
  split: "1.012784", merge: "1.012784", "first-registration": "1.013978", certificate: "1.013978", "certificate-renewal": "1.012783",
};

/** Chuẩn hóa mã từ bộ chọn UI, mã canonical hoặc mã external của DVC. */
const resolveDiscoveryProcedureCode = (procedureId: string, province?: string) => {
  const mappedCode = OFFICIAL_DISCOVERY_PROCEDURE_CODES[procedureId] || procedureId;
  const procedure = getOfficialLandProcedure(mappedCode, province) || getOfficialLandProcedure(procedureId, province);
  return procedure?.code || mappedCode;
};

const requireSensitiveAccess = (role: "admin" | "user", action: "view" | "download" | "manage") => {
  if (!canAccessSensitiveDossier(role, action)) throw new TRPCError({ code: "FORBIDDEN", message: `Vai trò ${role} không được phép ${action === "view" ? "xem" : action === "download" ? "tải xuống" : "quản lý"} hồ sơ nhạy cảm.` });
};

export const normalizeTemplateSource = (value: string) => {
  try {
    const parsed = new URL(value.trim());
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : "https://dichvucong.gov.vn";
  } catch {
    return "https://dichvucong.gov.vn";
  }
};

const dossierComponentForAnalysisSchema = z.preprocess(value => {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const item = value as Record<string, unknown>;
  if (typeof item.name !== "string" || item.name.length <= 240) return item;
  const originalName = item.name.trim();
  const suffix = " …";
  return { ...item, name: `${originalName.slice(0, 240 - suffix.length).trimEnd()}${suffix}`, sourceName: originalName };
}, z.object({
  id: z.string().max(120),
  name: z.string().trim().min(1).max(240),
  sourceName: z.string().max(4000).optional(),
  required: z.boolean().optional(),
  evidence: z.string().max(1000).optional(),
}));
function inferAlternateComponentId(fileName: string, components: Awaited<ReturnType<typeof scanDvcProcedureSource>>["dossierComponents"]) {
  const normalizedFile = fileName.toLocaleLowerCase("vi").replace(/[^a-z0-9]+/gi, "");
  const fileNumbers = fileName.match(/\d+/g) || [];
  return components.find(component => {
    const normalizedComponent = component.name.toLocaleLowerCase("vi").replace(/[^a-z0-9]+/gi, "");
    if (normalizedComponent.includes(normalizedFile) || normalizedFile.includes(normalizedComponent)) return true;
    const componentNumbers: string[] = component.name.match(/\d+/g) || [];
    return fileNumbers.length > 0 && fileNumbers.some(number => componentNumbers.includes(number));
  })?.id;
}

async function discoverAndVerifyAlternateTemplates(procedureCode: string, snapshot: Awaited<ReturnType<typeof scanDvcProcedureSource>>, province?: string) {
  const procedure = getOfficialLandProcedure(procedureCode);
  if (!procedure) return { candidates: [], attachments: [], warnings: ["Không tìm thấy metadata thủ tục để rà nguồn thay thế."] };
  const sourceUrls = [
    ...(procedure.legalDocuments || []).map(item => item.sourceUrl),
    procedure.baseUrl,
    procedure.sourceUrl,
    ...getDvcSourcesForProcedure({ procedureCode, province }).filter(source => source.scope === "ministry" || source.scope === "provincial" || source.scope === "local").map(source => source.sourceUrl),
    "https://vanban.chinhphu.vn/",
    "https://www.monre.gov.vn/",
    "https://dichvucong.monre.gov.vn/",
    "https://htpldn.moj.gov.vn/Pages/chi-tiet-tin.aspx?ItemID=24&l=Phobienphapluatkinh",
  ];
  const templateNames = procedure.referenceTemplates.map(item => item.name);
  const templateCodes = procedure.referenceTemplates.flatMap(item => (item.name.match(/(?:mẫu|mau|form|phụ lục|phu luc)\s*(?:số\s*)?[A-Za-z0-9/-]+/gi) || []));
  const discovery = await discoverOfficialTemplateFallbacks({ sourceUrls, procedureName: procedure.name, procedureAliases: procedure.aliases, templateNames, templateCodes });
  const directCandidates = procedure.referenceTemplates
    .filter(item => /\.(?:docx?|pdf)(?:\?|$)/i.test(item.sourceUrl))
    .map(item => ({
      url: item.sourceUrl,
      fileName: decodeURIComponent(new URL(item.sourceUrl).pathname.split("/").pop() || item.name),
      format: /\.pdf(?:\?|$)/i.test(item.sourceUrl) ? "pdf" as const : "docx" as const,
      score: 10,
      matchedKeywords: [item.name],
      discovery: "official_fallback" as const,
    }));
  const candidateMap = new Map<string, (typeof directCandidates)[number] | (typeof discovery.candidates)[number]>();
  for (const candidate of [...directCandidates, ...discovery.candidates]) candidateMap.set(candidate.url, candidate);
  const sourcePriority = (url: string) => {
    try {
      const host = new URL(url).hostname.toLocaleLowerCase("vi");
      if (host.includes("dichvucong.gov.vn") || host.includes("vpcp.gov.vn")) return 100;
      if (host.includes("chinhphu.vn")) return 95;
      if (host.includes("monre.gov.vn") || host.includes("mae.gov.vn") || host.includes("dichvucong.monre.gov.vn")) return 90;
      if (host.includes("gov.vn")) return 80;
      return 20;
    } catch {
      return 0;
    }
  };
  const candidates = Array.from(candidateMap.values()).sort((a, b) => {
    const scoreA = (a.score || 0) + sourcePriority(a.url) + (a.matchedKeywords?.length || 0) * 3;
    const scoreB = (b.score || 0) + sourcePriority(b.url) + (b.matchedKeywords?.length || 0) * 3;
    return scoreB - scoreA;
  });
  const attachments = [];
  const warnings = discovery.sources.filter(source => !source.candidates.length).map(source => `Không tìm thấy link file mẫu khớp trên nguồn thay thế: ${source.sourceUrl}`);
  for (const candidate of candidates.slice(0, 20)) {
    try {
      const isLegacyReference = candidate.format === "doc";
      const downloaded = isLegacyReference
        ? await downloadPublicReferenceCandidate({ candidateUrl: candidate.url, originalFileName: candidate.fileName })
        : await downloadOfficialTemplateCandidate({ candidateUrl: candidate.url, originalFileName: candidate.fileName });
      const stored = await storagePut(`${isLegacyReference ? "dvc-reference-fallback" : "dvc-official-fallback"}/${procedureCode}/${downloaded.checksum}-${downloaded.fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`, downloaded.bytes, downloaded.contentType);
      const verificationFormat = candidate.format === "doc" ? undefined : candidate.format;
      const inspected = verificationFormat ? await inspectVerifiedTemplate({ id: `alternate-${downloaded.checksum.slice(0, 12)}`, fileName: downloaded.fileName, format: verificationFormat, mimeType: downloaded.contentType, sourceUrl: downloaded.sourceUrl, sourceCheckedAt: new Date().toISOString(), sha256: downloaded.checksum, storageKey: stored.key, sourceStatus: "verified" }, downloaded.bytes, []) : undefined;
      const matched = candidate.matchedKeywords.join(", ");
      attachments.push({ id: `${isLegacyReference ? "reference" : "official-fallback"}-${downloaded.checksum.slice(0, 16)}`, name: downloaded.fileName, url: downloaded.sourceUrl, kind: candidate.format, sourceUrl: downloaded.sourceUrl, checkedAt: new Date().toISOString(), status: isLegacyReference ? "matched_reference" as const : "verified_binary" as const, evidence: isLegacyReference ? `Binary Word legacy .doc từ nguồn công khai; chỉ giữ Reference-only, không được dùng làm Official/fill; matchedKeywords=${matched}; SHA-256=${downloaded.checksum}.` : `Binary tải từ nguồn thay thế chính thức ngoài DVC; matchedKeywords=${matched}; SHA-256=${downloaded.checksum}.`, storageKey: stored.key, fileUrl: stored.url, checksum: downloaded.checksum, fillable: inspected?.fillable, availableFields: inspected?.availableFields, componentId: inferAlternateComponentId(downloaded.fileName, snapshot.dossierComponents) });
    } catch (error) {
      warnings.push(`Không xác minh được file thay thế ${candidate.fileName}: ${error instanceof Error ? error.message : "lỗi không xác định"}`);
    }
  }
  return { candidates, attachments, warnings };
}

async function enrichDvcSnapshot(procedureCode: string, snapshot: Awaited<ReturnType<typeof scanDvcProcedureSource>>, province?: string) {
  // Khi DVC đã timeout/503, không tiếp tục quét tuần tự các nguồn thay thế trong cùng request autoscale; persisted Official templates sẽ được ghép ngay sau đó. Điều này tránh vượt timeout production và vẫn giữ cảnh báo Pending minh bạch.
  const shouldFallback = snapshot.fetched && (snapshot.attachments.every(item => item.status !== "verified_binary") || snapshot.warnings.some(item => /503|không tải|chưa tìm thấy/i.test(item)));
  if (!shouldFallback) return { snapshot, fallback: { candidates: [], attachments: [], warnings: [] as string[] } };
  try {
    const fallback = await discoverAndVerifyAlternateTemplates(procedureCode, snapshot, province);
    const existing = new Set(snapshot.attachments.map(item => item.checksum || item.url));
    const attachments = [...snapshot.attachments, ...fallback.attachments.filter(item => !existing.has(item.checksum || item.url))];
    return { snapshot: { ...snapshot, attachments, warnings: [...snapshot.warnings, ...fallback.warnings] }, fallback };
  } catch (error) {
    // Alternate-source discovery is best effort. Never discard a valid DVC
    // snapshot (especially its registry fallback components) because one
    // external source timed out or returned malformed HTML.
    return {
      snapshot: { ...snapshot, warnings: [...snapshot.warnings, `Nguồn thay thế không truy cập được: ${error instanceof Error ? error.message : "lỗi không xác định"}`] },
      fallback: { candidates: [], attachments: [], warnings: [] as string[] },
    };
  }
}

/**
 * Hợp nhất các binary Official đã xác minh trong Kho AI pháp lý vào snapshot
 * DVC. Kho persisted là nguồn chuẩn; scan DVC chỉ bổ sung ứng viên mới.
 */
async function mergePersistedOfficialTemplates(procedureCode: string, scan: Awaited<ReturnType<typeof scanDvcProcedureSource>>) {
  const legalBundle = await getLegalProcedureBundle(procedureCode);
  const verifiedTemplates = (legalBundle?.templates || []).filter(item =>
    (item.provenance === "verified_binary" || item.provenance === "official") &&
    Boolean(item.storageKey || item.fileUrl) &&
    Boolean(item.checksum),
  );
  if (!verifiedTemplates.length) return { scan, persistedOfficialCount: 0 };

  const components = scan.dossierComponents.length
    ? scan.dossierComponents
    : (legalBundle?.requirements || []).map(item => ({
        id: String(item.id),
        name: item.label,
        required: Boolean(item.required),
        evidence: item.notes || "Thành phần hồ sơ từ Kho AI pháp lý.",
      }));
  const existing = new Set(scan.attachments.map(item => item.checksum || item.url));
  const persistedAttachments = verifiedTemplates
    .filter(item => !existing.has(item.checksum || item.fileUrl || item.sourceUrl || String(item.id)))
    .map(item => {
      const sourceUrl = item.sourceUrl || item.fileUrl || scan.sourceUrl;
      const fileName = item.name || `legal-template-${item.id}`;
      const format = item.format === "pdf" ? "pdf" as const : "docx" as const;
      return {
        id: `legal-official-${item.id}`,
        name: fileName,
        url: sourceUrl,
        kind: format,
        sourceUrl,
        checkedAt: new Date().toISOString(),
        status: "verified_binary" as const,
        evidence: `Mẫu Official đã xác minh trong Kho AI pháp lý; provenance=${item.provenance}; SHA-256=${item.checksum}.`,
        storageKey: item.storageKey || undefined,
        fileUrl: item.fileUrl || undefined,
        checksum: item.checksum || undefined,
        componentId: inferAlternateComponentId(fileName, components),
        sourceLayer: "template_file" as const,
      };
    });
  return {
    scan: { ...scan, dossierComponents: components, attachments: [...scan.attachments, ...persistedAttachments] },
    persistedOfficialCount: persistedAttachments.length,
  };
}

/** Materialize các binary đã allowlist; mã ngoài được quy về mã canonical của registry. */
async function materializeRegistryOfficialTemplates(procedureCode: string) {
  const registry = getOfficialLandProcedure(procedureCode);
  if (!registry?.verifiedTemplates?.length) return { canonicalCode: registry?.code ?? procedureCode, materialized: 0, failures: [] as string[] };
  const procedure = await ensureLegalProcedureFromRegistry(registry.code);
  if (!procedure) return { canonicalCode: registry.code, materialized: 0, failures: ["Không tạo được thủ tục canonical trong Kho AI pháp lý."] };
  const parsedSource = new URL(registry.sourceUrl);
  const source = await upsertLegalSource({ name: registry.sourceName, baseUrl: registry.baseUrl || parsedSource.origin, sourceType: registry.sourceType === "public_service" ? "public_service" : "government", jurisdiction: "national", notes: `Registry kiểm tra ${registry.checkedAt}; dùng để materialize binary allowlist.` });
  const results = await mapWithConcurrency(registry.verifiedTemplates, 3, async official => {
    try {
      const downloaded = await downloadOfficialTemplateCandidate({ candidateUrl: official.sourceUrl, originalFileName: official.name });
      if (downloaded.checksum !== official.checksum) throw new Error(`SHA-256 không khớp allowlist: ${downloaded.checksum}`);
      const stored = await storagePut(`legal-official/${registry.code}/${downloaded.checksum}_${downloaded.fileName}`, downloaded.bytes, downloaded.contentType || undefined);
      await upsertOfficialLegalTemplate({ procedureId: procedure.id, sourceId: source.id, name: official.name, documentType: official.documentType, format: official.format, sourceUrl: official.sourceUrl, storageKey: stored.key, fileUrl: stored.url, checksum: downloaded.checksum, notes: official.notes });
      return { materialized: 1, failure: undefined };
    } catch (error) {
      return { materialized: 0, failure: `${official.name}: ${error instanceof Error ? error.message : "không xác định"}` };
    }
  });
  return {
    canonicalCode: registry.code,
    materialized: results.reduce((total, result) => total + result.materialized, 0),
    failures: results.flatMap(result => result.failure ? [result.failure] : []),
  };
}

// Bundle và officialStatus thường được mở cùng lúc. Cache in-flight/TTL ngăn hai query tải
// cùng một binary ngoài mạng và kiểm SHA-256 lặp lại cho cùng một mã thủ tục.
const registryMaterializeCache = new Map<string, { promise: Promise<unknown>; expiresAt: number }>();
const materializeRegistryOnce = (code: string) => {
  const cached = registryMaterializeCache.get(code);
  if (cached && cached.expiresAt > Date.now()) return cached.promise;
  const promise = materializeRegistryOfficialTemplates(code).catch(error => {
    registryMaterializeCache.delete(code);
    throw error;
  });
  registryMaterializeCache.set(code, { promise, expiresAt: Date.now() + 5 * 60_000 });
  return promise;
};

/** Một workflow duy nhất cho mọi mã: discovery → fallback → binary/checksum → bundle/mapping. */
async function runProcedureWorkflow(procedureCode: string, province?: string) {
  const materialized = await materializeRegistryOnce(procedureCode) as Awaited<ReturnType<typeof materializeRegistryOfficialTemplates>>;
  const dvcScan = await scanDvcProcedureSource({ procedureCode: materialized.canonicalCode, province });
  const enriched = await enrichDvcSnapshot(materialized.canonicalCode, dvcScan, province);
  const merged = await mergePersistedOfficialTemplates(materialized.canonicalCode, enriched.snapshot);
  return {
    scan: merged.scan,
    fallback: enriched.fallback,
    bundle: assembleDvcProcedureBundle(merged.scan, materialized.canonicalCode),
    persistedOfficialCount: merged.persistedOfficialCount,
    materializeFailures: materialized.failures,
  };
}

/** Dựng kế hoạch từ snapshot vừa discovery; không quét mạng lần hai cho cùng một thao tác. */
function buildPlanFromWorkflow(input: { procedureCode: string; province?: string }, workflow: Awaited<ReturnType<typeof runProcedureWorkflow>>) {
  const snapshot = workflow.scan;
  const requirements = snapshot.dossierComponents.map((component, index) => ({
    id: component.id,
    order: index + 1,
    name: component.name,
    required: component.required,
    evidence: component.evidence,
    status: "needs_input" as const,
  }));
  const sourceWorkflow = snapshot.procedureSteps.length
    ? snapshot.procedureSteps.map((title, index) => ({ id: `dvc-step-${index + 1}`, order: index + 1, title, status: "needs_review" as const }))
    : [
        { id: "source", order: 1, title: "Đọc nguồn thủ tục chính thức", status: snapshot.fetched ? "ready" as const : "needs_review" as const },
        { id: "requirements", order: 2, title: "Phân tích thành phần hồ sơ", status: requirements.length ? "ready" as const : "needs_review" as const },
        { id: "templates", order: 3, title: "Phát hiện và ghép biểu mẫu", status: snapshot.attachments.length ? "ready" as const : "needs_review" as const },
      ];
  const workflowSteps = [
    ...sourceWorkflow,
    { id: "profile", order: sourceWorkflow.length + 1, title: "Nhập thông tin hồ sơ một lần", status: "needs_input" as const },
    { id: "review", order: sourceWorkflow.length + 2, title: "Kiểm tra và xác nhận trước khi xuất", status: "needs_review" as const },
  ];
  const procedureBundle = workflow.bundle;
  return { module: "ai-auto-dossier" as const, procedureCode: input.procedureCode, province: input.province ?? null, snapshot, alternateCandidates: workflow.fallback.candidates, workflow: workflowSteps, requirements, procedureBundle, generatedAt: new Date().toISOString(), notice: `Đã ghép ${procedureBundle.readyCount}/${procedureBundle.totalCount} thành phần có binary đã kiểm tra, trong đó ${workflow.persistedOfficialCount} mẫu Official được lấy từ Kho AI pháp lý; nguồn thay thế vẫn được rà khi DVC lỗi.` };
}

import { createBuyerLead, createConsultationRequest, createDeal, listSoldPropertiesForTransaction, createLegalCheck, createOwner, createProperty, updateProperty, createPropertyImage, deleteProperty, createSurvey, createValuation, getPublishedPropertyWithImages, listAreas, listBuyerLeads, listConsultationRequests, listDeals, listFeaturedProperties, listLatestPublishedProperties, listLegalChecks, listOwners, listProperties, listPropertiesByCreator, listPublishedProperties, listSurveys, listValuations, updateConsultationStatus, deleteConsultationRequest, updatePropertyStatus, ensureDealForSoldProperty, listPropertyDossiers, getPropertyDossier, createPropertyDossier, ensurePropertyDossier, listPropertyDossiersForUser, updatePropertyDossier, deletePropertyDossier, updatePropertyDossierStep, createPropertyDossierDocument, deletePropertyDossierDocument, listLegalDocumentScans, createLegalDocumentScan, confirmLegalDocumentScan, rejectLegalDocumentScan, updatePropertyLocation, listPropertyArchiveFiles, createPropertyArchiveFile, renamePropertyArchiveFile, deletePropertyArchiveFile, getDashboardSummary, listLandDossiers, getLandDossier, createLandDossier, updateLandDossier, deleteLandDossier, updateLandDossierStep, updateConsultationAi, listLegalSources, listLegalProcedures, mergeLegalProcedureCatalog, getLegalProcedureBundle, listLegalTemplates, createLegalSource, upsertLegalSource, createLegalProcedure, createLegalTemplate, createLegalRequirement, createLegalSyncRun, finishLegalSyncRun, createLegalDocument, updateLegalTemplateBinary, getLegalTemplateWithFields, suggestLegalTemplates, upsertOfficialLegalTemplate, upsertOfficialLegalTemplateMapping, ensureLegalProcedureFromRegistry, saveLegalProcedureVersion, listLegalProcedureVersions, saveLegalTemplateMappings, listLegalTemplateMappings, appendLandDossierAudit, listLandDossierAudits, upsertUserUploadLegalTemplate, getManusConnectionState, updateManusConnectionState, createManusChangeRequest, listManusChangeRequests, markManusChangeSynced, approveManusChange, findRecentMarketingConsultation, listMarketingCampaigns, getMarketingCampaign, getPublishedPropertyById, createMarketingCampaign, updateMarketingCampaign, listMarketingChannels, createMarketingChannel, updateMarketingChannel, listMarketingContents, createMarketingContent, updateMarketingContent, listMarketingCalendar, createMarketingCalendarItem, updateMarketingCalendarItem } from "./db";

const propertyType = z.enum(["house", "land", "apartment", "villa", "industrial", "commercial_land", "agricultural", "commercial", "resort", "project", "rental"]);
const propertyStatus = z.enum(["draft", "published", "reserved", "sold"]);
const marketingChannelType = z.enum(["website", "facebook", "tiktok", "zalo", "youtube", "email", "google", "other"]);
const marketingObjective = z.enum(["sell", "rent", "consignment", "buyer", "area", "project", "brand"]);
const marketingCampaignStatus = z.enum(["draft", "active", "paused", "completed"]);
const marketingContentType = z.enum(["title", "description", "facebook_post", "website_copy", "ad_copy", "video_script", "reel_script", "email", "message"]);
const marketingContentStatus = z.enum(["draft", "pending_review", "published", "ended"]);
const marketingCalendarStatus = z.enum(["planned", "published", "cancelled"]);
const marketingCampaignInput = z.object({ name: z.string().trim().min(2).max(180), objective: marketingObjective.default("sell"), propertyId: z.number().int().positive().nullable().optional(), audience: z.string().trim().max(255).nullable().optional(), channels: z.array(marketingChannelType).max(8).optional(), budget: z.string().regex(/^\d+(\.\d{1,2})?$/).nullable().optional(), startsAt: z.coerce.date().nullable().optional(), endsAt: z.coerce.date().nullable().optional(), status: marketingCampaignStatus.optional() });
const marketingContentInput = z.object({ campaignId: z.number().int().positive().nullable().optional(), propertyId: z.number().int().positive().nullable().optional(), channelType: marketingChannelType, contentType: marketingContentType, title: z.string().trim().max(255).nullable().optional(), body: z.string().trim().min(1).max(20000), status: marketingContentStatus.optional(), scheduledAt: z.coerce.date().nullable().optional(), aiGenerated: z.boolean().optional() });
const propertyImageUrl = z.string().refine(value => /^https?:\/\//.test(value) || /^\/manus-storage\//.test(value), "URL media không hợp lệ");
const propertyMediaUrl = propertyImageUrl;
const propertyMediaMime = z.string().regex(/^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime))$/);
const property3dMime = z.string().regex(/^(model\/gltf\+json|model\/gltf-binary|application\/octet-stream|application\/x-ply|application\/x-e57)$/);

const consultationAiSchema = { type: "object", additionalProperties: false, properties: {
  propertyType: { type: ["string", "null"] }, area: { type: ["string", "null"] }, budgetMin: { type: ["number", "null"] }, budgetMax: { type: ["number", "null"] }, purpose: { type: ["string", "null"] }, minArea: { type: ["number", "null"] }, bedrooms: { type: ["number", "null"] }, timeline: { type: ["string", "null"] }, priority: { type: "string", enum: ["high", "potential", "reference"] }, summary: { type: "string" }, missingInfo: { type: "array", items: { type: "string" } }
}, required: ["propertyType", "area", "budgetMin", "budgetMax", "purpose", "minArea", "bedrooms", "timeline", "priority", "summary", "missingInfo"] } as const;

type ConsultationAiProfile = { propertyType: string | null; area: string | null; budgetMin: number | null; budgetMax: number | null; purpose: string | null; minArea: number | null; bedrooms: number | null; timeline: string | null; priority: "high" | "potential" | "reference"; summary: string; missingInfo: string[] };

async function analyzeConsultationRequest(id: number, input: { name: string; interest: string; message: string | null; conversationHistory?: string | null; propertyIds?: number[] }) {
  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: "Bạn là AI quản lý nhu cầu khách hàng cho sàn bất động sản Việt Nam. Hãy trích xuất hồ sơ mua hàng từ yêu cầu tư vấn. Không tự bịa dữ liệu còn thiếu; để null và ghi vào missingInfo. Chấm priority high khi khách có ngân sách rõ, nhu cầu cụ thể và thời gian mua trong khoảng 1 tháng; potential khi nhu cầu tương đối rõ; reference khi chỉ tham khảo. Chỉ trả JSON theo schema." },
        { role: "user", content: `Khách hàng: ${input.name}\nNhu cầu: ${input.interest}\nLời nhắn: ${input.message || "Không có"}\nLịch sử AI đã tư vấn: ${input.conversationHistory || "Chưa có"}\nBĐS khách quan tâm: ${(input.propertyIds || []).join(", ") || "Chưa xác định"}` },
      ],
      response_format: { type: "json_schema", json_schema: { name: "consultation_need_profile", strict: true, schema: consultationAiSchema } },
      maxTokens: 900,
    });
    const content = response.choices?.[0]?.message?.content;
    const profile = JSON.parse(typeof content === "string" ? content : "{}") as ConsultationAiProfile;
    const typeMap: Record<string, "house" | "land" | "apartment" | "villa" | "industrial" | "commercial_land" | "agricultural" | "commercial" | "resort" | "project" | "rental"> = { "nhà phố": "house", "nhà": "house", "đất nền": "land", "đất": "land", "đất thương mại": "commercial_land", "đất nông nghiệp": "agricultural", "khu thương mại": "commercial", "khu nghỉ dưỡng": "resort", "resort": "resort", "đất dự án": "project", "dự án": "project", "cho thuê": "rental", "cho thuê khác": "rental", "căn hộ": "apartment", "chung cư": "apartment", "villa": "villa", "khu công nghiệp": "industrial", "industrial": "industrial" };
    const normalizedType = profile.propertyType ? typeMap[profile.propertyType.toLowerCase()] : undefined;
    const filters = { propertyType: normalizedType, location: profile.area || undefined, minPrice: profile.budgetMin ?? undefined, maxPrice: profile.budgetMax ?? undefined, minArea: profile.minArea ?? undefined, minBedrooms: profile.bedrooms ?? undefined, sort: "newest" as const };
    let matches = await listPublishedProperties(filters);
    if (!matches.length) matches = await listPublishedProperties({ propertyType: normalizedType, q: profile.area || undefined, sort: "newest" });
    const matched = matches.slice(0, 5).map((property, index) => ({ id: property.id, title: property.title, slug: property.slug, location: property.location, price: property.price, area: property.area, fitScore: Math.max(60, 94 - index * 4) }));
    const completeness = [profile.propertyType, profile.area, profile.budgetMax, profile.purpose, profile.timeline].filter(value => value !== null && value !== undefined && value !== "").length;
    const aiScore = profile.priority === "high" ? Math.min(100, 78 + completeness * 4) : profile.priority === "potential" ? Math.min(79, 54 + completeness * 5) : Math.min(53, 28 + completeness * 5);
    const routingStage = profile.area ? "area_queue" as const : "admin_queue" as const;
    await updateConsultationAi(id, { aiStatus: "analyzed", aiPriority: profile.priority, aiSummary: profile.summary, aiProfile: JSON.stringify(profile), aiMatches: JSON.stringify(matched), aiAnalyzedAt: new Date(), aiArea: profile.area, aiScore, routingStage, conversationHistory: input.conversationHistory || null });
    if (profile.priority === "high") {
      await notifyOwner({
        title: "🔥 AI xác định khách hàng ưu tiên cao",
        content: `${input.name} có nhu cầu ưu tiên cao. ${profile.summary}\n${profile.area ? `Khu vực: ${profile.area}` : "Khu vực: chưa rõ"}\nAI tìm thấy ${matched.length} BĐS phù hợp. Mở mục Yêu cầu tư vấn để xử lý tiếp.`,
      });
    }
    return { profile, matches: matched };
  } catch (error) {
    console.warn("[Consultation AI] Analysis failed:", error);
    await updateConsultationAi(id, { aiStatus: "failed", aiAnalyzedAt: new Date() });
    return { profile: null, matches: [] };
  }
}

async function extractLegalFileText(bytes: Buffer, mimeType: string | undefined, fileName: string | undefined) {
  const mime = (mimeType || "").toLowerCase();
  const name = (fileName || "").toLowerCase();
  if (mime.includes("wordprocessingml") || name.endsWith(".docx")) {
    const mammoth = await import("mammoth");
    const result = await mammoth.extractRawText({ buffer: bytes });
    return result.value.trim();
  }
  if (mime === "application/pdf" || name.endsWith(".pdf")) {
    const { PDFParse } = await import("pdf-parse");
    const parser = new PDFParse({ data: bytes });
    try {
      const result = await parser.getText();
      return result.text.trim();
    } finally {
      await parser.destroy();
    }
  }
  if (mime.startsWith("text/") || /\.(txt|md|csv|html?|json)$/i.test(name) || !mime) return bytes.toString("utf8").trim();
  throw new TRPCError({ code: "BAD_REQUEST", message: "Định dạng này chưa được hỗ trợ tự đọc. Hãy dùng TXT, MD, CSV, HTML, JSON, DOCX hoặc PDF có lớp văn bản." });
}

async function extractLegalFileWithVision(bytes: Buffer, mimeType: string | undefined, fileName: string | undefined) {
  const mime = (mimeType || "application/octet-stream").toLowerCase();
  const isImage = mime.startsWith("image/") || /\.(png|jpe?g|webp)$/i.test(fileName || "");
  const isPdf = mime === "application/pdf" || /\.pdf$/i.test(fileName || "");
  if (!isImage && !isPdf) throw new TRPCError({ code: "BAD_REQUEST", message: "OCR pháp lý chỉ nhận ảnh PNG/JPG/WEBP hoặc PDF scan." });
  const dataUrl = `data:${mime};base64,${bytes.toString("base64")}`;
  const content = isImage
    ? [{ type: "text" as const, text: "Đọc toàn bộ chữ nhìn thấy trong ảnh văn bản pháp luật hoặc biểu mẫu đất đai. Giữ nguyên số hiệu, tiêu đề, mục, điều, khoản và bảng biểu; phần không đọc rõ ghi [KHÔNG RÕ], không suy đoán." }, { type: "image_url" as const, image_url: { url: dataUrl, detail: "high" as const } }]
    : [{ type: "text" as const, text: "Đọc toàn bộ nội dung tệp PDF pháp luật hoặc biểu mẫu đất đai. Nếu là bản scan, OCR từng trang; giữ nguyên số hiệu, tiêu đề, mục, điều, khoản và bảng biểu; phần không đọc rõ ghi [KHÔNG RÕ], không suy đoán." }, { type: "file_url" as const, file_url: { url: dataUrl, mime_type: "application/pdf" as const } }];
  const response = await invokeLLM({
    messages: [{ role: "system", content }, { role: "user", content: "Chỉ trả JSON theo schema. Đây là bản trích xuất hỗ trợ rà soát, không xác nhận hiệu lực hay tính chính thức của văn bản." }],
    outputSchema: { name: "legal_scan_ocr", strict: true, schema: { type: "object", additionalProperties: false, properties: { extractedText: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 100 }, warnings: { type: "array", items: { type: "string" } } }, required: ["extractedText", "confidence", "warnings"] } },
    maxTokens: 6000,
  });
  const raw = typeof response.choices?.[0]?.message?.content === "string" ? response.choices[0].message.content : JSON.stringify(response.choices?.[0]?.message?.content || "{}");
  try {
    const parsed = JSON.parse(raw) as { extractedText?: string; confidence?: number; warnings?: string[] };
    const extractedText = (parsed.extractedText || "").trim();
    if (extractedText.length < 20) throw new Error("empty OCR");
    return { text: extractedText, confidence: Math.max(0, Math.min(100, Number(parsed.confidence) || 0)), warnings: parsed.warnings || [] };
  } catch {
    throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa đọc rõ tệp scan. Hãy tải ảnh/PDF rõ hơn hoặc kiểm tra nội dung trước khi lưu." });
  }
}

async function mapWithConcurrency<T, R>(items: T[], concurrency: number, worker: (item: T) => Promise<R>) {
  const results: R[] = new Array(items.length);
  let cursor = 0;
  async function runWorker() {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      results[index] = await worker(items[index]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length || 1) }, () => runWorker()));
  return results;
}

const propertyLayoutValues = ["auto", "mosaic", "grid2", "grid3", "carousel"] as const;
const listingKindValues = ["house", "land", "apartment", "villa", "industrial", "commercial_land", "agricultural", "commercial", "resort", "project", "rental"] as const;

export const appRouter = router({
  propertyLayoutSettings: router({
    public: publicProcedure.query(() => getPublicPropertyLayoutSettings()),
    get: adminProcedure.query(({ ctx }) => getPropertyLayoutSettings(ctx.user.id)),
    save: adminProcedure.input(z.object({
      defaultLayout: z.enum(propertyLayoutValues),
      overrides: z.record(z.string(), z.enum(propertyLayoutValues)).superRefine((value, ctx) => { for (const key of Object.keys(value)) if (!(listingKindValues as readonly string[]).includes(key)) ctx.addIssue({ code: z.ZodIssueCode.custom, message: `Danh mục không hợp lệ: ${key}` }); }),
    })).mutation(({ ctx, input }) => upsertPropertyLayoutSettings(ctx.user.id, input)),
  }),
  system: systemRouter,
  manusConnection: router({
    status: adminProcedure.query(async () => ({ state: await getManusConnectionState(), requests: await listManusChangeRequests() })),
    connect: adminProcedure.mutation(async () => updateManusConnectionState({ status: "connected", lastSyncMessage: "Đã kết nối theo sự đồng ý của quản trị viên." })),
    disconnect: adminProcedure.mutation(async () => {
      const state = await getManusConnectionState();
      if (state.lastSyncStatus === "pending") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Chưa thể ngắt kết nối: vẫn còn yêu cầu chưa đồng bộ thành công." });
      return updateManusConnectionState({ status: "disconnected", lastSyncMessage: "Đã ngắt kết nối sau khi đồng bộ thành công." });
    }),
    requestUpdate: adminProcedure.input(z.object({ title: z.string().trim().min(3).max(180), description: z.string().trim().min(5).max(5000), requestType: z.enum(["fix", "update", "configuration"]).default("update") })).mutation(async ({ input, ctx }) => {
      const created = await createManusChangeRequest({ ...input, requestedBy: ctx.user.id, localDraft: JSON.stringify({ title: input.title, description: input.description, requestedAt: new Date().toISOString() }) });
      await updateManusConnectionState({ status: "connected" });
      return created;
    }),
    syncRequest: adminProcedure.input(z.object({ id: z.number().int().positive(), syncSummary: z.string().trim().min(5).max(2000), localDraft: z.string().max(20000).optional() })).mutation(async ({ input }) => markManusChangeSynced(input.id, input.syncSummary, input.localDraft)),
    approveRequest: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => approveManusChange(input.id, ctx.user.id)),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    adminLogin: publicProcedure
      .input(z.object({ username: z.string().trim().min(1).max(120), password: z.string().min(1).max(256) }))
      .mutation(async ({ input, ctx }) => {
        const stored = await getAdminAuthSettings(input.username);
        if (!await verifyAdminPassword(input.username, input.password, stored?.passwordHash)) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Tên đăng nhập hoặc mật khẩu quản trị không đúng." });
        }
        const token = await sdk.signSession({
          openId: `admin_${input.username}`,
          appId: process.env.VITE_APP_ID || "admin",
          name: "Quản trị viên",
        }, { expiresInMs: 8 * 60 * 60 * 1000 });
        ctx.res.cookie(COOKIE_NAME, token, getSessionCookieOptions(ctx.req));
        return { success: true } as const;
      }),
    changePasswordFromLogin: publicProcedure
      .input(z.object({ username: z.string().trim().min(1).max(120), currentPassword: z.string().min(1).max(256), newPassword: z.string().min(10).max(256), confirmPassword: z.string().min(10).max(256) }))
      .mutation(async ({ input }) => {
        const stored = await getAdminAuthSettings(input.username);
        if (!await verifyAdminPassword(input.username, input.currentPassword, stored?.passwordHash)) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Tên đăng nhập hoặc mật khẩu hiện tại không đúng." });
        }
        if (input.newPassword !== input.confirmPassword) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Mật khẩu mới và xác nhận mật khẩu không khớp." });
        }
        if (!validateAdminPassword(input.newPassword)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Mật khẩu mới phải có ít nhất 10 ký tự, gồm chữ và số." });
        }
        await upsertAdminAuthSettings(input.username, await hashAdminPassword(input.newPassword));
        return { success: true } as const;
      }),
    changePassword: protectedProcedure
      .input(z.object({ currentPassword: z.string().min(1).max(256), newPassword: z.string().min(10).max(256), confirmPassword: z.string().min(10).max(256) }))
      .mutation(async ({ input, ctx }) => {
        const username = ctx.user.openId.startsWith("admin_") ? ctx.user.openId.slice("admin_".length) : "";
        if (!username) throw new TRPCError({ code: "FORBIDDEN", message: "Chỉ phiên quản trị mới được đổi mật khẩu." });
        const stored = await getAdminAuthSettings(username);
        if (!await verifyAdminPassword(username, input.currentPassword, stored?.passwordHash)) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Mật khẩu hiện tại không đúng." });
        }
        if (input.newPassword !== input.confirmPassword) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Mật khẩu mới và xác nhận mật khẩu không khớp." });
        }
        if (!validateAdminPassword(input.newPassword)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Mật khẩu mới phải có ít nhất 10 ký tự, gồm chữ và số." });
        }
        await upsertAdminAuthSettings(username, await hashAdminPassword(input.newPassword));
        return { success: true } as const;
      }),
    logout: publicProcedure.mutation(({ ctx }) => { ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 }); return { success: true } as const; }),
  }),
  aiAutoDossier: router({
    pendingStatuses: protectedProcedure.input(z.object({ procedureCodes: z.array(z.string().trim().min(2).max(80)).max(200).default([]) })).query(async ({ input }) => {
      const details = await Promise.all(input.procedureCodes.map(async code => {
        try {
          const bundle = await getLegalProcedureBundle(code);
          const templates = bundle?.templates || [];
          const verified = templates.filter(item => (item.provenance === "verified_binary" || item.provenance === "official") && Boolean(item.storageKey || item.fileUrl) && Boolean(item.checksum));
          if (verified.length > 0) return { procedureCode: code, status: "official_ready" as const, classification: "Official" as const, reason: "Có binary, checksum và provenance Official đã xác minh." };
          const hasBinary = templates.some(item => Boolean(item.storageKey || item.fileUrl));
          const hasChecksum = templates.some(item => Boolean(item.checksum));
          const classification = hasBinary ? "Reference" as const : "Metadata/Pending" as const;
          return { procedureCode: code, status: "pending" as const, classification, reason: !bundle ? "Chưa có bundle thủ tục trong kho" : !templates.length ? "Chưa có biểu mẫu/binary được lưu" : !hasBinary ? "Chưa tải được binary DOCX/PDF; chỉ có metadata/discovery" : !hasChecksum ? "Binary tham khảo chưa có SHA-256" : "Binary chưa đạt xác minh Official" };
        } catch (error) {
          return { procedureCode: code, status: "pending" as const, classification: "Metadata/Pending" as const, reason: error instanceof Error ? `Lỗi truy vấn trạng thái: ${error.message}` : "Lỗi truy vấn trạng thái" };
        }
      }));
      const pending = details.filter(item => item.status === "pending");
      const officialReady = details.filter(item => item.status === "official_ready");
      return { pendingCodes: pending.map(item => item.procedureCode), officialReadyCodes: officialReady.map(item => item.procedureCode), referenceCodes: details.filter(item => item.classification === "Reference").map(item => item.procedureCode), metadataPendingCodes: details.filter(item => item.classification === "Metadata/Pending").map(item => item.procedureCode), details, checkedAt: new Date().toISOString() };
    }),
    identifyProcedure: protectedProcedure.input(z.object({
      province: z.string().trim().max(120).optional(),
      documents: z.array(z.object({
        fileName: z.string().trim().min(1).max(180),
        documentType: z.string().trim().max(180).optional(),
        ocrText: z.string().trim().max(8000).optional(),
        ocrFields: z.array(z.object({ label: z.string().trim().max(160), value: z.string().max(1000), evidence: z.string().max(600).optional() })).max(24).optional(),
      })).min(1).max(24),
    })).mutation(async ({ input }) => {
      const evidenceText = input.documents.map(document => [document.fileName, document.documentType || "", document.ocrText || "", ...(document.ocrFields || []).flatMap(field => [field.label, field.value, field.evidence || ""])].join(" ")).join("\\n").slice(0, 80_000);
      const registry = searchOfficialLandProcedures("", input.province).slice(0, 260).map(item => ({ code: item.code, name: item.name, aliases: item.aliases, groupName: item.groupName }));
      const allowedCodes = new Set(registry.map(item => item.code));
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là trợ lý nhận diện thủ tục đất đai Việt Nam. Chỉ đề xuất mã có trong danh mục được cung cấp; không tự tạo mã, không kết luận hồ sơ hợp lệ. Dựa trên tên tài liệu và bằng chứng OCR, trả tối đa 5 đề xuất theo mức phù hợp giảm dần. Nếu bằng chứng không đủ, ghi rõ cần người dùng xác nhận." },
          { role: "user", content: `Địa phương: ${input.province || "Chưa chọn"}\\nBằng chứng tài liệu:\\n${evidenceText}\\n\\nDanh mục mã được phép:\\n${registry.map(item => `${item.code} | ${item.name} | ${(item.aliases || []).join(", ")} | ${item.groupName}`).join("\\n")}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "land_dossier_procedure_identification", strict: true, schema: { type: "object", additionalProperties: false, properties: { suggestions: { type: "array", maxItems: 5, items: { type: "object", additionalProperties: false, properties: { procedureCode: { type: "string" }, reason: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 1 }, evidence: { type: "array", items: { type: "string" }, maxItems: 5 } }, required: ["procedureCode", "reason", "confidence", "evidence"] } }, notice: { type: "string" } }, required: ["suggestions", "notice"] } } },
        maxTokens: 1800,
      });
      let parsed: { suggestions?: Array<{ procedureCode: string; reason: string; confidence: number; evidence: string[] }>; notice?: string } = {};
      const content = response.choices?.[0]?.message?.content;
      try { parsed = JSON.parse(typeof content === "string" ? content : JSON.stringify(content || "{}")); } catch { parsed = { notice: "AI chưa trả về kết quả có cấu trúc; hãy chọn thủ tục thủ công." }; }
      const aiSuggestions = Array.isArray(parsed.suggestions) ? parsed.suggestions : [];
      const suggestions = aiSuggestions.filter(item => allowedCodes.has(item.procedureCode)).map(item => {
        const catalogItem = registry.find(candidate => candidate.code === item.procedureCode);
        return { procedureCode: item.procedureCode, procedureTitle: catalogItem?.name || item.procedureCode, groupName: catalogItem?.groupName || "", reason: item.reason, confidence: Math.max(0, Math.min(1, Number(item.confidence) || 0)), evidence: item.evidence || [], sourceUrl: getOfficialLandProcedure(item.procedureCode, input.province)?.sourceUrl || null };
      });
      const deterministic = searchOfficialLandProcedures(evidenceText, input.province).slice(0, 5).map(item => ({ procedureCode: item.code, procedureTitle: item.name, groupName: item.groupName, reason: "Khớp trực tiếp với registry từ tên/bằng chứng tài liệu.", confidence: 0.55, evidence: ["Kết quả tìm kiếm registry"], sourceUrl: item.sourceUrl }));
      return { suggestions: suggestions.length ? suggestions : deterministic, notice: parsed.notice || "AI chỉ hỗ trợ đề xuất. Hãy mở nguồn chính thức và xác nhận thủ tục trước khi tạo hồ sơ.", checkedAt: new Date().toISOString(), province: input.province || null };
    }),
    catalog: protectedProcedure.input(z.object({ query: z.string().trim().max(180).optional(), province: z.string().trim().max(120).optional() }).optional()).query(async ({ input }) => {
      const query = input?.query || "";
      const registered = searchOfficialLandProcedures(query, input?.province);
      const databaseItems = await listLegalProcedures(query);
      const byCode = new Map<string, (typeof registered)[number] | (typeof databaseItems)[number]>();
      for (const item of registered) byCode.set(item.code, item);
      for (const item of databaseItems) {
        const existing = byCode.get(item.code);
        byCode.set(item.code, existing ? { ...item, ...existing } : item);
      }
      for (const code of OFFICIAL_2304_PROCEDURE_CODES) {
        if (byCode.has(code)) continue;
        const registryItem = getOfficialLandProcedure(code, input?.province);
        byCode.set(code, {
          code,
          name: registryItem?.name || `Mã TTHC ${code} — cần đối soát tên thủ tục`,
          aliases: registryItem?.aliases || [code],
          groupName: registryItem?.groupName || "Danh mục 2304/QĐ-BNNMT — Pending đối soát",
          sourceName: registryItem?.sourceName || "Bộ Nông nghiệp và Môi trường / Cục Quản lý đất đai",
          sourceType: (registryItem?.sourceType || "government") as "government" | "public_service",
          sourceUrl: registryItem?.sourceUrl || OFFICIAL_2304_SOURCE_URL,
          baseUrl: registryItem?.baseUrl || "https://mae.gov.vn",
          checkedAt: registryItem?.checkedAt || "2026-08-21",
          authority: registryItem?.authority || "Cơ quan thực hiện theo phụ lục và địa phương",
          province: null,
          verifiedBinaryAvailable: false,
          referenceTemplates: [],
          notes: OFFICIAL_2304_CODE_INDEX_NOTICE,
        });
      }
      const items = Array.from(byCode.values()).map(item => {
        const canonicalName = getOfficialLandProcedure(item.code)?.name || getVerified2304ProcedureName(item.code);
        return canonicalName ? { ...item, name: canonicalName } : item;
      });
      return { checkedAt: officialRegistryCheckedAt, items, catalogCount: items.length, registryCount: registered.length, databaseCount: databaseItems.length, indexed2304Count: OFFICIAL_2304_PROCEDURE_CODES.length, notice: "Danh mục hợp nhất registry, CSDL và chỉ mục mã 2304 đã xác nhận. Các mã chỉ có trong chỉ mục vẫn Pending cho tới khi đối soát tên, quy trình, thành phần và binary SHA-256; không tự tạo mã từ tên file." };
    }),
    queueCodeMatching: protectedProcedure.input(z.object({ documents: z.array(z.object({ name: z.string().trim().min(1).max(500), sourceUrl: z.string().url().optional(), checksum: z.string().trim().max(128).optional() })).max(500) })).mutation(({ input }) => {
      return input.documents.map(document => {
        const searchText = `${document.name} ${document.sourceUrl || ""}`;
        const candidates = searchOfficialLandProcedures(searchText).slice(0, 5).map(item => ({ code: item.code, name: item.name, groupName: item.groupName, sourceUrl: item.sourceUrl }));
        return { ...document, status: candidates.length ? "queued" as const : "unmatched" as const, candidates, notice: candidates.length ? "Đã xếp hàng chờ quản trị viên xác nhận mã TTHC; chưa tự gắn thủ tục." : "Chưa tìm thấy mã phù hợp trong registry; cần bổ sung nguồn chính thức." };
      });
    }),
    discover: protectedProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional() })).mutation(async ({ input }) => {
      const workflow = await runProcedureWorkflow(input.procedureCode, input.province);
      return { ...workflow.scan, alternateCandidates: workflow.fallback.candidates, bundle: workflow.bundle, plan: buildPlanFromWorkflow(input, workflow), module: "ai-auto-dossier" as const, discoveredAt: new Date().toISOString(), notice: "Đã chạy workflow thống nhất theo mã: đọc thành phần, rà DVC → Chính phủ/Bộ → địa phương, tải và mapping; chỉ binary có checksum và provenance chính thức mới được xem xét Official." };
    }),
    inspectReferenceCandidates: protectedProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), candidateUrls: z.array(z.string().url()).min(1).max(20) })).mutation(async ({ input }) => {
      const procedure = getOfficialLandProcedure(input.procedureCode);
      if (!procedure) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy mã thủ tục trong registry." });
      const snapshot = await scanDvcProcedureSource({ procedureCode: input.procedureCode });
      const results = [] as Array<{ url: string; status: "reference_only" | "failed"; fileUrl?: string; storageKey?: string; checksum?: string; fileName?: string; signatureOk?: boolean; componentId?: string; error?: string }>;
      for (const candidateUrl of Array.from(new Set(input.candidateUrls))) {
        try {
          const downloaded = await downloadPublicReferenceCandidate({ candidateUrl });
          if (!downloaded.signatureOk) throw new Error("Chữ ký file không khớp DOC/DOCX/PDF.");
          const stored = await storagePut(`dvc-reference/${input.procedureCode}/${downloaded.checksum}-${downloaded.fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`, downloaded.bytes, downloaded.contentType || "application/octet-stream");
          results.push({ url: downloaded.sourceUrl, status: "reference_only", fileUrl: stored.url, storageKey: stored.key, checksum: downloaded.checksum, fileName: downloaded.fileName, signatureOk: downloaded.signatureOk, componentId: inferAlternateComponentId(downloaded.fileName, snapshot.dossierComponents) });
        } catch (error) {
          results.push({ url: candidateUrl, status: "failed", error: error instanceof Error ? error.message : "Không xác định" });
        }
      }
      const mergedScan = mergeDvcReferenceBinaries(snapshot, results.filter(item => item.status === "reference_only" && item.signatureOk && item.componentId).map(item => ({ name: item.fileName || "reference-template", url: item.url, kind: /\.pdf$/i.test(item.fileName || "") ? "pdf" as const : "docx" as const, sourceUrl: item.url, checksum: item.checksum, storageKey: item.storageKey, fileUrl: item.fileUrl, matchedKeywords: item.componentId ? [item.componentId] : [] })));
      return { procedureCode: input.procedureCode, results, bundle: assembleDvcProcedureBundle(mergedScan, input.procedureCode), officialEligible: false as const, notice: "Các file từ Google/web đã được ghép nếu khớp mẫu dưới trạng thái ready_reference; chúng vẫn không phải Official Template khi chưa có provenance cơ quan nhà nước." };
    }),
    uploadReferenceFile: protectedProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), fileName: z.string().trim().min(1).max(180), mimeType: z.string().trim().max(160).optional(), base64: z.string().min(1).max(18_000_000) })).mutation(async ({ input }) => {
      const procedure = getOfficialLandProcedure(input.procedureCode);
      if (!procedure) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy mã thủ tục trong registry." });
      const raw = input.base64.replace(/^data:[^;]+;base64,/, "");
      const bytes = Buffer.from(raw, "base64");
      if (!bytes.length || bytes.length > 12 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "File rỗng hoặc vượt giới hạn 12 MB." });
      const signatureOk = /^PK/.test(bytes.subarray(0, 4).toString("latin1")) || bytes.subarray(0, 4).toString("latin1") === "%PDF" || bytes.subarray(0, 8).toString("latin1") === "\u00d0\u00cf\u0011\u00e0\u00a1\u00b1\u001a\u00e1";
      if (!signatureOk) throw new TRPCError({ code: "BAD_REQUEST", message: "File không có chữ ký DOC/DOCX/PDF hợp lệ." });
      const crypto = await import("node:crypto");
      const checksum = crypto.createHash("sha256").update(bytes).digest("hex");
      const snapshot = await scanDvcProcedureSource({ procedureCode: input.procedureCode });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
      const stored = await storagePut(`dvc-user-reference/${input.procedureCode}/${checksum}-${safeName}`, bytes, input.mimeType || "application/octet-stream");
      const componentId = inferAlternateComponentId(input.fileName, snapshot.dossierComponents);
      const mergedScan = mergeDvcReferenceBinaries(snapshot, componentId ? [{ name: input.fileName, url: stored.url, kind: /\.pdf$/i.test(input.fileName) ? "pdf" as const : "docx" as const, sourceUrl: "user-upload", checksum, storageKey: stored.key, fileUrl: stored.url, matchedKeywords: [componentId] }] : []);
      return { procedureCode: input.procedureCode, fileName: input.fileName, fileUrl: stored.url, storageKey: stored.key, checksum, bytes: bytes.length, signatureOk, componentId, bundle: assembleDvcProcedureBundle(mergedScan, input.procedureCode), status: "reference_only" as const, officialEligible: false as const, notice: "File người dùng cung cấp đã được ghép nếu khớp component dưới trạng thái ready_reference; chưa phải Official Template." };
    }),
    confirmReference: protectedProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), attachmentId: z.string().trim().min(1).max(180) })).mutation(async ({ input }) => {
      const procedure = getOfficialLandProcedure(input.procedureCode);
      if (!procedure) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy mã thủ tục trong registry." });
      const snapshot = await scanDvcProcedureSource({ procedureCode: input.procedureCode });
      const confirmed = confirmReferenceForPersonalUse(snapshot, input.attachmentId);
      return { procedureCode: input.procedureCode, bundle: assembleDvcProcedureBundle(confirmed, input.procedureCode), officialEligible: false as const, notice: "File đã được xác nhận để sử dụng cá nhân và vẫn nằm trong khu Mẫu tham khảo; không chuyển sang Official Nhà nước." };
    }),
    syncProcedure: adminProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional() })).mutation(async ({ input }) => {
      const workflow = await runProcedureWorkflow(input.procedureCode, input.province);
      const bundle = workflow.bundle;
      const files = bundle.allAttachments.map(file => {
        const discovered = true;
        const downloaded = file.status !== "pending" && file.status !== "failed";
        const checksum = Boolean(file.checksum) || file.status === "verified_binary";
        const stored = Boolean(file.storageKey || file.fileUrl);
        const mapped = Boolean(file.componentId);
        const failed = file.status === "failed" || Boolean(file.verificationError);
        const stages = [
          { key: "discovery", label: "Phát hiện", status: discovered ? "completed" : "pending" },
          { key: "components", label: "Thành phần", status: bundle.totalCount > 0 ? "completed" : "pending" },
          { key: "candidate", label: "Chọn mẫu", status: file.sourceUrl ? "completed" : "pending" },
          { key: "download", label: "Tải xuống", status: failed ? "failed" : downloaded ? "completed" : "pending" },
          { key: "checksum", label: "Checksum", status: failed ? "failed" : checksum ? "completed" : "pending" },
          { key: "storage", label: "Lưu kho", status: failed ? "failed" : stored ? "completed" : "pending" },
          { key: "mapping", label: "Gắn thủ tục", status: failed ? "failed" : mapped ? "completed" : "pending" },
        ] as const;
        const completed = stages.filter(stage => stage.status === "completed").length;
        return { id: file.id, name: file.name, componentId: file.componentId, sourceUrl: file.sourceUrl || file.url, classification: file.status === "verified_binary" ? "Official" as const : "Reference/Pending" as const, status: failed ? "failed" as const : completed === stages.length ? "completed" as const : "pending" as const, percent: Math.round((completed / stages.length) * 100), stages, error: file.verificationError };
      });
      return { procedureCode: input.procedureCode, checkedAt: new Date().toISOString(), files, summary: { files: files.length, completed: files.filter(file => file.status === "completed").length, failed: files.filter(file => file.status === "failed").length, official: files.filter(file => file.classification === "Official").length, referenceOrPending: files.filter(file => file.classification === "Reference/Pending").length }, notice: "Đã rà soát từng file; Official chỉ giữ cho binary đã xác minh, các file còn lại hiển thị Reference/Pending." };
    }),
    batchDiscover: protectedProcedure.input(z.object({ procedureCodes: z.array(z.string().trim().min(2).max(80)).max(2000).optional(), province: z.string().trim().max(120).optional() }).optional()).mutation(async ({ input }) => {
      const registeredCodes = listOfficialLandProcedures().map(item => item.code);
      const procedureCodes = Array.from(new Set(input?.procedureCodes?.length ? input.procedureCodes : registeredCodes));
      const results = await mapWithConcurrency(procedureCodes, 3, async procedureCode => {
        try {
          const workflow = await runProcedureWorkflow(procedureCode, input?.province);
          const { scan, fallback, bundle } = workflow;
          const officialCount = bundle.allAttachments.filter(item => item.status === "verified_binary").length;
          const referenceCount = bundle.allAttachments.filter(item => item.status === "matched_reference").length;
          const pendingCount = bundle.allAttachments.filter(item => item.status === "pending" || item.status === "failed").length;
          return { procedureCode, scan, alternateCandidates: fallback.candidates, bundle, syncStatus: { officialCount, referenceCount, pendingCount, componentCount: bundle.totalCount } };
        } catch (error) {
          const message = error instanceof Error ? error.message : "Không đồng bộ được thủ tục.";
          return { procedureCode, scan: undefined, alternateCandidates: [], bundle: { procedureCode, sourceUrl: "", checkedAt: new Date().toISOString(), components: [], allAttachments: [], missingComponents: [], readyCount: 0, totalCount: 0 }, syncStatus: { officialCount: 0, referenceCount: 0, pendingCount: 0, componentCount: 0 }, error: message };
        }
      });
      const summary = results.reduce((acc, item) => ({
        procedures: acc.procedures + 1,
        officialFiles: acc.officialFiles + item.syncStatus.officialCount,
        referenceFiles: acc.referenceFiles + item.syncStatus.referenceCount,
        pendingFiles: acc.pendingFiles + item.syncStatus.pendingCount,
        readyComponents: acc.readyComponents + item.bundle.readyCount,
        totalComponents: acc.totalComponents + item.bundle.totalCount,
        failedProcedures: acc.failedProcedures + (item.error ? 1 : 0),
      }), { procedures: 0, officialFiles: 0, referenceFiles: 0, pendingFiles: 0, readyComponents: 0, totalComponents: 0, failedProcedures: 0 });
      return { checkedAt: new Date().toISOString(), procedureCodes, results, summary, notice: "Đã quét và ghép theo từng mã thủ tục trong catalog với tối đa 3 luồng. Một nguồn lỗi không làm dừng các thủ tục còn lại; Official chỉ dành cho binary đã tải và xác minh, Reference/Pending được giữ riêng." };
    }),
    batchSyncAll: adminProcedure.input(z.object({ procedureCodes: z.array(z.string().trim().min(2).max(80)).max(2000).optional(), province: z.string().trim().max(120).optional() }).optional()).mutation(async ({ input }) => {
      const registered = listOfficialLandProcedures();
      const dbProcedures = await listLegalProcedures();
      const catalogCodes = mergeLegalProcedureCatalog(
        dbProcedures,
        registered.map((item, index) => ({ id: -(index + 1), code: item.code, name: item.name, groupName: item.groupName ?? null })),
      ).map(item => item.code);
      const procedureCodes = Array.from(new Set((input?.procedureCodes?.length ? input.procedureCodes : catalogCodes).map(code => getOfficialLandProcedure(code)?.code ?? code)));
      const sources = (await listLegalSources()).filter(source => source.active === 1);
      const source = sources.find(item => item.sourceType === "public_service") ?? sources.find(item => item.sourceType === "government") ?? sources[0];
      if (!source) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Chưa có nguồn pháp lý hoạt động để lưu Official." });
      await Promise.all(procedureCodes.map(code => ensureLegalProcedureFromRegistry(code)));
      const refreshedDbProcedures = await listLegalProcedures();
      const results = await mapWithConcurrency(procedureCodes, 3, async procedureCode => {
        const procedure = registered.find(item => item.code === procedureCode);
        const dbProcedure = refreshedDbProcedures.find(item => item.code === procedureCode);
        await materializeRegistryOfficialTemplates(procedureCode);
        let recoverySnapshot: Awaited<ReturnType<typeof scanDvcProcedureSource>> | undefined;
        let recoveryBundle: ReturnType<typeof assembleDvcProcedureBundle> | undefined;
        try {
          const files = [] as Array<{ name: string; status: "official" | "reference" | "pending"; classification: "Official" | "Reference" | "Pending"; checksum?: string; sourceUrl: string; storageUrl?: string; componentId?: string; stages: Array<{ key: string; label: string; status: "completed" | "pending" | "failed" }>; error?: string }>;
        const snapshot = await scanDvcProcedureSource({ procedureCode, province: input?.province });
        recoverySnapshot = snapshot;
        const enriched = await enrichDvcSnapshot(procedureCode, snapshot, input?.province);
        recoverySnapshot = enriched.snapshot;
        const bundle = assembleDvcProcedureBundle(enriched.snapshot, procedureCode);
        recoveryBundle = bundle;
        const discovered = enriched.fallback.attachments.filter(file => file.status === "verified_binary").map(file => ({ name: file.name, sourceUrl: file.sourceUrl, checksum: file.checksum, storageKey: file.storageKey, fileUrl: file.fileUrl, componentId: file.componentId, format: file.kind === "pdf" ? "pdf" as const : "docx" as const, documentType: "official_template", notes: file.evidence }));
        const allowlisted = procedure && "verifiedTemplates" in procedure ? (procedure.verifiedTemplates ?? []).map(file => ({ name: file.name, sourceUrl: file.sourceUrl, checksum: file.checksum, format: file.format, documentType: file.documentType, notes: file.notes })) : [];
        const candidates = [...allowlisted, ...discovered].filter((item, index, all) => all.findIndex(other => other.sourceUrl === item.sourceUrl || (item.checksum && other.checksum === item.checksum)) === index);
        const inferCandidateComponent = (fileName: string) => {
          const normalizedFile = fileName.toLocaleLowerCase("vi").normalize("NFKD").replace(/[\\u0300-\\u036f]/g, "").replace(/[^a-z0-9]+/gi, " ").trim();
          const tokens = normalizedFile.split(/\\s+/).filter(token => token.length > 2);
          return bundle.components.find(component => {
            const normalizedComponent = component.name.toLocaleLowerCase("vi").normalize("NFKD").replace(/[\\u0300-\\u036f]/g, "").replace(/[^a-z0-9]+/gi, " ").trim();
            return normalizedComponent.includes(normalizedFile) || normalizedFile.includes(normalizedComponent) || tokens.filter(token => token.length > 4).filter(token => normalizedComponent.includes(token)).length >= 2;
          });
        };
        for (const candidate of candidates) {
          try {
            const downloaded = await downloadOfficialTemplateCandidate({ candidateUrl: candidate.sourceUrl, originalFileName: candidate.name });
            if (!downloaded.checksum || (candidate.checksum && downloaded.checksum !== candidate.checksum)) throw new Error("Checksum binary không khớp hoặc chưa có allowlist xác minh.");
            const stored = await storagePut(`legal-official/${procedureCode}/${downloaded.checksum}_${downloaded.fileName}`, downloaded.bytes, downloaded.contentType || undefined);
            const matchedComponent = ("componentId" in candidate && candidate.componentId ? bundle.components.find(component => component.id === candidate.componentId) : undefined) ?? inferCandidateComponent(candidate.name);
            const procedureId = dbProcedure?.id;
            const template = procedureId !== undefined ? await upsertOfficialLegalTemplate({ procedureId, sourceId: source.id, name: candidate.name, documentType: candidate.documentType, format: candidate.format, sourceUrl: candidate.sourceUrl, storageKey: stored.key, fileUrl: stored.url, checksum: downloaded.checksum, notes: candidate.notes }) : undefined;
            if (template && matchedComponent && procedureId !== undefined) {
              const requirementId = /^\d+$/.test(matchedComponent.id) ? Number(matchedComponent.id) : undefined;
              await upsertOfficialLegalTemplateMapping({ procedureId, requirementId, templateId: template.id, componentLabel: matchedComponent.name, confidence: 85 });
            }
            files.push({ name: candidate.name, status: "official", classification: "Official", checksum: downloaded.checksum, sourceUrl: candidate.sourceUrl, storageUrl: stored.url, componentId: matchedComponent?.id, stages: [{ key: "discovery", label: "Phát hiện", status: "completed" }, { key: "download", label: "Tải xuống", status: "completed" }, { key: "checksum", label: "Checksum", status: "completed" }, { key: "storage", label: "Lưu kho", status: "completed" }, { key: "mapping", label: "Gắn thủ tục", status: template && matchedComponent && procedureId ? "completed" : "pending" }] });
          } catch (error) {
            files.push({ name: candidate.name, status: "pending", classification: "Pending", sourceUrl: candidate.sourceUrl, stages: [{ key: "discovery", label: "Phát hiện", status: "completed" }, { key: "download", label: "Tải xuống", status: "failed" }, { key: "checksum", label: "Checksum", status: "pending" }, { key: "storage", label: "Lưu kho", status: "pending" }, { key: "mapping", label: "Gắn thủ tục", status: "pending" }], error: error instanceof Error ? error.message : "Không tải được file Official." });
          }
        }
        const knownSources = new Set(files.map(file => file.sourceUrl));
        const inferComponentId = (attachment: typeof bundle.allAttachments[number]) => {
          if (attachment.componentId) return attachment.componentId;
          const haystack = `${attachment.name} ${attachment.evidence}`.toLocaleLowerCase("vi");
          return bundle.components.find(component => {
            const name = component.name.toLocaleLowerCase("vi");
            return haystack.includes(name) || name.split(/\s+/).some(token => token.length > 4 && haystack.includes(token));
          })?.id;
        };
        for (const attachment of bundle.allAttachments) {
          const sourceUrl = attachment.sourceUrl || attachment.url || procedure?.sourceUrl || "";
          const componentId = inferComponentId(attachment);
          if (knownSources.has(sourceUrl) && attachment.status === "verified_binary") continue;
          const isOfficial = attachment.status === "verified_binary" && Boolean(attachment.checksum) && Boolean(attachment.storageKey || attachment.fileUrl);
          const isReference = attachment.status === "matched_reference" || attachment.status === "confirmed_reference" || attachment.status === "awaiting_manual_review";
          const isFailed = attachment.status === "failed";
          files.push({
            name: attachment.name,
            status: isOfficial ? "official" : isFailed ? "pending" : isReference ? "reference" : "pending",
            classification: isOfficial ? "Official" : isFailed ? "Pending" : isReference ? "Reference" : "Pending",
            checksum: attachment.checksum,
            sourceUrl,
            storageUrl: attachment.fileUrl,
            componentId,
            stages: [
              { key: "discovery", label: "Phát hiện", status: "completed" },
              { key: "download", label: "Tải xuống", status: attachment.storageKey || attachment.fileUrl ? "completed" : isFailed ? "failed" : "pending" },
              { key: "checksum", label: "Checksum", status: attachment.checksum ? "completed" : isFailed ? "failed" : "pending" },
              { key: "storage", label: "Lưu kho", status: attachment.storageKey || attachment.fileUrl ? "completed" : "pending" },
              { key: "mapping", label: "Gắn thủ tục", status: componentId ? "completed" : "pending" },
            ],
            error: attachment.verificationError,
          });
        }
        if (!files.length) files.push({ name: "Chưa tìm thấy binary mẫu đã xác minh", status: "pending", classification: "Pending", sourceUrl: procedure?.baseUrl ?? "", stages: [{ key: "discovery", label: "Phát hiện", status: "completed" }, { key: "download", label: "Tải xuống", status: "pending" }, { key: "checksum", label: "Checksum", status: "pending" }, { key: "storage", label: "Lưu kho", status: "pending" }, { key: "mapping", label: "Gắn thủ tục", status: "pending" }], error: "Không phát hiện DOCX/PDF đủ điều kiện từ các nguồn đã quét." });
        const official = files.filter(file => file.status === "official").length;
        const reference = files.filter(file => file.status === "reference").length;
        const pending = files.filter(file => file.status === "pending").length;
          return { procedureCode, files, bundle, syncStatus: { officialCount: official, referenceCount: reference, pendingCount: pending, componentCount: bundle.totalCount }, official, reference, pending };
        } catch (error) {
          const message = error instanceof Error ? error.message : "Không đồng bộ được thủ tục.";
          const preservedBundle = recoveryBundle || (recoverySnapshot ? assembleDvcProcedureBundle(recoverySnapshot, procedureCode) : undefined);
          const preservedFiles = preservedBundle?.allAttachments.map(attachment => {
            const isOfficial = attachment.status === "verified_binary" && Boolean(attachment.checksum) && Boolean(attachment.storageKey || attachment.fileUrl);
            const isReference = attachment.status === "matched_reference" || attachment.status === "confirmed_reference" || attachment.status === "awaiting_manual_review";
            return { name: attachment.name, status: isOfficial ? "official" as const : isReference ? "reference" as const : "pending" as const, classification: isOfficial ? "Official" as const : isReference ? "Reference" as const : "Pending" as const, checksum: attachment.checksum, sourceUrl: attachment.sourceUrl || attachment.url, storageUrl: attachment.fileUrl, componentId: attachment.componentId, stages: [{ key: "discovery", label: "Phát hiện", status: "completed" as const }, { key: "download", label: "Tải xuống", status: attachment.storageKey || attachment.fileUrl ? "completed" as const : "pending" as const }, { key: "checksum", label: "Checksum", status: attachment.checksum ? "completed" as const : "pending" as const }, { key: "storage", label: "Lưu kho", status: attachment.storageKey || attachment.fileUrl ? "completed" as const : "pending" as const }, { key: "mapping", label: "Gắn thủ tục", status: attachment.componentId ? "completed" as const : "pending" as const }], error: attachment.verificationError };
          }) || [];
          const files = preservedFiles.length ? preservedFiles : [{ name: "Chưa tìm thấy binary mẫu đã xác minh", status: "pending" as const, classification: "Pending" as const, sourceUrl: recoverySnapshot?.sourceUrl || procedure?.baseUrl || "", stages: [{ key: "discovery", label: "Phát hiện", status: recoverySnapshot ? "completed" as const : "failed" as const }, { key: "download", label: "Tải xuống", status: "pending" as const }, { key: "checksum", label: "Checksum", status: "pending" as const }, { key: "storage", label: "Lưu kho", status: "pending" as const }, { key: "mapping", label: "Gắn thủ tục", status: "pending" as const }], error: message }];
          const official = files.filter(file => file.status === "official").length;
          const reference = files.filter(file => file.status === "reference").length;
          const pending = files.filter(file => file.status === "pending").length;
          const recoveredComponentCount = preservedBundle?.totalCount || recoverySnapshot?.dossierComponents.length || 0;
          const hasRecoveredData = recoveredComponentCount > 0 || files.some(file => file.status !== "pending");
          return {
            procedureCode,
            files,
            bundle: preservedBundle || { procedureCode, sourceUrl: recoverySnapshot?.sourceUrl || procedure?.baseUrl || "", checkedAt: new Date().toISOString(), components: recoverySnapshot?.dossierComponents.map(component => ({ ...component, status: "missing" as const, attachments: [] })) || [], allAttachments: recoverySnapshot?.attachments || [], missingComponents: recoverySnapshot?.dossierComponents.map(component => component.name) || [], readyCount: 0, totalCount: recoveredComponentCount },
            syncStatus: { officialCount: official, referenceCount: reference, pendingCount: pending, componentCount: recoveredComponentCount },
            official,
            reference,
            pending,
            ...(hasRecoveredData ? { warning: message } : { error: message }),
          };
        }
      });
      return { checkedAt: new Date().toISOString(), procedureCodes, results, summary: { procedures: results.length, officialFiles: results.reduce((sum, item) => sum + item.official, 0), referenceFiles: results.reduce((sum, item) => sum + item.reference, 0), pendingFiles: results.reduce((sum, item) => sum + item.pending, 0), failedProcedures: results.filter(item => "error" in item && Boolean(item.error)).length }, notice: "Đã discovery nguồn chính thức, tải và lưu các binary có checksum khớp; Reference giữ riêng để dùng tham khảo; file lỗi hoặc chưa đủ chứng cứ vẫn giữ Pending." };
    }),
    buildPlan: protectedProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional() })).mutation(async ({ input }) => {
      const workflow = await runProcedureWorkflow(input.procedureCode, input.province);
      return buildPlanFromWorkflow(input, workflow);
    }),
    analyzeDossier: protectedProcedure.input(z.object({
      procedureCode: z.string().trim().min(2).max(80),
      province: z.string().trim().max(120).optional(),
      profile: z.record(z.string().trim().max(80), z.string().max(2000)).default({}),
      ocrFields: z.array(z.object({ key: z.string().max(100).optional(), label: z.string().max(180), value: z.string().max(2000), evidence: z.string().max(1000).optional(), confidence: z.number().min(0).max(1).optional() })).max(60).default([]),
      dossierComponents: z.array(dossierComponentForAnalysisSchema).max(80).default([]),
      uploadedDocuments: z.array(z.object({
        fileName: z.string().max(240),
        mimeType: z.string().max(120),
        componentId: z.string().max(120).optional(),
        componentName: z.string().max(240).optional(),
        extractedFields: z.array(z.object({ label: z.string().max(180), value: z.string().max(2000), evidence: z.string().max(1000).optional() })).max(80).default([]),
      })).max(80).default([]),
    })).mutation(async ({ input }) => {
      const bundle = await getLegalProcedureBundle(input.procedureCode);
      const verifiedTemplates = (bundle?.templates || []).filter(item => (item.provenance === "verified_binary" || item.provenance === "official") && Boolean(item.storageKey || item.fileUrl) && Boolean(item.checksum));
      const sourceContext = {
        procedureCode: input.procedureCode,
        province: input.province || "Toàn quốc",
        procedure: bundle?.procedure ? { name: bundle.procedure.name, groupName: bundle.procedure.groupName, authority: bundle.procedure.authority, processingTime: bundle.procedure.processingTime, feeNotes: bundle.procedure.feeNotes, conditions: bundle.procedure.conditions, workflow: bundle.procedure.workflow, sourceDocumentIds: bundle.procedure.sourceDocumentIds } : null,
        requirements: (bundle?.requirements || []).map(item => ({ id: item.id, label: item.label, requirementType: item.requirementType, required: Boolean(item.required), fieldKey: item.fieldKey, sourceDocumentId: item.sourceDocumentId, notes: item.notes })),
        components: input.dossierComponents.length ? input.dossierComponents : (bundle?.requirements || []).map(item => ({ id: item.id, name: item.label, required: Boolean(item.required), evidence: item.notes || "" })),
        legalSources: (bundle?.sources || []).map(item => ({ id: item.id, name: item.name, baseUrl: item.baseUrl, sourceType: item.sourceType, jurisdiction: item.jurisdiction, notes: item.notes })),
        legalDocuments: (bundle?.documents || []).map(item => ({ id: item.id, title: item.title, documentNumber: item.documentNumber, documentType: item.documentType, issuingBody: item.issuingBody, sourceUrl: item.sourceUrl, fileUrl: item.fileUrl, status: item.status, contentHash: item.contentHash, checkedAt: item.checkedAt, contentText: item.contentText?.slice(0, 30000), warnings: item.warnings })),
        templates: (bundle?.templates || []).map(item => ({ id: item.id, name: item.name, documentType: item.documentType, format: item.format, sourceUrl: item.sourceUrl, fileUrl: item.fileUrl, province: item.province, receivingAuthority: item.receivingAuthority, jurisdictionScope: item.jurisdictionScope, provenance: item.provenance, checksum: item.checksum, versionLabel: item.versionLabel, notes: item.notes })),
        officialTemplates: verifiedTemplates.map(item => ({ name: item.name, format: item.format, sourceUrl: item.sourceUrl, checksum: item.checksum })),
        sourceCounts: { sources: bundle?.sources?.length || 0, documents: bundle?.documents?.length || 0, templates: bundle?.templates?.length || 0, verifiedTemplates: verifiedTemplates.length },
        userProfile: input.profile,
        ocrEvidence: input.ocrFields,
        uploadedDocuments: input.uploadedDocuments.map(document => ({
          fileName: document.fileName,
          mimeType: document.mimeType,
          componentId: document.componentId,
          componentName: document.componentName,
          extractedFields: document.extractedFields,
        })),
      };
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là trợ lý phân tích hồ sơ đất đai Việt Nam. Hãy đọc toàn bộ profile, toàn bộ trường OCR và toàn bộ giấy tờ đã tải lên (CCCD, hộ chiếu, giấy tờ nhà đất và tài liệu liên quan) để trích xuất dữ liệu có bằng chứng và lập bản điền nháp theo thủ tục. Không bỏ qua tài liệu nào đã được cung cấp. Không suy đoán, không kết luận hồ sơ hợp lệ, không thay thế cơ quan nhà nước. Mọi trường đề xuất phải có source là profile, ocr hoặc missing và needsConfirmation=true. Các căn cứ pháp lý chỉ dùng để xác định yêu cầu hồ sơ, không được biến thành dữ liệu cá nhân. Trả JSON tiếng Việt." },
          { role: "user", content: `Phân tích hồ sơ theo dữ liệu sau và lập bảng trường cần người dùng kiểm tra trước khi điền mẫu:\n${JSON.stringify(sourceContext).slice(0, 180000)}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "land_dossier_analysis", strict: true, schema: { type: "object", additionalProperties: false, properties: { fields: { type: "array", maxItems: 80, items: { type: "object", additionalProperties: false, properties: { key: { type: "string" }, label: { type: "string" }, value: { type: "string" }, source: { type: "string", enum: ["profile", "ocr", "missing"] }, evidence: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 1 }, needsConfirmation: { type: "boolean" }, required: { type: "boolean" } }, required: ["key", "label", "value", "source", "evidence", "confidence", "needsConfirmation", "required"] } }, warnings: { type: "array", maxItems: 20, items: { type: "string" } }, missingComponents: { type: "array", maxItems: 40, items: { type: "string" } }, legalNotes: { type: "array", maxItems: 20, items: { type: "string" } } }, required: ["fields", "warnings", "missingComponents", "legalNotes"] } } },
        maxTokens: 5000,
      });
      const content = response.choices?.[0]?.message?.content;
      try {
        const analysis = JSON.parse(typeof content === "string" ? content : JSON.stringify(content || "{}"));
        return { ...analysis, procedureCode: input.procedureCode, province: input.province || "Toàn quốc", analyzedAt: new Date().toISOString(), verifiedTemplateCount: verifiedTemplates.length, officialExportEligible: verifiedTemplates.length > 0, notice: "Kết quả AI chỉ là bản điền nháp có bằng chứng. Người dùng phải xác nhận từng trường và đối chiếu giấy tờ gốc trước khi xuất." };
      } catch {
        throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa trả về kết quả phân tích có cấu trúc. Vui lòng thử lại." });
      }
    }),
  }),
  consultations: router({
    create: publicProcedure.input(z.object({ interest: z.string().trim().min(1).max(255), name: z.string().trim().min(2).max(120), phone: z.preprocess(value => typeof value === "string" ? value.replace(/[\s().-]/g, "") : value, z.string().regex(/^(?:\+84|0)(?:3|5|7|8|9)\d{8}$/, "Số điện thoại Việt Nam không hợp lệ")).transform(value => value.replace(/^\+84/, "0")), message: z.string().trim().max(2000).optional(), conversationHistory: z.string().max(12000).optional(), propertyIds: z.array(z.number().int().positive()).max(10).optional() })).mutation(async ({ input }) => { const created = await createConsultationRequest({ interest: input.interest, name: input.name, phone: input.phone, message: input.message || null }); await notifyOwner({ title: "🔔 Yêu cầu tư vấn mới", content: `${input.name} vừa gửi yêu cầu “${input.interest}”.
Số điện thoại: ${input.phone}
${input.message ? `Nội dung: ${input.message}` : "Chưa có lời nhắn chi tiết."}
Mở mục Yêu cầu tư vấn để tiếp nhận.` }); await analyzeConsultationRequest(created.id, { name: input.name, interest: input.interest, message: input.message || null, conversationHistory: input.conversationHistory || null, propertyIds: input.propertyIds || [] }); return created; }),
    list: adminProcedure.query(() => listConsultationRequests()),
    updateStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["new", "contacted", "closed"]) })).mutation(({ input }) => updateConsultationStatus(input.id, input.status)),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const result = await deleteConsultationRequest(input.id); if (!result.success) throw new TRPCError({ code: result.reason === "not_found" ? "NOT_FOUND" : "BAD_REQUEST", message: result.reason === "not_handled" ? "Chỉ được xóa yêu cầu đã xem hoặc đã liên hệ." : "Không tìm thấy yêu cầu tư vấn." }); return result; }),
  }),
  marketing: router({
    campaigns: router({
      list: adminProcedure.query(() => listMarketingCampaigns()),
      create: adminProcedure.input(marketingCampaignInput).mutation(async ({ input, ctx }) => {
        if (input.propertyId) {
          const property = await getPublishedPropertyById(input.propertyId);
          if (!property) throw new TRPCError({ code: "BAD_REQUEST", message: "Chiến dịch chỉ được liên kết với BĐS đang published." });
        }
        return createMarketingCampaign({ name: input.name, objective: input.objective, propertyId: input.propertyId ?? null, audience: input.audience ?? null, channelsJson: JSON.stringify(input.channels ?? []), budget: input.budget ?? null, startsAt: input.startsAt ?? null, endsAt: input.endsAt ?? null, status: input.status ?? "draft", createdBy: ctx.user.id });
      }),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: marketingCampaignInput.partial() })).mutation(async ({ input }) => {
        if (input.data.propertyId) {
          const property = await getPublishedPropertyById(input.data.propertyId);
          if (!property) throw new TRPCError({ code: "BAD_REQUEST", message: "BĐS liên kết phải đang published." });
        }
        return updateMarketingCampaign(input.id, { name: input.data.name, objective: input.data.objective, propertyId: input.data.propertyId, audience: input.data.audience, channelsJson: input.data.channels ? JSON.stringify(input.data.channels) : undefined, budget: input.data.budget, startsAt: input.data.startsAt, endsAt: input.data.endsAt, status: input.data.status });
      }),
    }),
    channels: router({
      list: adminProcedure.query(() => listMarketingChannels()),
      create: adminProcedure.input(z.object({ name: z.string().trim().min(2).max(120), channelType: marketingChannelType, handle: z.string().trim().max(255).nullable().optional(), active: z.boolean().optional() })).mutation(({ input, ctx }) => createMarketingChannel({ name: input.name, channelType: input.channelType, handle: input.handle ?? null, active: input.active === false ? 0 : 1, createdBy: ctx.user.id })),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: z.object({ name: z.string().trim().min(2).max(120).optional(), channelType: marketingChannelType.optional(), handle: z.string().trim().max(255).nullable().optional(), active: z.boolean().optional() }) })).mutation(({ input }) => updateMarketingChannel(input.id, { ...input.data, active: input.data.active === undefined ? undefined : input.data.active ? 1 : 0 })),
    }),
    contents: router({
      list: adminProcedure.query(() => listMarketingContents()),
      create: adminProcedure.input(marketingContentInput).mutation(async ({ input, ctx }) => {
        if (input.campaignId && !(await getMarketingCampaign(input.campaignId))) throw new TRPCError({ code: "BAD_REQUEST", message: "Không tìm thấy chiến dịch liên kết." });
        if (input.propertyId && !(await getPublishedPropertyById(input.propertyId))) throw new TRPCError({ code: "BAD_REQUEST", message: "Nội dung chỉ được gắn với BĐS published." });
        return createMarketingContent({ campaignId: input.campaignId ?? null, propertyId: input.propertyId ?? null, channelType: input.channelType, contentType: input.contentType, title: input.title ?? null, body: input.body, status: input.status ?? "draft", scheduledAt: input.scheduledAt ?? null, aiGenerated: input.aiGenerated ? 1 : 0, createdBy: ctx.user.id });
      }),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: marketingContentInput.partial() })).mutation(({ input }) => updateMarketingContent(input.id, { ...input.data, aiGenerated: input.data.aiGenerated === undefined ? undefined : input.data.aiGenerated ? 1 : 0 })),
    }),
    calendar: router({
      list: adminProcedure.query(() => listMarketingCalendar()),
      create: adminProcedure.input(z.object({ contentId: z.number().int().positive(), campaignId: z.number().int().positive().nullable().optional(), propertyId: z.number().int().positive().nullable().optional(), channelType: marketingChannelType, scheduledAt: z.coerce.date(), status: marketingCalendarStatus.optional(), note: z.string().trim().max(2000).nullable().optional() })).mutation(async ({ input, ctx }) => {
        if (input.campaignId && !(await getMarketingCampaign(input.campaignId))) throw new TRPCError({ code: "BAD_REQUEST", message: "Không tìm thấy chiến dịch liên kết." });
        if (input.propertyId && !(await getPublishedPropertyById(input.propertyId))) throw new TRPCError({ code: "BAD_REQUEST", message: "BĐS lịch nội dung phải đang published." });
        return createMarketingCalendarItem({ contentId: input.contentId, campaignId: input.campaignId ?? null, propertyId: input.propertyId ?? null, channelType: input.channelType, scheduledAt: input.scheduledAt, status: input.status ?? "planned", note: input.note ?? null, createdBy: ctx.user.id });
      }),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: z.object({ scheduledAt: z.coerce.date().optional(), status: marketingCalendarStatus.optional(), note: z.string().trim().max(2000).nullable().optional() }) })).mutation(({ input }) => updateMarketingCalendarItem(input.id, input.data)),
    }),
    aiContent: router({
      generate: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), contentType: marketingContentType, channelType: marketingChannelType, audience: z.string().trim().max(255).optional() })).mutation(async ({ input, ctx }) => {
        const property = await getPublishedPropertyById(input.propertyId);
        if (!property) throw new TRPCError({ code: "BAD_REQUEST", message: "Chỉ tạo nội dung từ BĐS published." });
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "Bạn là biên tập viên Marketing bất động sản Việt Nam. Hãy tạo bản nháp ngắn gọn, có thể sử dụng sau khi môi giới duyệt. Chỉ dùng dữ liệu được cung cấp; không bịa tiện ích, pháp lý, quy hoạch, mức sinh lời hoặc thông tin không có. Với thông tin chưa có, không tự điền. Luôn ghi rõ đây là bản nháp cần kiểm tra." },
            { role: "user", content: `Loại nội dung: ${input.contentType}. Kênh: ${input.channelType}. Đối tượng: ${input.audience || "Chưa xác định"}. Dữ liệu BĐS: ${JSON.stringify({ title: property.title, propertyType: property.propertyType, listingType: property.listingType, price: property.price, area: property.area, buildArea: property.buildArea, location: property.location, orientation: property.orientation, roadWidth: property.roadWidth, bedrooms: property.bedrooms, bathrooms: property.bathrooms, legalStatus: property.legalStatus, description: property.description })}` },
          ],
          outputSchema: { name: "marketing_content_draft", strict: true, schema: { type: "object", additionalProperties: false, properties: { title: { type: "string" }, body: { type: "string" }, shortCaption: { type: "string" }, hashtags: { type: "array", items: { type: "string" }, maxItems: 12 }, warnings: { type: "array", items: { type: "string" }, maxItems: 8 }, requiresApproval: { type: "boolean" } }, required: ["title", "body", "shortCaption", "hashtags", "warnings", "requiresApproval"] } },
          maxTokens: 1400,
        });
        const raw = response.choices?.[0]?.message?.content;
        let draft: Record<string, unknown>;
        try { draft = JSON.parse(typeof raw === "string" ? raw : JSON.stringify(raw || "{}")) as Record<string, unknown>; } catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa tạo được bản nháp đúng cấu trúc." }); }
        const saved = await createMarketingContent({ propertyId: property.id, campaignId: null, channelType: input.channelType, contentType: input.contentType, title: typeof draft.title === "string" ? draft.title : property.title, body: typeof draft.body === "string" ? draft.body : "", status: "draft", aiGenerated: 1, createdBy: ctx.user.id });
        return { ...draft, contentId: saved?.id, propertyId: property.id, status: "draft" as const };
      }),
    }),
    captureLead: publicProcedure.input(z.object({ campaignId: z.number().int().positive(), propertyId: z.number().int().positive().nullable().optional(), channel: marketingChannelType.default("website"), interest: z.string().trim().min(2).max(255), name: z.string().trim().min(2).max(120), phone: z.preprocess(value => typeof value === "string" ? value.replace(/[\s().-]/g, "") : value, z.string().regex(/^(?:\+84|0)(?:3|5|7|8|9)\d{8}$/, "Số điện thoại Việt Nam không hợp lệ")).transform(value => value.replace(/^\+84/, "0")), message: z.string().trim().max(2000).optional() })).mutation(async ({ input }) => {
      const campaign = await getMarketingCampaign(input.campaignId);
      if (!campaign || campaign.status !== "active") throw new TRPCError({ code: "NOT_FOUND", message: "Chiến dịch không còn hoạt động." });
      const propertyId = input.propertyId ?? campaign.propertyId ?? undefined;
      if (campaign.propertyId && propertyId !== campaign.propertyId) throw new TRPCError({ code: "BAD_REQUEST", message: "BĐS không khớp với chiến dịch." });
      if (propertyId && !(await getPublishedPropertyById(propertyId))) throw new TRPCError({ code: "BAD_REQUEST", message: "BĐS trong chiến dịch không còn được công khai." });
      const recent = await findRecentMarketingConsultation({ phone: input.phone, marketingCampaignId: input.campaignId, marketingPropertyId: propertyId, since: new Date(Date.now() - 24 * 60 * 60 * 1000) });
      if (recent) return { id: recent.id, deduplicated: true as const };
      const created = await createConsultationRequest({ interest: input.interest, name: input.name, phone: input.phone, message: input.message || null, marketingCampaignId: input.campaignId, marketingChannel: input.channel, marketingPropertyId: propertyId ?? null });
      await notifyOwner({ title: "🔔 Khách quan tâm từ Marketing", content: `${input.name} vừa quan tâm chiến dịch “${campaign.name}” qua ${input.channel}.\nSố điện thoại: ${input.phone}\n${input.message || "Chưa có lời nhắn chi tiết."}\nMở mục Yêu cầu tư vấn để tiếp nhận.` });
      await analyzeConsultationRequest(created.id, { name: input.name, interest: input.interest, message: input.message || null, propertyIds: propertyId ? [propertyId] : [] });
      return { id: created.id, deduplicated: false as const };
    }),
  }),
  properties: router({
    areas: publicProcedure.query(() => listAreas()),
    geocode: publicProcedure.input(z.object({ address: z.string().trim().min(3).max(255) })).query(async ({ input }) => { const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&countrycodes=vn&accept-language=vi&q=${encodeURIComponent(input.address)}`; const response = await fetch(url, { headers: { "User-Agent": "BatDongSanXanh/1.0 contact@batdongsanxanh.vn" } }); if (!response.ok) throw new TRPCError({ code: "BAD_GATEWAY", message: "Không tìm được vị trí từ địa chỉ này." }); const data = await response.json() as Array<{ display_name: string; lat: string; lon: string }>; return data.map(item => ({ label: item.display_name, latitude: item.lat, longitude: item.lon })); }),
    uploadImage: protectedProcedure.input(z.object({ fileName: z.string().min(1).max(180), mimeType: z.string().regex(/^image\/(jpeg|png|webp|gif)$/), data: z.string().min(1).max(14_000_000) })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (bytes.byteLength > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Ảnh không được vượt quá 10MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploaded = await storagePut(`properties/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      return { url: uploaded.url, key: uploaded.key, mediaType: "image" as const };
    }),
    uploadMedia: adminProcedure.input(z.object({ fileName: z.string().min(1).max(180), mimeType: propertyMediaMime, data: z.string().min(1).max(70_000_000) })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      const maxBytes = input.mimeType.startsWith("video/") ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
      if (bytes.byteLength > maxBytes) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: input.mimeType.startsWith("video/") ? "Video không được vượt quá 50MB." : "Ảnh không được vượt quá 10MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploaded = await storagePut(`properties/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      return { url: uploaded.url, key: uploaded.key, mediaType: input.mimeType.startsWith("video/") ? "video" as const : "image" as const };
    }),
    uploadPropertyMediaAsset: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), assetType: z.enum(["video", "image", "360", "3d"]), fileName: z.string().trim().min(1).max(180), mimeType: z.string().trim().min(1).max(120), data: z.string().min(1).max(140_000_000) })).mutation(async ({ input, ctx }) => {
      const allowedMime = input.assetType === "3d" ? property3dMime : propertyMediaMime;
      if (!allowedMime.safeParse(input.mimeType).success) throw new TRPCError({ code: "BAD_REQUEST", message: "Định dạng media không phù hợp với loại tài sản đã chọn." });
      const bytes = Buffer.from(input.data, "base64");
      const maxBytes = input.assetType === "video" ? 50 * 1024 * 1024 : input.assetType === "3d" ? 100 * 1024 * 1024 : 15 * 1024 * 1024;
      if (bytes.byteLength > maxBytes) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: input.assetType === "video" ? "Video không được vượt quá 50MB." : input.assetType === "3d" ? "File 3D không được vượt quá 100MB." : "Ảnh/ảnh 360° không được vượt quá 15MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploaded = await storagePut(`property-media/${input.propertyId}/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      const saved = await createPropertyArchiveFile({ propertyId: input.propertyId, category: "marketing", documentType: `Media BĐS · ${input.assetType}`, fileName: input.fileName, mimeType: input.mimeType, url: uploaded.url, storageKey: uploaded.key, uploadedBy: ctx.user.id });
      return { ...saved, propertyId: input.propertyId, assetType: input.assetType, url: uploaded.url, storageKey: uploaded.key, status: "uploaded" as const };
    }),
    analyzePropertyMediaAsset: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), assetType: z.enum(["video", "image", "360"]), mediaUrl: z.string().url(), mimeType: z.enum(["video/mp4", "video/webm", "video/quicktime", "image/jpeg", "image/png", "image/webp", "image/gif"]), propertyContext: z.string().trim().max(4000).optional() })).mutation(async ({ input }) => {
      const content = input.assetType === "video" ? [{ type: "text" as const, text: `Phân tích video giới thiệu bất động sản này. Hãy chỉ mô tả những gì có thể quan sát, không tự suy đoán pháp lý, giá trị hay tiện ích không xuất hiện. ${input.propertyContext || ""}` }, { type: "file_url" as const, file_url: { url: input.mediaUrl, mime_type: input.mimeType as "video/mp4" } }] : [{ type: "text" as const, text: `Phân tích ảnh/ảnh 360° bất động sản này. Hãy chỉ mô tả những gì nhìn thấy, đánh dấu thông tin cần môi giới kiểm tra lại. ${input.propertyContext || ""}` }, { type: "image_url" as const, image_url: { url: input.mediaUrl, detail: "high" as const } }];
      const response = await invokeLLM({ messages: [{ role: "system", content: "Bạn là biên tập viên media bất động sản tại Việt Nam. Trả JSON theo schema. Không bịa tiện ích, diện tích, pháp lý, giá hoặc cảnh không có trong media. Kết quả là bản nháp để môi giới duyệt, không tự động công khai." }, { role: "user", content }], response_format: { type: "json_schema", json_schema: { name: "property_media_storyboard", strict: true, schema: { type: "object", additionalProperties: false, properties: { summary: { type: "string" }, scenes: { type: "array", maxItems: 8, items: { type: "object", additionalProperties: false, properties: { order: { type: "integer" }, durationSeconds: { type: "integer" }, visual: { type: "string" }, narration: { type: "string" }, onScreenText: { type: "string" } }, required: ["order", "durationSeconds", "visual", "narration", "onScreenText"] } }, narration: { type: "string" }, captions: { type: "array", items: { type: "string" }, maxItems: 12 }, warnings: { type: "array", items: { type: "string" }, maxItems: 12 }, requiresBrokerApproval: { type: "boolean" } }, required: ["summary", "scenes", "narration", "captions", "warnings", "requiresBrokerApproval"] } } }, maxTokens: 2600 });
      const raw = response.choices?.[0]?.message?.content;
      let storyboard: unknown = raw;
      if (typeof raw === "string") { try { storyboard = JSON.parse(raw); } catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI trả về nội dung không đúng cấu trúc. Vui lòng thử lại." }); } }
      return { propertyId: input.propertyId, assetType: input.assetType, mediaUrl: input.mediaUrl, storyboard, status: "needs_review" as const };
    }),
    analyzeListingDocument: protectedProcedure.input(z.object({ fileName: z.string().min(1).max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), data: z.string().min(1).max(14_000_000) })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (bytes.byteLength > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Ảnh/tệp không được vượt quá 10MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploaded = await storagePut(`listing-ocr/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      const response = await invokeLLM({
        messages: [{ role: "user", content: [
          { type: "text", text: "Bạn là trợ lý nhập liệu đăng bán bất động sản tại Việt Nam. Hãy đọc ảnh giấy tờ hoặc thông tin bất động sản và đề xuất các trường nhìn thấy rõ để điền vào biểu mẫu đăng bán. Không kết luận pháp lý, không xác minh thật giả, không suy đoán phần bị che hoặc mờ. Không trích xuất số CCCD, số điện thoại hay dữ liệu cá nhân nếu không nhìn thấy rõ; nếu không chắc chắn hãy trả null. Chuẩn hóa diện tích và giá thành chuỗi số khi có thể; giá dùng đơn vị tỷ đồng nếu ảnh thể hiện tỷ. Chỉ trả JSON theo schema." },
          { type: "image_url", image_url: { url: `data:${input.mimeType};base64,${input.data}`, detail: "high" } },
        ] }],
        outputSchema: { name: "listing_document_extraction", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          title: { type: ["string", "null"] }, propertyType: { type: ["string", "null"] }, location: { type: ["string", "null"] }, province: { type: ["string", "null"] }, area: { type: ["string", "null"] }, price: { type: ["string", "null"] }, buildArea: { type: ["string", "null"] }, roadWidth: { type: ["string", "null"] }, bedrooms: { type: ["integer", "null"] }, bathrooms: { type: ["integer", "null"] }, orientation: { type: ["string", "null"] }, legalStatus: { type: ["string", "null"] }, certificateType: { type: ["string", "null"] }, certificateArea: { type: ["string", "null"] }, landUsePurpose: { type: ["string", "null"] }, planningStatus: { type: ["string", "null"] }, mortgageStatus: { type: ["string", "null"] }, ownerName: { type: ["string", "null"] }, ownerPhone: { type: ["string", "null"] }, propertyCode: { type: ["string", "null"] }, description: { type: ["string", "null"] }, confidence: { type: "number", minimum: 0, maximum: 100 }, notes: { type: ["string", "null"] }
        }, required: ["title", "propertyType", "location", "province", "area", "price", "buildArea", "roadWidth", "bedrooms", "bathrooms", "orientation", "legalStatus", "certificateType", "certificateArea", "landUsePurpose", "planningStatus", "mortgageStatus", "ownerName", "ownerPhone", "propertyCode", "description", "confidence", "notes"] } },
        maxTokens: 2200,
      });
      const content = response.choices?.[0]?.message?.content;
      const raw = typeof content === "string" ? content : JSON.stringify(content || "{}");
      let extracted: Record<string, unknown>;
      try { extracted = JSON.parse(raw) as Record<string, unknown>; } catch { throw new TRPCError({ code: "BAD_REQUEST", message: "Không đọc được thông tin từ ảnh. Vui lòng chụp lại rõ hơn." }); }
      const confidence = typeof extracted.confidence === "number" ? Math.min(100, Math.max(0, extracted.confidence)) : 0;
      return { extracted, confidence, imageUrl: uploaded.url, storageKey: uploaded.key, fileName: input.fileName, status: "needs_review" as const, warning: "AI chỉ đề xuất dữ liệu nhìn thấy trong ảnh. Hãy kiểm tra từng trường trước khi lưu hoặc công khai bài đăng." };
    }),
    featured: publicProcedure.query(() => listFeaturedProperties()),
    latest: publicProcedure.query(() => listLatestPublishedProperties()),
    list: publicProcedure.input(z.object({
      q: z.string().trim().max(255).optional(),
      propertyType: propertyType.optional(),
      areaId: z.number().int().positive().optional(),
      province: z.string().max(120).optional(),
      location: z.string().max(255).optional(),
      minPrice: z.number().nonnegative().optional(),
      maxPrice: z.number().nonnegative().optional(),
      minArea: z.number().nonnegative().optional(),
      maxArea: z.number().nonnegative().optional(),
      minBedrooms: z.number().int().nonnegative().optional(),
      maxBedrooms: z.number().int().nonnegative().optional(),
      orientation: z.string().max(80).optional(),
      legalStatus: z.string().max(160).optional(),
      sort: z.enum(["newest", "price_asc", "price_desc", "area_desc"]).optional(),
    }).optional()).query(({ input }) => listPublishedProperties(input ?? {})),
    detail: publicProcedure.input(z.object({ slug: z.string().min(1) })).query(({ input }) => getPublishedPropertyWithImages(input.slug)),
    adminList: adminProcedure.query(() => listProperties()),
    soldForTransaction: adminProcedure.query(() => listSoldPropertiesForTransaction()),
    mine: protectedProcedure.query(({ ctx }) => listPropertiesByCreator(ctx.user.id)),
    create: protectedProcedure.input(z.object({ title: z.string().min(3).max(255), slug: z.string().min(3).max(255), propertyType, listingType: z.enum(["sale", "rent"]).default("sale"), price: z.string().regex(/^\d+(\.\d{1,2})?$/), area: z.string().regex(/^\d+(\.\d{1,2})?$/), buildArea: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(), roadWidth: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(), bedrooms: z.number().int().nonnegative().optional(), bathrooms: z.number().int().nonnegative().optional(), constructionYear: z.number().int().min(1800).max(2100).optional(), orientation: z.string().max(80).optional(), location: z.string().min(2).max(255), latitude: z.string().regex(/^-?\d{1,3}(\.\d{1,7})?$/).nullable().optional(), longitude: z.string().regex(/^-?\d{1,3}(\.\d{1,7})?$/).nullable().optional(), mapVisibility: z.enum(["approximate", "exact", "private"]).optional(), distanceToMainRoad: z.string().max(120).optional(), nearbySchools: z.string().max(255).optional(), nearbyMarket: z.string().max(255).optional(), nearbyHospital: z.string().max(255).optional(), distanceToCenter: z.string().max(120).optional(), areaId: z.number().int().positive().optional(), description: z.string().max(10000).optional(), legalStatus: z.string().max(160).optional(), certificateType: z.string().max(160).optional(), certificateArea: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(), landUsePurpose: z.string().max(255).optional(), planningStatus: z.string().max(255).optional(), mortgageStatus: z.string().max(255).optional(), legalSource: z.string().max(255).optional(), negotiable: z.boolean().optional(), brokerageFee: z.string().max(160).optional(), depositTerms: z.string().max(5000).optional(), transactionTerms: z.string().max(5000).optional(), listingDetails: z.string().max(20000).optional(), propertyCode: z.string().max(80).optional(), brokerName: z.string().max(120).optional(), brokerPhone: z.string().max(30).optional(), brokerZalo: z.string().max(255).optional(), ownerName: z.string().max(120).optional(), ownerPhone: z.string().max(30).optional(), imageUrl: propertyImageUrl.optional(), imageUrls: z.array(propertyImageUrl).max(8, "Bài đăng chỉ được tối đa 8 ảnh.").optional(), videoUrls: z.array(propertyMediaUrl).max(4, "Bài đăng chỉ được tối đa 4 video.").optional() })).mutation(async ({ input, ctx }) => { const { imageUrl, imageUrls, videoUrls, ...propertyInput } = input; const created = await createProperty({ ...propertyInput, areaId: input.areaId || null, createdBy: ctx.user.id, latitude: input.latitude || null, longitude: input.longitude || null, mapVisibility: input.mapVisibility || "approximate", description: input.description || null, buildArea: input.buildArea || null, roadWidth: input.roadWidth || null, bedrooms: input.bedrooms ?? null, bathrooms: input.bathrooms ?? null, constructionYear: input.constructionYear ?? null, orientation: input.orientation || null, distanceToMainRoad: input.distanceToMainRoad || null, nearbySchools: input.nearbySchools || null, nearbyMarket: input.nearbyMarket || null, nearbyHospital: input.nearbyHospital || null, distanceToCenter: input.distanceToCenter || null, legalStatus: input.legalStatus || null, certificateType: input.certificateType || null, certificateArea: input.certificateArea || null, landUsePurpose: input.landUsePurpose || null, planningStatus: input.planningStatus || null, mortgageStatus: input.mortgageStatus || null, legalSource: input.legalSource || "Theo hồ sơ/chủ nhà cung cấp", negotiable: input.negotiable === false ? 0 : 1, brokerageFee: input.brokerageFee || null, depositTerms: input.depositTerms || null, transactionTerms: input.transactionTerms || null, listingDetails: input.listingDetails || null, propertyCode: input.propertyCode || null, brokerName: input.brokerName || null, brokerPhone: input.brokerPhone || null, brokerZalo: input.brokerZalo || null, ownerName: input.ownerName || null, ownerPhone: input.ownerPhone || null }); const imageList = imageUrls?.length ? imageUrls : imageUrl ? [imageUrl] : []; for (let index = 0; index < imageList.length; index += 1) { const url = imageList[index]; if (url) await createPropertyImage({ propertyId: created.id, url, mediaType: "image", altText: `${input.title} · ảnh ${index + 1}`, sortOrder: index }); } for (let index = 0; index < (videoUrls || []).length; index += 1) { const url = videoUrls?.[index]; if (url) await createPropertyImage({ propertyId: created.id, url, mediaType: "video", altText: `${input.title} · video ${index + 1}`, sortOrder: imageList.length + index }); } const dossier = await ensurePropertyDossier({ propertyId: created.id, createdBy: ctx.user.id }); return { ...created, dossierId: dossier.id, dossierCreated: dossier.created }; }),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), title: z.string().min(3).max(255).optional(), slug: z.string().min(3).max(255).optional(), propertyType: propertyType.optional(), listingType: z.enum(["sale", "rent"]).optional(), price: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(), area: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(), buildArea: z.string().regex(/^\d+(\.\d{1,2})?$/).nullable().optional(), bedrooms: z.number().int().nonnegative().nullable().optional(), bathrooms: z.number().int().nonnegative().nullable().optional(), location: z.string().min(2).max(255).optional(), latitude: z.string().nullable().optional(), longitude: z.string().nullable().optional(), mapVisibility: z.enum(["approximate", "exact", "private"]).optional(), orientation: z.string().max(80).nullable().optional(), description: z.string().max(10000).nullable().optional(), listingDetails: z.string().max(20000).nullable().optional(), legalStatus: z.string().max(160).nullable().optional(), certificateType: z.string().max(160).nullable().optional(), certificateArea: z.string().nullable().optional(), landUsePurpose: z.string().max(255).nullable().optional(), planningStatus: z.string().max(255).nullable().optional(), mortgageStatus: z.string().max(255).nullable().optional(), propertyCode: z.string().max(80).nullable().optional(), brokerName: z.string().max(120).nullable().optional(), brokerPhone: z.string().max(30).nullable().optional(), brokerZalo: z.string().max(255).nullable().optional(), ownerName: z.string().max(120).nullable().optional(), ownerPhone: z.string().max(30).nullable().optional() })).mutation(async ({ input, ctx }) => { const { id, ...data } = input; const result = await updateProperty(id, ctx.user.role === "admin" ? undefined : ctx.user.id, data); if (!result.success) throw new TRPCError({ code: result.reason === "forbidden" ? "FORBIDDEN" : "NOT_FOUND", message: result.reason === "forbidden" ? "Bạn không có quyền chỉnh sửa bài đăng này." : "Không tìm thấy bài đăng." }); return result; }),
    updateStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: propertyStatus })).mutation(async ({ input, ctx }) => { const result = await updatePropertyStatus(input.id, input.status); if (result.reason === "not_found") throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy bài đăng." }); if (result.reason === "incomplete") throw new TRPCError({ code: "BAD_REQUEST", message: "Chưa thể Công khai: hãy bổ sung giá, diện tích và địa chỉ thực tế của bài đăng trước." }); if (input.status === "sold") { const dossier = await ensurePropertyDossier({ propertyId: input.id, createdBy: ctx.user.id }); const deal = await ensureDealForSoldProperty(input.id, ctx.user.id); return { ...result, sold: true as const, dossierId: dossier.id, dossierCreated: dossier.created, deal, productionStatus: dossier.created ? "queued" as const : "ready_for_production" as const }; } return result; }),
    updateLocation: adminProcedure.input(z.object({ id: z.number().int().positive(), location: z.string().min(2).max(255), latitude: z.string().regex(/^-?\d{1,3}(\.\d{1,7})?$/).nullable(), longitude: z.string().regex(/^-?\d{1,3}(\.\d{1,7})?$/).nullable(), mapVisibility: z.enum(["approximate", "exact", "private"]) })).mutation(({ input }) => updatePropertyLocation(input.id, input)),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => { const result = await deleteProperty(input.id, ctx.user.role === "admin" ? undefined : ctx.user.id); if (result.reason === "not_found") throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy bài đăng." }); if (result.reason === "forbidden") throw new TRPCError({ code: "FORBIDDEN", message: "Bạn chỉ có thể xóa bài Nháp do chính mình tạo." }); if (result.reason === "linked_records") throw new TRPCError({ code: "CONFLICT", message: "Bài đã có hồ sơ pháp lý, định giá, khảo sát hoặc giao dịch liên kết nên không thể xóa." }); return result; }),
  }),
  legalDocuments: router({
    list: adminProcedure.input(z.object({ propertyId: z.number().int().positive() })).query(({ input, ctx }) => { requireSensitiveAccess(ctx.user.role, "view"); return listLegalDocumentScans(input.propertyId); }),
    analyze: adminProcedure.input(z.object({ propertyId: z.number().int().positive().optional(), createDraft: z.boolean().optional(), fileName: z.string().min(1).max(255), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), data: z.string().min(1).max(14_000_000) })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (bytes.byteLength > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Ảnh hồ sơ không được vượt quá 10MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploadScope = input.propertyId ? String(input.propertyId) : "inbox";
      const uploaded = await storagePut(`legal-documents/${uploadScope}/${ctx.user.id}-${Date.now()}-${safeName}`, bytes, input.mimeType);
      const response = await invokeLLM({
        messages: [{ role: "user", content: [
          { type: "text", text: "Bạn là trợ lý nhập liệu hồ sơ bất động sản tại Việt Nam. Hãy đọc ảnh sổ đỏ/sổ hồng để đề xuất các trường pháp lý nhìn thấy rõ. Không kết luận pháp lý, không xác minh tính thật giả, không suy đoán phần bị che/mờ, không trích xuất số CCCD hoặc thông tin cá nhân nhạy cảm. Nếu không chắc chắn, trả về null và confidence thấp. Chỉ trả JSON theo schema." },
          { type: "image_url", image_url: { url: `data:${input.mimeType};base64,${input.data}`, detail: "high" } },
        ] }],
        outputSchema: { name: "legal_document_extraction", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          legalStatus: { type: ["string", "null"] }, certificateType: { type: ["string", "null"] }, certificateArea: { type: ["string", "null"] }, landUsePurpose: { type: ["string", "null"] }, planningStatus: { type: ["string", "null"] }, mortgageStatus: { type: ["string", "null"] }, legalSource: { type: ["string", "null"] }, confidence: { type: "number", minimum: 0, maximum: 100 }, notes: { type: ["string", "null"] }
        }, required: ["legalStatus", "certificateType", "certificateArea", "landUsePurpose", "planningStatus", "mortgageStatus", "legalSource", "confidence", "notes"] } },
        maxTokens: 1200,
      });
      const content = response.choices?.[0]?.message?.content;
      const raw = typeof content === "string" ? content : JSON.stringify(content || "{}");
      let extracted: Record<string, unknown>;
      try { extracted = JSON.parse(raw) as Record<string, unknown>; } catch { throw new TRPCError({ code: "BAD_REQUEST", message: "Không đọc được kết quả nhận diện. Vui lòng chụp lại ảnh rõ hơn." }); }
      const confidence = typeof extracted.confidence === "number" ? Math.min(100, Math.max(0, extracted.confidence)) : 0;
      let propertyId = input.propertyId;
      if (!propertyId && input.createDraft !== false) {
        const certificateArea = typeof extracted.certificateArea === "string" && /^\d+(\.\d{1,2})?$/.test(extracted.certificateArea) ? extracted.certificateArea : "0";
        const suffix = Date.now();
        const createdProperty = await createProperty({ title: `BĐS từ hồ sơ pháp lý · ${new Date().toLocaleDateString("vi-VN")}`, slug: `ho-so-phap-ly-${suffix}`, propertyType: "land", listingType: "sale", price: "0", area: certificateArea, location: "Chưa xác định · cần bổ sung địa chỉ", legalStatus: typeof extracted.legalStatus === "string" ? extracted.legalStatus : null, certificateType: typeof extracted.certificateType === "string" ? extracted.certificateType : null, certificateArea: certificateArea === "0" ? null : certificateArea, landUsePurpose: typeof extracted.landUsePurpose === "string" ? extracted.landUsePurpose : null, planningStatus: typeof extracted.planningStatus === "string" ? extracted.planningStatus : null, mortgageStatus: typeof extracted.mortgageStatus === "string" ? extracted.mortgageStatus : null, legalSource: typeof extracted.legalSource === "string" ? extracted.legalSource : "Theo ảnh hồ sơ cung cấp · cần kiểm tra bản gốc", createdBy: ctx.user.id, status: "draft", negotiable: 1 });
        propertyId = createdProperty.id;
      }
      if (!propertyId) throw new TRPCError({ code: "BAD_REQUEST", message: "Hãy chọn BĐS hoặc bật tạo bài Nháp từ hồ sơ." });
      const created = await createLegalDocumentScan({ propertyId, fileName: input.fileName, mimeType: input.mimeType, imageUrl: uploaded.url, storageKey: uploaded.key, extractedData: JSON.stringify(extracted), confidence: String(confidence), createdBy: ctx.user.id });
      const archive = await createPropertyArchiveFile({ propertyId, category: "legal", documentType: "Sổ đỏ / sổ hồng · bản gốc quét", fileName: input.fileName, mimeType: input.mimeType, url: uploaded.url, storageKey: uploaded.key, uploadedBy: ctx.user.id });
      return { ...created, archiveId: archive.id, propertyId, imageUrl: uploaded.url, status: "pending" as const, extracted, createdDraft: !input.propertyId, isPublicImage: false as const, warning: "Ảnh giấy tờ đã được lưu trong vùng hồ sơ riêng tư, không hiển thị trên card hoặc trang công khai. Kết quả chỉ hỗ trợ nhập liệu; hãy kiểm tra hồ sơ gốc, bổ sung thông tin còn thiếu và chỉ công khai sau khi được duyệt." };
    }),
    confirm: adminProcedure.input(z.object({ id: z.number().int().positive(), propertyId: z.number().int().positive(), legalStatus: z.string().max(160).nullable(), certificateType: z.string().max(160).nullable(), certificateArea: z.string().regex(/^\d+(\\.\d{1,2})?$/).nullable(), landUsePurpose: z.string().max(255).nullable(), planningStatus: z.string().max(255).nullable(), mortgageStatus: z.string().max(255).nullable(), legalSource: z.string().max(255).nullable() })).mutation(async ({ input, ctx }) => { const { id, propertyId, ...data } = input; const result = await confirmLegalDocumentScan(id, propertyId, data, ctx.user.id); if (result.reason === "not_found") throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy lượt quét hồ sơ." }); return result; }),
    reject: adminProcedure.input(z.object({ id: z.number().int().positive(), propertyId: z.number().int().positive() })).mutation(({ input, ctx }) => rejectLegalDocumentScan(input.id, input.propertyId, ctx.user.id)),
  }),
  archives: router({
    list: adminProcedure.input(z.object({ propertyId: z.number().int().positive().optional(), category: z.enum(["property", "legal", "valuation", "marketing", "transaction"]).optional(), search: z.string().max(160).optional() }).optional()).query(({ input, ctx }) => { requireSensitiveAccess(ctx.user.role, input?.category === "legal" || input?.category === "transaction" ? "view" : "view"); return listPropertyArchiveFiles(input); }),
    upload: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), category: z.enum(["property", "legal", "valuation", "marketing", "transaction"]), documentType: z.string().trim().min(1).max(160), fileName: z.string().trim().min(1).max(180), mimeType: z.string().regex(/^(image|video|application|text)\//), data: z.string().min(1).max(14_000_000) })).mutation(async ({ input, ctx }) => { requireSensitiveAccess(ctx.user.role, "manage"); const bytes = Buffer.from(input.data, "base64"); if (bytes.byteLength > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp không được vượt quá 10MB." }); const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-"); const uploaded = await storagePut(`property-archives/${input.propertyId}/${input.category}/${ctx.user.id}-${safeName}`, bytes, input.mimeType); return createPropertyArchiveFile({ propertyId: input.propertyId, category: input.category, documentType: input.documentType, fileName: input.fileName, mimeType: input.mimeType, url: uploaded.url, storageKey: uploaded.key, uploadedBy: ctx.user.id }); }),
    rename: adminProcedure.input(z.object({ id: z.number().int().positive(), fileName: z.string().trim().min(1).max(180), documentType: z.string().trim().min(1).max(160).optional() })).mutation(({ input, ctx }) => { requireSensitiveAccess(ctx.user.role, "manage"); return renamePropertyArchiveFile(input.id, input.fileName, input.documentType); }),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input, ctx }) => { requireSensitiveAccess(ctx.user.role, "manage"); return deletePropertyArchiveFile(input.id); }),
  }),
  brokerage: router({
    property3dAnnotations: router({
      list: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), assetUrl: z.string().url().max(4000).optional() })).query(({ input }) => listProperty3dAnnotations(input.propertyId).then(rows => input.assetUrl ? rows.filter(row => row.assetUrl === input.assetUrl) : rows)),
      create: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), assetUrl: z.string().url().max(4000), assetFileName: z.string().trim().max(255).optional(), title: z.string().trim().min(1).max(160), body: z.string().max(4000).optional(), tag: z.string().trim().max(80).optional(), positionX: z.number().min(-10).max(10), positionY: z.number().min(-10).max(10), positionZ: z.number().min(-10).max(10) })).mutation(({ input, ctx }) => createProperty3dAnnotation({ ...input, positionX: String(input.positionX), positionY: String(input.positionY), positionZ: String(input.positionZ), assetFileName: input.assetFileName || null, body: input.body || null, tag: input.tag || null, createdBy: ctx.user.id })),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), propertyId: z.number().int().positive(), title: z.string().trim().min(1).max(160).optional(), body: z.string().max(4000).nullable().optional(), tag: z.string().trim().max(80).nullable().optional(), positionX: z.number().min(-10).max(10).optional(), positionY: z.number().min(-10).max(10).optional(), positionZ: z.number().min(-10).max(10).optional() })).mutation(({ input }) => { const { id, propertyId, title, body, tag, positionX, positionY, positionZ } = input; return updateProperty3dAnnotation(id, propertyId, { title, body, tag, ...(positionX === undefined ? {} : { positionX: String(positionX) }), ...(positionY === undefined ? {} : { positionY: String(positionY) }), ...(positionZ === undefined ? {} : { positionZ: String(positionZ) }) }); }),
      delete: adminProcedure.input(z.object({ id: z.number().int().positive(), propertyId: z.number().int().positive() })).mutation(({ input }) => deleteProperty3dAnnotation(input.id, input.propertyId)),
    }),
    owners: adminProcedure.query(() => listOwners()),
    createOwner: adminProcedure.input(z.object({ name: z.string().min(2).max(120), phone: z.string().min(8).max(30), email: z.string().email().optional(), notes: z.string().max(3000).optional() })).mutation(({ input }) => createOwner({ ...input, email: input.email || null, notes: input.notes || null })),
    buyers: adminProcedure.query(() => listBuyerLeads()),
    createBuyer: adminProcedure.input(z.object({ name: z.string().min(2).max(120), phone: z.string().min(8).max(30), budget: z.string().optional(), preferredArea: z.string().max(255).optional(), propertyType: z.string().max(80).optional(), notes: z.string().max(3000).optional() })).mutation(({ input, ctx }) => createBuyerLead({ ...input, budget: input.budget || null, preferredArea: input.preferredArea || null, propertyType: input.propertyType || null, notes: input.notes || null, assignedTo: ctx.user.id })),
    surveys: adminProcedure.query(() => listSurveys()),
    createSurvey: adminProcedure.input(z.object({ buyerLeadId: z.number().int().positive().optional(), propertyId: z.number().int().positive().optional(), purpose: z.string().max(120).optional(), budget: z.string().optional(), timeline: z.string().max(120).optional(), mustHave: z.string().max(3000).optional(), notes: z.string().max(3000).optional() })).mutation(({ input, ctx }) => createSurvey({ ...input, buyerLeadId: input.buyerLeadId || null, propertyId: input.propertyId || null, budget: input.budget || null, purpose: input.purpose || null, timeline: input.timeline || null, mustHave: input.mustHave || null, notes: input.notes || null, createdBy: ctx.user.id })),
    legalChecks: adminProcedure.query(() => listLegalChecks()),
    createLegalCheck: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), status: z.enum(["pending", "in_review", "verified", "issue_found"]).default("pending"), documents: z.string().max(3000).optional(), notes: z.string().max(3000).optional() })).mutation(({ input, ctx }) => createLegalCheck({ ...input, checkedBy: ctx.user.id, documents: input.documents || null, notes: input.notes || null })),
    valuations: adminProcedure.query(() => listValuations()),
    createValuation: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), estimatedPrice: z.string().regex(/^\d+(\.\d{1,2})?$/), method: z.string().max(160).optional(), comparableNotes: z.string().max(3000).optional() })).mutation(({ input, ctx }) => createValuation({ ...input, assessedBy: ctx.user.id, method: input.method || null, comparableNotes: input.comparableNotes || null })),
    deals: adminProcedure.query(() => listDeals()),
    getDeal: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getDeal(input.id)),
    createDeal: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), buyerLeadId: z.number().int().positive().optional(), ownerId: z.number().int().positive().optional(), stage: z.enum(["new", "negotiating", "deposit", "contracted", "completed", "cancelled"]).default("new"), transactionCode: z.string().trim().max(40).optional(), agreedPrice: z.string().regex(/^\d+(\\.\d{1,2})?$/).optional(), depositAmount: z.string().regex(/^\d+(\\.\d{1,2})?$/).optional(), depositDate: z.coerce.date().optional(), expectedNotaryDate: z.coerce.date().optional(), commissionAmount: z.string().regex(/^\d+(\\.\d{1,2})?$/).optional(), paymentMethod: z.string().max(120).optional(), notaryOffice: z.string().max(255).optional(), notes: z.string().max(3000).optional() })).mutation(({ input, ctx }) => createDeal({ ...input, assignedTo: ctx.user.id, buyerLeadId: input.buyerLeadId || null, ownerId: input.ownerId || null, transactionCode: input.transactionCode || null, agreedPrice: input.agreedPrice || null, depositAmount: input.depositAmount || null, depositDate: input.depositDate || null, expectedNotaryDate: input.expectedNotaryDate || null, commissionAmount: input.commissionAmount || null, paymentMethod: input.paymentMethod || null, notaryOffice: input.notaryOffice || null, notes: input.notes || null })),
    updateDeal: adminProcedure.input(z.object({ id: z.number().int().positive(), stage: z.enum(["new", "negotiating", "deposit", "contracted", "completed", "cancelled"]).optional(), depositAmount: z.string().regex(/^\d+(\\.\d{1,2})?$/).nullable().optional(), depositDate: z.coerce.date().nullable().optional(), expectedNotaryDate: z.coerce.date().nullable().optional(), completionDate: z.coerce.date().nullable().optional(), commissionAmount: z.string().regex(/^\d+(\\.\d{1,2})?$/).nullable().optional(), paymentStatus: z.enum(["pending", "partial", "paid"]).optional(), paymentMethod: z.string().max(120).nullable().optional(), notaryOffice: z.string().max(255).nullable().optional(), transferStatus: z.enum(["not_started", "in_progress", "completed"]).optional(), handoverStatus: z.enum(["not_started", "scheduled", "completed"]).optional(), issueNote: z.string().max(4000).nullable().optional(), nextAction: z.string().max(2000).nullable().optional(), checklist: z.string().max(12000).nullable().optional(), notes: z.string().max(3000).nullable().optional() })).mutation(({ input }) => { const { id, ...data } = input; return updateDeal(id, data); }),
    aiAssistant: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const deal = await getDeal(input.id); if (!deal) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy giao dịch." }); const missing: string[] = []; if (!deal.buyerLeadId) missing.push("Khách mua"); if (!deal.ownerId) missing.push("Chủ nhà"); if (!deal.agreedPrice) missing.push("Giá chốt"); if (deal.stage === "deposit" && !deal.depositAmount) missing.push("Số tiền đặt cọc"); if (["contracted", "completed"].includes(deal.stage) && !deal.expectedNotaryDate) missing.push("Ngày công chứng dự kiến"); if (deal.transferStatus !== "completed") missing.push("Hồ sơ sang tên"); const nextAction = missing[0] ? `Bổ sung: ${missing[0]}` : deal.stage === "new" ? "Xác nhận nhu cầu và chuyển sang đàm phán" : deal.stage === "negotiating" ? "Ghi nhận giá chốt và điều kiện đặt cọc" : deal.stage === "deposit" ? "Kiểm tra hạn công chứng và phiếu đặt cọc" : deal.stage === "contracted" ? "Theo dõi sang tên và hồ sơ bàn giao" : "Đối chiếu hồ sơ hoàn tất và lưu lịch sử"; return { dealId: deal.id, missing, nextAction, warnings: deal.issueNote ? [deal.issueNote] : [], requiresReview: true, notice: "Trợ lý AI chỉ hỗ trợ rà soát dữ liệu giao dịch; môi giới phải kiểm tra hồ sơ gốc và xác nhận thủ công." }; }),
    dossiers: router({
      list: protectedProcedure.query(({ ctx }) => listPropertyDossiersForUser({ userId: ctx.user.id, isAdmin: ctx.user.role === "admin" })),
      get: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getPropertyDossier(input.id)),
      create: adminProcedure.input(z.object({ propertyId: z.number().int().positive(), assignedTo: z.number().int().positive().optional() })).mutation(async ({ input, ctx }) => {
        try { return await createPropertyDossier({ propertyId: input.propertyId, assignedTo: input.assignedTo || ctx.user.id, createdBy: ctx.user.id }); }
        catch (error) { throw new TRPCError({ code: "CONFLICT", message: "Bất động sản này đã có hồ sơ quy trình hoặc không tồn tại." }); }
      }),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["active", "completed", "paused"]).optional(), currentStep: z.number().int().min(1).max(12).optional(), assignedTo: z.number().int().positive().nullable().optional(), notes: z.string().max(10000).nullable().optional() })).mutation(({ input }) => { const { id, ...data } = input; return updatePropertyDossier(id, data); }),
      delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { const result = await deletePropertyDossier(input.id); if (result.reason === "not_found") throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hồ sơ BĐS." }); return result; }),
      updateStep: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["completed", "in_progress", "not_started", "needs_review"]), details: z.string().max(10000).nullable().optional(), notes: z.string().max(10000).nullable().optional() })).mutation(({ input, ctx }) => updatePropertyDossierStep(input.id, { status: input.status, details: input.details, notes: input.notes, updatedBy: ctx.user.id })),
      uploadDocument: adminProcedure.input(z.object({ dossierId: z.number().int().positive(), stepNumber: z.number().int().min(1).max(12), fileName: z.string().min(1).max(180), mimeType: z.string().regex(/^(image|video|application|text)\//), data: z.string().min(1).max(14_000_000) })).mutation(async ({ input, ctx }) => { const bytes = Buffer.from(input.data, "base64"); if (bytes.byteLength > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tài liệu không được vượt quá 10MB." }); const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-"); const uploaded = await storagePut(`dossiers/${input.dossierId}/${input.stepNumber}/${ctx.user.id}-${safeName}`, bytes, input.mimeType); return createPropertyDossierDocument({ dossierId: input.dossierId, stepNumber: input.stepNumber, fileName: input.fileName, mimeType: input.mimeType, url: uploaded.url, storageKey: uploaded.key, uploadedBy: ctx.user.id }); }),
      analyzeStepImage: adminProcedure.input(z.object({ dossierId: z.number().int().positive(), stepNumber: z.number().int().min(1).max(12), fileName: z.string().min(1).max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), data: z.string().min(1).max(14_000_000), fields: z.array(z.object({ key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_]{1,60}$/), label: z.string().min(1).max(120) })).min(1).max(30) })).mutation(async ({ input, ctx }) => {
        const bytes = Buffer.from(input.data, "base64");
        if (bytes.byteLength > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Ảnh biên bản không được vượt quá 10MB." });
        const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
        const uploaded = await storagePut(`dossiers/${input.dossierId}/${input.stepNumber}/ocr-${ctx.user.id}-${Date.now()}-${safeName}`, bytes, input.mimeType);
        const propertyFields = Object.fromEntries(input.fields.map(field => [field.key, { type: ["string", "null"], description: field.label }]));
        const response = await invokeLLM({
          messages: [{ role: "user", content: [
            { type: "text", text: `Bạn là trợ lý nhập liệu quy trình môi giới bất động sản tại Việt Nam. Hãy đọc ảnh biên bản được chụp và đề xuất dữ liệu cho đúng bước nghiệp vụ. Chỉ trích xuất thông tin nhìn thấy rõ, không suy đoán, không kết luận pháp lý. Các trường cần điền: ${JSON.stringify(input.fields)}. Nếu không thấy giá trị, trả null. summary là tóm tắt ngắn nội dung biên bản và confidence là mức tin cậy 0-100. Chỉ trả JSON theo schema.` },
            { type: "image_url", image_url: { url: `data:${input.mimeType};base64,${input.data}`, detail: "high" } },
          ] }],
          outputSchema: { name: "workflow_document_extraction", strict: true, schema: { type: "object", additionalProperties: false, properties: { fields: { type: "object", additionalProperties: { type: ["string", "null"] }, properties: propertyFields }, summary: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 100 }, warnings: { type: "array", items: { type: "string" }, maxItems: 8 } }, required: ["fields", "summary", "confidence", "warnings"] } },
          maxTokens: 1800,
        });
        const content = response.choices?.[0]?.message?.content;
        const raw = typeof content === "string" ? content : JSON.stringify(content || "{}");
        let extracted: { fields?: Record<string, unknown>; summary?: string; confidence?: number; warnings?: string[] };
        try { extracted = JSON.parse(raw) as typeof extracted; } catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa đọc được biên bản. Vui lòng chụp lại ảnh rõ hơn." }); }
        const document = await createPropertyDossierDocument({ dossierId: input.dossierId, stepNumber: input.stepNumber, fileName: input.fileName, mimeType: input.mimeType, url: uploaded.url, storageKey: uploaded.key, uploadedBy: ctx.user.id });
        return { document, fields: extracted.fields || {}, summary: extracted.summary || "", confidence: Math.min(100, Math.max(0, Number(extracted.confidence) || 0)), warnings: Array.isArray(extracted.warnings) ? extracted.warnings.slice(0, 8).map(String) : [] };
      }),
      deleteDocument: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => deletePropertyDossierDocument(input.id)),
        }),
  }),
  dashboard: router({
    summary: adminProcedure.query(() => getDashboardSummary()),
  }),
  landDossiers: router({
    list: protectedProcedure.query(({ ctx }) => listLandDossiers(ctx.user.id)),
    detail: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input, ctx }) => { const result = await getLandDossier(input.id, ctx.user.id); if (!result) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy hồ sơ đất đai." }); return result; }),
    create: adminProcedure.input(z.object({ procedureType: z.string().trim().min(2).max(120), title: z.string().trim().min(2).max(255), propertyId: z.number().int().positive().nullable().optional(), answers: z.record(z.string(), z.string()).optional(), steps: z.array(z.object({ stepNumber: z.number().int().positive(), title: z.string().min(2).max(180), checklist: z.array(z.object({ label: z.string().min(1).max(255), status: z.enum(["completed", "missing", "conditional", "verify"]).default("missing"), note: z.string().max(500).optional() })).max(20), relatedTemplates: z.array(z.string().max(160)).max(12).optional() })).min(1).max(12) })).mutation(({ input, ctx }) => { const code = `HS-${Date.now().toString(36).toUpperCase()}`; return createLandDossier({ dossierCode: code, procedureType: input.procedureType, title: input.title, status: "in_progress", currentStep: 1, answers: JSON.stringify(input.answers || {}), notes: null, createdBy: ctx.user.id, propertyId: input.propertyId || null }, input.steps.map(step => ({ dossierId: 0, stepNumber: step.stepNumber, title: step.title, status: step.stepNumber === 1 ? "in_progress" : "not_started", checklist: JSON.stringify(step.checklist), relatedTemplates: JSON.stringify(step.relatedTemplates || []), notes: null, completedAt: null })) ); }),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), currentStep: z.number().int().positive().max(12).optional(), status: z.enum(["draft", "in_progress", "completed", "paused", "cancelled"]).optional(), answers: z.record(z.string(), z.string()).optional(), notes: z.string().max(5000).optional() })).mutation(({ input, ctx }) => updateLandDossier(input.id, ctx.user.id, { currentStep: input.currentStep, status: input.status, answers: input.answers ? JSON.stringify(input.answers) : undefined, notes: input.notes })),
    cancel: adminProcedure.input(z.object({ id: z.number().int().positive(), reason: z.string().trim().max(5000).optional() })).mutation(({ input, ctx }) => updateLandDossier(input.id, ctx.user.id, { status: "cancelled", notes: input.reason ? `Đã hủy hồ sơ: ${input.reason}` : "Đã hủy hồ sơ." })),
    delete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input, ctx }) => deleteLandDossier(input.id, ctx.user.id)),
    updateStep: adminProcedure.input(z.object({ id: z.number().int().positive(), dossierId: z.number().int().positive(), status: z.enum(["completed", "in_progress", "not_started", "needs_review"]), checklist: z.array(z.object({ label: z.string(), status: z.enum(["completed", "missing", "conditional", "verify"]), note: z.string().optional() })).max(20) })).mutation(({ input, ctx }) => updateLandDossierStep(input.id, input.dossierId, ctx.user.id, { status: input.status, checklist: JSON.stringify(input.checklist), completedAt: input.status === "completed" ? new Date() : null })),
  }),
  landDossierBuilder: router({
    ocr: adminProcedure.input(z.object({ procedureId: z.string().trim().min(1).max(80), province: z.string().trim().min(1).max(120), fileName: z.string().trim().min(1).max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel"]), data: z.string().min(1).max(16_000_000) })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (bytes.byteLength > 12 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp OCR không được vượt quá 12MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploaded = await storagePut(`land-dossier-builder/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      const isImage = input.mimeType.startsWith("image/");
      const isPdf = input.mimeType === "application/pdf";
      let extractedOfficeText = "";
      if (!isImage && !isPdf) {
        try {
          if (input.mimeType.includes("word") || input.mimeType.includes("document") || /\\.docx?$/i.test(input.fileName)) {
            const mammoth = await import("mammoth");
            const result = await mammoth.extractRawText({ buffer: bytes });
            extractedOfficeText = result.value.slice(0, 120_000).trim();
          } else {
            const XLSX = await import("xlsx");
            const workbook = XLSX.read(bytes, { type: "buffer", cellDates: true });
            extractedOfficeText = workbook.SheetNames.map(sheetName => {
              const sheet = workbook.Sheets[sheetName];
              return `SHEET: ${sheetName}\\n${XLSX.utils.sheet_to_csv(sheet)}`;
            }).join("\\n\\n").slice(0, 120_000).trim();
          }
          if (!extractedOfficeText) throw new Error("empty office text");
        } catch {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Không đọc được nội dung DOCX/XLS/XLSX. Hãy kiểm tra tệp gốc hoặc tải bản PDF/ảnh rõ hơn." });
        }
      }
      const media = isImage
        ? { type: "image_url" as const, image_url: { url: `data:${input.mimeType};base64,${input.data}`, detail: "high" as const } }
        : isPdf
          ? { type: "file_url" as const, file_url: { url: `data:${input.mimeType};base64,${input.data}`, mime_type: "application/pdf" as const } }
          : { type: "text" as const, text: `Nội dung đã trích xuất từ ${input.fileName}:\\n${extractedOfficeText}` };
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là OCR hồ sơ đất đai Việt Nam. Chỉ trích xuất chữ nhìn thấy, không suy đoán và không kết luận hồ sơ hợp lệ. Nếu không đọc được hãy để trống và ghi cảnh báo. Trả JSON tiếng Việt." },
          { role: "user", content: [{ type: "text", text: `Thủ tục: ${input.procedureId}. Địa phương: ${input.province}. Trích xuất trường thông tin nhận dạng từ tài liệu.` }, media] },
        ],
        response_format: { type: "json_schema", json_schema: { name: "land_dossier_ocr", strict: true, schema: { type: "object", additionalProperties: false, properties: { fields: { type: "array", items: { type: "object", additionalProperties: false, properties: { key: { type: "string" }, label: { type: "string" }, value: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 1 }, evidence: { type: "string" } }, required: ["key", "label", "value", "confidence", "evidence"] }, maxItems: 30 }, warnings: { type: "array", items: { type: "string" }, maxItems: 10 }, documentType: { type: "string" }, overallConfidence: { type: "number", minimum: 0, maximum: 1 } }, required: ["fields", "warnings", "documentType", "overallConfidence"] } } },
        maxTokens: 2200,
      });
      const content = response.choices?.[0]?.message?.content;
      try { const extracted = JSON.parse(typeof content === "string" ? content : JSON.stringify(content || "{}")); return { ...extracted, fileName: input.fileName, mimeType: input.mimeType, storageKey: uploaded.key, fileUrl: uploaded.url, reviewed: false, warning: "OCR chỉ hỗ trợ nhập liệu. Hãy đối chiếu bản gốc và xác nhận trước khi điền mẫu." }; }
      catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "OCR chưa trả về dữ liệu có cấu trúc. Vui lòng thử lại." }); }
    }),
    exportBundle: adminProcedure.input(z.object({ procedureTitle: z.string().trim().min(1).max(180), province: z.string().trim().min(1).max(120), fields: z.array(z.object({ label: z.string().max(180), value: z.string().max(2000), confirmed: z.boolean() })).max(40), format: z.enum(["docx", "pdf"]), documentType: z.enum(["bundle", "transfer-contract", "variation-form", "pit-tax", "registration-fee", "checklist", "gift-contract", "inheritance-document", "lease-contract", "lease-variation", "purpose-application", "split-application", "merge-application", "mortgage-registration", "correction-application", "first-registration-application", "land-data-request"]).default("bundle"), documentLabel: z.string().trim().min(1).max(240).optional(), templateName: z.string().trim().min(1).max(240), templateSource: z.string().trim().max(1000).transform(normalizeTemplateSource), sourceCheckedAt: z.string().trim().min(1).max(80), templateProvenance: z.enum(["metadata-only", "verified-binary"]).default("metadata-only"), templateId: z.number().int().positive().optional() })).mutation(async ({ input }) => {
      if (input.fields.some(field => !field.confirmed)) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Cần xác nhận tất cả trường OCR trước khi xuất hồ sơ." });
      const title = input.documentLabel || input.procedureTitle;
      const sectionTitleByType: Record<string, string> = { "transfer-contract": "HỢP ĐỒNG CHUYỂN NHƯỢNG QUYỀN SỬ DỤNG ĐẤT", "variation-form": "ĐƠN ĐĂNG KÝ BIẾN ĐỘNG ĐẤT ĐAI", "pit-tax": "TỜ KHAI THUẾ THU NHẬP CÁ NHÂN", "registration-fee": "TỜ KHAI LỆ PHÍ TRƯỚC BẠ", "checklist": "CHECKLIST HỒ SƠ ĐẤT ĐAI", "gift-contract": "VĂN BẢN/HỢP ĐỒNG TẶNG CHO QUYỀN SỬ DỤNG ĐẤT", "inheritance-document": "VĂN BẢN THỪA KẾ/ KHAI NHẬN DI SẢN", "lease-contract": "HỢP ĐỒNG CHO THUÊ/CHO THUÊ LẠI ĐẤT", "lease-variation": "ĐƠN ĐĂNG KÝ BIẾN ĐỘNG DO CHO THUÊ ĐẤT", "purpose-application": "ĐƠN XIN CHUYỂN MỤC ĐÍCH SỬ DỤNG ĐẤT", "split-application": "ĐƠN ĐỀ NGHỊ TÁCH THỬA ĐẤT", "merge-application": "ĐƠN ĐỀ NGHỊ HỢP THỬA ĐẤT", "mortgage-registration": "ĐƠN ĐĂNG KÝ/XÓA ĐĂNG KÝ THẾ CHẤP", "correction-application": "ĐƠN ĐỀ NGHỊ ĐÍNH CHÍNH THÔNG TIN ĐẤT ĐAI", "first-registration-application": "ĐƠN ĐĂNG KÝ ĐẤT ĐAI, CẤP GIẤY CHỨNG NHẬN LẦN ĐẦU", "land-data-request": "VĂN BẢN ĐỀ NGHỊ CUNG CẤP THÔNG TIN, DỮ LIỆU ĐẤT ĐAI" }; const sectionTitle = sectionTitleByType[input.documentType] || `HỒ SƠ ĐẤT ĐAI — ${input.procedureTitle}`;
      const fields = input.fields.map(field => ({ label: field.label, value: field.value }));
      let verifiedAsset = getVerifiedLandTemplate(input.documentType, input.format);
      if (input.templateId) {
        const stored = await getLegalTemplateWithFields(input.templateId);
        if (!stored || stored.template.provenance !== "verified_binary" || !stored.template.storageKey || !stored.template.checksum || !["docx", "pdf"].includes(stored.template.format)) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Mẫu được chọn chưa có binary DOCX/PDF đã xác minh." });
        verifiedAsset = { id: `legal-template-${stored.template.id}`, fileName: stored.template.name, format: stored.template.format as "docx" | "pdf", mimeType: stored.template.format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document", sourceUrl: stored.template.sourceUrl, sourceCheckedAt: stored.template.updatedAt.toISOString(), sha256: stored.template.checksum, storageKey: stored.template.storageKey, sourceStatus: "verified" as const, placeholderMap: Object.fromEntries(stored.fields.map(field => [field.label, field.placeholderToken || field.fieldKey])) };
      }
      if (verifiedAsset) {
        try {
          const signedUrl = await storageGetSignedUrl(verifiedAsset.storageKey);
          const response = await fetch(signedUrl);
          if (!response.ok) throw new Error(`Không tải được template verified (${response.status}).`);
          const sourceBytes = new Uint8Array(await response.arrayBuffer());
          const filled = await fillVerifiedTemplate(verifiedAsset, sourceBytes, fields);
          return {
            fileName: verifiedAsset.fileName,
            mimeType: verifiedAsset.mimeType,
            data: Buffer.from(filled).toString("base64"),
            status: "confirmed-verified-template" as const,
            templateProvenance: "verified-binary" as const,
          };
        } catch (error) {
          if (input.templateId || input.templateProvenance === "verified-binary" || verifiedAsset) {
            const detail = error instanceof Error ? ` ${error.message}` : "";
            throw new TRPCError({ code: "PRECONDITION_FAILED", message: `Không thể tải hoặc điền mẫu binary đã xác minh. Không tạo bản nháp thay thế.${detail}` });
          }
          console.warn("[Land dossier] verified template unavailable; draft export remains explicitly marked as draft", error);
        }
      }
      if (input.templateProvenance === "verified-binary" && !verifiedAsset) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Chưa có mẫu DOCX/PDF chính thức đã xác minh cho thủ tục này." });
      }
      const formHeader = ["CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", "Độc lập - Tự do - Hạnh phúc", "", sectionTitle, ...(input.documentType === "variation-form" ? ["Mẫu số 09/ĐK — Đơn đăng ký biến động đất đai, tài sản gắn liền với đất"] : []), `Thủ tục: ${title}`, `Địa phương: ${input.province}`, "", "I. THÔNG TIN VÀ NỘI DUNG KÊ KHAI"]; const formFields = fields.map((field, index) => `[${String(index + 1).padStart(2, "0")}] ${field.label}: ${field.value || "........................................................"}`); const signature = ["", "II. CAM KẾT VÀ XÁC NHẬN", "Tôi cam kết các thông tin đã kê khai là đúng theo giấy tờ cung cấp và chịu trách nhiệm về nội dung hồ sơ.", "", "Người kê khai/đại diện", "(Ký, ghi rõ họ tên)", "", "........................................................"]; const provenance = ["", "THÔNG TIN THAM KHẢO", `Mẫu tham chiếu: ${input.templateName}`, `Nguồn: ${input.templateSource}`, `Ngày kiểm tra nguồn: ${input.sourceCheckedAt}`, "Trạng thái: CONFIRMED DRAFT — bản tham khảo do AI dựng, chưa phải mẫu Official và chưa điền trực tiếp vào file gốc của cơ quan nhà nước.", "GHI CHÚ: Người dùng phải đối chiếu thủ tục, biểu mẫu và yêu cầu của cơ quan tiếp nhận trước khi in, ký và nộp."]; const lines = [...formHeader, ...formFields, ...signature, ...provenance];
      const safeFileStem = (input.documentLabel || input.documentType).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-|-$/g, "").toLowerCase() || input.documentType;
      if (input.format === "docx") { const document = new Document({ sections: [{ children: [new Paragraph({ text: "BỘ HỒ SƠ ĐẤT ĐAI", heading: HeadingLevel.TITLE }), ...lines.map(line => new Paragraph({ children: [new TextRun(line)] }))] }] }); const buffer = await Packer.toBuffer(document); return { fileName: `${safeFileStem}-ban-nhap.docx`, mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", data: buffer.toString("base64"), status: "confirmed-draft" as const, templateProvenance: "metadata-only" as const }; }
      const pdf = await PDFDocument.create();
      pdf.setTitle(`${sectionTitle} - ${title}`);
      pdf.setAuthor("Bat dong san xanh - AI lap ho so");
      const font = await pdf.embedFont(StandardFonts.Helvetica);
      const safePdfText = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D").replace(/[^\x20-\x7E]/g, " ");
      const wrappedLines = lines.flatMap(line => { const safe = safePdfText(line); if (!safe) return [""]; const words = safe.split(/\s+/); const output: string[] = []; let current = ""; for (const word of words) { const candidate = current ? `${current} ${word}` : word; if (candidate.length > 92) { if (current) output.push(current); current = word; } else current = candidate; } if (current) output.push(current); return output; });
      let page = pdf.addPage([595, 842]); let y = 800;
      for (const line of wrappedLines) { if (y < 48) { page = pdf.addPage([595, 842]); y = 800; } page.drawText(line, { x: 40, y, size: 9, font, color: rgb(0.1, 0.2, 0.16) }); y -= 15; }
      const bytesOut = await pdf.save();
      return { fileName: `${safeFileStem}-ban-nhap.pdf`, mimeType: "application/pdf", data: Buffer.from(bytesOut).toString("base64"), status: "confirmed-draft" as const, templateProvenance: "metadata-only" as const };
    }),
  }),
  ai: router({
    optimizeResponsive: adminProcedure.input(z.object({ viewportWidth: z.number().int().min(240).max(5000), viewportHeight: z.number().int().min(240).max(5000), documentWidth: z.number().int().min(0).max(10000), horizontalOverflow: z.boolean(), route: z.string().max(255), visibleSections: z.array(z.string().max(160)).max(30), interactionNotes: z.array(z.string().max(240)).max(20) })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là AI chuyên kiểm toán giao diện web Responsive Mobile-first cho một CRM bất động sản Việt Nam. Phân tích dữ liệu đo được, không bịa lỗi không có dữ liệu. Ưu tiên không tràn ngang, nội dung không bị che, vùng bấm tối thiểu 44px và bố cục một hàng chỉ khi đủ chỗ; nếu không đủ chỗ, đề xuất xuống hàng hợp lý thay vì ép chữ quá nhỏ. Trả JSON tiếng Việt, ngắn gọn, có thể thực thi." },
          { role: "user", content: `Trang: ${input.route}. Viewport: ${input.viewportWidth}x${input.viewportHeight}. Chiều rộng tài liệu: ${input.documentWidth}. Có tràn ngang: ${input.horizontalOverflow ? "Có" : "Không"}. Khu vực đang thấy: ${input.visibleSections.join(", ") || "Chưa xác định"}. Ghi chú thao tác: ${input.interactionNotes.join("; ") || "Không có"}.` },
        ],
        outputSchema: { name: "responsive_ui_audit", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          score: { type: "integer", minimum: 0, maximum: 100 }, summary: { type: "string" }, priority: { type: "string", enum: ["low", "medium", "high"] }, issues: { type: "array", items: { type: "object", additionalProperties: false, properties: { title: { type: "string" }, severity: { type: "string", enum: ["info", "warning", "critical"] }, detail: { type: "string" }, fix: { type: "string" } }, required: ["title", "severity", "detail", "fix"] }, maxItems: 8 }, actions: { type: "array", items: { type: "object", additionalProperties: false, properties: { label: { type: "string" }, target: { type: "string" }, rationale: { type: "string" } }, required: ["label", "target", "rationale"] }, maxItems: 8 }
        }, required: ["score", "summary", "priority", "issues", "actions"] } },
        maxTokens: 1200,
      });
      const content = response.choices?.[0]?.message?.content;
      try { return JSON.parse(typeof content === "string" ? content : JSON.stringify(content || "{}")) as { score: number; summary: string; priority: "low" | "medium" | "high"; issues: Array<{ title: string; severity: "info" | "warning" | "critical"; detail: string; fix: string }>; actions: Array<{ label: string; target: string; rationale: string }> }; }
      catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa tạo được báo cáo Responsive. Vui lòng thử lại." }); }
    }),
    chat: publicProcedure.input(z.object({ messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().trim().min(1).max(4000) })).min(1).max(12), propertyContext: z.string().max(5000).optional() })).mutation(async ({ input }) => {
      const latestUserMessage = [...input.messages].reverse().find(message => message.role === "user")?.content || "";
      let inventory: Array<{ id: number; slug: string; title: string; location: string; price: string; area: string }> = [];
      try {
        const discovered = await listPublishedProperties({ q: latestUserMessage.slice(0, 180), sort: "newest" });
        inventory = discovered.slice(0, 5).map(property => ({ id: property.id, slug: property.slug, title: property.title, location: property.location, price: property.price, area: property.area }));
      } catch {
        inventory = [];
      }
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là Trợ lý AI tư vấn mua bất động sản của Bất động sản xanh. Trả lời tiếng Việt, thân thiện và ngắn gọn. Mục tiêu là hiểu nhu cầu, hỏi từng câu bổ sung còn thiếu về loại BĐS, khu vực, ngân sách, diện tích/phòng ngủ, mục đích và thời điểm mua; sau đó đề xuất đúng những BĐS có trong danh sách dữ liệu được cung cấp. Tuyệt đối không bịa giá, pháp lý, tình trạng sản phẩm hoặc cam kết giao dịch. Nếu chưa đủ thông tin, hãy hỏi một câu tiếp theo thay vì đoán. Nếu khách muốn được gọi lại, đặt lịch hoặc thể hiện ý định mua rõ ràng, đánh dấu shouldHandoff=true và hướng dẫn để lại họ tên/số điện thoại trong biểu mẫu liên hệ; không yêu cầu dữ liệu nhạy cảm khác trong chat. Khi nói về pháp lý, phải ghi rõ chỉ là thông tin tham khảo và cần chuyên viên/cơ quan có thẩm quyền xác nhận. Bối cảnh BĐS: " + (input.propertyContext || "Không có BĐS cụ thể.") + `\nDanh sách BĐS công khai có thể đề xuất: ${JSON.stringify(inventory)}` },
          ...input.messages.map(message => ({ role: message.role, content: message.content })),
        ],
        outputSchema: { name: "public_property_consultation", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          answer: { type: "string" }, followUpQuestion: { type: ["string", "null"] }, shouldHandoff: { type: "boolean" }, priority: { type: "string", enum: ["high", "potential", "reference"] }, capturePrompt: { type: "string" }, suggestedPropertyIds: { type: "array", items: { type: "integer" }, maxItems: 5 }
        }, required: ["answer", "followUpQuestion", "shouldHandoff", "priority", "capturePrompt", "suggestedPropertyIds"] } },
        maxTokens: 900,
      });
      const content = response.choices?.[0]?.message?.content;
      try {
        const result = JSON.parse(typeof content === "string" ? content : JSON.stringify(content || "{}")) as { answer: string; followUpQuestion: string | null; shouldHandoff: boolean; priority: "high" | "potential" | "reference"; capturePrompt: string; suggestedPropertyIds: number[] };
        const matches = inventory.filter(property => result.suggestedPropertyIds.includes(property.id));
        if (result.shouldHandoff && result.priority === "high") {
          await notifyOwner({ title: "🔥 AI phát hiện khách cần môi giới tiếp nhận", content: `Khách đang trò chuyện với Trợ lý AI công khai và có nhu cầu ưu tiên cao.\n${result.answer}\nChưa có thông tin liên hệ; mở mục Yêu cầu tư vấn để theo dõi.` });
        }
        return { ...result, matches };
      } catch {
        throw new TRPCError({ code: "BAD_GATEWAY", message: "Trợ lý AI chưa tạo được câu trả lời. Vui lòng thử lại." });
      }
    }),
    prepareCall: protectedProcedure.input(z.object({ customerName: z.string().trim().min(2).max(120), phone: z.string().trim().min(8).max(30), goal: z.string().trim().min(3).max(500), propertyContext: z.string().max(5000).optional() })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là trợ lý chuẩn bị cuộc gọi cho môi giới bất động sản. Tạo kịch bản ngắn, lịch sự bằng tiếng Việt, không gây áp lực, không cam kết pháp lý/giá. Cuộc gọi chỉ được thực hiện sau khi môi giới xem lại và xác nhận. Nhắc người gọi giới thiệu mình là AI nếu cuộc gọi được tự động hóa." },
          { role: "user", content: `Khách hàng: ${input.customerName}. Số điện thoại: ${input.phone}. Mục tiêu: ${input.goal}. Bối cảnh BĐS: ${input.propertyContext || "Không có"}. Hãy trả về JSON gồm greeting, talkingPoints (mảng tối đa 5 mục), consentLine và closing.` },
        ],
        outputSchema: { name: "call_script", strict: true, schema: { type: "object", additionalProperties: false, properties: { greeting: { type: "string" }, talkingPoints: { type: "array", items: { type: "string" }, maxItems: 5 }, consentLine: { type: "string" }, closing: { type: "string" } }, required: ["greeting", "talkingPoints", "consentLine", "closing"] } },
        maxTokens: 700,
      });
      const content = response.choices?.[0]?.message?.content;
      try { return JSON.parse(typeof content === "string" ? content : JSON.stringify(content || "{}")) as { greeting: string; talkingPoints: string[]; consentLine: string; closing: string }; }
      catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "Chưa tạo được kịch bản gọi. Vui lòng thử lại." }); }
    }),
    analyzeDossier: protectedProcedure.input(z.object({ style: z.enum(["concise", "professional", "facebook"]), property: z.record(z.string(), z.unknown()), steps: z.array(z.object({ stepNumber: z.number().int().min(1).max(12), name: z.string().max(120), status: z.string().max(40), details: z.string().max(10000).nullable().optional(), notes: z.string().max(10000).nullable().optional() })).max(12), documentNames: z.array(z.string().max(180)).max(100).optional() })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là trợ lý nội dung cho sàn Bất động sản xanh tại Đà Nẵng. Phân tích dữ liệu BĐS được cung cấp, chỉ sử dụng thông tin có trong dữ liệu, không bịa giá/vị trí/pháp lý. Không kết luận giấy tờ hợp lệ hay quy hoạch; mọi nhận định pháp lý phải ghi rõ cần chuyên viên kiểm tra. Trả về tiếng Việt, giọng chuyên nghiệp, dễ hiểu." },
          { role: "user", content: `Hãy phân tích hồ sơ sau và tạo bản nháp đăng bán theo phong cách ${input.style === "concise" ? "ngắn gọn, súc tích" : input.style === "professional" ? "chuyên nghiệp, minh bạch" : "tối ưu cho Facebook, dễ đọc, có lời kêu gọi hành động nhưng không phóng đại"}. Dữ liệu tài sản: ${JSON.stringify(input.property)}. Tiến độ 12 bước: ${JSON.stringify(input.steps)}. Tài liệu đã lưu: ${JSON.stringify(input.documentNames || [])}.` },
        ],
        outputSchema: { name: "real_estate_dossier_analysis", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          summary: { type: "string" }, strengths: { type: "array", items: { type: "string" } }, missingInformation: { type: "array", items: { type: "string" } }, warnings: { type: "array", items: { type: "string" } }, listingTitle: { type: "string" }, listingDescription: { type: "string" }, shortCaption: { type: "string" }, hashtags: { type: "array", items: { type: "string" } }
        }, required: ["summary", "strengths", "missingInformation", "warnings", "listingTitle", "listingDescription", "shortCaption", "hashtags"] } },
        maxTokens: 1800,
      });
      const content = response.choices?.[0]?.message?.content;
      const raw = typeof content === "string" ? content : JSON.stringify(content || "{}");
      try { return JSON.parse(raw) as { summary: string; strengths: string[]; missingInformation: string[]; warnings: string[]; listingTitle: string; listingDescription: string; shortCaption: string; hashtags: string[] }; }
      catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa trả về được bản phân tích. Vui lòng thử lại." }); }
    }),
    summarizeLandSearchResult: protectedProcedure.input(z.object({ resultId: z.string().trim().min(1).max(255), title: z.string().trim().min(1).max(255), subtitle: z.string().max(500).optional(), kind: z.enum(["template", "archive", "procedure", "legal"]), content: z.string().trim().min(1).max(12000), procedureId: z.string().max(120).optional(), propertyContext: z.string().max(1000).optional() })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là trợ lý hồ sơ đất đai tại Việt Nam. Chỉ sử dụng dữ liệu được cung cấp, không tự tạo căn cứ pháp luật hoặc khẳng định hồ sơ hợp lệ. Hãy trả về JSON tiếng Việt gồm bản tóm tắt ngắn, checklist tham khảo và bước tiếp theo. Checklist phải phân biệt required (thường cần), conditional (tùy trường hợp) và verify (cần cơ quan/chuyên gia xác nhận). Mọi nội dung đều phải kèm cảnh báo không thay thế tư vấn pháp lý." },
          { role: "user", content: `Kết quả tra cứu: ${input.title}. Loại kết quả: ${input.kind}. Mô tả: ${input.subtitle || "Không có"}. Mã thủ tục: ${input.procedureId || "Không có"}. Nội dung tra cứu: ${input.content}. Bối cảnh BĐS: ${input.propertyContext || "Không có"}.` },
        ],
        outputSchema: { name: "land_search_ai_assist", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          summary: { type: "string" }, checklist: { type: "array", items: { type: "object", additionalProperties: false, properties: { label: { type: "string" }, status: { type: "string", enum: ["required", "conditional", "verify"] }, note: { type: "string" } }, required: ["label", "status", "note"] }, maxItems: 12 }, nextSteps: { type: "array", items: { type: "string" }, maxItems: 6 }, disclaimer: { type: "string" }
        }, required: ["summary", "checklist", "nextSteps", "disclaimer"] } },
        maxTokens: 1500,
      });
      const content = response.choices?.[0]?.message?.content;
      const raw = typeof content === "string" ? content : JSON.stringify(content || "{}");
      try { return JSON.parse(raw) as { summary: string; checklist: Array<{ label: string; status: "required" | "conditional" | "verify"; note: string }>; nextSteps: string[]; disclaimer: string }; }
      catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa tạo được tóm tắt và checklist. Vui lòng thử lại." }); }
    }),
    researchLegal: protectedProcedure.input(z.object({ question: z.string().trim().min(8).max(2000), context: z.string().max(2000).optional() })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là trợ lý nghiên cứu quy trình bất động sản tại Việt Nam. Hãy giải thích bằng tiếng Việt, phân biệt rõ thông tin tham khảo với tư vấn pháp lý. Không khẳng định hồ sơ hợp lệ, không thay thế luật sư/công chứng viên/cơ quan nhà nước. Khi không có nguồn chắc chắn, hãy nói rõ cần kiểm tra văn bản chính thức hiện hành. Trả lời ngắn gọn theo các mục: tóm tắt, checklist thực hiện, điểm cần kiểm tra, nguồn nên đối chiếu." },
          { role: "user", content: `Câu hỏi: ${input.question}\nBối cảnh hồ sơ: ${input.context || "Không có"}` },
        ],
        maxTokens: 1600,
      });
      const content = response.choices?.[0]?.message?.content;
      const answer = typeof content === "string" ? content : JSON.stringify(content || "Không có kết quả.");
      return { answer, sources: ["Cổng thông tin điện tử Chính phủ", "Cơ sở dữ liệu quốc gia về văn bản pháp luật", "Cơ quan đăng ký đất đai/công chứng địa phương"] };
    }),
  }),
  legalKnowledge: router({
    sources: protectedProcedure.query(({ ctx }) => { if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Chỉ quản trị viên được quản lý nguồn pháp lý." }); return listLegalSources(); }),
    procedures: protectedProcedure.input(z.object({ query: z.string().max(180).optional() }).optional()).query(({ input }) => listLegalProcedures(input?.query)),
    officialStatus: protectedProcedure.input(z.object({ code: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional() })).query(async ({ input }) => {
      const registry = getOfficialLandProcedure(input.code, input.province);
      const ensured = await ensureLegalProcedureFromRegistry(input.code).catch(() => undefined);
      const resolvedRegistry = registry || (ensured ? getOfficialLandProcedure(ensured.code, input.province) : undefined);
      if (!resolvedRegistry) return { code: input.code, province: input.province || null, procedure: { verified: false, sourceUrl: null }, legalDocuments: { verified: false, count: 0, items: [] }, templateFile: { verified: false, count: 0, items: [] } } as const;
      let bundle: Awaited<ReturnType<typeof getLegalProcedureBundle>>;
      try {
        await materializeRegistryOnce(resolvedRegistry.code);
        bundle = await getLegalProcedureBundle(resolvedRegistry.code);
      } catch { bundle = undefined; }
      const verifiedLegalDocuments = (resolvedRegistry.legalDocuments || []).filter(document => document.status === "verified");
      const verifiedTemplates = (bundle?.templates || []).filter(item => item.provenance === "verified_binary" || item.provenance === "official").filter(item => Boolean(item.storageKey || item.fileUrl));
      return {
        code: resolvedRegistry.code,
        name: resolvedRegistry.name,
        province: input.province || null,
        procedure: { verified: /^https:\/\//i.test(resolvedRegistry.sourceUrl) && Boolean(resolvedRegistry.sourceUrl), sourceUrl: resolvedRegistry.sourceUrl, sourceName: resolvedRegistry.sourceName, checkedAt: resolvedRegistry.checkedAt, workflowSteps: resolvedRegistry.workflowSteps || [], requirements: resolvedRegistry.requirements || [], referenceTemplates: resolvedRegistry.referenceTemplates || [] },
        legalDocuments: { verified: verifiedLegalDocuments.length > 0, count: verifiedLegalDocuments.length, items: verifiedLegalDocuments },
        templateFile: { verified: verifiedTemplates.length > 0, count: verifiedTemplates.length, items: verifiedTemplates.map(item => ({ id: item.id, name: item.name, format: item.format, sourceUrl: item.sourceUrl, fileUrl: item.fileUrl || null, storageKey: item.storageKey || null, checksum: item.checksum || null, provenance: item.provenance })) },
      } as const;
    }),
    templates: protectedProcedure.input(z.object({ province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional(), jurisdictionScope: z.enum(["national", "provincial", "district", "commune", "agency_specific"]).optional(), procedureId: z.number().int().positive().optional(), procedureCode: z.string().trim().max(80).optional(), query: z.string().trim().max(180).optional() }).optional()).query(({ input }) => listLegalTemplates(input)),
    suggestTemplates: protectedProcedure.input(z.object({ procedureId: z.number().int().positive(), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional() })).query(({ ctx, input }) => { if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Chỉ quản trị viên được ghép biểu mẫu pháp lý." }); return suggestLegalTemplates(input); }),
    bundle: protectedProcedure.input(z.object({ code: z.string().trim().min(2).max(80) })).query(async ({ input }) => {
      const ensured = await ensureLegalProcedureFromRegistry(input.code).catch(() => undefined);
      const canonicalCode = ensured?.code || getOfficialLandProcedure(input.code)?.code || input.code;
      await materializeRegistryOnce(canonicalCode);
      return getLegalProcedureBundle(canonicalCode);
    }),
    uploadUserTemplateByComponent: protectedProcedure.input(z.object({ procedureCode: z.string().trim().min(2).max(80), componentLabel: z.string().trim().min(1).max(255), requirementId: z.number().int().positive().optional(), fileName: z.string().trim().min(1).max(255), mimeType: z.enum(["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "image/jpeg", "image/png"]), data: z.string().min(1).max(14_000_000), notes: z.string().trim().max(1000).optional() })).mutation(async ({ input, ctx }) => {
      const procedure = getOfficialLandProcedure(input.procedureCode);
      const legalBundle = await getLegalProcedureBundle(input.procedureCode);
      if (!procedure || !legalBundle) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy thủ tục trong registry hoặc Kho pháp lý AI." });
      const bytes = Buffer.from(input.data, "base64");
      if (!bytes.length || bytes.length > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp phải lớn hơn 0 và không vượt quá 10MB." });
      const signatures = { pdf: bytes.subarray(0, 4).toString() === "%PDF", docx: bytes.subarray(0, 2).toString() === "PK", image: bytes.subarray(0, 3).toString("hex") === "ffd8ff" || bytes.subarray(0, 8).toString("hex") === "89504e470d0a1a0a" };
      const format = input.mimeType === "application/pdf" ? "pdf" : input.mimeType.includes("wordprocessingml") ? "docx" : "scan" as const;
      const validSignature = format === "pdf" ? signatures.pdf : format === "docx" ? signatures.docx : signatures.image;
      if (!validSignature) throw new TRPCError({ code: "BAD_REQUEST", message: "Chữ ký tệp không khớp với MIME; tệp được giữ ngoài Official." });
      const { createHash } = await import("node:crypto");
      const checksum = createHash("sha256").update(bytes).digest("hex");
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const stored = await storagePut(`legal-user-uploads/${ctx.user.id}/${input.procedureCode}/${checksum}-${safeName}`, bytes, input.mimeType);
      const saved = await upsertUserUploadLegalTemplate({ userId: ctx.user.id, procedureId: legalBundle.procedure.id, name: input.fileName, documentType: input.componentLabel, format, storageKey: stored.key, fileUrl: stored.url, checksum, componentLabel: input.componentLabel, requirementId: input.requirementId, notes: input.notes });
      return { success: true, procedureCode: input.procedureCode, componentLabel: input.componentLabel, templateId: saved.templateId, checksum, fileUrl: stored.url, provenance: "metadata_only" as const, status: "reference_user_upload" as const, nextAction: "AI có thể dùng file để dựng hồ sơ; cần kiểm tra thủ công trước khi nộp." };
    }),
    uploadVerifiedBinary: adminProcedure.input(z.object({ templateId: z.number().int().positive(), fileName: z.string().trim().min(1).max(255), mimeType: z.enum(["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]), data: z.string().min(1).max(14_000_000), sourceUrl: z.string().url().max(1000), documentNumber: z.string().trim().max(120).optional(), versionLabel: z.string().trim().max(80).optional(), effectiveFrom: z.string().date().optional(), effectiveTo: z.string().date().optional(), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional(), notes: z.string().trim().max(1000).optional() })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (!bytes.length || bytes.length > 10 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp mẫu phải lớn hơn 0 và không vượt quá 10MB." });
      const isPdf = input.mimeType === "application/pdf" && bytes.subarray(0, 4).toString() === "%PDF";
      const isDocx = input.mimeType.includes("wordprocessingml") && bytes.subarray(0, 2).toString() === "PK";
      if (!isPdf && !isDocx) throw new TRPCError({ code: "BAD_REQUEST", message: "Chữ ký tệp không khớp với MIME DOCX/PDF. Mẫu chưa được xác minh." });
      const { createHash } = await import("node:crypto");
      const checksum = createHash("sha256").update(bytes).digest("hex");
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const format = isPdf ? "pdf" : "docx";
      const stored = await storagePut(`legal-templates/${ctx.user.id}/${input.templateId}/${checksum}-${safeName}`, bytes, input.mimeType);
      await updateLegalTemplateBinary(input.templateId, { storageKey: stored.key, fileUrl: stored.url, checksum, format, provenance: "verified_binary", status: "active", province: input.province || undefined, receivingAuthority: input.receivingAuthority || undefined, versionLabel: input.versionLabel || undefined, effectiveFrom: input.effectiveFrom ? new Date(input.effectiveFrom) : undefined, effectiveTo: input.effectiveTo ? new Date(input.effectiveTo) : undefined, notes: `Đã kiểm tra binary bởi quản trị viên ${ctx.user.id}; nguồn: ${input.sourceUrl}${input.documentNumber ? `; số hiệu: ${input.documentNumber}` : ""}${input.versionLabel ? `; phiên bản: ${input.versionLabel}` : ""}${input.notes ? `; ghi chú: ${input.notes}` : ""}` });
      return { success: true, templateId: input.templateId, checksum, format, fileUrl: stored.url, provenance: "verified_binary" as const };
    }),
    approveBinaryCandidate: adminProcedure.input(z.object({ templateId: z.number().int().positive(), notes: z.string().trim().max(1000).optional() })).mutation(async ({ input, ctx }) => {
      const stored = await getLegalTemplateWithFields(input.templateId);
      if (!stored || stored.template.provenance !== "metadata_only" || stored.template.status !== "needs_review" || !stored.template.storageKey || !stored.template.checksum) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Mẫu chưa ở trạng thái Pending có binary và checksum để phê duyệt." });
      }
      const signedUrl = await storageGetSignedUrl(stored.template.storageKey);
      const response = await fetch(signedUrl);
      if (!response.ok) throw new TRPCError({ code: "BAD_GATEWAY", message: `Không đọc được binary Pending từ storage (${response.status}).` });
      const bytes = Buffer.from(await response.arrayBuffer());
      const { createHash } = await import("node:crypto");
      const checksum = createHash("sha256").update(bytes).digest("hex");
      if (checksum !== stored.template.checksum) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Checksum binary trong storage không khớp metadata; giữ nguyên trạng thái Pending." });
      const sourceNotes = stored.template.notes || "";
      const trustedSource = /https:\/\/(?:www\.)?(?:[^\s/]+\.)?(?:gov\.vn|vbpl\.vn|(?:cdn)?chinhphu\.vn)(?:[/:\s]|$)/i.test(sourceNotes);
      if (!trustedSource) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Chưa xác minh được nguồn Chính phủ/VBPL trong metadata mẫu; hãy bổ sung URL nguồn chính thức trước khi duyệt." });
      const inspection = await inspectVerifiedTemplate({
        id: String(stored.template.id),
        fileName: stored.template.name,
        format: stored.template.format as "docx" | "pdf",
        mimeType: stored.template.format === "pdf" ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        sourceUrl: sourceNotes.match(/https:\/\/[^;\s]+/i)?.[0] || "https://invalid.local",
        sourceCheckedAt: new Date().toISOString(),
        sourceStatus: "verified",
        sha256: stored.template.checksum,
        storageKey: stored.template.storageKey,
      }, bytes, stored.fields.map(field => ({ label: field.label, value: "" })));
      if (!inspection.fillable) throw new TRPCError({ code: "PRECONDITION_FAILED", message: inspection.warning || "Mẫu chưa có trường điền tự động; chưa thể tạo bản Official tự động." });
      await updateLegalTemplateBinary(input.templateId, {
        format: stored.template.format,
        checksum: stored.template.checksum,
        provenance: "verified_binary",
        status: "active",
        notes: `${stored.template.notes || ""}\nĐã phê duyệt thành Verified Binary bởi quản trị viên ${ctx.user.id} ngày 2026-08-19.${input.notes ? ` Ghi chú: ${input.notes}` : ""}`.trim(),
      });
      return { success: true, templateId: input.templateId, checksum, provenance: "verified_binary" as const, status: "active" as const };
    }),
    searchDocuments: adminProcedure.input(z.object({ query: z.string().trim().min(2).max(180) })).mutation(async ({ input }) => {
      const items = await searchLegalDocuments(input.query);
      return { query: input.query.trim(), items, notice: items.some(item => !item.warning) ? "Kết quả được lọc theo miền chính thức .gov.vn/.vbpl.vn. Hãy mở và xác nhận văn bản cụ thể trước khi lưu; AI không tự gắn Official." : "Chưa lấy được kết quả chi tiết tự động. Các nguồn gợi ý bên dưới chỉ là điểm bắt đầu để bạn xác nhận." };
    }),
    discoverReceivingAuthorities: protectedProcedure.input(z.object({ procedureId: z.string().trim().min(2).max(80), province: z.string().trim().min(1).max(120), district: z.string().trim().max(120).optional(), ward: z.string().trim().max(120).optional() })).query(async ({ input }) => {
      const officialCode = OFFICIAL_DISCOVERY_PROCEDURE_CODES[input.procedureId] || input.procedureId;
      return discoverDvcReceivingAuthorities({ procedureCode: officialCode, province: input.province, district: input.district, ward: input.ward });
    }),
    listAllDvcSources: protectedProcedure.query(() => ({
      checkedAt: "2026-08-21",
      sources: DVC_SOURCE_REGISTRY.map(source => ({ id: source.id, authority: source.authority, tier: source.tier, scope: source.scope, administrativeLevel: source.administrativeLevel, province: source.province || null, sourceUrl: source.sourceUrl, discoveryOnly: Boolean(source.discoveryOnly), procedureCount: Object.keys(source.procedureUrls || {}).length, note: source.note || null })),
      provinceCoverage: DVC_PROVINCE_COVERAGE,
      notice: "Danh mục nguồn đã đăng ký để discovery. Chỉ binary có provenance nguồn, MIME phù hợp và SHA-256 hợp lệ mới được xét Official.",
    })),
    listDvcSources: protectedProcedure.input(z.object({ procedureId: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional() })).query(({ input }) => {
      const officialCode = resolveDiscoveryProcedureCode(input.procedureId, input.province);
      if (!officialCode) return { sources: [], provinces: listRegisteredDvcProvinces(), notice: "Chưa có mã thủ tục trong registry nguồn DVC." };
      return { sources: getDvcSourcesForProcedure({ procedureCode: officialCode, province: input.province, receivingAuthority: input.receivingAuthority }), provinces: listRegisteredDvcProvinces(), notice: "Nguồn DVC được lấy từ registry đã kiểm tra; binary vẫn phải qua xác minh." };
    }),
    autoDiscoverDvcBinaryCandidates: adminProcedure.input(z.object({ procedureId: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional() })).mutation(async ({ input }) => {
      const officialCode = resolveDiscoveryProcedureCode(input.procedureId, input.province);
      const procedure = officialCode ? getOfficialLandProcedure(officialCode, input.province) : undefined;
      if (!procedure) throw new TRPCError({ code: "NOT_FOUND", message: "Chưa có thủ tục trong registry nguồn DVC." });
      const sources = getDvcSourcesForProcedure({ procedureCode: officialCode!, province: input.province, receivingAuthority: input.receivingAuthority });
      const results = [];
      for (const source of sources) {
        try {
          const [result, dvcScan] = await Promise.all([
            discoverOfficialTemplateCandidates({ sourceUrl: source.sourceUrl, procedureName: procedure.name, procedureAliases: procedure.aliases, templateNames: procedure.referenceTemplates.map(item => item.name), templateCodes: procedure.referenceTemplates.map(item => item.documentType) }),
            scanDvcProcedureSource({ procedureCode: officialCode!, province: input.province }),
          ]);
          const scannedCandidates = dvcScan.attachments
            .filter((attachment): attachment is typeof attachment & { kind: "docx" | "pdf" } => attachment.kind === "docx" || attachment.kind === "pdf")
            .map(attachment => ({ url: attachment.url, fileName: attachment.name, format: attachment.kind, score: attachment.status === "verified_binary" ? 100 : 0, matchedKeywords: attachment.componentId ? [attachment.componentId] : [], discovery: "dvc_instructions" as const, status: attachment.status, checksum: attachment.checksum, storageKey: attachment.storageKey, fileUrl: attachment.fileUrl, fillable: attachment.fillable, verificationError: attachment.verificationError, componentId: attachment.componentId }));
          results.push({ source, ...result, dvcScan, candidates: Array.from(new Map([...result.candidates, ...scannedCandidates].map(item => [item.url, item])).values()) });
        } catch (error) {
          results.push({ source, keywords: [], candidates: [], dvcScan: null, error: error instanceof Error ? error.message : "Không thể đọc nguồn DVC." });
        }
      }
      const candidates = results.flatMap(item => item.candidates.map(candidate => ({ ...candidate, province: input.province || null, receivingAuthority: input.receivingAuthority || procedure.authority, sourceUrl: item.source.sourceUrl })));
      const scans = results.filter(item => item.dvcScan).map(item => item.dvcScan);
      const dossierComponents = Array.from(new Map(scans.flatMap(scan => scan!.dossierComponents).map(item => [item.name.toLocaleLowerCase("vi"), item])).values());
      const attachments = Array.from(new Map(scans.flatMap(scan => scan!.attachments).map(item => [item.url, item])).values());
      return { procedure: { code: procedure.code, name: procedure.name, authority: input.receivingAuthority || procedure.authority }, sources, results, scans, dossierComponents, attachments, candidates: Array.from(new Map(candidates.map(item => [item.url, item])).values()), notice: attachments.some(item => item.status === "verified_binary") ? `AI đã tự tải và lưu ${attachments.filter(item => item.status === "verified_binary").length} binary từ phần Thành phần hồ sơ; các file đã qua kiểm tra định dạng/SHA-256 nhưng chưa tự gắn Official.` : attachments.some(item => item.status === "failed") ? `AI đã phát hiện ${attachments.length} URL binary nhưng tải hoặc xác minh chưa thành công; xem lỗi từng file và có thể chạy lại discovery.` : dossierComponents.length ? "Đã trích xuất thành phần hồ sơ từ phần Hướng dẫn DVC nhưng chưa phát hiện binary DOCX/PDF trực tiếp." : "AI đã quét nguồn DVC nhưng chưa phát hiện binary hoặc thành phần hồ sơ chi tiết; cần mở hướng dẫn địa phương nếu có." };
    }),
    autoDiscoverBinaryCandidates: adminProcedure.input(z.object({ procedureId: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional() })).mutation(async ({ input }) => {
      const officialCode = resolveDiscoveryProcedureCode(input.procedureId, input.province);
      const procedure = officialCode ? getOfficialLandProcedure(officialCode, input.province) : undefined;
      if (!procedure) throw new TRPCError({ code: "NOT_FOUND", message: "Chưa có nguồn thủ tục chính thức đã lập registry cho lựa chọn này." });
      try {
        const result = await discoverOfficialTemplateCandidates({ sourceUrl: procedure.sourceUrl, procedureName: procedure.name, procedureAliases: procedure.aliases, templateNames: procedure.referenceTemplates.map(item => item.name), templateCodes: procedure.referenceTemplates.map(item => item.documentType) });
        return { ...result, procedure: { code: procedure.code, name: procedure.name, sourceUrl: procedure.sourceUrl, authority: input.receivingAuthority || procedure.authority }, notice: result.candidates.length ? "AI đã tự quét nguồn thủ tục và tìm thấy binary ứng viên. Các tệp chỉ được gắn Official sau khi vượt cổng kiểm tra nguồn, checksum và fillability." : "AI đã quét nguồn chính thức nhưng chưa phát hiện liên kết DOCX/PDF trực tiếp; cần mở nguồn để kiểm tra tệp đính kèm." };
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Không thể tự quét mẫu từ nguồn thủ tục." });
      }
    }),
    findBinaryCandidates: adminProcedure.input(z.object({ sourceUrl: z.string().url().max(1000), keywords: z.array(z.string().trim().min(1).max(80)).min(1).max(12) })).mutation(async ({ input }) => {
      try {
        const candidates = await findOfficialTemplateCandidates(input);
        return { candidates, notice: candidates.length ? "Đã tìm thấy binary ứng viên từ miền nguồn được phép. Chưa có tệp nào được coi là Official." : "Không tìm thấy liên kết DOCX/PDF trực tiếp trong nguồn này." };
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Không thể tìm binary từ nguồn này." });
      }
    }),
    downloadBinaryCandidate: adminProcedure.input(z.object({ templateId: z.number().int().positive(), candidateUrl: z.string().url().max(1200), sourceUrl: z.string().url().max(1200), fileName: z.string().trim().max(255).optional(), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional(), versionLabel: z.string().trim().max(80).optional(), effectiveFrom: z.string().date().optional(), effectiveTo: z.string().date().optional(), notes: z.string().trim().max(1000).optional() })).mutation(async ({ input, ctx }) => {
      try {
        const downloaded = await downloadOfficialTemplateCandidate({ candidateUrl: input.candidateUrl, originalFileName: input.fileName });
        const stored = await storagePut(`legal-template-candidates/${ctx.user.id}/${input.templateId}/${downloaded.checksum}-${downloaded.fileName.replace(/[^a-zA-Z0-9._-]/g, "-")}`, downloaded.bytes, downloaded.contentType);
        await updateLegalTemplateBinary(input.templateId, { storageKey: stored.key, fileUrl: stored.url, checksum: downloaded.checksum, format: downloaded.contentType === "application/pdf" ? "pdf" : "docx", provenance: "metadata_only", status: "needs_review", province: input.province || undefined, receivingAuthority: input.receivingAuthority || undefined, versionLabel: input.versionLabel || undefined, effectiveFrom: input.effectiveFrom ? new Date(input.effectiveFrom) : undefined, effectiveTo: input.effectiveTo ? new Date(input.effectiveTo) : undefined, notes: `AI tự tải binary ứng viên; CHƯA XÁC MINH Official. Nguồn trang: ${input.sourceUrl}; liên kết tệp: ${downloaded.sourceUrl}; checksum SHA-256: ${downloaded.checksum}${input.notes ? `; ghi chú: ${input.notes}` : ""}` });
        return { success: true, templateId: input.templateId, fileName: downloaded.fileName, checksum: downloaded.checksum, fileUrl: stored.url, provenance: "metadata_only" as const, status: "needs_review" as const, notice: "Binary đã lưu vào khu chờ xác minh. Cần quản trị viên kiểm tra nội dung, nguồn, phiên bản và phạm vi trước khi chuyển Official." };
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "Không thể tải binary ứng viên." });
      }
    }),
    searchOfficial: protectedProcedure.input(z.object({ query: z.string().trim().max(180).optional(), code: z.string().trim().max(80).optional(), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional() })).query(({ input }) => {
      const result = input.code ? getOfficialLandProcedure(input.code, input.province) : undefined;
      const candidates = result ? [result] : searchOfficialLandProcedures(input.query || "", input.province);
      const items = input.receivingAuthority ? candidates.filter(item => item.authority.toLowerCase().includes(input.receivingAuthority!.toLowerCase()) || !item.authority) : candidates;
      return { checkedAt: officialRegistryCheckedAt, items, notice: "Kết quả là tham chiếu nguồn chính thức đã lập registry; tệp binary vẫn cần kiểm tra hash và trạng thái hiệu lực trước khi gắn Official." };
    }),
    analyzeSourceUrl: adminProcedure.input(z.object({ url: z.string().trim().url().max(1000) })).mutation(async ({ input }) => {
      const analysis = await analyzeLegalSourceUrl(input.url);
      return { ...analysis, requiresConfirmation: true, provenanceStatus: analysis.attachments.length ? "candidate_attachments_found" as const : "metadata_only" as const, notice: "AI chỉ trích xuất dữ liệu để bạn kiểm tra. Chưa tự gắn Official và chưa tự lưu nguồn cho đến khi quản trị viên xác nhận." };
    }),
    ingestText: adminProcedure.input(z.object({ sourceName: z.string().trim().min(2).max(180), sourceType: z.enum(["government", "public_service", "local_authority", "official_gazette", "other"]), baseUrl: z.string().url().max(1000), sourceUrl: z.string().url().max(1000), title: z.string().trim().min(2).max(255), documentNumber: z.string().max(120).optional(), text: z.string().trim().max(120000).optional(), province: z.string().max(120).optional(), receivingAuthority: z.string().max(255).optional(), originalFileName: z.string().max(255).optional(), mimeType: z.string().max(120).optional(), fileDataBase64: z.string().max(8_000_000).optional() } )).mutation(async ({ input, ctx }) => {
      let extractedText = input.text?.trim() || "";
      let ocrWarnings: string[] = [];
      let ocrConfidence: number | null = null;
      if (input.fileDataBase64) {
        const bytes = Buffer.from(input.fileDataBase64, "base64");
        if (bytes.length > 6 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp pháp lý tối đa 6 MB." });
        const fileName = input.originalFileName || "";
        const mime = input.mimeType || "";
        const scanLike = /image\/(png|jpe?g|webp)/i.test(mime) || /\.(png|jpe?g|webp)$/i.test(fileName);
        const pdfLike = /application\/pdf/i.test(mime) || /\.pdf$/i.test(fileName);
        if (!extractedText || /\.(pdf|docx)$/i.test(fileName) || /pdf|wordprocessingml/i.test(mime)) {
          try { extractedText = await extractLegalFileText(bytes, mime, fileName); }
          catch (error) {
            if (!scanLike && !pdfLike) throw error;
            extractedText = "";
          }
        }
        if (extractedText.length < 200 && (scanLike || pdfLike)) {
          const vision = await extractLegalFileWithVision(bytes, mime, fileName);
          extractedText = vision.text;
          ocrConfidence = vision.confidence;
          ocrWarnings = vision.warnings;
        }
      }
      if (extractedText.length < 200) throw new TRPCError({ code: "BAD_REQUEST", message: "AI chưa đọc được tối thiểu 200 ký tự. Hãy tải tệp rõ hơn hoặc cung cấp nội dung rõ hơn." });
      if (extractedText.length > 120000) extractedText = extractedText.slice(0, 120000);
      const source = await createLegalSource({ name: input.sourceName, baseUrl: input.baseUrl, sourceType: input.sourceType, jurisdiction: input.province || null, active: 1, lastCheckedAt: new Date(), notes: "Nguồn do quản trị viên cung cấp; cần đối chiếu bản gốc trước khi nâng provenance." });
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là hệ thống chuẩn hóa dữ liệu pháp luật đất đai Việt Nam. Chỉ trích xuất nội dung có trong văn bản được cung cấp; không suy đoán, không tự thêm căn cứ. Trả JSON tiếng Việt. Mọi biểu mẫu chưa có tệp nhị phân phải đánh dấu metadata_only." },
          { role: "user", content: `Nguồn: ${input.sourceName}\nSố hiệu: ${input.documentNumber || "không rõ"}\nĐịa phương: ${input.province || "không rõ"}\nTiêu đề: ${input.title}\nURL: ${input.sourceUrl}\nNội dung:\n${extractedText}` },
        ],
        response_format: { type: "json_schema", json_schema: { name: "legal_knowledge_ingest", strict: true, schema: { type: "object", additionalProperties: false, properties: {
          documentType: { type: "string" }, issuingBody: { type: "string" }, effectiveFrom: { type: ["string", "null"] }, effectiveTo: { type: ["string", "null"] }, warnings: { type: "array", items: { type: "string" }, maxItems: 12 }, procedures: { type: "array", items: { type: "object", additionalProperties: false, properties: { code: { type: "string" }, name: { type: "string" }, groupName: { type: "string" }, aliases: { type: "array", items: { type: "string" } }, authority: { type: ["string", "null"] }, processingTime: { type: ["string", "null"] }, conditions: { type: "array", items: { type: "string" } }, workflow: { type: "array", items: { type: "string" } }, requirements: { type: "array", items: { type: "object", additionalProperties: false, properties: { label: { type: "string" }, requirementType: { type: "string", enum: ["document", "field", "condition", "fee", "instruction"] }, required: { type: "boolean" }, fieldKey: { type: ["string", "null"] }, notes: { type: ["string", "null"] } }, required: ["label", "requirementType", "required", "fieldKey", "notes"] } }, templates: { type: "array", items: { type: "object", additionalProperties: false, properties: { name: { type: "string" }, documentType: { type: "string" }, format: { type: "string", enum: ["docx", "pdf", "html", "scan"] }, versionLabel: { type: ["string", "null"] }, notes: { type: ["string", "null"] } }, required: ["name", "documentType", "format", "versionLabel", "notes"] } } }, required: ["code", "name", "groupName", "aliases", "authority", "processingTime", "conditions", "workflow", "requirements", "templates"] } }, maxItems: 20 }, required: ["documentType", "issuingBody", "effectiveFrom", "effectiveTo", "warnings", "procedures"] } } },
        maxTokens: 6000,
      });
      const content = response.choices?.[0]?.message?.content; const raw = typeof content === "string" ? content : JSON.stringify(content || "{}");
      let parsed: { documentType: string; issuingBody: string; effectiveFrom: string | null; effectiveTo: string | null; warnings: string[]; procedures: Array<{ code: string; name: string; groupName: string; aliases: string[]; authority: string | null; processingTime: string | null; conditions: string[]; workflow: string[]; requirements: Array<{ label: string; requirementType: "document" | "field" | "condition" | "fee" | "instruction"; required: boolean; fieldKey: string | null; notes: string | null }>; templates: Array<{ name: string; documentType: string; format: "docx" | "pdf" | "html" | "scan"; versionLabel: string | null; notes: string | null }> }> };
      try { parsed = JSON.parse(raw) as typeof parsed; } catch { throw new TRPCError({ code: "BAD_GATEWAY", message: "AI chưa chuẩn hóa được văn bản. Vui lòng kiểm tra nội dung hoặc thử lại." }); }
      let storedFile: { key: string; url: string } | null = null;
      let contentHash: string | null = null;
      if (input.fileDataBase64) {
        const bytes = Buffer.from(input.fileDataBase64, "base64");
        if (bytes.length > 6 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp pháp lý tối đa 6 MB." });
        const { createHash } = await import("node:crypto");
        contentHash = createHash("sha256").update(bytes).digest("hex");
        storedFile = await storagePut(`legal-knowledge/${ctx.user.id}/${Date.now()}-${input.originalFileName || "source"}`, bytes, input.mimeType || "application/octet-stream");
      }
      const document = await (async () => { return createLegalDocument({ sourceId: source.id, title: input.title, documentNumber: input.documentNumber || null, documentType: parsed.documentType, issuingBody: parsed.issuingBody, sourceUrl: input.sourceUrl, fileUrl: storedFile?.url || null, storageKey: storedFile?.key || null, mimeType: input.mimeType || "text/plain", contentText: extractedText, contentHash, status: "extracted", effectiveFrom: parsed.effectiveFrom ? new Date(parsed.effectiveFrom) : null, effectiveTo: parsed.effectiveTo ? new Date(parsed.effectiveTo) : null, checkedAt: new Date(), extractedBy: "built-in-llm", warnings: JSON.stringify([...(parsed.warnings || []), ...ocrWarnings, ...(ocrConfidence !== null && ocrConfidence < 75 ? [`Độ tin cậy OCR ${ocrConfidence}%, cần đối chiếu bản gốc.`] : [])]) }); })();
      const created = []; for (const item of parsed.procedures || []) { const procedure = await createLegalProcedure({ code: item.code, name: item.name, groupName: item.groupName, aliases: JSON.stringify(item.aliases || []), authority: item.authority, defaultProvince: input.province || null, processingTime: item.processingTime, feeNotes: null, conditions: JSON.stringify(item.conditions || []), workflow: JSON.stringify(item.workflow || []), status: "needs_review", sourceDocumentIds: JSON.stringify([document.id]), lastReviewedAt: new Date() }); for (let i = 0; i < (item.requirements || []).length; i++) { const r = item.requirements[i]; await createLegalRequirement({ procedureId: procedure.id, sortOrder: i, label: r.label, requirementType: r.requirementType, required: r.required ? 1 : 0, fieldKey: r.fieldKey, sourceDocumentId: document.id, notes: r.notes }); } for (const template of item.templates || []) await createLegalTemplate({ procedureId: procedure.id, sourceId: source.id, name: template.name, documentType: template.documentType, format: template.format, sourceUrl: input.sourceUrl, storageKey: null, fileUrl: null, sourceDocumentId: document.id, province: input.province || null, receivingAuthority: input.receivingAuthority || null, jurisdictionScope: input.receivingAuthority ? "agency_specific" : input.province ? "provincial" : "national", provenance: "metadata_only", checksum: null, versionLabel: template.versionLabel, effectiveFrom: parsed.effectiveFrom ? new Date(parsed.effectiveFrom) : null, effectiveTo: parsed.effectiveTo ? new Date(parsed.effectiveTo) : null, status: "needs_review", notes: template.notes }); created.push({ code: item.code, name: item.name }); }
      return { sourceId: source.id, documentId: document.id, procedures: created, warnings: [...(parsed.warnings || []), ...ocrWarnings], ocrConfidence, provenance: "metadata_only" as const, message: "Đã lưu dữ liệu trích xuất vào CSDL. Cần quản trị viên rà soát nguồn và biểu mẫu trước khi sử dụng." };
    }),
  }),
  sourceWorkflow: router({
    ocr: protectedProcedure.input(z.object({
      sourceLabel: z.string().trim().min(1).max(120),
      stepTitle: z.string().trim().min(1).max(180),
      fileName: z.string().trim().min(1).max(255),
      mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "application/pdf"]),
      data: z.string().min(1).max(16_000_000),
      fields: z.array(z.object({ id: z.string().trim().min(1).max(120), label: z.string().trim().min(1).max(180) })).max(50),
    })).mutation(async ({ input, ctx }) => {
      const bytes = Buffer.from(input.data, "base64");
      if (bytes.byteLength > 12 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Tệp OCR không được vượt quá 12MB." });
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      const uploaded = await storagePut(`source-workflow/${ctx.user.id}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      const media = input.mimeType.startsWith("image/")
        ? { type: "image_url" as const, image_url: { url: `data:${input.mimeType};base64,${input.data}`, detail: "high" as const } }
        : { type: "file_url" as const, file_url: { url: `data:${input.mimeType};base64,${input.data}`, mime_type: "application/pdf" as const } };
      const requestedFields = input.fields.map(field => `${field.id} | ${field.label}`).join("\\n");
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "Bạn là OCR hồ sơ bất động sản Việt Nam. Chỉ trích xuất thông tin nhìn thấy trong tài liệu, không suy đoán. Trả JSON đúng schema; trường không đọc được để chuỗi rỗng và ghi cảnh báo." },
          { role: "user", content: [{ type: "text", text: `Nguồn: ${input.sourceLabel}. Bước: ${input.stepTitle}.\\nCác trường cần nhận diện (id | nhãn):\\n${requestedFields}\\nHãy ánh xạ thông tin nhìn thấy vào đúng id trường.` }, media] },
        ],
        response_format: { type: "json_schema", json_schema: { name: "source_workflow_ocr", strict: true, schema: { type: "object", additionalProperties: false, properties: { fields: { type: "array", maxItems: 50, items: { type: "object", additionalProperties: false, properties: { key: { type: "string" }, label: { type: "string" }, value: { type: "string" }, confidence: { type: "number", minimum: 0, maximum: 1 }, evidence: { type: "string" } }, required: ["key", "label", "value", "confidence", "evidence"] } }, warnings: { type: "array", maxItems: 12, items: { type: "string" } }, overallConfidence: { type: "number", minimum: 0, maximum: 1 } }, required: ["fields", "warnings", "overallConfidence"] } } },
        maxTokens: 2600,
      });
      const content = response.choices?.[0]?.message?.content;
      try {
        const contentText = typeof content === "string"
          ? content
          : Array.isArray(content)
            ? content.map(part => {
                if (typeof part === "string") return part;
                const partRecord = part && typeof part === "object" ? part as { text?: unknown } : undefined;
                return typeof partRecord?.text === "string" ? partRecord.text : "";
              }).join("")
            : content && typeof content === "object" && "text" in content && typeof (content as { text?: unknown }).text === "string"
              ? String((content as { text: string }).text)
              : JSON.stringify(content || "{}");
        const extracted = JSON.parse(contentText) as { fields?: Array<{ key?: string; label?: string; value?: string; confidence?: number; evidence?: string }>; warnings?: string[]; overallConfidence?: number };
        return {
          fileName: input.fileName,
          mimeType: input.mimeType,
          storageKey: uploaded.key,
          fileUrl: uploaded.url,
          fields: (extracted.fields || []).map(field => ({ key: String(field.key || ""), label: String(field.label || ""), value: String(field.value || ""), confidence: Math.min(1, Math.max(0, Number(field.confidence) || 0)), evidence: String(field.evidence || "") })),
          warnings: Array.isArray(extracted.warnings) ? extracted.warnings.slice(0, 12).map(String) : [],
          overallConfidence: Math.min(1, Math.max(0, Number(extracted.overallConfidence) || 0)),
          reviewed: false,
          warning: "OCR chỉ đề xuất dữ liệu. Hãy đối chiếu bản gốc và xác nhận trước khi chuyển bước.",
        };
      } catch {
        throw new TRPCError({ code: "BAD_GATEWAY", message: "OCR chưa trả về dữ liệu có cấu trúc. Vui lòng thử lại với ảnh/PDF rõ hơn." });
      }
    }),
  }),
  aiLandDossierAdmin: router({
    versionHistory: adminProcedure.input(z.object({ code: z.string().trim().min(2).max(80) })).query(async ({ input }) => {
      const bundle = await getLegalProcedureBundle(input.code);
      if (!bundle) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy thủ tục trong kho pháp lý." });
      const versions = await listLegalProcedureVersions(bundle.procedure.id);
      return { procedure: bundle.procedure, versions };
    }),
    createVersion: adminProcedure.input(z.object({ code: z.string().trim().min(2).max(80), sourceUrl: z.string().url().max(1200), sourceHash: z.string().trim().max(128).optional(), snapshotKey: z.string().trim().max(500).optional(), workflow: z.array(z.object({ id: z.string().min(1).max(80), title: z.string().min(1).max(240), description: z.string().max(1000).optional(), requirementIds: z.array(z.number().int().positive()).max(50).optional() })).max(50), requirements: z.array(z.record(z.string(), z.unknown())).max(100), effectiveFrom: z.string().date().optional(), status: z.enum(["discovered", "reviewed", "active", "superseded"]).default("discovered") })).mutation(async ({ input }) => {
      const bundle = await getLegalProcedureBundle(input.code);
      if (!bundle) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy thủ tục trong kho pháp lý." });
      const created = await saveLegalProcedureVersion({ procedureId: bundle.procedure.id, sourceUrl: input.sourceUrl, sourceHash: input.sourceHash || null, snapshotKey: input.snapshotKey || null, workflowJson: JSON.stringify(input.workflow), requirementsJson: JSON.stringify(input.requirements), effectiveFrom: input.effectiveFrom ? new Date(input.effectiveFrom) : null, status: input.status });
      return { ...created, procedureId: bundle.procedure.id };
    }),
    templateMappings: adminProcedure.input(z.object({ procedureId: z.number().int().positive() })).query(({ input }) => listLegalTemplateMappings(input.procedureId)),
    saveTemplateMappings: adminProcedure.input(z.object({ procedureId: z.number().int().positive(), mappings: z.array(z.object({ requirementId: z.number().int().positive().optional(), templateId: z.number().int().positive(), mapping: z.record(z.string(), z.unknown()), confidence: z.number().int().min(0).max(100), status: z.enum(["suggested", "reviewed", "approved", "rejected"]).default("suggested") })).max(100) })).mutation(async ({ input, ctx }) => {
      const result = await saveLegalTemplateMappings(input.mappings.map(item => ({ procedureId: input.procedureId, requirementId: item.requirementId || null, templateId: item.templateId, mappingJson: JSON.stringify(item.mapping), confidence: item.confidence, status: item.status, reviewedAt: item.status === "approved" || item.status === "rejected" ? new Date() : null, reviewedBy: item.status === "approved" || item.status === "rejected" ? ctx.user.id : null })));
      return result;
    }),
    dossierAudits: adminProcedure.input(z.object({ dossierId: z.number().int().positive() })).query(({ input }) => listLandDossierAudits(input.dossierId)),
    appendAudit: adminProcedure.input(z.object({ dossierId: z.number().int().positive(), action: z.string().trim().min(1).max(120), status: z.enum(["passed", "warning", "blocked"]), evidence: z.record(z.string(), z.unknown()).optional() })).mutation(({ input, ctx }) => appendLandDossierAudit({ dossierId: input.dossierId, action: input.action, status: input.status, evidenceJson: input.evidence ? JSON.stringify(input.evidence) : null, actorId: ctx.user.id })),
    crawlerStatus: adminProcedure.input(z.object({ code: z.string().trim().min(2).max(80), province: z.string().trim().max(120).optional(), receivingAuthority: z.string().trim().max(255).optional() })).query(async ({ input }) => {
      const registry = getOfficialLandProcedure(input.code, input.province);
      const sources = getDvcSourcesForProcedure({ procedureCode: input.code, province: input.province, receivingAuthority: input.receivingAuthority });
      const history = registry ? await listLegalProcedureVersions((await getLegalProcedureBundle(input.code))?.procedure.id || 0) : [];
      return { code: input.code, registryFound: Boolean(registry), checkedAt: registry?.checkedAt || officialRegistryCheckedAt, sources, versions: history, sourceCount: sources.length, notice: registry ? "Registry và nguồn DVC sẵn sàng để quét." : "Chưa có registry cho mã thủ tục; cần bổ sung nguồn trước khi đồng bộ." };
    }),
  }),
});
export type AppRouter = typeof appRouter;
