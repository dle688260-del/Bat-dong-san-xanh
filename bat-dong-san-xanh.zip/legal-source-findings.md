# Kết quả xác minh nguồn biểu mẫu gốc

Ngày kiểm tra: 2026-08-18.

## Nguồn đã xác minh

Cổng Thông tin điện tử Chính phủ có trang chính thức cho **Thông tư 10/2024/TT-BTNMT** của Bộ Tài nguyên và Môi trường tại:

https://vanban.chinhphu.vn/?pageid=27160&docid=210905&classid=1

Thông tin hiển thị trên trang: số ký hiệu 10/2024/TT-BTNMT; ngày ban hành 31-07-2024; ngày hiệu lực 01-08-2024; cơ quan ban hành Bộ Tài nguyên và Môi trường; trích yếu quy định về hồ sơ địa chính, Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất.

Trang có mục **Tài liệu đính kèm** và tệp `10-btnmt.pdf`. Điều này xác nhận giả định của người dùng là đúng ở mức nguồn: văn bản/tệp gốc có thể được công khai để tải từ cổng chính thức. Tuy nhiên, tệp đang là PDF của toàn văn thông tư; cần đọc phụ lục để xác định chính xác mẫu nào có thể dùng cho từng thủ tục, không được suy đoán chỉ từ tên tệp.

## Quy tắc triển khai

Kho hệ thống sẽ lưu URL nguồn, cơ quan, số hiệu, ngày ban hành, ngày hiệu lực, ngày kiểm tra, MIME, kích thước và SHA-256 của tệp. Chỉ khi tải thành công, loại tệp hợp lệ, hash ổn định, đọc được nội dung và đối chiếu được số hiệu/phụ lục thì mới gắn `verified-binary`. Nguồn LuatVietnam hoặc thư viện pháp luật được dùng để đối chiếu/giải thích; nhãn Official ưu tiên nguồn Chính phủ, Bộ, Cục Thuế hoặc cổng dịch vụ công của cơ quan tiếp nhận.

## Giới hạn cần giữ

Biểu mẫu công khai không đồng nghĩa mọi tệp đều là mẫu áp dụng cho mọi tỉnh/thành hoặc mọi thời điểm. Sau khi tự điền, hệ thống vẫn phải hiển thị nguồn, phiên bản và cảnh báo người dùng kiểm tra với cơ quan tiếp nhận trước khi ký/nộp. Không được tải tự động hoặc coi là chính thức nếu nguồn yêu cầu đăng nhập, CAPTCHA, hoặc không xác minh được quyền truy cập/tính toàn vẹn tệp.
