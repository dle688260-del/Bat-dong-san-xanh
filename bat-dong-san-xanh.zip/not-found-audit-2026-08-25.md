# Rà soát Not Found sau khi tách storefront và CRM

- Domain production: https://batdongsan-7bupubgw.manus.space/
- Kiểm tra bằng trình duyệt ngày 2026-08-25.
- `/crm/login` hiển thị đúng màn hình “Đăng nhập quản trị”, URL giữ nguyên `/crm/login`, không hiển thị Not Found.
- `/` hiển thị đúng storefront với logo, danh mục, nguồn hàng, CTA và biểu mẫu công khai.
- Kiểm tra local server sau rollback/khôi phục: `/`, `/crm`, `/crm/login`, `/bat-dong-san` đều HTTP 200.
- Manifest storefront: `start_url: /`, `scope: /`.
- Manifest CRM: `start_url: /crm`, `scope: /crm`.
- Bản phát hành hiện tại có route tách theo namespace `/crm/*`; nếu điện thoại vẫn báo Not Found sau khi đã cài app cũ, nguyên nhân có thể là shortcut/PWA cũ hoặc người dùng mở sai domain/URL, không phải route production hiện tại.

## Kiểm tra biến thể URL mobile

Trình duyệt production cũng mở thành công cả `/crm/` và `/crm/login/`. `/crm/` hiển thị trang yêu cầu đăng nhập CRM; `/crm/login/` hiển thị đầy đủ biểu mẫu đăng nhập quản trị. Không tái hiện được lỗi Not Found trên các biến thể URL này. Điều này cho thấy nếu điện thoại của người dùng vẫn báo Not Found thì cần xử lý bộ nhớ đệm/shortcut PWA cũ hoặc mở nhầm domain cũ; URL production hiện tại đã phản hồi đúng.

## Tái kiểm tra sau phản hồi người dùng

Ngày 2026-08-25, production tại `/crm/login` tiếp tục hiển thị đúng màn hình đăng nhập CRM trong trình duyệt sandbox. Service worker đang ở trạng thái `activated`, dùng scope toàn domain và cache `bdsxanh-shell-v2`. Vì vậy lỗi người dùng gặp có khả năng liên quan đến cache/shortcut trên thiết bị cá nhân hoặc biểu tượng app cũ, dù URL production hiện tại trả về đúng nội dung.
