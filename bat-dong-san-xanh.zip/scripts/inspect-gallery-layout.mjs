import fs from "node:fs";
const path = "client/src/pages/BrokerageAdmin.tsx";
const text = fs.readFileSync(path, "utf8");
const needles = ["function BrokerageForm", "const BrokerageForm", "listingDetails", "uploadedImages", "imageUrls", "PropertyPostingTemplate", "uploadMedia"];
const out = [];
for (const needle of needles) {
  const index = text.indexOf(needle);
  if (index >= 0) out.push(`\n--- ${needle} @ ${index} ---\n${text.slice(Math.max(0, index - 900), Math.min(text.length, index + 1800))}`);
}
fs.writeFileSync("/tmp/gallery-layout-snippets.txt", out.join("\n"));
