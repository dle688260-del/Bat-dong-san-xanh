import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");

describe("property media asset upload contract", () => {
  it("stores media under a property-scoped S3 prefix and archives metadata", () => {
    expect(routerSource).toContain("uploadPropertyMediaAsset:");
    expect(routerSource).toContain("property-media/${input.propertyId}/${ctx.user.id}");
    expect(routerSource).toContain('category: "marketing"');
    expect(routerSource).toContain("documentType: `Media BĐS · ${input.assetType}`");
  });

  it("accepts 3D formats needed by Polycam/LiDAR workflows", () => {
    expect(routerSource).toContain("const property3dMime =");
    expect(routerSource).toContain("gltf");
    expect(routerSource).toContain("ply");
    expect(routerSource).toContain("e57");
    expect(routerSource).toContain('z.enum(["video", "image", "360", "3d"])');
  });

  it("keeps explicit size limits for video, 3D, and images", () => {
    expect(routerSource).toContain("50 * 1024 * 1024");
    expect(routerSource).toContain("100 * 1024 * 1024");
    expect(routerSource).toContain("15 * 1024 * 1024");
  });

  it("exposes property-scoped 3D annotation CRUD with bounded coordinates", () => {
    expect(routerSource).toContain("property3dAnnotations:");
    expect(routerSource).toContain("listProperty3dAnnotations");
    expect(routerSource).toContain("createProperty3dAnnotation");
    expect(routerSource).toContain("updateProperty3dAnnotation");
    expect(routerSource).toContain("deleteProperty3dAnnotation");
    expect(routerSource).toContain("positionX: z.number().min(-10).max(10)");
    expect(routerSource).toContain("assetUrl: z.string().url().max(4000)");
  });

  it("requires broker review for AI storyboard output", () => {
    expect(routerSource).toContain("analyzePropertyMediaAsset:");
    expect(routerSource).toContain("property_media_storyboard");
    expect(routerSource).toContain("requiresBrokerApproval");
    expect(routerSource).toContain('status: "needs_review"');
  });
});
