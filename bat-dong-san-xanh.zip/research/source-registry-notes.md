# Ghi chú nguồn pháp lý đã đăng ký

Các URL dưới đây đã có trong `server/dvcSourceRegistry.ts` hoặc `server/officialLandProcedureRegistry.ts`; chỉ dùng để discovery/provenance theo đúng nhãn, không tự suy đoán binary.

- DVC Quốc gia: https://vpcp.dichvucong.gov.vn
- DVC Quốc gia — mã 1.012784: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784
- DVC Bộ — lĩnh vực đất đai: https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8
- DVC Bộ — mã 2.002317: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67
- DVC Bộ — mã 1.004278: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=69
- Cổng Chính phủ — hệ thống văn bản: https://chinhphu.vn/he-thong-van-ban
- Cổng Chính phủ — Luật Đất đai: https://chinhphu.vn/?pageid=27160&docid=211189&classid=1&typegroupid=3
- Cục Quản lý đất đai — danh sách văn bản: https://qldd.mae.gov.vn/danh-sach-van-ban.htm
- Cổng Chính phủ — bài mẫu 01/ĐK: https://xaydungchinhsach.chinhphu.vn/mau-don-de-nghi-tach-thua-dat-hop-thua-dat-119240801152947547.htm
- CDN binary mẫu 01/ĐK đã đăng ký: https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/don-17225006379202035387597.docx
- DVC Hà Nội: https://dichvucong.hanoi.gov.vn
- DVC TP.HCM: https://dichvucong.hochiminhcity.gov.vn
- HCC Đà Nẵng: https://hcc.danang.gov.vn
- Cổng đất đai TP.HCM: https://hcm.mplis.gov.vn/og

Quy tắc: nguồn trang thủ tục, văn bản pháp lý và binary mẫu là ba lớp độc lập. Chỉ binary tải được từ host được allowlist, đúng định dạng/chữ ký và có SHA-256/provenance mới được gắn Official. Nguồn discovery hoặc metadata-only giữ Pending/Reference.
