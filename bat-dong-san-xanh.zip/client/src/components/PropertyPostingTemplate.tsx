import React, { useState } from "react";
import { ArrowUpRight, ChevronLeft, ChevronRight, Facebook, Image as ImageIcon, MapPin, MessageCircle, Phone, RotateCcw } from "lucide-react";
import { Link } from "wouter";
import { MapView } from "@/components/Map";

export type GalleryLayout = "single" | "split" | "mosaic";

export type PostingTemplateData = {
  title: string;
  location: string;
  typeLabel: string;
  price: string;
  pricePerM2: string;
  area: string;
  frontage?: string;
  depth?: string;
  orientation?: string;
  roadWidth?: string;
  bedrooms?: string;
  bathrooms?: string;
  legalItems?: string[];
  images?: string[];
  galleryLayout?: GalleryLayout;
  latitude?: number | null;
  longitude?: number | null;
  detailHref?: string;
  phone?: string;
  zalo?: string;
  onSelect?: () => void;
  density?: "default" | "compact";
};

const fallbackImage = "";

export function readGalleryLayout(value: unknown): GalleryLayout {
  if (value === "split" || value === "mosaic" || value === "single") return value;
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value) as Record<string, unknown>;
      const layout = parsed.galleryLayout;
      if (layout === "split" || layout === "mosaic" || layout === "single") return layout;
    } catch {
      // Older listings may store plain or invalid JSON; use the safe default.
    }
  }
  if (value && typeof value === "object") {
    const layout = (value as Record<string, unknown>).galleryLayout;
    if (layout === "split" || layout === "mosaic" || layout === "single") return layout;
  }
  return "single";
}

function GalleryImage({ src, alt, className = "", eager = false }: { src: string; alt: string; className?: string; eager?: boolean }) {
  const [failed, setFailed] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  if (!src || failed) return <div className={`flex h-full flex-col items-center justify-center gap-2 bg-[#dfe7df] px-4 text-center text-xs font-semibold text-[#567064] ${className}`} role="img" aria-label={failed ? `${alt} không tải được` : alt}><ImageIcon size={36} /><span>Ảnh chưa tải được</span>{src && <button type="button" onClick={() => { setFailed(false); setRetryKey(value => value + 1); }} className="inline-flex items-center gap-1 rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-black text-[#1F5A4A] shadow-sm" aria-label={`Tải lại ${alt}`}><RotateCcw size={13} /> Tải lại ảnh</button>}</div>;
  return <img key={`${src}-${retryKey}`} src={src} alt={alt} loading={eager ? "eager" : "lazy"} decoding="async" fetchPriority={eager ? "high" : "low"} onError={() => setFailed(true)} className={`h-full w-full object-cover ${className}`} />;
}

export function PropertyPostingTemplate({
  title, location, typeLabel, price, pricePerM2, area, frontage, depth, orientation, roadWidth,
  bedrooms, bathrooms, legalItems = [], images = [], galleryLayout = "single", latitude, longitude, detailHref = "#", phone = "0989682825",
  zalo = "https://zalo.me/0989682825", onSelect, density = "default",
}: PostingTemplateData) {
  const [active, setActive] = useState(0);
  const [showMap, setShowMap] = useState(false);
  const gallery = images.length ? images : [fallbackImage];
  const hasMap = latitude !== null && latitude !== undefined && longitude !== null && longitude !== undefined;
  const details = [
    ["Ngang × dài", frontage && depth ? `${frontage} × ${depth} m` : "Đang cập nhật"],
    ["Hướng", orientation || "Đang cập nhật"],
    ["Đường", roadWidth ? `${roadWidth} m` : "Đang cập nhật"],
    ["Phòng ngủ", bedrooms || "Đang cập nhật"],
    ["Phòng vệ sinh", bathrooms || "Đang cập nhật"],
  ];
  const primaryLegalItems = legalItems.filter(item => /^(Pháp lý|Vay vốn)/i.test(item));
  const secondaryLegalItems = legalItems.filter(item => !/^(Pháp lý|Vay vốn)/i.test(item));
  const visibleLayout = galleryLayout === "split" && gallery.length > 1 ? "split" : galleryLayout === "mosaic" && gallery.length > 2 ? "mosaic" : "single";
  const renderGallery = () => {
    if (showMap) return <MapView className="h-full w-full" initialCenter={{ lat: latitude!, lng: longitude! }} initialZoom={15} onMapReady={map => { new window.google!.maps.Marker({ map, position: { lat: latitude!, lng: longitude! }, title }); }} />;
    if (visibleLayout === "split") return <div className="grid h-full grid-cols-2 gap-1"><GalleryImage src={gallery[0]} alt={`${title} 1`} eager /><GalleryImage src={gallery[1]} alt={`${title} 2`} /></div>;
    if (visibleLayout === "mosaic") return <div className="grid h-full grid-cols-2 grid-rows-2 gap-1"><div className="row-span-2"><GalleryImage src={gallery[0]} alt={`${title} 1`} eager /></div><GalleryImage src={gallery[(active + 1) % gallery.length]} alt={`${title} 2`} /><GalleryImage src={gallery[(active + 2) % gallery.length]} alt={`${title} 3`} /></div>;
    return <GalleryImage src={gallery[active]} alt={title} eager />;
  };
  const compact = density === "compact";
  return <article className={`h-full overflow-hidden rounded-2xl border border-[#DCE9E1] bg-white shadow-[0_8px_24px_rgba(18,62,49,.08)] ${compact ? "[&_.property-title]:text-[22px] [&_.property-price]:text-[28px]" : ""}`}>
      <div className={compact ? "p-3 sm:p-3.5" : "p-4 sm:p-5"}>
      <div className="relative flex items-start gap-3"><div className="min-w-0 flex-1 pr-20 sm:pr-24"><p className="flex line-clamp-2 items-start gap-1.5 break-words text-[15px] font-black leading-6 text-[#42675A]"><MapPin size={18} className="mt-0.5 shrink-0 text-[#1F5A4A]" /><span>{location}</span></p><h2 className="property-title mt-1 line-clamp-2 text-[27px] font-black leading-[1.05] tracking-[-.035em] text-[#123C2F] sm:text-[32px]">{title}</h2></div><span className="absolute right-0 top-0 shrink-0 rounded-full bg-[#F4D06F] px-3 py-1.5 text-[12px] font-black text-[#123C2F]">{typeLabel}</span></div>
      <div className="mt-4 flex items-end justify-between gap-3"><div><strong className="property-price block text-[34px] font-black leading-none tracking-[-.055em] text-[#1F5A4A] sm:text-[40px]">{price}</strong><span className="mt-2 block text-[15px] font-black leading-5 text-[#687A72]">Giá/m² · {pricePerM2}</span></div><span className="rounded-xl bg-[#EDF6F0] px-3 py-2 text-[17px] font-black text-[#17483B]">{area} m²</span></div>
      <div className="mt-4 grid grid-cols-5 gap-x-1.5 gap-y-1 border-b border-[#DCE7E0] pb-3 sm:gap-x-2">{details.map(([label, value]) => <div key={label} className="min-w-0"><p className="truncate text-[9px] font-semibold leading-[1.15] text-[#65766E] sm:text-[11px]">{label}</p><p className="mt-0.5 truncate text-[12px] font-black leading-[1.15] text-[#123C2F] sm:text-[15px]">{value}</p></div>)}</div>
      {primaryLegalItems.length > 0 && <div className="mt-3 flex flex-nowrap items-center gap-2 overflow-x-auto pb-1 [scrollbar-width:thin]">{primaryLegalItems.map(item => <span key={item} className="inline-flex shrink-0 rounded-full bg-[#EEF6F1] px-3 py-1.5 text-[12px] font-bold text-[#1F5A4A]">{item}</span>)}</div>}
      {secondaryLegalItems.length > 0 && <div className="mt-2 flex flex-wrap gap-2">{secondaryLegalItems.map(item => <span key={item} className="inline-flex max-w-full rounded-full bg-[#EEF6F1] px-3 py-1.5 text-[12px] font-bold text-[#1F5A4A]">{item}</span>)}</div>}
      <div className={`relative mt-3 overflow-hidden rounded-xl bg-[#dfe7df] ${compact ? "h-[200px] sm:h-[240px]" : "h-[320px] sm:h-[420px]"}`}>{renderGallery()}<span className="absolute left-3 top-3 rounded-full bg-[#F4D06F] px-3 py-1.5 text-sm font-black text-[#123C2F]">{showMap ? "Vị trí" : visibleLayout === "split" ? "2 ảnh" : visibleLayout === "mosaic" ? "3+ ảnh" : `Ảnh ${active + 1}/${gallery.length}`}</span>{hasMap && <button type="button" onClick={() => setShowMap(value => !value)} className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-white/95 px-3 py-2 text-sm font-black text-[#1F5A4A]"><MapPin size={16} /> {showMap ? "Ảnh" : "Vị trí"}</button>}{!showMap && visibleLayout === "single" && gallery.length > 1 && <><button type="button" onClick={() => setActive(index => (index - 1 + gallery.length) % gallery.length)} aria-label="Ảnh trước" className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-[#1F5A4A]"><ChevronLeft size={22} /></button><button type="button" onClick={() => setActive(index => (index + 1) % gallery.length)} aria-label="Ảnh tiếp theo" className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-[#1F5A4A]"><ChevronRight size={22} /></button></>}</div>
      <div className="mt-3 flex w-full flex-nowrap items-center gap-1 sm:gap-1.5"><Link href={detailHref} onClick={onSelect} className="inline-flex min-h-10 min-w-0 flex-1 items-center justify-center gap-0.5 rounded-full bg-[#1F5A4A] px-1.5 text-[12px] font-black text-white sm:min-h-11 sm:gap-1 sm:px-2 sm:text-[14px]">Xem chi tiết <ArrowUpRight size={15} /></Link><a href={`tel:${phone}`} onClick={event => event.stopPropagation()} className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[#1F5A4A] sm:min-h-11 sm:min-w-11" title="Gọi" aria-label="Gọi"><Phone size={16} /></a><a href={zalo} target="_blank" rel="noreferrer" onClick={event => event.stopPropagation()} className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[11px] font-black text-[#1F5A4A] sm:min-h-11 sm:min-w-11 sm:text-[12px]" aria-label="Zalo">Zalo</a><a href="https://m.me/" target="_blank" rel="noreferrer" onClick={event => event.stopPropagation()} className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[#1F5A4A] sm:min-h-11 sm:min-w-11" title="Messenger" aria-label="Messenger"><MessageCircle size={16} /></a><a href="https://www.facebook.com/" target="_blank" rel="noreferrer" onClick={event => event.stopPropagation()} className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full border border-[#D6DEDA] text-[#1F5A4A] sm:min-h-11 sm:min-w-11" title="Facebook" aria-label="Facebook"><Facebook size={16} /></a></div>
    </div>
  </article>;
}
