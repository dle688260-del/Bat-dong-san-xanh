CREATE TABLE `admin_auth_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(120) NOT NULL,
	`passwordHash` text NOT NULL,
	`passwordVersion` int NOT NULL DEFAULT 1,
	`changedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `admin_auth_settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `admin_auth_settings_username_unique` UNIQUE(`username`)
);
