import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("manual legal sync progress contract", () => {
  const routerSource = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
  const pageSource = readFileSync(resolve(process.cwd(), "client/src/pages/AiLandDossierAutoModule.tsx"), "utf8");

  it("exposes an admin-only one-procedure sync contract with file stages", () => {
    expect(routerSource).toContain("syncProcedure: adminProcedure");
    expect(routerSource).toContain('key: "discovery"');
    expect(routerSource).toContain('key: "download"');
    expect(routerSource).toContain('key: "checksum"');
    expect(routerSource).toContain('key: "storage"');
    expect(routerSource).toContain('key: "mapping"');
    expect(routerSource).toContain('classification: file.status === "verified_binary" ? "Official"');
  });

  it("keeps batch procedure failures isolated from the tRPC response", () => {
    expect(routerSource).toContain("batchSyncAll: adminProcedure");
    expect(routerSource).toContain("try {\n          const files = []");
    expect(routerSource).toContain('classification: "Pending" as const');
    expect(routerSource).toContain('error: message');
    expect(routerSource).toContain("Alternate-source discovery is best effort");
    expect(routerSource).toContain("snapshot: { ...snapshot, warnings:");
    expect(routerSource).toContain("let recoverySnapshot");
    expect(routerSource).toContain("const preservedBundle = recoveryBundle ||");
    expect(routerSource).toContain("recoverySnapshot?.dossierComponents");
  });

  it("ranks alternate candidates by official source priority and match score", () => {
    expect(routerSource).toContain("const sourcePriority = (url: string)");
    expect(routerSource).toContain('host.includes("dichvucong.gov.vn")');
    expect(routerSource).toContain(".sort((a, b) => {");
    expect(routerSource).toContain("sourcePriority(a.url)");
    expect(routerSource).toContain("matchedKeywords?.length");
  });

  it("builds the batch catalog from database rows plus registry-backed entries", () => {
    expect(routerSource).toContain("const dbProcedures = await listLegalProcedures()");
    expect(routerSource).toContain("const catalogCodes = mergeLegalProcedureCatalog(");
    expect(routerSource).toContain("registered.map((item, index) => ({ id: -(index + 1), code: item.code");
  });

  it("does not truncate server batch catalog at the old 66-procedure limit", () => {
    expect(routerSource).toContain('.max(2000).optional()');
    expect(routerSource).toContain('Array.from(new Set((input?.procedureCodes?.length ? input.procedureCodes : catalogCodes).map(code => getOfficialLandProcedure(code)?.code ?? code)))');
    expect(routerSource).not.toContain('catalogCodes)).slice(0, 66)');
    expect(routerSource).not.toContain('registeredCodes)).slice(0, 66)');
  });

  it("renders the manual trigger and preserves Official/Reference separation", () => {
    expect(pageSource).toContain("Đồng bộ ngay");
    expect(pageSource).toContain("trpc.aiAutoDossier.syncProcedure.useMutation");
    expect(routerSource).toContain('key: "components"');
    expect(routerSource).toContain('key: "candidate"');
    expect(pageSource).toContain("dynamicPipeline");
    expect(pageSource).toContain('file.classification === "Official"');
    expect(pageSource).toContain("Reference/Pending");
  });
});
