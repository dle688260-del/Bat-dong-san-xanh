# Nghiên cứu tích hợp đăng bài đa kênh

## Facebook Pages API
Tài liệu Meta cho biết có thể tạo, xuất bản, cập nhật và xóa bài trên Facebook Page qua Pages API. Luồng cần Facebook Login, Page access token và các quyền như `pages_manage_engagement`, `pages_manage_posts`, `pages_read_engagement`, `pages_read_user_engagement`; đăng video cần thêm `publish_video`. Ứng dụng/người dùng phải có các nhiệm vụ `CREATE_CONTENT`, `MANAGE` và `MODERATE` trên Page. Có thể đăng ngay hoặc lên lịch trong khoảng 10 phút đến 30 ngày, và đăng ảnh qua endpoint `/page_id/photos`.

Nguồn: https://developers.facebook.com/documentation/pages-api/posts

## Zalo OA OpenAPI
Trang tài liệu Zalo OA đã mở nhưng nội dung động không được trích xuất đầy đủ trong phiên hiện tại. Cần xác minh thêm endpoint chính thức trước khi cam kết tính năng đăng bài công khai. Phạm vi chắc chắn cần kiểm tra là Zalo Official Account, quyền ứng dụng và khả năng gửi tin nhắn/thông báo; không nên giả định rằng API cho phép đăng bài lên trang cá nhân Zalo.

Nguồn: https://developers.zalo.me/docs/api/official-account-api-230

## TikTok Content Posting API
TikTok có Content Posting API cho phép đăng trực tiếp video và ảnh lên tài khoản người dùng được ủy quyền. Cần ứng dụng đã đăng ký, bật sản phẩm Content Posting API, được duyệt scope `video.publish` và người dùng ủy quyền scope đó. Ảnh phải đến từ domain hoặc URL prefix đã xác minh; video có thể tải tệp hoặc kéo từ URL. Ứng dụng chưa audit sẽ bị giới hạn nội dung ở chế độ riêng tư, vì vậy muốn đăng công khai cần hoàn tất audit của TikTok.

Nguồn: https://developers.tiktok.com/doc/content-posting-api-get-started

## YouTube Data API
YouTube Data API `videos.insert` cho phép tải video và đặt metadata như tiêu đề, mô tả, thẻ, danh mục và trạng thái riêng tư/công khai. Cần OAuth với một trong các scope upload phù hợp, đặc biệt `https://www.googleapis.com/auth/youtube.upload`. Đây là kênh phù hợp cho video giới thiệu BĐS, không phải đăng bài văn bản/ảnh đơn thuần.

Nguồn: https://developers.google.com/youtube/v3/docs/videos/insert

## Google Business Profile
Google Business Profile APIs có resource `accounts.locations.localPosts` với các phương thức tạo, xóa, đọc, liệt kê, cập nhật và xem insight bài đăng địa phương. API cũng có resource media để quản lý hình ảnh. Đây là hình thức đăng cập nhật lên Hồ sơ doanh nghiệp Google Search/Maps, không phải đăng lên một mạng xã hội cá nhân.

Nguồn: https://developers.google.com/my-business/reference/rest
