
## Nguồn phát hiện ngày 2026-08-20

Các nguồn nhà nước cần tiếp tục mở và quét: Cổng Dịch vụ công Quốc gia với thủ tục 1.013978 (`https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978`), thủ tục 1.012783 (`https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783`), và thủ tục 2.000410 (`https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410`).

Nguồn Chính phủ: bài về Mẫu Đơn đăng ký đất đai, tài sản gắn liền với đất (`https://xaydungchinhsach.chinhphu.vn/mau-don-dang-ky-dat-dai-tai-san-gan-lien-voi-dat-119240801160735957.htm`). Nguồn Bộ Tư pháp người dùng gửi: `https://htpldn.moj.gov.vn/Pages/chi-tiet-tin.aspx?ItemID=24&l=Phobienphapluatkinh`.

Kết quả tìm kiếm cũng trả về các nguồn tư nhân như LuatVietnam, Thư viện pháp luật, Luật Duy Hưng, Maison Office và file CDN của Thư viện pháp luật. Các nguồn này chỉ là Reference/Pending trừ khi có thể truy nguyên trực tiếp tới công bố của cơ quan nhà nước; không gắn Official chỉ dựa trên kết quả tìm kiếm.

Mẫu số 15.docx được phát hiện tại `https://cdn.thuvienphapluat.vn/uploads/tintuc/2025/06/17/M%E1%BA%ABu%20s%E1%BB%91%2015.docx`, nhưng domain không phải cơ quan nhà nước nên cần giữ Reference/Pending cho tới khi xác minh được nguồn công bố gốc.

## Kết quả đọc nguồn chính thức

Trang Chính phủ về đăng ký đất đai (`https://xaydungchinhsach.chinhphu.vn/mau-don-dang-ky-dat-dai-tai-san-gan-lien-voi-dat-119240801160735957.htm`) công bố bài ngày 02/08/2024, nêu Mẫu số 04/ĐK theo Nghị định 101/2024/NĐ-CP và có liên kết DOCX trực tiếp: `https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkydatdai-17225027906701732310327.docx`. Đây là nguồn Chính phủ; cần tải và checksum file.

Trang Chính phủ về tách/hợp thửa (`https://xaydungchinhsach.chinhphu.vn/thu-tuc-tach-thua-hoac-hop-thua-dat-moi-nhat-119250727085442592.htm`) công bố theo Quyết định 2304/QĐ-BNNMT ngày 23/06/2025. Trang nêu thành phần hồ sơ gồm Đơn đề nghị tách/hợp thửa Mẫu số 21 và Bản vẽ Mẫu số 22 ban hành kèm Nghị định 151/2025/NĐ-CP; 01 bộ hồ sơ; thời hạn tối đa 12 ngày, hoặc 22 ngày tại vùng khó khăn; điều kiện theo Điều 220 Luật Đất đai và diện tích tối thiểu do UBND cấp tỉnh quy định. Trang cũng mô tả Mẫu 21 với nội dung tách/hợp thửa và yêu cầu bản vẽ Mẫu 22.

DVC 1.013978 khi trích xuất chỉ hiển thị đăng nhập, chưa lấy được nội dung chi tiết. DVC 1.012783 trích xuất được thủ tục cấp đổi Giấy chứng nhận và có nhiều thời hạn theo trường hợp; chưa thấy liên kết binary trong phần đã đọc.

Phân loại hiện tại: link DOCX CDN thuộc Chính phủ là ứng viên Official cần checksum; bài Chính phủ là Official Procedure/Legal source; DVC bị hạn chế trích xuất nên binary chưa được gắn Official nếu chưa tải và xác minh thực tế.

### File đã tải và kiểm tra

- File: `mau-04-dk-chinh-phu.docx`
- URL nguồn: `https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkydatdai-17225027906701732310327.docx`
- MIME/file signature: Microsoft Word 2007+ (DOCX)
- SHA-256: `08eb8df5ad3d38f81751b751e024a581625723db72b3e8edbda4f8c7587e1500`
- Nội dung XML xác nhận tiêu đề `Mẫu số 04/ĐK` và tên `Đơn đăng ký đất đai, tài sản gắn liền với đất`, dùng cho đăng ký đất đai/tài sản gắn liền với đất lần đầu. File này là ứng viên Official cho nhóm thủ tục đăng ký lần đầu, không phải tự động gắn cho thủ tục tách/hợp thửa hay đăng ký biến động.

### File đã tải và kiểm tra — Mẫu 11/ĐK

- File: `mau-11-dk-chinh-phu.docx`
- URL nguồn công bố: `https://xaydungchinhsach.chinhphu.vn/mau-don-dang-ky-bien-dong-dat-dai-tai-san-gan-lien-voi-dat-119240801154458481.htm`
- URL tải trực tiếp: `https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkybiendongdat-17225018464101254582634.docx`
- MIME/file signature: Microsoft Word 2007+ (DOCX)
- SHA-256: `6d029d2c8bc920380de658dfc4e69cb2ecc19261c4ff6fbc9f3579da4774026c`
- Nội dung XML xác nhận `Mẫu số 11/ĐK` và `Đơn đăng ký biến động đất đai, tài sản gắn liền với đất`.
- Phân loại: ứng viên Official binary cho nhóm đăng ký biến động; cần đối chiếu thủ tục cụ thể và hiệu lực áp dụng trước khi gắn Official toàn hệ thống.

## DVC Quốc gia – nhóm thủ tục đất đai bổ sung

- Cung cấp thông tin, dữ liệu đất đai — mã 1.012789: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
- Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận lần đầu — mã 1.013978: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
- Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất — mã 1.012783: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783
- Đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, tài sản gắn liền với đất — mã 1.011441: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441
- Xóa đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, tài sản gắn liền với đất — mã 1.011443: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011443
- Đăng ký biến động quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất — mã 2.000410: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410
- Nguồn dịch vụ công chuyên ngành liên quan cung cấp thông tin dữ liệu đất đai: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67

Ghi chú: Các URL trên là nguồn chính thức cần đưa vào hàng đợi discovery. DVC có thể yêu cầu phiên hoặc giới hạn trích xuất; trong trường hợp đó, chỉ file tải được và xác minh được mới được nâng Official.

## Bổ sung quét DVC Quốc gia — 2026-08-20

### Mã 1.011441 — đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, tài sản gắn liền với đất
- URL DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441
- Trang trả về tên thủ tục, nơi tiếp nhận là Văn phòng đăng ký đất đai/Sở hoặc Chi nhánh, và hiển thị liên kết `Mau so 01a_QSDT, TSGLVD.docx` thuộc miền `csdl.dichvucong.gov.vn`.
- Lần mở chi tiết tiếp theo bị chặn bởi tiện ích trình duyệt (`ERR_BLOCKED_BY_CLIENT`), nên URL binary đầy đủ và checksum chưa được xác minh trong phiên này.
- Chỉ ghi nhận URL thủ tục là Official Procedure URL; mẫu DOCX giữ Pending/Reference cho đến khi tải được binary và tính SHA-256.

## Kết quả trích xuất DVC Quốc gia — 2026-08-20

Các trang DVC chính thức đã đọc qua bộ trích xuất nội dung:

| Mã | Thủ tục | Mẫu/tệp phát hiện | URL tải từ DVC | Phân loại hiện tại |
|---|---|---|---|---|
| 1.012789 | Cung cấp thông tin, dữ liệu đất đai | Phiếu yêu cầu theo Mẫu 14, 14a, 14b, 14c, 14d, 14đ; liên kết `Mus14a14b14c14d.docx` | https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fd87368b77cb67c | Ứng viên Official; cần tải binary và SHA-256 |
| 1.013978 | Đăng ký đất đai, cấp Giấy chứng nhận lần đầu | `Mus15DKLD.docx`; nội dung cũng viện dẫn Mẫu 16, 17, 19 theo Nghị định 151/2025/NĐ-CP | https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1 | Ứng viên Official; cần tải binary và SHA-256 |
| 1.012783 | Cấp đổi Giấy chứng nhận | Trang DVC đã đọc được quy trình, nhưng phần trích xuất bị cắt trước bảng thành phần hồ sơ; chưa ghi nhận URL binary trong kết quả hiện tại | https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783 | Official Procedure URL; mẫu Pending |
| 2.000410 | Đăng ký biến động trong chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn... | Mẫu 09/ĐK PDF và Mẫu 10/ĐK PDF | https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe998b4cf4ed90a ; https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe2f78f7bc72401 | Ứng viên Official; cần tải binary và SHA-256 |

Nguồn trang thủ tục tương ứng: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789 ; https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978 ; https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783 ; https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410.

Ghi chú pháp lý dữ liệu: DVC nêu cơ quan tiếp nhận/ thực hiện có thể là Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai, Chi nhánh hoặc UBND cấp xã tùy thủ tục và địa bàn. Hệ thống chỉ dùng thông tin này để dựng hồ sơ và gợi ý cơ quan; không coi URL thủ tục là bằng chứng binary Official. Chỉ sau khi tải được DOCX/PDF, kiểm chữ ký định dạng, nội dung/mã mẫu và SHA-256 mới nâng file lên Official.

## Kiểm tra tải binary — 20/08/2026

Đã thử tải trực tiếp bốn URL `csdl.dichvucong.gov.vn` bằng HTTP client với chuyển hướng và User-Agent trình duyệt:

- Mẫu 14/14a–14đ, mã `3fd87368b77cb67c`: HTTP `503`.
- Mẫu 15/ĐK, mã `3feb61d7b430b1d1`: HTTP `503`.
- Mẫu 09/ĐK, mã `3fe998b4cf4ed90a`: HTTP `503`.
- Mẫu 10/ĐK, mã `3fe2f78f7bc72401`: HTTP `503`.

Không có binary hợp lệ để kiểm tra MIME, nội dung hoặc SHA-256 trong lần chạy này. Do đó, bốn tệp vẫn là **Candidate/Pending**, không được gắn `Official`. Cơ chế fallback phải tiếp tục tìm bản công bố tương ứng trên Chính phủ/Bộ/Sở; nếu chỉ có nguồn thương mại thì giữ `Reference`.

## Kiểm tra cổng DVC địa phương — 20/08/2026

Đã kiểm tra ba miền do người dùng cung cấp. `dichvucong.hanoi.gov.vn` trả về hệ thống thông tin giải quyết thủ tục hành chính Thành phố Hà Nội và có mục chủ đề đất đai trên trang chủ. `dichvucong.hochiminhcity.gov.vn` xác nhận cơ quan chủ quản là UBND Thành phố Hồ Chí Minh và đơn vị vận hành là Trung tâm Chuyển đổi số Thành phố; trang hiện thông báo từ ngày 19/06/2025 việc thực hiện dịch vụ công trực tuyến tập trung tại Cổng Dịch vụ công Quốc gia. `hcc.danang.gov.vn` xác nhận đây là Trang thông tin điện tử của Trung tâm Phục vụ hành chính công Thành phố Đà Nẵng, có các tin công bố thủ tục hành chính và thông tin liên hệ chính thức.

Các trang HTML địa phương không cung cấp ngay binary DOCX/PDF trong lần trích xuất này. Vì vậy, ba miền được đăng ký làm nguồn **local-government discovery/fallback**, không tự động nâng bất kỳ file nào thành Official. Cổng TP.HCM cần ưu tiên chuyển hướng tra cứu về DVC Quốc gia theo thông báo hiện tại; Hà Nội và Đà Nẵng cần tiếp tục quét mục thủ tục/biểu mẫu hoặc các trang công bố của cơ quan chuyên môn. Mọi file chỉ được gắn Official sau khi xác định thủ tục, cơ quan công bố, nội dung mẫu và SHA-256.

Nguồn kiểm tra: [DVC Hà Nội](https://dichvucong.hanoi.gov.vn/trang-chu), [DVC TP.HCM](https://dichvucong.hochiminhcity.gov.vn/), [trang thủ tục TP.HCM](https://dichvucong.hochiminhcity.gov.vn/vi/procedure/detail/64ad44a47fa28944a1a2a377), [HCC Đà Nẵng](https://hcc.danang.gov.vn/).

## Kiểm tra HTTP batch thử nghiệm ba địa phương — 2026-08-20

- Hà Nội (`https://dichvucong.hanoi.gov.vn`): HTTP 200, có thể tiếp tục discovery.
- Thành phố Hồ Chí Minh (`https://dichvucong.hochiminhcity.gov.vn`): HTTP 200, có thể tiếp tục discovery; cần lưu ý cổng hiện hướng người dùng tập trung về DVC Quốc gia.
- Đà Nẵng (`https://hcc.danang.gov.vn`): môi trường quét gặp `SSL_ERROR_SYSCALL`, chưa thể kết luận nội dung thủ tục hoặc binary bị chặn.
- Kết quả trên chỉ xác nhận miền gốc; chưa có binary DOC/DOCX/PDF và SHA-256 nên chưa nâng file nào thành Official.
