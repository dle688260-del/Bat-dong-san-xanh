# Kiểm tra production module hồ sơ đất đai AI

- URL: https://batdongsan-7bupubgw.manus.space/ai-ho-so-dat-dai-tu-dong
- Thời điểm kiểm tra: 2026-08-23.
- Kết quả: route production render được module, không xuất hiện màn hình `Unexpected error` khi mở.
- Giao diện hiện hiển thị thanh điều hướng quản trị, nút `Đồng bộ ngay`, các nhóm `REGISTRY`, `BỘ NGUỒN TỰ ĐỘNG`, `PHẠM VI PRODUCTION`, ô tìm thủ tục và các bước hồ sơ.
- Catalog hiển thị `Tất cả 74` và các nhóm thủ tục; mã đang hiển thị trong bundle là `2.000889`.
- Tại thời điểm kiểm tra, bundle hiển thị trạng thái `Đang tự nạp bundle...`; chưa thực hiện thao tác phân tích hoặc batch vì cần xác nhận phiên quản trị và không tự ý chạy tác vụ production.
