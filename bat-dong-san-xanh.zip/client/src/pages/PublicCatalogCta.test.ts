import { describe, expect, it } from "vitest";
import { PUBLIC_CATALOG_LABEL } from "./Home";
import { PUBLIC_CATALOG_EMPTY_MESSAGE, PUBLIC_ROLE_GUIDANCE } from "./PropertyCatalog";

describe("public catalog customer entry points", () => {
  it("uses a customer-facing label for the public listing route", () => {
    expect(PUBLIC_CATALOG_LABEL).toBe("Sản phẩm đang bán");
  });

  it("keeps a contact path when no public listing matches", () => {
    expect(PUBLIC_CATALOG_EMPTY_MESSAGE).toContain("chưa có bài đăng công khai");
    expect(PUBLIC_CATALOG_EMPTY_MESSAGE).toContain("0989 682 825");
  });

  it("explains the separate broker and customer paths", () => {
    expect(PUBLIC_ROLE_GUIDANCE).toContain("Môi giới đăng bài trong mục Quản lý");
    expect(PUBLIC_ROLE_GUIDANCE).toContain("khách hàng xem các bài đã Công khai");
    expect(PUBLIC_ROLE_GUIDANCE).toContain("Sản phẩm đang bán");
  });
});
