/* Design reminder: Keep the public experience calm, editorial, and biophilic; light theme with pine green hierarchy. */
import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import PropertyCatalog from "./pages/PropertyCatalog";
import PropertyDetail from "./pages/PropertyDetail";
import AdminLogin from "./pages/AdminLogin";
import { PublicAiAssistant } from "./components/PublicAiAssistant";
import { getAppMode } from "@shared/const";

// Public storefront routes stay eager so the first customer visit remains direct.
// Internal CRM, dossier, AI and archive screens are fetched only when their route opens.
const ConsultationAdmin = lazy(() => import("./pages/ConsultationAdmin"));
const BrokerageAdmin = lazy(() => import("./pages/BrokerageAdmin"));
const PropertyDossierAdmin = lazy(() => import("./pages/PropertyDossierAdmin"));
const BrokerageProcessAdmin = lazy(
  () => import("./pages/BrokerageProcessAdmin")
);
const PropertyArchiveAdmin = lazy(() => import("./pages/PropertyArchiveAdmin"));
const AIDossierAdmin = lazy(() => import("./pages/AIDossierAdmin"));
const AllDossiersAI = lazy(() => import("./pages/AllDossiersAI"));
const LandDossierBuilder = lazy(() => import("./pages/LandDossierBuilder"));
const AiLandDossierAutoModule = lazy(
  () => import("./pages/AiLandDossierAutoModule")
);
const AiLandDossierOperations = lazy(
  () => import("./pages/AiLandDossierOperations")
);
const AILegalKnowledgeBase = lazy(() => import("./pages/AILegalKnowledgeBase"));
const CrmDashboard = lazy(() => import("./pages/CrmDashboard"));
const TransactionCenter = lazy(() => import("./pages/TransactionCenter"));
const MarketingCenter = lazy(() => import("./pages/MarketingCenter"));
const ModuleBuilderAdmin = lazy(() => import("./pages/ModuleBuilderAdmin"));

function AdminRouteFallback() {
  return (
    <main className="flex min-h-[60vh] items-center justify-center bg-[#F7F4EA] px-6 py-16 text-center">
      <div>
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#8A6415]">
          Bất động sản xanh
        </p>
        <p className="mt-3 text-lg font-semibold text-[#18352D]">
          Đang mở khu vực quản lý…
        </p>
        <p className="mt-2 text-sm text-[#60766D]">
          Các mô-đun quản trị đang được tải riêng để trang bán hàng nhẹ hơn.
        </p>
      </div>
    </main>
  );
}

function Router() {
  const mode = getAppMode();
  const normalizedPathname =
    window.location.pathname.replace(/\/+$/, "") || "/";
  const isCrmPath =
    normalizedPathname === "/crm" || normalizedPathname.startsWith("/crm/");
  const isCrm = mode === "crm" || mode === "both" || isCrmPath;
  const isStorefront = mode === "storefront" || mode === "both";

  return (
    <Suspense fallback={<AdminRouteFallback />}>
      <Switch>
        {/* Storefront Routes */}
        {isStorefront && (
          <>
            <Route path="/" component={Home} />
            <Route path="/bat-dong-san" component={PropertyCatalog} />
            <Route path="/bat-dong-san/:slug" component={PropertyDetail} />
          </>
        )}

        {/* CRM / Admin Routes */}
        <Route path="/dang-nhap-quan-tri" component={AdminLogin} />
        {isCrm && (
          <>
            {mode === "crm" && <Route path="/" component={CrmDashboard} />}
            <Route path="/crm/login" component={AdminLogin} />
            <Route path="/crm" component={CrmDashboard} />
            <Route path="/dashboard" component={CrmDashboard} />
            <Route path="/dashboard/khach-hang" component={CrmDashboard} />
            <Route path="/dashboard/giao-dich" component={TransactionCenter} />
            <Route path="/dashboard/marketing" component={MarketingCenter} />
            <Route path="/dashboard/ai" component={CrmDashboard} />
            <Route path="/dashboard/bao-cao" component={CrmDashboard} />
            <Route path="/quan-tri-module" component={ModuleBuilderAdmin} />
            <Route path="/quan-ly" component={ConsultationAdmin} />
            <Route path="/quan-ly-moi-gioi" component={BrokerageAdmin} />
            <Route path="/ho-so-dien-tu" component={PropertyDossierAdmin} />
            <Route path="/ho-so-ai" component={AllDossiersAI} />
            <Route path="/hs-dat-dai-ai" component={AIDossierAdmin} />
            <Route path="/crm/ai-san-xuat" component={AIDossierAdmin} />
            <Route
              path="/ai-lap-ho-so-dat-dai"
              component={LandDossierBuilder}
            />
            <Route path="/ai-ho-so-dat-dai" component={LandDossierBuilder} />
            <Route
              path="/ai-ho-so-dat-dai-tu-dong"
              component={AiLandDossierAutoModule}
            />
            <Route
              path="/ai-land-dossier-pipeline"
              component={LandDossierBuilder}
            />
            <Route path="/ai-ho-so-tu-dong" component={LandDossierBuilder} />
            <Route
              path="/ai-ho-so-dat-dai-tu-dong-moi"
              component={AiLandDossierAutoModule}
            />
            <Route
              path="/ai-ho-so-dat-dai-ai-moi"
              component={AiLandDossierAutoModule}
            />
            <Route
              path="/ai-ho-so-dat-dai-van-hanh"
              component={AiLandDossierOperations}
            />
            <Route path="/ai-kho-phap-ly" component={AILegalKnowledgeBase} />
            <Route path="/quan-ly-ho-so" component={PropertyDossierAdmin} />
            <Route
              path="/quy-trinh-moi-gioi"
              component={BrokerageProcessAdmin}
            />
            <Route path="/kho-luu-tru" component={PropertyArchiveAdmin} />
          </>
        )}

        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="top-right" />
          <Router />
          <PublicAiAssistant />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
