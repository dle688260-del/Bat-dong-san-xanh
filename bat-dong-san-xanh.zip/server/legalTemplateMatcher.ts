import type { LegalDocument, LegalProcedure, LegalProcedureRequirement, LegalTemplate } from "../drizzle/schema";

export type LegalTemplateMatch = {
  template: LegalTemplate;
  score: number;
  matchedEvidence: string[];
  eligibleForOfficial: boolean;
  reason: string;
};

const normalize = (value: string | null | undefined) => (value || "").toLocaleLowerCase("vi-VN").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d");
const tokens = (value: string) => normalize(value).split(/[^a-z0-9]+/).filter(token => token.length >= 3);

export function matchLegalTemplatesByEvidence(input: {
  procedure: LegalProcedure;
  requirements: LegalProcedureRequirement[];
  documents: LegalDocument[];
  templates: LegalTemplate[];
  province?: string;
  receivingAuthority?: string;
}): LegalTemplateMatch[] {
  const procedureText = [input.procedure.code, input.procedure.name, input.procedure.aliases, input.procedure.conditions, input.procedure.workflow].filter(Boolean).join(" ");
  const requirementText = input.requirements.map(item => item.label).join(" ");
  const sourceText = input.documents.map(item => [item.title, item.documentNumber, item.documentType, item.contentText].filter(Boolean).join(" ")).join(" ");
  const evidenceTokens = new Set(tokens(`${procedureText} ${requirementText} ${sourceText}`));
  const procedureTokens = new Set(tokens(procedureText));

  return input.templates.map(template => {
    const templateTokens = tokens(`${template.name} ${template.documentType} ${template.versionLabel} ${template.notes}`);
    const matched = templateTokens.filter(token => evidenceTokens.has(token));
    const procedureMatches = templateTokens.filter(token => procedureTokens.has(token));
    const localMatch = Boolean(!input.province || !template.province || normalize(template.province) === normalize(input.province) || template.jurisdictionScope === "national");
    const authorityMatch = Boolean(!input.receivingAuthority || !template.receivingAuthority || normalize(template.receivingAuthority) === normalize(input.receivingAuthority) || template.jurisdictionScope === "national");
    const sourceVerified = input.documents.some(document => document.id === template.sourceDocumentId && ["verified", "extracted"].includes(document.status) && Boolean(document.contentText?.trim()));
    const binaryVerified = template.provenance === "verified_binary" && Boolean(template.storageKey && template.checksum) && ["docx", "pdf"].includes(template.format);
    const score = Math.min(100, matched.length * 8 + procedureMatches.length * 15 + (localMatch ? 10 : 0) + (authorityMatch ? 10 : 0) + (sourceVerified ? 15 : 0) + (binaryVerified ? 20 : 0));
    const matchedEvidence = Array.from(new Set([...procedureMatches, ...matched])).slice(0, 8);
    const eligibleForOfficial = binaryVerified && sourceVerified && localMatch && authorityMatch && score >= 45;
    return { template, score, matchedEvidence, eligibleForOfficial, reason: eligibleForOfficial ? "Mẫu có binary, nguồn văn bản và phạm vi áp dụng phù hợp." : "Chỉ là gợi ý theo bằng chứng; cần xác minh thêm binary, nguồn hoặc phạm vi địa phương." };
  }).sort((a, b) => b.score - a.score || a.template.name.localeCompare(b.template.name, "vi"));
}

export function isVerifiedOfficialTemplateMatch(match: LegalTemplateMatch) {
  return match.eligibleForOfficial;
}
