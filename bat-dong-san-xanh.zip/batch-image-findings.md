# Biên bản đối soát ảnh batch 2026-08-21

## Ảnh 103031
- Mẫu Phiếu yêu cầu cung cấp dữ liệu đất đai — Mẫu số 01/PYC và Hợp đồng cung cấp dữ liệu đất đai — Mẫu số 02.
- Nguồn hiển thị là endpoint mdm.monre.gov.vn.
- Phát hiện đã xong nhưng tải xuống lỗi.
- Lý do hiển thị: MIME không phù hợp với phần mở rộng `application/vnd.openxmlformats-officedocument.wordprocessingml.document`.
- Checksum và lưu kho đang chờ; gắn thủ tục đang chờ.

## Ảnh 103027
- `Mus14.docx` và `Mus14a14b14c14d.docx` thuộc nguồn DVC Quốc gia, mã thủ tục hiển thị `348167`.
- Lý do: không tải được binary HTTP 503 sau 3 lần thử.
- Checksum lỗi, lưu kho chờ, nhưng gắn thủ tục đã xong; đây là lỗi nguồn binary, không phải lỗi mapping.
- Thủ tục `2.002317` đang hiển thị 0/13 thành phần sẵn sàng, Official 0, Reference 0, Pending 3.

## Nhận định tạm thời
- Có hai nhóm lỗi độc lập: MIME/đuôi file từ endpoint MONRE và binary DVC Quốc gia trả 503.
- Cần tiếp tục đọc các ảnh còn lại để xác định có file tải thành công hoặc lỗi duy nhất còn lại trước khi sửa code.

## Ảnh 103024 và 103017
Các file `Mus01.docx`, `Mus26.docx`, `Mus04.docx` và `Mus01a...` thuộc nguồn DVC Quốc gia với endpoint hiển thị mã `385237`; nhiều file `Mus14...` thuộc mã `348167`. Tất cả đều báo không tải được binary HTTP 503 sau 3 lần, checksum lỗi, lưu kho chờ và gắn thủ tục xong. Thủ tục `1.012789` hiển thị 0/11 thành phần sẵn sàng, Official 0, Reference 0, Pending 3. Kết quả xác nhận lỗi tập trung theo endpoint DVC, không phải checksum ngẫu nhiên từng file.
