# Biên bản rà soát website/CRM

## Ngày
2026-08-26

## Phát hiện ban đầu

- TypeScript và Vitest hiện không báo lỗi trong lần kiểm tra tổng thể.
- Storefront `/` hiển thị được trên mobile, gồm header, tìm kiếm, danh mục và một BĐS nổi bật.
- Route `/bat-dong-san` tại thời điểm chụp preview vẫn hiển thị trạng thái “Đang tải sản phẩm…”, dù network log cho thấy query `properties.latest` trả HTTP 200 và có dữ liệu. Cần kiểm tra trạng thái loading/kết thúc query và trải nghiệm khi dữ liệu chậm.
- Route `/crm/login` hiển thị đúng form đăng nhập và nút vàng “Đổi mật khẩu” trên mobile.
- Route `/crm` tại thời điểm chụp preview hiển thị skeleton/loading; cần xác minh sau khi auth hoàn tất, không kết luận là lỗi nếu chưa đăng nhập.
- Không thấy lỗi HTTP rõ ràng trong network log cho query storefront; analytics trả HTTP 200.

## Việc cần ưu tiên

1. Xác minh vì sao catalog có thể giữ trạng thái loading khi API đã trả dữ liệu.
2. Kiểm tra trạng thái CRM sau đăng nhập thực tế.
3. Rà soát các nút/route chính và các trạng thái rỗng, lỗi, loading.
4. Chỉ sửa các lỗi tái hiện được và bổ sung test hồi quy.
