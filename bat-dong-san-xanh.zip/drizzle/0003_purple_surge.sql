ALTER TABLE `properties` ADD `buildArea` decimal(10,2);--> statement-breakpoint
ALTER TABLE `properties` ADD `constructionYear` int;--> statement-breakpoint
ALTER TABLE `properties` ADD `distanceToMainRoad` varchar(120);--> statement-breakpoint
ALTER TABLE `properties` ADD `nearbySchools` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD `nearbyMarket` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD `nearbyHospital` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD `distanceToCenter` varchar(120);--> statement-breakpoint
ALTER TABLE `properties` ADD `certificateType` varchar(160);--> statement-breakpoint
ALTER TABLE `properties` ADD `certificateArea` decimal(10,2);--> statement-breakpoint
ALTER TABLE `properties` ADD `landUsePurpose` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD `planningStatus` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD `mortgageStatus` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD `legalSource` varchar(255) DEFAULT 'Theo hồ sơ/chủ nhà cung cấp';--> statement-breakpoint
ALTER TABLE `properties` ADD `negotiable` tinyint DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `properties` ADD `brokerageFee` varchar(160);--> statement-breakpoint
ALTER TABLE `properties` ADD `depositTerms` text;--> statement-breakpoint
ALTER TABLE `properties` ADD `transactionTerms` text;--> statement-breakpoint
ALTER TABLE `properties` ADD `propertyCode` varchar(80);--> statement-breakpoint
ALTER TABLE `properties` ADD `brokerName` varchar(120);--> statement-breakpoint
ALTER TABLE `properties` ADD `brokerPhone` varchar(30);--> statement-breakpoint
ALTER TABLE `properties` ADD `brokerZalo` varchar(255);--> statement-breakpoint
ALTER TABLE `properties` ADD CONSTRAINT `properties_propertyCode_unique` UNIQUE(`propertyCode`);