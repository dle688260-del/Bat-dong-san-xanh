# Rà soát giao diện tăng cỡ chữ và thu gọn

Desktop 1280px: khu vực quản lý giữ bố cục sidebar và nội dung chính ổn định; tiêu đề, mô tả, nút đăng sản phẩm và khối camera pháp lý dễ đọc hơn, không thấy tràn ngang trong vùng xem đầu trang.

Mobile 390px: tiêu đề Quản lý đăng bán, mô tả, nút Đăng bán sản phẩm, khối camera và nút Mở camera hồ sơ hiển thị rõ; các vùng bấm đủ lớn và nội dung tự xếp dọc. Khoảng cách phần đầu được thu gọn để giảm vùng trống. Preview được kiểm tra ở route /quan-ly-moi-gioi; phần Hồ sơ điện tử dùng chung token typography mới và sẽ áp dụng cùng mức dễ đọc khi mở hồ sơ.

TypeScript không lỗi và 84/84 Vitest đạt.
