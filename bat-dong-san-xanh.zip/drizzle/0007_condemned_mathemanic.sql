ALTER TABLE `properties` ADD `latitude` decimal(10,7);--> statement-breakpoint
ALTER TABLE `properties` ADD `longitude` decimal(10,7);--> statement-breakpoint
ALTER TABLE `properties` ADD `mapVisibility` enum('approximate','exact','private') DEFAULT 'approximate' NOT NULL;