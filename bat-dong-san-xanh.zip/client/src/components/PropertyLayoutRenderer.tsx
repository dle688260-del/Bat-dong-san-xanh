import React from "react";
import type { ListingKind } from "@/lib/propertyListingRegistry";

export type PropertyDisplayLayout =
  | "auto"
  | "mosaic"
  | "grid2"
  | "grid3"
  | "carousel";
export type PropertyRenderVariant = "default" | "compact";
export type PropertyLayoutOverrides = Partial<
  Record<ListingKind, PropertyDisplayLayout>
>;
export type PropertyLayoutConfig = {
  defaultLayout: PropertyDisplayLayout;
  byCategory: PropertyLayoutOverrides;
};

export const PROPERTY_LAYOUT_STORAGE_KEY = "bdsxanh:property-display-layout";
export const PROPERTY_LAYOUT_CONFIG_STORAGE_KEY =
  "bdsxanh:property-display-layout-config";

const isPropertyDisplayLayout = (
  value: unknown
): value is PropertyDisplayLayout =>
  value === "auto" ||
  value === "mosaic" ||
  value === "grid2" ||
  value === "grid3" ||
  value === "carousel";

export function readStoredPropertyLayout(
  storage: Pick<Storage, "getItem"> | undefined
): PropertyDisplayLayout {
  try {
    const saved = storage?.getItem(PROPERTY_LAYOUT_STORAGE_KEY);
    return isPropertyDisplayLayout(saved) ? saved : "auto";
  } catch {
    return "auto";
  }
}

export function writeStoredPropertyLayout(
  storage: Pick<Storage, "setItem"> | undefined,
  layout: PropertyDisplayLayout
) {
  try {
    storage?.setItem(PROPERTY_LAYOUT_STORAGE_KEY, layout);
  } catch {
    // Ignore blocked or unavailable browser storage and keep the in-memory choice.
  }
}

function sanitizeOverrides(value: unknown): PropertyLayoutOverrides {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(
    Object.entries(value).filter(
      ([key, layout]) => isPropertyKind(key) && isPropertyDisplayLayout(layout)
    )
  ) as PropertyLayoutOverrides;
}

function isPropertyKind(value: string): value is ListingKind {
  return [
    "house",
    "land",
    "apartment",
    "villa",
    "industrial",
    "commercial_land",
    "agricultural",
    "commercial",
    "resort",
    "project",
    "rental",
  ].includes(value);
}

export function readStoredPropertyLayoutConfig(
  storage: Pick<Storage, "getItem"> | undefined
): PropertyLayoutConfig {
  try {
    const raw = storage?.getItem(PROPERTY_LAYOUT_CONFIG_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as {
        defaultLayout?: unknown;
        byCategory?: unknown;
      };
      return {
        defaultLayout: isPropertyDisplayLayout(parsed.defaultLayout)
          ? parsed.defaultLayout
          : "auto",
        byCategory: sanitizeOverrides(parsed.byCategory),
      };
    }
    return { defaultLayout: readStoredPropertyLayout(storage), byCategory: {} };
  } catch {
    return { defaultLayout: "auto", byCategory: {} };
  }
}

export function writeStoredPropertyLayoutConfig(
  storage: Pick<Storage, "setItem"> | undefined,
  config: PropertyLayoutConfig
) {
  try {
    storage?.setItem(
      PROPERTY_LAYOUT_CONFIG_STORAGE_KEY,
      JSON.stringify({
        defaultLayout: isPropertyDisplayLayout(config.defaultLayout)
          ? config.defaultLayout
          : "auto",
        byCategory: sanitizeOverrides(config.byCategory),
      })
    );
  } catch {
    // Ignore blocked or unavailable browser storage and keep the in-memory choice.
  }
}

export function getPropertyLayoutForCategory(
  config: PropertyLayoutConfig,
  category?: ListingKind | null
) {
  return category && config.byCategory[category]
    ? config.byCategory[category]
    : config.defaultLayout;
}

function getBrowserStorage(): Storage | undefined {
  try {
    return typeof window === "undefined" ? undefined : window.localStorage;
  } catch {
    return undefined;
  }
}

export function usePersistentPropertyLayoutConfig() {
  const [config, setConfig] = React.useState<PropertyLayoutConfig>({
    defaultLayout: "auto",
    byCategory: {},
  });
  const [hydrated, setHydrated] = React.useState(false);

  React.useEffect(() => {
    setConfig(readStoredPropertyLayoutConfig(getBrowserStorage()));
    setHydrated(true);
  }, []);

  React.useEffect(() => {
    if (hydrated) writeStoredPropertyLayoutConfig(getBrowserStorage(), config);
  }, [config, hydrated]);

  const setDefaultLayout = React.useCallback(
    (defaultLayout: PropertyDisplayLayout) => {
      setConfig(current => ({ ...current, defaultLayout }));
    },
    []
  );
  const setCategoryLayout = React.useCallback(
    (category: ListingKind, layout: PropertyDisplayLayout) => {
      setConfig(current => ({
        ...current,
        byCategory: { ...current.byCategory, [category]: layout },
      }));
    },
    []
  );
  const clearCategoryLayout = React.useCallback((category: ListingKind) => {
    setConfig(current => {
      const byCategory = { ...current.byCategory };
      delete byCategory[category];
      return { ...current, byCategory };
    });
  }, []);

  return {
    config,
    setConfig,
    setDefaultLayout,
    setCategoryLayout,
    clearCategoryLayout,
  };
}

export function usePersistentPropertyLayout() {
  const settings = usePersistentPropertyLayoutConfig();
  return [settings.config.defaultLayout, settings.setDefaultLayout] as const;
}

type LayoutOption = { value: PropertyDisplayLayout; label: string };

export const PROPERTY_LAYOUT_OPTIONS: LayoutOption[] = [
  { value: "auto", label: "Tự động" },
  { value: "mosaic", label: "1 lớn + 4 nhỏ" },
  { value: "grid2", label: "2 cột" },
  { value: "grid3", label: "3 cột" },
  { value: "carousel", label: "Vuốt ngang" },
];

export function resolveAutoPropertyLayout(
  count: number
): Exclude<PropertyDisplayLayout, "auto"> {
  if (count >= 5) return "mosaic";
  if (count === 4 || count === 3) return "grid3";
  if (count === 2) return "grid2";
  return "carousel";
}

export function getPropertyLayoutLabel(layout: PropertyDisplayLayout) {
  return (
    PROPERTY_LAYOUT_OPTIONS.find(option => option.value === layout)?.label ??
    "Tự động"
  );
}

export function PropertyLayoutPicker({
  value,
  onChange,
  className = "",
}: {
  value: PropertyDisplayLayout;
  onChange: (layout: PropertyDisplayLayout) => void;
  className?: string;
}) {
  return (
    <div
      className={`flex max-w-full items-center gap-1 overflow-x-auto rounded-full border border-[#DCE9E1] bg-[#F7FAF6] p-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden ${className}`}
      aria-label="Chọn bố cục sản phẩm"
    >
      {PROPERTY_LAYOUT_OPTIONS.map(option => (
        <button
          key={option.value}
          type="button"
          aria-pressed={value === option.value}
          onClick={() => onChange(option.value)}
          className={`shrink-0 rounded-full px-2.5 py-1.5 text-[10px] font-black transition sm:px-3 sm:text-xs ${value === option.value ? "bg-[#1F5A4A] text-white shadow-sm" : "text-[#557268] hover:bg-white hover:text-[#1F5A4A]"}`}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function PropertyLayoutRenderer<T>({
  items,
  layout = "auto",
  renderItem,
  className = "",
  itemKey,
}: {
  items: T[];
  layout?: PropertyDisplayLayout;
  renderItem: (
    item: T,
    index: number,
    variant: PropertyRenderVariant
  ) => React.ReactNode;
  className?: string;
  itemKey?: (item: T, index: number) => React.Key;
}) {
  if (!items.length) return null;
  const resolved =
    layout === "auto" ? resolveAutoPropertyLayout(items.length) : layout;
  const keyFor = (item: T, index: number) => itemKey?.(item, index) ?? index;
  const render = (
    item: T,
    index: number,
    variant: PropertyRenderVariant = "default"
  ) => (
    <React.Fragment key={keyFor(item, index)}>
      {renderItem(item, index, variant)}
    </React.Fragment>
  );

  if (resolved === "carousel") {
    const itemWidth =
      items.length === 1
        ? "w-full min-w-full"
        : "w-[92vw] min-w-[92vw] sm:w-[48%] sm:min-w-[48%] lg:w-[32%] lg:min-w-[32%]";
    return (
      <div
        data-display-layout="carousel"
        className={`flex snap-x snap-mandatory gap-4 overflow-x-auto overscroll-x-contain px-1 pb-2 pr-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden ${className}`}
      >
        {items.map((item, index) => (
          <div
            key={keyFor(item, index)}
            className={`${itemWidth} shrink-0 snap-start`}
          >
            {render(item, index)}
          </div>
        ))}
      </div>
    );
  }

  if (resolved === "mosaic") {
    const lead = items[0];
    const supporting = items.slice(1, 5);
    const rest = items.slice(5);
    return (
      <div data-display-layout="mosaic" className={`space-y-3 ${className}`}>
        <div className="grid gap-3 md:grid-cols-4 md:grid-rows-2 md:auto-rows-fr">
          <div className="min-w-0 md:col-span-2 md:row-span-2">
            {render(lead, 0)}
          </div>
          {supporting.map((item, index) => (
            <div key={keyFor(item, index + 1)} className="min-w-0">
              <div className="[&>article]:h-full">
                {render(item, index + 1, "compact")}
              </div>
            </div>
          ))}
        </div>
        {rest.length > 0 && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {rest.map((item, index) => (
              <div key={keyFor(item, index + 5)} className="min-w-0">
                {render(item, index + 5, "compact")}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  const columns =
    resolved === "grid3"
      ? "sm:grid-cols-2 xl:grid-cols-3"
      : items.length === 1
        ? "grid-cols-1"
        : "sm:grid-cols-2";
  return (
    <div
      data-display-layout={resolved}
      className={`grid gap-3 ${columns} ${className}`}
    >
      {items.map((item, index) => (
        <div key={keyFor(item, index)} className="min-w-0">
          {render(item, index)}
        </div>
      ))}
    </div>
  );
}
