import crypto from "node:crypto";
import JSZip from "jszip";
import { PDFDocument } from "pdf-lib";

export type VerifiedTemplateFormat = "docx" | "pdf";

export type VerifiedTemplateAsset = {
  id: string;
  fileName: string;
  format: VerifiedTemplateFormat;
  mimeType: string;
  sourceUrl: string;
  sourceCheckedAt: string;
  sha256: string;
  storageKey: string;
  sourceStatus: "verified";
  placeholderMap?: Record<string, string>;
};

export type TemplateFieldValue = { label: string; value: string };

export type VerifiedTemplateInspection = {
  format: VerifiedTemplateFormat;
  fillable: boolean;
  availableFields: string[];
  matchedFields: string[];
  warning?: string;
};

export function sha256Hex(bytes: Uint8Array) {
  return crypto.createHash("sha256").update(bytes).digest("hex");
}

function assertBinarySignature(bytes: Uint8Array, format: VerifiedTemplateFormat) {
  if (format === "docx") {
    if (bytes.length < 4 || bytes[0] !== 0x50 || bytes[1] !== 0x4b || bytes[2] !== 0x03 || bytes[3] !== 0x04) {
      throw new Error("Template DOCX không có chữ ký ZIP hợp lệ.");
    }
    return;
  }
  if (bytes.length < 5 || String.fromCharCode(...Array.from(bytes.slice(0, 5))) !== "%PDF-") {
    throw new Error("Template PDF không có chữ ký PDF hợp lệ.");
  }
}

export function assertVerifiedTemplateAsset(asset: VerifiedTemplateAsset, bytes: Uint8Array) {
  if (asset.sourceStatus !== "verified") throw new Error("Template chưa có trạng thái nguồn chính thức đã xác minh.");
  if (!asset.sourceUrl.startsWith("https://")) throw new Error("Nguồn template phải dùng HTTPS.");
  assertBinarySignature(bytes, asset.format);
  const actual = sha256Hex(bytes);
  if (actual.toLowerCase() !== asset.sha256.toLowerCase()) {
    throw new Error(`Checksum template không khớp: kỳ vọng ${asset.sha256}, nhận ${actual}.`);
  }
  return { ...asset, sha256: actual };
}

function escapeXml(value: string) {
  return value.replace(/[<>&'\"]/g, char => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '\"': "&quot;" })[char] ?? char);
}

function normalizeAnchorText(value: string) {
  return value.toLocaleLowerCase("vi").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/[^a-z0-9]+/g, " ").trim();
}

function readDocxText(xml: string) {
  return Array.from(xml.matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)).map(match => match[1].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">" ).replace(/&quot;/g, '\"').replace(/&apos;/g, "'")).join("");
}

function paragraphHasField(paragraphXml: string, field: TemplateFieldValue) {
  return normalizeAnchorText(readDocxText(paragraphXml)).includes(normalizeAnchorText(field.label));
}

function fillDocxAnchors(paragraphXml: string, fields: TemplateFieldValue[]) {
  const paragraphText = readDocxText(paragraphXml);
  let changed = 0;
  let seenText = "";
  const filled = new Set<string>();
  const textNodes = Array.from(paragraphXml.matchAll(/<w:t\b([^>]*)>([\s\S]*?)<\/w:t>/g));
  let nodeIndex = 0;
  const updated = paragraphXml.replace(/<w:t\b([^>]*)>([\s\S]*?)<\/w:t>/g, (full, attrs: string, encodedText: string) => {
    const decodedText = readDocxText(`<w:t>${encodedText}</w:t>`);
    seenText += decodedText;
    const candidate = fields.find(field => !filled.has(field.label) && normalizeAnchorText(seenText).includes(normalizeAnchorText(field.label)));
    if (!candidate) return full;
    const blank = /(?:[.…_][\s.…_]*){3,}/;
    if (!blank.test(decodedText)) {
      nodeIndex += 1;
      return full;
    }
    filled.add(candidate.label);
    changed += 1;
    nodeIndex += 1;
    return `<w:t${attrs}>${escapeXml(decodedText.replace(blank, ` ${candidate.value || ""}`))}</w:t>`;
  });
  if (changed === 0) {
    const fallback = fields.find(field => paragraphHasField(paragraphXml, field));
    if (fallback && paragraphText) {
      return { xml: updated.replace(/<\/w:p>$/, `<w:r><w:t xml:space="preserve"> ${escapeXml(fallback.value || "")}</w:t></w:r></w:p>`), changed: 1 };
    }
  }
  return { xml: updated, changed };
}

export async function inspectVerifiedTemplate(asset: VerifiedTemplateAsset, bytes: Uint8Array, fields: TemplateFieldValue[] = []): Promise<VerifiedTemplateInspection> {
  assertVerifiedTemplateAsset(asset, bytes);
  if (asset.format === "docx") {
    const zip = await JSZip.loadAsync(bytes);
    const xmlParts: string[] = [];
    for (const path of Object.keys(zip.files)) {
      if (path.startsWith("word/") && path.endsWith(".xml")) xmlParts.push(await zip.file(path)!.async("string"));
    }
      const tokenNames = fields.map(field => asset.placeholderMap?.[field.label] ?? `{{${field.label}}}`);
      const documentXml = xmlParts.join("\\n");
      const matchedFields = fields.filter(field => documentXml.includes(asset.placeholderMap?.[field.label] ?? `{{${field.label}}}`) || paragraphHasField(documentXml, field)).map(field => asset.placeholderMap?.[field.label] ?? field.label);
      return {
        format: "docx",
        fillable: matchedFields.length > 0,
        availableFields: tokenNames,
        matchedFields,
        warning: matchedFields.length === 0 ? "DOCX mẫu chính thức không có placeholder hoặc nhãn kê khai khớp dữ liệu; cần ánh xạ thủ công hoặc nhập trực tiếp trên file gốc trước khi nộp." : undefined,
      };
  }
  const pdf = await PDFDocument.load(bytes);
  const formFields = pdf.getForm().getFields().map(field => field.getName());
  const expectedNames = fields.map(field => asset.placeholderMap?.[field.label] ?? field.label);
  const matchedFields = expectedNames.filter(name => formFields.includes(name));
  return {
    format: "pdf",
    fillable: matchedFields.length > 0,
    availableFields: formFields,
    matchedFields,
    warning: formFields.length === 0 ? "PDF mẫu chính thức không có AcroForm; không thể tự điền bằng dữ liệu số." : matchedFields.length === 0 ? "PDF có AcroForm nhưng không khớp tên trường dữ liệu; cần lập bản đồ trường thủ công." : undefined,
  };
}

export async function fillVerifiedDocx(asset: VerifiedTemplateAsset, bytes: Uint8Array, fields: TemplateFieldValue[]) {
  if (asset.format !== "docx") throw new Error("Asset không phải DOCX.");
  assertVerifiedTemplateAsset(asset, bytes);
  const inspection = await inspectVerifiedTemplate(asset, bytes, fields);
  if (!inspection.fillable) throw new Error(inspection.warning || "DOCX mẫu chính thức không có trường để điền tự động.");
  const zip = await JSZip.loadAsync(bytes);
  const replacements = new Map<string, string>();
  for (const field of fields) {
    const token = asset.placeholderMap?.[field.label] ?? `{{${field.label}}}`;
    replacements.set(token, escapeXml(field.value || ""));
  }
  let changed = 0;
  for (const path of Object.keys(zip.files)) {
    if (!path.startsWith("word/") || !path.endsWith(".xml")) continue;
    let xml = await zip.file(path)!.async("string");
    for (const [token, value] of Array.from(replacements.entries())) {
      if (xml.includes(token)) {
        xml = xml.split(token).join(value);
        changed += 1;
      }
    }
    const paragraphs = Array.from(xml.matchAll(/<w:p\b[^>]*>[\s\S]*?<\/w:p>/g));
    for (const match of paragraphs) {
      const result = fillDocxAnchors(match[0], fields);
      if (result.changed > 0) {
        xml = xml.replace(match[0], result.xml);
        changed += result.changed;
      }
    }
    zip.file(path, xml);
  }
  if (changed === 0) throw new Error("Không tìm thấy placeholder hoặc nhãn kê khai trong DOCX đã xác minh; không xuất bản điền mẫu.");
  return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
}

export async function fillVerifiedPdf(asset: VerifiedTemplateAsset, bytes: Uint8Array, fields: TemplateFieldValue[]) {
  if (asset.format !== "pdf") throw new Error("Asset không phải PDF.");
  assertVerifiedTemplateAsset(asset, bytes);
  const pdf = await PDFDocument.load(bytes);
  const form = pdf.getForm();
  const formFields = form.getFields();
  if (formFields.length === 0) throw new Error("PDF mẫu chính thức không có AcroForm; cần điền thủ công trên file gốc, không thể xuất Official tự động.");
  const byName = new Map(fields.map(field => [asset.placeholderMap?.[field.label] ?? field.label, field.value]));
  let changed = 0;
  for (const field of formFields) {
    const value = byName.get(field.getName());
    if (value === undefined) continue;
    const textField = form.getTextField(field.getName());
    textField.setText(value);
    changed += 1;
  }
  if (changed === 0) throw new Error("Không khớp trường dữ liệu với PDF đã xác minh; không xuất bản điền mẫu.");
  return Buffer.from(await pdf.save());
}

export async function fillVerifiedTemplate(asset: VerifiedTemplateAsset, bytes: Uint8Array, fields: TemplateFieldValue[]) {
  if (asset.format === "docx") return fillVerifiedDocx(asset, bytes, fields);
  return fillVerifiedPdf(asset, bytes, fields);
}
