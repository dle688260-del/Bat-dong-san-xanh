ALTER TABLE `deals` ADD `transactionCode` varchar(40);--> statement-breakpoint
ALTER TABLE `deals` ADD `depositAmount` decimal(18,2);--> statement-breakpoint
ALTER TABLE `deals` ADD `depositDate` timestamp;--> statement-breakpoint
ALTER TABLE `deals` ADD `expectedNotaryDate` timestamp;--> statement-breakpoint
ALTER TABLE `deals` ADD `completionDate` timestamp;--> statement-breakpoint
ALTER TABLE `deals` ADD `commissionAmount` decimal(18,2);--> statement-breakpoint
ALTER TABLE `deals` ADD `paymentStatus` enum('pending','partial','paid') DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `deals` ADD `paymentMethod` varchar(120);--> statement-breakpoint
ALTER TABLE `deals` ADD `notaryOffice` varchar(255);--> statement-breakpoint
ALTER TABLE `deals` ADD `transferStatus` enum('not_started','in_progress','completed') DEFAULT 'not_started' NOT NULL;--> statement-breakpoint
ALTER TABLE `deals` ADD `handoverStatus` enum('not_started','scheduled','completed') DEFAULT 'not_started' NOT NULL;--> statement-breakpoint
ALTER TABLE `deals` ADD `issueNote` text;--> statement-breakpoint
ALTER TABLE `deals` ADD `nextAction` text;--> statement-breakpoint
ALTER TABLE `deals` ADD `checklist` text;--> statement-breakpoint
ALTER TABLE `deals` ADD CONSTRAINT `deals_transactionCode_unique` UNIQUE(`transactionCode`);