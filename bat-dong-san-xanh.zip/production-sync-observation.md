# Production sync observation

- URL checked: https://batdongsan-7bupubgw.manus.space/ai-ho-so-dat-dai-tu-dong
- The page shows 74 procedure entries in the UI, including code 2.000889.
- The banner remains "Đang đồng bộ..." after repeated checks at approximately 12:37:04, 12:37:14, 12:37:35, 12:37:44, 12:38:17 GMT+7.
- The page exposes a "Thử lại" button, but no completed batch result or explicit failure text was visible in extracted content.
- Registry source URLs shown by the page include:
  - https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=2912&open_popup=1
  - https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8
  - https://mae.gov.vn/noidung/Lists/DuLieuLinhVucCongBo/Attachments/2/ph%E1%BB%A5%20l%E1%BB%A5c%20VII.pdf
  - https://qldd.mae.gov.vn/danh-sach-van-ban.htm
  - https://drive.google.com/drive/folders/13qbgnsfzOOZxm9Dc50gXWVrCbpw6MG_L
- The page itself correctly states that discovery URLs do not imply an Official binary; Official requires a verified DOCX/PDF and checksum.
- Action implication: do not click Sync again while the existing batch is still displayed as running; investigate the backend request/timeout and surface an explicit progress or failure state before retrying.

## Cập nhật sau 67 request
- Trang production vẫn hiển thị “Đang đồng bộ”.
- Performance ghi nhận 67 request syncProcedure.
- Nội dung lỗi hiện trên trang: `Nạp nguồn theo mã và tỉnh chưa hoàn tất: Unexpected token 'S', "Service Unavailable" is not valid JSON`.
- Kết luận: batch chưa hoàn tất thành công; cần phân loại mã thành công/thất bại và retry có kiểm soát, không bấm Đồng bộ lại toàn bộ.

## Kiểm tra production khi người dùng thử mã 2000889
- URL: https://batdongsan-7bupubgw.manus.space/ai-ho-so-dat-dai-tu-dong
- Màn hình được kiểm tra vẫn đang ở mã `1.012783`/mẫu 09/ĐK, chưa phải `2.000889`.
- Bundle hiển thị trạng thái `Đã tự nạp bundle`, nhưng tổng hợp ghi `0 mẫu Official có checksum`.
- Banner lỗi: `Nạp nguồn theo mã và tỉnh chưa hoàn tất: Unexpected token 'S', "Service Unavailable" is not valid JSON`.
- Discovery URLs hiển thị gồm DVC quốc gia, DVC Bộ, phụ lục VII của MAE và qldd.mae.gov.vn; các URL discovery không phải binary Official.
- Kết luận: chưa có bằng chứng Official cho mã 1.012783; cần chọn lại mã chuẩn `2.000889` trước khi kiểm tra mẫu 09/ĐK của mã đó.

## Trạng thái trước khi chọn lại mã 2.000889
- Sau khi cuộn về đầu module, các nguồn registry trên production vẫn trỏ theo mã `1.012783`.
- Trang đang hiển thị nút `Đồng bộ ngay` và bundle của mã đang chọn; mã `2.000889` chưa được chọn trong trạng thái này.
- Không thao tác lại đồng bộ toàn catalog; chỉ cần tìm/chọn đúng mã để kiểm thử riêng.
