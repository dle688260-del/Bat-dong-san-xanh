import { describe, expect, it } from "vitest";
import { getPlanningReviewState } from "./CrmPlanningReview";

describe("getPlanningReviewState", () => {
  it("requires status, official URL, and check date", () => {
    expect(getPlanningReviewState("", "https://example.gov.vn", "2026-08-25")).toBe("missing");
    expect(getPlanningReviewState("Chưa phát hiện", "", "2026-08-25")).toBe("missing");
    expect(getPlanningReviewState("Chưa phát hiện", "https://example.gov.vn", "")).toBe("needs_verification");
  });

  it("accepts a complete source record", () => {
    expect(getPlanningReviewState("Chưa phát hiện chồng lấn", "https://quyhoach.xaydung.gov.vn", "2026-08-25")).toBe("verified_source");
  });

  it("rejects non-http links", () => {
    expect(getPlanningReviewState("Có quy hoạch", "javascript:alert(1)", "2026-08-25")).toBe("needs_verification");
  });
});
