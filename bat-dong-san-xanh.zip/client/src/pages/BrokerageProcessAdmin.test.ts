import { describe, expect, it } from "vitest";
import {
  BROKERAGE_PROCESS_MENU_LABEL,
  BROKERAGE_PROCESS_TITLE,
  BROKERAGE_PROCESS_WORD_LABEL,
  BROKERAGE_PROCESS_WORD_MIME,
  BROKERAGE_PROCESS_WORD_EXTENSION,
  PROCESS_STEPS,
  PROPERTY_PROFILE_OPTIONS,
  getProcessStepsForType,
  normalizePropertyProfileType,
} from "./BrokerageProcessAdmin";

describe("Brokerage process CRM contract", () => {
  it("exposes the requested process labels", () => {
    expect(BROKERAGE_PROCESS_MENU_LABEL).toBe("Quá trình môi giới 12 bước");
    expect(BROKERAGE_PROCESS_TITLE).toBe("QUY TRÌNH QUẢN LÝ BẤT ĐỘNG SẢN");
    expect(BROKERAGE_PROCESS_WORD_LABEL).toBe("Xuất quy trình Word");
    expect(BROKERAGE_PROCESS_WORD_MIME).toBe("application/msword;charset=utf-8");
    expect(BROKERAGE_PROCESS_WORD_EXTENSION).toBe(".doc");
  });

  it("contains all 12 workflow steps", () => {
    expect(PROCESS_STEPS).toHaveLength(12);
    expect(PROCESS_STEPS.map(step => step.title)).toEqual([
      "Tiếp nhận thông tin BĐS",
      "Khảo sát sơ bộ",
      "Khảo sát thực tế",
      "Kiểm tra quy hoạch",
      "Kiểm tra pháp lý",
      "Định giá BĐS",
      "Tiếp nhận ký gửi",
      "Đăng bán",
      "Quản lý khách mua",
      "Xem BĐS",
      "Đàm phán & giao dịch",
      "Hoàn tất",
    ]);
  });

  it("maps each property type to a distinct profile and keeps 12 steps", () => {
    expect(PROPERTY_PROFILE_OPTIONS).toHaveLength(8);
    const landSteps = getProcessStepsForType("land");
    const apartmentSteps = getProcessStepsForType("apartment");
    expect(landSteps).toHaveLength(12);
    expect(apartmentSteps).toHaveLength(12);
    expect(landSteps[0].fields).toContain("Số thửa");
    expect(apartmentSteps[0].fields).toContain("Tên dự án");
    expect(apartmentSteps[0].fields).not.toContain("Số thửa");
  });

  it("normalizes property types from stored property data", () => {
    expect(normalizePropertyProfileType("apartment")).toBe("apartment");
    expect(normalizePropertyProfileType("Căn hộ")).toBe("apartment");
    expect(normalizePropertyProfileType("villa")).toBe("villa_resort");
    expect(normalizePropertyProfileType("unknown")).toBe("land");
  });

  it("includes key intake, legal, marketing and completion fields", () => {
    expect(PROCESS_STEPS[0].fields).toEqual(expect.arrayContaining(["Họ tên chủ nhà", "Số điện thoại", "Địa chỉ BĐS", "Người tiếp nhận"]));
    expect(PROCESS_STEPS[4].fields).toEqual(expect.arrayContaining(["Giấy chứng nhận", "Chủ sở hữu", "Thế chấp/tranh chấp"]));
    expect(PROCESS_STEPS[7].fields).toEqual(expect.arrayContaining(["Hình ảnh", "Video", "Kênh đăng website/Facebook/Zalo"]));
    expect(PROCESS_STEPS[11].fields).toEqual(expect.arrayContaining(["Công chứng", "Thanh toán", "Sang tên", "Lưu hồ sơ giao dịch"]));
  });
});
