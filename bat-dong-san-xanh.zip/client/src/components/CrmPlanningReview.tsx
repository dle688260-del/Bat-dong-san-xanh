import { useMemo, useState } from "react";
import { ExternalLink, FileCheck2, ShieldAlert } from "lucide-react";

export type PlanningReviewState = "verified_source" | "needs_verification" | "missing";

export function getPlanningReviewState(status: string, sourceUrl: string, checkedAt: string): PlanningReviewState {
  if (!status.trim() || !sourceUrl.trim()) return "missing";
  if (!/^https?:\/\//i.test(sourceUrl.trim()) || !checkedAt.trim()) return "needs_verification";
  return "verified_source";
}

export default function CrmPlanningReview() {
  const [status, setStatus] = useState("");
  const [sourceUrl, setSourceUrl] = useState("");
  const [checkedAt, setCheckedAt] = useState("");
  const state = useMemo(() => getPlanningReviewState(status, sourceUrl, checkedAt), [status, sourceUrl, checkedAt]);
  const label = state === "verified_source" ? "Đã ghi nhận nguồn để đối chiếu" : state === "needs_verification" ? "Cần kiểm tra lại nguồn" : "Chưa đủ dữ liệu quy hoạch";
  const tone = state === "verified_source" ? "bg-[#e2f1e8] text-[#1e6a59]" : state === "needs_verification" ? "bg-[#fff1ca] text-[#9d751f]" : "bg-[#fbe6df] text-[#b25549]";
  return <section data-responsive-section="CRM Planning Review" className="mb-5 rounded-[24px] border border-[#dce7df] bg-[#fffdf8] p-5 shadow-[0_10px_28px_rgba(23,59,53,0.04)]"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-[0.18em] text-[#b48a36]">Kiểm tra có kiểm soát</p><h2 className="mt-2 font-serif text-2xl text-[#173b35]">Đối chiếu quy hoạch</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-[#688078]">Ghi lại trạng thái, nguồn chính thức và ngày kiểm tra để phân biệt dữ liệu tham khảo với xác nhận pháp lý.</p></div><ShieldAlert className="h-7 w-7 text-[#b48a36]" /></div><div className="mt-4 grid gap-3 lg:grid-cols-[1fr_1fr_180px]"><label className="text-sm font-semibold text-[#527068]">Kết quả ghi nhận<input value={status} onChange={event => setStatus(event.target.value)} placeholder="Ví dụ: Chưa phát hiện chồng lấn" className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35]" /></label><label className="text-sm font-semibold text-[#527068]">Liên kết nguồn chính thức<input value={sourceUrl} onChange={event => setSourceUrl(event.target.value)} placeholder="https://…" inputMode="url" className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35]" /></label><label className="text-sm font-semibold text-[#527068]">Ngày kiểm tra<input value={checkedAt} onChange={event => setCheckedAt(event.target.value)} type="date" className="mt-1.5 w-full rounded-xl border border-[#dce7df] bg-white px-3 py-3 text-sm text-[#173b35]" /></label></div><div className="mt-4 flex flex-wrap items-center gap-3"><span className={`inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-bold ${tone}`}><FileCheck2 className="h-4 w-4" />{label}</span>{/^https?:\/\//i.test(sourceUrl.trim()) ? <a href={sourceUrl.trim()} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full border border-[#dce7df] bg-white px-3 py-2 text-xs font-bold text-[#1e6a59]"><ExternalLink className="h-4 w-4" />Mở nguồn đối chiếu</a> : null}</div><p className="mt-4 text-xs leading-5 text-[#688078]">Kết quả này không thay thế trích lục, văn bản cung cấp thông tin quy hoạch hoặc xác nhận của cơ quan có thẩm quyền.</p></section>;
}
