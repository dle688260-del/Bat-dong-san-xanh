import { describe, expect, it } from "vitest";
import {
  DASHBOARD_MENU_GROUPS,
  DASHBOARD_MENU_ITEMS,
  DASHBOARD_MENU_SUBITEMS,
  filterNewConsignmentRequests,
  getStoredSidebarWidth,
  isDashboardPathActive,
} from "./DashboardLayout";

describe("DashboardLayout localStorage guard", () => {
  it("uses the default width when browser storage is unavailable", () => {
    expect(getStoredSidebarWidth(undefined)).toBe(280);
  });

  it("accepts a stored width inside the supported range", () => {
    expect(getStoredSidebarWidth({ getItem: () => "360" })).toBe(360);
  });

  it("ignores invalid or unsafe stored widths", () => {
    expect(getStoredSidebarWidth({ getItem: () => "120" })).toBe(280);
    expect(getStoredSidebarWidth({ getItem: () => "not-a-number" })).toBe(280);
  });
});

describe("notification bell consultation filter", () => {
  it("counts only new consignment requests", () => {
    const requests = [
      {
        id: 1,
        name: "Chủ nhà A",
        phone: "0900000001",
        interest: "Ký gửi bất động sản",
        message: null,
        createdAt: Date.now(),
        status: "new" as const,
      },
      {
        id: 2,
        name: "Khách mua B",
        phone: "0900000002",
        interest: "Mua nhà",
        message: null,
        createdAt: Date.now(),
        status: "new" as const,
      },
      {
        id: 3,
        name: "Chủ nhà C",
        phone: "0900000003",
        interest: "Ký gửi bất động sản",
        message: null,
        createdAt: Date.now(),
        status: "contacted" as const,
      },
    ];

    expect(
      filterNewConsignmentRequests(requests).map(request => request.id)
    ).toEqual([1]);
  });
});

describe("electronic dossier navigation", () => {
  it("exposes the electronic dossier menu and route", () => {
    expect(DASHBOARD_MENU_ITEMS).toContainEqual({
      icon: expect.anything(),
      label: "8. Hồ sơ điện tử",
      path: "/ho-so-dien-tu",
    });
  });
});

describe("central AI assistant navigation", () => {
  it("keeps the AI legal knowledge base reachable from the CRM", () => {
    expect(DASHBOARD_MENU_ITEMS).toContainEqual({
      icon: expect.anything(),
      label: "10. AI Kho pháp lý hồ sơ",
      path: "/ai-kho-phap-ly",
    });
    expect(
      DASHBOARD_MENU_GROUPS.find(
        group => group.id === "ai-production"
      )?.items.map(item => item.path)
    ).toEqual(expect.arrayContaining(["/hs-dat-dai-ai", "/ai-kho-phap-ly"]));
    expect(DASHBOARD_MENU_SUBITEMS["/ai-kho-phap-ly"]).toEqual(
      expect.arrayContaining([
        expect.objectContaining({
          label: "AI hồ sơ đất đai tự động",
          path: "/ai-ho-so-dat-dai-tu-dong",
        }),
        expect.objectContaining({
          label: "AI hồ sơ đất đai tự động nâng cao",
          path: "/ai-ho-so-dat-dai-tu-dong-moi",
        }),
      ])
    );
  });

  it("keeps three separate land dossier AI entry points", () => {
    expect(DASHBOARD_MENU_SUBITEMS["/hs-dat-dai-ai"]).toEqual([
      {
        label: "Mục 1 · Tạo hồ sơ & AI phân tích",
        path: "/hs-dat-dai-ai?tab=create",
      },
      { label: "Mục 2 · Hồ sơ của tôi", path: "/hs-dat-dai-ai?tab=mine" },
      {
        label: "Mục 3 · AI chuyên trách đất đai",
        path: "/hs-dat-dai-ai?tab=specialized",
      },
    ]);
    expect(
      isDashboardPathActive("/hs-dat-dai-ai?tab=specialized", "/hs-dat-dai-ai")
    ).toBe(true);
  });

  it("keeps land dossier AI separate and groups production modules under the legal AI knowledge base", () => {
    expect(DASHBOARD_MENU_ITEMS).toContainEqual({
      icon: expect.anything(),
      label: "5. AI Matching & Trợ lý",
      path: "/dashboard/ai",
    });
    expect(
      DASHBOARD_MENU_ITEMS.filter(item => item.path === "/dashboard/ai")
    ).toHaveLength(1);
    expect(DASHBOARD_MENU_ITEMS).toContainEqual({
      icon: expect.anything(),
      label: "9. Hồ sơ đất đai AI",
      path: "/hs-dat-dai-ai",
    });
    expect(
      DASHBOARD_MENU_GROUPS.find(group => group.id === "ai-production")?.label
    ).toBe("9 · AI pháp lý & Hồ sơ đất đai");
    expect(DASHBOARD_MENU_GROUPS.find(group => group.id === "ai")?.label).toBe(
      "5 · AI Matching & Trợ lý"
    );
  });
});

describe("central menu groups", () => {
  it("includes every major website work area and its child routes", () => {
    expect(DASHBOARD_MENU_GROUPS.map(group => group.id)).toEqual([
      "overview",
      "inventory",
      "marketing",
      "customers",
      "ai",
      "process",
      "transactions",
      "dossiers",
      "ai-production",
      "storage",
      "reports",
      "storefront",
    ]);

    const groupPaths = DASHBOARD_MENU_GROUPS.flatMap(group =>
      group.items.map(item => item.path)
    );
    expect(groupPaths).toEqual(
      expect.arrayContaining([
        "/crm",
        "/dashboard",
        "/",
        "/quan-ly-moi-gioi",
        "/dashboard/khach-hang",
        "/quan-ly",
        "/quy-trinh-moi-gioi",
        "/dashboard/marketing",
        "/dashboard/ai",
        "/dashboard/bao-cao",
        "/ho-so-dien-tu",
        "/ai-kho-phap-ly",
        "/hs-dat-dai-ai",
        "/kho-luu-tru",
      ])
    );
    expect(new Set(groupPaths).size).toBe(groupPaths.length);
  });
});

describe("nested submenu navigation", () => {
  it("provides child actions for the main workspaces", () => {
    const requiredPaths = [
      "/dashboard",
      "/bat-dong-san",
      "/dashboard/khach-hang",
      "/dashboard/giao-dich",
      "/dashboard/marketing",
      "/ho-so-dien-tu",
      "/hs-dat-dai-ai",
      "/ai-lap-ho-so-dat-dai",
      "/ai-ho-so-dat-dai",
      "/ai-kho-phap-ly",
      "/dashboard/bao-cao",
      "/kho-luu-tru",
    ];

    for (const path of requiredPaths) {
      expect(DASHBOARD_MENU_SUBITEMS[path]?.length).toBeGreaterThan(0);
      expect(
        DASHBOARD_MENU_SUBITEMS[path].every(
          item => item.label && item.path.startsWith("/")
        )
      ).toBe(true);
    }
  });
});

describe("consultation management navigation", () => {
  it("exposes the shared consultation intake menu", () => {
    expect(DASHBOARD_MENU_ITEMS).toContainEqual({
      icon: expect.anything(),
      label: "2. Tư vấn & ký gửi",
      path: "/quan-ly",
    });
  });
});
