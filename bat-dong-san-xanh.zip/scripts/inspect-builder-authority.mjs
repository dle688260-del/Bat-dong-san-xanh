import fs from "node:fs";
const file = fs.readFileSync("client/src/pages/LandDossierBuilder.tsx", "utf8");
const needles = ["const [province", "const [district", "const [ward", "const [receiving", "legalKnowledge.", "Cơ quan tiếp nhận", "Tỉnh/thành", "Quận/huyện", "Xã/phường"];
for (const needle of needles) {
  const index = file.indexOf(needle);
  console.log(`\n=== ${needle} @ ${index} ===`);
  if (index >= 0) console.log(file.slice(Math.max(0, index - 500), Math.min(file.length, index + 1800)));
}
