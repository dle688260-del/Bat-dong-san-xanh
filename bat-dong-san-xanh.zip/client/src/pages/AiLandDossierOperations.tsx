import { useMemo, useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Activity, CheckCircle2, ExternalLink, FileClock, FileSearch, GitBranch, Loader2, RefreshCw, ShieldCheck, XCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";

const formatDate = (value: unknown) => value ? new Date(String(value)).toLocaleString("vi-VN") : "Chưa có";

export default function AiLandDossierOperations() {
  const [code, setCode] = useState("1.012789");
  const [dossierId, setDossierId] = useState("");
  const [activeCode, setActiveCode] = useState("1.012789");
  const [activeDossierId, setActiveDossierId] = useState<number | null>(null);
  const history = trpc.aiLandDossierAdmin.versionHistory.useQuery({ code: activeCode }, { retry: false });
  const crawler = trpc.aiLandDossierAdmin.crawlerStatus.useQuery({ code: activeCode }, { retry: false });
  const mappings = trpc.aiLandDossierAdmin.templateMappings.useQuery({ procedureId: history.data?.procedure.id || 0 }, { enabled: Boolean(history.data?.procedure.id), retry: false });
  const audits = trpc.aiLandDossierAdmin.dossierAudits.useQuery({ dossierId: activeDossierId || 0 }, { enabled: Boolean(activeDossierId), retry: false });
  const utils = trpc.useUtils();
  const appendAudit = trpc.aiLandDossierAdmin.appendAudit.useMutation({ onSuccess: () => { toast.success("Đã ghi nhật ký audit."); if (activeDossierId) void utils.aiLandDossierAdmin.dossierAudits.invalidate({ dossierId: activeDossierId }); }, onError: error => toast.error(error.message) });
  const sourceCount = crawler.data?.sourceCount ?? 0;
  const versionCount = history.data?.versions?.length ?? 0;
  const approvedMappings = useMemo(() => (mappings.data || []).filter(item => item.status === "approved").length, [mappings.data]);
  const loadCode = () => { const value = code.trim(); if (value.length < 2) { toast.error("Nhập mã thủ tục hợp lệ."); return; } setActiveCode(value); };
  const loadDossier = () => { const value = Number(dossierId); if (!Number.isInteger(value) || value < 1) { toast.error("Nhập ID hồ sơ là số nguyên dương."); return; } setActiveDossierId(value); };
  const recordAudit = (status: "passed" | "warning" | "blocked") => { if (!activeDossierId) { toast.error("Hãy nhập ID hồ sơ trước."); return; } appendAudit.mutate({ dossierId: activeDossierId, action: "admin_review", status, evidence: { procedureCode: activeCode, recordedAt: new Date().toISOString() } }); };

  return <DashboardLayout>
    <div className="min-h-screen bg-[#F4F8F3] p-4 md:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <header className="rounded-3xl bg-gradient-to-br from-[#123C32] via-[#1F5A4A] to-[#6D8F61] p-6 text-white shadow-lg md:p-8">
          <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
            <div><div className="mb-2 flex items-center gap-2 text-sm text-emerald-100"><ShieldCheck className="h-4 w-4" /> Vận hành có kiểm chứng</div><h1 className="text-3xl font-black tracking-tight md:text-4xl">AI Hồ sơ đất đai · Vận hành</h1><p className="mt-2 max-w-3xl text-sm leading-6 text-emerald-50">Theo dõi phiên bản quy trình, đối chiếu ghép biểu mẫu, nhật ký audit và trạng thái nguồn DVC. Không có màn hình nào tự gắn Official khi thiếu xác minh binary.</p></div>
            <Button type="button" variant="secondary" onClick={() => { void history.refetch(); void crawler.refetch(); }}><RefreshCw className="mr-2 h-4 w-4" /> Đồng bộ lại</Button>
          </div>
        </header>

        <div className="grid gap-4 md:grid-cols-4">
          <Metric icon={<GitBranch />} label="Phiên bản quy trình" value={versionCount} tone="green" />
          <Metric icon={<Activity />} label="Nguồn DVC" value={sourceCount} tone="blue" />
          <Metric icon={<FileSearch />} label="Mapping đã duyệt" value={approvedMappings} tone="gold" />
          <Metric icon={<FileClock />} label="Audit hồ sơ" value={audits.data?.length ?? 0} tone="slate" />
        </div>

        <Card className="border-[#D6E5D8] shadow-sm"><CardContent className="grid gap-4 p-5 md:grid-cols-[1fr_auto] md:items-end"><div><Label htmlFor="procedure-code">Mã thủ tục cần theo dõi</Label><Input id="procedure-code" value={code} onChange={event => setCode(event.target.value)} onKeyDown={event => { if (event.key === "Enter") loadCode(); }} className="mt-2 bg-white" placeholder="Ví dụ: 1.012789 hoặc 2.000889" /></div><Button type="button" onClick={loadCode} className="bg-[#1F5A4A] hover:bg-[#164637]">Mở dữ liệu thủ tục</Button></CardContent></Card>

        <Tabs defaultValue="crawler" className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 bg-[#E6F0E7] md:w-[680px] md:grid-cols-4"><TabsTrigger value="crawler">Nguồn & đồng bộ</TabsTrigger><TabsTrigger value="versions">Lịch sử phiên bản</TabsTrigger><TabsTrigger value="mappings">Ghép biểu mẫu</TabsTrigger><TabsTrigger value="audits">Audit hồ sơ</TabsTrigger></TabsList>
          <TabsContent value="crawler"><Card><CardHeader><CardTitle className="flex items-center gap-2"><Activity className="h-5 w-5 text-[#1F5A4A]" /> Trạng thái crawler / nguồn thủ tục</CardTitle></CardHeader><CardContent className="space-y-4">{crawler.isLoading ? <Loading /> : crawler.error ? <ErrorNotice message={crawler.error.message} /> : <><Alert className={crawler.data?.registryFound ? "border-emerald-200 bg-emerald-50" : "border-amber-200 bg-amber-50"}><AlertDescription><strong>{crawler.data?.registryFound ? "Đã có registry thủ tục" : "Chưa có registry thủ tục"}</strong> · {crawler.data?.notice}<br /><span className="text-xs">Lần kiểm tra registry: {formatDate(crawler.data?.checkedAt)}</span></AlertDescription></Alert><div className="space-y-3">{crawler.data?.sources.map((source, index) => <div key={`${source.sourceUrl}-${index}`} className="flex flex-col gap-3 rounded-2xl border border-[#D6E5D8] bg-white p-4 md:flex-row md:items-center md:justify-between"><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><Badge className="bg-emerald-100 text-emerald-800">{source.scope === "provincial" ? "DVC theo tỉnh" : "DVC toàn quốc"}</Badge><span className="font-semibold text-[#18352D]">{source.authority}</span></div><p className="mt-1 break-all text-xs text-muted-foreground">{source.sourceUrl}</p></div><Button size="sm" variant="outline" asChild><a href={source.sourceUrl} target="_blank" rel="noreferrer"><ExternalLink className="mr-1 h-3.5 w-3.5" /> Mở nguồn</a></Button></div>)}{!crawler.data?.sources.length && <p className="rounded-xl bg-[#FFF9EA] p-4 text-sm text-[#6F5520]">Chưa có nguồn DVC trong registry cho mã này. Đây là trạng thái cần bổ sung nguồn, không được suy đoán URL.</p>}</div></>}</CardContent></Card></TabsContent>
          <TabsContent value="versions"><Card><CardHeader><CardTitle className="flex items-center gap-2"><GitBranch className="h-5 w-5 text-[#1F5A4A]" /> Lịch sử quy trình · {activeCode}</CardTitle></CardHeader><CardContent>{history.isLoading ? <Loading /> : history.error ? <ErrorNotice message={history.error.message} /> : <div className="space-y-3">{history.data?.versions.map(version => <div key={version.id} className="rounded-2xl border border-[#D6E5D8] bg-white p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><p className="font-bold text-[#18352D]">Phiên bản #{version.id}</p><p className="text-xs text-muted-foreground">Nguồn: {version.sourceUrl}</p></div><Badge variant={version.status === "active" ? "default" : "outline"}>{version.status}</Badge></div><p className="mt-2 text-xs text-muted-foreground">Tạo lúc {formatDate(version.createdAt)} · Hiệu lực từ {formatDate(version.effectiveFrom)}{version.sourceHash ? ` · SHA-256 ${version.sourceHash.slice(0, 12)}…` : ""}</p></div>)}{!history.data?.versions.length && <p className="rounded-xl bg-[#FFF9EA] p-4 text-sm text-[#6F5520]">Chưa có snapshot phiên bản được lưu. Hãy tạo snapshot sau khi crawler đọc và quản trị viên rà soát nguồn.</p>}</div>}</CardContent></Card></TabsContent>
          <TabsContent value="mappings"><Card><CardHeader><CardTitle className="flex items-center gap-2"><FileSearch className="h-5 w-5 text-[#1F5A4A]" /> Mapping biểu mẫu cho thủ tục</CardTitle></CardHeader><CardContent>{mappings.isLoading ? <Loading /> : mappings.error ? <ErrorNotice message={mappings.error.message} /> : <div className="space-y-3">{mappings.data?.map(mapping => <div key={mapping.id} className="flex flex-col gap-2 rounded-2xl border border-[#D6E5D8] bg-white p-4 md:flex-row md:items-center md:justify-between"><div><p className="font-semibold text-[#18352D]">Mẫu #{mapping.templateId}{mapping.requirementId ? ` · Thành phần #${mapping.requirementId}` : ""}</p><p className="text-xs text-muted-foreground">Độ tin cậy {mapping.confidence}% · {formatDate(mapping.reviewedAt || mapping.createdAt)}</p></div><Badge variant={mapping.status === "approved" ? "default" : mapping.status === "rejected" ? "destructive" : "outline"}>{mapping.status}</Badge></div>)}{!mappings.data?.length && <p className="rounded-xl bg-[#FFF9EA] p-4 text-sm text-[#6F5520]">Chưa có mapping được lưu cho procedure này. AI vẫn có thể đề xuất ở module lập hồ sơ, nhưng chưa được coi là phê duyệt.</p>}</div>}</CardContent></Card></TabsContent>
          <TabsContent value="audits"><Card><CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-[#1F5A4A]" /> Nhật ký kiểm tra hồ sơ</CardTitle></CardHeader><CardContent className="space-y-4"><div className="grid gap-3 md:grid-cols-[1fr_auto]"><div><Label htmlFor="dossier-id">ID hồ sơ</Label><Input id="dossier-id" value={dossierId} onChange={event => setDossierId(event.target.value)} placeholder="Ví dụ: 12" className="mt-2 bg-white" /></div><Button type="button" variant="outline" onClick={loadDossier}>Mở audit</Button></div>{activeDossierId && <div className="flex flex-wrap gap-2"><Button size="sm" onClick={() => recordAudit("passed")} disabled={appendAudit.isPending} className="bg-emerald-700"><CheckCircle2 className="mr-1 h-4 w-4" /> Ghi đạt</Button><Button size="sm" variant="outline" onClick={() => recordAudit("warning")} disabled={appendAudit.isPending}><AlertTriangleIcon /> Ghi cảnh báo</Button><Button size="sm" variant="destructive" onClick={() => recordAudit("blocked")} disabled={appendAudit.isPending}><XCircle className="mr-1 h-4 w-4" /> Ghi chặn</Button></div>}{audits.isLoading && <Loading />}{audits.error && <ErrorNotice message={audits.error.message} />}{audits.data?.map(audit => <div key={audit.id} className="rounded-2xl border border-[#D6E5D8] bg-white p-4"><div className="flex items-center justify-between gap-3"><p className="font-semibold text-[#18352D]">{audit.action}</p><Badge variant={audit.status === "passed" ? "default" : audit.status === "blocked" ? "destructive" : "outline"}>{audit.status}</Badge></div><p className="mt-1 text-xs text-muted-foreground">{formatDate(audit.createdAt)} · actor #{audit.actorId || "system"}</p></div>)}</CardContent></Card></TabsContent>
        </Tabs>
      </div>
    </div>
  </DashboardLayout>;
}

function Metric({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: "green" | "blue" | "gold" | "slate" }) { const colors = { green: "bg-emerald-50 text-emerald-800", blue: "bg-sky-50 text-sky-800", gold: "bg-amber-50 text-amber-800", slate: "bg-slate-50 text-slate-800" }; return <Card className="border-[#D6E5D8] shadow-sm"><CardContent className="flex items-center gap-3 p-4"><div className={`rounded-xl p-2 ${colors[tone]}`}>{icon}</div><div><p className="text-xs text-muted-foreground">{label}</p><p className="text-2xl font-black text-[#18352D]">{value}</p></div></CardContent></Card>; }
function Loading() { return <div className="flex items-center gap-2 py-8 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Đang tải dữ liệu quản trị…</div>; }
function ErrorNotice({ message }: { message: string }) { return <Alert variant="destructive"><AlertDescription>{message}</AlertDescription></Alert>; }
function AlertTriangleIcon() { return <span className="mr-1 text-base">!</span>; }
