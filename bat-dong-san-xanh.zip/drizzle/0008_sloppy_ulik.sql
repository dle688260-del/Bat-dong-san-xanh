CREATE TABLE `property_archive_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`propertyId` int NOT NULL,
	`category` enum('property','legal','valuation','marketing','transaction') NOT NULL,
	`documentType` varchar(160) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`url` text NOT NULL,
	`storageKey` text NOT NULL,
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `property_archive_files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `property_archive_files` ADD CONSTRAINT `property_archive_files_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `property_archive_files` ADD CONSTRAINT `property_archive_files_uploadedBy_users_id_fk` FOREIGN KEY (`uploadedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;