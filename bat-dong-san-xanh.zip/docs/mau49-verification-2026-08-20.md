# Xác minh tệp Mẫu49 — 2026-08-20

Tệp người dùng gửi: `/home/ubuntu/upload/Mẫu49-Pl2-151-2025-ND-CP.doc`

Metadata từ `file`: Composite Document File V2 Document, Microsoft Word, 3 trang, 698 từ, 3,981 ký tự, tạo/lưu lần cuối ngày 27/08/2025, tác giả/Last Saved By: Thu Thao, không có Security flag.

Kích thước: 47,104 bytes.
SHA-256: `6951b30c30d7724beb616a7d84e9bb94e5ace600bf58e0d5fbea74fae03f4bc7`.

LibreOffice đọc được tệp và chuyển đổi sang văn bản thành công. Nội dung là **Mẫu số 49**, thuộc **Phụ lục II** của **Nghị định 151/2025/NĐ-CP**, dùng cho tổ chức kinh tế đề nghị nhận chuyển nhượng/thuê quyền sử dụng đất/nhận góp vốn bằng quyền sử dụng đất để thực hiện dự án đầu tư. Biểu mẫu có các trường về cơ quan nhận, tổ chức kinh tế, địa điểm và diện tích khu đất, mục đích/thời hạn/hình thức sử dụng đất, năng lực tài chính, thông tin dự án, khả năng thỏa thuận và cam kết.

Kết luận bước đầu: tệp là DOC hợp lệ và đọc được, nhưng chưa thể gắn Official chỉ dựa trên tên file hoặc metadata cục bộ. Cần đối chiếu URL DVC/Nghị định chính thức và mã thủ tục cụ thể của người dùng; sau đó mới lưu metadata/provenance và ghép vào đúng dossier component.
