import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
const routerSource = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
const transactionSource = readFileSync(resolve(process.cwd(), "client/src/pages/TransactionCenter.tsx"), "utf8");

describe("sold property to transaction sync contract", () => {
  it("creates or reuses one linked deal when a property becomes sold", () => {
    expect(dbSource).toContain("ensureDealForSoldProperty");
    expect(dbSource).toContain('eq(properties.status, "sold")');
    expect(dbSource).toContain("eq(deals.propertyId, propertyId)");
    expect(dbSource).toContain('ne(deals.stage, "cancelled")');
  });

  it("invokes automatic handoff from the sold status mutation", () => {
    expect(routerSource).toContain("ensureDealForSoldProperty(input.id, ctx.user.id)");
    expect(routerSource).toContain("deal, productionStatus");
  });

  it("keeps manual sold-property selection available", () => {
    expect(transactionSource).toContain("trpc.properties.soldForTransaction.useQuery");
    expect(transactionSource).toContain("propertyId: Number(form.propertyId)");
    expect(transactionSource).toContain("Sản phẩm Đã bán trong Nguồn hàng");
  });
});
