import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const proxySource = readFileSync(new URL("./_core/storageProxy.ts", import.meta.url), "utf8");

describe("Storage proxy binary access contract", () => {
  it("fetches the signed object server-side instead of redirecting the browser", () => {
    expect(proxySource).toContain("objectResp = await fetch(url, { signal: controller.signal });");
    expect(proxySource).toContain("res.send(Buffer.from(await objectResp.arrayBuffer()));");
    expect(proxySource).not.toContain("res.redirect(307, url)");
  });

  it("preserves content type, caches images, and protects non-image files", () => {
    expect(proxySource).toContain('res.set("Content-Type", contentType)');
    expect(proxySource).toContain('const isCacheableImage = contentType?.toLowerCase().startsWith("image/") === true;');
    expect(proxySource).toContain('"public, max-age=3600, stale-while-revalidate=86400"');
    expect(proxySource).toContain('"no-store, no-cache, must-revalidate"');
    expect(proxySource).toContain('res.set("X-Content-Type-Options", "nosniff")');
  });

  it("fails closed when Forge does not return a valid HTTP signed URL", () => {
    expect(proxySource).toContain('!/^https?:\\/\\//i.test(url)');
    expect(proxySource).toContain('res.status(502).send("Empty signed URL from backend")');
  });

  it("exposes an application-owned Official endpoint outside the reserved storage path", () => {
    expect(proxySource).toContain('app.get("/api/official-storage"');
    expect(proxySource).toContain('key.startsWith(OFFICIAL_STORAGE_PREFIX)');
    expect(proxySource).toContain('const OFFICIAL_STORAGE_PREFIX = "legal-official/"');
    expect(proxySource).toContain('res.status(400).send("Invalid official storage key")');
  });
});
