import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { LandProcedureGuidanceStep } from "@/components/LandProcedureGuidanceStep";
import { LegalSourceRegistryPanel } from "@/components/LegalSourceRegistryPanel";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  BookOpen,
  Camera,
  CheckCircle2,
  ClipboardCheck,
  Download,
  ExternalLink,
  FileText,
  FolderOpen,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  Upload,
  X,
  Users,
  UserRound,
  Building2,
  ReceiptText,
  Handshake,
  BriefcaseBusiness,
  FileSearch,
  ListChecks,
  PencilLine,
  FileDown,
  Save,
} from "lucide-react";
import { Document, HeadingLevel, Packer, Paragraph, TextRun } from "docx";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { landDossierBuilderTemplates } from "@/pages/LandDossierBuilder";

export const aiDossierSharedLegalSourceTitle =
  "Nguồn pháp lý từ AI Kho pháp lý hồ sơ AI";

const categories = [
  ["property", "Khảo sát BĐS"],
  ["legal", "Pháp lý"],
  ["valuation", "Định giá"],
  ["transaction", "Đặt cọc · Sang tên"],
  ["marketing", "Mẫu môi giới"],
] as const;

const transactionTypes = [
  ["transfer_land", "Chuyển nhượng nhà/đất"],
  ["inheritance", "Thừa kế quyền sử dụng đất"],
  ["agri_land", "Đất nông nghiệp"],
  ["house", "Nhà ở/căn hộ"],
  ["hotel_resort", "Khách sạn · Resort · Villa"],
  ["industrial", "Khu công nghiệp/dự án"],
  ["commercial", "BĐS thương mại"],
  ["lease", "Cho thuê"],
] as const;

type TransactionType = (typeof transactionTypes)[number][0];

const landWorkflowSteps = [
  {
    number: 1,
    title: "Kiểm tra điều kiện & giấy tờ",
    items: [
      "Thông tin bên chuyển nhượng",
      "Thông tin bên nhận",
      "Thông tin thửa đất",
      "Giấy chứng nhận",
      "Tình trạng hôn nhân",
      "Đồng sở hữu / ủy quyền",
    ],
  },
  {
    number: 2,
    title: "Công chứng hợp đồng",
    items: [
      "Giấy chứng nhận bản gốc",
      "CCCD/giấy tờ tùy thân",
      "Giấy tờ tình trạng hôn nhân",
      "Hợp đồng dự thảo",
    ],
  },
  {
    number: 3,
    title: "Hồ sơ thuế & lệ phí",
    items: [
      "Tờ khai thuế thu nhập cá nhân",
      "Tờ khai lệ phí trước bạ",
      "Giấy tờ miễn/giảm nếu có",
    ],
  },
  {
    number: 4,
    title: "Đăng ký biến động / sang tên",
    items: [
      "Đơn đăng ký biến động",
      "Hợp đồng đã công chứng",
      "Bản gốc Giấy chứng nhận",
      "Hồ sơ thuế, lệ phí",
    ],
  },
  {
    number: 5,
    title: "Theo dõi xử lý & nhận kết quả",
    items: [
      "Nộp hồ sơ tại cơ quan tiếp nhận",
      "Theo dõi phiếu hẹn",
      "Nhận kết quả sang tên",
    ],
  },
] as const;

const universalWorkflowSteps = [
  {
    number: 1,
    key: "information",
    title: "Thông tin hồ sơ",
    description: "Chọn BĐS, chủ thể, thửa đất và dữ liệu đầu vào.",
  },
  {
    number: 2,
    key: "procedure",
    title: "Chọn thủ tục",
    description: "Xác định đúng thủ tục, trường hợp và cơ quan tiếp nhận.",
  },
  {
    number: 3,
    key: "analysis",
    title: "AI phân tích",
    description:
      "Đối chiếu dữ liệu, phát hiện thiếu và gợi ý thành phần hồ sơ.",
  },
  {
    number: 4,
    key: "assembly",
    title: "Lắp bộ hồ sơ",
    description: "Tự điền dữ liệu vào khung mẫu và tạo mục lục hồ sơ.",
  },
  {
    number: 5,
    key: "review",
    title: "Rà soát & chỉnh sửa",
    description:
      "Kiểm tra nội dung, cập nhật trường còn thiếu và xác nhận bản nháp.",
  },
  {
    number: 6,
    key: "export",
    title: "Xuất hồ sơ",
    description: "Tải DOCX hoặc in/lưu PDF sau khi đã kiểm tra.",
  },
] as const;

const manualBrokerTemplate = {
  id: "owner-negotiation",
  title: "Phiếu đàm phán BĐS · thông tin chủ nhà / chủ ký gửi",
  fileName: "phieu-dam-phan-bds.docx",
  fileUrl: "/manus-storage/phieu-dam-phan-bds_62098c93.docx",
  usage:
    "Mẫu làm việc thủ công để môi giới in hoặc mở trên điện thoại, cùng chủ nhà/chủ ký gửi ghi nhận thông tin và ký xác nhận.",
};

const procedureRequirementMap: Record<string, string[]> = {
  variation: [
    "Thông tin người sử dụng đất/chủ sở hữu",
    "Giấy chứng nhận",
    "Văn bản làm căn cứ biến động",
    "Thông tin bên nhận hoặc nội dung thay đổi",
    "Nghĩa vụ tài chính và giấy tờ liên quan",
  ],
  certificate: [
    "Thông tin người sử dụng đất",
    "Nguồn gốc sử dụng đất",
    "Thông tin thửa đất",
    "Tài liệu chứng minh quá trình sử dụng",
    "Sơ đồ/bản trích đo nếu cần",
  ],
  purpose: [
    "Giấy chứng nhận",
    "Mục đích sử dụng hiện tại",
    "Mục đích đề nghị chuyển",
    "Quy hoạch/kế hoạch sử dụng đất",
    "Nghĩa vụ tài chính dự kiến",
  ],
  split: [
    "Giấy chứng nhận",
    "Thông tin thửa đất gốc",
    "Phương án các thửa sau tách",
    "Bản vẽ/trích đo",
    "Điều kiện diện tích, kích thước, lối đi",
  ],
  merge: [
    "Giấy chứng nhận của các thửa",
    "Thông tin các thửa liền kề",
    "Mục đích sử dụng và thời hạn",
    "Phương án thửa sau hợp",
    "Bản vẽ/trích đo",
  ],
  transfer: [
    "Thông tin bên chuyển nhượng",
    "Thông tin bên nhận",
    "Giấy chứng nhận",
    "Hợp đồng/văn bản chuyển quyền",
    "Thuế, lệ phí và đăng ký biến động",
  ],
  gift: [
    "Thông tin bên tặng cho",
    "Thông tin bên nhận tặng cho",
    "Giấy chứng nhận",
    "Văn bản tặng cho",
    "Quan hệ miễn/giảm và đăng ký biến động",
  ],
  inheritance: [
    "Giấy chứng nhận",
    "Giấy chứng tử hoặc căn cứ thừa kế",
    "Thông tin người thừa kế",
    "Di chúc/văn bản thỏa thuận",
    "Đăng ký biến động và nghĩa vụ liên quan",
  ],
  mortgage: [
    "Giấy chứng nhận",
    "Thông tin bên bảo đảm",
    "Hợp đồng thế chấp",
    "Thông tin bên nhận bảo đảm",
    "Đăng ký biện pháp bảo đảm",
  ],
  release: [
    "Giấy chứng nhận",
    "Văn bản giải chấp",
    "Thông tin bên bảo đảm",
    "Xác nhận của bên nhận bảo đảm",
    "Hồ sơ xóa đăng ký",
  ],
  tax: [
    "Thông tin người nộp thuế",
    "Thông tin giao dịch/tài sản",
    "Giá trị và căn cứ tính",
    "Tờ khai tương ứng",
    "Chứng từ nộp hoặc miễn giảm",
  ],
};

const fallbackLandProcedures = [
  {
    id: "variation",
    title: "Đăng ký biến động đất đai",
    hint: "Chuyển nhượng, tặng cho, thừa kế, thay đổi thông tin",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "variation-m09",
  },
  {
    id: "certificate",
    title: "Cấp Giấy chứng nhận",
    hint: "Đăng ký đất đai, cấp giấy chứng nhận lần đầu",
    transactionType: "agri_land" as TransactionType,
    sourceId: "registration-land-m15",
  },
  {
    id: "purpose",
    title: "Chuyển mục đích sử dụng đất",
    hint: "Kiểm tra điều kiện, quy hoạch và nghĩa vụ tài chính",
    transactionType: "agri_land" as TransactionType,
    sourceId: "registration-land-m15",
  },
  {
    id: "split",
    title: "Tách thửa",
    hint: "Đơn đề nghị tách thửa, bản vẽ và giấy chứng nhận",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "split-merge-land",
  },
  {
    id: "merge",
    title: "Hợp thửa",
    hint: "Đơn đề nghị hợp thửa, bản vẽ và giấy chứng nhận",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "split-merge-land",
  },
  {
    id: "transfer",
    title: "Chuyển nhượng",
    hint: "Hợp đồng, đăng ký biến động và hồ sơ thuế",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "variation-m09",
  },
  {
    id: "gift",
    title: "Tặng cho",
    hint: "Văn bản tặng cho và hồ sơ đăng ký biến động",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "variation-m09",
  },
  {
    id: "inheritance",
    title: "Thừa kế",
    hint: "Văn bản thừa kế, nhân thân và đăng ký biến động",
    transactionType: "inheritance" as TransactionType,
    sourceId: "variation-m09",
  },
  {
    id: "mortgage",
    title: "Đăng ký thế chấp",
    hint: "Hợp đồng bảo đảm và đăng ký biện pháp bảo đảm",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "transfer-variation",
  },
  {
    id: "release",
    title: "Xóa đăng ký thế chấp",
    hint: "Văn bản giải chấp và cập nhật đăng ký",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "transfer-variation",
  },
  {
    id: "tax",
    title: "Thuế và lệ phí liên quan",
    hint: "Tờ khai, lệ phí trước bạ và chứng từ nghĩa vụ tài chính",
    transactionType: "transfer_land" as TransactionType,
    sourceId: "transfer-tax",
  },
] as const;

type LandProcedureOption = {
  id: string;
  title: string;
  hint: string;
  transactionType: TransactionType;
  sourceId: string;
};

type ChecklistItem = {
  id: string;
  label: string;
  hint: string;
  categories: string[];
};
type LandSearchAiAssist = {
  summary: string;
  checklist: Array<{
    label: string;
    status: "required" | "conditional" | "verify";
    note: string;
  }>;
  nextSteps: string[];
  disclaimer: string;
};
type PrePrintChecklistItem = {
  id: string;
  label: string;
  templateLabel?: string;
  templateFile?: string;
  templateStatus: "official" | "reference" | "pending" | "not-applicable";
  templateSource?: string;
};
type AIDossierOcrField = {
  key: string;
  label: string;
  value: string;
  confidence: number;
  evidence: string;
};
type AIDossierOcrResult = {
  fileName: string;
  mimeType: string;
  storageKey?: string;
  fileUrl?: string;
  documentType: string;
  fields: AIDossierOcrField[];
  warnings: string[];
  overallConfidence: number;
  reviewed: boolean;
  warning?: string;
};
type AIDossierAnalysisResult = {
  procedureCode: string;
  province: string;
  fields: Array<{
    key: string;
    label: string;
    value: string;
    source: "profile" | "ocr" | "missing";
    evidence: string;
    confidence: number;
    needsConfirmation: boolean;
    required: boolean;
  }>;
  warnings: string[];
  missingComponents: string[];
  legalNotes: string[];
  verifiedTemplateCount: number;
  officialExportEligible: boolean;
  notice: string;
  analyzedAt: string;
};
type LandEvidenceItem = {
  name: string;
  size: number;
  type: string;
  status: "uploaded" | "ocr" | "analysis" | "review" | "error";
  progress: number;
  stage: string;
  documentType?: string;
  storageKey?: string;
  fileUrl?: string;
  ocr?: AIDossierOcrResult;
};
type LandOcrMimeType =
  | "image/jpeg"
  | "image/png"
  | "image/webp"
  | "application/pdf"
  | "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  | "application/msword"
  | "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  | "application/vnd.ms-excel";

const adminToBuilderProcedure: Record<string, string> = {
  first_registration: "first-registration",
  reissue: "certificate-reissue",
  renewal: "certificate-renewal",
  purpose_change: "purpose",
  split: "split",
  merge: "merge",
  transfer: "transfer",
  gift: "gift",
  inheritance: "inheritance",
  mortgage: "mortgage",
  release_mortgage: "mortgage",
  tax_fee: "registration-fee",
  variation: "variation",
};

function matchOfficialTemplateForRequirement(
  procedureId: string,
  document: string
) {
  const templates = landDossierBuilderTemplates(
    adminToBuilderProcedure[procedureId] ?? procedureId
  );
  const normalized = document.toLowerCase();
  const template =
    templates.find(item => {
      const label = `${item.label} ${item.fileName}`.toLowerCase();
      return (
        (normalized.includes("đơn") && label.includes("đơn")) ||
        (normalized.includes("lệ phí") && label.includes("lệ phí")) ||
        (normalized.includes("thuế") && label.includes("thuế")) ||
        (normalized.includes("tách thửa") && label.includes("tách thửa")) ||
        (normalized.includes("hợp thửa") && label.includes("hợp thửa"))
      );
    }) ??
    (templates.length === 1 && /đơn|tờ khai|biểu mẫu/i.test(document)
      ? templates[0]
      : undefined);
  if (!template) return { templateStatus: "not-applicable" as const };
  return {
    templateLabel: template.label,
    templateFile: template.fileName,
    templateSource: template.sourceUrl,
    // Có mapping + nguồn/file tham chiếu thì phải hiện Reference; chỉ binary đã xác minh mới là Official.
    templateStatus:
      template.provenance === "verified-binary"
        ? ("official" as const)
        : ("reference" as const),
  };
}

const checklistByType: Record<TransactionType, ChecklistItem[]> = {
  transfer_land: [
    {
      id: "identity",
      label: "Thông tin chủ thể và người liên quan",
      hint: "Đối chiếu danh tính theo hồ sơ gốc, không chỉ dựa vào bản scan.",
      categories: ["legal"],
    },
    {
      id: "certificate",
      label: "Giấy chứng nhận hoặc tài liệu quyền sử dụng",
      hint: "Kiểm tra bản gốc và thông tin thửa đất.",
      categories: ["legal"],
    },
    {
      id: "planning",
      label: "Thông tin quy hoạch cần đối chiếu",
      hint: "Kết quả AI chỉ là tham khảo, cần xác minh nguồn chính thức.",
      categories: ["legal", "property"],
    },
    {
      id: "deposit",
      label: "Thỏa thuận/đặt cọc và điều kiện giao dịch",
      hint: "Ghi rõ điều kiện, thời hạn và trách nhiệm các bên.",
      categories: ["transaction"],
    },
    {
      id: "notary",
      label: "Hồ sơ công chứng và đăng ký biến động",
      hint: "Cơ quan tiếp nhận có thể yêu cầu bổ sung theo từng trường hợp.",
      categories: ["transaction", "legal"],
    },
  ],
  inheritance: [
    {
      id: "death",
      label: "Tài liệu chứng minh sự kiện thừa kế",
      hint: "Cần rà soát bản gốc và quan hệ nhân thân.",
      categories: ["legal"],
    },
    {
      id: "heirs",
      label: "Thông tin và ý chí của người thừa kế",
      hint: "Không tự kết luận quyền hưởng nếu chưa được chuyên môn xác nhận.",
      categories: ["legal"],
    },
    {
      id: "certificate",
      label: "Giấy chứng nhận quyền sử dụng đất",
      hint: "Đối chiếu thửa đất, chủ sử dụng và tình trạng đăng ký.",
      categories: ["legal"],
    },
    {
      id: "registration",
      label: "Hồ sơ đăng ký biến động",
      hint: "Kiểm tra yêu cầu của cơ quan đăng ký đất đai địa phương.",
      categories: ["transaction", "legal"],
    },
  ],
  agri_land: [
    {
      id: "certificate",
      label: "Giấy chứng nhận và mục đích sử dụng đất",
      hint: "Không suy đoán mục đích sử dụng từ hình ảnh mờ.",
      categories: ["legal"],
    },
    {
      id: "planning",
      label: "Quy hoạch và hạn chế sử dụng",
      hint: "Cần đối chiếu dữ liệu quy hoạch hiện hành.",
      categories: ["legal", "property"],
    },
    {
      id: "land_use",
      label: "Thời hạn và điều kiện sử dụng",
      hint: "Yêu cầu chuyên môn kiểm tra theo loại đất và giao dịch.",
      categories: ["legal"],
    },
    {
      id: "transfer",
      label: "Hồ sơ chuyển nhượng/cho thuê phù hợp",
      hint: "Mẫu chỉ là bản nháp nội bộ.",
      categories: ["transaction"],
    },
  ],
  house: [
    {
      id: "certificate",
      label: "Giấy chứng nhận nhà, đất và tài sản gắn liền",
      hint: "Đối chiếu diện tích, hiện trạng và chủ sở hữu.",
      categories: ["legal"],
    },
    {
      id: "survey",
      label: "Phiếu khảo sát hiện trạng",
      hint: "Bổ sung ảnh, video và thông số đo thực tế.",
      categories: ["property"],
    },
    {
      id: "planning",
      label: "Thông tin quy hoạch/xây dựng cần kiểm tra",
      hint: "Không coi bản đồ hoặc OCR là kết luận chính thức.",
      categories: ["legal"],
    },
    {
      id: "transaction",
      label: "Hồ sơ giao dịch và bàn giao",
      hint: "Theo dõi tiến độ từ đặt cọc đến hoàn tất.",
      categories: ["transaction"],
    },
  ],
  hotel_resort: [
    {
      id: "asset",
      label: "Hồ sơ tài sản và quyền sử dụng đất",
      hint: "Tách rõ phần đất, công trình và tài sản kinh doanh.",
      categories: ["legal", "property"],
    },
    {
      id: "operation",
      label: "Thông tin vận hành/khai thác",
      hint: "Chỉ ghi nhận tài liệu được cung cấp và có nguồn.",
      categories: ["property", "valuation"],
    },
    {
      id: "planning",
      label: "Quy hoạch, xây dựng và giấy phép liên quan",
      hint: "Cần chuyên môn xác minh hiệu lực.",
      categories: ["legal"],
    },
    {
      id: "transaction",
      label: "Bộ hồ sơ giao dịch",
      hint: "Dự thảo phải được kiểm tra trước khi dùng.",
      categories: ["transaction"],
    },
  ],
  industrial: [
    {
      id: "project",
      label: "Hồ sơ dự án/quyền sử dụng đất",
      hint: "Phân biệt quyền sử dụng đất, hạ tầng và dự án.",
      categories: ["legal", "property"],
    },
    {
      id: "planning",
      label: "Quy hoạch và chấp thuận liên quan",
      hint: "Đối chiếu văn bản/nguồn chính thức.",
      categories: ["legal"],
    },
    {
      id: "lease",
      label: "Điều kiện thuê/chuyển nhượng",
      hint: "Không tự kết luận khả năng giao dịch.",
      categories: ["transaction"],
    },
    {
      id: "valuation",
      label: "Thông tin định giá và so sánh",
      hint: "Kết quả AI không thay thế thẩm định.",
      categories: ["valuation"],
    },
  ],
  commercial: [
    {
      id: "asset",
      label: "Hồ sơ pháp lý tài sản thương mại",
      hint: "Đối chiếu quyền sở hữu, sử dụng và hiện trạng.",
      categories: ["legal"],
    },
    {
      id: "valuation",
      label: "Thông tin giá và hiệu quả khai thác",
      hint: "Chỉ sử dụng số liệu có tài liệu nguồn.",
      categories: ["valuation"],
    },
    {
      id: "lease",
      label: "Hợp đồng thuê/khai thác nếu có",
      hint: "Bảo vệ thông tin nhạy cảm khi tải lên.",
      categories: ["transaction"],
    },
    {
      id: "transaction",
      label: "Bộ hồ sơ mua bán/chuyển nhượng",
      hint: "Cần rà soát theo giao dịch thực tế.",
      categories: ["transaction"],
    },
  ],
  lease: [
    {
      id: "owner",
      label: "Thông tin người cho thuê và tài sản",
      hint: "Đối chiếu giấy tờ và quyền cho thuê.",
      categories: ["property", "legal"],
    },
    {
      id: "condition",
      label: "Biên bản hiện trạng/bàn giao",
      hint: "Nên lưu ảnh, video và chữ ký các bên.",
      categories: ["property", "transaction"],
    },
    {
      id: "contract",
      label: "Hợp đồng thuê và phụ lục",
      hint: "Mẫu nội bộ cần được kiểm tra trước khi ký.",
      categories: ["transaction"],
    },
  ],
};

type LegalTemplate = {
  id: string;
  title: string;
  group: string;
  keywords: string[];
  authority: string;
  basis: string;
  effective: string;
  updated: string;
  transactionType: TransactionType;
  content: string;
  officialFileName?: string;
  officialFileUrl?: string;
  officialFormStatus?:
    | "official_source"
    | "legacy_reference"
    | "needs_local_review";
};
type OfficialSource = {
  sourceUrl: string;
  sourceName: string;
  issuingAgency: string;
  legalBasis: string;
  effectiveDate: string;
  lastCheckedAt: string;
  version: string;
  status: "verified" | "directory" | "needs_review";
};

const officialSources: Record<string, OfficialSource> = {
  "variation-m09": {
    sourceUrl:
      "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fd07c1846d6e054",
    sourceName: "CSDL thủ tục hành chính · file Mẫu số 09/ĐK",
    issuingAgency: "Cơ quan đăng ký đất đai theo thẩm quyền",
    legalBasis:
      "Mẫu số 09/ĐK được cổng tra cứu hiển thị cho đăng ký biến động; cần đối chiếu mẫu đang áp dụng theo thời điểm và địa phương",
    effectiveDate: "Cần xác nhận theo hồ sơ cụ thể",
    lastCheckedAt: "17/08/2026",
    version: "Mẫu 09/ĐK · tham chiếu lịch sử",
    status: "needs_review",
  },
  "registration-land-m15": {
    sourceUrl:
      "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1",
    sourceName: "CSDL thủ tục hành chính · Mus15DKLD.docx",
    issuingAgency: "Cơ quan đăng ký đất đai theo thẩm quyền",
    legalBasis:
      "Đơn đăng ký đất đai, tài sản gắn liền với đất theo Mẫu số 15/ĐK trong hệ thống biểu mẫu được tra cứu",
    effectiveDate: "Theo phiên bản mẫu và thủ tục đang công bố",
    lastCheckedAt: "17/08/2026",
    version: "Mus15DKLD.docx · cần đối chiếu địa phương",
    status: "verified",
  },
  "transfer-variation": {
    sourceUrl:
      "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410",
    sourceName: "Cổng Dịch vụ công Quốc gia",
    issuingAgency: "Cơ quan đăng ký đất đai theo thẩm quyền địa phương",
    legalBasis:
      "Thủ tục đăng ký biến động quyền sử dụng đất; trang chính thức có phần mẫu tải về",
    effectiveDate: "Theo phiên bản đang công bố trên cổng",
    lastCheckedAt: "16/08/2026",
    version: "2.000410 · đang công bố",
    status: "verified",
  },
  "transfer-tax": {
    sourceUrl: "https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx",
    sourceName: "Cổng Dịch vụ công Bộ Nông nghiệp và Môi trường",
    issuingAgency: "Cơ quan thuế và cơ quan tiếp nhận theo hồ sơ",
    legalBasis:
      "Tra cứu dịch vụ công chính thức; biểu mẫu thuế phải đối chiếu với cơ quan thuế",
    effectiveDate: "Chưa xác định từ nguồn đất đai này",
    lastCheckedAt: "16/08/2026",
    version: "Tra cứu · không phải bản mẫu thuế",
    status: "directory",
  },
  "registration-certificate": {
    sourceUrl:
      "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978",
    sourceName: "Cổng Dịch vụ công Quốc gia",
    issuingAgency: "UBND cấp xã/cơ quan đăng ký đất đai theo thẩm quyền",
    legalBasis:
      "Thủ tục đăng ký đất đai, tài sản gắn liền với đất và cấp Giấy chứng nhận lần đầu",
    effectiveDate: "Theo phiên bản đang công bố trên cổng",
    lastCheckedAt: "16/08/2026",
    version: "1.013978 · đang công bố",
    status: "verified",
  },
  "inheritance-file": {
    sourceUrl:
      "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410",
    sourceName: "Cổng Dịch vụ công Quốc gia",
    issuingAgency: "Cơ quan đăng ký đất đai/cơ quan công chứng theo trường hợp",
    legalBasis:
      "Thủ tục đăng ký biến động có trường hợp thừa kế, cần đối chiếu hồ sơ nhân thân và văn bản thừa kế",
    effectiveDate: "Theo phiên bản đang công bố trên cổng",
    lastCheckedAt: "16/08/2026",
    version: "2.000410 · đang công bố",
    status: "verified",
  },
  "lease-contract": {
    sourceUrl:
      "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410",
    sourceName: "Cổng Dịch vụ công Quốc gia",
    issuingAgency: "Cơ quan tiếp nhận theo loại tài sản và giao dịch",
    legalBasis:
      "Nguồn tham khảo thủ tục đăng ký biến động; hợp đồng thuê không mặc nhiên là mẫu của cổng",
    effectiveDate: "Theo hồ sơ và quy định hiện hành",
    lastCheckedAt: "16/08/2026",
    version: "2.000410 · nguồn tham chiếu",
    status: "needs_review",
  },
  "commercial-transfer": {
    sourceUrl: "https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx",
    sourceName: "Cổng Dịch vụ công Bộ Nông nghiệp và Môi trường",
    issuingAgency: "Cơ quan có thẩm quyền theo loại tài sản/dự án",
    legalBasis:
      "Tra cứu dịch vụ công chính thức; cần phân loại tài sản trước khi chọn thủ tục",
    effectiveDate: "Cần xác nhận theo giao dịch cụ thể",
    lastCheckedAt: "16/08/2026",
    version: "Tra cứu · chưa có mẫu riêng",
    status: "directory",
  },
  "split-merge-land": {
    sourceUrl:
      "https://vpcp.dichvucong.gov.vn/p/home/dich-vu-cong-truc-tuyen.html",
    sourceName: "Cổng Dịch vụ công Quốc gia · tra cứu thủ tục",
    issuingAgency: "Cơ quan đăng ký đất đai theo thẩm quyền địa phương",
    legalBasis:
      "Nguồn tra cứu chính thức cho thủ tục tách thửa/hợp thửa; cần chọn đúng địa phương và phiên bản đang áp dụng",
    effectiveDate: "Cần xác nhận theo thời điểm và địa phương",
    lastCheckedAt: "16/08/2026",
    version: "Tra cứu · chưa phải bản mẫu được xác minh",
    status: "directory",
  },
};

type OfficialLegalDocument = {
  id: string;
  title: string;
  kind: "Luật" | "Nghị định" | "Cổng thủ tục";
  sourceUrl: string;
  sourceName: string;
  issuingAgency: string;
  effectiveDate: string;
  lastCheckedAt: string;
  status: "verified" | "needs_review";
  note: string;
};

const officialLegalDocuments: OfficialLegalDocument[] = [
  {
    id: "law-31-2024-qh15",
    title: "Luật Đất đai số 31/2024/QH15",
    kind: "Luật",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=211189",
    sourceName: "Hệ thống văn bản Chính phủ",
    issuingAgency: "Quốc hội",
    effectiveDate: "01/08/2024 theo văn bản công bố",
    lastCheckedAt: "17/08/2026",
    status: "verified",
    note: "Nguồn gốc để đối chiếu nguyên tắc, quyền và thủ tục đất đai.",
  },
  {
    id: "decree-151-2025-ndcp",
    title: "Nghị định 151/2025/NĐ-CP",
    kind: "Nghị định",
    sourceUrl: "https://vanban.chinhphu.vn/?pageid=27160&docid=213927",
    sourceName: "Hệ thống văn bản Chính phủ",
    issuingAgency: "Chính phủ",
    effectiveDate: "Theo trang văn bản chính thức",
    lastCheckedAt: "17/08/2026",
    status: "verified",
    note: "Đối chiếu phân quyền, trình tự và thẩm quyền theo phạm vi áp dụng.",
  },
  {
    id: "national-public-service-land",
    title: "Tra cứu thủ tục đất đai trên Cổng Dịch vụ công Quốc gia",
    kind: "Cổng thủ tục",
    sourceUrl:
      "https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978",
    sourceName: "Cổng Dịch vụ công Quốc gia",
    issuingAgency: "Cơ quan nhà nước có thẩm quyền",
    effectiveDate: "Theo thủ tục và địa phương được chọn",
    lastCheckedAt: "17/08/2026",
    status: "verified",
    note: "Phải chọn đúng mã thủ tục, địa phương và cơ quan tiếp nhận trước khi dùng mẫu.",
  },
];

export function aiDossierOfficialLegalDocuments() {
  return officialLegalDocuments;
}

function normalizeSearchText(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d");
}
function matchesNaturalQuery(text: string, query: string) {
  const terms = normalizeSearchText(query)
    .split(/\s+/)
    .filter(term => term.length >= 2);
  if (!terms.length) return true;
  const haystack = normalizeSearchText(text);
  return terms.every(term => haystack.includes(term));
}
function getOfficialSource(templateId: string) {
  return officialSources[templateId];
}
function officialStatusLabel(status?: OfficialSource["status"]) {
  if (status === "verified") return "Nguồn chính thức đã gắn";
  if (status === "directory") return "Mở cổng tra cứu";
  return "Cần rà soát trước khi dùng";
}
function officialStatusClass(status?: OfficialSource["status"]) {
  if (status === "verified") return "bg-emerald-100 text-emerald-800";
  if (status === "directory") return "bg-blue-100 text-blue-800";
  return "bg-amber-100 text-amber-800";
}

function getProcedureLegalBundle(procedureId: string) {
  const procedure =
    certificateProcedures.find(item => item.id === procedureId) ||
    certificateProcedures[0];
  const landProcedure = fallbackLandProcedures.find(
    item => item.id === procedureId
  );
  const officialTemplateSource = landProcedure
    ? getOfficialSource(landProcedure.sourceId)
    : undefined;
  const templates = landProcedure
    ? getProcedureTemplates(landProcedure, legalTemplates)
    : [];
  return {
    procedure,
    legalDocuments: officialLegalDocuments,
    officialTemplateSource,
    templates,
  };
}

export function aiDossierProcedureLegalBundle(procedureId: string) {
  const bundle = getProcedureLegalBundle(procedureId);
  return {
    procedureTitle: bundle.procedure.title,
    legalDocuments: bundle.legalDocuments.map(document => ({
      id: document.id,
      title: document.title,
      kind: document.kind,
      sourceUrl: document.sourceUrl,
      status: document.status,
    })),
    officialTemplate: bundle.officialTemplateSource
      ? {
          sourceName: bundle.officialTemplateSource.sourceName,
          sourceUrl: bundle.officialTemplateSource.sourceUrl,
          status: bundle.officialTemplateSource.status,
        }
      : null,
    templates: bundle.templates.map(template => template.title),
  };
}

type LandAnswers = {
  seller: string;
  buyer: string;
  parcel: string;
  certificate: string;
  marital: string;
  mortgage: string;
  location: string;
};

type PropertyForLandDossier = {
  id: number;
  title: string;
  location: string;
  propertyCode?: string | null;
  area?: string | number | null;
  certificateArea?: string | number | null;
  propertyType?: string | null;
  legalStatus?: string | null;
  certificateType?: string | null;
  landUsePurpose?: string | null;
  planningStatus?: string | null;
  mortgageStatus?: string | null;
  ownerName?: string | null;
  ownerPhone?: string | null;
  price?: string | number | null;
};
export function aiDossierBuildInputProperty(
  answers: LandAnswers
): PropertyForLandDossier {
  return {
    id: 0,
    title: "Hồ sơ đầu vào chưa gắn BĐS",
    location: answers.location.trim() || "Chưa xác định khu vực",
    propertyCode: null,
    area: null,
    certificateArea: null,
    propertyType: "Đất đai",
    legalStatus: answers.certificate.trim() || null,
    certificateType: answers.certificate.trim() || null,
    mortgageStatus: answers.mortgage.trim() || null,
    ownerName: answers.seller.trim() || null,
  };
}
function getPropertyDossierFields(
  property: PropertyForLandDossier,
  procedureId: string,
  answers: LandAnswers
) {
  const fields = [
    { label: "Bất động sản", value: property.title, required: true },
    { label: "Địa chỉ/khu vực", value: property.location, required: true },
    { label: "Mã BĐS", value: property.propertyCode || "", required: false },
    {
      label: "Diện tích",
      value: property.certificateArea || property.area || "",
      required: true,
    },
    {
      label: "Chủ sử dụng/chủ sở hữu",
      value: answers.seller || property.ownerName || "",
      required: true,
    },
    {
      label: "Thông tin Giấy chứng nhận",
      value:
        answers.certificate ||
        [property.certificateType, property.legalStatus]
          .filter(Boolean)
          .join(" · "),
      required: true,
    },
    {
      label: "Mục đích sử dụng đất",
      value: property.landUsePurpose || "",
      required: procedureId === "purpose",
    },
    {
      label: "Quy hoạch",
      value: property.planningStatus || "",
      required: ["split", "merge", "purpose"].includes(procedureId),
    },
    {
      label: "Thế chấp/đồng sở hữu",
      value: answers.mortgage || property.mortgageStatus || "",
      required: ["transfer", "variation", "split", "merge"].includes(
        procedureId
      ),
    },
  ];
  if (["transfer", "variation"].includes(procedureId)) {
    fields.push({
      label: "Bên nhận quyền",
      value: answers.buyer,
      required: true,
    });
  }
  return fields;
}

function getMissingLandDossierFields(
  property: PropertyForLandDossier,
  procedureId: string,
  answers: LandAnswers
) {
  return getPropertyDossierFields(property, procedureId, answers)
    .filter(field => field.required && !String(field.value || "").trim())
    .map(field => field.label);
}

function getUniversalRequirements(procedureId: string) {
  return (
    procedureRequirementMap[procedureId] || [
      "Thông tin chủ thể",
      "Thông tin BĐS/thửa đất",
      "Giấy tờ pháp lý nền",
      "Văn bản theo thủ tục",
      "Yêu cầu của cơ quan tiếp nhận",
    ]
  );
}
function getProcedureTemplates(
  procedure: {
    id: string;
    title: string;
    hint: string;
    transactionType: TransactionType;
    sourceId: string;
  },
  templates: LegalTemplate[]
) {
  const keywords = normalizeSearchText(
    `${procedure.title} ${procedure.hint} ${getUniversalRequirements(procedure.id).join(" ")}`
  )
    .split(/\s+/)
    .filter(word => word.length >= 3);
  const exactSource = templates.find(
    template => template.id === procedure.sourceId
  );
  const excludedTemplateIds =
    procedure.id === "split"
      ? ["merge-land"]
      : procedure.id === "merge"
        ? ["split-land"]
        : [];
  const scored = templates
    .filter(template => !excludedTemplateIds.includes(template.id))
    .map(template => {
      const haystack = normalizeSearchText(
        `${template.title} ${template.group} ${template.keywords.join(" ")} ${template.transactionType}`
      );
      const score =
        (template.id === procedure.sourceId ? 100 : 0) +
        keywords.filter(keyword => haystack.includes(keyword)).length;
      return { template, score };
    })
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map(item => item.template);
  return Array.from(
    new Map(
      [...(exactSource ? [exactSource] : []), ...scored].map(template => [
        template.id,
        template,
      ])
    ).values()
  );
}
export { getProcedureTemplates, officialLegalDocuments };

export function aiDossierProcedureSearch(queryText = "", filter = "all") {
  const query = normalizeSearchText(queryText);
  return certificateProcedures.filter(item => {
    const haystack = normalizeSearchText(
      `${item.title} ${item.description} ${item.fields.join(" ")} ${item.documents.join(" ")}`
    );
    const matchesSearch = !query || haystack.includes(query);
    const matchesFilter =
      filter === "all" ||
      (filter === "giay-chung-nhan" &&
        ["first_registration", "reissue", "renewal"].includes(item.id)) ||
      (filter === "bien-dong" &&
        ["transfer", "gift", "inheritance", "variation"].includes(item.id)) ||
      (filter === "thua-dat" &&
        ["split", "merge", "purpose_change"].includes(item.id)) ||
      (filter === "bao-dam" &&
        ["mortgage", "release_mortgage"].includes(item.id)) ||
      (filter === "tai-chinh" && item.id === "tax_fee");
    return matchesSearch && matchesFilter;
  });
}

function buildUniversalChecklist(
  procedureId: string,
  property: PropertyForLandDossier,
  answers: LandAnswers
) {
  const fields = getPropertyDossierFields(property, procedureId, answers);
  const values = fields
    .map(field => `${field.label} ${field.value || ""}`)
    .join(" ");
  return getUniversalRequirements(procedureId).map((label, index) => ({
    label,
    status:
      index === 0 && values.trim()
        ? ("completed" as const)
        : ("missing" as const),
    note:
      index === 0 && values.trim()
        ? "Đã có dữ liệu từ BĐS hoặc thông tin người dùng."
        : "Cần bổ sung hoặc đối chiếu với hồ sơ gốc.",
  }));
}
function buildUniversalDossierPreview(
  property: PropertyForLandDossier,
  procedureTitle: string,
  procedureId: string,
  answers: LandAnswers,
  missingFields: string[]
) {
  const fields = getPropertyDossierFields(property, procedureId, answers).map(
    field => `${field.label}: ${field.value || "[CÒN THIẾU]"}`
  );
  const checklist = getUniversalRequirements(procedureId).map(
    (item, index) => `${index + 1}. ${item}`
  );
  return [
    `BỘ HỒ SƠ ĐẤT ĐAI AI — ${procedureTitle.toUpperCase()}`,
    `Mã tham chiếu: ${property.propertyCode || "Chưa có mã BĐS"}`,
    `BĐS: ${property.title}`,
    `Địa chỉ: ${property.location}`,
    "",
    "MỤC LỤC",
    "1. Thông tin hồ sơ",
    "2. Thủ tục và nguồn tham khảo",
    "3. Phân tích AI và checklist",
    "4. Thành phần bộ hồ sơ",
    "5. Rà soát trước khi nộp",
    "6. Xuất và lưu trữ",
    "",
    "1. THÔNG TIN HỒ SƠ",
    ...fields,
    "",
    "2. THỦ TỤC VÀ NGUỒN THAM KHẢO",
    `Thủ tục: ${procedureTitle}`,
    `Nguồn tham khảo: ${getOfficialSource(fallbackLandProcedures.find(item => item.id === procedureId)?.sourceId || "")?.sourceName || "Cần xác định theo địa phương"}`,
    "",
    "3. PHÂN TÍCH AI VÀ CHECKLIST",
    ...checklist,
    "",
    "4. THÀNH PHẦN BỘ HỒ SƠ",
    ...universalWorkflowSteps
      .slice(3, 4)
      .flatMap(step => [
        `${step.number}. ${step.title}`,
        ...getUniversalRequirements(procedureId).map(item => `- ${item}`),
      ]),
    "",
    "5. RÀ SOÁT TRƯỚC KHI NỘP",
    ...(missingFields.length
      ? missingFields.map(item => `- Cần bổ sung: ${item}`)
      : ["- Chưa phát hiện trường bắt buộc còn thiếu từ dữ liệu hiện có."]),
    "- Đối chiếu mẫu chính thức, bản gốc và yêu cầu của cơ quan tiếp nhận.",
    "",
    "6. XUẤT VÀ LƯU TRỮ",
    "- Bản DOCX/PDF này là bản chuẩn bị nội bộ; người dùng phải kiểm tra trước khi ký hoặc nộp.",
    "",
    "CẢNH BÁO: AI chỉ hỗ trợ tổng hợp và kiểm tra sơ bộ, không thay thế tư vấn pháp lý hoặc quyết định của cơ quan nhà nước.",
  ].join("\n");
}

function buildLandDossierPreview(
  property: PropertyForLandDossier,
  procedureTitle: string,
  procedureId: string,
  answers: LandAnswers,
  missingFields: string[]
) {
  const lines = getPropertyDossierFields(property, procedureId, answers).map(
    field => `${field.label}: ${field.value || "[CÒN THIẾU]"}`
  );
  return [
    `BỘ HỒ SƠ THAM KHẢO — ${procedureTitle.toUpperCase()}`,
    `BĐS: ${property.title} · ${property.propertyCode || "chưa có mã"}`,
    "",
    "I. DỮ LIỆU BẤT ĐỘNG SẢN",
    ...lines,
    "",
    "II. THÀNH PHẦN HỒ SƠ GỢI Ý",
    ...landWorkflowSteps.flatMap(step => [
      `Bước ${step.number} — ${step.title}`,
      ...step.items.map(item => `- ${item}`),
    ]),
    "",
    "III. THÔNG TIN CẦN BỔ SUNG",
    ...(missingFields.length
      ? missingFields.map(item => `- ${item}`)
      : ["- Không phát hiện trường bắt buộc còn thiếu từ dữ liệu hiện có"]),
    "",
    "CẢNH BÁO: Bản nháp do AI hỗ trợ; cần đối chiếu dữ liệu, mẫu hiện hành và yêu cầu của cơ quan tiếp nhận trước khi sử dụng hoặc nộp hồ sơ.",
  ].join("\\n");
}

const legalTemplates: LegalTemplate[] = [
  {
    id: "registration-land-m15",
    title: "Đơn đăng ký đất đai, tài sản gắn liền với đất · Mẫu số 15/ĐK",
    group: "Cấp Giấy chứng nhận / đăng ký đất đai",
    keywords: ["đăng ký đất đai", "cấp giấy chứng nhận", "mẫu 15", "Mus15DKLD"],
    authority: "Cơ quan đăng ký đất đai theo thẩm quyền",
    basis:
      "Nghị định 151/2025/NĐ-CP và thủ tục đang công bố trên CSDL thủ tục hành chính",
    effective: "Theo phiên bản mẫu đang công bố",
    updated: "17/08/2026",
    transactionType: "agri_land",
    content:
      "Mẫu gốc cần tải từ nguồn chính thức; AI chỉ điền bản xem trước để người dùng rà soát.",
    officialFileName: "Mus15DKLD.docx",
    officialFileUrl:
      "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1",
    officialFormStatus: "official_source",
  },
  {
    id: "variation-m09",
    title:
      "Đơn đăng ký biến động đất đai, tài sản gắn liền với đất · Mẫu số 09/ĐK",
    group: "Đăng ký biến động / chuyển nhượng / tặng cho / thừa kế",
    keywords: [
      "đăng ký biến động",
      "chuyển nhượng",
      "tặng cho",
      "thừa kế",
      "mẫu 09",
    ],
    authority: "Cơ quan đăng ký đất đai theo thẩm quyền",
    basis:
      "Mẫu được CSDL thủ tục hành chính hiển thị; cần kiểm tra mẫu mới theo thời điểm áp dụng",
    effective: "Cần xác nhận trước khi ký nộp",
    updated: "17/08/2026",
    transactionType: "transfer_land",
    content:
      "Bản tham chiếu có nguồn; không gắn nhãn biểu mẫu hiện hành nếu chưa đối chiếu thủ tục và địa phương.",
    officialFileName: "mau-09-dk.doc",
    officialFileUrl:
      "https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fd07c1846d6e054",
    officialFormStatus: "legacy_reference",
  },
  {
    id: "transfer-variation",
    title: "Đơn đăng ký biến động đất đai",
    group: "Đất đai",
    keywords: ["chuyển nhượng", "đăng ký biến động", "sang tên", "đất"],
    authority: "Cơ quan đăng ký đất đai — cần đối chiếu địa phương",
    basis: "Văn bản hiện hành về đăng ký đất đai; cần kiểm tra bản chính thức",
    effective: "Cần xác nhận theo thời điểm sử dụng",
    updated: "Thư viện nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "transfer_land",
    content:
      "BẢN THAM KHẢO NỘI BỘ — ĐƠN ĐĂNG KÝ BIẾN ĐỘNG ĐẤT ĐAI\\n\\nThông tin người đăng ký:\\nLý do biến động: Chuyển nhượng\\nThông tin thửa đất:\\nTài liệu kèm theo:\\n\\nCẢNH BÁO: Cần tải và đối chiếu mẫu chính thức từ cơ quan có thẩm quyền trước khi nộp.",
  },
  {
    id: "transfer-tax",
    title: "Tờ khai thuế chuyển nhượng bất động sản",
    group: "Thuế",
    keywords: ["chuyển nhượng", "thuế", "tờ khai", "mua bán"],
    authority: "Cơ quan thuế — cần xác nhận biểu mẫu đang áp dụng",
    basis: "Quy định thuế hiện hành; cần kiểm tra phiên bản mới nhất",
    effective: "Cần xác nhận theo thời điểm kê khai",
    updated: "Thư viện nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "transfer_land",
    content:
      "BẢN THAM KHẢO NỘI BỘ — TỜ KHAI THUẾ CHUYỂN NHƯỢNG\\n\\nThông tin người nộp thuế:\\nThông tin tài sản:\\nGiá chuyển nhượng:\\nThuế dự kiến:\\nTài liệu nguồn:\\n\\nCẢNH BÁO: Không dùng bản này để kê khai chính thức nếu chưa được cơ quan thuế hoặc chuyên gia xác nhận.",
  },
  {
    id: "registration-certificate",
    title: "Hồ sơ cấp Giấy chứng nhận lần đầu",
    group: "Đất đai",
    keywords: ["cấp giấy chứng nhận", "sổ đỏ", "đăng ký lần đầu", "đất"],
    authority: "Cơ quan đăng ký đất đai — tùy hồ sơ và địa phương",
    basis: "Quy định đăng ký, cấp giấy chứng nhận hiện hành",
    effective: "Cần xác nhận theo thời điểm nộp",
    updated: "Thư viện nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "agri_land",
    content:
      "CHECKLIST THAM KHẢO NỘI BỘ — CẤP GIẤY CHỨNG NHẬN LẦN ĐẦU\\n\\nThông tin người sử dụng đất:\\nNguồn gốc sử dụng:\\nThông tin thửa đất:\\nTài liệu chứng minh:\\n\\nCẢNH BÁO: Cơ quan tiếp nhận có thể yêu cầu tài liệu khác theo từng trường hợp.",
  },
  {
    id: "inheritance-file",
    title: "Bộ hồ sơ thừa kế quyền sử dụng đất",
    group: "Giao dịch",
    keywords: ["thừa kế", "di chúc", "quyền sử dụng đất", "sang tên"],
    authority: "Cơ quan công chứng/đăng ký đất đai — cần xác nhận",
    basis: "Quy định dân sự, đất đai và công chứng hiện hành",
    effective: "Cần xác nhận theo thời điểm thực hiện",
    updated: "Thư viện nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "inheritance",
    content:
      "CHECKLIST THAM KHẢO NỘI BỘ — THỪA KẾ QUYỀN SỬ DỤNG ĐẤT\\n\\nNgười để lại di sản:\\nNgười thừa kế:\\nDi chúc/văn bản thỏa thuận:\\nGiấy chứng nhận:\\nHồ sơ nhân thân:\\n\\nCẢNH BÁO: Không tự kết luận quyền thừa kế; cần chuyên gia hoặc cơ quan có thẩm quyền kiểm tra.",
  },
  {
    id: "lease-contract",
    title: "Bộ hồ sơ hợp đồng cho thuê bất động sản",
    group: "Giao dịch",
    keywords: ["cho thuê", "hợp đồng thuê", "đặt cọc", "bàn giao"],
    authority: "Các bên giao dịch; mẫu pháp lý cần chuyên gia kiểm tra",
    basis: "Quy định dân sự và nhà ở/kinh doanh bất động sản hiện hành",
    effective: "Cần xác nhận theo thời điểm ký",
    updated: "Thư viện nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "lease",
    content:
      "BẢN NHÁP NỘI BỘ — HỢP ĐỒNG CHO THUÊ\\n\\nBên cho thuê:\\nBên thuê:\\nTài sản thuê:\\nThời hạn và giá thuê:\\nĐặt cọc và bàn giao:\\n\\nCẢNH BÁO: Cần rà soát trước khi ký.",
  },
  {
    id: "commercial-transfer",
    title: "Bộ hồ sơ chuyển nhượng BĐS thương mại",
    group: "BĐS thương mại",
    keywords: [
      "thương mại",
      "khách sạn",
      "resort",
      "villa",
      "dự án",
      "chuyển nhượng",
    ],
    authority: "Cơ quan có thẩm quyền theo loại tài sản và giao dịch",
    basis:
      "Quy định đất đai, xây dựng, doanh nghiệp và kinh doanh bất động sản hiện hành",
    effective: "Cần xác nhận theo thời điểm giao dịch",
    updated: "Thư viện nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "commercial",
    content:
      "CHECKLIST THAM KHẢO NỘI BỘ — BĐS THƯƠNG MẠI\\n\\nHồ sơ quyền sử dụng đất:\\nHồ sơ tài sản/công trình:\\nGiấy phép và quy hoạch:\\nHồ sơ vận hành/khai thác:\\nHồ sơ giao dịch:\\n\\nCẢNH BÁO: Cần phân loại tài sản và kiểm tra chuyên môn trước khi sử dụng.",
  },
  {
    id: "split-land",
    title: "Đơn đề nghị tách thửa",
    group: "Đất đai",
    keywords: [
      "tách thửa",
      "tach thua",
      "chia thửa",
      "bản vẽ tách thửa",
      "giấy chứng nhận",
    ],
    authority: "Cơ quan đăng ký đất đai theo thẩm quyền địa phương",
    basis:
      "Thủ tục tách thửa; cần đối chiếu điều kiện diện tích, kích thước, lối đi và quy định địa phương",
    effective: "Cần xác nhận theo thời điểm và địa phương",
    updated: "Bản tham khảo nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "transfer_land",
    content:
      "BẢN THAM KHẢO NỘI BỘ — ĐƠN ĐỀ NGHỊ TÁCH THỬA\\n\\nThông tin người sử dụng đất:\\nThông tin thửa đất và Giấy chứng nhận:\\nLý do tách thửa:\\nPhương án các thửa sau khi tách:\\nBản vẽ/đo đạc kèm theo:\\n\\nCẢNH BÁO: Cần kiểm tra điều kiện tách thửa và mẫu chính thức tại địa phương trước khi nộp.",
  },
  {
    id: "merge-land",
    title: "Đơn đề nghị hợp thửa",
    group: "Đất đai",
    keywords: [
      "hợp thửa",
      "hop thua",
      "gộp thửa",
      "bản vẽ hợp thửa",
      "giấy chứng nhận",
    ],
    authority: "Cơ quan đăng ký đất đai theo thẩm quyền địa phương",
    basis:
      "Thủ tục hợp thửa; cần đối chiếu điều kiện liền kề, cùng mục đích sử dụng và quy định địa phương",
    effective: "Cần xác nhận theo thời điểm và địa phương",
    updated: "Bản tham khảo nội bộ — chưa thay thế mẫu chính thức",
    transactionType: "transfer_land",
    content:
      "BẢN THAM KHẢO NỘI BỘ — ĐƠN ĐỀ NGHỊ HỢP THỬA\\n\\nThông tin người sử dụng đất:\\nThông tin các thửa đất và Giấy chứng nhận:\\nLý do hợp thửa:\\nThông tin thửa đất sau khi hợp:\\nBản vẽ/đo đạc kèm theo:\\n\\nCẢNH BÁO: Cần kiểm tra điều kiện hợp thửa và mẫu chính thức tại địa phương trước khi nộp.",
  },
  {
    id: "ai-complete-land-dossier-user-spec",
    title: "AI · BỘ HỒ SƠ ĐẤT ĐAI HOÀN CHỈNH · THEO YÊU CẦU NGƯỜI DÙNG",
    group: "AI · Bộ hồ sơ theo yêu cầu người dùng",
    keywords: [
      "AI bộ hồ sơ hoàn chỉnh",
      "hồ sơ đất đai",
      "đọc nghị định",
      "lọc biểu mẫu",
      "chuyển nhượng",
      "sang tên",
      "tự động lập hồ sơ",
      "DOCX",
      "PDF",
    ],
    authority:
      "Kho pháp lý AI · cần xác nhận cơ quan tiếp nhận và địa phương trước khi dùng",
    basis:
      "Tệp yêu cầu người dùng; AI phải đối chiếu từng căn cứ với nguồn pháp lý chính thức trước khi đưa vào hồ sơ",
    effective: "Bộ khung nội bộ — không phải mẫu nhà nước gốc",
    updated: "19/08/2026",
    transactionType: "transfer_land",
    content:
      "BỘ HỒ SƠ NỘI BỘ — AI LẬP THỦ TỤC ĐẤT ĐAI HOÀN CHỈNH THEO YÊU CẦU NGƯỜI DÙNG\\n\\nMỤC ĐÍCH\\nAI tiếp nhận loại giao dịch và địa phương, đọc các nguồn pháp lý đã cấu hình, xác định thủ tục dự kiến, lọc thành phần hồ sơ và đề xuất biểu mẫu có căn cứ. Mọi kết luận phải hiển thị nguồn, ngày kiểm tra, phiên bản và trạng thái xác minh.\\n\\nQUY TRÌNH A — XÁC ĐỊNH THỦ TỤC\\n1. Chọn loại giao dịch: chuyển nhượng, tặng cho, thừa kế, cấp Giấy chứng nhận, tách thửa, hợp thửa, chuyển mục đích hoặc cho thuê.\\n2. Chọn tỉnh/thành, cơ quan tiếp nhận và mục đích thực hiện.\\n3. AI phân tích dữ liệu, đề xuất thủ tục và yêu cầu người dùng xác nhận trước khi lập hồ sơ.\\n\\nQUY TRÌNH B — ĐỐI CHIẾU PHÁP LÝ\\n1. Truy xuất nguồn chính thức đã cấu hình.\\n2. Đọc luật, nghị định, thông tư và trang thủ tục tương ứng.\\n3. Trích thành phần hồ sơ, thời hạn, cơ quan, cách nộp và căn cứ điều/khoản/điểm nếu nguồn có công bố.\\n4. Nếu chưa có nguồn hoặc chưa xác minh được tệp gốc, phải ghi CHƯA XÁC MINH và không gọi là biểu mẫu chính thức.\\n\\nQUY TRÌNH C — TẠO BỘ HỒ SƠ\\n1. Nhập thông tin các bên, thửa đất, Giấy chứng nhận, giá trị giao dịch, tình trạng hôn nhân, thế chấp/ủy quyền và liên hệ.\\n2. Tải CCCD, Giấy chứng nhận, hợp đồng, giấy tờ hôn nhân và tài liệu liên quan.\\n3. AI kiểm tra đủ, cần kiểm tra và còn thiếu; chỉ cho xuất chính thức khi người dùng xác nhận dữ liệu.\\n4. Ghép từng thành phần với biểu mẫu đã xác minh hoặc đánh dấu bản dự thảo nội bộ.\\n5. Tạo DOCX/PDF, xem trước, tải từng tệp và tải ZIP.\\n\\nDANH MỤC THÀNH PHẦN GỢI Ý CHO CHUYỂN NHƯỢNG/SANG TÊN\\n- Đơn đăng ký biến động đất đai, tài sản gắn liền với đất — mẫu phải đối chiếu đúng nguồn và địa phương.\\n- Hợp đồng chuyển nhượng — cần công chứng/chứng thực theo trường hợp.\\n- Bản gốc Giấy chứng nhận và giấy tờ nhân thân.\\n- Tờ khai thuế, lệ phí trước bạ và giấy tờ nghĩa vụ tài chính — phải chọn đúng mẫu cơ quan thuế đang áp dụng.\\n- Giấy tờ hôn nhân, ủy quyền, đồng sở hữu hoặc giải chấp nếu phát sinh.\\n\\nQUẢN TRỊ VÀ PHIÊN BẢN\\nMỗi hồ sơ lưu snapshot dữ liệu, căn cứ, biểu mẫu, nguồn, ngày kiểm tra và trạng thái. Khi sửa dữ liệu, AI chỉ ra tài liệu bị ảnh hưởng và tạo phiên bản mới.\\n\\nCẢNH BÁO PHÁP LÝ\\nĐây là bộ khung nội bộ do AI hỗ trợ, không phải một bộ biểu mẫu nhà nước gốc. Không ký, in hoặc nộp chỉ dựa trên bản này; phải đối chiếu nguồn chính thức, tệp mẫu đã xác minh và yêu cầu thực tế của cơ quan tiếp nhận.",
  },
];

const templates: Record<TransactionType, { title: string; content: string }> = {
  transfer_land: {
    title: "Bộ dự thảo chuyển nhượng nhà/đất",
    content:
      "BẢN NHÁP NỘI BỘ — CHUYỂN NHƯỢNG NHÀ/ĐẤT\n\nThông tin tài sản:\nThông tin các bên:\nGiá và phương thức thanh toán:\nĐiều kiện đặt cọc:\nThời hạn công chứng:\nHồ sơ cần đối chiếu:\n\nCẢNH BÁO: Chưa phải hợp đồng pháp lý. Cần luật sư/công chứng viên kiểm tra trước khi sử dụng.",
  },
  inheritance: {
    title: "Bộ rà soát thừa kế",
    content:
      "BẢN NHÁP NỘI BỘ — RÀ SOÁT HỒ SƠ THỪA KẾ\n\nNgười để lại di sản:\nNgười thừa kế dự kiến:\nTài sản liên quan:\nTài liệu đã có:\nTài liệu còn thiếu:\n\nCẢNH BÁO: Không kết luận quyền thừa kế. Cần chuyên gia pháp lý/cơ quan có thẩm quyền xác nhận.",
  },
  agri_land: {
    title: "Checklist đất nông nghiệp",
    content:
      "CHECKLIST NỘI BỘ — ĐẤT NÔNG NGHIỆP\n\nMục đích sử dụng:\nThời hạn sử dụng:\nThông tin quy hoạch:\nHạn chế giao dịch cần kiểm tra:\nTài liệu nguồn:\n\nCẢNH BÁO: Chỉ là mẫu tham khảo, không thay thế tư vấn pháp lý.",
  },
  house: {
    title: "Bộ hồ sơ nhà ở/căn hộ",
    content:
      "CHECKLIST NỘI BỘ — NHÀ Ở/CĂN HỘ\n\nGiấy chứng nhận:\nHiện trạng tài sản:\nQuy hoạch/xây dựng:\nPhí, nghĩa vụ và bàn giao:\nTài liệu cần bổ sung:\n\nCẢNH BÁO: Cần kiểm tra theo hồ sơ thực tế.",
  },
  hotel_resort: {
    title: "Bộ hồ sơ khách sạn/resort/villa",
    content:
      "CHECKLIST NỘI BỘ — KHÁCH SẠN/RESORT/VILLA\n\nĐất và tài sản gắn liền:\nHồ sơ dự án/xây dựng:\nVận hành/khai thác:\nGiấy phép liên quan:\nTài liệu giao dịch:\n\nCẢNH BÁO: Cần chuyên môn kiểm tra.",
  },
  industrial: {
    title: "Bộ hồ sơ khu công nghiệp/dự án",
    content:
      "CHECKLIST NỘI BỘ — KHU CÔNG NGHIỆP/DỰ ÁN\n\nHồ sơ dự án:\nQuy hoạch/chấp thuận:\nQuyền sử dụng đất/hạ tầng:\nĐiều kiện thuê/chuyển nhượng:\n\nCẢNH BÁO: Không phải kết luận pháp lý.",
  },
  commercial: {
    title: "Bộ hồ sơ BĐS thương mại",
    content:
      "CHECKLIST NỘI BỘ — BĐS THƯƠNG MẠI\n\nTài sản và quyền sử dụng:\nGiá trị/khai thác:\nHợp đồng thuê:\nHồ sơ giao dịch:\n\nCẢNH BÁO: Cần rà soát trước khi ký.",
  },
  lease: {
    title: "Bộ hồ sơ cho thuê",
    content:
      "CHECKLIST NỘI BỘ — CHO THUÊ\n\nNgười cho thuê:\nTài sản và hiện trạng:\nThời hạn thuê:\nGiá và đặt cọc:\nBiên bản bàn giao:\n\nCẢNH BÁO: Mẫu tham khảo, cần kiểm tra trước khi dùng.",
  },
};

function toBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
function isPreviewable(mime: string) {
  return (
    mime.startsWith("image/") ||
    mime.startsWith("video/") ||
    mime === "application/pdf"
  );
}

type CertificateProcedure = {
  id: string;
  title: string;
  description: string;
  fields: string[];
  documents: string[];
};
const certificateProcedures: CertificateProcedure[] = [
  {
    id: "first_registration",
    title: "Đăng ký đất đai, cấp Giấy chứng nhận lần đầu",
    description: "Dành cho trường hợp chưa được cấp Giấy chứng nhận.",
    fields: [
      "Họ và tên người sử dụng đất",
      "Số định danh/CCCD",
      "Nguồn gốc sử dụng đất",
      "Địa chỉ thửa đất",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Mục đích sử dụng",
      "Thời điểm bắt đầu sử dụng",
    ],
    documents: [
      "CCCD/giấy tờ nhân thân",
      "Tài liệu về nguồn gốc sử dụng đất",
      "Sơ đồ hoặc trích đo thửa đất",
      "Chứng từ nghĩa vụ tài chính nếu có",
    ],
  },
  {
    id: "reissue",
    title: "Cấp lại Giấy chứng nhận",
    description:
      "Dành cho trường hợp mất, hư hỏng hoặc cần cấp lại theo căn cứ phù hợp.",
    fields: [
      "Họ và tên người sử dụng đất",
      "Số định danh/CCCD",
      "Số Giấy chứng nhận cũ",
      "Lý do đề nghị cấp lại",
      "Địa chỉ thửa đất",
      "Số thửa · tờ bản đồ",
      "Thông tin liên hệ",
    ],
    documents: [
      "CCCD/giấy tờ nhân thân",
      "Đơn đề nghị cấp lại",
      "Giấy tờ chứng minh lý do cấp lại",
      "Thông báo mất hoặc tài liệu liên quan nếu cần",
    ],
  },
  {
    id: "renewal",
    title: "Cấp đổi Giấy chứng nhận",
    description:
      "Dành cho trường hợp có nhu cầu cấp đổi hoặc cập nhật Giấy chứng nhận.",
    fields: [
      "Họ và tên người sử dụng đất",
      "Số định danh/CCCD",
      "Số Giấy chứng nhận",
      "Lý do cấp đổi",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Địa chỉ thửa đất",
    ],
    documents: [
      "Giấy chứng nhận bản gốc",
      "CCCD/giấy tờ nhân thân",
      "Đơn đề nghị cấp đổi",
      "Tài liệu đo đạc hoặc thay đổi thông tin nếu có",
    ],
  },
  {
    id: "purpose_change",
    title: "Chuyển mục đích sử dụng đất",
    description:
      "Chuẩn bị hồ sơ đề nghị chuyển mục đích và kiểm tra nghĩa vụ tài chính theo trường hợp.",
    fields: [
      "Họ và tên người sử dụng đất",
      "Số định danh/CCCD",
      "Địa chỉ thửa đất",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Mục đích đang sử dụng",
      "Mục đích đề nghị chuyển",
      "Căn cứ quy hoạch nếu có",
    ],
    documents: [
      "CCCD/giấy tờ nhân thân",
      "Giấy chứng nhận",
      "Đơn đề nghị chuyển mục đích",
      "Trích đo hoặc tài liệu thửa đất",
      "Chứng từ nghĩa vụ tài chính nếu có",
    ],
  },
  {
    id: "split",
    title: "Tách thửa",
    description:
      "Chuẩn bị đơn, bản vẽ/trích đo và hồ sơ chứng minh điều kiện tách thửa.",
    fields: [
      "Họ và tên người sử dụng đất",
      "Số định danh/CCCD",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Diện tích thửa hiện tại",
      "Số thửa dự kiến sau tách",
      "Diện tích các thửa sau tách",
      "Địa chỉ thửa đất",
    ],
    documents: [
      "CCCD/giấy tờ nhân thân",
      "Giấy chứng nhận",
      "Đơn đề nghị tách thửa",
      "Bản vẽ/trích đo địa chính",
      "Văn bản đồng ý hoặc ủy quyền nếu có",
    ],
  },
  {
    id: "merge",
    title: "Hợp thửa",
    description:
      "Chuẩn bị hồ sơ hợp các thửa liền kề theo điều kiện địa phương.",
    fields: [
      "Họ và tên người sử dụng đất",
      "Số định danh/CCCD",
      "Các số thửa cần hợp",
      "Các tờ bản đồ",
      "Tổng diện tích",
      "Mục đích sử dụng",
      "Địa chỉ thửa đất",
    ],
    documents: [
      "CCCD/giấy tờ nhân thân",
      "Giấy chứng nhận của các thửa",
      "Đơn đề nghị hợp thửa",
      "Bản vẽ/trích đo địa chính",
      "Văn bản đồng sở hữu hoặc ủy quyền nếu có",
    ],
  },
  {
    id: "transfer",
    title: "Chuyển nhượng quyền sử dụng đất",
    description:
      "Chuẩn bị hồ sơ chuyển nhượng, thuế–phí và đăng ký biến động sang tên.",
    fields: [
      "Thông tin bên chuyển nhượng",
      "Thông tin bên nhận chuyển nhượng",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Giá chuyển nhượng",
      "Tình trạng hôn nhân",
      "Thông tin liên hệ",
    ],
    documents: [
      "CCCD các bên",
      "Giấy chứng nhận bản gốc",
      "Hợp đồng chuyển nhượng",
      "Giấy tờ hôn nhân",
      "Tờ khai thuế và lệ phí",
    ],
  },
  {
    id: "gift",
    title: "Tặng cho quyền sử dụng đất",
    description:
      "Chuẩn bị văn bản tặng cho, giấy tờ quan hệ và đăng ký biến động.",
    fields: [
      "Thông tin bên tặng cho",
      "Thông tin bên nhận tặng cho",
      "Quan hệ giữa các bên",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Tình trạng hôn nhân",
    ],
    documents: [
      "CCCD các bên",
      "Giấy chứng nhận",
      "Hợp đồng/văn bản tặng cho",
      "Giấy tờ chứng minh quan hệ nếu xin miễn giảm",
      "Đơn đăng ký biến động",
    ],
  },
  {
    id: "inheritance",
    title: "Thừa kế quyền sử dụng đất",
    description:
      "Chuẩn bị hồ sơ thừa kế, xác định người thừa kế và đăng ký biến động.",
    fields: [
      "Thông tin người để lại di sản",
      "Thông tin người thừa kế",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Di chúc hoặc căn cứ thừa kế",
      "Quan hệ thừa kế",
    ],
    documents: [
      "Giấy chứng tử",
      "CCCD người thừa kế",
      "Giấy chứng nhận",
      "Di chúc hoặc văn bản thỏa thuận phân chia",
      "Giấy tờ quan hệ nhân thân",
    ],
  },
  {
    id: "mortgage",
    title: "Đăng ký thế chấp quyền sử dụng đất",
    description:
      "Chuẩn bị hồ sơ đăng ký biện pháp bảo đảm bằng quyền sử dụng đất.",
    fields: [
      "Thông tin bên thế chấp",
      "Thông tin bên nhận thế chấp",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Nghĩa vụ được bảo đảm",
      "Thời hạn bảo đảm",
      "Thông tin hợp đồng",
    ],
    documents: [
      "CCCD các bên",
      "Giấy chứng nhận",
      "Hợp đồng thế chấp",
      "Văn bản ủy quyền nếu có",
      "Đơn đăng ký biện pháp bảo đảm",
    ],
  },
  {
    id: "release_mortgage",
    title: "Xóa đăng ký thế chấp",
    description: "Chuẩn bị văn bản giải chấp và hồ sơ xóa đăng ký thế chấp.",
    fields: [
      "Thông tin bên thế chấp",
      "Thông tin bên nhận thế chấp",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Ngày hoàn thành nghĩa vụ",
      "Số văn bản giải chấp",
      "Thông tin liên hệ",
    ],
    documents: [
      "CCCD người sử dụng đất",
      "Giấy chứng nhận",
      "Văn bản giải chấp/xác nhận hoàn thành nghĩa vụ",
      "Đơn yêu cầu xóa đăng ký",
      "Văn bản ủy quyền nếu có",
    ],
  },
  {
    id: "tax_fee",
    title: "Thuế và phí, lệ phí liên quan",
    description:
      "Chuẩn bị tờ khai và chứng từ nghĩa vụ tài chính theo hồ sơ đất đai.",
    fields: [
      "Người nộp thuế/lệ phí",
      "Số định danh/CCCD",
      "Thông tin thửa đất hoặc giao dịch",
      "Giá trị làm căn cứ",
      "Loại thuế/lệ phí",
      "Trường hợp miễn giảm",
      "Thông tin liên hệ",
    ],
    documents: [
      "CCCD người nộp",
      "Giấy chứng nhận hoặc hợp đồng",
      "Tờ khai thuế thu nhập cá nhân",
      "Tờ khai lệ phí trước bạ",
      "Chứng từ miễn giảm hoặc nộp tiền nếu có",
    ],
  },
  {
    id: "variation",
    title: "Đăng ký biến động để cập nhật Giấy chứng nhận",
    description:
      "Dành cho chuyển nhượng, tặng cho, thừa kế hoặc thay đổi thông tin.",
    fields: [
      "Người sử dụng đất hiện tại",
      "Người nhận quyền hoặc nội dung thay đổi",
      "Số Giấy chứng nhận",
      "Số thửa · tờ bản đồ",
      "Diện tích",
      "Căn cứ biến động",
      "Thông tin liên hệ",
    ],
    documents: [
      "Giấy chứng nhận",
      "CCCD của các bên",
      "Hợp đồng/văn bản chuyển quyền",
      "Giấy tờ hôn nhân hoặc thừa kế nếu có",
      "Tờ khai thuế và lệ phí theo trường hợp",
    ],
  },
];

type CertificateOcrField = {
  key: string;
  label: string;
  value: string;
  confidence: number;
  source: string;
  confirmed: boolean;
};

type CertificateWorkspaceModule = {
  id: string;
  label: string;
  description: string;
  removable: boolean;
};

const certificateWorkspaceModules: CertificateWorkspaceModule[] = [
  {
    id: "procedure",
    label: "Thủ tục & nguồn pháp lý",
    description: "Thủ tục đang chọn và nguồn áp dụng tương ứng.",
    removable: false,
  },
  {
    id: "profile",
    label: "Thông tin hồ sơ",
    description: "Các trường thông tin chủ thể, thửa đất và giấy chứng nhận.",
    removable: true,
  },
  {
    id: "documents",
    label: "Giấy tờ & OCR",
    description: "Khu vực chụp/tải giấy tờ và kiểm duyệt kết quả OCR.",
    removable: true,
  },
  {
    id: "analysis",
    label: "AI kiểm tra & dựng hồ sơ",
    description: "Phân tích thiếu/mâu thuẫn và dựng bộ hồ sơ nháp.",
    removable: true,
  },
  {
    id: "review",
    label: "Rà soát trước khi in",
    description: "Checklist đối chiếu trước khi xác nhận và xuất tệp.",
    removable: true,
  },
];

export function aiDossierRemovableModuleIds() {
  return certificateWorkspaceModules
    .filter(module => module.removable)
    .map(module => module.id);
}

export function aiDossierRemoveModuleIds(
  hiddenModuleIds: string[],
  moduleId: string
) {
  if (!aiDossierRemovableModuleIds().includes(moduleId)) return hiddenModuleIds;
  return Array.from(new Set([...hiddenModuleIds, moduleId]));
}

function CertificateAiWorkspace() {
  const [procedureId, setProcedureId] = useState("first_registration");
  const [procedureSearch, setProcedureSearch] = useState("");
  const [procedureFilter, setProcedureFilter] = useState("all");
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<
    Array<{ name: string; type: string; size: number }>
  >([]);
  const [ocrStatus, setOcrStatus] = useState<"idle" | "processing" | "ready">(
    "idle"
  );
  const [ocrFields, setOcrFields] = useState<CertificateOcrField[]>([]);
  const [confirmed, setConfirmed] = useState(false);
  const [aiCheck, setAiCheck] = useState<"idle" | "checking" | "done">("idle");
  const [exported, setExported] = useState(false);
  const [draftReviewConfirmed, setDraftReviewConfirmed] = useState(false);
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [prePrintChecks, setPrePrintChecks] = useState<Record<string, boolean>>(
    {}
  );
  const [draftId, setDraftId] = useState(() => `certificate-${Date.now()}`);
  const [draftSavedAt, setDraftSavedAt] = useState<number | null>(null);
  const [draftNotice, setDraftNotice] = useState<
    "idle" | "saving" | "saved" | "restored"
  >("idle");
  const [savedDrafts, setSavedDrafts] = useState<
    Array<{ id: string; savedAt: number; procedureId: string; step: number }>
  >([]);
  const [hiddenModuleIds, setHiddenModuleIds] = useState<string[]>([]);
  const [showModuleManager, setShowModuleManager] = useState(false);
  const [pendingModuleId, setPendingModuleId] = useState<string | null>(null);
  const hiddenModuleIdSet = useMemo(
    () => new Set(hiddenModuleIds),
    [hiddenModuleIds]
  );
  const hiddenModuleLabels = useMemo(
    () =>
      certificateWorkspaceModules
        .filter(module => hiddenModuleIdSet.has(module.id))
        .map(module => module.label),
    [hiddenModuleIdSet]
  );
  const inputRef = useRef<HTMLInputElement>(null);
  const procedure =
    certificateProcedures.find(item => item.id === procedureId) ||
    certificateProcedures[0];
  const filteredProcedures = useMemo(
    () => aiDossierProcedureSearch(procedureSearch, procedureFilter),
    [procedureFilter, procedureSearch]
  );
  const procedureLegalBundle = useMemo(
    () => getProcedureLegalBundle(procedureId),
    [procedureId]
  );
  const progress = Math.round((step / 10) * 100);
  const missingDocuments = procedure.documents.filter(
    (_, index) => !files[index]
  );
  const analysisStatus = aiDossierAnalysisStatus({
    filesCount: files.length,
    ocrStatus,
    confirmed,
    aiCheck,
  });
  const prePrintChecklist: PrePrintChecklistItem[] = [
    ...procedure.documents.map(document => ({
      id: `${procedure.id}:document:${document}`,
      label: `Đã chuẩn bị hoặc xác nhận yêu cầu: ${document}`,
      ...matchOfficialTemplateForRequirement(procedure.id, document),
    })),
    {
      id: `${procedure.id}:ocr`,
      label: "Đã rà soát và xác nhận dữ liệu OCR/nhập trực tiếp",
      templateStatus: "not-applicable" as const,
    },
    {
      id: `${procedure.id}:originals`,
      label: "Đã đối chiếu bản gốc và bản sao trước khi in",
      templateStatus: "not-applicable" as const,
    },
    {
      id: `${procedure.id}:signature`,
      label: "Đã kiểm tra người ký, số bản in và nơi tiếp nhận hồ sơ",
      templateStatus: "not-applicable" as const,
    },
  ];
  const prePrintCompleted = prePrintChecklist.filter(
    item => prePrintChecks[item.id]
  ).length;
  const prePrintReady = prePrintCompleted === prePrintChecklist.length;
  const officialTemplateReady =
    prePrintChecklist.some(item => item.templateStatus === "official") &&
    prePrintChecklist.every(
      item =>
        item.templateStatus !== "pending" && item.templateStatus !== "reference"
    );
  const draftStorageKey = "bdsxanh-certificate-ai-drafts";
  const legalReference = officialLegalDocuments;
  const buildCertificateExportContent = () =>
    [
      `BỘ HỒ SƠ AI CẤP GIẤY CHỨNG NHẬN`,
      `Thủ tục: ${procedure.title}`,
      `Trạng thái: ${officialTemplateReady ? "OFFICIAL TEMPLATE · Đã kiểm tra nguồn, binary, checksum và khả năng điền" : "BẢN NHÁP HỖ TRỢ · Chưa đủ mẫu binary Official đã xác minh"}`,
      "",
      "NGUỒN PHÁP LÝ ĐỐI CHIẾU",
      ...legalReference.map(
        document =>
          `${document.title} · ${document.sourceUrl} · kiểm tra ${document.lastCheckedAt}`
      ),
      "",
      "MẪU ĐƯỢC GHÉP THEO THÀNH PHẦN",
      ...prePrintChecklist
        .filter(item => item.templateStatus !== "not-applicable")
        .map(
          item =>
            `${item.label} → ${item.templateLabel || "Chưa ghép được mẫu"} · ${item.templateFile || "Chưa có binary"} · ${item.templateSource || "Chưa có nguồn"}`
        ),
      "",
      "DỮ LIỆU ĐÃ XÁC NHẬN",
      ...ocrFields.map(
        field => `${field.label}: ${field.value || "Chưa bổ sung"}`
      ),
      "",
      "DANH MỤC TÀI LIỆU",
      ...procedure.documents.map(
        (document, index) =>
          `${index + 1}. ${document}${files[index] ? ` · ${files[index].name}` : " · Cần bổ sung"}`
      ),
      "",
      "Lưu ý: Trạng thái Official Template chỉ áp dụng khi từng mẫu được ghép có nguồn phù hợp và binary đã vượt kiểm tra xác minh. Tệp này không phải chứng nhận của cơ quan Nhà nước; người dùng vẫn phải đối chiếu yêu cầu hiện hành với cơ quan tiếp nhận trước khi ký và nộp.",
    ].join("\\n");

  function readDrafts() {
    try {
      return JSON.parse(
        window.localStorage.getItem(draftStorageKey) || "[]"
      ) as Array<Record<string, unknown>>;
    } catch {
      return [];
    }
  }

  function saveDraft(manual = false) {
    if (typeof window === "undefined") return;
    setDraftNotice("saving");
    const savedAt = Date.now();
    const draft = {
      id: draftId,
      savedAt,
      procedureId,
      step,
      files,
      ocrFields,
      confirmed,
      aiCheck,
      exported,
      draftReviewConfirmed,
      hiddenModuleIds,
    };
    const drafts = readDrafts()
      .filter(item => item.id !== draftId)
      .slice(-9);
    window.localStorage.setItem(
      draftStorageKey,
      JSON.stringify([...drafts, draft])
    );
    setDraftSavedAt(savedAt);
    setSavedDrafts(
      [...drafts, draft]
        .map(item => ({
          id: String(item.id),
          savedAt: Number(item.savedAt),
          procedureId: String(item.procedureId),
          step: Number(item.step),
        }))
        .sort((a, b) => b.savedAt - a.savedAt)
    );
    setDraftNotice("saved");
    if (manual)
      toast.success("Bản nháp đã được lưu. Bạn có thể tiếp tục lần sau.");
  }

  function restoreDraft(id: string) {
    const draft = readDrafts().find(item => item.id === id);
    if (!draft) return;
    setDraftId(String(draft.id));
    setProcedureId(String(draft.procedureId));
    setStep(Number(draft.step) || 1);
    setFiles(
      Array.isArray(draft.files)
        ? (draft.files as Array<{ name: string; type: string; size: number }>)
        : []
    );
    setOcrFields(
      Array.isArray(draft.ocrFields)
        ? (draft.ocrFields as CertificateOcrField[])
        : []
    );
    setConfirmed(Boolean(draft.confirmed));
    setAiCheck(
      draft.aiCheck === "done"
        ? "done"
        : draft.aiCheck === "checking"
          ? "checking"
          : "idle"
    );
    setExported(Boolean(draft.exported));
    setDraftReviewConfirmed(Boolean(draft.draftReviewConfirmed));
    setHiddenModuleIds(
      Array.isArray(draft.hiddenModuleIds)
        ? (draft.hiddenModuleIds as string[]).filter(moduleId =>
            aiDossierRemovableModuleIds().includes(moduleId)
          )
        : []
    );
    setDraftSavedAt(Number(draft.savedAt));
    setDraftNotice("restored");
    toast.success("Đã khôi phục bản nháp để tiếp tục.");
  }

  function removeWorkspaceModule(moduleId: string) {
    const module = certificateWorkspaceModules.find(
      item => item.id === moduleId
    );
    if (!module || !module.removable) {
      toast.error(
        "Thủ tục và nguồn pháp lý là mô-đun bắt buộc, không thể xóa."
      );
      return;
    }
    setPendingModuleId(moduleId);
  }

  function confirmRemoveWorkspaceModule() {
    if (!pendingModuleId) return;
    const module = certificateWorkspaceModules.find(
      item => item.id === pendingModuleId
    );
    if (!module || !module.removable) {
      setPendingModuleId(null);
      toast.error(
        "Thủ tục và nguồn pháp lý là mô-đun bắt buộc, không thể xóa."
      );
      return;
    }
    setHiddenModuleIds(current =>
      aiDossierRemoveModuleIds(current, pendingModuleId)
    );
    setPendingModuleId(null);
    toast.success(`Đã ẩn mô-đun “${module.label}” khỏi bản nháp.`);
  }

  function restoreWorkspaceModules() {
    setHiddenModuleIds([]);
    toast.success("Đã khôi phục các mô-đun của hồ sơ.");
  }

  function deleteDraft(id: string) {
    const drafts = readDrafts().filter(item => item.id !== id);
    window.localStorage.setItem(draftStorageKey, JSON.stringify(drafts));
    setSavedDrafts(
      drafts
        .map(item => ({
          id: String(item.id),
          savedAt: Number(item.savedAt),
          procedureId: String(item.procedureId),
          step: Number(item.step),
        }))
        .sort((a, b) => b.savedAt - a.savedAt)
    );
    if (id === draftId) toast.success("Đã xóa bản nháp hiện tại.");
  }

  useEffect(() => {
    if (typeof window === "undefined") return;
    const drafts = readDrafts();
    setSavedDrafts(
      drafts
        .map(item => ({
          id: String(item.id),
          savedAt: Number(item.savedAt),
          procedureId: String(item.procedureId),
          step: Number(item.step),
        }))
        .sort((a, b) => b.savedAt - a.savedAt)
    );
    const latest = drafts.sort(
      (a, b) => Number(b.savedAt) - Number(a.savedAt)
    )[0];
    if (
      latest &&
      Number(latest.savedAt) > Date.now() - 1000 * 60 * 60 * 24 * 30
    )
      restoreDraft(String(latest.id));
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => saveDraft(), 700);
    return () => window.clearTimeout(timer);
  }, [
    procedureId,
    step,
    files,
    ocrFields,
    confirmed,
    aiCheck,
    exported,
    hiddenModuleIds,
  ]);

  function loadFiles(fileList: FileList | null) {
    if (!fileList?.length) return;
    const nextFiles = Array.from(fileList).map(file => ({
      name: file.name,
      type: file.type,
      size: file.size,
    }));
    setFiles(current => [...current, ...nextFiles]);
    setOcrStatus("processing");
    setConfirmed(false);
    setDraftReviewConfirmed(false);
    window.setTimeout(() => {
      setOcrFields(
        procedure.fields.map((label, index) => ({
          key: `${procedure.id}-${index}`,
          label,
          value: "",
          confidence: Math.max(78, 96 - index * 2),
          source:
            nextFiles[index % nextFiles.length]?.name || "Tài liệu đầu vào",
          confirmed: false,
        }))
      );
      setOcrStatus("ready");
      setStep(current => Math.max(current, 4));
    }, 900);
  }

  function updateOcrField(key: string, value: string) {
    setOcrFields(current =>
      current.map(field =>
        field.key === key ? { ...field, value, confirmed: false } : field
      )
    );
    setConfirmed(false);
    setDraftReviewConfirmed(false);
  }

  function confirmOcr() {
    if (!ocrFields.length) return;
    setOcrFields(current =>
      current.map(field => ({ ...field, confirmed: true }))
    );
    setConfirmed(true);
    setStep(current => Math.max(current, 5));
  }

  function runAiCheck() {
    setAiCheck("checking");
    window.setTimeout(() => {
      setAiCheck("done");
      setStep(current => Math.max(current, 7));
    }, 800);
  }

  function confirmFinalDraft() {
    if (!confirmed || aiCheck !== "done") {
      toast.error("Hãy xác nhận dữ liệu OCR và chạy AI phân tích trước.");
      return;
    }
    if (!prePrintReady) {
      toast.error(
        `Hãy hoàn tất checklist trước khi xác nhận (${prePrintCompleted}/${prePrintChecklist.length}).`
      );
      return;
    }
    if (hiddenModuleLabels.length > 0) {
      toast.error(
        "Hãy khôi phục các mô-đun đã ẩn trước khi xác nhận bộ hồ sơ cuối."
      );
      return;
    }
    setDraftReviewConfirmed(true);
    toast.success(
      "Đã xác nhận bản nháp sau khi rà soát. Nút xuất cuối đã được mở khóa."
    );
  }

  async function exportCertificateBundle(format: "docx" | "pdf") {
    if (!draftReviewConfirmed) {
      toast.error(
        "Bạn phải rà soát và bấm ‘Xác nhận bản nháp’ trước khi xuất/in."
      );
      return;
    }
    if (!prePrintReady) {
      toast.error(
        `Hãy hoàn tất checklist trước khi xuất hồ sơ (${prePrintCompleted}/${prePrintChecklist.length}).`
      );
      return;
    }
    if (hiddenModuleLabels.length > 0) {
      toast.error("Hãy khôi phục các mô-đun đã ẩn trước khi xuất bộ hồ sơ.");
      return;
    }
    if (!officialTemplateReady) {
      toast.error(
        "Chưa đủ mẫu Official đã xác minh cho các thành phần hồ sơ. Hãy mở hàng chờ mẫu, xác minh binary và phê duyệt trước khi xuất Official."
      );
      return;
    }
    const content = buildCertificateExportContent();
    const lines = content.split(/\\r?\\n/).filter(Boolean);
    let bytes: Uint8Array | undefined;
    let outputBlob: Blob | undefined;
    let mime: string;
    if (format === "docx") {
      const document = new Document({
        sections: [
          {
            properties: {},
            children: lines.map(
              (line, index) =>
                new Paragraph({
                  children: [
                    new TextRun({
                      text: line,
                      bold: index === 0,
                      size: index === 0 ? 28 : 22,
                    }),
                  ],
                  spacing: { after: 140 },
                })
            ),
          },
        ],
      });
      outputBlob = await Packer.toBlob(document);
      mime =
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    } else {
      const pdf = await PDFDocument.create();
      const font = await pdf.embedFont(StandardFonts.Helvetica);
      const boldFont = await pdf.embedFont(StandardFonts.HelveticaBold);
      let page = pdf.addPage([595, 842]);
      let y = 790;
      for (let index = 0; index < lines.length; index += 1) {
        const rawLine = lines[index];
        const safeLine = rawLine
          .normalize("NFD")
          .replace(/[\\u0300-\\u036f]/g, "")
          .replace(/[^\\x20-\\x7E]/g, " ");
        const chunks = safeLine.match(/.{1,88}(?:\\s|$)/g) || [safeLine];
        for (const chunk of chunks) {
          if (y < 48) {
            page = pdf.addPage([595, 842]);
            y = 790;
          }
          page.drawText(chunk.trim(), {
            x: 42,
            y,
            size: index === 0 ? 14 : 9.5,
            font: index === 0 ? boldFont : font,
            color: rgb(0.12, 0.2, 0.17),
          });
          y -= index === 0 ? 26 : 16;
        }
      }
      bytes = await pdf.save();
      mime = "application/pdf";
    }
    if (!outputBlob) {
      const binaryBuffer = new Uint8Array(bytes ?? []).buffer as ArrayBuffer;
      outputBlob = new Blob([binaryBuffer], { type: mime });
    }
    const url = URL.createObjectURL(outputBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `ho-so-cap-giay-chung-nhan.${format}`;
    link.click();
    URL.revokeObjectURL(url);
    setExported(true);
    setStep(10);
  }

  async function downloadPrePrintChecklistPdf() {
    const pdf = await PDFDocument.create();
    const page = pdf.addPage([595, 842]);
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    const boldFont = await pdf.embedFont(StandardFonts.HelveticaBold);
    const lines = [
      "CHECKLIST KIỂM TRA TRƯỚC KHI IN HỒ SƠ",
      `Thủ tục: ${procedure.title}`,
      `Tiến độ kiểm tra: ${prePrintCompleted}/${prePrintChecklist.length} mục`,
      "",
      ...prePrintChecklist.map(
        item => `${prePrintChecks[item.id] ? "☑" : "☐"} ${item.label}`
      ),
      "",
      "Lưu ý: Checklist hỗ trợ rà soát hồ sơ, không thay thế yêu cầu chính thức của cơ quan tiếp nhận.",
    ];
    let y = 790;
    lines.forEach((line, index) => {
      const isTitle = index === 0;
      page.drawText(line, {
        x: 42,
        y,
        size: isTitle ? 15 : 10,
        font: isTitle ? boldFont : font,
        color: isTitle ? rgb(0.12, 0.35, 0.29) : rgb(0.16, 0.22, 0.19),
        maxWidth: 510,
      });
      y -= isTitle ? 28 : 20;
      if (y < 42) {
        y = 790;
      }
    });
    const bytes = await pdf.save();
    const pdfBuffer = new Uint8Array(bytes).buffer as ArrayBuffer;
    const url = URL.createObjectURL(
      new Blob([pdfBuffer], { type: "application/pdf" })
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = `checklist-${procedure.id}-truoc-khi-in.pdf`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Đã tải checklist PDF.");
  }
  return (
    <section
      className="mt-6 rounded-2xl border-2 border-[#B8D2C1] bg-[#F7FBF7] p-5 shadow-sm sm:p-6"
      aria-labelledby="certificate-ai-title"
    >
      <div className="flex flex-col gap-4 border-b border-[#D8E4DC] pb-5 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-[#DCEBE0] px-3 py-1.5 text-[11px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
            <ShieldCheck className="h-3.5 w-3.5" />
            AI chuyên trách đất đai
          </div>
          <h2
            id="certificate-ai-title"
            className="mt-3 text-2xl font-black text-[#18352D]"
          >
            Trung tâm AI · Cấp Giấy chứng nhận
          </h2>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">
            Phân hệ độc lập cạnh Mục 1, dành riêng cho việc chuẩn bị hồ sơ nộp
            tại bộ phận một cửa. Không lấy dữ liệu tự động từ CRM môi giới.
          </p>
        </div>
        <div className="min-w-56 rounded-xl bg-white p-3">
          <div className="flex items-center justify-between text-xs font-black text-[#1F5A4A]">
            <span>Tiến độ hồ sơ</span>
            <span>{progress}%</span>
          </div>
          <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-[#E4ECE6]">
            <div
              className="h-full rounded-full bg-[#1F5A4A] transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2 text-[11px] text-[#60766D]">
            {exported
              ? "Đã xuất bộ hồ sơ"
              : `Bước ${step}/10 · ${step < 4 ? "Chuẩn bị dữ liệu" : step < 7 ? "AI kiểm tra" : step < 10 ? "Hoàn thiện bộ hồ sơ" : "In – ký – nộp"}`}
          </p>
        </div>
      </div>
      <div className="mt-4 rounded-2xl border border-[#C9D8D0] bg-white p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
              Lưu nháp tiến trình
            </p>
            <p className="mt-1 text-xs text-[#60766D]">
              Dữ liệu được tự lưu trên thiết bị này sau mỗi thay đổi. Bạn có thể
              lưu thủ công hoặc tiếp tục bản nháp ở lần sau.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`text-xs font-bold ${draftNotice === "saving" ? "text-[#B38321]" : "text-[#1F5A4A]"}`}
            >
              {draftNotice === "saving"
                ? "Đang lưu nháp…"
                : draftNotice === "restored"
                  ? "Đã khôi phục nháp"
                  : draftSavedAt
                    ? `Đã lưu ${new Date(draftSavedAt).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}`
                    : "Chưa lưu"}
            </span>
            <Button
              type="button"
              variant="outline"
              className="text-xs"
              onClick={() => saveDraft(true)}
            >
              Lưu nháp ngay
            </Button>
          </div>
        </div>
        {savedDrafts.length > 0 ? (
          <div className="mt-3 border-t border-[#E5EEE7] pt-3">
            <p className="text-[11px] font-black uppercase text-[#60766D]">
              Bản nháp có thể tiếp tục
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {savedDrafts.map(draft => (
                <div
                  key={draft.id}
                  className="flex items-center gap-2 rounded-xl bg-[#F4F8F4] px-3 py-2 text-xs"
                >
                  <button
                    type="button"
                    className="font-bold text-[#1F5A4A] underline-offset-2 hover:underline"
                    onClick={() => restoreDraft(draft.id)}
                  >
                    Tiếp tục ·{" "}
                    {certificateProcedures.find(
                      item => item.id === draft.procedureId
                    )?.title || "Hồ sơ đất đai"}{" "}
                    · Bước {draft.step}/10
                  </button>
                  <button
                    type="button"
                    aria-label="Xóa bản nháp"
                    className="text-[#A14C31]"
                    onClick={() => {
                      if (
                        window.confirm(
                          "Xóa bản nháp này? Dữ liệu đã xóa không thể khôi phục."
                        )
                      )
                        deleteDraft(draft.id);
                    }}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
      <div className="mt-4 rounded-2xl border border-[#D8B15A] bg-[#FFFDF5] p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
              Quản lý mô-đun hồ sơ
            </p>
            <p className="mt-1 text-xs leading-5 text-[#6F5520]">
              Xóa những mô-đun không cần dùng khỏi bản nháp hiện tại. Hệ thống
              không xóa tài liệu trong Kho pháp lý và không xóa hồ sơ đã lưu.
            </p>
          </div>
          <Button
            type="button"
            variant="outline"
            className="shrink-0 border-[#D8B15A] text-xs text-[#6F5520]"
            onClick={() => setShowModuleManager(current => !current)}
            aria-expanded={showModuleManager}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            {showModuleManager ? "Đóng quản lý" : "Xóa mô-đun thừa"}
          </Button>
        </div>
        {showModuleManager && (
          <div className="mt-4 border-t border-[#E9D9AE] pt-3">
            <div className="space-y-2">
              {certificateWorkspaceModules.map(module => {
                const hidden = hiddenModuleIdSet.has(module.id);
                return (
                  <div
                    key={module.id}
                    className={`flex flex-col gap-3 rounded-xl p-3 sm:flex-row sm:items-center sm:justify-between ${hidden ? "bg-[#F1EBD9]" : "bg-white"}`}
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-xs font-black text-[#18352D]">
                          {module.label}
                        </p>
                        {hidden && (
                          <span className="rounded-full bg-[#E8D9AF] px-2 py-0.5 text-[10px] font-black text-[#6F5520]">
                            Đã ẩn khỏi bản nháp
                          </span>
                        )}
                      </div>
                      <p className="mt-1 text-[11px] leading-4 text-[#60766D]">
                        {module.description}
                      </p>
                    </div>
                    {module.removable ? (
                      <Button
                        type="button"
                        variant="outline"
                        className="shrink-0 self-start border-[#D5B36A] text-xs text-[#A14C31] sm:self-auto"
                        onClick={() => removeWorkspaceModule(module.id)}
                        disabled={hidden}
                        aria-label={`Xóa mô-đun ${module.label}`}
                      >
                        <Trash2 className="mr-2 h-3.5 w-3.5" />
                        {hidden ? "Đã xóa" : "Xóa"}
                      </Button>
                    ) : (
                      <span className="shrink-0 text-[11px] font-black text-[#1F5A4A]">
                        Bắt buộc
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
            {hiddenModuleIds.length > 0 && (
              <Button
                type="button"
                variant="outline"
                className="mt-3 text-xs text-[#1F5A4A]"
                onClick={restoreWorkspaceModules}
              >
                Khôi phục tất cả mô-đun
              </Button>
            )}
            <p className="mt-3 text-[11px] leading-4 text-[#6F5520]">
              Mô-đun bị xóa chỉ được ẩn khỏi bản nháp trên thiết bị này; hãy
              khôi phục lại trước khi xuất nếu thủ tục yêu cầu thành phần đó.
            </p>
          </div>
        )}
      </div>
      <AlertDialog
        open={pendingModuleId !== null}
        onOpenChange={open => {
          if (!open) setPendingModuleId(null);
        }}
      >
        <AlertDialogContent className="border-[#D8B15A] bg-[#FFFDF5] text-[#18352D]">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-[#18352D]">
              <AlertTriangle className="h-5 w-5 text-[#B38321]" />
              Xác nhận ẩn mô-đun
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2 text-left text-[#60766D]">
              <span className="block font-bold text-[#18352D]">
                {certificateWorkspaceModules.find(
                  module => module.id === pendingModuleId
                )?.label || "Mô-đun hồ sơ"}
              </span>
              <span className="block">
                Mô-đun này sẽ được ẩn khỏi bản nháp hiện tại. Tài liệu gốc,
                nguồn pháp lý và hồ sơ đã lưu không bị xóa; bạn có thể khôi phục
                lại trong mục Quản lý mô-đun.
              </span>
              <span className="block font-semibold text-[#A14C31]">
                Hãy chỉ xác nhận nếu bạn chắc chắn mô-đun này không cần dùng
                trong bản nháp hiện tại. Mô-đun bắt buộc không thể xóa.
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#C8D8D0] text-[#18352D]">
              Hủy, giữ lại
            </AlertDialogCancel>
            <AlertDialogAction
              className="bg-[#A14C31] text-white hover:bg-[#893D28]"
              onClick={confirmRemoveWorkspaceModule}
            >
              Xác nhận ẩn mô-đun
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <div className="mt-5 grid gap-2 md:grid-cols-5">
        {[
          "Chọn thủ tục",
          "Nhập thông tin",
          "Tải giấy tờ",
          "AI đọc OCR",
          "Kiểm tra",
          "Dựng hồ sơ",
          "Rà soát",
          "Kiểm tra cuối",
          "Xuất",
          "Nộp một cửa",
        ].map((label, index) => (
          <button
            type="button"
            key={label}
            onClick={() => setStep(index + 1)}
            className={`rounded-xl p-2 text-left text-[11px] font-bold ${step === index + 1 ? "bg-[#1F5A4A] text-white" : step > index + 1 ? "bg-[#E5F0E8] text-[#1F5A4A]" : "bg-white text-[#60766D]"}`}
          >
            <span className="block text-[10px] uppercase opacity-70">
              {String(index + 1).padStart(2, "0")}
            </span>
            {label}
          </button>
        ))}
      </div>
      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(280px,.7fr)]">
        <div className="space-y-4">
          <div className="rounded-2xl border border-[#D8E4DC] bg-white p-4">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
              Bước 1 · Chọn đúng thủ tục
            </p>
            <p className="mt-2 text-xs leading-5 text-[#60766D]">
              Không để AI tự đoán tên thủ tục. Hãy tìm và chọn đúng thủ tục
              trong catalog chuẩn; hệ thống sẽ dùng lựa chọn này để ghép nguồn
              pháp lý, trường thông tin và checklist tương ứng.
            </p>
            <div className="mt-3 grid gap-2 sm:grid-cols-[minmax(0,1fr)_11rem]">
              <Input
                value={procedureSearch}
                onChange={event => setProcedureSearch(event.target.value)}
                placeholder="Tìm thủ tục, giấy tờ, từ khóa…"
                aria-label="Tìm thủ tục"
              />
              <select
                value={procedureFilter}
                onChange={event => setProcedureFilter(event.target.value)}
                aria-label="Lọc nhóm thủ tục"
                className="min-h-10 rounded-xl border border-[#C9D8D0] bg-white px-3 text-xs font-bold text-[#18352D]"
              >
                <option value="all">Tất cả nhóm</option>
                <option value="giay-chung-nhan">Giấy chứng nhận</option>
                <option value="bien-dong">Đăng ký biến động</option>
                <option value="thua-dat">Thửa đất</option>
                <option value="bao-dam">Thế chấp/bảo đảm</option>
                <option value="tai-chinh">Thuế, phí</option>
              </select>
            </div>
            <div
              className="mt-3 max-h-56 space-y-2 overflow-y-auto rounded-xl border border-[#D8E4DC] bg-[#F8FBF8] p-2 pr-1 [scrollbar-color:#9BB8A6_#EDF4EF] [scrollbar-width:thin]"
              aria-label="Danh sách thủ tục có thể cuộn"
            >
              {filteredProcedures.length ? (
                filteredProcedures.map(item => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() => {
                      setProcedureId(item.id);
                      setOcrFields([]);
                      setFiles([]);
                      setConfirmed(false);
                      setDraftReviewConfirmed(false);
                      setHiddenModuleIds([]);
                      setAiCheck("idle");
                      setStep(1);
                    }}
                    className={`w-full rounded-lg border px-3 py-2 text-left transition-colors ${item.id === procedureId ? "border-[#1F5A4A] bg-[#E5F0E8]" : "border-transparent bg-white hover:border-[#B8D2C1]"}`}
                  >
                    <span className="block text-xs font-black text-[#18352D]">
                      {item.title}
                    </span>
                    <span className="mt-0.5 block text-[11px] leading-4 text-[#60766D]">
                      {item.description}
                    </span>
                  </button>
                ))
              ) : (
                <p className="px-3 py-4 text-center text-xs text-[#60766D]">
                  Không tìm thấy thủ tục phù hợp. Hãy thử từ khóa khác.
                </p>
              )}
            </div>
            <p className="mt-2 text-xs leading-5 text-[#60766D]">
              Đang chọn:{" "}
              <span className="font-black text-[#1F5A4A]">
                {procedure.title}
              </span>
            </p>
            <LegalSourceRegistryPanel
              procedureId={
                adminToBuilderProcedure[procedure.id] ?? procedure.id
              }
              title="Nguồn pháp lý từ AI Kho pháp lý hồ sơ AI"
            />
            <div
              className="mt-3 rounded-xl border border-[#D8B15A] bg-[#FFFDF5] p-3"
              aria-label="Mẫu thủ công cho môi giới và chủ nhà"
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-xs font-black uppercase tracking-[0.12em] text-[#6F5520]">
                    Mẫu làm việc thủ công · dùng cho mọi thủ tục
                  </p>
                  <p className="mt-1 text-sm font-black text-[#18352D]">
                    {manualBrokerTemplate.title}
                  </p>
                  <p className="mt-1 text-[11px] leading-4 text-[#60766D]">
                    {manualBrokerTemplate.usage} File:{" "}
                    {manualBrokerTemplate.fileName}
                  </p>
                </div>
                <a
                  href={manualBrokerTemplate.fileUrl}
                  download={manualBrokerTemplate.fileName}
                  className="inline-flex min-h-10 shrink-0 items-center justify-center rounded-lg bg-[#B38321] px-3 py-2 text-xs font-black text-white shadow-sm transition-colors hover:bg-[#946C16] focus:outline-none focus:ring-2 focus:ring-[#B38321] focus:ring-offset-2"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Tải mẫu DOCX
                </a>
              </div>
            </div>
            <div
              className="mt-3 rounded-xl border border-[#BFD2C5] bg-[#F1F8F2] p-3"
              aria-live="polite"
            >
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.12em] text-[#1F5A4A]">
                    Đã chọn thủ tục · sẵn sàng xác minh
                  </p>
                  <p className="mt-1 text-[11px] leading-4 text-[#60766D]">
                    Bấm nút này để khóa nguồn áp dụng cho thủ tục đang chọn và
                    chuyển thẳng đến bước AI phân tích yêu cầu hồ sơ.
                  </p>
                </div>
                <Button
                  type="button"
                  className="shrink-0 bg-[#1F5A4A] text-xs hover:bg-[#164637]"
                  onClick={() => {
                    setConfirmed(false);
                    setAiCheck("idle");
                    setStep(aiDossierLegalVerificationNextStep().step);
                    toast.success(
                      `Đã xác nhận nguồn cho thủ tục “${procedure.title}”. Chuyển sang bước AI phân tích.`
                    );
                  }}
                >
                  <ShieldCheck className="mr-2 h-4 w-4" />
                  Xác minh & phân tích tiếp
                </Button>
              </div>
            </div>
          </div>
          {!hiddenModuleIdSet.has("profile") && (
            <div className="rounded-2xl border border-[#D8E4DC] bg-white p-4">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
                Bước 2 · Thông tin hồ sơ
              </p>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                {procedure.fields.map(field => (
                  <label
                    key={field}
                    className="text-xs font-bold text-[#18352D]"
                  >
                    {field}
                    <Input
                      value={
                        ocrFields.find(item => item.label === field)?.value ||
                        ""
                      }
                      onChange={event => {
                        const existing = ocrFields.find(
                          item => item.label === field
                        );
                        if (existing)
                          updateOcrField(existing.key, event.target.value);
                        else
                          setOcrFields(current => [
                            ...current,
                            {
                              key: `${procedure.id}-${field}`,
                              label: field,
                              value: event.target.value,
                              confidence: 0,
                              source: "Nhập trực tiếp",
                              confirmed: false,
                            },
                          ]);
                      }}
                      placeholder="Nhập hoặc chờ OCR tự điền"
                      className="mt-1.5"
                    />
                  </label>
                ))}
              </div>
            </div>
          )}
          {!hiddenModuleIdSet.has("documents") && (
            <div className="rounded-2xl border border-[#D8E4DC] bg-white p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
                    Bước 3–4 · Chụp/tải và xem kết quả OCR
                  </p>
                  <p className="mt-1 text-xs text-[#60766D]">
                    Tải ảnh, PDF, Word hoặc video. Dữ liệu chỉ được tự điền sau
                    khi bạn xác nhận.
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => inputRef.current?.click()}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    Tải giấy tờ
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => inputRef.current?.click()}
                  >
                    <Camera className="mr-2 h-4 w-4" />
                    Chụp/tải ảnh
                  </Button>
                </div>
              </div>
              <input
                ref={inputRef}
                type="file"
                multiple
                accept="image/*,video/*,.pdf,.doc,.docx"
                className="hidden"
                onChange={event => loadFiles(event.target.files)}
              />
              {files.length > 0 && (
                <div className="mt-3 space-y-2">
                  {files.map(file => (
                    <div
                      key={`${file.name}-${file.size}`}
                      className="flex items-center justify-between rounded-xl bg-[#F4F8F4] p-3 text-xs"
                    >
                      <span className="truncate font-bold text-[#18352D]">
                        {file.name}
                      </span>
                      <span
                        className={`ml-3 shrink-0 font-black ${ocrStatus === "processing" ? "text-[#B38321]" : "text-[#1F5A4A]"}`}
                      >
                        {ocrStatus === "processing"
                          ? "AI đang đọc…"
                          : "Đã nhận diện · chờ xác nhận"}
                      </span>
                    </div>
                  ))}
                </div>
              )}
              {ocrStatus === "processing" && (
                <div className="mt-3 rounded-xl bg-[#FFF9EA] p-3 text-xs font-bold text-[#6F5520]">
                  <span className="mr-2 inline-block h-3 w-3 animate-spin rounded-full border-2 border-[#D8B15A] border-t-transparent" />
                  OCR đang trích xuất dữ liệu từ tài liệu…
                </div>
              )}
              {ocrStatus === "ready" && (
                <div className="mt-3 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3">
                  <div className="flex items-center justify-between text-xs font-black text-[#6F5520]">
                    <span>Kết quả OCR cần bạn kiểm duyệt</span>
                    <span>
                      {ocrFields.filter(field => field.value).length}/
                      {ocrFields.length} trường đã có dữ liệu
                    </span>
                  </div>
                  <div className="mt-3 space-y-2">
                    {ocrFields.map(field => (
                      <div
                        key={field.key}
                        className="grid gap-2 sm:grid-cols-[1fr_1fr_auto] sm:items-center"
                      >
                        <span className="text-xs font-bold text-[#18352D]">
                          {field.label}
                        </span>
                        <Input
                          value={field.value}
                          onChange={event =>
                            updateOcrField(field.key, event.target.value)
                          }
                          placeholder="Chưa nhận diện · nhập/chỉnh sửa"
                        />
                        <span className="text-[10px] font-bold text-[#60766D]">
                          {field.confidence
                            ? `${field.confidence}% · ${field.source}`
                            : "Nhập trực tiếp"}
                        </span>
                      </div>
                    ))}
                  </div>
                  <Button
                    type="button"
                    onClick={confirmOcr}
                    className="mt-3 bg-[#1F5A4A]"
                    disabled={!ocrFields.length}
                  >
                    <CheckCircle2 className="mr-2 h-4 w-4" />
                    Xác nhận kết quả OCR và tự điền
                  </Button>
                </div>
              )}
            </div>
          )}
          {!hiddenModuleIdSet.has("analysis") && (
            <div className="rounded-2xl border border-[#D8E4DC] bg-white p-4">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
                Bước 5–8 · AI kiểm tra và dựng bộ hồ sơ
              </p>
              <div className="mt-3 grid gap-2 sm:grid-cols-3">
                <div className="rounded-xl bg-[#EAF4EC] p-3 text-xs font-bold text-[#1F5A4A]">
                  {confirmed ? "Đã xác nhận dữ liệu OCR" : "Chưa xác nhận OCR"}
                </div>
                <div className="rounded-xl bg-[#FFF9EA] p-3 text-xs font-bold text-[#6F5520]">
                  {missingDocuments.length} tài liệu cần kiểm tra
                </div>
                <div className="rounded-xl bg-[#EEF3FA] p-3 text-xs font-bold text-[#315C8A]">
                  {aiCheck === "done"
                    ? "AI đã kiểm tra xong"
                    : "Chờ AI phân tích"}
                </div>
              </div>
              <div
                className="mt-3 rounded-xl border border-[#D8E4DC] bg-[#F7FBF7] p-3"
                aria-live="polite"
              >
                <p className="text-sm font-black text-[#1F5A4A]">
                  {analysisStatus.title}
                </p>
                <p className="mt-1 text-xs leading-5 text-[#60766D]">
                  {analysisStatus.detail}
                </p>
                {analysisStatus.nextAction && (
                  <p className="mt-2 text-xs font-black text-[#B38321]">
                    Bước tiếp theo: {analysisStatus.nextAction}
                  </p>
                )}
              </div>
              <Button
                type="button"
                onClick={runAiCheck}
                disabled={!confirmed || aiCheck === "checking"}
                className="mt-3 bg-[#1F5A4A]"
              >
                {aiCheck === "checking" ? (
                  <>
                    <span className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    AI đang kiểm tra…
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    AI phân tích và dựng bộ hồ sơ
                  </>
                )}
              </Button>
              {aiCheck === "done" && (
                <div className="mt-3 rounded-xl border border-[#D8E4DC] bg-[#F7FBF7] p-3 text-xs leading-5 text-[#60766D]">
                  <p className="font-black text-[#1F5A4A]">
                    Bộ hồ sơ đã được dựng theo thủ tục đã chọn.
                  </p>
                  <p className="mt-1">
                    AI đã tách danh mục giấy tờ bắt buộc, đánh dấu tài liệu còn
                    thiếu và đưa dữ liệu đã xác nhận vào phần rà soát. Hãy đối
                    chiếu bản gốc trước khi xuất.
                  </p>
                </div>
              )}
            </div>
          )}
          {!hiddenModuleIdSet.has("review") && (
            <div className="rounded-2xl border border-[#E4D4A8] bg-[#FFFDF4] p-4">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
                    Kiểm tra nhanh trước khi in
                  </p>
                  <h3 className="mt-1 text-base font-black text-[#18352D]">
                    Rà soát bộ hồ sơ trước khi nộp
                  </h3>
                  <p className="mt-1 text-xs leading-5 text-[#6F5520]">
                    Đánh dấu từng mục sau khi đã kiểm tra thực tế. Checklist này
                    giúp tránh thiếu giấy tờ, nhưng không thay thế yêu cầu của
                    cơ quan tiếp nhận.
                  </p>
                </div>
                <span
                  className={`shrink-0 rounded-full px-3 py-1 text-xs font-black ${prePrintReady ? "bg-[#DDEFE1] text-[#1F5A4A]" : "bg-[#F5E8C6] text-[#6F5520]"}`}
                >
                  {prePrintCompleted}/{prePrintChecklist.length} mục
                </span>
              </div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                <p className="text-xs text-[#60766D]">
                  Có thể tải bản PDF để theo dõi trước khi in hồ sơ.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={downloadPrePrintChecklistPdf}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Tải checklist PDF
                </Button>
              </div>
              <div className="mt-3 space-y-2">
                {prePrintChecklist.map(item => (
                  <label
                    key={item.id}
                    className="flex cursor-pointer items-start gap-3 rounded-xl bg-white px-3 py-2.5 text-xs text-[#18352D] transition-colors hover:bg-[#F7FBF7]"
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(prePrintChecks[item.id])}
                      onChange={event =>
                        setPrePrintChecks(current => ({
                          ...current,
                          [item.id]: event.target.checked,
                        }))
                      }
                      className="mt-0.5 h-4 w-4 accent-[#1F5A4A]"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block font-semibold leading-5">
                        {item.label}
                      </span>
                      {item.templateStatus !== "not-applicable" && (
                        <span
                          className={`mt-1 block text-[11px] leading-4 ${item.templateStatus === "official" ? "text-[#1F5A4A]" : item.templateStatus === "reference" ? "text-[#315C8A]" : "text-[#9A6A16]"}`}
                        >
                          {item.templateStatus === "official"
                            ? "Mẫu Official đã xác minh"
                            : item.templateStatus === "reference"
                              ? "Bản tham khảo đã ghép theo thủ tục · chưa Official"
                              : "Đang chờ xác minh mẫu"}{" "}
                          · {item.templateLabel || "Chưa có tên mẫu"}
                          {item.templateFile ? ` · ${item.templateFile}` : ""}
                        </span>
                      )}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          )}
          <div className="rounded-2xl border border-[#D8E4DC] bg-white p-4">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
              Bước 9–10 · Xuất, in, ký và nộp
            </p>
            <div className="mt-3 rounded-xl border border-[#BFD2C5] bg-[#F7FBF7] p-3">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-black text-[#1F5A4A]">
                    Lớp 2 · Xác nhận bản nháp đã rà soát
                  </p>
                  <p className="mt-1 text-[11px] leading-4 text-[#60766D]">
                    Chỉ sau khi bạn bấm xác nhận, file xuất mới được ghi trạng
                    thái OFFICIAL có điều kiện và các nút xuất/in mới hoạt động.
                  </p>
                </div>
                <Button
                  type="button"
                  onClick={confirmFinalDraft}
                  disabled={
                    !confirmed ||
                    aiCheck !== "done" ||
                    !prePrintReady ||
                    hiddenModuleLabels.length > 0 ||
                    draftReviewConfirmed
                  }
                  className="shrink-0 bg-[#1F5A4A]"
                >
                  {draftReviewConfirmed ? (
                    <>
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Đã xác nhận
                    </>
                  ) : (
                    <>
                      <ClipboardCheck className="mr-2 h-4 w-4" />
                      Xác nhận bản nháp
                    </>
                  )}
                </Button>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                disabled={
                  !confirmed || !prePrintReady || hiddenModuleLabels.length > 0
                }
                onClick={() => setShowPrintPreview(current => !current)}
              >
                <FileText className="mr-2 h-4 w-4" />
                {showPrintPreview ? "Ẩn bản xem trước" : "Xem bản in kiểm tra"}
              </Button>
              <Button
                type="button"
                variant="outline"
                disabled={
                  !draftReviewConfirmed ||
                  !officialTemplateReady ||
                  hiddenModuleLabels.length > 0
                }
                onClick={() => exportCertificateBundle("docx")}
              >
                <FileDown className="mr-2 h-4 w-4" />
                Xuất DOCX
              </Button>
              <Button
                type="button"
                variant="outline"
                disabled={
                  !draftReviewConfirmed ||
                  !officialTemplateReady ||
                  hiddenModuleLabels.length > 0
                }
                onClick={() => exportCertificateBundle("pdf")}
              >
                <Download className="mr-2 h-4 w-4" />
                Xuất PDF
              </Button>
              <Button
                type="button"
                disabled={
                  !draftReviewConfirmed ||
                  !officialTemplateReady ||
                  hiddenModuleLabels.length > 0
                }
                onClick={() => {
                  setExported(true);
                  setStep(10);
                  toast.success("Đã đánh dấu sẵn sàng in, ký và nộp một cửa.");
                }}
                className="bg-[#1F5A4A]"
              >
                <ClipboardCheck className="mr-2 h-4 w-4" />
                Sẵn sàng in – ký – nộp
              </Button>
            </div>
            {showPrintPreview && (
              <div className="mt-3 rounded-xl border border-[#D8B15A] bg-[#FFFDF5] p-4">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-[#6F5520]">
                    Bản xem trước để in kiểm tra
                  </p>
                  <span className="text-[11px] text-[#60766D]">
                    Nguồn và ngày kiểm tra được giữ trong bản xuất
                  </span>
                </div>
                <pre className="max-h-72 overflow-auto whitespace-pre-wrap text-[11px] leading-5 text-[#18352D]">
                  {buildCertificateExportContent()}
                </pre>
              </div>
            )}
            {!prePrintReady && (
              <p className="mt-3 text-xs font-semibold text-[#A14C31]">
                Hoàn tất checklist để mở khóa bước xác nhận bản nháp.
              </p>
            )}
            {!confirmed && (
              <p className="mt-3 text-xs font-semibold text-[#A14C31]">
                Cần xác nhận dữ liệu OCR trước khi xác nhận bản nháp cuối.
              </p>
            )}
            {draftReviewConfirmed && (
              <p
                className={`mt-3 text-xs font-semibold ${officialTemplateReady ? "text-[#1F5A4A]" : "text-[#A14C31]"}`}
              >
                {officialTemplateReady
                  ? "Đã đủ mẫu Official đã xác minh. Có thể xuất file theo điều kiện kiểm tra."
                  : "Đã xác nhận nội dung, nhưng chưa đủ mẫu binary Official đã xác minh nên chưa thể xuất Official."}
              </p>
            )}
          </div>
        </div>
        <aside className="space-y-4">
          <div className="rounded-2xl bg-[#1F5A4A] p-5 text-white">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#D8E9D9]">
              AI riêng cho cấp Giấy chứng nhận
            </p>
            <h3 className="mt-2 text-lg font-black">
              Không tự động nộp thay bạn
            </h3>
            <p className="mt-2 text-sm leading-6 text-[#E0EFE2]">
              AI chỉ hỗ trợ đọc, đối chiếu và dựng bản chuẩn bị. Người dùng phải
              kiểm tra bản gốc, ký đúng thẩm quyền và mang hồ sơ đến cơ quan
              tiếp nhận.
            </p>
          </div>
          <div className="rounded-2xl border border-[#D8E4DC] bg-white p-4">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[#B38321]">
              Thành phần dự kiến
            </p>
            <div className="mt-3 space-y-2">
              {procedure.documents.map((document, index) => (
                <div key={document} className="flex gap-2 text-xs leading-5">
                  <span
                    className={`mt-1 h-2 w-2 shrink-0 rounded-full ${files[index] ? "bg-[#1F5A4A]" : "bg-[#D8B15A]"}`}
                  />
                  <span className="text-[#60766D]">{document}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[11px] leading-4 text-[#6F5520]">
              Danh mục chỉ mang tính hỗ trợ; thành phần thực tế phụ thuộc thủ
              tục và cơ quan tiếp nhận địa phương.
            </p>
          </div>
        </aside>
      </div>
    </section>
  );
}

type LandWorkspaceTab = "create" | "mine" | "specialized";

function getLandWorkspaceTabFromUrl(): LandWorkspaceTab {
  if (typeof window === "undefined") return "create";
  const tab = new URLSearchParams(window.location.search).get("tab");
  return tab === "mine" || tab === "specialized" ? tab : "create";
}

export function aiLandWorkspaceTabs() {
  return ["Tạo hồ sơ", "Hồ sơ của tôi", "AI chuyên trách đất đai"] as const;
}

export default function AIDossierAdmin() {
  const [propertyId, setPropertyId] = useState("");
  const [category, setCategory] =
    useState<(typeof categories)[number][0]>("property");
  const [transactionType, setTransactionType] =
    useState<TransactionType>("transfer_land");
  const [search, setSearch] = useState("");
  const [templateSearch, setTemplateSearch] = useState("");
  const [hubSearch, setHubSearch] = useState("");
  const [hubCategory, setHubCategory] = useState("all");
  const [procedureSearch, setProcedureSearch] = useState("");
  const [selectedProcedure, setSelectedProcedure] = useState<string>(
    fallbackLandProcedures[0].id
  );
  const [preview, setPreview] = useState<{
    url: string;
    name: string;
    mime: string;
  } | null>(null);
  const [legalQuestion, setLegalQuestion] = useState("");
  const [legalAnswer, setLegalAnswer] = useState<{
    answer: string;
    sources: string[];
  } | null>(null);
  const [templateText, setTemplateText] = useState("");
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});
  const [sourceReviews, setSourceReviews] = useState<
    Record<string, { checkedAt: string; approved: boolean }>
  >({});
  const [selectedLegalDocumentId, setSelectedLegalDocumentId] = useState(
    officialLegalDocuments[0].id
  );
  const [syncPreview, setSyncPreview] = useState<{
    template: LegalTemplate;
    source: OfficialSource;
  } | null>(null);
  const [templateDraftLabel, setTemplateDraftLabel] =
    useState("Bản nháp hồ sơ");
  const [aiAssistByResult, setAiAssistByResult] = useState<
    Record<
      string,
      {
        status: "idle" | "loading" | "success" | "error";
        data?: LandSearchAiAssist;
      }
    >
  >({});
  const [landWorkspaceTab, setLandWorkspaceTab] = useState<LandWorkspaceTab>(
    getLandWorkspaceTabFromUrl
  );
  const [newLandProcedure, setNewLandProcedure] = useState<string>("");
  const [newProcedureSearch, setNewProcedureSearch] = useState("");
  const [aiProcedureSearch, setAiProcedureSearch] = useState(false);
  const [aiRelatedProcedureIds, setAiRelatedProcedureIds] = useState<string[]>(
    []
  );
  const [myDossierPropertyId, setMyDossierPropertyId] = useState("");
  const [myDossierProcedureId, setMyDossierProcedureId] = useState<string>(
    fallbackLandProcedures[0].id
  );
  const [myDossierPreview, setMyDossierPreview] = useState("");
  const [myDossierMissing, setMyDossierMissing] = useState<string[]>([]);

  useEffect(() => {
    const tab = getLandWorkspaceTabFromUrl();
    setLandWorkspaceTab(tab);
    if (tab === "specialized") {
      window.requestAnimationFrame(() =>
        document
          .getElementById("ai-chuyen-trach-dat-dai")
          ?.scrollIntoView({ block: "start" })
      );
    }
  }, []);
  const [landAnswers, setLandAnswers] = useState({
    seller: "",
    buyer: "",
    parcel: "",
    certificate: "",
    marital: "",
    mortgage: "",
    location: "",
  });
  const [createPropertyId, setCreatePropertyId] = useState("");
  const [createDossierProcedureId, setCreateDossierProcedureId] = useState("");
  const [createDossierPreview, setCreateDossierPreview] = useState("");
  const [createDossierMissing, setCreateDossierMissing] = useState<string[]>(
    []
  );
  const [createProvince, setCreateProvince] = useState("Đà Nẵng");
  const [landEvidence, setLandEvidence] = useState<LandEvidenceItem[]>([]);
  const [ocrResults, setOcrResults] = useState<
    Record<string, AIDossierOcrResult>
  >({});
  const [ocrConfirmed, setOcrConfirmed] = useState(false);
  const [exportingFormat, setExportingFormat] = useState<"docx" | "pdf" | null>(
    null
  );
  const [procedureSuggestions, setProcedureSuggestions] = useState<
    Array<{
      procedureCode: string;
      procedureTitle: string;
      groupName: string;
      reason: string;
      confidence: number;
      evidence: string[];
      sourceUrl?: string | null;
    }>
  >([]);
  const [analysisResult, setAnalysisResult] =
    useState<AIDossierAnalysisResult | null>(null);
  const [analysisConfirmed, setAnalysisConfirmed] = useState(false);
  const [savedCreateDossierId, setSavedCreateDossierId] = useState<
    number | null
  >(null);
  const [createDossierSaveState, setCreateDossierSaveState] = useState<
    "idle" | "saving" | "saved" | "error"
  >("idle");
  const [submissionStatus, setSubmissionStatus] = useState<
    "draft" | "ready_to_print" | "signed" | "submitted"
  >("draft");
  const fileRef = useRef<HTMLInputElement>(null);
  const { user, loading: authLoading } = useAuth();
  const isAdmin = user?.role === "admin";
  const canQueryPrivate = !authLoading && !!user;
  const adminQueryOptions = { enabled: canQueryPrivate && isAdmin };
  const ownerQueryOptions = { enabled: canQueryPrivate && !isAdmin };
  const propertiesAdmin = trpc.properties.adminList.useQuery(
    undefined,
    adminQueryOptions
  );
  const propertiesMine = trpc.properties.mine.useQuery(
    undefined,
    ownerQueryOptions
  );
  const properties = isAdmin ? propertiesAdmin : propertiesMine;
  const owners = trpc.brokerage.owners.useQuery(undefined, adminQueryOptions);
  const buyers = trpc.brokerage.buyers.useQuery(undefined, adminQueryOptions);
  const surveys = trpc.brokerage.surveys.useQuery(undefined, adminQueryOptions);
  const legalChecks = trpc.brokerage.legalChecks.useQuery(
    undefined,
    adminQueryOptions
  );
  const valuations = trpc.brokerage.valuations.useQuery(
    undefined,
    adminQueryOptions
  );
  const deals = trpc.brokerage.deals.useQuery(undefined, adminQueryOptions);
  const dossiers = trpc.brokerage.dossiers.list.useQuery(undefined, {
    enabled: canQueryPrivate,
  });
  const landDossiers = trpc.landDossiers.list.useQuery(undefined, {
    enabled: canQueryPrivate,
  });
  const allArchives = trpc.archives.list.useQuery({}, adminQueryOptions);
  const files = trpc.archives.list.useQuery(
    {
      propertyId: propertyId ? Number(propertyId) : undefined,
      category,
      search: search || undefined,
    },
    { enabled: canQueryPrivate && !!propertyId }
  );
  const upload = trpc.archives.upload.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu tài liệu vào Kho hồ sơ đất đai AI");
      files.refetch();
    },
    onError: e => toast.error(e.message),
  });
  const remove = trpc.archives.delete.useMutation({
    onSuccess: () => {
      toast.success("Đã xóa tài liệu");
      files.refetch();
    },
    onError: e => toast.error(e.message),
  });
  const research = trpc.ai.researchLegal.useMutation({
    onSuccess: result => setLegalAnswer(result),
    onError: e => toast.error(e.message),
  });
  const createLandDossierMutation = trpc.landDossiers.create.useMutation({
    onSuccess: created => {
      setSavedCreateDossierId(created.id);
      setCreateDossierSaveState("saved");
      toast.success("Đã lưu hồ sơ đất đai theo quy trình");
      landDossiers.refetch();
    },
    onError: error => {
      setCreateDossierSaveState("error");
      toast.error(error.message);
    },
  });
  const updateLandDossierMutation = trpc.landDossiers.update.useMutation({
    onSuccess: () => {
      setCreateDossierSaveState("saved");
      toast.success("Đã cập nhật tiến độ hồ sơ");
      landDossiers.refetch();
    },
    onError: error => {
      setCreateDossierSaveState("error");
      toast.error(error.message);
    },
  });
  const cancelLandDossierMutation = trpc.landDossiers.cancel.useMutation({
    onSuccess: () => {
      toast.success("Đã hủy hồ sơ");
      landDossiers.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const deleteLandDossierMutation = trpc.landDossiers.delete.useMutation({
    onSuccess: () => {
      toast.success("Đã xóa hồ sơ");
      landDossiers.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const identifyProcedureMutation =
    trpc.aiAutoDossier.identifyProcedure.useMutation({
      onSuccess: result => {
        setProcedureSuggestions(result.suggestions);
        if (result.suggestions[0]) {
          const suggested = result.suggestions[0];
          const matchedProcedure = landProcedures.find(
            procedure => procedure.id === suggested.procedureCode
          );
          setNewLandProcedure(suggested.procedureCode);
          setCreateDossierProcedureId(suggested.procedureCode);
          setCreateDossierPreview("");
          setCreateDossierMissing([]);
          setSubmissionStatus("draft");
          toast.success(
            `AI đề xuất thủ tục: ${suggested.procedureTitle}. ${matchedProcedure ? "Thủ tục đã được chọn; hãy xác nhận trước khi tạo hồ sơ." : "Hãy đối chiếu với catalog thủ tục trước khi xác nhận."}`
          );
        } else toast.info(result.notice);
      },
      onError: error => toast.error(`AI nhận diện thủ tục: ${error.message}`),
    });
  const ocrLandDossierMutation = trpc.landDossierBuilder.ocr.useMutation();
  const exportBundleMutation = trpc.landDossierBuilder.exportBundle.useMutation(
    {
      onError: error => {
        setExportingFormat(null);
        toast.error(`Xuất hồ sơ: ${error.message}`);
      },
    }
  );
  const analyzeLandDossierMutation =
    trpc.aiAutoDossier.analyzeDossier.useMutation({
      onSuccess: result => {
        setAnalysisResult(result);
        setAnalysisConfirmed(false);
        setCreateDossierMissing([
          ...result.missingComponents,
          ...result.warnings,
        ]);
        setLandEvidence(current =>
          current.map(item =>
            item.status === "analysis"
              ? {
                  ...item,
                  status: "review",
                  progress: 100,
                  stage: "AI đã đối chiếu · cần xác nhận cảnh báo",
                }
              : item
          )
        );
        toast.success(
          "AI đã phân tích hồ sơ; các trường đều cần đối chiếu trước khi điền mẫu."
        );
      },
      onError: error => toast.error(`AI phân tích hồ sơ: ${error.message}`),
    });
  const summarizeResult = trpc.ai.summarizeLandSearchResult.useMutation({
    onMutate: variables =>
      setAiAssistByResult(current => ({
        ...current,
        [variables.resultId]: { status: "loading" },
      })),
    onSuccess: (result, variables) =>
      setAiAssistByResult(current => ({
        ...current,
        [variables.resultId]: { status: "success", data: result },
      })),
    onError: (error, variables) => {
      setAiAssistByResult(current => ({
        ...current,
        [variables.resultId]: { status: "error" },
      }));
      toast.error(error.message);
    },
  });
  const procedureCatalog = trpc.aiAutoDossier.catalog.useQuery(undefined, {
    enabled: canQueryPrivate,
    staleTime: 5 * 60 * 1000,
  });
  const landProcedures = useMemo(() => {
    const items = procedureCatalog.data?.items;
    if (!items?.length) return fallbackLandProcedures;
    return items.map(item => {
      const aliases = Array.isArray(item.aliases)
        ? item.aliases
        : item.aliases
          ? [item.aliases]
          : [];
      const haystack = `${item.name} ${aliases.join(" ")}`.toLowerCase();
      const transactionType: TransactionType = haystack.includes("thừa kế")
        ? "inheritance"
        : haystack.includes("nông nghiệp") ||
            haystack.includes("mục đích sử dụng")
          ? "agri_land"
          : "transfer_land";
      return {
        id: item.code,
        title: item.name,
        hint: [item.groupName, ...aliases].filter(Boolean).join(" · "),
        transactionType,
        sourceId: item.code,
      };
    });
  }, [procedureCatalog.data]);
  useEffect(() => {
    if (!landProcedures.some(item => item.id === selectedProcedure))
      setSelectedProcedure(
        landProcedures[0]?.id || fallbackLandProcedures[0].id
      );
    if (!newLandProcedure && landProcedures[0])
      setNewLandProcedure(landProcedures[0].id);
    if (!landProcedures.some(item => item.id === myDossierProcedureId))
      setMyDossierProcedureId(
        landProcedures[0]?.id || fallbackLandProcedures[0].id
      );
  }, [
    landProcedures,
    selectedProcedure,
    newLandProcedure,
    myDossierProcedureId,
  ]);
  const selectedProperty = useMemo(
    () => properties.data?.find(item => item.id === Number(propertyId)),
    [properties.data, propertyId]
  );
  const myDossierProperty = useMemo(
    () =>
      properties.data?.find(item => item.id === Number(myDossierPropertyId)) as
        | PropertyForLandDossier
        | undefined,
    [properties.data, myDossierPropertyId]
  );
  const myDossierProcedure =
    landProcedures.find(item => item.id === myDossierProcedureId) ||
    landProcedures[0];
  const checklist = checklistByType[transactionType];
  const filteredProcedures = useMemo(
    () =>
      landProcedures.filter(item =>
        matchesNaturalQuery(
          `${item.title} ${item.hint} ${item.id} ${item.transactionType}`,
          procedureSearch
        )
      ),
    [landProcedures, procedureSearch]
  );
  const landSearchResults = useMemo(() => {
    if (!procedureSearch.trim())
      return [] as Array<{
        id: string;
        kind: "template" | "archive";
        title: string;
        subtitle: string;
        searchText: string;
        template?: LegalTemplate;
        archive?: typeof allArchives.data extends Array<infer T> ? T : never;
      }>;
    const templateResults = legalTemplates.map(template => ({
      id: `template-${template.id}`,
      kind: "template" as const,
      title: template.title,
      subtitle: `${template.group} · ${template.authority}`,
      searchText: [
        template.title,
        template.group,
        template.authority,
        template.basis,
        template.effective,
        template.updated,
        ...template.keywords,
      ].join(" "),
      template,
    }));
    const archiveResults = (allArchives.data || []).map(item => ({
      id: `archive-${item.file.id}`,
      kind: "archive" as const,
      title: item.file.fileName,
      subtitle: `${item.file.documentType} · ${item.property.title}`,
      searchText: `${item.file.fileName} ${item.file.documentType} ${item.property.title} ${item.property.location}`,
      archive: item,
    }));
    return [...templateResults, ...archiveResults]
      .filter(item => matchesNaturalQuery(item.searchText, procedureSearch))
      .slice(0, 30);
  }, [allArchives.data, procedureSearch]);
  const activeProcedure =
    landProcedures.find(item => item.id === selectedProcedure) ||
    landProcedures[0];
  const activeProcedureSource = getOfficialSource(activeProcedure.sourceId);
  const selectedLegalDocument =
    officialLegalDocuments.find(item => item.id === selectedLegalDocumentId) ||
    officialLegalDocuments[0];
  const newProcedure = landProcedures.find(
    item => item.id === newLandProcedure
  );
  const filteredNewProcedures = useMemo(
    () =>
      newProcedureSearch.trim()
        ? landProcedures
            .filter(item =>
              matchesNaturalQuery(
                `${item.title} ${item.hint} ${item.id} ${item.transactionType}`,
                newProcedureSearch
              )
            )
            .slice(0, 12)
        : landProcedures,
    [landProcedures, newProcedureSearch]
  );
  const aiRelatedProcedures = useMemo(
    () =>
      landProcedures.filter(item => aiRelatedProcedureIds.includes(item.id)),
    [aiRelatedProcedureIds, landProcedures]
  );
  const newProcedureTemplates = useMemo(
    () =>
      newProcedure ? getProcedureTemplates(newProcedure, legalTemplates) : [],
    [newProcedure]
  );
  const filteredTemplates = useMemo(() => {
    const query = normalizeSearchText(templateSearch.trim());
    if (!query) return legalTemplates;
    return legalTemplates.filter(item => {
      const source = getOfficialSource(item.id);
      return matchesNaturalQuery(
        [
          item.title,
          item.group,
          item.authority,
          item.basis,
          source?.sourceName,
          source?.issuingAgency,
          source?.legalBasis,
          ...item.keywords,
        ].join(" "),
        query
      );
    });
  }, [templateSearch]);
  const fileNames = (files.data || []).map(item =>
    `${item.file.documentType} ${item.file.fileName}`.toLowerCase()
  );
  const checklistState = useMemo(
    () =>
      checklist.map(item => ({
        ...item,
        matched:
          item.categories.some(group => group === category) ||
          fileNames.some(name =>
            item.label
              .toLowerCase()
              .split(" ")
              .some(word => word.length > 4 && name.includes(word))
          ),
      })),
    [checklist, category, fileNames]
  );
  const missingCount = checklistState.filter(
    item => !item.matched && !checkedItems[item.id]
  ).length;
  const dossierHubRecords = useMemo(() => {
    const records: Array<{
      id: string;
      category: string;
      title: string;
      subtitle: string;
      status: string;
      propertyId?: number;
      searchText: string;
      icon: "property" | "person" | "file" | "deal";
    }> = [];
    (properties.data || []).forEach(item =>
      records.push({
        id: `property-${item.id}`,
        category: "BĐS",
        title: item.title,
        subtitle: `${item.propertyCode || "Chưa có mã"} · ${item.location}`,
        status: item.status,
        propertyId: item.id,
        searchText: `${item.title} ${item.location} ${item.propertyCode || ""} ${item.legalStatus || ""}`,
        icon: "property",
      })
    );
    (owners.data || []).forEach(item =>
      records.push({
        id: `owner-${item.id}`,
        category: "Chủ nhà",
        title: item.name,
        subtitle: `${item.phone}${item.email ? ` · ${item.email}` : ""}`,
        status: "Đang quản lý",
        searchText: `${item.name} ${item.phone} ${item.email || ""} ${item.notes || ""}`,
        icon: "person",
      })
    );
    (buyers.data || []).forEach(item =>
      records.push({
        id: `buyer-${item.id}`,
        category: "Khách hàng",
        title: item.name,
        subtitle: `${item.preferredArea || "Chưa có khu vực"} · ${item.status}`,
        status: item.status,
        searchText: `${item.name} ${item.phone} ${item.preferredArea || ""} ${item.propertyType || ""} ${item.notes || ""}`,
        icon: "person",
      })
    );
    (allArchives.data || []).forEach(item =>
      records.push({
        id: `archive-${item.file.id}`,
        category:
          item.file.category === "legal"
            ? "Pháp lý"
            : item.file.category === "transaction"
              ? "Giao dịch"
              : item.file.category === "valuation"
                ? "Thuế / định giá"
                : item.file.category === "marketing"
                  ? "Môi giới"
                  : "Hồ sơ BĐS",
        title: item.file.fileName,
        subtitle: `${item.file.documentType} · ${item.property.title}`,
        status: "Đã lưu",
        propertyId: item.property.id,
        searchText: `${item.file.fileName} ${item.file.documentType} ${item.property.title} ${item.property.location}`,
        icon: "file",
      })
    );
    (surveys.data || []).forEach(item =>
      records.push({
        id: `survey-${item.id}`,
        category: "Khảo sát",
        title: `Phiếu khảo sát #${item.id}`,
        subtitle: item.purpose || "Khảo sát nhu cầu/giao dịch",
        status: "Đã ghi nhận",
        propertyId: item.propertyId || undefined,
        searchText: `${item.purpose || ""} ${item.mustHave || ""} ${item.notes || ""}`,
        icon: "file",
      })
    );
    (legalChecks.data || []).forEach(item =>
      records.push({
        id: `legal-${item.id}`,
        category: "Pháp lý",
        title: `Kiểm tra pháp lý #${item.id}`,
        subtitle: item.notes || "Chưa có ghi chú",
        status: item.status,
        propertyId: item.propertyId,
        searchText: `${item.status} ${item.documents || ""} ${item.notes || ""}`,
        icon: "file",
      })
    );
    (valuations.data || []).forEach(item =>
      records.push({
        id: `valuation-${item.id}`,
        category: "Định giá",
        title: `Phiếu định giá #${item.id}`,
        subtitle: `${item.estimatedPrice} · ${item.method || "Chưa có phương pháp"}`,
        status: "Đã ghi nhận",
        propertyId: item.propertyId,
        searchText: `${item.estimatedPrice} ${item.method || ""} ${item.comparableNotes || ""}`,
        icon: "file",
      })
    );
    (deals.data || []).forEach(item =>
      records.push({
        id: `deal-${item.id}`,
        category: "Giao dịch",
        title: `Giao dịch #${item.id}`,
        subtitle: `${item.stage} · ${item.agreedPrice || "Chưa chốt giá"}`,
        status: item.stage,
        propertyId: item.propertyId,
        searchText: `${item.stage} ${item.agreedPrice || ""} ${item.notes || ""}`,
        icon: "deal",
      })
    );
    (dossiers.data || []).forEach(item =>
      records.push({
        id: `dossier-${item.dossier.id}`,
        category: "Hồ sơ AI điện tử",
        title: `Hồ sơ AI · ${item.property.title}`,
        subtitle: `Bước ${item.dossier.currentStep}/12 · ${item.dossier.status}`,
        status: item.dossier.status,
        propertyId: item.property.id,
        searchText: `${item.property.title} ${item.dossier.status} ${item.dossier.notes || ""}`,
        icon: "deal",
      })
    );
    return records
      .filter(
        item =>
          (hubCategory === "all" || item.category === hubCategory) &&
          matchesNaturalQuery(item.searchText, hubSearch)
      )
      .slice(0, 60);
  }, [
    properties.data,
    owners.data,
    buyers.data,
    surveys.data,
    legalChecks.data,
    valuations.data,
    deals.data,
    dossiers.data,
    allArchives.data,
    hubSearch,
    hubCategory,
  ]);
  const hubCategories = [
    "all",
    ...Array.from(new Set(dossierHubRecords.map(item => item.category))),
  ];

  async function handleUpload(file?: File) {
    if (!file) return;
    if (!propertyId) {
      toast.error("Hãy chọn một BĐS trước khi lưu tài liệu.");
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Tệp không được vượt quá 10MB.");
      return;
    }
    if (!/^(image|video|application|text)\//.test(file.type)) {
      toast.error("Định dạng tệp chưa được hỗ trợ.");
      return;
    }
    upload.mutate({
      propertyId: Number(propertyId),
      category,
      documentType:
        category === "property"
          ? "Phiếu khảo sát BĐS"
          : categories.find(item => item[0] === category)?.[1] ||
            "Tài liệu hồ sơ",
      fileName: file.name,
      mimeType: file.type,
      data: await toBase64(file),
    });
  }
  function selectNewProcedure(procedureId: string) {
    setNewLandProcedure(procedureId);
    setCreateDossierProcedureId(procedureId);
    setCreateDossierPreview("");
    setCreateDossierMissing([]);
    setSubmissionStatus("draft");
  }
  function searchRelatedLandProcedures() {
    const query = normalizeSearchText(newProcedureSearch.trim());
    if (!query) {
      toast.error(
        "Hãy nhập từ khóa như chuyển nhượng, tách thửa hoặc đăng ký biến động."
      );
      return;
    }
    setAiProcedureSearch(true);
    window.setTimeout(() => {
      const terms = query.split(/\\s+/).filter(Boolean);
      const ranked = landProcedures
        .map(procedure => {
          const haystack = normalizeSearchText(
            `${procedure.title} ${procedure.hint} ${procedure.id} ${procedure.transactionType}`
          );
          const score = terms.reduce(
            (total, term) => total + (haystack.includes(term) ? 2 : 0),
            0
          );
          return { id: procedure.id, score };
        })
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .map(item => item.id);
      setAiRelatedProcedureIds(
        ranked.length ? ranked : landProcedures.map(item => item.id)
      );
      setAiProcedureSearch(false);
      toast.success(
        `AI đã tìm thấy ${ranked.length || landProcedures.length} thủ tục trong catalog để đối chiếu.`
      );
    }, 450);
  }
  async function handleLandDocumentUpload(file?: File) {
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) {
      toast.error("Tệp OCR không được vượt quá 12MB.");
      return;
    }
    if (!/^(image|video|application|text)\//.test(file.type)) {
      toast.error("Mục 1 chỉ nhận ảnh, video, PDF, Word hoặc tệp văn bản.");
      return;
    }
    const evidence: LandEvidenceItem = {
      name: file.name,
      size: file.size,
      type: file.type,
      status: "uploaded",
      progress: 8,
      stage: "Đang tiếp nhận dữ liệu đầu vào",
    };
    setLandEvidence(current => [...current, evidence]);
    const updateEvidenceProgress = (
      status: LandEvidenceItem["status"],
      progress: number,
      stage: string,
      extra: Partial<LandEvidenceItem> = {}
    ) =>
      setLandEvidence(current =>
        current.map(item =>
          item.name === evidence.name
            ? { ...item, status, progress, stage, ...extra }
            : item
        )
      );
    const data = await toBase64(file);
    const supportedOcrMimeTypes: LandOcrMimeType[] = [
      "image/jpeg",
      "image/png",
      "image/webp",
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel",
    ];
    const canOcr = supportedOcrMimeTypes.includes(file.type as LandOcrMimeType);
    if (!canOcr) {
      if (createPropertyId) {
        upload.mutate(
          {
            propertyId: Number(createPropertyId),
            category: "legal",
            documentType: "Tài liệu hiện trường · cần AI rà soát riêng",
            fileName: file.name,
            mimeType: file.type,
            data,
          },
          {
            onSuccess: () => {
              updateEvidenceProgress(
                "review",
                100,
                "Đã lưu tài liệu hiện trường · OCR giấy tờ cần ảnh/PDF/Word"
              );
              toast.success(
                `Đã lưu ${file.name}. Video/hiện trường được giữ làm bằng chứng tham khảo.`
              );
            },
            onError: () =>
              updateEvidenceProgress(
                "error",
                100,
                "Không thể lưu · dữ liệu phiên làm việc vẫn được giữ"
              ),
          }
        );
      } else {
        updateEvidenceProgress(
          "review",
          100,
          "Đã giữ trong phiên làm việc · OCR giấy tờ cần ảnh/PDF/Word"
        );
        toast.info(
          "Video/hiện trường đã được giữ trong phiên làm việc; nút AI nhận diện lại sẽ dùng giấy tờ OCR được hỗ trợ."
        );
      }
      return;
    }
    updateEvidenceProgress("ocr", 28, "OCR đang đọc nội dung giấy tờ");
    try {
      const result = await ocrLandDossierMutation.mutateAsync({
        procedureId: newLandProcedure || landProcedures[0]?.id || "variation",
        province: createProvince,
        fileName: file.name,
        mimeType: file.type as LandOcrMimeType,
        data,
      });
      setOcrResults(current => ({ ...current, [file.name]: result }));
      setOcrConfirmed(false);
      updateEvidenceProgress(
        "review",
        100,
        "OCR hoàn tất · cần đối chiếu bản gốc trước khi dùng",
        {
          documentType: result.documentType,
          storageKey: result.storageKey,
          fileUrl: result.fileUrl,
          ocr: result,
        }
      );
      const mergedAnswers = mergeOcrFieldsIntoAnswers(
        result.fields,
        landAnswers
      );
      setLandAnswers(mergedAnswers);
      toast.success(
        `OCR đã đọc ${file.name}; các trường nhận diện được đã điền vào bản nháp để bạn xác nhận.`
      );
      if (createPropertyId) {
        upload.mutate(
          {
            propertyId: Number(createPropertyId),
            category: "legal",
            documentType: `Giấy tờ đất đai · ${result.documentType || "OCR"}`,
            fileName: file.name,
            mimeType: file.type,
            data,
          },
          {
            onError: error =>
              toast.error(
                `Đã OCR nhưng chưa lưu Kho pháp lý: ${error.message}`
              ),
          }
        );
      }
    } catch (error) {
      updateEvidenceProgress(
        "error",
        100,
        "OCR lỗi · hãy thử ảnh/PDF rõ hơn hoặc giữ tệp để rà soát thủ công"
      );
      toast.error(
        error instanceof Error
          ? error.message
          : "OCR chưa hoàn tất; bạn vẫn có thể chọn thủ tục và nhập thủ công."
      );
    }
  }
  function mergeOcrFieldsIntoAnswers(
    fields: AIDossierOcrField[],
    current: LandAnswers
  ): LandAnswers {
    const next = { ...current };
    for (const field of fields) {
      const haystack = `${field.key} ${field.label}`.toLocaleLowerCase("vi");
      if (!field.value.trim()) continue;
      if (
        /seller|transferor|chuyển nhượng|bên chuyển|người sử dụng đất|chủ sử dụng|chủ sở hữu/.test(
          haystack
        ) &&
        !next.seller.trim()
      )
        next.seller = field.value;
      else if (
        /buyer|transferee|bên nhận|người nhận|bên mua/.test(haystack) &&
        !next.buyer.trim()
      )
        next.buyer = field.value;
      else if (
        /parcel|thửa|số tờ|diện tích|địa chỉ thửa/.test(haystack) &&
        !next.parcel.trim()
      )
        next.parcel = field.value;
      else if (
        /certificate|giấy chứng nhận|sổ đỏ|sổ hồng/.test(haystack) &&
        !next.certificate.trim()
      )
        next.certificate = field.value;
      else if (
        /marital|hôn nhân|kết hôn|độc thân/.test(haystack) &&
        !next.marital.trim()
      )
        next.marital = field.value;
      else if (
        /mortgage|thế chấp|bảo đảm/.test(haystack) &&
        !next.mortgage.trim()
      )
        next.mortgage = field.value;
      else if (
        /location|địa chỉ|tỉnh|huyện|xã|phường|vị trí/.test(haystack) &&
        !next.location.trim()
      )
        next.location = field.value;
    }
    return next;
  }
  function identifyLandProcedureFromEvidence() {
    const documents = landEvidence
      .filter(item => item.ocr || item.status !== "error")
      .map(item => ({
        fileName: item.name,
        documentType: item.documentType || item.ocr?.documentType || "",
        ocrText:
          item.ocr?.fields
            .map(field => `${field.label}: ${field.value} (${field.evidence})`)
            .join("\\n") || "",
        ocrFields:
          item.ocr?.fields.map(field => ({
            label: field.label,
            value: field.value,
            evidence: field.evidence,
          })) || [],
      }));
    if (!documents.length) {
      toast.error("Hãy tải ít nhất một giấy tờ trước khi AI nhận diện lại.");
      return;
    }
    identifyProcedureMutation.mutate({ province: createProvince, documents });
  }
  function analyzeCreateDossier(
    nextOcrResults = ocrResults,
    nextEvidence = landEvidence
  ) {
    const procedure = landProcedures.find(item => item.id === newLandProcedure);
    if (!procedure) {
      toast.error("Hãy chọn thủ tục trước khi phân tích hồ sơ.");
      return;
    }
    const ocrFields = Object.values(nextOcrResults).flatMap(result =>
      result.fields.map(field => ({
        key: field.key,
        label: field.label,
        value: field.value,
        evidence: `${result.fileName}: ${field.evidence}`,
        confidence: field.confidence,
      }))
    );
    const profile = Object.fromEntries(
      Object.entries(landAnswers).map(([key, value]) => [key, value.trim()])
    );
    const components = getUniversalRequirements(procedure.id).map(
      (name, index) => ({
        id: `requirement-${index + 1}`,
        name,
        required: true,
        evidence: "Danh mục thành phần hồ sơ cần đối chiếu theo thủ tục.",
      })
    );
    const uploadedDocuments = nextEvidence
      .filter(item => item.ocr)
      .map(item => ({
        fileName: item.name,
        mimeType: item.type,
        componentName: item.ocr?.documentType || item.documentType,
        extractedFields:
          item.ocr?.fields.map(field => ({
            label: field.label,
            value: field.value,
            evidence: field.evidence,
          })) || [],
      }));
    setLandEvidence(current =>
      current.map(item =>
        item.status === "review"
          ? {
              ...item,
              status: "analysis",
              progress: 82,
              stage: "AI đang đối chiếu thành phần và trường bắt buộc",
            }
          : item
      )
    );
    analyzeLandDossierMutation.mutate({
      procedureCode: procedure.sourceId || procedure.id,
      province: createProvince,
      profile,
      ocrFields,
      dossierComponents: components,
      uploadedDocuments,
    });
  }
  function markOcrFieldReviewed(
    fileName: string,
    fieldKey: string,
    value: string
  ) {
    setOcrResults(current => {
      const result = current[fileName];
      if (!result) return current;
      return {
        ...current,
        [fileName]: {
          ...result,
          reviewed: true,
          fields: result.fields.map(field =>
            field.key === fieldKey ? { ...field, value } : field
          ),
        },
      };
    });
    setOcrConfirmed(false);
    setLandAnswers(current =>
      mergeOcrFieldsIntoAnswers(
        [
          {
            key: fieldKey,
            label: fieldKey,
            value,
            confidence: 1,
            evidence: "Người dùng xác nhận/chỉnh sửa",
          },
        ],
        current
      )
    );
  }
  function confirmAnalysisField(fieldKey: string, value: string) {
    const trimmed = value.trim();
    setAnalysisResult(current =>
      current
        ? {
            ...current,
            fields: current.fields.map(field =>
              field.key === fieldKey
                ? { ...field, value: trimmed, needsConfirmation: false }
                : field
            ),
          }
        : current
    );
    if (trimmed)
      setLandAnswers(current =>
        mergeOcrFieldsIntoAnswers(
          [
            {
              key: fieldKey,
              label: fieldKey,
              value: trimmed,
              confidence: 1,
              evidence: "Người dùng xác nhận/chỉnh sửa",
            },
          ],
          current
        )
      );
  }
  function askLegal(question = legalQuestion) {
    const text = question.trim();
    if (text.length < 8) {
      toast.error("Hãy nhập câu hỏi cụ thể hơn.");
      return;
    }
    research.mutate({
      question: text,
      context: `Loại giao dịch: ${transactionTypes.find(item => item[0] === transactionType)?.[1]}. BĐS: ${selectedProperty ? `${selectedProperty.title}; ${selectedProperty.location}` : "chưa chọn"}. Nhóm tài liệu hiện tại: ${category}. Tài liệu đã lưu: ${fileNames.join(", ") || "chưa có"}.`,
    });
  }
  function proposeOfficialUpdate(template: LegalTemplate) {
    const source = getOfficialSource(template.id);
    if (!source) {
      toast.error("Mẫu này chưa có nguồn chính thức được ánh xạ.");
      return;
    }
    setSyncPreview({ template, source });
  }
  function approveOfficialUpdate(templateId: string) {
    setSourceReviews(current => ({
      ...current,
      [templateId]: {
        checkedAt: new Date().toLocaleString("vi-VN"),
        approved: true,
      },
    }));
    setSyncPreview(null);
    toast.success(
      "Đã phê duyệt đề xuất nguồn; mẫu nội bộ cũ vẫn được giữ trong lịch sử."
    );
  }
  function downloadBinary(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    link.rel = "noopener noreferrer";
    link.setAttribute("aria-label", `Tải ${filename}`);
    link.style.position = "fixed";
    link.style.left = "-9999px";
    document.body.appendChild(link);
    link.click();
    window.setTimeout(() => {
      URL.revokeObjectURL(url);
      link.remove();
    }, 2000);
  }

  function safePdfLine(line: string) {
    return line
      .normalize("NFD")
      .replace(/[\\u0300-\\u036f]/g, "")
      .replace(/[^\\x20-\\x7E]/g, " ")
      .trim();
  }

  function wrapPdfLine(line: string, maxChars = 92) {
    const safe = safePdfLine(line);
    if (!safe) return [""];
    const words = safe.split(/\\s+/);
    const chunks: string[] = [];
    let current = "";
    for (const word of words) {
      if ((current + (current ? " " : "") + word).length <= maxChars)
        current += (current ? " " : "") + word;
      else {
        if (current) chunks.push(current);
        current = word.slice(0, maxChars);
      }
    }
    if (current) chunks.push(current);
    return chunks;
  }

  async function downloadDossierDocx(content: string, filename: string) {
    if (!content.trim()) {
      toast.error("Mẫu này chưa có nội dung để tải xuống.");
      return;
    }
    const lines = content.replace(/\\\\n/g, "\\n").split("\\n");
    const children = lines.map(line => {
      const isHeading = /^(BỘ HỒ SƠ|MỤC LỤC|[1-6]\\. |CẢNH BÁO)/.test(
        line.trim()
      );
      return new Paragraph({
        heading: isHeading ? HeadingLevel.HEADING_2 : undefined,
        children: [new TextRun({ text: line || " ", bold: isHeading })],
      });
    });
    const docxDocument = new Document({
      sections: [{ properties: {}, children }],
    });
    downloadBinary(
      await Packer.toBlob(docxDocument),
      filename.endsWith(".docx") ? filename : `${filename}.docx`
    );
  }

  async function downloadDossierPdf(
    content: string,
    filename: string,
    title?: string
  ) {
    if (!content.trim()) {
      toast.error("Mẫu này chưa có nội dung để xuất PDF.");
      return;
    }
    const pdf = await PDFDocument.create();
    const font = await pdf.embedFont(StandardFonts.Helvetica);
    const boldFont = await pdf.embedFont(StandardFonts.HelveticaBold);
    let page = pdf.addPage([595, 842]);
    let y = 790;
    const lines = [
      title ? title.toUpperCase() : "BẢN DỰ THẢO HỒ SƠ",
      ...content.replace(/\\\\n/g, "\\n").split("\\n"),
    ];
    lines.forEach((line, index) => {
      for (const chunk of wrapPdfLine(line)) {
        if (y < 48) {
          page = pdf.addPage([595, 842]);
          y = 790;
        }
        page.drawText(chunk, {
          x: 42,
          y,
          size: index === 0 ? 14 : 9.5,
          font: index === 0 ? boldFont : font,
          color: rgb(0.12, 0.2, 0.17),
        });
        y -= index === 0 ? 26 : 16;
      }
    });
    const bytes = await pdf.save();
    downloadBinary(
      new Blob([new Uint8Array(bytes).buffer as ArrayBuffer], {
        type: "application/pdf",
      }),
      filename.endsWith(".pdf") ? filename : `${filename}.pdf`
    );
  }

  function printDossierPreview(content: string, title: string) {
    void downloadDossierPdf(
      content,
      `${title.toLowerCase().replace(/[^a-z0-9]+/gi, "-")}.pdf`,
      title
    );
  }

  function createWorkflowDossier() {
    const procedure = landProcedures.find(item => item.id === newLandProcedure);
    if (!procedure) {
      toast.error("Hãy chọn thủ tục trước để AI dựng đúng bộ hồ sơ.");
      return;
    }
    if (!landAnswers.location.trim() || !landAnswers.parcel.trim()) {
      toast.error("Hãy nhập ít nhất khu vực và thông tin thửa đất.");
      return;
    }
    const answeredCount = Object.values(landAnswers).filter(value =>
      value.trim()
    ).length;
    const requirements = getUniversalRequirements(procedure.id);
    const steps = universalWorkflowSteps.map(step => {
      const checklist =
        step.number === 3
          ? requirements.map((label, index) => ({
              label,
              status:
                index === 0 && answeredCount > 0
                  ? ("completed" as const)
                  : ("missing" as const),
              note:
                index === 0 && answeredCount > 0
                  ? "Đã có dữ liệu đầu vào."
                  : "Cần bổ sung hoặc đối chiếu bản gốc.",
            }))
          : [
              {
                label: step.description,
                status:
                  step.number === 1 && answeredCount > 0
                    ? ("completed" as const)
                    : ("missing" as const),
                note: "AI chỉ gợi ý trạng thái; cần đối chiếu bản gốc.",
              },
            ];
      const relatedTemplates = legalTemplates
        .filter(template =>
          template.keywords.some(keyword =>
            `${template.title} ${template.group} ${procedure.title}`
              .toLowerCase()
              .includes(keyword.toLowerCase())
          )
        )
        .slice(0, 6)
        .map(template => template.title);
      return {
        stepNumber: step.number,
        title: step.title,
        checklist,
        relatedTemplates,
      };
    });
    createLandDossierMutation.mutate({
      procedureType: procedure.title,
      title: `${procedure.title} · ${landAnswers.location.trim()}`,
      propertyId: propertyId ? Number(propertyId) : null,
      answers: landAnswers,
      steps,
    });
  }
  function buildLegalEvidenceHeader(procedureTitle: string) {
    return `NGUỒN PHÁP LÝ ĐƯỢC CHỌN\nThủ tục: ${procedureTitle}\nVăn bản/nguồn: ${selectedLegalDocument.title}\nLoại: ${selectedLegalDocument.kind}\nCơ quan: ${selectedLegalDocument.issuingAgency}\nNguồn gốc: ${selectedLegalDocument.sourceName}\nURL: ${selectedLegalDocument.sourceUrl}\nNgày hiệu lực/áp dụng: ${selectedLegalDocument.effectiveDate}\nNgày kiểm tra nguồn: ${selectedLegalDocument.lastCheckedAt}\nTrạng thái: ${selectedLegalDocument.status === "verified" ? "Đã đối chiếu metadata nguồn chính thức; vẫn cần kiểm tra mẫu theo địa phương" : "Cần kiểm duyệt trước khi dùng"}\nCẢNH BÁO: Đây là bản dự thảo hỗ trợ chuẩn bị hồ sơ. Người dùng phải xem, chỉnh sửa, ký và đối chiếu với cơ quan tiếp nhận trước khi nộp.\n\n`;
  }

  function buildCreateDossierSteps(
    procedure: LandProcedureOption,
    inputProperty: PropertyForLandDossier,
    answers: LandAnswers
  ) {
    const requirements = getUniversalRequirements(procedure.id);
    return universalWorkflowSteps.map(step => ({
      stepNumber: step.number,
      title: step.title,
      checklist:
        step.number === 3
          ? buildUniversalChecklist(procedure.id, inputProperty, answers)
          : [
              {
                label: step.description,
                status:
                  step.number === 1 &&
                  Object.values(answers).some(value => value.trim())
                    ? ("completed" as const)
                    : ("missing" as const),
                note: "AI chỉ gợi ý trạng thái; cần đối chiếu bản gốc.",
              },
            ],
      relatedTemplates: legalTemplates
        .filter(template =>
          template.keywords.some(keyword =>
            `${template.title} ${procedure.title} ${requirements.join(" ")}`
              .toLowerCase()
              .includes(keyword.toLowerCase())
          )
        )
        .slice(0, 6)
        .map(template => template.title),
    }));
  }

  function buildCreateDossierAnswers(
    procedure: LandProcedureOption,
    answers: LandAnswers,
    missing: string[],
    status = submissionStatus
  ): Record<string, string> {
    const ocrFields = Object.values(ocrResults).flatMap(result =>
      result.fields.map(field => ({
        key: field.key,
        label: field.label,
        value: field.value,
        evidence: `${result.fileName}: ${field.evidence}`,
        confidence: field.confidence,
      }))
    );
    const uploadedDocuments = landEvidence.map(item => ({
      fileName: item.name,
      mimeType: item.type,
      status: item.status,
      documentType: item.documentType || item.ocr?.documentType || "",
      storageKey: item.storageKey || "",
      fileUrl: item.fileUrl || "",
    }));
    return {
      ...answers,
      province: createProvince,
      procedureId: procedure.id,
      procedureTitle: procedure.title,
      submissionStatus: status,
      ocrFields: JSON.stringify(ocrFields),
      uploadedDocuments: JSON.stringify(uploadedDocuments),
      missingComponents: JSON.stringify(missing),
      aiAnalysis: analysisResult ? JSON.stringify(analysisResult) : "",
      savedAtClient: new Date().toISOString(),
    };
  }

  async function saveCreateDossierDraft(statusOverride = submissionStatus) {
    const procedure = landProcedures.find(item => item.id === newLandProcedure);
    if (!procedure) {
      toast.error("Hãy chọn thủ tục trước khi lưu hồ sơ.");
      return;
    }
    const answersFromInput: LandAnswers = Object.fromEntries(
      Object.entries(landAnswers).map(([key, value]) => [key, value.trim()])
    ) as LandAnswers;
    const inputProperty = aiDossierBuildInputProperty(answersFromInput);
    const missing = getMissingLandDossierFields(
      inputProperty,
      procedure.id,
      answersFromInput
    );
    const steps = buildCreateDossierSteps(
      procedure,
      inputProperty,
      answersFromInput
    );
    const answers = buildCreateDossierAnswers(
      procedure,
      answersFromInput,
      [...missing, ...(analysisResult?.warnings || [])],
      statusOverride
    );
    const propertyIdValue = createPropertyId.trim()
      ? Number(createPropertyId)
      : null;
    setLandAnswers(answersFromInput);
    setCreateDossierProcedureId(procedure.id);
    setCreateDossierMissing([...missing, ...(analysisResult?.warnings || [])]);
    setCreateDossierSaveState("saving");
    const persistedStatus =
      statusOverride === "draft"
        ? ("draft" as const)
        : ("in_progress" as const);
    try {
      if (savedCreateDossierId) {
        await updateLandDossierMutation.mutateAsync({
          id: savedCreateDossierId,
          currentStep: analysisResult ? 3 : landEvidence.length ? 2 : 1,
          status: persistedStatus,
          answers,
          notes: "Bản nháp Mục 1 · cần đối chiếu bản gốc trước khi nộp.",
        });
      } else {
        const result = await createLandDossierMutation.mutateAsync({
          procedureType: procedure.title,
          title: `${procedure.title} · ${answersFromInput.location || "bản nháp mới"}`,
          propertyId:
            propertyIdValue !== null && Number.isFinite(propertyIdValue)
              ? propertyIdValue
              : null,
          answers,
          steps,
        });
        setSavedCreateDossierId(result.id);
      }
      toast.success(
        savedCreateDossierId
          ? "Đã cập nhật bản nháp hồ sơ; dữ liệu sẽ được giữ để tiếp tục xử lý."
          : "Đã lưu bản nháp hồ sơ; các lần lưu sau sẽ cập nhật cùng một hồ sơ."
      );
    } catch (error) {
      setCreateDossierSaveState("error");
      toast.error(
        error instanceof Error ? error.message : "Chưa lưu được bản nháp hồ sơ."
      );
    }
  }

  function buildCreateExportFields() {
    if (analysisResult?.fields.length) {
      return analysisResult.fields.map(field => ({
        label: field.label,
        value: field.value.trim(),
        confirmed: analysisConfirmed && Boolean(field.value.trim()),
      }));
    }
    return Object.entries(landAnswers)
      .filter(([, value]) => value.trim())
      .map(([key, value]) => ({
        label: key,
        value: value.trim(),
        confirmed: Object.keys(ocrResults).length === 0 || ocrConfirmed,
      }));
  }

  async function exportCreateDossier(format: "docx" | "pdf") {
    const procedure = landProcedures.find(item => item.id === newLandProcedure);
    if (!procedure || !createDossierPreview) {
      toast.error("Hãy dựng bản nháp hồ sơ trước khi xuất.");
      return;
    }
    if (Object.keys(ocrResults).length > 0 && !ocrConfirmed) {
      toast.error("Hãy xác nhận kết quả OCR trước khi xuất hồ sơ.");
      return;
    }
    if (!analysisResult) {
      toast.error(
        "Hãy chạy AI phân tích và đối chiếu cảnh báo trước khi xuất."
      );
      return;
    }
    const template = landDossierBuilderTemplates(
      adminToBuilderProcedure[procedure.id] ?? procedure.id
    )[0];
    if (!template) {
      toast.error("Chưa có thông tin mẫu tham chiếu cho thủ tục này.");
      return;
    }
    const fields = buildCreateExportFields();
    if (fields.some(field => !field.confirmed)) {
      toast.error("Vẫn còn trường dữ liệu cần xác nhận trước khi xuất.");
      return;
    }
    setExportingFormat(format);
    try {
      const result = await exportBundleMutation.mutateAsync({
        procedureTitle: procedure.title,
        province: createProvince.trim() || "Chưa xác định",
        fields,
        format,
        documentType: "bundle",
        documentLabel: `${procedure.title} · ${createProvince}`,
        templateName: template.label,
        templateSource: template.sourceUrl,
        sourceCheckedAt: selectedLegalDocument.lastCheckedAt,
        templateProvenance: template.provenance,
      });
      const binary = Uint8Array.from(atob(result.data), char =>
        char.charCodeAt(0)
      );
      const blob = new Blob([binary], { type: result.mimeType });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = result.fileName;
      anchor.click();
      URL.revokeObjectURL(url);
      toast.success(
        result.status === "confirmed-verified-template"
          ? "Đã xuất theo mẫu đã xác minh. Vẫn cần kiểm tra trước khi nộp."
          : "Đã xuất bản nháp có đánh dấu cần đối chiếu; chưa phải mẫu Official."
      );
    } finally {
      setExportingFormat(null);
    }
  }

  function createNewLandDossier() {
    const procedure = landProcedures.find(item => item.id === newLandProcedure);
    if (!procedure) {
      toast.error("Hãy chọn thủ tục trước để AI dựng đúng bộ hồ sơ.");
      return;
    }
    const answersFromInput: LandAnswers = Object.fromEntries(
      Object.entries(landAnswers).map(([key, value]) => [key, value.trim()])
    ) as LandAnswers;
    if (
      !answersFromInput.location &&
      !answersFromInput.parcel &&
      !answersFromInput.seller &&
      !answersFromInput.certificate
    ) {
      toast.error(
        "Hãy nhập thông tin đầu vào hoặc tải giấy tờ để AI phân tích."
      );
      return;
    }
    const inputProperty = aiDossierBuildInputProperty(answersFromInput);
    const missing = getMissingLandDossierFields(
      inputProperty,
      procedure.id,
      answersFromInput
    );
    const preview = `${buildLegalEvidenceHeader(procedure.title)}${buildUniversalDossierPreview(inputProperty, procedure.title, procedure.id, answersFromInput, missing)}`;
    setLandAnswers(answersFromInput);
    setCreateDossierProcedureId(procedure.id);
    setCreateDossierMissing(missing);
    setCreateDossierPreview(preview);
    setSubmissionStatus("ready_to_print");
    void saveCreateDossierDraft("ready_to_print");
  }

  function normaliseTemplateContent(content: string) {
    return content.replace(/\\\\n/g, "\\n").replace(/\\r/g, "\\r");
  }

  function openProcedureTemplate(template: LegalTemplate) {
    setTemplateDraftLabel(
      `${template.title} · ${newProcedure?.title || "thủ tục đã chọn"}`
    );
    setTemplateText(normaliseTemplateContent(template.content));
  }

  function fillLandTemplate(template: LegalTemplate) {
    if (!landAnswers.location.trim() || !landAnswers.parcel.trim()) {
      toast.error(
        "Hãy nhập ít nhất khu vực và thông tin thửa đất trong phần Tạo hồ sơ mới."
      );
      setLandWorkspaceTab("create");
      return;
    }
    setTemplateDraftLabel(`${template.title} · đã tự động điền`);
    setTemplateText(
      aiDossierAutofillTemplate(
        template.title,
        normaliseTemplateContent(template.content),
        landAnswers
      )
    );
    toast.success(
      `Đã điền dữ liệu vào mẫu ${template.title}. Hãy kiểm tra trước khi tải.`
    );
  }

  function downloadTemplate(template: LegalTemplate) {
    const content = normaliseTemplateContent(template.content);
    const filename = template.title.toLowerCase().replace(/[^a-z0-9]+/gi, "-");
    void downloadDossierDocx(content, `${filename}.docx`);
    toast.success(
      "Đã tạo DOCX nhị phân để mở và chỉnh sửa. Đây vẫn là bản tham khảo, không phải mẫu Official."
    );
  }
  function downloadTemplatePdf(template: LegalTemplate) {
    const content = normaliseTemplateContent(template.content);
    const filename = template.title.toLowerCase().replace(/[^a-z0-9]+/gi, "-");
    void downloadDossierPdf(content, `${filename}.pdf`, template.title);
  }
  function analyzeChecklist() {
    askLegal(
      `Hãy giúp tôi rà soát theo dạng tham khảo bộ hồ sơ cho giao dịch ${transactionTypes.find(item => item[0] === transactionType)?.[1]}. Checklist dự kiến gồm: ${checklist.map(item => item.label).join("; ")}. Tài liệu hiện đã có: ${fileNames.join(", ") || "chưa có"}. Hãy phân biệt rõ đã có, còn thiếu và cần cơ quan/chuyên gia kiểm tra.`
    );
  }
  function prepareMyLandDossier() {
    if (!myDossierProperty) {
      toast.error("Hãy chọn một BĐS từ dữ liệu BĐS của tôi.");
      return;
    }
    const answersForProperty: LandAnswers = {
      ...landAnswers,
      location: landAnswers.location.trim() || myDossierProperty.location,
      parcel:
        landAnswers.parcel.trim() ||
        `Mã BĐS ${myDossierProperty.propertyCode || myDossierProperty.id} · diện tích ${myDossierProperty.certificateArea || myDossierProperty.area || "chưa có"} m²`,
      seller: landAnswers.seller.trim() || myDossierProperty.ownerName || "",
      certificate:
        landAnswers.certificate.trim() ||
        [myDossierProperty.certificateType, myDossierProperty.legalStatus]
          .filter(Boolean)
          .join(" · "),
      mortgage:
        landAnswers.mortgage.trim() || myDossierProperty.mortgageStatus || "",
    };
    const missing = getMissingLandDossierFields(
      myDossierProperty,
      myDossierProcedure.id,
      answersForProperty
    );
    setLandAnswers(answersForProperty);
    setMyDossierMissing(missing);
    setMyDossierPreview(
      buildUniversalDossierPreview(
        myDossierProperty,
        myDossierProcedure.title,
        myDossierProcedure.id,
        answersForProperty,
        missing
      )
    );
    toast.success(
      missing.length
        ? `Đã dựng bản nháp; còn thiếu ${missing.length} trường cần bổ sung.`
        : "Đã dựng bộ hồ sơ từ dữ liệu BĐS."
    );
  }

  function createMyLandDossier() {
    if (!myDossierProperty) {
      toast.error("Hãy chọn một BĐS trước.");
      return;
    }
    const answersForProperty: LandAnswers = {
      ...landAnswers,
      location: landAnswers.location.trim() || myDossierProperty.location,
      parcel:
        landAnswers.parcel.trim() ||
        `Mã BĐS ${myDossierProperty.propertyCode || myDossierProperty.id} · diện tích ${myDossierProperty.certificateArea || myDossierProperty.area || "chưa có"} m²`,
      seller: landAnswers.seller.trim() || myDossierProperty.ownerName || "",
      certificate:
        landAnswers.certificate.trim() ||
        [myDossierProperty.certificateType, myDossierProperty.legalStatus]
          .filter(Boolean)
          .join(" · "),
      mortgage:
        landAnswers.mortgage.trim() || myDossierProperty.mortgageStatus || "",
    };
    const answeredCount = Object.values(answersForProperty).filter(value =>
      value.trim()
    ).length;
    const requirements = getUniversalRequirements(myDossierProcedure.id);
    const steps = universalWorkflowSteps.map(step => ({
      stepNumber: step.number,
      title: step.title,
      checklist:
        step.number === 3
          ? buildUniversalChecklist(
              myDossierProcedure.id,
              myDossierProperty,
              answersForProperty
            )
          : [
              {
                label: step.description,
                status:
                  step.number === 1 && answeredCount > 0
                    ? ("completed" as const)
                    : ("missing" as const),
                note: "AI chỉ gợi ý trạng thái; cần đối chiếu bản gốc.",
              },
            ],
      relatedTemplates: legalTemplates
        .filter(template =>
          template.keywords.some(keyword =>
            `${template.title} ${myDossierProcedure.title} ${requirements.join(" ")}`
              .toLowerCase()
              .includes(keyword.toLowerCase())
          )
        )
        .slice(0, 6)
        .map(template => template.title),
    }));
    createLandDossierMutation.mutate({
      procedureType: myDossierProcedure.title,
      title: `${myDossierProcedure.title} · ${myDossierProperty.title}`,
      propertyId: myDossierProperty.id,
      answers: answersForProperty,
      steps,
    });
  }

  function selectLandProcedure(
    procedure: (typeof fallbackLandProcedures)[number]
  ) {
    setSelectedProcedure(procedure.id);
    setTransactionType(procedure.transactionType);
    setTemplateSearch(procedure.title);
    toast.success(`Đã lập bộ hồ sơ tham khảo: ${procedure.title}`);
  }

  function openHubRecord(record: (typeof dossierHubRecords)[number]) {
    if (record.propertyId) setPropertyId(String(record.propertyId));
    if (record.category === "Pháp lý") setCategory("legal");
    else if (record.category === "Giao dịch") setCategory("transaction");
    else if (
      record.category === "Thuế / định giá" ||
      record.category === "Định giá"
    )
      setCategory("valuation");
    else if (record.category === "Môi giới") setCategory("marketing");
    else setCategory("property");
    toast.success(
      record.propertyId
        ? `Đã mở hồ sơ liên quan đến BĐS #${record.propertyId}.`
        : "Đã chọn hồ sơ trong kho tổng hợp."
    );
  }
  function hubIcon(kind: (typeof dossierHubRecords)[number]["icon"]) {
    if (kind === "property") return <Building2 className="h-5 w-5" />;
    if (kind === "person") return <UserRound className="h-5 w-5" />;
    if (kind === "deal") return <Handshake className="h-5 w-5" />;
    return <FileText className="h-5 w-5" />;
  }
  return (
    <DashboardLayout>
      <main className="min-h-screen bg-[#F4F7F4] px-4 py-5 text-[#18352D] sm:px-6 lg:px-8">
        <div className="mx-auto max-w-[1500px]">
          <section className="rounded-[28px] bg-gradient-to-br from-[#123D32] via-[#1F5A4A] to-[#2E7660] p-6 text-white shadow-lg sm:p-8">
            <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
              <div>
                <p className="text-sm font-bold uppercase tracking-[0.18em] text-[#D8B15A]">
                  Quản lý nguồn hàng · AI pháp lý
                </p>
                <h1 className="mt-2 text-3xl font-black sm:text-4xl">
                  Kho hồ sơ đất đai AI
                </h1>
                <p className="mt-3 max-w-2xl text-sm leading-6 text-white/80 sm:text-base">
                  Tập trung tài liệu theo từng BĐS và loại giao dịch. AI hỗ trợ
                  tìm kiếm, rà soát thiếu hồ sơ và tạo bản nháp để bạn kiểm tra.
                </p>
              </div>
              <div className="flex flex-wrap gap-2 text-xs font-bold">
                <span className="rounded-full bg-white/15 px-3 py-2">
                  Camera + OCR
                </span>
                <span className="rounded-full bg-white/15 px-3 py-2">
                  Checklist giao dịch
                </span>
                <span className="rounded-full bg-white/15 px-3 py-2">
                  Bản nháp có cảnh báo
                </span>
              </div>
            </div>
          </section>
          <section className="mt-5 rounded-2xl border-2 border-[#D8E4DC] bg-[#FBFDFB] p-5 shadow-sm sm:p-6">
            <div className="mb-4 inline-flex rounded-full bg-[#F4E7BF] px-3 py-1.5 text-[11px] font-black uppercase tracking-[0.16em] text-[#80601C]">
              Mục 1 · Tạo hồ sơ mới
            </div>
            <div className="flex flex-col gap-4 border-b border-[#E1EAE3] pb-4 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">
                  Phân hệ chuyên sâu · khác với Hồ sơ AI tổng hợp
                </p>
                <h2 className="mt-1 text-2xl font-black text-[#18352D]">
                  Tạo lập hồ sơ đất đai theo quy trình
                </h2>
                <p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">
                  Chọn BĐS, chọn thủ tục, AI phân tích và dựng bộ hồ sơ theo
                  workflow 6 bước rồi lưu vào Hồ sơ của tôi. Đây là workspace xử
                  lý thủ tục đất đai, không phải kho hồ sơ CRM tổng hợp.
                </p>
              </div>
              <div className="flex gap-2 rounded-xl bg-[#EEF5F0] p-1">
                <button
                  type="button"
                  onClick={() => setLandWorkspaceTab("create")}
                  className={`rounded-lg px-3 py-2 text-xs font-black ${landWorkspaceTab === "create" ? "bg-[#1F5A4A] text-white" : "text-[#1F5A4A]"}`}
                >
                  <Sparkles className="mr-1 inline h-3.5 w-3.5" />
                  Mục 1 · Tạo hồ sơ mới
                </button>
                <button
                  type="button"
                  onClick={() => setLandWorkspaceTab("mine")}
                  className={`rounded-lg px-3 py-2 text-xs font-black ${landWorkspaceTab === "mine" ? "bg-[#1F5A4A] text-white" : "text-[#1F5A4A]"}`}
                >
                  <FolderOpen className="mr-1 inline h-3.5 w-3.5" />
                  Hồ sơ của tôi ({landDossiers.data?.length || 0})
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLandWorkspaceTab("specialized");
                    document
                      .getElementById("ai-chuyen-trach-dat-dai")
                      ?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }}
                  className={`rounded-lg px-3 py-2 text-xs font-black ${landWorkspaceTab === "specialized" ? "bg-[#1F5A4A] text-white" : "text-[#1F5A4A]"}`}
                >
                  <ShieldCheck className="mr-1 inline h-3.5 w-3.5" />
                  AI chuyên trách đất đai
                </button>
              </div>
            </div>
            {landWorkspaceTab === "create" ? (
              <div>
                <section className="mb-5 rounded-2xl border-2 border-[#D8E4DC] bg-white p-5 shadow-sm sm:p-6">
                  <div className="flex flex-col gap-3 border-b border-[#E1EAE3] pb-4 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">
                        Bước 1 · Chọn thủ tục
                      </p>
                      <h3 className="mt-1 text-2xl font-black text-[#18352D]">
                        Chọn đúng hồ sơ đất đai để AI phân tích
                      </h3>
                      <p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">
                        Đây là bước riêng của phân hệ pháp lý đất đai. Hãy chọn
                        thủ tục trước; hệ thống sẽ xác định thành phần hồ sơ,
                        giấy tờ cần bổ sung và quy trình xử lý tương ứng.
                      </p>
                    </div>
                    <span className="inline-flex w-fit items-center gap-2 rounded-full bg-[#EAF2ED] px-3 py-2 text-xs font-black text-[#1F5A4A]">
                      <Sparkles className="h-4 w-4" />
                      AI phân tích sau khi chọn
                    </span>
                  </div>
                  <div className="mt-4 rounded-xl border border-[#D8E4DC] bg-[#F7FBF7] p-3">
                    <div className="flex flex-col gap-2 sm:flex-row">
                      <div className="relative flex-1">
                        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#7B9186]" />
                        <Input
                          value={newProcedureSearch}
                          onChange={event => {
                            setNewProcedureSearch(event.target.value);
                            setAiRelatedProcedureIds([]);
                          }}
                          onKeyDown={event => {
                            if (event.key === "Enter")
                              searchRelatedLandProcedures();
                          }}
                          placeholder="Tìm thủ tục: chuyển nhượng, tách thửa, thừa kế..."
                          className="min-h-11 bg-white pl-9 text-sm"
                          aria-label="Tìm kiếm thủ tục đất đai"
                        />
                      </div>
                      <Button
                        type="button"
                        onClick={searchRelatedLandProcedures}
                        disabled={aiProcedureSearch}
                        className="min-h-11 shrink-0 bg-[#1F5A4A] hover:bg-[#164637]"
                      >
                        <Sparkles
                          className={`mr-2 h-4 w-4 ${aiProcedureSearch ? "animate-spin" : ""}`}
                        />
                        {aiProcedureSearch
                          ? "AI đang tìm..."
                          : "AI tìm liên quan"}
                      </Button>
                    </div>
                    <p className="mt-2 text-[11px] text-[#60766D]">
                      Gõ có dấu hoặc không dấu. AI sẽ ưu tiên thủ tục phù hợp và
                      mở rộng các thủ tục đất đai liên quan.
                    </p>
                    {aiRelatedProcedures.length > 0 && (
                      <div className="mt-3 rounded-lg border border-[#F0D9A4] bg-[#FFF9EA] p-3">
                        <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">
                          AI gợi ý từ khóa của bạn
                        </p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          {aiRelatedProcedures.map(procedure => (
                            <button
                              key={`ai-${procedure.id}`}
                              type="button"
                              onClick={() => selectNewProcedure(procedure.id)}
                              className="rounded-full border border-[#D8B15A] bg-white px-3 py-1.5 text-xs font-bold text-[#6F5520] hover:bg-[#F4E7BF]"
                            >
                              {procedure.title}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    {filteredNewProcedures.map(procedure => (
                      <button
                        key={procedure.id}
                        type="button"
                        onClick={() => selectNewProcedure(procedure.id)}
                        className={`min-h-[92px] rounded-xl border p-4 text-left transition-colors ${newLandProcedure === procedure.id ? "border-[#1F5A4A] bg-[#EAF2ED] ring-2 ring-[#BFD2C5]" : "border-[#D8E4DC] bg-[#FBFDFB] hover:border-[#9FBDAA] hover:bg-[#F4F8F5]"}`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="text-sm font-black text-[#18352D]">
                            {procedure.title}
                          </span>
                          {newLandProcedure === procedure.id && (
                            <CheckCircle2 className="h-4 w-4 shrink-0 text-[#1F5A4A]" />
                          )}
                        </div>
                        <span className="mt-2 block text-[11px] leading-4 text-[#60766D]">
                          {procedure.hint}
                        </span>
                      </button>
                    ))}
                  </div>
                  <div className="mt-4 rounded-xl border-2 border-[#BFD2C5] bg-[#F7FBF7] p-4">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
                          Nguồn pháp lý AI phải đối chiếu
                        </p>
                        <h4 className="mt-1 text-base font-black text-[#18352D]">
                          Chọn Luật, nghị định và nguồn thủ tục áp dụng
                        </h4>
                        <p className="mt-1 max-w-3xl text-xs leading-5 text-[#60766D]">
                          AI sẽ đưa nguồn đã chọn vào bản xem trước. Mẫu cuối
                          vẫn phải được đối chiếu theo mã thủ tục, địa phương và
                          cơ quan tiếp nhận.
                        </p>
                      </div>
                      <select
                        value={selectedLegalDocumentId}
                        onChange={event =>
                          setSelectedLegalDocumentId(event.target.value)
                        }
                        className="min-h-11 w-full rounded-xl border border-[#C9D8D0] bg-white p-3 text-sm font-bold text-[#18352D] lg:max-w-md"
                        aria-label="Chọn nguồn pháp lý chính thức"
                      >
                        {officialLegalDocuments.map(document => (
                          <option key={document.id} value={document.id}>
                            {document.kind} · {document.title}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="mt-3 grid gap-2 sm:grid-cols-4">
                      <div className="rounded-lg bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          Cơ quan
                        </p>
                        <p className="mt-1 text-xs font-bold text-[#18352D]">
                          {selectedLegalDocument.issuingAgency}
                        </p>
                      </div>
                      <div className="rounded-lg bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          Nguồn
                        </p>
                        <a
                          href={selectedLegalDocument.sourceUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="mt-1 block truncate text-xs font-bold text-[#1F5A4A] underline"
                        >
                          {selectedLegalDocument.sourceName}
                        </a>
                      </div>
                      <div className="rounded-lg bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          Ngày kiểm tra
                        </p>
                        <p className="mt-1 text-xs font-bold text-[#18352D]">
                          {selectedLegalDocument.lastCheckedAt}
                        </p>
                      </div>
                      <div className="rounded-lg bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          Trạng thái
                        </p>
                        <p className="mt-1 text-xs font-bold text-[#1F5A4A]">
                          {selectedLegalDocument.status === "verified"
                            ? "Đã xác minh nguồn"
                            : "Cần kiểm duyệt"}
                        </p>
                      </div>
                    </div>
                    <p className="mt-3 text-[11px] font-semibold leading-4 text-[#6F5520]">
                      {selectedLegalDocument.note} Bản xuất là bản hỗ trợ chuẩn
                      bị; hãy xem, chỉnh sửa, ký và xác nhận tại cơ quan tiếp
                      nhận trước khi nộp.
                    </p>
                  </div>
                  {newProcedure ? (
                    <div className="mt-4 grid gap-4 lg:grid-cols-[1.15fr_.85fr]">
                      <div className="rounded-xl bg-[#F7FBF7] p-4">
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">
                              AI đã nhận diện thủ tục
                            </p>
                            <p className="mt-1 text-lg font-black text-[#18352D]">
                              {newProcedure.title}
                            </p>
                          </div>
                          <span className="rounded-full bg-[#D8E4DC] px-3 py-1 text-[10px] font-black text-[#1F5A4A]">
                            {newProcedureTemplates.length} mẫu liên quan
                          </span>
                        </div>
                        <p className="mt-2 text-xs leading-5 text-[#60766D]">
                          {newProcedure.hint}. AI sẽ dùng dữ liệu này để phân
                          tích điều kiện, đối chiếu giấy tờ và tạo bộ hồ sơ.
                        </p>
                        <div className="mt-3 space-y-2">
                          {newProcedureTemplates.slice(0, 4).map(template => {
                            const source = getOfficialSource(template.id);
                            return (
                              <div
                                key={template.id}
                                className="flex flex-col gap-2 rounded-lg border border-[#D8E4DC] bg-white p-3 sm:flex-row sm:items-center sm:justify-between"
                              >
                                <div>
                                  <p className="text-xs font-black text-[#18352D]">
                                    {template.title}
                                  </p>
                                  <p className="mt-1 text-[11px] text-[#60766D]">
                                    {template.officialFileName ||
                                      "Mẫu/khung theo thủ tục"}{" "}
                                    ·{" "}
                                    {template.officialFormStatus ===
                                    "official_source"
                                      ? "Nguồn file chính thức"
                                      : template.officialFormStatus ===
                                          "legacy_reference"
                                        ? "Tham chiếu cần rà soát"
                                        : "Cần rà soát địa phương"}
                                  </p>
                                </div>
                                {source && (
                                  <a
                                    href={source.sourceUrl}
                                    target="_blank"
                                    rel="noreferrer"
                                    className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-black ${officialStatusClass(source.status)}`}
                                  >
                                    <ExternalLink className="h-3 w-3" />
                                    {officialStatusLabel(source.status)}
                                  </a>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      <div className="rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-4">
                        <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">
                          Thành phần cần chuẩn bị
                        </p>
                        <div className="mt-2 grid gap-2 sm:grid-cols-2">
                          {(procedureRequirementMap[newProcedure.id] || []).map(
                            (requirement, index) => (
                              <div
                                key={requirement}
                                className="flex items-start gap-2 text-xs text-[#6F5520]"
                              >
                                <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-[#D8B15A] text-[9px] font-black text-white">
                                  {index + 1}
                                </span>
                                <span>{requirement}</span>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4 rounded-xl border border-dashed border-[#BFD2C5] bg-[#FBFDFB] p-5 text-center text-sm text-[#60766D]">
                      Chưa chọn thủ tục. Hãy chọn một ô ở trên để AI bắt đầu
                      phân tích hồ sơ.
                    </div>
                  )}
                  {newProcedure && (
                    <section className="mt-5 rounded-2xl border-2 border-[#BFD2C5] bg-[#F7FBF7] p-4 sm:p-5">
                      <div className="flex flex-col gap-3 border-b border-[#D8E4DC] pb-4 lg:flex-row lg:items-end lg:justify-between">
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">
                            Bước 2 · Dữ liệu đầu vào & AI đối chiếu
                          </p>
                          <h4 className="mt-1 text-lg font-black text-[#18352D]">
                            Tải giấy tờ, nhận diện lại và lưu hồ sơ
                          </h4>
                          <p className="mt-1 max-w-3xl text-xs leading-5 text-[#60766D]">
                            AI chỉ đề xuất và điền bản nháp. Bạn cần kiểm tra
                            bản gốc, chỉnh các trường OCR và xác nhận với cơ
                            quan tiếp nhận trước khi nộp.
                          </p>
                        </div>
                        <span className="inline-flex w-fit items-center gap-2 rounded-full bg-white px-3 py-2 text-xs font-black text-[#1F5A4A]">
                          <FileText className="h-4 w-4" />
                          {savedCreateDossierId
                            ? `Đang chỉnh sửa hồ sơ #${savedCreateDossierId}`
                            : "Chưa lưu hồ sơ"}
                        </span>
                      </div>
                      <div className="mt-4 grid gap-3 sm:grid-cols-2">
                        <label className="text-xs font-black text-[#18352D]">
                          Tỉnh/thành phố
                          <Input
                            value={createProvince}
                            onChange={event =>
                              setCreateProvince(event.target.value)
                            }
                            className="mt-1 min-h-10 bg-white text-sm font-normal"
                            placeholder="Ví dụ: Đà Nẵng"
                          />
                        </label>
                        <label className="text-xs font-black text-[#18352D]">
                          Mã BĐS liên kết (không bắt buộc)
                          <Input
                            value={createPropertyId}
                            onChange={event =>
                              setCreatePropertyId(event.target.value)
                            }
                            inputMode="numeric"
                            className="mt-1 min-h-10 bg-white text-sm font-normal"
                            placeholder="Ví dụ: 125"
                          />
                        </label>
                      </div>
                      <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {(
                          [
                            ["location", "Địa chỉ/khu vực"],
                            ["seller", "Người sử dụng đất/chủ thể hiện tại"],
                            ["buyer", "Người nhận quyền/bên liên quan"],
                            ["parcel", "Số thửa · tờ bản đồ · diện tích"],
                            ["certificate", "Giấy chứng nhận"],
                            ["marital", "Tình trạng hôn nhân"],
                            ["mortgage", "Thế chấp/đăng ký bảo đảm"],
                          ] as Array<[keyof LandAnswers, string]>
                        ).map(([key, label]) => (
                          <label
                            key={key}
                            className="text-xs font-black text-[#18352D]"
                          >
                            {label}
                            <Input
                              value={landAnswers[key]}
                              onChange={event =>
                                setLandAnswers(current => ({
                                  ...current,
                                  [key]: event.target.value,
                                }))
                              }
                              className="mt-1 min-h-10 bg-white text-sm font-normal"
                              placeholder="AI sẽ điền sau khi OCR; bạn có thể sửa"
                            />
                          </label>
                        ))}
                      </div>
                      <input
                        ref={fileRef}
                        type="file"
                        className="hidden"
                        multiple
                        accept="image/jpeg,image/png,image/webp,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,video/*,text/*"
                        onChange={async event => {
                          const selectedFiles = Array.from(
                            event.target.files || []
                          );
                          event.target.value = "";
                          for (const file of selectedFiles) {
                            await handleLandDocumentUpload(file);
                          }
                        }}
                      />
                      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => fileRef.current?.click()}
                          disabled={
                            ocrLandDossierMutation.isPending || upload.isPending
                          }
                          className="min-h-10 border-[#9FBDAA] bg-white text-[#1F5A4A]"
                        >
                          <Upload className="mr-2 h-4 w-4" />
                          Tải giấy tờ / ảnh / video
                        </Button>
                        <Button
                          type="button"
                          onClick={identifyLandProcedureFromEvidence}
                          disabled={
                            identifyProcedureMutation.isPending ||
                            !landEvidence.length
                          }
                          className="min-h-10 bg-[#B38321] text-white hover:bg-[#926D18]"
                        >
                          <Sparkles className="mr-2 h-4 w-4" />
                          {identifyProcedureMutation.isPending
                            ? "AI đang nhận diện..."
                            : "AI nhận diện lại"}
                        </Button>
                        <Button
                          type="button"
                          onClick={() => analyzeCreateDossier()}
                          disabled={
                            analyzeLandDossierMutation.isPending ||
                            !newProcedure
                          }
                          className="min-h-10 bg-[#1F5A4A] hover:bg-[#164637]"
                        >
                          <FileSearch className="mr-2 h-4 w-4" />
                          {analyzeLandDossierMutation.isPending
                            ? "AI đang phân tích..."
                            : "AI phân tích hồ sơ"}
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => void saveCreateDossierDraft()}
                          disabled={
                            createDossierSaveState === "saving" ||
                            createLandDossierMutation.isPending ||
                            updateLandDossierMutation.isPending
                          }
                          className="min-h-10 border-[#1F5A4A] bg-white text-[#1F5A4A]"
                        >
                          <Save className="mr-2 h-4 w-4" />
                          {createDossierSaveState === "saving"
                            ? "Đang lưu..."
                            : savedCreateDossierId
                              ? "Cập nhật hồ sơ"
                              : "Lưu hồ sơ ngay"}
                        </Button>
                        <Button
                          type="button"
                          onClick={createNewLandDossier}
                          disabled={
                            createLandDossierMutation.isPending ||
                            updateLandDossierMutation.isPending
                          }
                          className="min-h-10 bg-[#18352D] hover:bg-[#10251F]"
                        >
                          <ClipboardCheck className="mr-2 h-4 w-4" />
                          Dựng & lưu bộ hồ sơ
                        </Button>
                      </div>
                      {procedureSuggestions.length > 0 && (
                        <div className="mt-4 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3">
                          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">
                            AI nhận diện từ giấy tờ
                          </p>
                          <div className="mt-2 space-y-2">
                            {procedureSuggestions.map(suggestion => (
                              <button
                                key={`${suggestion.procedureCode}-${suggestion.procedureTitle}`}
                                type="button"
                                onClick={() =>
                                  selectNewProcedure(suggestion.procedureCode)
                                }
                                className="flex w-full flex-col gap-1 rounded-lg border border-[#E8D39A] bg-white p-3 text-left hover:bg-[#FFF6D9] sm:flex-row sm:items-center sm:justify-between"
                              >
                                <span>
                                  <span className="block text-xs font-black text-[#18352D]">
                                    {suggestion.procedureTitle}
                                  </span>
                                  <span className="mt-1 block text-[11px] leading-4 text-[#6F5520]">
                                    {suggestion.reason ||
                                      suggestion.evidence.join(" · ")}
                                  </span>
                                </span>
                                <span className="shrink-0 text-[10px] font-black text-[#1F5A4A]">
                                  Độ tin cậy{" "}
                                  {Math.round(suggestion.confidence * 100)}%
                                </span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                      {landEvidence.length > 0 && (
                        <div className="mt-4 rounded-xl border border-[#D8E4DC] bg-white p-3">
                          <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
                            Tài liệu đầu vào · {landEvidence.length} tệp
                          </p>
                          <div className="mt-2 space-y-2">
                            {landEvidence.map(item => (
                              <div
                                key={`${item.name}-${item.size}`}
                                className="rounded-lg bg-[#F7FBF7] p-3"
                              >
                                <div className="flex items-start justify-between gap-3">
                                  <div className="min-w-0">
                                    <p className="truncate text-xs font-black text-[#18352D]">
                                      {item.name}
                                    </p>
                                    <p className="mt-1 text-[11px] text-[#60766D]">
                                      {item.documentType || "Chưa phân loại"} ·{" "}
                                      {item.stage}
                                    </p>
                                  </div>
                                  <span className="shrink-0 text-[10px] font-black uppercase text-[#1F5A4A]">
                                    {item.status}
                                  </span>
                                </div>
                                <div className="mt-2 h-1.5 rounded-full bg-[#E1EAE3]">
                                  <div
                                    className="h-1.5 rounded-full bg-[#1F5A4A]"
                                    style={{ width: `${item.progress}%` }}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {Object.values(ocrResults).length > 0 && (
                        <div className="mt-4 rounded-xl border border-[#D8E4DC] bg-white p-3">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
                              Kết quả OCR · cần người dùng xác nhận
                            </p>
                            <div className="flex items-center gap-2">
                              <span className="hidden text-[10px] font-bold text-[#60766D] sm:inline">
                                Không tự động thay thế bản gốc
                              </span>
                              <Button
                                type="button"
                                variant="outline"
                                className="min-h-8 border-[#B38321] bg-white px-2 text-[10px] text-[#6F5520]"
                                onClick={() => {
                                  setOcrResults(current =>
                                    Object.fromEntries(
                                      Object.entries(current).map(
                                        ([key, result]) => [
                                          key,
                                          { ...result, reviewed: true },
                                        ]
                                      )
                                    )
                                  );
                                  setOcrConfirmed(true);
                                  toast.success(
                                    "Đã xác nhận kết quả OCR để tiếp tục đối chiếu."
                                  );
                                }}
                              >
                                {ocrConfirmed
                                  ? "Đã xác nhận OCR"
                                  : "Xác nhận OCR"}
                              </Button>
                            </div>
                          </div>
                          <div className="mt-3 grid gap-3 lg:grid-cols-2">
                            {Object.values(ocrResults).flatMap(result =>
                              result.fields.map(field => (
                                <label
                                  key={`${result.fileName}-${field.key}`}
                                  className="text-xs font-black text-[#18352D]"
                                >
                                  {field.label}
                                  <Input
                                    value={field.value}
                                    onChange={event =>
                                      markOcrFieldReviewed(
                                        result.fileName,
                                        field.key,
                                        event.target.value
                                      )
                                    }
                                    className="mt-1 min-h-10 bg-[#FBFDFB] text-sm font-normal"
                                  />
                                  <span className="mt-1 block text-[10px] font-normal text-[#60766D]">
                                    {result.fileName} · tin cậy{" "}
                                    {Math.round(field.confidence * 100)}% ·{" "}
                                    {field.evidence}
                                  </span>
                                </label>
                              ))
                            )}
                          </div>
                        </div>
                      )}
                      {(createDossierMissing.length > 0 || analysisResult) && (
                        <div className="mt-4 grid gap-3 lg:grid-cols-2">
                          <div className="rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3">
                            <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#B38321]">
                              Cảnh báo / thành phần cần bổ sung
                            </p>
                            <ul className="mt-2 space-y-1 text-xs leading-5 text-[#6F5520]">
                              {(createDossierMissing.length > 0
                                ? createDossierMissing
                                : ["Chưa có cảnh báo từ AI."]
                              ).map((item, index) => (
                                <li
                                  key={`${item}-${index}`}
                                  className="flex gap-2"
                                >
                                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                                  <span>{item}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                          {analysisResult && (
                            <div className="rounded-xl border border-[#D8E4DC] bg-white p-3">
                              <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
                                Kết luận AI · chưa phải xác nhận pháp lý
                              </p>
                              <p className="mt-2 text-xs leading-5 text-[#60766D]">
                                {analysisResult.notice}
                              </p>
                              {analysisResult.legalNotes.length > 0 && (
                                <ul className="mt-2 space-y-1 text-xs leading-5 text-[#18352D]">
                                  {analysisResult.legalNotes
                                    .slice(0, 4)
                                    .map(note => (
                                      <li key={note}>• {note}</li>
                                    ))}
                                </ul>
                              )}
                              <Button
                                type="button"
                                variant="outline"
                                className="mt-3 min-h-9 border-[#1F5A4A] bg-white text-xs text-[#1F5A4A]"
                                onClick={() => {
                                  setAnalysisConfirmed(true);
                                  toast.success(
                                    "Đã ghi nhận bạn đã đối chiếu các trường AI phân tích."
                                  );
                                }}
                              >
                                {analysisConfirmed
                                  ? "Đã xác nhận dữ liệu phân tích"
                                  : "Xác nhận dữ liệu phân tích"}
                              </Button>
                            </div>
                          )}
                        </div>
                      )}
                      {createDossierPreview && (
                        <div className="mt-4 rounded-xl border border-[#D8E4DC] bg-white p-3">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-[10px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
                              Bản nháp hồ sơ
                            </p>
                            <span className="text-[10px] font-bold text-[#B38321]">
                              {submissionStatus === "ready_to_print"
                                ? "Sẵn sàng rà soát"
                                : "Bản nháp"}
                            </span>
                          </div>
                          <pre className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-[#F7FBF7] p-3 text-xs leading-5 text-[#18352D]">
                            {createDossierPreview}
                          </pre>
                          <div className="mt-3 flex flex-wrap gap-2">
                            <Button
                              type="button"
                              variant="outline"
                              className="min-h-9 border-[#1F5A4A] bg-white text-xs text-[#1F5A4A]"
                              onClick={() => void exportCreateDossier("docx")}
                              disabled={exportingFormat !== null}
                            >
                              <FileDown className="mr-1.5 h-3.5 w-3.5" />
                              {exportingFormat === "docx"
                                ? "Đang xuất DOCX..."
                                : "Xuất DOCX có xác nhận"}
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              className="min-h-9 border-[#B38321] bg-white text-xs text-[#6F5520]"
                              onClick={() => void exportCreateDossier("pdf")}
                              disabled={exportingFormat !== null}
                            >
                              <Download className="mr-1.5 h-3.5 w-3.5" />
                              {exportingFormat === "pdf"
                                ? "Đang xuất PDF..."
                                : "Xuất PDF có xác nhận"}
                            </Button>
                          </div>
                          <div className="sticky bottom-3 z-10 mt-3 flex gap-2 rounded-xl border border-[#D8E4DC] bg-white/95 p-2 shadow-lg backdrop-blur sm:hidden">
                            <Button
                              type="button"
                              className="min-h-10 flex-1 bg-[#1F5A4A] text-xs"
                              onClick={() => void saveCreateDossierDraft()}
                              disabled={createDossierSaveState === "saving"}
                            >
                              <Save className="mr-1.5 h-3.5 w-3.5" />
                              {savedCreateDossierId ? "Cập nhật" : "Lưu hồ sơ"}
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              className="min-h-10 border-[#B38321] bg-white px-3 text-xs text-[#6F5520]"
                              onClick={() => void exportCreateDossier("pdf")}
                              disabled={exportingFormat !== null}
                            >
                              <Download className="mr-1.5 h-3.5 w-3.5" />
                              PDF
                            </Button>
                          </div>
                        </div>
                      )}
                    </section>
                  )}
                </section>
              </div>
            ) : (
              <div className="mt-5 space-y-4">
                <div className="rounded-2xl border border-[#CFE2D4] bg-[#F7FBF7] p-4">
                  <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
                    <label className="flex-1 text-xs font-black text-[#18352D]">
                      BĐS của tôi
                      <select
                        value={myDossierPropertyId}
                        onChange={event => {
                          setMyDossierPropertyId(event.target.value);
                          setMyDossierPreview("");
                          setMyDossierMissing([]);
                        }}
                        className="mt-1 min-h-11 w-full rounded-xl border border-[#D8E4DC] bg-white p-3 text-sm font-bold text-[#18352D]"
                      >
                        <option value="">
                          Chọn bất động sản đã có trong hệ thống
                        </option>
                        {(properties.data || []).map(property => (
                          <option key={property.id} value={property.id}>
                            {property.title} · {property.location}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="flex-1 text-xs font-black text-[#18352D]">
                      Thủ tục cần lập
                      <select
                        value={myDossierProcedureId}
                        onChange={event => {
                          setMyDossierProcedureId(
                            event.target.value as typeof myDossierProcedureId
                          );
                          setMyDossierPreview("");
                          setMyDossierMissing([]);
                        }}
                        className="mt-1 min-h-11 w-full rounded-xl border border-[#D8E4DC] bg-white p-3 text-sm font-bold text-[#18352D]"
                      >
                        {fallbackLandProcedures.map(procedure => (
                          <option key={procedure.id} value={procedure.id}>
                            {procedure.title}
                          </option>
                        ))}
                      </select>
                    </label>
                    <Button
                      type="button"
                      onClick={prepareMyLandDossier}
                      className="bg-[#1F5A4A] hover:bg-[#164637]"
                    >
                      <Sparkles className="mr-2 h-4 w-4" />
                      Kiểm tra & dựng hồ sơ
                    </Button>
                  </div>
                  {myDossierProperty && (
                    <div className="mt-4 grid gap-3 md:grid-cols-3">
                      <div className="rounded-xl bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          BĐS đã chọn
                        </p>
                        <p className="mt-1 text-sm font-black">
                          {myDossierProperty.title}
                        </p>
                        <p className="text-xs text-[#60766D]">
                          {myDossierProperty.location}
                        </p>
                      </div>
                      <div className="rounded-xl bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          Dữ liệu đã lấy
                        </p>
                        <p className="mt-1 text-xs leading-5 text-[#60766D]">
                          Chủ sử dụng:{" "}
                          {myDossierProperty.ownerName || "Chưa có"}
                          <br />
                          Pháp lý: {myDossierProperty.legalStatus || "Chưa có"}
                          <br />
                          Diện tích:{" "}
                          {myDossierProperty.certificateArea ||
                            myDossierProperty.area ||
                            "Chưa có"}{" "}
                          m²
                        </p>
                      </div>
                      <div className="rounded-xl bg-white p-3">
                        <p className="text-[10px] font-black uppercase text-[#B38321]">
                          Kiểm tra trước khi tạo
                        </p>
                        {myDossierMissing.length ? (
                          <p className="mt-1 text-xs font-bold text-[#A14C31]">
                            Còn thiếu {myDossierMissing.length} mục:{" "}
                            {myDossierMissing.join(", ")}
                          </p>
                        ) : (
                          <p className="mt-1 text-xs font-bold text-[#1F5A4A]">
                            Chưa chạy kiểm tra
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                  {myDossierPreview && (
                    <div className="mt-4 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-4">
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <p className="text-xs font-black uppercase text-[#B38321]">
                            Bản nháp bộ hồ sơ
                          </p>
                          <p className="mt-1 text-sm font-bold text-[#18352D]">
                            {myDossierProcedure.title} ·{" "}
                            {myDossierProperty?.title}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            className="text-xs"
                            onClick={() => {
                              setTemplateDraftLabel(
                                `${myDossierProcedure.title} · bản nháp từ BĐS`
                              );
                              setTemplateText(myDossierPreview);
                            }}
                          >
                            Xem/chỉnh sửa
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className="text-xs"
                            onClick={() =>
                              void downloadDossierDocx(
                                myDossierPreview,
                                `${myDossierProcedure.title.toLowerCase().replace(/[^a-z0-9]+/gi, "-")}-bo-ho-so.docx`
                              )
                            }
                          >
                            <FileDown className="mr-1.5 h-3.5 w-3.5" />
                            Tải DOCX
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className="text-xs"
                            onClick={() =>
                              printDossierPreview(
                                myDossierPreview,
                                `${myDossierProcedure.title} · ${myDossierProperty?.title || "Hồ sơ"}`
                              )
                            }
                          >
                            <Download className="mr-1.5 h-3.5 w-3.5" />
                            In / lưu PDF
                          </Button>
                          <Button
                            type="button"
                            onClick={createMyLandDossier}
                            disabled={createLandDossierMutation.isPending}
                            className="bg-[#1F5A4A] text-xs"
                          >
                            {createLandDossierMutation.isPending
                              ? "Đang lưu..."
                              : "Lưu vào Hồ sơ của tôi"}
                          </Button>
                        </div>
                      </div>
                      <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap rounded-lg bg-white p-3 text-xs leading-5 text-[#60766D]">
                        {myDossierPreview}
                      </pre>
                      <p className="mt-3 text-[11px] leading-4 text-[#6F5520]">
                        Bản nháp chỉ hỗ trợ chuẩn bị hồ sơ. Kiểm tra, ký và đối
                        chiếu mẫu chính thức trước khi nộp.
                      </p>
                    </div>
                  )}
                </div>
                <LandProcedureGuidanceStep
                  property={myDossierProperty}
                  evidence={landEvidence}
                  onUpload={file => void handleLandDocumentUpload(file)}
                  onDelete={name => {
                    setLandEvidence(current =>
                      current.filter(item => item.name !== name)
                    );
                    toast.success(`Đã xóa ${name} khỏi phiên làm việc.`);
                  }}
                  onBuildBundle={(procedureId, bundle) => {
                    setMyDossierProcedureId(
                      (procedureId === "purpose-change"
                        ? "purpose"
                        : procedureId === "split-merge"
                          ? "split"
                          : procedureId) as typeof myDossierProcedureId
                    );
                    const bundleText = bundle
                      .map(
                        (item, index) =>
                          `${index + 1}. ${item.label}${item.required ? " · Cần chuẩn bị" : " · Tài liệu liên quan"}${item.condition ? ` · ${item.condition}` : ""}`
                      )
                      .join("\n");
                    setMyDossierPreview(
                      `${aiDossierUniversalPreviewSample(procedureId)}\n\nDANH SÁCH TÀI LIỆU TRONG BỘ HỒ SƠ\n${bundleText}\n\nTRẠNG THÁI: BẢN NHÁP HỖ TRỢ · CẦN ĐỐI CHIẾU MẪU GỐC, MÃ THỦ TỤC VÀ ĐỊA PHƯƠNG TRƯỚC KHI KÝ/NỘP.`
                    );
                    toast.success(
                      `Đã dựng bộ hồ sơ gồm ${bundle.length} tài liệu để xem, chỉnh sửa và tải xuống.`
                    );
                  }}
                />
                {(landDossiers.data || []).map(item => (
                  <div
                    key={item.id}
                    className="rounded-xl border border-[#D8E4DC] bg-white p-4"
                  >
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="text-xs font-black uppercase tracking-wide text-[#B38321]">
                          {item.dossierCode} · {item.procedureType}
                        </p>
                        <h3 className="mt-1 font-black text-[#18352D]">
                          {item.title}
                        </h3>
                        <p className="mt-1 text-xs text-[#60766D]">
                          Bước {item.currentStep}/6 ·{" "}
                          {item.status === "completed"
                            ? "Hoàn tất"
                            : item.status === "cancelled"
                              ? "Đã hủy"
                              : item.status === "paused"
                                ? "Tạm dừng"
                                : "Đang xử lý"}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-28 overflow-hidden rounded-full bg-[#E4ECE6]">
                          <div
                            className="h-full rounded-full bg-[#D8B15A]"
                            style={{
                              width: `${Math.min(100, Math.round((item.currentStep / 6) * 100))}%`,
                            }}
                          />
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          className="text-xs"
                          disabled={
                            item.status === "cancelled" ||
                            item.status === "completed" ||
                            updateLandDossierMutation.isPending
                          }
                          onClick={() =>
                            updateLandDossierMutation.mutate({
                              id: item.id,
                              currentStep: Math.min(6, item.currentStep + 1),
                              status:
                                item.currentStep >= 6
                                  ? "completed"
                                  : "in_progress",
                            })
                          }
                        >
                          {item.currentStep >= 6
                            ? "Đã đủ bước"
                            : "Đánh dấu bước tiếp"}
                        </Button>
                        {item.status !== "cancelled" &&
                          item.status !== "completed" && (
                            <Button
                              type="button"
                              variant="outline"
                              className="text-xs text-[#A14C31]"
                              disabled={cancelLandDossierMutation.isPending}
                              onClick={() => {
                                if (
                                  window.confirm(
                                    `Hủy hồ sơ ${item.dossierCode}? Hồ sơ sẽ được giữ lại để xem lịch sử.`
                                  )
                                )
                                  cancelLandDossierMutation.mutate({
                                    id: item.id,
                                    reason: "Người dùng chủ động hủy hồ sơ.",
                                  });
                              }}
                            >
                              <X className="mr-1 h-3 w-3" />
                              Hủy
                            </Button>
                          )}
                        <Button
                          type="button"
                          variant="outline"
                          className="text-xs text-[#A14C31]"
                          disabled={deleteLandDossierMutation.isPending}
                          onClick={() => {
                            if (
                              window.confirm(
                                `Xóa hồ sơ ${item.dossierCode}? Thao tác này không thể hoàn tác.`
                              )
                            )
                              deleteLandDossierMutation.mutate({ id: item.id });
                          }}
                        >
                          <Trash2 className="mr-1 h-3 w-3" />
                          Xóa
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {!landDossiers.data?.length && (
                  <div className="rounded-xl border border-dashed border-[#BFD2C5] p-8 text-center text-sm text-[#60766D]">
                    Chưa có hồ sơ đất đai nào. Hãy chọn “Tạo hồ sơ mới” để bắt
                    đầu.
                  </div>
                )}
              </div>
            )}
          </section>
          <section id="ai-chuyen-trach-dat-dai" className="scroll-mt-6">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#EAF2ED] px-3 py-1.5 text-[11px] font-black uppercase tracking-[0.14em] text-[#1F5A4A]">
              <ShieldCheck className="h-3.5 w-3.5" />
              AI chuyên trách đất đai · workflow hồ sơ chuyên sâu
            </div>
            <CertificateAiWorkspace />
          </section>
          <section className="mt-5 rounded-2xl border border-[#D8E4DC] bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">
                  Kho hồ sơ thông minh
                </p>
                <h2 className="mt-1 text-2xl font-black text-[#18352D]">
                  Hồ sơ AI · toàn bộ nguồn hàng
                </h2>
                <p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">
                  Một nơi để tìm hồ sơ khách hàng, chủ nhà, BĐS, pháp lý, thuế,
                  giao dịch, công chứng, môi giới và đất đai. Bạn có thể gõ{" "}
                  <strong>“Hồ sơ chuyển nhượng đất”</strong> để lọc nhanh tài
                  liệu liên quan.
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2 rounded-xl bg-[#F4F8F4] px-3 py-2 text-sm font-bold text-[#1F5A4A]">
                <FileSearch className="h-4 w-4" />
                {dossierHubRecords.length} kết quả
              </div>
            </div>
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-[#60766D]" />
                <Input
                  value={hubSearch}
                  onChange={e => setHubSearch(e.target.value)}
                  placeholder="Ví dụ: Hồ sơ chuyển nhượng đất, khách Sơn Trà, sổ đỏ..."
                  className="pl-9"
                  aria-label="Tìm kiếm toàn bộ hồ sơ AI"
                />
              </div>
              <Button
                type="button"
                onClick={() => askLegal(hubSearch)}
                disabled={research.isPending || hubSearch.trim().length < 8}
                className="bg-[#1F5A4A] hover:bg-[#164637]"
              >
                <Sparkles className="mr-2 h-4 w-4" />
                {research.isPending ? "AI đang tìm..." : "AI phân tích"}
              </Button>
            </div>
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {hubCategories.map(item => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setHubCategory(item)}
                  className={`whitespace-nowrap rounded-full px-3 py-2 text-xs font-bold transition-colors ${hubCategory === item ? "bg-[#1F5A4A] text-white" : "bg-[#EEF5F0] text-[#1F5A4A] hover:bg-[#DCEBE0]"}`}
                >
                  {item === "all" ? "Tất cả" : item}
                </button>
              ))}
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {dossierHubRecords.slice(0, 9).map(record => (
                <article
                  key={record.id}
                  className="rounded-xl border border-[#E4ECE6] bg-[#FCFEFC] p-4"
                >
                  <div className="flex items-start gap-3">
                    <span className="rounded-xl bg-[#EAF2ED] p-3 text-[#1F5A4A]">
                      {hubIcon(record.icon)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-[10px] font-black uppercase tracking-wide text-[#B38321]">
                          {record.category}
                        </span>
                        <span className="rounded-full bg-[#F4F8F4] px-2 py-1 text-[10px] font-bold text-[#60766D]">
                          {record.status}
                        </span>
                      </div>
                      <h3 className="mt-1 truncate font-black text-[#18352D]">
                        {record.title}
                      </h3>
                      <p className="mt-1 line-clamp-2 text-xs leading-5 text-[#60766D]">
                        {record.subtitle}
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      className="h-8 flex-1 text-xs"
                      onClick={() => openHubRecord(record)}
                    >
                      Mở hồ sơ
                    </Button>
                    {record.id.startsWith("archive-") && (
                      <a
                        href={
                          (allArchives.data || []).find(
                            item => `archive-${item.file.id}` === record.id
                          )?.file.url
                        }
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex h-8 items-center rounded-md bg-[#EAF2ED] px-3 text-xs font-bold text-[#1F5A4A]"
                      >
                        Tải file
                      </a>
                    )}
                  </div>
                </article>
              ))}
            </div>
            {!dossierHubRecords.length && (
              <div className="mt-4 rounded-xl bg-[#FFF9EA] p-5 text-center text-sm text-[#6F5520]">
                Chưa có kết quả phù hợp. Hãy thử “chuyển nhượng”, “đất”, “sổ
                đỏ”, tên khách hàng hoặc mã BĐS.
              </div>
            )}
            <p className="mt-4 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3 text-xs leading-5 text-[#6F5520]">
              <strong>Lưu ý pháp lý:</strong> AI chỉ tìm, phân loại và tóm tắt
              tài liệu đang có trong hệ thống. Kết quả không thay thế văn bản
              chính thức, luật sư, công chứng viên hoặc cơ quan tiếp nhận; cần
              kiểm tra bản gốc và thời điểm hiệu lực trước khi giao dịch.
            </p>
          </section>
          <section className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.25fr)_minmax(360px,.75fr)]">
            <div className="space-y-5"></div>
            <aside className="space-y-5">
              <section className="rounded-2xl border border-[#D8E4DC] bg-white p-5 shadow-sm">
                <div className="flex items-start gap-3">
                  <Sparkles className="mt-1 h-5 w-5 text-[#B38321]" />
                  <div>
                    <h2 className="text-xl font-black">AI tra cứu pháp lý</h2>
                    <p className="mt-1 text-sm leading-6 text-[#60766D]">
                      Đặt câu hỏi theo loại giao dịch đang chọn.
                    </p>
                  </div>
                </div>
                <Textarea
                  value={legalQuestion}
                  onChange={e => setLegalQuestion(e.target.value)}
                  className="mt-4 min-h-28"
                  placeholder="Ví dụ: Hồ sơ chuyển nhượng đất cần kiểm tra gì?"
                />
                <Button
                  type="button"
                  onClick={() => askLegal()}
                  disabled={research.isPending}
                  className="mt-3 w-full bg-[#1F5A4A] hover:bg-[#164637]"
                >
                  <Search className="mr-2 h-4 w-4" />
                  Tìm và giải thích
                </Button>
                {legalAnswer && (
                  <div className="mt-4 rounded-xl bg-[#F4F8F4] p-4 text-sm leading-6">
                    <p className="whitespace-pre-wrap">{legalAnswer.answer}</p>
                    <p className="mt-3 border-t border-[#D8E4DC] pt-3 text-xs text-[#60766D]">
                      AI chỉ hỗ trợ tra cứu và tóm tắt. Cần kiểm tra văn bản
                      chính thức, thời điểm hiệu lực và hỏi chuyên viên pháp lý
                      trước khi ký hoặc giao dịch.
                    </p>
                  </div>
                )}
              </section>
            </aside>
          </section>
          <section className="mt-5 rounded-2xl border border-[#D8E4DC] bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-[#B38321]">
                  Kho biểu mẫu theo Cổng DVC
                </p>
                <h2 className="mt-1 text-2xl font-black text-[#18352D]">
                  Mẫu đất đai · thuế · phí · hồ sơ liên quan
                </h2>
                <p className="mt-1 max-w-3xl text-sm leading-6 text-[#60766D]">
                  Chọn thủ tục để xem nguồn, mở mẫu tham khảo, tải mẫu từ đường
                  dẫn công bố hoặc dùng mẫu làm khung tạo hồ sơ. Trạng thái
                  nguồn được hiển thị riêng, không mặc định đồng nghĩa với mẫu
                  Official.
                </p>
              </div>
              <div className="rounded-xl bg-[#F4F8F4] px-3 py-2 text-xs font-black text-[#1F5A4A]">
                {filteredTemplates.length} tài liệu phù hợp
              </div>
            </div>
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-[#60766D]" />
                <Input
                  value={templateSearch}
                  onChange={e => setTemplateSearch(e.target.value)}
                  placeholder="Tìm Mẫu 09/ĐK, thuế, lệ phí trước bạ, chuyển nhượng..."
                  className="pl-9"
                  aria-label="Tìm biểu mẫu đất đai thuế phí"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                onClick={() => setTemplateSearch("")}
              >
                Xóa tìm kiếm
              </Button>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {filteredTemplates.map(template => {
                const source = getOfficialSource(template.id);
                return (
                  <article
                    key={template.id}
                    className="rounded-xl border border-[#E4ECE6] bg-[#FCFEFC] p-4"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="rounded-full bg-[#EAF2ED] px-2 py-1 text-[10px] font-black uppercase tracking-wide text-[#1F5A4A]">
                        {template.group}
                      </span>
                      <span
                        className={`rounded-full px-2 py-1 text-[10px] font-black ${officialStatusClass(source?.status)}`}
                      >
                        {source
                          ? officialStatusLabel(source.status)
                          : "Bản tham khảo nội bộ"}
                      </span>
                    </div>
                    <h3 className="mt-3 font-black leading-5 text-[#18352D]">
                      {template.title}
                    </h3>
                    <p className="mt-1 line-clamp-3 text-xs leading-5 text-[#60766D]">
                      {template.content.replace(/\\n/g, " ")}
                    </p>
                    <div className="mt-3 space-y-1 text-[11px] leading-4 text-[#60766D]">
                      <p>
                        <strong>Cơ quan:</strong> {template.authority}
                      </p>
                      <p>
                        <strong>Căn cứ:</strong> {template.basis}
                      </p>
                      {source && (
                        <p>
                          <strong>Kiểm tra:</strong> {source.lastCheckedAt} ·{" "}
                          {source.version}
                        </p>
                      )}
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        className="h-8 text-xs"
                        onClick={() => openProcedureTemplate(template)}
                      >
                        <FileText className="mr-1 h-3.5 w-3.5" />
                        Xem mẫu
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        className="h-8 text-xs"
                        onClick={() => downloadTemplate(template)}
                      >
                        <FileDown className="mr-1 h-3.5 w-3.5" />
                        DOCX
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        className="h-8 text-xs"
                        onClick={() => downloadTemplatePdf(template)}
                      >
                        <Download className="mr-1 h-3.5 w-3.5" />
                        PDF
                      </Button>
                      {source && (
                        <a
                          href={source.sourceUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex h-8 items-center rounded-md border border-[#C9D8D0] px-3 text-xs font-bold text-[#1F5A4A] hover:bg-[#EEF5F0]"
                        >
                          <ExternalLink className="mr-1 h-3.5 w-3.5" />
                          Mở nguồn
                        </a>
                      )}
                      <Button
                        type="button"
                        className="h-8 bg-[#1F5A4A] text-xs hover:bg-[#164637]"
                        onClick={() => {
                          const builderProcedure =
                            template.transactionType === "transfer_land"
                              ? "transfer"
                              : fallbackLandProcedures.find(
                                  item =>
                                    item.transactionType ===
                                    template.transactionType
                                )?.id || "variation";
                          window.location.assign(
                            `/ai-lap-ho-so-dat-dai?procedure=${builderProcedure}`
                          );
                        }}
                      >
                        <Sparkles className="mr-1 h-3.5 w-3.5" />
                        Dùng mẫu tạo hồ sơ
                      </Button>
                    </div>
                  </article>
                );
              })}
            </div>
            {!filteredTemplates.length && (
              <div className="mt-4 rounded-xl bg-[#FFF9EA] p-5 text-center text-sm text-[#6F5520]">
                Chưa tìm thấy biểu mẫu phù hợp. Hãy thử “biến động”, “Mẫu 09”,
                “thuế” hoặc “lệ phí”.
              </div>
            )}
            <p className="mt-4 rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-3 text-xs leading-5 text-[#6F5520]">
              <strong>Trạng thái file:</strong> Nguồn “Mở cổng tra cứu” hoặc
              “Cần rà soát” chỉ cung cấp đường dẫn/metadata. Khi file gốc chưa
              tải hoặc chưa xác minh, hệ thống chỉ dùng bản nháp hỗ trợ và yêu
              cầu đối chiếu trước khi ký nộp.
            </p>
          </section>
          \n{" "}
          {templateText && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
              onClick={() => setTemplateText("")}
            >
              <div
                className="w-full max-w-2xl rounded-2xl bg-white p-5 shadow-2xl"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-black">{templateDraftLabel}</h2>
                  <button
                    type="button"
                    onClick={() => setTemplateText("")}
                    className="rounded-lg p-2 hover:bg-[#EEF5F0]"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <Textarea
                  value={templateText}
                  onChange={e => setTemplateText(e.target.value)}
                  className="mt-4 min-h-[420px] font-mono text-sm"
                />
                <div className="mt-4 flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() =>
                      void downloadDossierDocx(
                        templateText,
                        `${templateDraftLabel.toLowerCase().replace(/[^a-z0-9]+/gi, "-")}.docx`
                      )
                    }
                  >
                    <FileDown className="mr-2 h-4 w-4" />
                    Tải DOCX
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() =>
                      void downloadDossierPdf(
                        templateText,
                        `${templateDraftLabel.toLowerCase().replace(/[^a-z0-9]+/gi, "-")}.pdf`,
                        templateDraftLabel
                      )
                    }
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Tải PDF
                  </Button>
                  <Button
                    type="button"
                    onClick={() => setTemplateText("")}
                    className="bg-[#1F5A4A]"
                  >
                    Đóng
                  </Button>
                </div>
              </div>
            </div>
          )}
          {syncPreview && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
              onClick={() => setSyncPreview(null)}
            >
              <div
                className="w-full max-w-2xl rounded-2xl bg-white p-5 shadow-2xl"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-black uppercase tracking-wide text-[#B38321]">
                      Đề xuất đồng bộ nguồn chính thức
                    </p>
                    <h2 className="mt-1 text-xl font-black text-[#18352D]">
                      {syncPreview.template.title}
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSyncPreview(null)}
                    className="rounded-lg p-2 hover:bg-[#EEF5F0]"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="mt-4 grid gap-3 text-sm">
                  <div className="rounded-xl bg-[#F4F8F4] p-4">
                    <p>
                      <strong>Nguồn:</strong> {syncPreview.source.sourceName}
                    </p>
                    <p>
                      <strong>Phiên bản công bố:</strong>{" "}
                      {syncPreview.source.version}
                    </p>
                    <p>
                      <strong>Ngày kiểm tra gần nhất:</strong>{" "}
                      {syncPreview.source.lastCheckedAt}
                    </p>
                    <p>
                      <strong>Trạng thái:</strong>{" "}
                      {officialStatusLabel(syncPreview.source.status)}
                    </p>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="rounded-xl border border-[#E4ECE6] p-4">
                      <p className="mb-2 font-black text-[#1F5A4A]">
                        Phiên bản nội bộ hiện tại
                      </p>
                      <pre className="max-h-48 overflow-auto whitespace-pre-wrap text-xs leading-5 text-[#60766D]">
                        {syncPreview.template.content}
                      </pre>
                    </div>
                    <div className="rounded-xl border border-[#F0D9A4] bg-[#FFF9EA] p-4">
                      <p className="mb-2 font-black text-[#6F5520]">
                        Kết quả cần quản trị viên xác minh
                      </p>
                      <p className="text-xs leading-5 text-[#6F5520]">
                        Ứng dụng đã mở được nguồn tra cứu chính thức và ghi nhận
                        metadata. Nội dung file trên cổng có thể thay đổi hoặc
                        yêu cầu chọn địa phương; hệ thống không tự động ghi đè
                        mẫu hiện tại. Chỉ phê duyệt sau khi tải/đối chiếu bản
                        chính thức và ghi nhận thay đổi.
                      </p>
                      <a
                        href={syncPreview.source.sourceUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-[#1F5A4A] underline"
                      >
                        <ExternalLink className="h-3 w-3" />
                        Mở nguồn để đối chiếu
                      </a>
                    </div>
                  </div>
                </div>
                <div className="mt-5 flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setSyncPreview(null)}
                  >
                    Giữ bản hiện tại
                  </Button>
                  <Button
                    type="button"
                    onClick={() =>
                      approveOfficialUpdate(syncPreview.template.id)
                    }
                    className="bg-[#1F5A4A] hover:bg-[#164637]"
                  >
                    Phê duyệt đề xuất
                  </Button>
                </div>
              </div>
            </div>
          )}
          {preview && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
              onClick={() => setPreview(null)}
            >
              <div
                className="max-h-[90vh] max-w-5xl overflow-auto rounded-2xl bg-white p-4"
                onClick={e => e.stopPropagation()}
              >
                <div className="mb-3 flex items-center justify-between gap-4">
                  <p className="font-bold">{preview.name}</p>
                  <button
                    type="button"
                    onClick={() => setPreview(null)}
                    className="rounded-lg bg-[#18352D] px-3 py-2 text-sm text-white"
                  >
                    Đóng
                  </button>
                </div>
                {preview.mime.startsWith("image/") ? (
                  <img
                    src={preview.url}
                    alt={preview.name}
                    className="max-h-[75vh] object-contain"
                  />
                ) : preview.mime.startsWith("video/") ? (
                  <video src={preview.url} controls className="max-h-[75vh]" />
                ) : (
                  <iframe
                    src={preview.url}
                    title={preview.name}
                    className="h-[70vh] w-[80vw]"
                  />
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </DashboardLayout>
  );
}

type LandAnswerMap = {
  seller: string;
  buyer: string;
  parcel: string;
  certificate: string;
  marital: string;
  mortgage: string;
  location: string;
};

export function aiDossierUniversalWorkflowTitles() {
  return universalWorkflowSteps.map(step => step.title);
}
export function aiDossierProcedureRequirements(procedureId: string) {
  return getUniversalRequirements(procedureId);
}
export function aiDossierUniversalPreviewSample(procedureId: string) {
  return (
    getUniversalRequirements(procedureId).join("\\n") +
    "\\nMỤC LỤC\\n6. Xuất hồ sơ"
  );
}

export function aiDossierAutofillTemplate(
  templateTitle: string,
  content: string,
  answers: LandAnswerMap
) {
  const fields: Array<[string, string]> = [
    ["Khu vực / cơ quan tiếp nhận", answers.location],
    ["Thông tin thửa đất", answers.parcel],
    ["Chủ sử dụng đất / người đề nghị", answers.seller],
    ["Người nhận quyền (nếu có)", answers.buyer],
    ["Giấy chứng nhận", answers.certificate],
    ["Tình trạng hôn nhân", answers.marital],
    ["Thế chấp / đồng sở hữu / ủy quyền", answers.mortgage],
  ];
  const filled = fields
    .map(
      ([label, value]) =>
        `${label}: ${value.trim() || "[CHƯA NHẬP — CẦN BỔ SUNG]"}`
    )
    .join("\\n");
  return `BẢN NHÁP TỰ ĐỘNG ĐIỀN — ${templateTitle}\\n\\nDữ liệu lấy từ thông tin người dùng nhập trong Hồ sơ đất đai AI.\\n${filled}\\n\\n--- MẪU THAM KHẢO ---\\n${content}\\n\\n[KIỂM TRA TRƯỚC KHI TẢI/NỘP] Đối chiếu thông tin với giấy tờ bản gốc, mẫu đang có hiệu lực và yêu cầu của cơ quan tiếp nhận.`;
}

export function aiDossierTemplateNames() {
  return [
    "Phiếu khảo sát BĐS",
    "Phiếu kiểm tra quy hoạch",
    "Quy trình đặt cọc – sang tên",
  ] as const;
}
export function aiDossierManualBrokerTemplate() {
  return { ...manualBrokerTemplate };
}
export function aiDossierOfficialSource(templateId: string) {
  return getOfficialSource(templateId);
}
export function aiDossierLandProcedureTitles() {
  return fallbackLandProcedures.map(item => item.title);
}
export function aiDossierLegalTemplateTitles(query = "") {
  return legalTemplates
    .filter(item =>
      matchesNaturalQuery(
        [
          item.title,
          item.group,
          item.authority,
          item.basis,
          ...item.keywords,
        ].join(" "),
        query
      )
    )
    .map(item => item.title);
}
export function aiDossierProcedureTemplates(procedureId: string) {
  const procedure =
    fallbackLandProcedures.find(item => item.id === procedureId) ||
    fallbackLandProcedures[0];
  return getProcedureTemplates(procedure, legalTemplates).map(
    item => item.title
  );
}
export function aiDossierChecklistTemplateMapping(
  procedureId: string,
  documents: string[]
) {
  return documents.map(document => ({
    document,
    ...matchOfficialTemplateForRequirement(procedureId, document),
  }));
}
export function aiDossierOfficialTemplateMetadata(procedureId: string) {
  const procedure =
    fallbackLandProcedures.find(item => item.id === procedureId) ||
    fallbackLandProcedures[0];
  return getProcedureTemplates(procedure, legalTemplates).map(item => ({
    id: item.id,
    title: item.title,
    officialFileName: item.officialFileName || null,
    officialFormStatus: item.officialFormStatus || null,
    officialFileUrl: item.officialFileUrl || null,
  }));
}
export function aiDossierOfficialSourceIds() {
  return Object.keys(officialSources);
}
export function aiDossierAcceptsCamera() {
  return true;
}
export function aiDossierFileActions() {
  return ["Xem file", "Tải về", "Xóa"] as const;
}
export function aiDossierTransactionTypes() {
  return transactionTypes.map(item => item[0]);
}
export function aiDossierArchiveCategory(category: string) {
  return category === "legal"
    ? "Pháp lý"
    : category === "transaction"
      ? "Giao dịch"
      : category === "valuation"
        ? "Thuế / định giá"
        : category === "marketing"
          ? "Môi giới"
          : "Hồ sơ BĐS";
}
export function aiDossierNaturalSearch(text: string, query: string) {
  const haystack = normalizeSearchText(text);
  const terms = normalizeSearchText(query)
    .split(/\s+/)
    .filter(term => term.length >= 3);
  return terms.length === 0 || terms.some(term => haystack.includes(term));
}
export function aiDossierLegalDisclaimer() {
  return "AI chỉ hỗ trợ tìm kiếm, phân loại và tóm tắt; không thay thế văn bản chính thức, luật sư, công chứng viên hoặc cơ quan nhà nước.";
}
export function aiDossierAiAssistKinds() {
  return ["required", "conditional", "verify"] as const;
}
export function aiDossierExportFormats() {
  return {
    preferred: "DOCX",
    available: ["DOCX", "PDF"] as const,
    legacyHtmlDocRemoved: true,
    officialLabelRequiresVerifiedBinary: true,
  };
}

export function aiDossierLegalVerificationNextStep() {
  return {
    step: 5,
    label: "Bước 5–8 · AI kiểm tra và dựng bộ hồ sơ",
    actionLabel: "Xác minh & phân tích tiếp",
  } as const;
}

export function aiDossierAnalysisStatus(input: {
  filesCount: number;
  ocrStatus: "idle" | "processing" | "ready";
  confirmed: boolean;
  aiCheck: "idle" | "checking" | "done";
}) {
  if (input.aiCheck === "checking")
    return {
      title: "AI đang kiểm tra hồ sơ",
      detail:
        "Hệ thống đang đối chiếu dữ liệu đã xác nhận với danh mục giấy tờ của thủ tục. Không cần bấm lại.",
      nextAction: "Chờ AI hoàn tất",
    };
  if (input.aiCheck === "done")
    return {
      title: "AI đã kiểm tra xong",
      detail:
        "Bộ hồ sơ đã được dựng; hãy mở phần rà soát để kiểm tra tài liệu còn thiếu.",
      nextAction: "Rà soát và đối chiếu bản gốc",
    };
  if (input.filesCount === 0)
    return {
      title: "Chưa thể phân tích vì chưa có giấy tờ",
      detail:
        "Hãy bấm “Tải giấy tờ” hoặc “Chụp/tải ảnh”. AI chỉ bắt đầu sau khi có ít nhất một tệp.",
      nextAction: "Tải hoặc chụp giấy tờ",
    };
  if (input.ocrStatus === "processing")
    return {
      title: "OCR đang đọc giấy tờ",
      detail:
        "AI chưa bị treo. Hệ thống đang trích xuất thông tin từ tệp; sau đó bạn cần kiểm tra kết quả.",
      nextAction: "Chờ OCR hoàn tất",
    };
  if (input.ocrStatus === "ready" && !input.confirmed)
    return {
      title: "Đang chờ bạn xác nhận OCR",
      detail:
        "Kiểm tra các trường AI đã nhận diện, chỉnh sửa nếu cần rồi bấm “Xác nhận kết quả OCR và tự điền”.",
      nextAction: "Kiểm tra và xác nhận OCR",
    };
  return {
    title: "Sẵn sàng phân tích",
    detail:
      "Dữ liệu OCR đã được xác nhận. Bạn có thể bắt đầu dựng bộ hồ sơ theo thủ tục đã chọn.",
    nextAction: "Bấm AI phân tích và dựng bộ hồ sơ",
  };
}

export function aiDossierEvidenceStatusLabel(
  status: "uploaded" | "ocr" | "analysis" | "review" | "error"
) {
  return status === "review"
    ? "Hoàn tất AI/OCR · cần đối chiếu bản gốc"
    : status === "ocr"
      ? "OCR đang đọc giấy tờ"
      : status === "analysis"
        ? "AI đang phân tích hồ sơ"
        : status === "error"
          ? "Lỗi xử lý, cần thử lại"
          : "Đang tải lên";
}
export function aiDossierSubmissionStatusLabel(
  status: "draft" | "ready_to_print" | "signed" | "submitted"
) {
  return status === "ready_to_print"
    ? "Sẵn sàng in"
    : status === "signed"
      ? "Đã ký"
      : status === "submitted"
        ? "Đã chuẩn bị nộp"
        : "Bản nháp";
}
