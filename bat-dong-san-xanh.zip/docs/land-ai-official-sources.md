# Nguồn chính thức cho đồng bộ mẫu HS ĐẤT ĐAI AI

Cập nhật nghiên cứu: 2026-08-16.

Các nguồn cần ưu tiên khi xây dựng bộ đồng bộ mẫu:

1. Cổng Dịch vụ công Quốc gia — Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
2. Cổng Dịch vụ công Quốc gia — Cấp đổi Giấy chứng nhận quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783
3. Cổng Dịch vụ công Quốc gia — Đăng ký biến động quyền sử dụng đất, quyền sở hữu tài sản gắn liền với đất: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410
4. Cổng Dịch vụ công Quốc gia — Cung cấp thông tin, dữ liệu đất đai: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
5. Cổng Dịch vụ công Bộ Tài nguyên và Môi trường — Cung cấp thông tin, dữ liệu đất đai: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67
6. Cổng Dịch vụ công Bộ Tài nguyên và Môi trường — Tra cứu dịch vụ công: https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx

Thiết kế an toàn: hệ thống nên lưu sourceUrl, sourceName, issuingAgency, legalBasis, effectiveDate, lastCheckedAt, version và status. Không tự động ghi đè mẫu đang được sử dụng. Phiên bản mới cần hiển thị phần thay đổi và chờ người quản trị phê duyệt. Các biểu mẫu pháp lý phải được đối chiếu với nguồn chính thức/cơ quan tiếp nhận hoặc chuyên gia pháp lý trước khi dùng cho giao dịch thật.

## Dữ kiện đã xác minh ngày 16/08/2026

- Cổng Dịch vụ công Quốc gia, thủ tục đăng ký đất đai/cấp Giấy chứng nhận lần đầu (`1.013978`) có phần thành phần hồ sơ và liên kết tải mẫu `Mus15DK.docx`.
- Cổng Dịch vụ công Quốc gia, thủ tục đăng ký biến động (`2.000410`) có mẫu `Mau so 09-DK.pdf` và mô tả các trường hợp chuyển nhượng, cho thuê, thừa kế, tặng cho.
- Cổng Dịch vụ công Bộ Nông nghiệp và Môi trường, dịch vụ cung cấp thông tin dữ liệu đất đai (`dv=67`) hiển thị phương thức nộp trực tuyến, căn cứ Luật Đất đai 31/2024/QH15 và Nghị định 101/2024/NĐ-CP.
- Trang tra cứu dịch vụ công của Bộ hiển thị `2.002317 — Cung cấp thông tin, dữ liệu đất đai` ở mức độ toàn trình.

Các URL này chỉ được dùng làm liên kết nguồn/tra cứu trong ứng dụng. Không tự động tải hoặc ghi đè mẫu nội bộ; người quản trị phải đối chiếu phiên bản và phê duyệt trước khi thay thế.
