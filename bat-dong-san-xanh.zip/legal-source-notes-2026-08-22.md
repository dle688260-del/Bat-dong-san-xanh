# Ghi chú nguồn pháp lý — 2026-08-22

Kết quả tìm kiếm cho “Trích đo địa chính”:

- Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978 — trang thủ tục đăng ký đất đai; mô tả có trường hợp UBND cấp xã tổ chức trích lục bản đồ địa chính.
- Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/phananhkiennghi/pakn-detail.html?id=3F5C1558FAE54B46E063550AA8C07DD9 — kiến nghị về việc ban hành riêng thủ tục trích đo địa chính thửa đất/khu đất; kết quả tìm kiếm không cung cấp mã thủ tục riêng.
- Cổng DVC Quốc gia: https://dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.009312&id_tinh_thanh=13453 — kết quả có mã 1.009312 nhưng cần mở trang và đối chiếu tên thủ tục trước khi gán.
- Báo Điện tử Chính phủ: https://baochinhphu.vn/tham-quyen-thuc-hien-trich-do-dia-chinh-thua-dat-102250520111355701.htm — bài ngày 2025-05-21 về thẩm quyền trích đo địa chính; dùng để đối chiếu thẩm quyền, không phải mẫu Official.

Không được tự gán mã 1.009312 cho “Trích đo địa chính” nếu chưa xác minh tên trên DVC.

## Tra cứu bổ sung về Quyết định 2304/QĐ-BNNMT
- Nguồn Bộ Nông nghiệp và Môi trường: https://mae.gov.vn/bo-nong-nghiep-va-moi-truong-cong-bo-thu-tuc-hanh-chinh-linh-vuc-at-ai-18780.htm
- Nguồn tra cứu văn bản: https://luatvietnam.vn/tai-nguyen/quyet-dinh-2304-qd-bnnmt-2025-cong-bo-thu-tuc-hanh-chinh-linh-vuc-dat-dai-thuoc-quan-ly-cua-bo-nong-nghiep-va-moi-truong-403869-d1.html
- Nguồn toàn văn tham khảo: https://thuvienphapluat.vn/phap-luat/ho-tro-phap-luat/toan-van-quyet-dinh-2304qdbnnmt-thu-tuc-hanh-chinh-ve-dat-dai-tu-172025-thuoc-pham-vi-qua-223339.html
- Các nguồn công bố danh mục thủ tục theo Quyết định 2304; cần trích xuất và đối chiếu tên/mã từ phụ lục hoặc trang chi tiết trước khi ghi thành procedure trong database. Không coi chỉ mục mã là đã có đủ tên, quy trình, thành phần hoặc Official binary.
