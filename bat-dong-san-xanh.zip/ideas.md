# Định hướng thiết kế — Bất động sản xanh

## Ba hướng thẩm mỹ ban đầu

### Hướng 1 — Sơn Trà Tĩnh Lặng
**Giới thiệu rất ngắn:** Một ngôn ngữ thị giác lấy cảm hứng từ đường bờ biển, cây xanh và kiến trúc nhiệt đới Đà Nẵng; tạo cảm giác đáng tin, thư thái và có chiều sâu địa phương.

**Xác suất:** 0.07

### Hướng 2 — Hồ Sơ Đầu Tư
**Giới thiệu rất ngắn:** Phong cách biên tập cao cấp với nền trắng ấm, chữ serif sắc nét và các khối thông tin như một hồ sơ tư vấn đầu tư được tuyển chọn.

**Xác suất:** 0.03

### Hướng 3 — Địa Hình Phát Triển
**Giới thiệu rất ngắn:** Giao diện giàu bản đồ, đường contour và màu khoáng vật, nhấn mạnh năng lực am hiểu địa bàn và khả năng kết nối nhiều tỉnh lân cận.

**Xác suất:** 0.09

## Hướng được chọn: Sơn Trà Tĩnh Lặng

### Design Movement
Biophilic editorial design — kết hợp chủ nghĩa tối giản biophilic với bố cục tạp chí địa phương đương đại, để bất động sản được kể như một phần của lối sống và cảnh quan.

### Core Principles
1. **Địa phương trước, bán hàng sau:** Đà Nẵng và miền Trung xuất hiện qua ánh sáng, địa hình, chất liệu và nhịp điệu bố cục.
2. **Tin cậy bằng khoảng thở:** Không dồn dập banner hay thẻ bo tròn đồng loạt; nội dung được phân cấp rõ và có không gian để người xem suy nghĩ.
3. **Tự nhiên nhưng có cấu trúc:** Màu xanh rừng, cát biển và mực than đi cùng đường nét bản đồ, khung ảnh và chi tiết đo đạc tinh tế.
4. **Chuyển đổi nhẹ nhàng:** CTA mời tư vấn rõ ràng, không gây áp lực; mọi tương tác đều hướng người dùng đến cuộc trò chuyện phù hợp.

### Color Philosophy
Màu xanh lá thông là màu thương hiệu độc quyền, đại diện cho sự bền vững và năng lực đồng hành lâu dài. Màu cát ấm làm nền để giao diện không lạnh như một cổng đăng tin, còn màu xanh biển nhạt tạo nhịp thở của Đà Nẵng. Màu mực than dùng cho chữ chính để giữ cảm giác tư vấn chuyên nghiệp, không dùng gradient tím hoặc neon.

### Layout Paradigm
Bố cục lệch trục theo kiểu tạp chí: phần hero chia thành cột nội dung hẹp và ảnh địa hình lớn; các khu vực bất động sản chạy theo nhịp ngang; khối tư vấn chuyên viên đặt như một “mốc tin cậy” bên cạnh form. Trên mobile, các trục được xếp thành dòng đọc dọc tự nhiên, giữ lại những đường kẻ và nhãn nhỏ để không mất chất biên tập.

### Signature Elements
- Đường contour mảnh mô phỏng địa hình, dùng làm họa tiết nền và đường dẫn thị giác.
- Nhãn số liệu dạng con dấu nhỏ: “Đà Nẵng / Miền Trung / Tư vấn 1–1”.
- Đường kẻ xanh lá và các góc cắt nhẹ gợi bản đồ quy hoạch, thay cho việc lạm dụng bo góc.

### Interaction Philosophy
Hover và focus phải tạo cảm giác “mở ra thêm thông tin”: ảnh dịch chuyển rất nhẹ, đường kẻ kéo dài, CTA chuyển từ nền cát sang xanh thông. Form liên hệ có phản hồi rõ ràng, thân thiện và không hứa hẹn quá mức. Link điện thoại luôn hiển thị rõ để khách cần tư vấn có thể liên hệ ngay.

### Animation
Dùng entrance reveal theo từng nhóm với độ trễ 40–60ms, chỉ chuyển động opacity và transform. Ảnh hero có parallax rất nhẹ khi cuộn; thẻ khu vực nâng 2–4px khi hover; nút có phản hồi nhấn 150ms. Tôn trọng `prefers-reduced-motion`, không dùng animation liên tục gây xao nhãng.

### Typography System
Tiêu đề dùng **DM Serif Display** với cỡ lớn, tạo cảm giác biên tập và giàu địa phương. Nội dung dùng **Manrope** với tracking thoáng, đọc tốt trên mobile. Tiêu đề viết câu tự nhiên, không lạm dụng viết hoa; nhãn phụ dùng Manrope 11–12px, tracking rộng và màu xanh thông.

### Brand Essence
**Bất động sản xanh kết nối những lựa chọn an cư và đầu tư có cơ sở tại Đà Nẵng cùng miền Trung, bằng sự am hiểu địa bàn và tư vấn tận tâm 1–1.**

Ba tính cách thương hiệu: **điềm tĩnh, am hiểu, tận tâm**.

### Brand Voice
Headline ngắn, có hình ảnh địa phương và tránh ngôn ngữ giật gân. CTA cụ thể, lịch sự, nói rõ bước tiếp theo. Microcopy như một chuyên viên tư vấn đang lắng nghe, không dùng các câu sáo rỗng kiểu “chào mừng” hay “bắt đầu ngay hôm nay”.

**Ví dụ:** “Tìm một nơi đáng sống, bắt đầu từ đúng địa hình.”

**Ví dụ:** “Trao đổi riêng với Lê Văn Tiến về nhu cầu của bạn.”

### Wordmark & Logo
Logo là biểu tượng hình chiếc lá kết hợp đường contour của một triền núi và đường bờ biển, tạo thành một chữ “B” trừu tượng. Mark không chứa chữ, dùng được độc lập ở header và favicon; wordmark “Bất động sản xanh” đi cùng DM Serif Display, trong đó dấu sắc và khoảng cách chữ được tinh chỉnh để tạo nét riêng.

### Signature Brand Color
**Xanh thông Sơn Trà — `#1F5A4A`**, một màu xanh rừng sâu vừa đủ trang trọng cho tư vấn bất động sản, vừa gợi hệ sinh thái và cảnh quan Đà Nẵng.
