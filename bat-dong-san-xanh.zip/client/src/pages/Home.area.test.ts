import { describe, expect, it } from "vitest";
import { filterAreas } from "./Home";

describe("filterAreas", () => {
  it("returns all area cards for an empty query", () => {
    expect(filterAreas("")).toHaveLength(5);
  });

  it("matches Vietnamese area names case-insensitively", () => {
    expect(filterAreas("đà NẴNG").map(area => area.name)).toEqual(["Đà Nẵng"]);
    expect(filterAreas("hoi an").map(area => area.name)).toEqual(["Hội An"]);
  });

  it("returns an empty state when there is no matching area", () => {
    expect(filterAreas("Tây Bắc")).toEqual([]);
  });
});
