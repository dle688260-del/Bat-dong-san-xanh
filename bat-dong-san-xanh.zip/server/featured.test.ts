import { describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  createBuyerLead: vi.fn(), createConsultationRequest: vi.fn(), createDeal: vi.fn(), createLegalCheck: vi.fn(), createOwner: vi.fn(), createProperty: vi.fn(), createPropertyImage: vi.fn(), createSurvey: vi.fn(), createValuation: vi.fn(), getPublishedPropertyWithImages: vi.fn(), listAreas: vi.fn(async () => []), listBuyerLeads: vi.fn(), listConsultationRequests: vi.fn(), listDeals: vi.fn(), listFeaturedProperties: vi.fn(async () => []), listLatestPublishedProperties: vi.fn(async () => [{ id: 9, title: "Nhà mới Sơn Trà", imageUrl: "https://example.com/son-tra.jpg" }]), listLegalChecks: vi.fn(), listOwners: vi.fn(), listProperties: vi.fn(), listPublishedProperties: vi.fn(), listSurveys: vi.fn(), listValuations: vi.fn(), updateConsultationStatus: vi.fn(), updatePropertyStatus: vi.fn(),
}));
vi.mock("./db", () => mocks);

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const context = { user: undefined, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] } satisfies TrpcContext;

describe("public property discovery", () => {
  it("returns empty states safely before areas or featured inventory exist", async () => {
    const caller = appRouter.createCaller(context);
    await expect(caller.properties.areas()).resolves.toEqual([]);
    await expect(caller.properties.featured()).resolves.toEqual([]);
    await expect(caller.properties.latest()).resolves.toEqual([{ id: 9, title: "Nhà mới Sơn Trà", imageUrl: "https://example.com/son-tra.jpg" }]);
    expect(mocks.listAreas).toHaveBeenCalledOnce();
    expect(mocks.listFeaturedProperties).toHaveBeenCalledOnce();
    expect(mocks.listLatestPublishedProperties).toHaveBeenCalledOnce();
  });
});
