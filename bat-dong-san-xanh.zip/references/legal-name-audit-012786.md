# Đối soát tên mã 1.012786

Nguồn chính: [Cổng Dịch vụ công Quốc gia](https://dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012786). Trang hiển thị tên thủ tục: **Cấp lại Giấy chứng nhận do bị mất**; đồng thời hiển thị thành phần hồ sơ, quy trình và cách thức thực hiện.

Nguồn đối chiếu địa phương: [Dịch vụ công Vĩnh Phúc](https://tracuuvinhphuc.phutho.gov.vn/vinhphuc/thutuchanhchinh/chitiet?maThuTuc=34781). Trang ghi mã `1.012786.000.00.00.H62` và cùng tên thủ tục **Cấp lại Giấy chứng nhận do bị mất**.

Ngày thu thập theo phiên làm việc: 23/08/2026. Mapping đã được thêm vào `server/officialLandProcedureCodeIndex.ts`; không suy đoán tên cho các mã còn chưa có nguồn xác minh tương ứng.
