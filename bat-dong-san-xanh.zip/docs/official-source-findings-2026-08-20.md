# Nguồn chính thức tìm được cho AI Hồ sơ đất đai

Ngày rà soát: 2026-08-20.

## Cổng DVC Bộ Nông nghiệp và Môi trường

- URL: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=180
- Thủ tục: Xác nhận tiếp tục sử dụng đất nông nghiệp của hộ gia đình, cá nhân khi hết hạn sử dụng đất đối với trường hợp có nhu cầu.
- Nội dung công bố: Mẫu số 09/ĐK; trang ghi mẫu được ban hành kèm Thông tư 33/2017/TT-BTNMT và công khai trên trang Bộ/Tổng cục Quản lý đất đai. Thành phần hồ sơ gồm đơn đăng ký biến động và bản gốc Giấy chứng nhận cùng giấy tờ thay đổi nhân thân/pháp nhân nếu có.
- Phân loại: Official Procedure/Legal metadata; chưa có binary mẫu trực tiếp trong phần trích xuất.

- URL: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=176
- Thủ tục: Cấp Giấy chứng nhận quyền sử dụng đất, quyền sở hữu nhà ở và tài sản khác gắn liền với đất cho người đã đăng ký quyền sử dụng đất lần đầu, trường hợp đã thành lập văn phòng đăng ký đất đai.
- Nội dung công bố: Mẫu 04a/ĐK, 04b/ĐK, 04d/ĐK; trang ghi các mẫu ban hành kèm Thông tư 24/2014/TT-BTNMT và công khai trên trang Bộ/Tổng cục Quản lý đất đai. Có thành phần, trình tự và cơ quan thực hiện.
- Phân loại: Official Procedure/Legal metadata; chưa có binary mẫu trực tiếp trong phần trích xuất.

## Cổng Thông tin điện tử Chính phủ

- URL: https://www.gov.vn/?pageid=27160&docid=210791
- Văn bản: Nghị định 101/2024/NĐ-CP, ban hành 29-07-2024, hiệu lực 01-08-2024.
- Binary pháp lý chính thức: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf
- Phân loại: Official Legal Document; không tự coi toàn bộ PDF nghị định là mẫu đơn. Chỉ phụ lục được xác định rõ là biểu mẫu và ghép đúng thành phần mới có thể xét Official Template.

## Cổng DVC địa phương

- URL: https://dichvucong.bentre.gov.vn/block/phieu-huong-dan/thu-tuc/56976
- Nội dung trích xuất: phiếu hướng dẫn thủ tục có mục thành phần hồ sơ và mẫu đơn/tờ khai; kết quả trích xuất không trả trực tiếp binary.
- Từ kết quả tìm kiếm: thủ tục cung cấp thông tin dữ liệu đất đai công bố Mẫu 14, 14a, 14b, 14c, 14d, 14đ và tên file Mus14a14b14c14d.docx.

## Kết luận sử dụng trong pipeline

Trang DVC chính thức và văn bản pháp lý chính thức có thể nâng hai lớp tương ứng độc lập. File mẫu/phụ lục chỉ nâng Official Template khi tải được byte thật, đúng định dạng, có provenance cơ quan nhà nước, có SHA-256 và ghép được vào component phù hợp. Nguồn ngoài nhà nước hoặc metadata không có binary vẫn giữ Reference/Pending.

## Binary pháp lý đã xác minh và lưu S3

PDF Nghị định 101/2024/NĐ-CP đã tải thành công từ `datafiles.chinhphu.vn`, có kích thước 5.546.344 bytes, nhận dạng PDF 1.4 và 137 trang. SHA-256 là `dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e`. Bản lưu S3 có key `legal-official/nghi-dinh-101-2024/dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e_b6a4c498.pdf` và URL nội bộ `/manus-storage/legal-official/nghi-dinh-101-2024/dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e_b6a4c498.pdf`.

Trạng thái của file này là `Official Legal Document`, không phải `Official Template File`, vì đây là toàn văn nghị định. Chỉ khi tách được phụ lục có biểu mẫu đúng thủ tục thì phụ lục đó mới được xét ở lớp Template/Annex.

## Kiểm tra Mus14 từ Cổng Một cửa Nghệ An

Nguồn chính thức: `https://motcua.nghean.gov.vn/kiosk/chi-tiet/chi-tiet-thu-tuc?ma-thu-tuc=108722&mcq=`. HTML công khai hiển thị mẫu `Mus14a14b14c14d.docx` và link tương đối `/tttl/40/giayto/2025_07/1752614892_Mus14a14b14c14d.docx`. Khi tải trực tiếp ngày 2026-08-20 với User-Agent và Referer, endpoint trả về HTML 1.399 bytes thay vì DOCX; chữ ký DOCX không hợp lệ, SHA-256 của response HTML là `24696f0890dcfb07aa4d6451ab4a18461fe6cbd871d8e97971fe2ab07cc53ca7`. Không gắn Official Template; giữ Pending vì nguồn có công bố tên/link nhưng binary tải được chưa phải DOCX.

Ứng viên Thanh Hóa `https://phanhoi.thanhhoa.gov.vn/api/get-files/PHIEU_YEU_CAU_CUNG_CAP_DU_LIEU_MAU_14_(_9.10)-_Copy_(3).docx_1759996804102.pdf` tải được PDF 151.572 bytes, SHA-256 `8a080e25b0a420e3e867faf7c1d8dca70fd915ce841985a1a05339d817d841bb`, nhưng nội dung là một phiếu đã điền thông tin cá nhân, không phải mẫu trắng; không gắn Official Template.


## Rà soát bổ sung thủ tục 1.012789

- **Cổng Dịch vụ công Quốc gia:** https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
- Thành phần hồ sơ công bố các Mẫu số 14, 14a, 14b, 14c, 14d, 14đ; trang hiển thị tên file `Mus14a14b14c14d.docx` và liên kết tải công khai.
- **Cổng Một cửa Nghệ An:** https://motcua.nghean.gov.vn/kiosk/chi-tiet/chi-tiet-thu-tuc?ma-thu-tuc=48764&mcq=
- **Cổng MAE, phụ lục thủ tục kèm Quyết định 2304/QĐ-BNNMT:** https://mae.gov.vn/noidung/Lists/VanBanDieuHanh/Attachments/3305/2.%20PHU%20LUC%20CHI%20TIET%20C%C3%81C%20THU%20TUC%20151.2025.N%C4%90-CP.pdf
- Quy tắc: URL thủ tục và phụ lục pháp lý được ghi ở lớp Official Procedure/Legal; file Mus14 chỉ vào Official Template khi response tải xuống là DOCX thật. Nếu endpoint trả HTML hoặc file bên ngoài là bản đã điền, giữ Pending/Reference.
