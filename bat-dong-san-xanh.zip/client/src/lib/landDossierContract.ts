export type LandDossierInput = {
  sellerName: string;
  sellerId: string;
  sellerAddress: string;
  sellerMaritalStatus: string;
  buyerName: string;
  buyerId: string;
  buyerAddress: string;
  buyerMaritalStatus: string;
  certificateNumber: string;
  certificateDate: string;
  certificateAuthority: string;
  parcelNumber: string;
  mapSheet: string;
  landAddress: string;
  area: string;
  landUse: string;
  transferPrice: string;
  depositDate: string;
  /** Các trường nhập động theo mã thủ tục, không làm mất dữ liệu legacy. */
  procedureFields: Record<string, string>;
};

export type LandDossierOcrField = {
  key: string;
  label: string;
  value: string;
  confidence: number;
  evidence: string;
  confirmed: boolean;
};

export type LandDossierWorkflowState =
  | "select-procedure"
  | "select-province"
  | "input-documents"
  | "ai-review"
  | "preview"
  | "confirmed";

export const EMPTY_LAND_DOSSIER_INPUT: LandDossierInput = {
  sellerName: "",
  sellerId: "",
  sellerAddress: "",
  sellerMaritalStatus: "",
  buyerName: "",
  buyerId: "",
  buyerAddress: "",
  buyerMaritalStatus: "",
  certificateNumber: "",
  certificateDate: "",
  certificateAuthority: "",
  parcelNumber: "",
  mapSheet: "",
  landAddress: "",
  area: "",
  landUse: "",
  transferPrice: "",
  depositDate: "",
  procedureFields: {},
};

export function mergeConfirmedOcrIntoInput(input: LandDossierInput, fields: LandDossierOcrField[]): LandDossierInput {
  const next = { ...input };
  for (const field of fields) {
    if (!field.confirmed) continue;
    if (field.key in next && field.key !== "procedureFields") {
      const key = field.key as keyof Omit<LandDossierInput, "procedureFields">;
      next[key] = field.value;
    } else {
      next.procedureFields[field.key] = field.value;
    }
  }
  return next;
}

export function landDossierWorkflowState(params: {
  procedureId: string;
  province: string;
  hasInput: boolean;
  hasOcr: boolean;
  confirmed: boolean;
}): LandDossierWorkflowState {
  if (!params.procedureId) return "select-procedure";
  if (!params.province) return "select-province";
  if (!params.hasInput && !params.hasOcr) return "input-documents";
  if (!params.confirmed) return params.hasOcr ? "ai-review" : "input-documents";
  return "confirmed";
}
