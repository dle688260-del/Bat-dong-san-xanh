import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  getPropertyLayoutLabel,
  getPropertyLayoutForCategory,
  readStoredPropertyLayout,
  readStoredPropertyLayoutConfig,
  resolveAutoPropertyLayout,
  writeStoredPropertyLayout,
  writeStoredPropertyLayoutConfig,
} from "./PropertyLayoutRenderer";

describe("PropertyLayoutRenderer layout strategy", () => {
  it("chooses a horizontal carousel for a single item", () => {
    expect(resolveAutoPropertyLayout(1)).toBe("carousel");
  });

  it("expands one carousel item to the available width instead of leaving empty desktop space", () => {
    const source = readFileSync(
      new URL("./PropertyLayoutRenderer.tsx", import.meta.url),
      "utf8"
    );
    expect(source).toMatch(/items\.length === 1\s*\?\s*"w-full min-w-full"/);
  });

  it("uses two columns for two items", () => {
    expect(resolveAutoPropertyLayout(2)).toBe("grid2");
  });

  it("uses a three-column editorial grid for three or four items", () => {
    expect(resolveAutoPropertyLayout(3)).toBe("grid3");
    expect(resolveAutoPropertyLayout(4)).toBe("grid3");
  });

  it("uses the 1-large plus 4-small mosaic for five or more items", () => {
    expect(resolveAutoPropertyLayout(5)).toBe("mosaic");
    expect(resolveAutoPropertyLayout(12)).toBe("mosaic");
  });

  it("exposes Vietnamese labels for the picker", () => {
    expect(getPropertyLayoutLabel("auto")).toBe("Tự động");
    expect(getPropertyLayoutLabel("mosaic")).toBe("1 lớn + 4 nhỏ");
    expect(getPropertyLayoutLabel("carousel")).toBe("Vuốt ngang");
  });

  it("reads only valid stored layouts and falls back to auto", () => {
    const storage = { getItem: () => "grid3" };
    expect(readStoredPropertyLayout(storage)).toBe("grid3");
    expect(readStoredPropertyLayout({ getItem: () => "not-a-layout" })).toBe(
      "auto"
    );
    expect(
      readStoredPropertyLayout({
        getItem: () => {
          throw new Error("blocked");
        },
      })
    ).toBe("auto");
  });

  it("applies a category override and falls back to the default layout", () => {
    const config = {
      defaultLayout: "grid2" as const,
      byCategory: { land: "mosaic" as const },
    };
    expect(getPropertyLayoutForCategory(config, "land")).toBe("mosaic");
    expect(getPropertyLayoutForCategory(config, "house")).toBe("grid2");
    expect(getPropertyLayoutForCategory(config, null)).toBe("grid2");
  });

  it("sanitizes stored category overrides and writes only valid configuration", () => {
    const storage = {
      getItem: () =>
        JSON.stringify({
          defaultLayout: "grid3",
          byCategory: { land: "mosaic", house: "bad", unknown: "carousel" },
        }),
    };
    expect(readStoredPropertyLayoutConfig(storage)).toEqual({
      defaultLayout: "grid3",
      byCategory: { land: "mosaic" },
    });
    let saved = "";
    writeStoredPropertyLayoutConfig(
      {
        setItem: (_key, value) => {
          saved = value;
        },
      },
      {
        defaultLayout: "grid2",
        byCategory: { land: "mosaic", house: "bad" as never },
      }
    );
    expect(JSON.parse(saved)).toEqual({
      defaultLayout: "grid2",
      byCategory: { land: "mosaic" },
    });
  });

  it("writes the selected layout without throwing when storage is blocked", () => {
    let saved = "";
    writeStoredPropertyLayout(
      {
        setItem: (_key, value) => {
          saved = value;
        },
      },
      "mosaic"
    );
    expect(saved).toBe("mosaic");
    expect(() =>
      writeStoredPropertyLayout(
        {
          setItem: () => {
            throw new Error("blocked");
          },
        },
        "carousel"
      )
    ).not.toThrow();
  });
});
