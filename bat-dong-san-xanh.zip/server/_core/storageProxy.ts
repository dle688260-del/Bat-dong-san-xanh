import type { Express, Request, Response as ExpressResponse } from "express";
import { ENV } from "./env";

const STORAGE_FETCH_TIMEOUT_MS = 30_000;
const OFFICIAL_STORAGE_PREFIX = "legal-official/";

function getPathStorageKey(req: Request): string {
  return (req.params as Record<string, string>)[0] || "";
}

function getQueryStorageKey(req: Request): string {
  const value = req.query.key;
  return typeof value === "string" ? value : "";
}

async function serveStorageObject(res: ExpressResponse, key: string) {
  if (!key) {
    res.status(400).send("Missing storage key");
    return;
  }

  if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
    res.status(500).send("Storage proxy not configured");
    return;
  }

  try {
    const forgeUrl = new URL(
      "v1/storage/presign/get",
      ENV.forgeApiUrl.replace(/\/+$/, "") + "/",
    );
    forgeUrl.searchParams.set("path", key);

    const forgeResp = await fetch(forgeUrl, {
      headers: { Authorization: `Bearer ${ENV.forgeApiKey}` },
    });

    if (!forgeResp.ok) {
      const body = await forgeResp.text().catch(() => "");
      console.error(`[StorageProxy] forge error: ${forgeResp.status} ${body}`);
      res.status(502).send("Storage backend error");
      return;
    }

    const { url } = (await forgeResp.json()) as { url: string };
    if (!url || !/^https?:\/\//i.test(url)) {
      res.status(502).send("Empty signed URL from backend");
      return;
    }

    // Do not redirect the browser to the signed CloudFront URL. In production,
    // browser document/fetch requests can be served by the edge as a stale
    // Not found response even though the signed object is present. Fetching
    // server-side keeps the storage contract behind this same-origin route and
    // gives the browser the actual verified binary response.
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), STORAGE_FETCH_TIMEOUT_MS);
    let objectResp: globalThis.Response;
    try {
      objectResp = await fetch(url, { signal: controller.signal });
    } finally {
      clearTimeout(timeoutId);
    }

    if (!objectResp.ok) {
      console.error(`[StorageProxy] object error: ${objectResp.status} for ${key}`);
      res
        .status(objectResp.status === 404 ? 404 : 502)
        .send(objectResp.status === 404 ? "Not found" : "Storage object error");
      return;
    }

    const contentType = objectResp.headers.get("content-type");
    const contentLength = objectResp.headers.get("content-length");
    if (contentType) res.set("Content-Type", contentType);
    if (contentLength) res.set("Content-Length", contentLength);
    // Uploaded media is addressed by an immutable storage key, so caching images
    // avoids re-fetching the same binary and re-generating a signed URL on every
    // navigation. Legal documents remain non-cacheable because they may be
    // sensitive and are opened as one-off downloads.
    const isCacheableImage = contentType?.toLowerCase().startsWith("image/") === true;
    res.set(
      "Cache-Control",
      isCacheableImage ? "public, max-age=3600, stale-while-revalidate=86400" : "no-store, no-cache, must-revalidate",
    );
    res.set("X-Content-Type-Options", "nosniff");
    res.send(Buffer.from(await objectResp.arrayBuffer()));
  } catch (err) {
    console.error("[StorageProxy] failed:", err);
    res.status(502).send("Storage proxy error");
  }
}

export function registerStorageProxy(app: Express) {
  // The platform reserves /manus-storage/* in production and may answer it
  // with its own redirect before the application route. Keep this legacy path
  // for compatibility, but use /api/official-storage?key=... for Official UI.
  app.get("/manus-storage/*", async (req, res) => {
    await serveStorageObject(res, getPathStorageKey(req));
  });

  // Query-string transport avoids losing slash-separated storage keys in an
  // edge wildcard route and stays on the application's API origin.
  app.get("/api/official-storage", async (req, res) => {
    const key = getQueryStorageKey(req);
    if (!key.startsWith(OFFICIAL_STORAGE_PREFIX)) {
      res.status(400).send("Invalid official storage key");
      return;
    }
    await serveStorageObject(res, key);
  });
}
