import { describe, expect, it } from "vitest";
import { AI_WRITING_STYLES, buildManualPublishTarget, DOSSIER_AI_OUTPUT_FIELDS, DOSSIER_FONT_SIZES, DOSSIER_STEP_FIELDS, DOSSIER_WORD_FILE_EXTENSION, DOSSIER_WORD_MIME_TYPE, getDossierSyncRows, PROPERTY_DOSSIER_DELETE_LABEL, PROPERTY_DOSSIER_STEP_NAMES, PROPERTY_DOSSIER_STATUS_META, PROPERTY_DOSSIER_TYPES, PUBLISHING_CHANNELS } from "./PropertyDossierAdmin";

describe("Property dossier workflow contract", () => {
  it("contains the complete 12-step brokerage workflow", () => {
    expect(PROPERTY_DOSSIER_STEP_NAMES).toHaveLength(12);
    expect(PROPERTY_DOSSIER_STEP_NAMES).toEqual([
      "Tiếp nhận thông tin BĐS",
      "Khảo sát sơ bộ",
      "Khảo sát thực tế",
      "Kiểm tra quy hoạch",
      "Kiểm tra pháp lý",
      "Định giá BĐS",
      "Tiếp nhận ký gửi",
      "Đăng bán",
      "Quản lý khách mua",
      "Xem BĐS",
      "Đàm phán & giao dịch",
      "Hoàn tất",
    ]);
  });

  it("exposes the requested property types for new dossiers", () => {
    expect(PROPERTY_DOSSIER_TYPES.map(type => type.label)).toEqual(["Đất nền", "Đất nông nghiệp", "Căn hộ", "Nhà phố", "Khu nghỉ dưỡng", "Villa / Resort"]);
  });

  it("keeps the delete action label visible on each dossier card", () => {
    expect(PROPERTY_DOSSIER_DELETE_LABEL).toBe("Xóa bài");
  });

  it("provides structured input fields for every workflow step", () => {
    expect(Object.keys(DOSSIER_STEP_FIELDS)).toHaveLength(12);
    expect(DOSSIER_STEP_FIELDS[0].map(field => field.key)).toContain("ownerName");
    expect(DOSSIER_STEP_FIELDS[4].map(field => field.key)).toContain("certificateType");
    expect(DOSSIER_STEP_FIELDS[11].map(field => field.key)).toContain("handover");
  });

  it("aggregates saved workflow fields into the electronic dossier overview", () => {
    const steps = Array.from({ length: 12 }, () => ({ details: null as string | null }));
    steps[0] = { details: JSON.stringify({ fields: { ownerName: "Trần Văn Minh", ownerPhone: "0900 123 456" } }) };
    steps[2] = { details: JSON.stringify({ fields: { area: "100", frontage: "5 m", orientation: "Đông Nam" } }) };
    steps[3] = { details: JSON.stringify({ fields: { planningStatus: "Đang xác minh" } }) };
    steps[4] = { details: JSON.stringify({ fields: { certificateType: "Giấy chứng nhận quyền sử dụng đất" } }) };
    steps[5] = { details: JSON.stringify({ fields: { recommendedPrice: "3,25 tỷ đồng" } }) };
    steps[8] = { details: JSON.stringify({ fields: { buyerName: "Phạm Thu Hà" } }) };
    steps[9] = { details: JSON.stringify({ fields: { viewingDate: "20/08/2026" } }) };

    expect(getDossierSyncRows(steps)).toEqual([
      ["Chủ nhà", "Trần Văn Minh"],
      ["Số điện thoại", "0900 123 456"],
      ["Diện tích khảo sát", "100 m²"],
      ["Mặt tiền / đường", "5 m"],
      ["Hướng", "Đông Nam"],
      ["Pháp lý", "Giấy chứng nhận quyền sử dụng đất"],
      ["Quy hoạch", "Đang xác minh"],
      ["Giá đề xuất", "3,25 tỷ đồng"],
      ["Khách mua", "Phạm Thu Hà"],
      ["Lịch xem nhà", "20/08/2026"],
    ]);
  });

  it("exposes the publishing channels for review before posting", () => {
    expect(PUBLISHING_CHANNELS.map(channel => channel.id)).toEqual(["facebook", "google", "youtube", "tiktok", "zalo"]);
    expect(PUBLISHING_CHANNELS.find(channel => channel.id === "facebook")?.label).toBe("Facebook Page");
    expect(PUBLISHING_CHANNELS.find(channel => channel.id === "zalo")?.label).toBe("Zalo OA");
  });

  it("builds safe manual-post targets for personal Facebook and Zalo flows", () => {
    const facebookTarget = buildManualPublishTarget("facebook", "Bán đất", "Gần biển Đà Nẵng");
    expect(facebookTarget).toContain("facebook.com/sharer/sharer.php?quote=");
    expect(facebookTarget).toContain(encodeURIComponent("Bán đất\n\nGần biển Đà Nẵng"));
    expect(buildManualPublishTarget("zalo", "Bán đất", "Gần biển Đà Nẵng")).toBe("https://chat.zalo.me/");
  });

  it("uses a standards-compliant DOCX download contract", () => {
    expect(DOSSIER_WORD_FILE_EXTENSION).toBe(".docx");
    expect(DOSSIER_WORD_MIME_TYPE).toBe("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
  });

  it("exposes the three dossier font sizes", () => {
    expect(DOSSIER_FONT_SIZES.map(size => size.id)).toEqual(["standard", "large", "extra-large"]);
    expect(DOSSIER_FONT_SIZES.map(size => size.label)).toEqual(["Tiêu chuẩn", "Lớn", "Rất lớn"]);
  });

  it("exposes the three AI writing styles", () => {
    expect(AI_WRITING_STYLES.map(style => style.id)).toEqual(["concise", "professional", "facebook"]);
    expect(AI_WRITING_STYLES.find(style => style.id === "facebook")?.label).toBe("Tối ưu Facebook");
  });

  it("defines the structured AI analysis and draft fields", () => {
    expect(DOSSIER_AI_OUTPUT_FIELDS).toEqual(["summary", "strengths", "missingInformation", "warnings", "listingTitle", "listingDescription", "shortCaption", "hashtags"]);
  });

  it("exposes the four operational statuses", () => {
    expect(Object.keys(PROPERTY_DOSSIER_STATUS_META)).toEqual([
      "completed",
      "in_progress",
      "not_started",
      "needs_review",
    ]);
    expect(PROPERTY_DOSSIER_STATUS_META.needs_review.label).toBe("Cần kiểm tra lại");
  });
});
