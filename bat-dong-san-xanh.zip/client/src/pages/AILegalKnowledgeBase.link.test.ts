import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("AILegalKnowledgeBase property and deal linkage contract", () => {
  const source = readFileSync(resolve(process.cwd(), "client/src/pages/AILegalKnowledgeBase.tsx"), "utf8");

  it("loads existing deals and property dossiers from CRM procedures", () => {
    expect(source).toContain("trpc.brokerage.deals.useQuery");
    expect(source).toContain("trpc.brokerage.dossiers.list.useQuery");
  });

  it("explains that legal records reuse the existing property key", () => {
    expect(source).toContain("propertyId");
    expect(source).toContain("không tạo hồ sơ trùng");
    expect(source).toContain("Liên kết hồ sơ pháp lý với BĐS và Giao dịch");
  });

  it("keeps the legal AI boundary explicit", () => {
    expect(source).toContain("AI chỉ hỗ trợ rà soát, không tự kết luận pháp lý");
  });
});
