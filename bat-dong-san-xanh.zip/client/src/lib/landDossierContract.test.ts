import { describe, expect, it } from "vitest";
import { EMPTY_LAND_DOSSIER_INPUT, landDossierWorkflowState, mergeConfirmedOcrIntoInput } from "./landDossierContract";

describe("land dossier contract", () => {
  it("merges only confirmed OCR fields that belong to the dossier contract", () => {
    const next = mergeConfirmedOcrIntoInput(EMPTY_LAND_DOSSIER_INPUT, [
      { key: "buyerName", label: "Bên nhận", value: "Nguyễn Văn A", confidence: 0.98, evidence: "CCCD", confirmed: true },
      { key: "area", label: "Diện tích", value: "120", confidence: 0.95, evidence: "Giấy chứng nhận", confirmed: false },
      { key: "unknown", label: "Không dùng", value: "x", confidence: 1, evidence: "", confirmed: true },
    ]);
    expect(next.buyerName).toBe("Nguyễn Văn A");
    expect(next.area).toBe("");
    expect(next).not.toHaveProperty("unknown");
  });

  it("returns the user-facing workflow stage in order", () => {
    expect(landDossierWorkflowState({ procedureId: "", province: "", hasInput: false, hasOcr: false, confirmed: false })).toBe("select-procedure");
    expect(landDossierWorkflowState({ procedureId: "transfer", province: "", hasInput: false, hasOcr: false, confirmed: false })).toBe("select-province");
    expect(landDossierWorkflowState({ procedureId: "transfer", province: "Đà Nẵng", hasInput: false, hasOcr: false, confirmed: false })).toBe("input-documents");
    expect(landDossierWorkflowState({ procedureId: "transfer", province: "Đà Nẵng", hasInput: true, hasOcr: true, confirmed: false })).toBe("ai-review");
    expect(landDossierWorkflowState({ procedureId: "transfer", province: "Đà Nẵng", hasInput: true, hasOcr: true, confirmed: true })).toBe("confirmed");
  });
});
