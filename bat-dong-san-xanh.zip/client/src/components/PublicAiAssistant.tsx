import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { Bot, Grip, Mic, Phone, Send, Sparkles, Volume2, X } from "lucide-react";
import { toast } from "sonner";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import { trpc } from "@/lib/trpc";
import { clampAssistantPosition, getDefaultAssistantPosition, type AssistantPosition } from "./publicAiAssistantPosition";

type SpeechRecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
  start: () => void;
};

type SpeechRecognitionConstructor = new () => SpeechRecognitionLike;

declare global {
  interface Window {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

export type PublicAiAssistantProps = {
  propertyContext?: string;
  title?: string;
};

const POSITION_KEY = "bdsx-ai-assistant-position-v2";
const initialMessage: Message = {
  role: "assistant",
  content: "Xin chào, tôi là Trợ lý AI của Bất động sản xanh. Tôi có thể giúp bạn tìm BĐS phù hợp, giải thích thông tin bài đăng hoặc ghi nhận nhu cầu tư vấn.",
};

function readSavedPosition(): AssistantPosition {
  if (typeof window === "undefined") return { left: 16, top: 16 };
  try {
    const saved = JSON.parse(window.localStorage.getItem(POSITION_KEY) || "null") as Partial<AssistantPosition> | null;
    if (typeof saved?.left === "number" && typeof saved.top === "number") return clampAssistantPosition({ left: saved.left, top: saved.top });
  } catch {
    // Ignore invalid local storage and use the default position.
  }
  return getDefaultAssistantPosition();
}

export function PublicAiAssistant({ propertyContext = "", title = "Trợ lý AI Bất động sản xanh" }: PublicAiAssistantProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([initialMessage]);
  const [listening, setListening] = useState(false);
  const [position, setPosition] = useState<AssistantPosition>(readSavedPosition);
  const [handoffOpen, setHandoffOpen] = useState(false);
  const [handoffName, setHandoffName] = useState("");
  const [handoffPhone, setHandoffPhone] = useState("");
  const dragRef = useRef<{ pointerId: number; offsetX: number; offsetY: number; moved: boolean } | null>(null);
  const chat = trpc.ai.chat.useMutation();
  const consultation = trpc.consultations.create.useMutation({
    onSuccess: () => { toast.success("Đã gửi nhu cầu. Chuyên viên sẽ liên hệ với bạn."); setHandoffOpen(false); setHandoffName(""); setHandoffPhone(""); },
    onError: error => toast.error(error.message || "Không thể gửi thông tin liên hệ."),
  });
  const suggestedPrompts = useMemo(() => propertyContext ? ["BĐS này có những thông tin nổi bật nào?", "Hồ sơ pháp lý của BĐS này cần kiểm tra gì?", "Tôi muốn đặt lịch xem BĐS này"] : ["Tôi muốn tìm căn hộ dưới 3 tỷ ở Đà Nẵng", "Tôi muốn ký gửi bất động sản", "Tôi cần được tư vấn mua nhà"], [propertyContext]);

  useEffect(() => {
    const handleResize = () => setPosition(current => clampAssistantPosition(current));
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    window.localStorage.setItem(POSITION_KEY, JSON.stringify(position));
  }, [position]);

  const speak = (text: string) => {
    if (!("speechSynthesis" in window)) {
      toast.info("Thiết bị này chưa hỗ trợ đọc câu trả lời bằng giọng nói.");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.replace(/[#*_`]/g, ""));
    utterance.lang = "vi-VN";
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
  };

  const sendMessage = (content: string) => {
    const trimmed = content.trim();
    if (!trimmed || chat.isPending) return;
    const nextMessages = [...messages, { role: "user" as const, content: trimmed }];
    setMessages(nextMessages);
    chat.mutate({
      messages: nextMessages.slice(-8).filter(message => message.role === "user" || message.role === "assistant").map(message => ({ role: message.role === "assistant" ? "assistant" as const : "user" as const, content: message.content })),
      propertyContext,
    }, {
      onSuccess: result => {
        const recommendations = result.matches.length ? `\n\n**BĐS phù hợp với nhu cầu:**\n${result.matches.map(property => `- **${property.title}** · ${property.price} tỷ · ${property.area} m² · ${property.location}`).join("\n")}` : "";
        const followUp = result.followUpQuestion ? `\n\n**Câu hỏi tiếp theo:** ${result.followUpQuestion}` : "";
        const handoff = result.shouldHandoff ? `\n\n**Chuyển sang chuyên viên:** ${result.capturePrompt}` : "";
        setMessages(current => [...current, { role: "assistant", content: `${result.answer}${recommendations}${followUp}${handoff}` }]);
        if (result.shouldHandoff) setHandoffOpen(true);
      },
      onError: error => toast.error(error.message || "Không thể kết nối trợ lý AI."),
    });
  };

  const submitHandoff = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const latestNeed = [...messages].reverse().find(item => item.role === "user")?.content || "Khách cần tư vấn mua bất động sản";
    const transcript = messages.map(item => `${item.role === "user" ? "Khách" : "AI"}: ${item.content}`).join("\n").slice(-12000);
    const propertyIds = messages.flatMap(item => Array.from(item.content.matchAll(/\b(?:BĐS|bất động sản)\s*#?(\d+)\b/gi), match => Number(match[1]))).filter(Boolean).slice(0, 10);
    consultation.mutate({ name: handoffName, phone: handoffPhone, interest: "Tư vấn mua BĐS qua Trợ lý AI", message: `${latestNeed}${propertyContext ? `\nBối cảnh: ${propertyContext}` : ""}`, conversationHistory: transcript, propertyIds });
  };

  const listen = () => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
      toast.info("Trình duyệt chưa hỗ trợ nhập bằng giọng nói. Bạn có thể dùng Chrome trên điện thoại hoặc máy tính.");
      return;
    }
    const recognition = new Recognition();
    recognition.lang = "vi-VN";
    recognition.interimResults = false;
    recognition.continuous = false;
    setListening(true);
    recognition.onresult = event => {
      const transcript = event.results[0]?.[0]?.transcript || "";
      setListening(false);
      sendMessage(transcript);
    };
    recognition.onerror = () => {
      setListening(false);
      toast.error("Không nhận diện được giọng nói. Vui lòng thử lại.");
    };
    recognition.onend = () => setListening(false);
    recognition.start();
  };

  const handlePointerDown = (event: React.PointerEvent<HTMLButtonElement>) => {
    if (event.button !== 0) return;
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      pointerId: event.pointerId,
      offsetX: event.clientX - position.left,
      offsetY: event.clientY - position.top,
      moved: false,
    };
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    if (Math.abs(event.clientX - (position.left + drag.offsetX)) > 4 || Math.abs(event.clientY - (position.top + drag.offsetY)) > 4) drag.moved = true;
    if (drag.moved) setPosition(clampAssistantPosition({ left: event.clientX - drag.offsetX, top: event.clientY - drag.offsetY }));
  };

  const handlePointerUp = (event: React.PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    event.currentTarget.releasePointerCapture(event.pointerId);
    if (!drag.moved) setOpen(true);
    dragRef.current = null;
  };

  return <>
    <button
      type="button"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={() => { dragRef.current = null; }}
      aria-label="Trò chuyện với AI"
      title="Kéo để di chuyển · Bấm để trò chuyện với AI"
      className="fixed z-40 inline-flex h-10 w-[118px] touch-none select-none items-center justify-center gap-1 rounded-full bg-[#1F5A4A] px-2 text-white shadow-[0_7px_18px_rgba(31,90,74,.24)] transition-[transform,box-shadow] hover:scale-[1.03] hover:shadow-[0_10px_22px_rgba(31,90,74,.3)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E6C478] active:scale-[.98] sm:h-11 sm:w-[132px] sm:px-2.5"
      style={{ left: position.left, top: position.top }}
    >
      <Bot size={16} />
      <span className="text-[10px] font-extrabold leading-3 tracking-tight sm:text-[11px]">Trò chuyện AI</span>
      <Grip size={10} className="ml-0.5 text-white/60" aria-hidden="true" />
      <span className="absolute -right-1 -top-1 inline-flex h-4 w-4 items-center justify-center rounded-full bg-[#E6C478] text-[#18352D]"><Sparkles size={9} /></span>
    </button>
    {open ? <div className="fixed inset-0 z-50 flex items-end justify-end bg-[#18352D]/20 p-3 sm:items-end sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className="flex w-full max-w-md flex-col overflow-hidden rounded-[24px] border border-[#1F5A4A]/15 bg-[#F8FBF7] shadow-2xl sm:max-h-[min(680px,calc(100vh-48px))]">
        <div className="flex items-center justify-between bg-[#1F5A4A] px-4 py-3 text-white">
          <div><p className="flex items-center gap-2 text-sm font-extrabold"><Bot size={18} />{title}</p><p className="mt-0.5 text-[11px] text-white/75">Hỗ trợ tìm hiểu thông tin, không thay thế tư vấn pháp lý</p></div>
          <button type="button" onClick={() => setOpen(false)} aria-label="Đóng Trợ lý AI" className="rounded-full p-2 hover:bg-white/10"><X size={18} /></button>
        </div>
        <AIChatBox messages={messages} onSendMessage={sendMessage} isLoading={chat.isPending} height="min(430px, 52vh)" placeholder="Nhập câu hỏi về BĐS…" emptyStateMessage="Hãy đặt câu hỏi để bắt đầu." suggestedPrompts={suggestedPrompts} />
        {handoffOpen ? <form onSubmit={submitHandoff} className="border-t border-[#1F5A4A]/10 bg-[#FFF7DE] px-3 py-3">
          <div className="mb-2 flex items-center gap-2 text-xs font-extrabold text-[#6D5315]"><Phone size={14} />Để chuyên viên tiếp nhận nhu cầu</div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <input value={handoffName} onChange={event => setHandoffName(event.target.value)} required minLength={2} maxLength={120} placeholder="Họ và tên" className="min-w-0 rounded-xl border border-[#E6C478]/70 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#E6C478]" />
            <input value={handoffPhone} onChange={event => setHandoffPhone(event.target.value)} required minLength={8} maxLength={30} placeholder="Số điện thoại" className="min-w-0 rounded-xl border border-[#E6C478]/70 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#E6C478]" />
          </div>
          <button type="submit" disabled={consultation.isPending} className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#1F5A4A] px-3 py-2 text-xs font-extrabold text-white disabled:opacity-60"><Phone size={14} />{consultation.isPending ? "Đang gửi…" : "Để chuyên viên gọi lại"}</button>
        </form> : null}
        <div className="flex items-center justify-between border-t border-[#1F5A4A]/10 bg-white px-3 py-2">
          <button type="button" onClick={listen} disabled={listening} className="inline-flex items-center gap-2 rounded-full border border-[#1F5A4A]/20 px-3 py-2 text-xs font-bold text-[#1F5A4A] disabled:opacity-60"><Mic size={15} />{listening ? "Đang nghe…" : "Nói bằng micro"}</button>
          <button type="button" onClick={() => { const latest = [...messages].reverse().find(item => item.role === "assistant"); if (latest) speak(latest.content); }} className="inline-flex items-center gap-2 rounded-full border border-[#E6C478] bg-[#FFF7DE] px-3 py-2 text-xs font-bold text-[#6D5315]"><Volume2 size={15} />Đọc câu trả lời</button>
          <Send size={15} className="text-[#9BAFA6]" />
        </div>
      </div>
    </div> : null}
  </>;
}
