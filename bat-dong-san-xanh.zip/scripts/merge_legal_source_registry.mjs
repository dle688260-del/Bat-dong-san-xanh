import { readFileSync, writeFileSync } from 'node:fs';

const path = '/home/ubuntu/bat-dong-san-xanh/client/src/pages/AIDossierAdmin.tsx';
let text = readFileSync(path, 'utf8');
const start = text.indexOf('<div className="mt-3 rounded-xl border border-[#D8E4DC] bg-[#F7FBF7] p-3"><div className="flex items-center justify-between gap-2"><p className="text-xs font-black uppercase tracking-[0.12em] text-[#1F5A4A]">Bộ nguồn AI tự gom theo thủ tục</p>');
const endMarker = '<div className="mt-3 rounded-xl border border-[#D8B15A]';
const end = start >= 0 ? text.indexOf(endMarker, start) : -1;
if (start < 0 || end < 0) throw new Error(`source block not found: start=${start}, end=${end}`);
text = text.slice(0, start) + '<LegalSourceRegistryPanel procedureId={adminToBuilderProcedure[procedure.id] ?? procedure.id} title="Nguồn pháp lý từ AI Kho pháp lý hồ sơ AI" />' + text.slice(end);
writeFileSync(path, text);
console.log('merged', { start, end });
