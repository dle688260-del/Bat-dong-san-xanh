import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { buildConsultationPayload, CONSIGNMENT_INTEREST, consultationInterests, FeaturedPropertySection, getFeaturedState, getPropertyDetailPath, LOGIN_LABEL, propertyCategories, services, submitConsultationForm } from "./Home";

describe("Home navigation", () => {
  it("exposes a clear login label for the public navigation", () => {
    expect(LOGIN_LABEL).toBe("Đăng nhập");
  });
});

describe("Home property categories", () => {
  it("includes agricultural land and its main subtypes", () => {
    const category = propertyCategories.find((item) => item.title === "Đất nông nghiệp");
    expect(category?.description).toContain("Đất lúa");
    expect(category?.description).toContain("cây hàng năm");
    expect(category?.description).toContain("cây lâu năm");
    expect(category?.description).toContain("nuôi trồng thủy sản");
    expect(consultationInterests).toContain("Đất nông nghiệp");
  });
});

describe("Home working process", () => {
  it("exposes the four customer journey steps with concise copy", () => {
    expect(services.map((service) => service.title)).toEqual(["Tìm đúng BĐS", "Kiểm tra thông tin", "Tư vấn giá", "Hỗ trợ giao dịch"]);
    expect(services.map((service) => service.text)).toEqual(["Lựa chọn theo nhu cầu & ngân sách.", "Hỗ trợ kiểm tra hồ sơ, pháp lý.", "Tham khảo giá & hỗ trợ thương lượng.", "Đồng hành từ xem nhà đến hoàn tất."]);
  });
});

describe("Home consignment CTA", () => {
  it("uses the dedicated consignment interest in the consultation form", () => {
    expect(CONSIGNMENT_INTEREST).toBe("Ký gửi bất động sản");
    const data = new FormData();
    data.set("interest", CONSIGNMENT_INTEREST);
    data.set("name", "Trần Thị B");
    data.set("phone", "0989682825");
    data.set("message", "Muốn ký gửi nhà tại Sơn Trà");

    expect(buildConsultationPayload(data)).toEqual({
      interest: "Ký gửi bất động sản",
      name: "Trần Thị B",
      phone: "0989682825",
      message: "Muốn ký gửi nhà tại Sơn Trà",
    });
  });
});

describe("Home consultation form", () => {
  it("builds the exact payload consumed by consultations.create", () => {
    const data = new FormData();
    data.set("interest", "An cư tại Đà Nẵng");
    data.set("name", "Nguyễn Văn A");
    data.set("phone", "0989682825");
    data.set("message", "Quan tâm khu vực Sơn Trà");

    expect(buildConsultationPayload(data)).toEqual({
      interest: "An cư tại Đà Nẵng",
      name: "Nguyễn Văn A",
      phone: "0989682825",
      message: "Quan tâm khu vực Sơn Trà",
    });
  });

  it("calls the mutation callback with the submitted form payload", () => {
    const data = new FormData();
    data.set("interest", "Đầu tư bất động sản");
    data.set("name", "Nguyễn Văn B");
    data.set("phone", "0909123456");
    data.set("message", "Quan tâm Hòa Xuân");
    const mutate = vi.fn();

    submitConsultationForm(data, mutate);

    expect(mutate).toHaveBeenCalledOnce();
    expect(mutate).toHaveBeenCalledWith({ interest: "Đầu tư bất động sản", name: "Nguyễn Văn B", phone: "0909123456", message: "Quan tâm Hòa Xuân" });
  });
});

describe("featured property section", () => {
  it("selects loading, items, and empty states used by the homepage branch", () => {
    expect(getFeaturedState(undefined, true)).toBe("loading");
    expect(getFeaturedState([{ id: 1 }], false)).toBe("items");
    expect(getFeaturedState([], false)).toBe("empty");
    expect(getFeaturedState(undefined, true, true)).toBe("empty");
  });

  it("renders the empty state CTA when there are no featured properties", () => {
    const markup = renderToStaticMarkup(createElement(FeaturedPropertySection, { state: "empty", properties: [] }));
    expect(markup).toContain("Sản phẩm thật đang được cập nhật.");
    expect(markup).toContain("Khám phá danh mục");
    expect(markup).not.toContain("MẪU THAM KHẢO");
    expect(markup).not.toContain("Bản tham khảo");
    expect(markup).not.toContain("Không giao dịch");
  });

  it("renders a real property card when featured data exists", () => {
    const markup = renderToStaticMarkup(createElement(FeaturedPropertySection, { state: "items", properties: [{ id: 1, slug: "son-tra-view", title: "Nhà phố Sơn Trà", location: "Sơn Trà, Đà Nẵng", price: "5.2", area: "120", propertyType: "house", imageUrl: "https://example.com/son-tra.jpg", description: "Nhà phố gần biển, pháp lý rõ ràng.", bedrooms: 3, bathrooms: 2, latitude: "16.0544", longitude: "108.2022", mapVisibility: "approximate", legalStatus: "Đã có sổ hồng", planningStatus: "Không vướng quy hoạch", mortgageStatus: "Có thể hỗ trợ vay", listingDetails: JSON.stringify({ frontage: "5", depth: "24", floors: "3", loanSupport: "Ngân hàng hỗ trợ vay" }) }] }));
    expect(markup).toContain("Nhà phố Sơn Trà");
    expect(markup).toContain("/bat-dong-san/son-tra-view");
    expect(markup).toContain('href="/bat-dong-san/son-tra-view"');
    expect(markup).toContain('aria-label="Xem chi tiết Nhà phố Sơn Trà"');
    expect(markup).toContain("Xem chi tiết");
    expect(markup).toContain("Hiển thị bản đồ vị trí Nhà phố Sơn Trà");
    expect(markup).toContain("43,33 triệu/m²");
    expect(markup).toContain("120 m²");
    expect(markup).toContain("Ngang × dài");
    expect(markup).toContain("5 × 24 m");
    expect(markup).toContain("Phòng ngủ");
    expect(markup).toContain("Phòng vệ sinh");
    expect(markup).toContain("Gọi điện");
    expect(markup).toContain("Zalo");
    expect(markup).toContain("Messenger");
    expect(markup).toContain("Facebook");
    expect(markup).toContain("Pháp lý:");
    expect(markup).toContain("Quy hoạch:");
    expect(markup).toContain("Vay vốn:");
    expect(markup).not.toContain(">Diện tích</p>");
    expect(markup).toContain('aria-label="Pháp lý và vay vốn"');
    expect(markup).toContain("flex-nowrap items-center gap-1.5 overflow-x-auto");
    expect(markup).toContain('src="https://example.com/son-tra.jpg"');
  });

  it("encodes property slugs safely for detail links", () => {
    expect(getPropertyDetailPath("nha-son-tra 2")).toBe("/bat-dong-san/nha-son-tra%202");
  });
});
