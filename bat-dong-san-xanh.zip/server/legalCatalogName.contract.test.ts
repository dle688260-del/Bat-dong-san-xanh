import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("legal catalog canonical name contract", () => {
  const routerSource = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
  const dbSource = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");

  it("overrides stale database placeholders with registry or verified appendix names", () => {
    expect(routerSource).toContain("getVerified2304ProcedureName");
    expect(routerSource).toContain("const canonicalName = getOfficialLandProcedure(item.code)?.name || getVerified2304ProcedureName(item.code);");
    expect(routerSource).toContain("return canonicalName ? { ...item, name: canonicalName } : item;");
  });

  it("keeps database materialization limited to placeholder names", () => {
    expect(dbSource).toContain("ensureLegalProcedureFromRegistry");
    expect(dbSource).toMatch(/placeholder|placeholder|cần đối soát/i);
  });
});

