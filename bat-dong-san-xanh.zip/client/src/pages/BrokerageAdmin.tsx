import React from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { FormEvent, useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  Building2,
  ClipboardCheck,
  Eye,
  FileCheck2,
  Globe2,
  GripVertical,
  Handshake,
  Landmark,
  Pencil,
  Plus,
  ScanLine,
  Search,
  Settings2,
  Trash2,
  Upload,
  Users,
  Video,
  WalletCards,
  X,
} from "lucide-react";
import { PROVINCE_OPTIONS } from "@/data/provinces";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import LegalDocumentScanner from "@/components/LegalDocumentScanner";
import ListingDocumentAutofill, {
  getListingOcrFormValues,
  type ListingOcrData,
} from "@/components/ListingDocumentAutofill";
import {
  LISTING_KIND_LABELS,
  LISTING_PROFILES,
  getListingProfile,
  type ListingKind,
  type ListingTransaction,
} from "@/lib/propertyListingRegistry";
import DynamicListingFields from "@/components/DynamicListingFields";
import {
  PropertyPostingTemplate,
  readGalleryLayout,
  type GalleryLayout,
} from "@/components/PropertyPostingTemplate";
import {
  getPropertyLayoutForCategory,
  PropertyLayoutPicker,
  PropertyLayoutRenderer,
  usePersistentPropertyLayoutConfig,
  type PropertyLayoutConfig,
  type PropertyDisplayLayout,
} from "@/components/PropertyLayoutRenderer";
import ThreeDAnnotationPanel from "@/components/ThreeDAnnotationPanel";

type Tab =
  | "properties"
  | "owners"
  | "buyers"
  | "survey"
  | "legal"
  | "valuation"
  | "deals";
const tabs: Array<{ key: Tab; label: string; icon: typeof Building2 }> = [
  { key: "properties", label: "Nguồn hàng", icon: Building2 },
  { key: "owners", label: "Chủ nhà", icon: Users },
  { key: "buyers", label: "Khách mua", icon: Search },
  { key: "survey", label: "Khảo sát", icon: ClipboardCheck },
  { key: "legal", label: "Pháp lý", icon: FileCheck2 },
  { key: "valuation", label: "Định giá", icon: WalletCards },
  { key: "deals", label: "Giao dịch", icon: Handshake },
];

export function normalizePropertyDecimal(value: string) {
  const raw = value
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/(m²|m2|㎡|tỷ|tỉ|ty)$/, "");
  if (!raw) return "";
  const normalized =
    raw.includes(",") && raw.includes(".")
      ? raw.lastIndexOf(",") > raw.lastIndexOf(".")
        ? raw.replace(/\./g, "").replace(",", ".")
        : raw.replace(/,/g, "")
      : raw.replace(/,/g, ".");
  return normalized.replace(/^\.(?=\d)/, "0.");
}

export function normalizePropertyType(value: string): ListingKind {
  const normalized = value
    .trim()
    .toLocaleLowerCase("vi")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  if (
    normalized.includes("can ho") ||
    normalized.includes("chung cu") ||
    normalized.includes("apartment")
  )
    return "apartment";
  if (
    normalized.includes("khu cong nghiep") ||
    normalized.includes("cong nghiep") ||
    normalized.includes("industrial")
  )
    return "industrial";
  if (
    normalized.includes("khu thuong mai") ||
    normalized.includes("commercial")
  )
    return "commercial";
  if (normalized.includes("biet thu") || normalized.includes("villa"))
    return "villa";
  if (
    normalized.includes("khu nghi duong") ||
    normalized.includes("nghi duong") ||
    normalized.includes("resort")
  )
    return "resort";
  if (
    normalized.includes("dat du an") ||
    normalized.includes("du an") ||
    normalized.includes("project")
  )
    return "project";
  if (
    normalized.includes("dat nong nghiep") ||
    normalized.includes("nong nghiep") ||
    normalized.includes("agricultural") ||
    normalized.includes("ruong")
  )
    return "agricultural";
  if (
    normalized.includes("dat thuong mai") ||
    normalized.includes("commercial land")
  )
    return "commercial_land";
  if (
    normalized.includes("cho thue khac") ||
    normalized.includes("bat dong san cho thue") ||
    normalized.includes("rental")
  )
    return "rental";
  if (
    normalized.includes("dat") ||
    normalized.includes("nen") ||
    normalized.includes("land")
  )
    return "land";
  return "house";
}

export function normalizePropertyArea(value: string) {
  const cleaned = value
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/(m²|m2|㎡|métvuông|metvuong)$/, "");
  if (!cleaned) return "";
  if (/^\d{1,3}(\.\d{3})+$/.test(cleaned)) return cleaned.replace(/\./g, "");
  return normalizePropertyDecimal(cleaned);
}

export function normalizePropertyMeasure(value: string) {
  const cleaned = value
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/(mét|met|m)$/, "")
    .replace(/[^\d,.-]/g, "");
  if (!cleaned) return "";
  if (/^\d{1,3}(\.\d{3})+$/.test(cleaned)) return cleaned.replace(/\./g, "");
  return normalizePropertyDecimal(cleaned);
}

export function isAcceptedPropertyImageUrl(value: string) {
  return /^https?:\/\//.test(value) || /^\/manus-storage\//.test(value);
}

export function removeUploadedImage(images: string[], url: string) {
  return images.filter(image => image !== url);
}

export function getGalleryLayout(imageCount: number) {
  if (imageCount <= 1) return { columns: 1, label: "1 ảnh" };
  if (imageCount === 2) return { columns: 2, label: "2 ảnh" };
  if (imageCount === 3) return { columns: 2, label: "3 ảnh" };
  return { columns: 3, label: "3+ ảnh" };
}

export function findAutomaticArea(
  location: string,
  areas: Array<{ id: number; name: string; province: string }>
) {
  const normalized = location.trim().toLocaleLowerCase("vi");
  const province =
    PROVINCE_OPTIONS.find(item =>
      normalized.includes(item.toLocaleLowerCase("vi"))
    ) || "";
  const area =
    areas.find(item =>
      normalized.includes(item.name.toLocaleLowerCase("vi"))
    ) || areas.find(item => province && item.province === province);
  return { province, areaId: area?.id ?? "" };
}

export function filterAreasByProvince(
  areas: Array<{ id: number; name: string; province: string }>,
  province: string
) {
  return province ? areas.filter(area => area.province === province) : areas;
}

export function buildPropertyPayload(
  text: (key: string) => string,
  num: (key: string) => number,
  negotiable: boolean
) {
  const location = [text("location"), text("province")]
    .map(value => value.trim())
    .filter(Boolean)
    .join(", ");
  const imageUrls = [
    "imageFront",
    "imageLivingRoom",
    "imageBedroom",
    "imageKitchen",
    "imageOutdoor",
    "imageRoad",
    "imageLegal",
  ]
    .flatMap(key =>
      text(key)
        .split(/\n|,/)
        .map(value => value.trim())
        .filter(Boolean)
    )
    .concat(
      text("imageUrls")
        .split(/\n|,/)
        .map(value => value.trim())
        .filter(Boolean)
    )
    .filter(isAcceptedPropertyImageUrl)
    .slice(0, 8);
  const videoUrls = text("videoUrls")
    .split(/\n|,/)
    .map(value => value.trim())
    .filter(Boolean)
    .filter(isAcceptedPropertyImageUrl)
    .slice(0, 4);
  const profile = getListingProfile(
    (text("listingType") || "sale") as ListingTransaction,
    normalizePropertyType(text("propertyType"))
  );
  const listingDetails = Object.fromEntries(
    profile.fields
      .map(field => [field.name, text(field.name).trim()])
      .filter(([, value]) => value)
  );
  listingDetails.galleryLayout = readGalleryLayout(text("galleryLayout"));
  const sourceMetadata = {
    sourceType: text("sourceType").trim(),
    sourceLabel: text("sourceLabel").trim(),
    transactionPurpose: text("transactionPurpose").trim(),
    transactionPurposeLabel: text("transactionPurposeLabel").trim(),
    propertyCategory: text("sourcePropertyCategory").trim(),
    propertySubtype: text("sourcePropertySubtype").trim(),
    sourceWorkflow: text("sourceWorkflow").trim(),
    sourceCode: text("sourceCode").trim(),
    warehouseGroup: text("warehouseGroup").trim(),
    intakeValues: text("sourceIntakeValues").trim(),
    workflowStepValues: text("sourceWorkflowStepValues").trim(),
    warehouseStage: text("sourceWarehouseStage").trim(),
    postSyncStatus: text("sourcePostSyncStatus").trim(),
  };
  Object.entries(sourceMetadata).forEach(([key, value]) => {
    if (value) listingDetails[key] = value;
  });
  return {
    title: text("title"),
    slug: text("slug"),
    propertyType: normalizePropertyType(text("propertyType")),
    listingType: (text("listingType") || "sale") as "sale" | "rent",
    price: normalizePropertyDecimal(text("price") || text("rentPrice")),
    area: normalizePropertyArea(text("area")),
    buildArea: normalizePropertyArea(text("buildArea")) || undefined,
    roadWidth: normalizePropertyMeasure(text("roadWidth")) || undefined,
    frontage: normalizePropertyMeasure(text("frontage")) || undefined,
    depth: normalizePropertyMeasure(text("depth")) || undefined,
    bedrooms: num("bedrooms") || undefined,
    bathrooms: num("bathrooms") || undefined,
    constructionYear: num("constructionYear") || undefined,
    location,
    areaId: num("areaId") || undefined,
    orientation: text("orientation") || undefined,
    distanceToMainRoad: text("distanceToMainRoad") || undefined,
    nearbySchools: text("nearbySchools") || undefined,
    nearbyMarket: text("nearbyMarket") || undefined,
    nearbyHospital: text("nearbyHospital") || undefined,
    distanceToCenter: text("distanceToCenter") || undefined,
    legalStatus: text("legalStatus") || undefined,
    certificateType: text("certificateType") || undefined,
    certificateArea:
      normalizePropertyArea(text("certificateArea")) || undefined,
    landUsePurpose: text("landUsePurpose") || undefined,
    planningStatus: text("planningStatus") || undefined,
    mortgageStatus: text("mortgageStatus") || undefined,
    legalSource: text("legalSource") || undefined,
    negotiable,
    brokerageFee: text("brokerageFee") || undefined,
    depositTerms: text("depositTerms") || undefined,
    transactionTerms: text("transactionTerms") || undefined,
    propertyCode: text("propertyCode") || undefined,
    ownerName: text("ownerName") || undefined,
    ownerPhone: text("ownerPhone") || undefined,
    brokerName: text("brokerName") || undefined,
    brokerPhone: text("brokerPhone") || undefined,
    brokerZalo: text("brokerZalo") || undefined,
    description: text("description") || undefined,
    listingDetails: JSON.stringify(listingDetails),
    imageUrls,
    videoUrls,
  };
}

export function getPropertySubmission(formData: FormData) {
  const text = (key: string) => String(formData.get(key) || "");
  const num = (key: string) => Number(formData.get(key) || 0);
  return buildPropertyPayload(text, num, formData.get("negotiable") === "on");
}

export function submitPropertyForm(
  formData: FormData,
  mutate: (payload: ReturnType<typeof getPropertySubmission>) => void
) {
  mutate(getPropertySubmission(formData));
}

export function getBrokerageErrorMessage(message: string) {
  if (message.includes("10002"))
    return "Tài khoản này chưa có quyền quản trị. Hãy đăng nhập đúng tài khoản chủ website hoặc liên hệ quản trị viên để được cấp role admin.";
  if (message.includes("10001")) return "Bạn cần đăng nhập trước khi đăng bài.";
  if (message.includes("Bài đã có hồ sơ pháp lý"))
    return "Bài đã có hồ sơ nghiệp vụ liên kết nên không thể xóa; hãy giữ lại để bảo toàn lịch sử giao dịch.";
  return message;
}

export const brokerageAccessGuidance =
  "Tài khoản thường có thể tạo nguồn hàng và lưu bài ở trạng thái Nháp; tài khoản role admin mới xem toàn bộ nguồn hàng và chuyển bài sang Công khai.";

export function getBrokerageAccessGuidance(user: { role?: string } | null | undefined) {
  if (!user) return "Bạn cần đăng nhập để mở khu vực Quản lý nguồn hàng.";
  return user.role === "admin"
    ? "Bạn đang dùng tài khoản quản trị: có thể xem toàn bộ nguồn hàng, kiểm duyệt và chuyển bài sang Công khai."
    : brokerageAccessGuidance;
}
export const MEDIA_PREPARATION_ACTIONS = [
  { key: "video", label: "Quay/Tải video" },
  { key: "3d", label: "Quét 3D" },
] as const;
export function isAcceptedProperty3DFile(fileName: string) {
  return /\.(usdz|glb|gltf|obj|ply|e57)$/i.test(fileName);
}
export function getPropertyDeleteDescription(title: string) {
  return `Bài “${title}” và toàn bộ ảnh liên quan sẽ bị xóa khỏi hệ thống. Thao tác này không thể hoàn tác.`;
}
export function confirmPropertyDeletion(
  id: number,
  confirmed: boolean,
  onDelete: (id: number) => void
) {
  if (confirmed) onDelete(id);
}
export function getSoldDossierRoute(propertyId: number) {
  return `/ai-ho-so-dat-dai?propertyId=${propertyId}`;
}
export function getSoldPropertyToastAction(
  propertyId: number,
  dealId?: number | null
) {
  return dealId
    ? { label: "Xem giao dịch", href: `/dashboard/giao-dich?dealId=${dealId}` }
    : { label: "Mở hồ sơ AI", href: getSoldDossierRoute(propertyId) };
}

export type SourceChannelKey =
  | "internal_broker"
  | "collaborator"
  | "owner"
  | "market"
  | "partner"
  | "project"
  | "ai"
  | "sale_advisor";

export const SOURCE_CREATION_PHASES = [
  "Chọn nguồn",
  "Loại giao dịch",
  "Chọn danh mục BĐS",
  "Chọn loại BĐS",
  "Mục đích sử dụng",
  "Nhập thông tin ban đầu",
  "Hệ thống xác định workflow",
  "Chạy workflow",
  "Kiểm duyệt",
  "Tạo mã nguồn",
  "Đưa vào kho",
] as const;

export const SOURCE_CHANNELS: Array<{
  key: SourceChannelKey;
  label: string;
  shortLabel: string;
  description: string;
  workflow: string[];
}> = [
  {
    key: "internal_broker",
    label: "Môi giới nội bộ",
    shortLabel: "MG nội bộ",
    description: "Nguồn do đội ngũ môi giới của sàn tiếp nhận và xác minh.",
    workflow: ["Tiếp nhận", "Hồ sơ môi giới", "Kiểm tra trùng", "Xác minh", "Khảo sát", "Quy hoạch", "Pháp lý", "Định giá", "Ký gửi", "Chuẩn hóa", "Kiểm duyệt", "Tạo mã", "Vào kho"],
  },
  {
    key: "collaborator",
    label: "Cộng tác viên",
    shortLabel: "CTV",
    description: "Nguồn do cộng tác viên chuyển về, có hồ sơ và chính sách CTV.",
    workflow: ["Tiếp nhận", "Hồ sơ CTV", "Kiểm tra", "Xác minh", "Khảo sát", "Quy hoạch", "Pháp lý", "Định giá", "Chính sách CTV", "Chuẩn hóa", "Kiểm duyệt", "Tạo mã", "Vào kho"],
  },
  {
    key: "owner",
    label: "Chủ nhà / chủ đất",
    shortLabel: "Chủ nhà",
    description: "Nguồn chính chủ cần khảo sát, xác minh và ký gửi.",
    workflow: ["Tiếp nhận", "Kiểm tra trùng", "Hẹn khảo sát", "Khảo sát sơ bộ", "Khảo sát thực tế", "Quy hoạch", "Pháp lý", "Định giá", "Hợp đồng ký gửi", "Chuẩn hóa", "Kiểm duyệt", "Tạo mã", "Vào kho"],
  },
  {
    key: "market",
    label: "Nguồn thị trường",
    shortLabel: "Thị trường",
    description: "Nguồn phát hiện trên thị trường, cần thu thập và xác minh lại.",
    workflow: ["Phát hiện", "Thu thập", "Chuẩn hóa", "Kiểm tra trùng", "Phân tích thị trường", "Xác minh", "Xác minh BĐS", "Quy hoạch", "Pháp lý", "Định giá", "Kiểm duyệt", "Tạo mã", "Vào kho"],
  },
  {
    key: "partner",
    label: "Đối tác",
    shortLabel: "Đối tác",
    description: "Nguồn từ đơn vị hợp tác, cần kiểm tra quyền khai thác và thỏa thuận.",
    workflow: ["Tiếp nhận", "Hồ sơ đối tác", "Kiểm tra trùng", "Quyền khai thác", "Xác minh BĐS", "Quy hoạch", "Pháp lý", "Kiểm tra giá", "Thỏa thuận", "Chuẩn hóa", "Kiểm duyệt", "Tạo mã", "Vào kho"],
  },
  {
    key: "project",
    label: "Dự án",
    shortLabel: "Dự án",
    description: "Nguồn dự án gồm hồ sơ chủ đầu tư, bảng giá và danh mục sản phẩm.",
    workflow: ["Tiếp nhận dự án", "Hồ sơ chủ đầu tư", "Vị trí", "Pháp lý", "Quy hoạch", "Tiến độ", "Danh mục sản phẩm", "Bảng giá", "Chính sách", "Chuẩn hóa", "Kiểm duyệt", "Tạo mã dự án", "Tạo mã sản phẩm", "Vào kho"],
  },
  {
    key: "ai",
    label: "AI tìm kiếm",
    shortLabel: "AI",
    description: "AI thu thập và chuẩn hóa; con người bắt buộc xác minh và duyệt.",
    workflow: ["Thiết lập tiêu chí", "AI tìm kiếm", "AI thu thập", "AI chuẩn hóa", "AI kiểm tra trùng", "AI phân tích", "AI chấm điểm", "Con người xác minh", "Quy hoạch", "Pháp lý", "Định giá", "Con người duyệt", "Tạo mã", "Vào kho"],
  },
  {
    key: "sale_advisor",
    label: "Sale tư vấn",
    shortLabel: "Sale tư vấn",
    description: "Nguồn do Sale tư vấn tiếp nhận từ khách hàng và nhập vào hệ thống để xử lý tiếp.",
    workflow: ["Tiếp nhận thông tin", "Nhập dữ liệu khách", "Xác định nhu cầu", "Kiểm tra trùng", "Xác minh BĐS", "Quy hoạch", "Pháp lý", "Định giá", "Tư vấn phương án", "Chuẩn hóa", "Kiểm duyệt", "Tạo mã", "Vào kho"],
  },
];

export const SOURCE_PROPERTY_CATEGORIES: Array<{
  key: string;
  label: string;
  defaultKind: ListingKind;
  subtypes: string[];
}> = [
  { key: "housing", label: "Nhà ở", defaultKind: "house", subtypes: ["Nhà riêng", "Nhà phố", "Nhà mặt tiền", "Nhà hẻm", "Nhà cấp 4", "Nhà nhiều tầng", "Biệt thự", "Villa", "Nhà vườn", "Liền kề", "Shophouse"] },
  { key: "land", label: "Đất", defaultKind: "land", subtypes: ["Đất ở", "Đất nền", "Đất nông nghiệp", "Đất cây lâu năm", "Đất cây hàng năm", "Đất thủy sản", "Đất lâm nghiệp", "Đất thương mại", "Đất sản xuất kinh doanh"] },
  { key: "apartment", label: "Căn hộ", defaultKind: "apartment", subtypes: ["Chung cư", "Căn hộ cao cấp", "Căn hộ dịch vụ", "Studio", "Officetel", "Penthouse", "Duplex", "Sky Villa"] },
  { key: "commercial", label: "Thương mại", defaultKind: "commercial", subtypes: ["Shophouse", "Mặt bằng", "Cửa hàng", "Ki-ốt", "Văn phòng", "Building", "Nhà hàng", "Khách sạn"] },
  { key: "resort", label: "Nghỉ dưỡng", defaultKind: "resort", subtypes: ["Resort", "Condotel", "Villa nghỉ dưỡng", "Biệt thự biển", "Bungalow", "Homestay"] },
  { key: "industrial", label: "Công nghiệp", defaultKind: "industrial", subtypes: ["Đất KCN", "Nhà xưởng", "Kho", "Logistics", "Nhà máy", "Cụm công nghiệp"] },
  { key: "agricultural", label: "Nông nghiệp", defaultKind: "agricultural", subtypes: ["Trang trại", "Vườn", "Farm", "Chăn nuôi", "Thủy sản"] },
  { key: "project", label: "Dự án", defaultKind: "project", subtypes: ["Căn hộ dự án", "Nhà phố dự án", "Biệt thự dự án", "Đất nền dự án", "Shophouse dự án", "Nghỉ dưỡng", "Đô thị", "Khu công nghiệp"] },
  { key: "special", label: "BĐS đặc thù", defaultKind: "commercial", subtypes: ["Tòa nhà", "Cao ốc", "Bệnh viện", "Trường học", "Công trình thương mại", "Công trình dịch vụ"] },
];

export const SOURCE_TRANSACTION_TYPES = [
  { key: "buy", label: "Mua" },
  { key: "sell", label: "Bán" },
  { key: "rent_in", label: "Thuê" },
  { key: "rent_out", label: "Cho thuê" },
  { key: "transfer", label: "Sang nhượng" },
] as const;
export type SourceTransactionType = (typeof SOURCE_TRANSACTION_TYPES)[number]["key"];

export const SOURCE_USE_PURPOSES = [
  { key: "living", label: "Để ở" },
  { key: "investment", label: "Đầu tư" },
  { key: "business", label: "Kinh doanh" },
  { key: "rental", label: "Cho thuê" },
  { key: "resort", label: "Nghỉ dưỡng" },
  { key: "construction", label: "Xây dựng" },
  { key: "other", label: "Khác" },
] as const;
export type SourceUsePurpose = (typeof SOURCE_USE_PURPOSES)[number]["key"];

export const SOURCE_TRANSACTION_PURPOSES = [
  ...SOURCE_TRANSACTION_TYPES.map(item => ({ key: item.key, label: item.label })),
] as const;
export type SourceTransactionPurpose = SourceTransactionType;

export type SourceCreationContext = {
  sourceType: SourceChannelKey;
  sourceLabel: string;
  transactionPurpose: SourceTransactionPurpose;
  transactionPurposeLabel: string;
  usePurpose?: SourceUsePurpose;
  usePurposeLabel?: string;
  propertyCategory: string;
  propertySubtype: string;
  propertyKind: ListingKind;
  workflow: string[];
  sourceCode?: string;
  warehouseGroup?: string;
  intakeValues?: Record<string, string>;
  workflowStepValues?: Record<string, string>;
  warehouseStage?: "initial_intake" | "post_draft" | "sales_warehouse";
  postSyncStatus?: string;
};

type SourceProcedureField = {
  id: string;
  label: string;
  type: "text" | "number" | "date" | "textarea" | "select" | "checkbox";
  required?: boolean;
  placeholder?: string;
  options?: string[];
  hint?: string;
};

type SourceProcedureModule = {
  id: string;
  title: string;
  summary: string;
  fields: SourceProcedureField[];
  actions: string[];
};

export type SourceWorkflowStepSchema = {
  id: string;
  title: string;
  task: string;
  fields: SourceProcedureField[];
  validation: string[];
  condition: string;
  aiAction: string;
  document: string;
  results: string[];
  responsibility?: "ai" | "human" | "hybrid";
  humanAction?: string;
  warehouseCondition?: string;
  automationMode?: "human" | "ai_review" | "hybrid";
  aiOutputFields?: SourceProcedureField[];
};

export type SourceWorkflowStepAiLog = {
  id: string;
  timestamp: string;
  step: string;
  checkType: string;
  inputData: string;
  result: string;
  severity: "info" | "warning" | "critical";
  recommendation: string;
  reviewerStatus: "pending" | "confirmed" | "rejected";
  reviewedAt?: string;
  reviewerNotes?: string;
};

export function readSourceWorkflowStepAiLogs(values: Record<string, string>, stepId: string): SourceWorkflowStepAiLog[] {
  try {
    const parsed = JSON.parse(values[`${stepId}-aiLogs`] || "[]") as SourceWorkflowStepAiLog[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

type SourceWorkflowFileRecord = {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  status: "uploading" | "ocr_complete" | "stored" | "unsupported" | "error";
  url?: string;
  storageKey?: string;
  uploadedAt: string;
  ocrFieldIds?: string[];
  error?: string;
};

type SourceWorkflowOcrPreviewField = {
  id: string;
  label: string;
  value: string;
  fieldId?: string;
  confidence: number;
  evidence?: string;
};

export function readSourceWorkflowFiles(values: Record<string, string>, stepId: string): SourceWorkflowFileRecord[] {
  try {
    const parsed = JSON.parse(values[`${stepId}-fileEntries`] || "[]") as SourceWorkflowFileRecord[];
    if (Array.isArray(parsed) && parsed.length > 0) return parsed;
  } catch {
    // Fall through to the legacy single-file snapshot below.
  }
  const legacyName = values[`${stepId}-files`]?.trim();
  return legacyName
    ? [{ id: `${stepId}-legacy`, name: legacyName, size: 0, mimeType: "", status: "stored", uploadedAt: new Date().toISOString() }]
    : [];
}

export function readSourceWorkflowOcrPreview(values: Record<string, string>, stepId: string): SourceWorkflowOcrPreviewField[] {
  try {
    const parsed = JSON.parse(values[`${stepId}-ocrPreview`] || "[]") as SourceWorkflowOcrPreviewField[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function formatSourceWorkflowFileSize(size: number) {
  if (!size) return "Kích thước chưa lưu";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.ceil(size / 1024)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export const SOURCE_COMMON_STEP_FIELDS: SourceProcedureField[] = [
  { id: "assetName", label: "Tên nguồn / tên tài sản", type: "text", required: true, placeholder: "Nhập tên nguồn / tên tài sản..." },
  { id: "providerName", label: "Người cung cấp", type: "text", required: true, placeholder: "Nhập người cung cấp..." },
  { id: "providerPhone", label: "Số điện thoại", type: "text", placeholder: "Nhập số điện thoại..." },
  { id: "providerEmail", label: "Email liên hệ", type: "text", placeholder: "Nhập email liên hệ..." },
  { id: "propertyRelationship", label: "Quan hệ với BĐS", type: "text", placeholder: "Nhập quan hệ với BĐS..." },
  { id: "assetArea", label: "Khu vực tài sản", type: "text", required: true, placeholder: "Nhập khu vực tài sản..." },
  { id: "assetAddress", label: "Địa chỉ chi tiết", type: "textarea", required: true, placeholder: "Nhập địa chỉ chi tiết..." },
  { id: "assetType", label: "Loại BĐS", type: "text", required: true, placeholder: "Nhập loại BĐS..." },
  { id: "transactionPurpose", label: "Mục đích giao dịch", type: "text", required: true, placeholder: "Nhập mục đích giao dịch..." },
  { id: "expectedPrice", label: "Giá kỳ vọng", type: "number", placeholder: "Nhập giá kỳ vọng..." },
  { id: "referralSource", label: "Nguồn giới thiệu", type: "text", placeholder: "Nhập nguồn giới thiệu..." },
  { id: "receiverName", label: "Người tiếp nhận", type: "text", required: true, placeholder: "Nhập người tiếp nhận..." },
  { id: "intakeChannel", label: "Kênh tiếp nhận", type: "text", placeholder: "Nhập kênh tiếp nhận..." },
  { id: "initialNote", label: "Ghi chú ban đầu", type: "textarea", placeholder: "Nhập nội dung..." },
  { id: "sourceCodeForm", label: "Mã nguồn", type: "text", required: true, placeholder: "Nhập mã nguồn..." },
  { id: "propertyCodeForm", label: "Mã BĐS / sản phẩm", type: "text", placeholder: "Nhập mã BĐS / sản phẩm..." },
  { id: "caseOwner", label: "Người phụ trách", type: "text", required: true, placeholder: "Nhập người phụ trách..." },
  { id: "priorityLevel", label: "Mức ưu tiên", type: "select", options: ["Thấp", "Trung bình", "Cao", "Khẩn cấp"] },
  { id: "processingDeadline", label: "Hạn xử lý", type: "date", required: true },
  { id: "internalNote", label: "Ghi chú nội bộ", type: "textarea", placeholder: "Nhập nội dung..." },
];

export const SOURCE_PROCEDURE_MODULES: SourceProcedureModule[] = [
  {
    id: "intake",
    title: "Tiếp nhận nguồn",
    summary: "Ghi nhận nguồn, người giới thiệu, nhân sự tiếp nhận và quyền liên hệ.",
    fields: [
      { id: "intakeCode", label: "Mã phiếu tiếp nhận", type: "text", required: true, placeholder: "TN-2026-..." },
      { id: "receivedAt", label: "Ngày tiếp nhận", type: "date", required: true },
      { id: "referrerName", label: "Người cung cấp / giới thiệu", type: "text", required: true },
      { id: "referrerPhone", label: "Số điện thoại", type: "text", required: true },
      { id: "assignedBroker", label: "Môi giới phụ trách", type: "text", required: true },
      { id: "contactPermission", label: "Đã được phép liên hệ và lưu thông tin", type: "checkbox", required: true },
    ],
    actions: ["Lưu phiếu tiếp nhận", "Kiểm tra trùng", "Chuyển xác minh"],
  },
  {
    id: "owner",
    title: "Chủ nguồn / Chủ sở hữu",
    summary: "Quản lý chủ thể, đồng sở hữu, liên hệ và kết quả xác minh ban đầu.",
    fields: [
      { id: "ownerType", label: "Loại chủ thể", type: "select", required: true, options: ["Cá nhân", "Đồng sở hữu", "Doanh nghiệp", "Chủ đầu tư", "Đại diện / Ủy quyền"] },
      { id: "ownerFullName", label: "Họ tên / Tên đơn vị", type: "text", required: true },
      { id: "ownerIdentity", label: "CCCD / Mã số doanh nghiệp", type: "text" },
      { id: "ownerPhone", label: "Điện thoại chính", type: "text", required: true },
      { id: "coOwners", label: "Đồng sở hữu / Người liên quan", type: "textarea", placeholder: "Ghi từng người và vai trò" },
      { id: "ownerVerified", label: "Đã xác minh đúng chủ thể", type: "checkbox", required: true },
    ],
    actions: ["OCR giấy tờ chủ thể", "Đối chiếu liên hệ", "Xác nhận chủ nguồn"],
  },
  {
    id: "property",
    title: "Thông tin BĐS đầy đủ",
    summary: "Địa chỉ, vị trí, kích thước, hiện trạng, kết cấu và khả năng tiếp cận.",
    fields: [
      { id: "fullAddress", label: "Địa chỉ đầy đủ", type: "textarea", required: true },
      { id: "province", label: "Tỉnh / Thành phố", type: "text", required: true },
      { id: "district", label: "Quận / Huyện", type: "text", required: true },
      { id: "ward", label: "Phường / Xã", type: "text" },
      { id: "mapLocation", label: "Tọa độ / Link bản đồ", type: "text" },
      { id: "landArea", label: "Diện tích đất (m²)", type: "number", required: true },
      { id: "usableArea", label: "Diện tích sử dụng (m²)", type: "number" },
      { id: "frontageWidth", label: "Mặt tiền (m)", type: "number" },
      { id: "roadWidth", label: "Đường trước BĐS (m)", type: "number" },
      { id: "propertyDirection", label: "Hướng", type: "select", options: ["Đông", "Tây", "Nam", "Bắc", "Đông Bắc", "Đông Nam", "Tây Bắc", "Tây Nam"] },
      { id: "propertyCondition", label: "Hiện trạng / Kết cấu", type: "textarea", required: true },
      { id: "occupancy", label: "Tình trạng sử dụng", type: "select", options: ["Đang trống", "Chủ đang ở", "Đang cho thuê", "Đang xây dựng", "Đang khai thác"] },
    ],
    actions: ["Định vị bản đồ", "Kiểm tra trùng địa chỉ", "Chuyển khảo sát"],
  },
  {
    id: "survey",
    title: "Khảo sát thực tế",
    summary: "Lịch khảo sát, hiện trạng, đường đi, hạ tầng, tiện ích và bằng chứng media.",
    fields: [
      { id: "surveySchedule", label: "Lịch khảo sát", type: "date", required: true },
      { id: "surveyor", label: "Người khảo sát", type: "text", required: true },
      { id: "actualCondition", label: "Hiện trạng thực tế", type: "textarea", required: true },
      { id: "accessRoad", label: "Đường vào / Khả năng tiếp cận", type: "textarea" },
      { id: "utilities", label: "Hạ tầng và tiện ích xung quanh", type: "textarea" },
      { id: "surveyPhotosReady", label: "Đã có ảnh khảo sát", type: "checkbox", required: true },
      { id: "surveyVideoReady", label: "Đã có video hoặc dữ liệu 3D (nếu có)", type: "checkbox" },
    ],
    actions: ["Chụp / tải ảnh", "Quay / tải video", "Lập biên bản khảo sát"],
  },
  {
    id: "planning",
    title: "Quy hoạch",
    summary: "Thông tin thửa đất, nguồn tra cứu, chỉ giới và cảnh báo quy hoạch.",
    fields: [
      { id: "parcelNumber", label: "Số thửa", type: "text" },
      { id: "mapSheet", label: "Tờ bản đồ", type: "text" },
      { id: "planningSource", label: "Nguồn kiểm tra quy hoạch", type: "text", required: true },
      { id: "planningResult", label: "Kết quả quy hoạch", type: "select", required: true, options: ["Phù hợp", "Có một phần quy hoạch", "Thuộc quy hoạch", "Chưa đủ dữ liệu", "Cần xác minh"] },
      { id: "constructionBoundary", label: "Lộ giới / Chỉ giới xây dựng", type: "textarea" },
      { id: "planningRisk", label: "Rủi ro và lưu ý", type: "textarea" },
      { id: "planningHumanConfirmed", label: "Môi giới đã đối chiếu kết quả", type: "checkbox", required: true },
    ],
    actions: ["Tải bản đồ / văn bản", "AI hỗ trợ đọc", "Xác nhận kết quả"],
  },
  {
    id: "legal",
    title: "Pháp lý & Giấy tờ OCR",
    summary: "Giấy chứng nhận, chủ thể pháp lý, thế chấp, tranh chấp và tài liệu liên quan.",
    fields: [
      { id: "certificateType", label: "Loại giấy chứng nhận", type: "select", required: true, options: ["Sổ đỏ", "Sổ hồng", "Hợp đồng mua bán", "Quyết định giao đất", "Giấy tờ khác", "Chưa có"] },
      { id: "certificateNumber", label: "Số phát hành / Số vào sổ", type: "text" },
      { id: "certificateIssuedAt", label: "Ngày cấp", type: "date" },
      { id: "legalOwner", label: "Chủ thể trên giấy tờ", type: "text", required: true },
      { id: "landUsePurpose", label: "Mục đích sử dụng đất", type: "text" },
      { id: "mortgageStatus", label: "Tình trạng thế chấp", type: "select", options: ["Không thế chấp", "Đang thế chấp", "Đã giải chấp", "Chưa xác minh"] },
      { id: "disputeStatus", label: "Tình trạng tranh chấp / ngăn chặn", type: "select", options: ["Không ghi nhận", "Có cảnh báo", "Đang tranh chấp", "Chưa xác minh"] },
      { id: "legalNotes", label: "Tài liệu còn thiếu / Lưu ý pháp lý", type: "textarea" },
      { id: "ocrHumanConfirmed", label: "Đã kiểm tra và xác nhận dữ liệu OCR", type: "checkbox", required: true },
    ],
    actions: ["Tải / chụp giấy tờ", "Chạy OCR", "Đối chiếu và xác nhận"],
  },
  {
    id: "valuation",
    title: "Định giá",
    summary: "Giá chủ đề nghị, giá phân tích, dữ liệu so sánh và mức độ thanh khoản.",
    fields: [
      { id: "askingPrice", label: "Giá chủ đề nghị", type: "number", required: true },
      { id: "suggestedPrice", label: "Giá đề xuất", type: "number", required: true },
      { id: "minimumPrice", label: "Giá tối thiểu có thể đàm phán", type: "number" },
      { id: "comparisonData", label: "BĐS so sánh / Căn cứ", type: "textarea", required: true },
      { id: "liquidity", label: "Đánh giá thanh khoản", type: "select", options: ["Cao", "Trung bình", "Thấp", "Cần theo dõi"] },
      { id: "valuationConfidence", label: "Độ tin cậy", type: "select", options: ["Cao", "Trung bình", "Thấp"] },
      { id: "valuationApproved", label: "Môi giới đã duyệt mức giá", type: "checkbox", required: true },
    ],
    actions: ["AI phân tích giá", "Thêm BĐS so sánh", "Duyệt giá"],
  },
  {
    id: "negotiation",
    title: "Đàm phán & Ký gửi",
    summary: "Giá chốt làm việc, thời hạn, hoa hồng, độc quyền và điều kiện ký gửi.",
    fields: [
      { id: "negotiatedPrice", label: "Giá thống nhất để chào bán", type: "number", required: true },
      { id: "commission", label: "Hoa hồng / Phí môi giới", type: "text", required: true },
      { id: "consignmentType", label: "Hình thức ký gửi", type: "select", required: true, options: ["Không độc quyền", "Độc quyền", "Hợp tác phân phối", "Chưa ký"] },
      { id: "consignmentStart", label: "Ngày bắt đầu", type: "date" },
      { id: "consignmentEnd", label: "Ngày hết hạn", type: "date" },
      { id: "negotiationTerms", label: "Điều kiện đàm phán / giao dịch", type: "textarea" },
      { id: "consignmentSigned", label: "Đã có xác nhận / hợp đồng ký gửi", type: "checkbox", required: true },
    ],
    actions: ["Tải mẫu ký gửi", "Tạo biên bản", "Xác nhận quyền khai thác"],
  },
  {
    id: "media",
    title: "Media & Nội dung bán hàng",
    summary: "Ảnh, video, 3D, tiêu đề, điểm nổi bật và nội dung công khai.",
    fields: [
      { id: "listingTitle", label: "Tiêu đề nội bộ / công khai", type: "text", required: true },
      { id: "sellingPoints", label: "Điểm nổi bật", type: "textarea", required: true },
      { id: "publicDescription", label: "Mô tả sản phẩm", type: "textarea", required: true },
      { id: "imageSetReady", label: "Đủ ảnh bìa, nội thất, ngoại thất, đường và pháp lý", type: "checkbox", required: true },
      { id: "videoSetReady", label: "Đã kiểm tra video / 3D", type: "checkbox" },
      { id: "publishChannels", label: "Kênh dự kiến", type: "textarea", placeholder: "Website, Facebook, TikTok, Zalo..." },
    ],
    actions: ["Mở kho ảnh", "Mở video / 3D", "AI soạn nội dung"],
  },
  {
    id: "review",
    title: "Kiểm duyệt chất lượng",
    summary: "Checklist bắt buộc trước khi tạo mã và đưa nguồn vào kho.",
    fields: [
      { id: "duplicateChecked", label: "Đã kiểm tra trùng nguồn / trùng BĐS", type: "checkbox", required: true },
      { id: "ownerChecked", label: "Đã xác minh chủ nguồn", type: "checkbox", required: true },
      { id: "locationChecked", label: "Đã xác minh vị trí / khảo sát", type: "checkbox", required: true },
      { id: "legalChecked", label: "Đã rà soát pháp lý và cảnh báo", type: "checkbox", required: true },
      { id: "priceChecked", label: "Đã duyệt giá", type: "checkbox", required: true },
      { id: "mediaChecked", label: "Đã duyệt media / nội dung", type: "checkbox", required: true },
      { id: "reviewer", label: "Người kiểm duyệt", type: "text", required: true },
      { id: "reviewDecision", label: "Quyết định", type: "select", required: true, options: ["Duyệt vào kho", "Yêu cầu bổ sung", "Tạm dừng", "Từ chối"] },
      { id: "reviewNotes", label: "Ghi chú kiểm duyệt", type: "textarea" },
    ],
    actions: ["Kiểm tra thiếu", "Gửi bổ sung", "Duyệt nguồn"],
  },
  {
    id: "inventory",
    title: "Tạo mã & Đưa vào kho",
    summary: "Mã nguồn, mã BĐS, trạng thái kho, mức hiển thị và đội phụ trách.",
    fields: [
      { id: "sourceCode", label: "Mã nguồn", type: "text", required: true, placeholder: "NG-2026-..." },
      { id: "propertyCode", label: "Mã BĐS", type: "text", required: true, placeholder: "BDS-2026-..." },
      { id: "inventoryStatus", label: "Trạng thái kho", type: "select", required: true, options: ["Nguồn mới", "Đang xác minh", "Đang khảo sát", "Đang bán", "Tạm dừng", "Đã bán", "Hết hạn"] },
      { id: "warehouseGroup", label: "Nhóm kho", type: "select", required: true, options: ["Thị trường", "Cộng tác", "Tồn kho", "Đang khảo sát", "Dự án", "Đã bán"] },
      { id: "visibility", label: "Mức hiển thị", type: "select", required: true, options: ["Nội bộ", "Đội phụ trách", "Cộng tác viên", "Công khai website"] },
      { id: "assignedTeam", label: "Đội / Nhân sự phụ trách", type: "text" },
    ],
    actions: ["Sinh mã", "Lưu vào kho", "Chuyển bài đăng"],
  },
  {
    id: "audit",
    title: "AI, Nhật ký & Bước tiếp theo",
    summary: "Lưu vết đề xuất AI, xác nhận con người, thay đổi và nhiệm vụ tiếp theo.",
    fields: [
      { id: "aiSummary", label: "Tóm tắt / Đề xuất AI", type: "textarea" },
      { id: "aiWarnings", label: "Cảnh báo cần kiểm tra", type: "textarea" },
      { id: "humanConfirmation", label: "Người dùng xác nhận chịu trách nhiệm dữ liệu", type: "checkbox", required: true },
      { id: "nextAction", label: "Bước tiếp theo", type: "text", required: true },
      { id: "nextActionDate", label: "Hạn xử lý", type: "date" },
      { id: "auditNotes", label: "Nhật ký / Ghi chú nội bộ", type: "textarea" },
    ],
    actions: ["Lưu snapshot", "Tạo nhiệm vụ", "Xem lịch sử"],
  },
];

export function getSourceProcedureCompletion(values: Record<string, string | boolean>) {
  const required = SOURCE_PROCEDURE_MODULES.flatMap(module => module.fields.filter(field => field.required));
  const completed = required.filter(field => values[field.id] === true || String(values[field.id] || "").trim()).length;
  return { completed, total: required.length, percent: required.length ? Math.round((completed / required.length) * 100) : 0 };
}

export function getSourceCreationContext(
  sourceType: SourceChannelKey,
  transactionType: SourceTransactionType | "",
  usePurposeOrCategory: SourceUsePurpose | string,
  categoryOrSubtype: string,
  propertySubtype?: string
): SourceCreationContext | null {
  const legacySignature = propertySubtype === undefined;
  const usePurpose = (legacySignature ? "other" : usePurposeOrCategory) as SourceUsePurpose;
  const categoryKey = legacySignature ? usePurposeOrCategory : categoryOrSubtype;
  const resolvedSubtype = legacySignature ? categoryOrSubtype : propertySubtype;
  const source = SOURCE_CHANNELS.find(item => item.key === sourceType);
  const legacyTransactionType = transactionType as string;
  const resolvedTransactionType = legacyTransactionType === "sale" ? "sell" : legacyTransactionType === "rent" ? "rent_out" : legacyTransactionType;
  const transaction = SOURCE_TRANSACTION_TYPES.find(item => item.key === resolvedTransactionType);
  const use = SOURCE_USE_PURPOSES.find(item => item.key === usePurpose);
  const category = SOURCE_PROPERTY_CATEGORIES.find(item => item.key === categoryKey);
  if (!source || !transaction || !use || !category || !category.subtypes.includes(resolvedSubtype)) return null;
  const inferredKind = normalizePropertyType(resolvedSubtype);
  return {
    sourceType,
    sourceLabel: source.label,
    transactionPurpose: transaction.key,
    transactionPurposeLabel: transaction.label,
    usePurpose: use.key,
    usePurposeLabel: use.label,
    propertyCategory: category.label,
    propertySubtype: resolvedSubtype,
    propertyKind:
      inferredKind === "house" && category.defaultKind !== "house"
        ? category.defaultKind
        : inferredKind,
    workflow: source.workflow,
  };
}

export type SourceStepRoute = "human_intake" | "ai_automation" | "hybrid_review";
export const HUMAN_INTAKE_STEP_NAMES = ["tiếp nhận", "nhập dữ liệu", "khảo sát", "hẹn khảo sát", "quy hoạch", "pháp lý", "định giá", "ký gửi"];
export const AI_AUTOMATION_STEP_NAMES = ["xác minh", "chuẩn hóa", "kiểm duyệt", "tạo mã", "vào kho", "kiểm tra trùng", "phân tích thị trường"];
export function getSourceStepRoute(step: string): SourceStepRoute {
  const normalized = step.toLocaleLowerCase("vi");
  if (HUMAN_INTAKE_STEP_NAMES.some(name => normalized.includes(name))) return "human_intake";
  if (AI_AUTOMATION_STEP_NAMES.some(name => normalized.includes(name))) return "ai_automation";
  return "hybrid_review";
}
export function getWorkflowStepResponsibility(step: string, sourceType: SourceChannelKey): { mode: "ai" | "human" | "hybrid"; route: SourceStepRoute; label: string; action: string; warehouseCondition: string } {
  const normalized = step.toLocaleLowerCase("vi");
  if (normalized.includes("tìm kiếm") || normalized.includes("thu thập") || normalized.includes("chuẩn hóa") || normalized.includes("kiểm tra trùng") || normalized.includes("phân tích") || normalized.includes("chấm điểm") || normalized.includes("phát hiện")) {
    return { mode: "hybrid", route: getSourceStepRoute(step), label: "AI phân tích · Người kiểm tra", action: "AI đề xuất từ dữ liệu, OCR hoặc nguồn tham chiếu; người phụ trách kiểm tra và xác nhận kết quả.", warehouseCondition: "Chưa được đưa vào kho nếu chưa có xác nhận của người phụ trách." };
  }
  if (normalized.includes("quy hoạch") || normalized.includes("pháp lý") || normalized.includes("định giá") || normalized.includes("xác minh") || normalized.includes("kiểm tra giá") || normalized.includes("vị trí") || normalized.includes("tiến độ")) {
    return { mode: "hybrid", route: getSourceStepRoute(step), label: "AI đối chiếu · Chuyên viên duyệt", action: "AI đọc và đối chiếu tài liệu, bản đồ hoặc dữ liệu giá; chuyên viên chịu trách nhiệm kết luận nghiệp vụ.", warehouseCondition: "Chỉ chuyển bước khi hồ sơ có kết quả và người duyệt xác nhận." };
  }
  if (normalized.includes("tạo mã") || normalized.includes("vào kho") || normalized.includes("kiểm duyệt") || normalized.includes("con người") || normalized.includes("ký gửi") || normalized.includes("hợp đồng") || normalized.includes("thỏa thuận")) {
    return { mode: "human", route: getSourceStepRoute(step), label: "Con người thực hiện", action: "Nhân sự đăng nhập nhập dữ liệu, kiểm tra checklist và xác nhận quyết định cuối cùng.", warehouseCondition: "Đủ trường bắt buộc, tài liệu cần thiết và quyết định duyệt thì mới đưa vào kho." };
  }
  return { mode: "human", route: getSourceStepRoute(step), label: "Nhân sự tiếp nhận", action: `Nhân sự phụ trách nguồn ${SOURCE_CHANNELS.find(item => item.key === sourceType)?.shortLabel || ""} nhập và xác nhận thông tin ban đầu.`, warehouseCondition: "Lưu nháp trước; chỉ chuyển bước sau khi hoàn tất trường bắt buộc." };
}

const SOURCE_STEP_FORM_FIELDS: Record<string, SourceProcedureField[]> = {
  intake: [
    { id: "receivedAt", label: "Ngày tiếp nhận", type: "date", required: true },
    { id: "sourceContact", label: "Người cung cấp / đầu mối", type: "text", required: true, placeholder: "Tên người hoặc đơn vị cung cấp" },
    { id: "contactPhone", label: "Điện thoại liên hệ", type: "text", required: true },
    { id: "intakeChannelDetail", label: "Kênh tiếp nhận và căn cứ", type: "textarea", required: true },
  ],
  owner: [
    { id: "ownerName", label: "Họ tên / tên chủ thể", type: "text", required: true },
    { id: "ownerIdentity", label: "CCCD / mã số doanh nghiệp", type: "text" },
    { id: "ownershipRelation", label: "Quan hệ với tài sản", type: "select", required: true, options: ["Chủ sở hữu", "Đồng sở hữu", "Đại diện ủy quyền", "Môi giới giới thiệu", "Chưa xác minh"] },
    { id: "ownerContactResult", label: "Kết quả xác nhận chủ thể", type: "textarea", required: true },
  ],
  property: [
    { id: "propertyAddress", label: "Địa chỉ / vị trí BĐS", type: "textarea", required: true },
    { id: "landArea", label: "Diện tích đất (m²)", type: "number", required: true },
    { id: "propertyCondition", label: "Hiện trạng và kết cấu", type: "textarea", required: true },
    { id: "locationEvidence", label: "Ảnh / tọa độ / link bản đồ", type: "text", required: true },
  ],
  survey: [
    { id: "surveyDate", label: "Ngày khảo sát", type: "date", required: true },
    { id: "surveyorName", label: "Người khảo sát", type: "text", required: true },
    { id: "currentArea", label: "Diện tích BĐS thực tế (m²)", type: "number", required: true, hint: "Bắt buộc > 0; đối chiếu giấy chứng nhận" },
    { id: "currentImages", label: "Hình ảnh hiện trạng", type: "text", required: true, placeholder: "Tối thiểu 6 ảnh: mặt tiền, lối vào, các phòng, ranh đất" },
    { id: "actualCondition", label: "Hiện trạng thực tế", type: "textarea", required: true },
    { id: "accessAndUtilities", label: "Đường vào, hạ tầng và tiện ích", type: "textarea", required: true },
    { id: "surveyEvidence", label: "Ảnh / video / dữ liệu 3D khảo sát", type: "text", required: true },
  ],
  planning: [
    { id: "parcelReference", label: "Số thửa / tờ bản đồ", type: "text", required: true },
    { id: "planningSource", label: "Nguồn tra cứu quy hoạch", type: "text", required: true },
    { id: "planningResult", label: "Kết quả quy hoạch", type: "select", required: true, options: ["Phù hợp", "Có một phần quy hoạch", "Thuộc quy hoạch", "Chưa đủ dữ liệu", "Cần xác minh"] },
    { id: "planningBoundary", label: "Lộ giới / chỉ giới / cảnh báo", type: "textarea", required: true },
  ],
  legal: [
    { id: "legalDocument", label: "Loại và số giấy tờ pháp lý", type: "text", required: true },
    { id: "legalHolder", label: "Chủ thể trên giấy tờ", type: "text", required: true },
    { id: "legalStatus", label: "Tình trạng thế chấp / tranh chấp", type: "select", required: true, options: ["Không ghi nhận", "Đang thế chấp", "Có tranh chấp", "Đã giải chấp", "Chưa xác minh"] },
    { id: "legalMissing", label: "Tài liệu còn thiếu và lưu ý", type: "textarea" },
  ],
  valuation: [
    { id: "askingPrice", label: "Giá chủ đề nghị", type: "number", required: true },
    { id: "marketReference", label: "BĐS / dữ liệu so sánh", type: "textarea", required: true },
    { id: "recommendedPrice", label: "Giá đề xuất", type: "number", required: true },
    { id: "liquidityAssessment", label: "Thanh khoản và độ tin cậy", type: "select", required: true, options: ["Cao", "Trung bình", "Thấp", "Cần theo dõi"] },
  ],
  agreement: [
    { id: "agreedPrice", label: "Giá thống nhất / giá chào", type: "number", required: true },
    { id: "commissionTerms", label: "Hoa hồng và điều kiện", type: "textarea", required: true },
    { id: "agreementPeriod", label: "Thời hạn thỏa thuận", type: "date", required: true },
    { id: "exploitationRight", label: "Quyền khai thác / ký gửi", type: "select", required: true, options: ["Độc quyền", "Không độc quyền", "Hợp tác phân phối", "Chưa xác nhận"] },
  ],
  project: [
    { id: "investorName", label: "Chủ đầu tư / pháp nhân dự án", type: "text", required: true },
    { id: "projectLocation", label: "Vị trí dự án", type: "textarea", required: true },
    { id: "projectProgress", label: "Tiến độ và tình trạng pháp lý", type: "textarea", required: true },
    { id: "productCatalog", label: "Danh mục sản phẩm / bảng giá", type: "text", required: true },
  ],
  ai: [
    { id: "searchCriteria", label: "Tiêu chí AI tìm kiếm", type: "textarea", required: true },
    { id: "collectedSource", label: "Nguồn dữ liệu AI thu thập", type: "textarea", required: true },
    { id: "aiScore", label: "Điểm phù hợp / mức tin cậy", type: "number", required: true },
    { id: "humanVerification", label: "Kết quả con người xác minh", type: "textarea", required: true },
  ],
  sale_advisor: [
    { id: "customerName", label: "Tên khách hàng", type: "text", required: true },
    { id: "customerNeed", label: "Nhu cầu và ngân sách", type: "textarea", required: true },
    { id: "matchingProperty", label: "BĐS / nhu cầu được ghép", type: "text", required: true },
    { id: "consultationOutcome", label: "Kết quả tư vấn và bước tiếp theo", type: "textarea", required: true },
  ],
};

const SOURCE_SPECIFIC_STEP_FIELDS: Record<SourceChannelKey, SourceProcedureField[]> = {
  collaborator: [
    { id: "ctvProfile", label: "Hồ sơ / mã CTV", type: "text", required: true },
    { id: "ctvCommissionPolicy", label: "Chính sách hoa hồng CTV", type: "textarea", required: true },
  ],
  owner: [
    { id: "ownerMandate", label: "Tình trạng ủy quyền / quyền ký gửi", type: "select", required: true, options: ["Đã xác nhận", "Đang chờ xác nhận", "Không có ủy quyền", "Cần bổ sung"] },
    { id: "ownerNegotiationNote", label: "Nội dung làm việc với chủ nhà", type: "textarea" },
  ],
  project: [
    { id: "projectDeveloperContact", label: "Đầu mối chủ đầu tư", type: "text", required: true },
    { id: "projectProductStatus", label: "Tình trạng giỏ hàng dự án", type: "select", required: true, options: ["Đang mở bán", "Đã giữ chỗ", "Đã bán", "Chưa mở bán", "Cần xác minh"] },
  ],
  market: [
    { id: "marketObservedAt", label: "Thời điểm phát hiện nguồn", type: "date", required: true },
    { id: "marketEvidenceLink", label: "Link / nguồn quan sát thị trường", type: "text", required: true },
  ],
  internal_broker: [
    { id: "internalBrokerId", label: "Mã môi giới nội bộ", type: "text", required: true },
    { id: "internalBrokerHandover", label: "Nội dung bàn giao nội bộ", type: "textarea", required: true },
  ],
  ai: [
    { id: "aiSourcePolicy", label: "Quy tắc nguồn dữ liệu AI", type: "textarea", required: true },
    { id: "aiHumanOwner", label: "Chuyên viên xác minh AI", type: "text", required: true },
  ],
  partner: [
    { id: "partnerOrganization", label: "Tên pháp nhân / đối tác", type: "text", required: true },
    { id: "partnerExploitationRight", label: "Quyền khai thác của đối tác", type: "textarea", required: true },
  ],
  sale_advisor: [
    { id: "advisorCode", label: "Mã Sale tư vấn", type: "text", required: true },
    { id: "advisorFollowUpDate", label: "Lịch chăm sóc tiếp theo", type: "date", required: true },
  ],
};

function sourceStepFormKey(step: string): string {
  const lower = step.toLocaleLowerCase("vi");
  if (lower.includes("ai")) return "ai";
  if (lower.includes("tiếp nhận") || lower.includes("phát hiện") || lower.includes("thiết lập tiêu chí")) return "intake";
  if (lower.includes("chủ đầu tư") || lower.includes("hồ sơ chủ") || lower.includes("hồ sơ ctv") || lower.includes("hồ sơ môi giới") || lower.includes("hồ sơ đối tác") || lower.includes("nhập dữ liệu khách")) return "owner";
  if (lower.includes("vị trí") || lower.includes("xác minh bđs") || lower.includes("thu thập") || lower.includes("tìm kiếm") || lower.includes("xác minh")) return "property";
  if (lower.includes("khảo sát") || lower.includes("tiến độ")) return "survey";
  if (lower.includes("quy hoạch")) return "planning";
  if (lower.includes("pháp lý") || lower.includes("chuẩn hóa") || lower.includes("giấy")) return "legal";
  if (lower.includes("giá") || lower.includes("định giá") || lower.includes("chấm điểm") || lower.includes("phân tích")) return "valuation";
  if (lower.includes("ký gửi") || lower.includes("hợp đồng") || lower.includes("thỏa thuận") || lower.includes("chính sách") || lower.includes("tư vấn phương án") || lower.includes("quyền khai thác")) return "agreement";
  if (lower.includes("danh mục") || lower.includes("bảng giá") || lower.includes("dự án")) return "project";
  return "intake";
}

export function getSourceWorkflowStepSchema(step: string, sourceType: SourceChannelKey): SourceWorkflowStepSchema {
  const id = `${sourceType}-${step.toLocaleLowerCase("vi").replace(/[^a-z0-9]+/gi, "-")}`;
  const lower = step.toLocaleLowerCase("vi");
  const formKey = sourceStepFormKey(step);
  const sourceLabel = SOURCE_CHANNELS.find(item => item.key === sourceType)?.shortLabel || sourceType;
  const fields = [...(SOURCE_STEP_FORM_FIELDS[formKey] || SOURCE_STEP_FORM_FIELDS.intake), ...(SOURCE_SPECIFIC_STEP_FIELDS[sourceType] || []), { id: "stepStatus", label: "Trạng thái bước", type: "select" as const, required: true, options: ["Chưa thực hiện", "Đang xử lý", "Đã hoàn tất", "Cần bổ sung"] }, { id: "responsiblePerson", label: "Người phụ trách / người xác nhận", type: "text" as const, required: true }];
  const isCodeStep = lower.includes("tạo mã");
  const isInventoryStep = lower.includes("vào kho");
  const isAi = lower.includes("ai") || lower.includes("phân tích") || lower.includes("chấm điểm") || lower.includes("chuẩn hóa") || lower.includes("kiểm tra") || isCodeStep || isInventoryStep;
  const isHybrid = lower.includes("quy hoạch") || lower.includes("pháp lý") || lower.includes("giá") || lower.includes("xác minh") || lower.includes("duyệt");
  const responsibility = isAi ? (isHybrid ? "hybrid" : "ai") : isHybrid ? "hybrid" : "human";
  const automationMode = isAi ? "ai_review" : isHybrid ? "hybrid" : "human";
  const aiOutputFields: SourceProcedureField[] = isCodeStep ? [
    { id: "sourceCodeForm", label: "Mã nguồn AI đề xuất", type: "text", required: true, placeholder: "AI sẽ sinh mã nguồn" },
    { id: "propertyCodeForm", label: "Mã BĐS / sản phẩm AI đề xuất", type: "text", required: true, placeholder: "AI sẽ sinh mã BĐS / sản phẩm" },
  ] : isInventoryStep ? [
    { id: "warehouseDecision", label: "Quyết định đưa vào kho", type: "select", required: true, options: ["Đủ điều kiện vào kho", "Chờ bổ sung", "Từ chối"] },
    { id: "warehouseTarget", label: "Kho đích AI đề xuất", type: "text", required: true, placeholder: "Kho nguồn tổng / Kho tiếp nhận" },
  ] : [
    { id: `${id}-aiSummary`, label: "Tóm tắt AI để người duyệt kiểm tra", type: "textarea", required: true, placeholder: "Kết quả AI sẽ hiển thị tại đây" },
    { id: `${id}-aiDecision`, label: "Kết luận AI", type: "select", required: true, options: ["Đạt", "Không đạt", "Cần bổ sung", "Cần xác minh"] },
  ];
  const task = isAi ? `AI tự động ${step.toLocaleLowerCase("vi")} từ toàn bộ dữ liệu nguồn; người dùng kiểm tra và xác nhận kết quả.` : formKey === "intake" ? `Tiếp nhận và lập dữ liệu đầu vào cho nguồn ${sourceLabel}` : `Hoàn tất biểu mẫu ${step} của nguồn ${sourceLabel}`;
  return { id, title: step, task, fields, validation: ["Đủ trường bắt buộc của biểu mẫu", "Có người phụ trách và trạng thái bước", "Tài liệu hoặc căn cứ được ghi nhận"], condition: `Biểu mẫu riêng cho nguồn ${sourceLabel}, áp dụng tại bước ${step}`, aiAction: isAi ? "AI tự đọc toàn bộ Source Data Package, kiểm tra thiếu/trùng/đối chiếu, đề xuất kết quả và mở form duyệt." : isHybrid ? "AI đọc và đối chiếu dữ liệu, tài liệu hoặc giá; chuyên viên kết luận và xác nhận." : "AI tóm tắt dữ liệu đầu vào và đề xuất kiểm tra tiếp theo; con người chịu trách nhiệm nhập liệu.", document: formKey === "legal" || formKey === "planning" ? "Giấy tờ pháp lý, bản đồ, văn bản và ảnh đối chiếu" : "Biên bản, ảnh, video, dữ liệu liên hệ hoặc tài liệu nghiệp vụ", results: ["Đạt", "Không đạt", "Cần bổ sung", "Cần xác minh"], responsibility, automationMode, aiOutputFields, humanAction: "Người phụ trách nhập dữ liệu, đối chiếu hồ sơ gốc, chỉnh sửa kết quả AI và xác nhận.", warehouseCondition: isInventoryStep ? "Chỉ đưa vào kho sau khi người dùng xác nhận quyết định và kho đích." : "Chỉ chuyển bước khi kết quả AI đã được người dùng kiểm tra và xác nhận." };
}

type SourceWorkspaceModule = {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  required?: boolean;
  parts: string[];
};

const SOURCE_WORKSPACE_MODULES: SourceWorkspaceModule[] = [
  {
    id: "source-picker",
    name: "Chọn nguồn",
    description: "Chọn một trong bảy kênh nguồn hàng.",
    enabled: true,
    required: true,
    parts: ["Danh sách nguồn", "Mô tả nguồn"],
  },
  {
    id: "property-picker",
    name: "Chọn loại BĐS",
    description: "Chọn nhóm và loại bất động sản chi tiết.",
    enabled: true,
    required: true,
    parts: ["Nhóm BĐS", "Loại chi tiết"],
  },
  {
    id: "intake-form",
    name: "Form thông tin nguồn",
    description: "Thông tin chủ nhà, vị trí, giá, pháp lý và giao dịch.",
    enabled: true,
    required: true,
    parts: ["Thông tin cơ bản", "Chủ sở hữu", "Vị trí", "Pháp lý"],
  },
  {
    id: "media",
    name: "Ảnh, camera và video",
    description: "Tải/chụp ảnh, quay/tải video và quản lý media.",
    enabled: true,
    parts: ["Ảnh BĐS", "Camera", "Video"],
  },
  {
    id: "ocr",
    name: "Giấy tờ & OCR",
    description: "Đọc giấy tờ và chỉ điền sau khi môi giới xác nhận.",
    enabled: true,
    parts: ["Tải giấy tờ", "OCR", "Xác nhận dữ liệu"],
  },
  {
    id: "workflow",
    name: "Workflow xử lý",
    description: "Chuỗi bước được sinh theo loại nguồn đã chọn.",
    enabled: true,
    parts: ["Danh sách bước", "Trạng thái", "Chuyển bước"],
  },
];

const SOURCE_MODULE_STORAGE_KEY = "bdsxanh-source-workspace-modules-v1";
const SOURCE_PROCEDURE_DRAFT_KEY = "bdsxanh-source-procedure-draft-v1";

function readSourceWorkspaceModules() {
  if (typeof window === "undefined") return SOURCE_WORKSPACE_MODULES;
  try {
    const stored = window.localStorage.getItem(SOURCE_MODULE_STORAGE_KEY);
    if (!stored) return SOURCE_WORKSPACE_MODULES;
    const parsed = JSON.parse(stored) as SourceWorkspaceModule[];
    return Array.isArray(parsed) && parsed.length ? parsed : SOURCE_WORKSPACE_MODULES;
  } catch {
    return SOURCE_WORKSPACE_MODULES;
  }
}

function readSourceProcedureDraft() {
  if (typeof window === "undefined") return {} as Record<string, string | boolean>;
  try {
    const stored = window.localStorage.getItem(SOURCE_PROCEDURE_DRAFT_KEY);
    return stored ? JSON.parse(stored) as Record<string, string | boolean> : {};
  } catch {
    return {} as Record<string, string | boolean>;
  }
}

function SourceProcedureEngine({
  context,
  onSnapshotChange,
}: {
  context: SourceCreationContext;
  onSnapshotChange: (snapshot: string) => void;
}) {
  const [activeModuleId, setActiveModuleId] = useState(SOURCE_PROCEDURE_MODULES[0].id);
  const [values, setValues] = useState<Record<string, string | boolean>>(readSourceProcedureDraft);
  const [moduleStatuses, setModuleStatuses] = useState<Record<string, "todo" | "doing" | "done">>({ intake: "doing" });
  const activeIndex = Math.max(0, SOURCE_PROCEDURE_MODULES.findIndex(module => module.id === activeModuleId));
  const activeModule = SOURCE_PROCEDURE_MODULES[activeIndex];
  const completion = getSourceProcedureCompletion(values);

  useEffect(() => {
    window.localStorage.setItem(SOURCE_PROCEDURE_DRAFT_KEY, JSON.stringify(values));
    onSnapshotChange(JSON.stringify({
      version: 1,
      sourceType: context.sourceType,
      sourceLabel: context.sourceLabel,
      propertyCategory: context.propertyCategory,
      propertySubtype: context.propertySubtype,
      workflow: context.workflow,
      activeModuleId,
      moduleStatuses,
      completion,
      values,
      savedAt: new Date().toISOString(),
      safety: "AI/OCR chỉ đề xuất; dữ liệu cần xác nhận của người dùng trước khi dùng nghiệp vụ.",
    }));
  }, [activeModuleId, completion.completed, completion.percent, completion.total, context, moduleStatuses, onSnapshotChange, values]);

  const setFieldValue = (field: SourceProcedureField, value: string | boolean) => {
    setValues(current => ({ ...current, [field.id]: value }));
  };
  const moduleRequired = (module: SourceProcedureModule) => module.fields.filter(field => field.required);
  const isModuleComplete = (module: SourceProcedureModule) => {
    const required = moduleRequired(module);
    return required.length === 0 || required.every(field => values[field.id] === true || String(values[field.id] || "").trim());
  };
  const finishModule = () => {
    if (!isModuleComplete(activeModule)) {
      toast.error("Hãy điền đủ các trường bắt buộc của module trước khi hoàn tất.");
      return;
    }
    setModuleStatuses(current => ({ ...current, [activeModule.id]: "done" }));
    const next = SOURCE_PROCEDURE_MODULES[activeIndex + 1];
    if (next) {
      setActiveModuleId(next.id);
      setModuleStatuses(current => ({ ...current, [next.id]: current[next.id] === "done" ? "done" : "doing" }));
    }
    toast.success(`Đã hoàn tất ${activeModule.title}`);
  };
  const saveDraft = () => {
    window.localStorage.setItem(SOURCE_PROCEDURE_DRAFT_KEY, JSON.stringify(values));
    toast.success("Đã lưu nháp toàn bộ Form Engine trên thiết bị này");
  };
  const routeAction = (action: string) => {
    const lower = action.toLocaleLowerCase("vi");
    const target = lower.includes("ocr") || lower.includes("giấy tờ")
      ? "source-document-tools"
      : lower.includes("ảnh") || lower.includes("video") || lower.includes("3d") || lower.includes("media")
        ? "source-media-tools"
        : null;
    if (target) {
      document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" });
      toast.info("Đã mở công cụ thật trong biểu mẫu bên dưới");
      return;
    }
    toast.info(`${action}: dữ liệu sẽ được lưu cùng snapshot nguồn khi bấm Lưu nháp / Lưu nguồn.`);
  };

  return (
    <section data-source-procedure-engine className="mt-5 overflow-hidden rounded-[1.5rem] border border-[#BFD7CA] bg-[#F8FBF9]">
      <div className="bg-[#18352D] p-4 text-white sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-xs font-black uppercase tracking-[.18em] text-[#E6C478]">Form & Procedure Engine · Đầy đủ theo cấu trúc file</p>
            <h3 className="mt-2 font-serif text-2xl tracking-[-.025em]">12 module nghiệp vụ tạo nguồn</h3>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-white/70">Mỗi module có trường bắt buộc, checklist, hành động và trạng thái riêng. Dữ liệu được lưu thành một snapshot gắn cùng hồ sơ BĐS; AI/OCR không tự xác nhận thay môi giới.</p>
          </div>
          <div className="min-w-[220px] rounded-2xl bg-white/10 p-3">
            <div className="flex items-center justify-between text-xs font-bold"><span>Hoàn thiện hồ sơ</span><span>{completion.completed}/{completion.total} trường bắt buộc</span></div>
            <div className="mt-2 h-2 rounded-full bg-white/15"><div className="h-2 rounded-full bg-[#E6C478]" style={{ width: `${completion.percent}%` }} /></div>
            <p className="mt-2 text-right text-xs font-black text-[#E6C478]">{completion.percent}%</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-[300px_minmax(0,1fr)]">
        <aside className="border-b border-[#DCE8E1] bg-white p-3 lg:border-b-0 lg:border-r">
          <div className="max-h-[640px] space-y-2 overflow-y-auto pr-1 [scrollbar-color:#8aa99a_transparent] [scrollbar-width:thin]">
            {SOURCE_PROCEDURE_MODULES.map((module, index) => {
              const status = isModuleComplete(module) || moduleStatuses[module.id] === "done" ? "done" : moduleStatuses[module.id] || "todo";
              return (
                <button key={module.id} type="button" onClick={() => { setActiveModuleId(module.id); setModuleStatuses(current => ({ ...current, [module.id]: current[module.id] === "done" ? "done" : "doing" })); }} className={`w-full rounded-xl border p-3 text-left ${activeModuleId === module.id ? "border-[#1F5A4A] bg-[#EDF5F0] ring-2 ring-[#1F5A4A]/10" : "border-[#E0EAE4] bg-white hover:border-[#9FBEAD]"}`}>
                  <div className="flex items-start gap-3">
                    <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] font-black ${status === "done" ? "bg-[#1F5A4A] text-white" : status === "doing" ? "bg-[#E6C478] text-[#18352D]" : "bg-[#EEF2EF] text-[#71877D]"}`}>{status === "done" ? "✓" : index + 1}</span>
                    <span className="min-w-0"><span className="block text-xs font-black text-[#18352D]">{module.title}</span><span className="mt-1 block text-[11px] leading-4 text-[#71877D]">{module.fields.length} trường · {moduleRequired(module).length} bắt buộc</span></span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <div className="min-w-0 p-4 sm:p-5">
          <div className="flex flex-col gap-3 border-b border-[#DCE8E1] pb-4 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[.14em] text-[#1F5A4A]">Module {activeIndex + 1}/{SOURCE_PROCEDURE_MODULES.length}</p>
              <h4 className="mt-1 text-xl font-black text-[#18352D]">{activeModule.title}</h4>
              <p className="mt-1 text-sm leading-6 text-[#60766D]">{activeModule.summary}</p>
            </div>
            <span className={`self-start rounded-full px-3 py-1.5 text-xs font-black ${isModuleComplete(activeModule) ? "bg-[#E3F2E8] text-[#1F5A4A]" : "bg-amber-100 text-amber-800"}`}>{isModuleComplete(activeModule) ? "Đủ trường bắt buộc" : "Cần bổ sung"}</span>
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2">
            {activeModule.fields.map(field => {
              const value = values[field.id];
              if (field.type === "checkbox") {
                return <label key={field.id} className="flex items-start gap-3 rounded-xl border border-[#DCE8E1] bg-white p-3 text-sm font-bold text-[#365B4F]"><input type="checkbox" checked={Boolean(value)} onChange={event => setFieldValue(field, event.target.checked)} className="mt-0.5 h-4 w-4 accent-[#1F5A4A]" /><span>{field.label}{field.required ? <span className="ml-1 text-red-600">*</span> : null}{field.hint ? <span className="mt-1 block text-xs font-normal text-[#71877D]">{field.hint}</span> : null}</span></label>;
              }
              const shared = "rounded-xl border border-[#CADDD2] bg-white px-3 py-2.5 text-sm text-[#18352D] outline-none focus:border-[#1F5A4A] focus:ring-2 focus:ring-[#1F5A4A]/10";
              return (
                <label key={field.id} className={`grid gap-1.5 text-xs font-bold text-[#365B4F] ${field.type === "textarea" ? "md:col-span-2" : ""}`}>
                  <span>{field.label}{field.required ? <span className="ml-1 text-red-600">*</span> : null}</span>
                  {field.type === "textarea" ? <textarea rows={3} value={String(value || "")} onChange={event => setFieldValue(field, event.target.value)} placeholder={field.placeholder} className={shared} /> : field.type === "select" ? <select value={String(value || "")} onChange={event => setFieldValue(field, event.target.value)} className={shared}><option value="">Chọn...</option>{(field.options || []).map(option => <option key={option} value={option}>{option}</option>)}</select> : <input type={field.type} value={String(value || "")} onChange={event => setFieldValue(field, event.target.value)} placeholder={field.placeholder} className={shared} />}
                  {field.hint ? <span className="font-normal text-[#71877D]">{field.hint}</span> : null}
                </label>
              );
            })}
          </div>

          <div className="mt-5 rounded-xl border border-[#DCE8E1] bg-white p-3">
            <p className="text-xs font-black uppercase tracking-[.14em] text-[#1F5A4A]">Hành động của module</p>
            <div className="mt-3 flex flex-wrap gap-2">{activeModule.actions.map(action => <button key={action} type="button" onClick={() => routeAction(action)} className="rounded-full border border-[#BCD3C6] bg-[#F8FBF9] px-3 py-2 text-xs font-black text-[#1F5A4A] hover:bg-[#EDF5F0]">{action}</button>)}</div>
          </div>

          <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex gap-2"><button type="button" disabled={activeIndex === 0} onClick={() => setActiveModuleId(SOURCE_PROCEDURE_MODULES[Math.max(0, activeIndex - 1)].id)} className="rounded-xl border border-[#CADDD2] bg-white px-4 py-2.5 text-sm font-black text-[#365B4F] disabled:opacity-40">Quay lại</button><button type="button" onClick={saveDraft} className="rounded-xl border border-[#1F5A4A] bg-white px-4 py-2.5 text-sm font-black text-[#1F5A4A]">Lưu nháp engine</button></div>
            <button type="button" onClick={finishModule} className="rounded-xl bg-[#1F5A4A] px-5 py-2.5 text-sm font-black text-white">{activeIndex === SOURCE_PROCEDURE_MODULES.length - 1 ? "Hoàn tất hồ sơ" : "Hoàn tất & sang module tiếp"}</button>
          </div>
        </div>
      </div>
    </section>
  );
}

function SourceWorkspaceModuleManager() {
  const [open, setOpen] = useState(false);
  const [modules, setModules] = useState<SourceWorkspaceModule[]>(readSourceWorkspaceModules);
  const [newModuleName, setNewModuleName] = useState("");
  const [selectedId, setSelectedId] = useState(SOURCE_WORKSPACE_MODULES[0].id);
  const [newPartName, setNewPartName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [draggedId, setDraggedId] = useState<string | null>(null);

  useEffect(() => {
    window.localStorage.setItem(SOURCE_MODULE_STORAGE_KEY, JSON.stringify(modules));
  }, [modules]);

  const selected = modules.find(module => module.id === selectedId) || modules[0];
  const moveModule = (id: string, direction: -1 | 1) => {
    setModules(current => {
      const index = current.findIndex(module => module.id === id);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= current.length) return current;
      const next = [...current];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next;
    });
  };
  const addModule = () => {
    const name = newModuleName.trim();
    if (!name) return;
    const id = `source-custom-${Date.now()}`;
    setModules(current => [...current, { id, name, description: "Module tùy chỉnh trong quy trình Tạo nguồn.", enabled: true, parts: [] }]);
    setSelectedId(id);
    setNewModuleName("");
    toast.success("Đã thêm module vào Tạo nguồn");
  };
  const addPart = () => {
    const name = newPartName.trim();
    if (!name || !selected) return;
    setModules(current => current.map(module => module.id === selected.id ? { ...module, parts: [...module.parts, name] } : module));
    setNewPartName("");
    toast.success("Đã thêm phần vào module");
  };

  return (
    <div data-source-module-manager className="mt-5 rounded-2xl border border-[#C9DDD2] bg-[#F7FAF8]">
      <div className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="flex items-center gap-2 text-sm font-black text-[#18352D]"><Settings2 className="h-4 w-4 text-[#1F5A4A]" /> Quản trị cấu trúc Tạo nguồn</p>
          <p className="mt-1 text-xs leading-5 text-[#60766D]">Thêm, sửa, sắp xếp hoặc ẩn module ngay tại đây. Ẩn/gỡ chỉ đổi bố cục, không xóa hồ sơ nghiệp vụ.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => setOpen(value => !value)} className="inline-flex items-center gap-2 rounded-full bg-[#1F5A4A] px-4 py-2.5 text-xs font-black text-white">
            <Settings2 className="h-4 w-4" /> {open ? "Đóng quản trị" : "Thêm / sửa module"}
          </button>
          <button type="button" onClick={() => { window.location.href = "/quan-tri-module"; }} className="inline-flex items-center gap-2 rounded-full border border-[#BCD3C6] bg-white px-4 py-2.5 text-xs font-black text-[#1F5A4A]">
            Quản trị đầy đủ
          </button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-[#DDE9E2] p-4">
          <div className="grid gap-2 sm:grid-cols-[1fr_auto]">
            <input value={newModuleName} onChange={event => setNewModuleName(event.target.value)} placeholder="Tên module mới" aria-label="Tên module Tạo nguồn mới" className="rounded-xl border border-[#CADDD2] bg-white px-3 py-2.5 text-sm outline-none focus:border-[#1F5A4A]" />
            <button type="button" onClick={addModule} disabled={!newModuleName.trim()} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#E6C478] px-4 py-2.5 text-sm font-black text-[#18352D] disabled:opacity-50"><Plus className="h-4 w-4" /> Thêm module</button>
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-[1.1fr_.9fr]">
            <div className="space-y-2">
              {modules.map((module, index) => (
                <div key={module.id} draggable onDragStart={() => setDraggedId(module.id)} onDragOver={event => event.preventDefault()} onDrop={() => {
                  if (!draggedId || draggedId === module.id) return;
                  setModules(current => {
                    const from = current.findIndex(item => item.id === draggedId);
                    const to = current.findIndex(item => item.id === module.id);
                    if (from < 0 || to < 0) return current;
                    const next = [...current];
                    const [moved] = next.splice(from, 1);
                    next.splice(to, 0, moved);
                    return next;
                  });
                  setDraggedId(null);
                  toast.success("Đã đổi vị trí module");
                }} className={`rounded-xl border bg-white p-3 ${selectedId === module.id ? "border-[#1F5A4A] ring-2 ring-[#1F5A4A]/10" : "border-[#DCE8E1]"}`}>
                  <div className="flex flex-wrap items-center gap-2">
                    <button type="button" onClick={() => setSelectedId(module.id)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                      <GripVertical className="h-4 w-4 shrink-0 cursor-grab text-[#8AA99A]" />
                      <span className="min-w-0"><span className="block truncate text-sm font-black text-[#18352D]">{module.name}</span><span className="block text-[11px] text-[#71877D]">{module.parts.length} thành phần · {module.enabled ? "Đang hiện" : "Đang ẩn"}</span></span>
                    </button>
                    <button type="button" aria-label={`Đưa ${module.name} lên`} disabled={index === 0} onClick={() => moveModule(module.id, -1)} className="rounded-lg border border-[#DCE8E1] p-2 disabled:opacity-30"><ArrowUp className="h-3.5 w-3.5" /></button>
                    <button type="button" aria-label={`Đưa ${module.name} xuống`} disabled={index === modules.length - 1} onClick={() => moveModule(module.id, 1)} className="rounded-lg border border-[#DCE8E1] p-2 disabled:opacity-30"><ArrowDown className="h-3.5 w-3.5" /></button>
                    <button type="button" aria-label={`Sửa ${module.name}`} onClick={() => { setEditingId(module.id); setEditingName(module.name); }} className="rounded-lg border border-[#DCE8E1] p-2 text-[#1F5A4A]"><Pencil className="h-3.5 w-3.5" /></button>
                    <button type="button" onClick={() => setModules(current => current.map(item => item.id === module.id ? { ...item, enabled: !item.enabled } : item))} className={`rounded-lg px-2.5 py-2 text-[11px] font-black ${module.enabled ? "bg-[#E8F2EC] text-[#1F5A4A]" : "bg-[#EEF0EE] text-[#6E7B75]"}`}>{module.enabled ? "Ẩn" : "Bật"}</button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild><button type="button" disabled={module.required} aria-label={`Xóa ${module.name}`} className="rounded-lg border border-red-200 p-2 text-red-600 disabled:cursor-not-allowed disabled:opacity-30"><Trash2 className="h-3.5 w-3.5" /></button></AlertDialogTrigger>
                      <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Xóa module khỏi bố cục?</AlertDialogTitle><AlertDialogDescription>Module “{module.name}” sẽ bị gỡ khỏi cấu hình Tạo nguồn. Hồ sơ và dữ liệu nghiệp vụ đã lưu không bị xóa.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Hủy</AlertDialogCancel><AlertDialogAction onClick={() => { setModules(current => current.filter(item => item.id !== module.id)); if (selectedId === module.id) setSelectedId(modules.find(item => item.id !== module.id)?.id || ""); toast.success("Đã gỡ module khỏi bố cục"); }} className="bg-red-600 hover:bg-red-700">Xóa khỏi bố cục</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
                    </AlertDialog>
                  </div>
                  {editingId === module.id ? <div className="mt-3 flex flex-col gap-2 sm:flex-row"><input value={editingName} onChange={event => setEditingName(event.target.value)} aria-label={`Tên mới cho ${module.name}`} className="min-w-0 flex-1 rounded-lg border border-[#CADDD2] px-3 py-2 text-sm" /><button type="button" onClick={() => { const name = editingName.trim(); if (!name) return; setModules(current => current.map(item => item.id === module.id ? { ...item, name } : item)); setEditingId(null); toast.success("Đã sửa tên module"); }} className="rounded-lg bg-[#1F5A4A] px-3 py-2 text-xs font-black text-white">Lưu sửa</button></div> : null}
                </div>
              ))}
            </div>

            <div className="rounded-xl border border-[#DCE8E1] bg-white p-4">
              <p className="text-xs font-black uppercase tracking-[.14em] text-[#1F5A4A]">Thành phần trong module</p>
              <h3 className="mt-1 text-lg font-black text-[#18352D]">{selected?.name || "Chọn module"}</h3>
              <div className="mt-3 space-y-2">
                {(selected?.parts || []).map(part => <div key={part} className="flex items-center justify-between gap-2 rounded-lg bg-[#F4F8F5] px-3 py-2 text-xs font-bold text-[#365B4F]"><span>{part}</span><AlertDialog><AlertDialogTrigger asChild><button type="button" aria-label={`Gỡ ${part}`} className="rounded-md p-1.5 text-red-600"><Trash2 className="h-3.5 w-3.5" /></button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Gỡ thành phần?</AlertDialogTitle><AlertDialogDescription>“{part}” chỉ bị gỡ khỏi module hiển thị; dữ liệu nghiệp vụ không bị xóa.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Hủy</AlertDialogCancel><AlertDialogAction onClick={() => setModules(current => current.map(item => item.id === selected?.id ? { ...item, parts: item.parts.filter(name => name !== part) } : item))} className="bg-red-600 hover:bg-red-700">Gỡ thành phần</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog></div>)}
              </div>
              <div className="mt-3 flex flex-col gap-2 sm:flex-row"><input value={newPartName} onChange={event => setNewPartName(event.target.value)} placeholder="Tên phần mới" aria-label="Tên thành phần mới" className="min-w-0 flex-1 rounded-lg border border-[#CADDD2] px-3 py-2 text-sm" /><button type="button" onClick={addPart} disabled={!selected || !newPartName.trim()} className="inline-flex items-center justify-center gap-1 rounded-lg border border-[#1F5A4A] px-3 py-2 text-xs font-black text-[#1F5A4A] disabled:opacity-40"><Plus className="h-3.5 w-3.5" /> Thêm phần</button></div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

export const SOURCE_INTAKE_FIELDS: Record<SourceChannelKey, Array<{ id: string; label: string; placeholder: string; required?: boolean }>> = {
  collaborator: [
    { id: "collaboratorName", label: "Tên CTV", placeholder: "Họ tên CTV", required: true },
    { id: "collaboratorPhone", label: "Điện thoại CTV", placeholder: "Số điện thoại", required: true },
    { id: "collaboratorAgreement", label: "Thỏa thuận CTV", placeholder: "Hoa hồng / điều kiện hợp tác" },
  ],
  owner: [
    { id: "ownerName", label: "Tên chủ nhà / chủ đất", placeholder: "Họ tên hoặc tên đơn vị", required: true },
    { id: "ownerPhone", label: "Điện thoại chủ nhà", placeholder: "Số điện thoại", required: true },
    { id: "ownerPermission", label: "Quyền cung cấp thông tin", placeholder: "Độc quyền / không độc quyền / đang trao đổi", required: true },
  ],
  project: [
    { id: "developerName", label: "Tên chủ đầu tư", placeholder: "Tên chủ đầu tư", required: true },
    { id: "projectName", label: "Tên dự án", placeholder: "Tên dự án", required: true },
    { id: "projectStage", label: "Giai đoạn dự án", placeholder: "Chuẩn bị / đang triển khai / mở bán" },
  ],
  internal_broker: [
    { id: "internalBroker", label: "Môi giới nội bộ", placeholder: "Tên nhân sự tiếp nhận", required: true },
    { id: "internalTeam", label: "Đội / chi nhánh", placeholder: "Tên đội phụ trách" },
    { id: "internalNote", label: "Ghi chú bàn giao", placeholder: "Thông tin cần bàn giao" },
  ],
  market: [
    { id: "marketSourceUrl", label: "Nguồn phát hiện", placeholder: "URL / kênh / khu vực phát hiện", required: true },
    { id: "marketObservedAt", label: "Ngày thu thập", placeholder: "YYYY-MM-DD", required: true },
    { id: "marketContactStatus", label: "Trạng thái tiếp cận", placeholder: "Chưa liên hệ / đang xác minh / đã liên hệ" },
  ],
  ai: [
    { id: "aiCriteria", label: "Tiêu chí AI tìm kiếm", placeholder: "Khu vực, giá, loại BĐS, diện tích", required: true },
    { id: "aiEvidence", label: "Nguồn bằng chứng", placeholder: "URL / tài liệu / dữ liệu đầu vào", required: true },
    { id: "aiHumanReviewer", label: "Người xác minh", placeholder: "Tên người kiểm tra", required: true },
  ],
  partner: [
    { id: "partnerName", label: "Tên đối tác", placeholder: "Tên đơn vị / cá nhân", required: true },
    { id: "partnerContact", label: "Người liên hệ", placeholder: "Họ tên và số điện thoại", required: true },
    { id: "partnerRights", label: "Quyền khai thác", placeholder: "Phạm vi được phép đăng / phân phối" },
  ],
  sale_advisor: [
    { id: "saleAdvisorName", label: "Tên Sale tư vấn", placeholder: "Họ tên nhân sự tư vấn", required: true },
    { id: "saleAdvisorCustomer", label: "Khách hàng tư vấn", placeholder: "Họ tên khách hàng / mã khách", required: true },
    { id: "saleAdvisorNeed", label: "Nhu cầu khách hàng", placeholder: "Mua / bán / thuê / cho thuê / sang nhượng", required: true },
    { id: "saleAdvisorBudget", label: "Ngân sách dự kiến", placeholder: "Khoảng giá hoặc ngân sách" },
  ],
};

function makeSourceCode(sourceType: SourceChannelKey) {
  const prefix = SOURCE_CHANNELS.find(item => item.key === sourceType)?.shortLabel.replace(/[^A-Za-z]/g, "").toUpperCase() || "NGUON";
  const date = new Date();
  const stamp = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  return `NG-${prefix}-${stamp}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

export function getSourceIntakeFieldValue(values: Record<string, string>, workflowValues: Record<string, string>, fieldId: string) {
  return values[fieldId] ?? workflowValues[fieldId] ?? "";
}

export function SourceSpecificIntake({ sourceType, values, workflowValues = {}, onChange }: { sourceType: SourceChannelKey; values: Record<string, string>; workflowValues?: Record<string, string>; onChange: (values: Record<string, string>) => void }) {
  const fields = SOURCE_INTAKE_FIELDS[sourceType];
  return (
    <div className="mt-4 rounded-2xl border border-[#BFD7CA] bg-white p-4 sm:p-5">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div><p className="text-xs font-black uppercase tracking-[.16em] text-[#1F5A4A]">Form tiếp nhận riêng · {SOURCE_CHANNELS.find(item => item.key === sourceType)?.label}</p><p className="mt-1 text-sm leading-6 text-[#60766D]">Các trường này chỉ dành cho nhóm nguồn đang chọn và sẽ được lưu cùng hồ sơ kho nguồn.</p></div>
        <span className="rounded-full bg-[#E8F2EC] px-3 py-1.5 text-xs font-black text-[#1F5A4A]">{fields.length} trường riêng</span>
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {fields.map(field => <label key={field.id} className="grid gap-1.5 text-xs font-bold text-[#365B4F]"><span>{field.label}{field.required ? <span className="ml-1 text-red-600">*</span> : null}</span><input value={getSourceIntakeFieldValue(values, workflowValues, field.id)} required={field.required} onChange={event => onChange({ ...values, [field.id]: event.target.value })} placeholder={field.placeholder} className="rounded-xl border border-[#CADDD2] bg-[#F8FBF9] px-3 py-2.5 text-sm text-[#18352D] outline-none focus:border-[#1F5A4A]" /></label>)}
      </div>
    </div>
  );
}

const normalizeOcrFieldKey = (value: string) => value.toLocaleLowerCase("vi").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/[^a-z0-9]+/g, "");

export const matchOcrFieldId = (fields: Array<{ id: string; label: string }>, extracted: { key?: string; label?: string }) => {
  const candidates = [extracted.key, extracted.label].filter(Boolean).map(value => normalizeOcrFieldKey(String(value)));
  if (!candidates.length) return undefined;
  const normalizedFields = fields.map(field => ({ ...field, idKey: normalizeOcrFieldKey(field.id), labelKey: normalizeOcrFieldKey(field.label) }));
  const exact = normalizedFields.find(field => candidates.some(candidate => candidate === field.idKey || candidate === field.labelKey));
  if (exact) return exact.id;
  const fuzzy = normalizedFields.find(field => candidates.some(candidate => candidate.length >= 4 && (candidate.includes(field.idKey) || candidate.includes(field.labelKey) || field.idKey.includes(candidate) || field.labelKey.includes(candidate))));
  return fuzzy?.id;
};

export type SourceOcrExtractedField = {
  key?: string;
  label?: string;
  value?: string;
  confidence?: number;
  evidence?: string;
};

export function mapSourceWorkflowOcrFields(
  stepFields: Array<{ id: string; label: string }>,
  intakeFields: Array<{ id: string; label: string }>,
  extractedFields: SourceOcrExtractedField[],
) {
  const workflowValues: Record<string, string> = {};
  const intakeValues: Record<string, string> = {};
  const preview: SourceWorkflowOcrPreviewField[] = [];

  for (const extracted of extractedFields) {
    const value = String(extracted.value ?? "").trim();
    if (!value) continue;
    const stepKey = matchOcrFieldId(stepFields, extracted);
    const intakeKey = matchOcrFieldId(intakeFields, extracted);
    if (stepKey) workflowValues[stepKey] = value;
    if (intakeKey) intakeValues[intakeKey] = value;
    preview.push({
      id: `${extracted.key || extracted.label || preview.length}-${preview.length}`,
      label: extracted.label || extracted.key || "Trường nhận diện",
      value,
      fieldId: stepKey || intakeKey,
      confidence: Number(extracted.confidence) || 0,
      evidence: extracted.evidence,
    });
  }

  return {
    workflowValues,
    intakeValues,
    filledFieldIds: Array.from(new Set([...Object.keys(workflowValues), ...Object.keys(intakeValues)])),
    preview,
  };
}

function SourceCreationWorkspace({
  areas,
  onSubmit,
  onClose,
}: {
  areas: Array<{ id: number; name: string; province: string }>;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  onClose: () => void;
}) {
  const [sourceType, setSourceType] = useState<SourceChannelKey | "">("");
  const [sourcePickerOpen, setSourcePickerOpen] = useState(false);
  const [sourceSearch, setSourceSearch] = useState("");
  const [categoryKey, setCategoryKey] = useState("");
  const [propertySubtype, setPropertySubtype] = useState("");
  const [transactionType, setTransactionType] = useState<SourceTransactionType | "">("");
  const [usePurpose, setUsePurpose] = useState<SourceUsePurpose | "">("");
  const [activeWorkflowStep, setActiveWorkflowStep] = useState("");
  const [workflowStepValues, setWorkflowStepValues] = useState<Record<string, string>>({});
  const [intakeValues, setIntakeValues] = useState<Record<string, string>>({});
  const [sourceCode, setSourceCode] = useState("");
  const [warehouseStage, setWarehouseStage] = useState<"initial_intake" | "post_draft" | "sales_warehouse">("initial_intake");
  const [postSyncStatus, setPostSyncStatus] = useState("Chưa tạo bài đăng");
  const autoAiStepRef = useRef("");
  const category = SOURCE_PROPERTY_CATEGORIES.find(item => item.key === categoryKey);
  const context = sourceType
    ? getSourceCreationContext(sourceType, transactionType, usePurpose, categoryKey, propertySubtype)
    : null;
  const source = SOURCE_CHANNELS.find(item => item.key === sourceType);
  const filteredSources = SOURCE_CHANNELS.filter(item => `${item.label} ${item.shortLabel} ${item.description}`.toLocaleLowerCase("vi").includes(sourceSearch.trim().toLocaleLowerCase("vi")));
  const sourceContext = context ? { ...context, sourceCode, warehouseGroup: source?.shortLabel || source?.label || "", intakeValues, workflowStepValues, warehouseStage, postSyncStatus } : null;
  const sourceWorkflowOcr = trpc.sourceWorkflow.ocr.useMutation();
  useEffect(() => {
    if (source?.workflow.length && !activeWorkflowStep) setActiveWorkflowStep(source.workflow[0]);
  }, [source?.key, source?.workflow, activeWorkflowStep]);
  const handleSourceSelect = (nextSource: SourceChannelKey) => {
    const nextCode = makeSourceCode(nextSource);
    setSourceType(nextSource);
    setSourcePickerOpen(false);
    setSourceSearch("");
    setSourceCode(nextCode);
    setTransactionType("");
    setUsePurpose("");
    setCategoryKey("");
    setPropertySubtype("");
    setActiveWorkflowStep("");
    setWorkflowStepValues({});
    setIntakeValues({});
    setWarehouseStage("initial_intake");
    setPostSyncStatus("Chưa tạo bài đăng");
    toast.info(`Đã chọn ${SOURCE_CHANNELS.find(item => item.key === nextSource)?.label}. Đang mở form tiếp nhận riêng.`);
    toast.success(`Đã tạo mã nguồn tạm ${nextCode}`);
  };
  const handleSourceSubmit = (event: FormEvent<HTMLFormElement>) => {
    const fields = sourceType ? SOURCE_INTAKE_FIELDS[sourceType] : [];
    const missing = fields.filter(field => field.required && !String(intakeValues[field.id] || "").trim());
    if (!sourceCode || missing.length) {
      event.preventDefault();
      toast.error(missing.length ? `Vui lòng bổ sung: ${missing.map(field => field.label).join(", ")}` : "Chưa có mã nguồn.");
      return;
    }
    setWarehouseStage("post_draft");
    setPostSyncStatus("AI đã nhận dữ liệu và tạo bài đăng nháp để Sale kiểm tra");
    toast.success(`${sourceCode} đã vào Kho tiếp nhận nguồn ban đầu; AI đang đồng bộ sang bài đăng nháp.`);
    onSubmit(event);
  };

  const advanceWorkflowStep = (schema: SourceWorkflowStepSchema, index: number) => {
    const now = new Date().toISOString();
    const nextStep = source?.workflow[index + 1];
    if (schema.automationMode === "ai_review") {
      const latestLog = readSourceWorkflowStepAiLogs(workflowStepValues, schema.id).at(-1);
      if (!latestLog || latestLog.reviewerStatus !== "confirmed") {
        toast.error("Cần chạy AI và xác nhận kết quả trước khi chuyển bước.");
        return;
      }
    }
    if (workflowStepValues.sourceCodeForm) setSourceCode(workflowStepValues.sourceCodeForm);
    setWorkflowStepValues(current => ({
      ...current,
      [`${schema.id}-status`]: nextStep ? "Đã hoàn tất · Đã chuyển bước" : "Đã hoàn tất",
      [`${schema.id}-completedAt`]: now,
      [`${schema.id}-audit`]: `Đã hoàn tất ${schema.title} lúc ${new Date(now).toLocaleString("vi-VN")}${nextStep ? `; chuyển sang ${nextStep}` : "; đây là bước cuối"}`,
    }));
    if (nextStep) {
      setActiveWorkflowStep(nextStep);
      toast.success(`Đã lưu ${schema.title} và chuyển sang bước ${index + 2}: ${nextStep}`);
    } else {
      toast.success(`Đã hoàn tất bước cuối: ${schema.title}`);
    }
  };

  const readStepLogs = (stepId: string) => readSourceWorkflowStepAiLogs(workflowStepValues, stepId);
  const persistStepLogs = (stepId: string, logs: SourceWorkflowStepAiLog[]) => setWorkflowStepValues(current => ({ ...current, [`${stepId}-aiLogs`]: JSON.stringify(logs) }));
  const runStepAiAnalysis = (schema: SourceWorkflowStepSchema) => {
    const lower = schema.title.toLocaleLowerCase("vi");
    const allInput = { ...intakeValues, ...workflowStepValues };
    const inputData = Object.entries(allInput).filter(([, value]) => String(value || "").trim()).map(([key, value]) => `${key}: ${value}`).join("; ") || "Chưa có dữ liệu đầu vào";
    const sourceFields = [...SOURCE_COMMON_STEP_FIELDS, ...schema.fields];
    const missing = sourceFields.filter(field => field.required && !String(workflowStepValues[field.id] || intakeValues[field.id] || "").trim());
    const isCodeStep = lower.includes("tạo mã");
    const isInventoryStep = lower.includes("vào kho");
    const suggestedSourceCode = sourceCode || makeSourceCode(sourceType || "owner");
    const suggestedPropertyCode = `${suggestedSourceCode}-BDS-${Date.now().toString().slice(-5)}`;
    const aiSummary = missing.length ? `AI đã đọc gói dữ liệu nhưng còn thiếu: ${missing.map(field => field.label).join(", ")}.` : `AI đã đọc ${Object.keys(allInput).length} dữ liệu nguồn, đối chiếu hồ sơ và tạo đề xuất cho bước ${schema.title}.`;
    const nextValues: Record<string, string> = {
      ...workflowStepValues,
      [`${schema.id}-status`]: "AI đã phân tích · chờ người duyệt",
      [`${schema.id}-aiSummary`]: aiSummary,
      [`${schema.id}-aiDecision`]: missing.length ? "Cần bổ sung" : "Đạt",
      [`${schema.id}-aiInputSnapshot`]: inputData,
      [`${schema.id}-aiRunAt`]: new Date().toISOString(),
    };
    if (isCodeStep) {
      nextValues.sourceCodeForm = suggestedSourceCode;
      nextValues.propertyCodeForm = suggestedPropertyCode;
      nextValues[`${schema.id}-aiSummary`] = missing.length ? aiSummary : `AI đã sinh mã nguồn ${suggestedSourceCode} và mã BĐS/sản phẩm ${suggestedPropertyCode}. Người dùng cần kiểm tra trước khi lưu.`;
    }
    if (isInventoryStep) {
      nextValues.warehouseDecision = missing.length ? "Chờ bổ sung" : "Đủ điều kiện vào kho";
      nextValues.warehouseTarget = "Kho nguồn tổng";
    }
    setWorkflowStepValues(nextValues);
    const log: SourceWorkflowStepAiLog = {
      id: `${schema.id}-ai-${Date.now()}`,
      timestamp: new Date().toISOString(),
      step: schema.title,
      checkType: isCodeStep ? "AI sinh mã nguồn và mã BĐS/sản phẩm" : isInventoryStep ? "AI kiểm tra điều kiện đưa vào kho" : schema.aiAction,
      inputData,
      result: missing.length ? `${aiSummary} AI chưa cho phép hoàn tất tự động.` : aiSummary,
      severity: missing.length ? "warning" : "info",
      recommendation: missing.length ? "Bổ sung dữ liệu còn thiếu, sau đó chạy lại AI." : "Người dùng kiểm tra, chỉnh sửa nếu cần và xác nhận kết quả AI trước khi chuyển bước.",
      reviewerStatus: "pending",
    };
    persistStepLogs(schema.id, [...readStepLogs(schema.id), log]);
    toast.success(`AI đã phân tích bước ${schema.title}; vui lòng kiểm tra và xác nhận kết quả.`);
  };
  useEffect(() => {
    if (!activeWorkflowStep || !sourceType) return;
    const schema = getSourceWorkflowStepSchema(activeWorkflowStep, sourceType);
    if (schema.automationMode !== "ai_review") return;
    const key = `${sourceType}:${schema.id}`;
    if (autoAiStepRef.current === key || readSourceWorkflowStepAiLogs(workflowStepValues, schema.id).length > 0) return;
    autoAiStepRef.current = key;
    runStepAiAnalysis(schema);
  }, [activeWorkflowStep, sourceType]);
  const updateAiLogReview = (schemaId: string, logId: string, reviewerStatus: SourceWorkflowStepAiLog["reviewerStatus"], reviewerNotes?: string) => {
    const reviewedAt = new Date().toISOString();
    persistStepLogs(schemaId, readStepLogs(schemaId).map(log => log.id === logId ? { ...log, reviewerStatus, reviewedAt, ...(reviewerNotes === undefined ? {} : { reviewerNotes }) } : log));
  };
  const handleWorkflowFileUpload = async (schema: SourceWorkflowStepSchema, file: File) => {
    const supportedOcr = ["image/jpeg", "image/png", "image/webp", "application/pdf"].includes(file.type);
    if (file.size > 12 * 1024 * 1024) {
      toast.error("Tệp OCR không được vượt quá 12MB.");
      return;
    }
    const fileId = `${schema.id}-${Date.now()}-${file.name}`;
    const queuedFile: SourceWorkflowFileRecord = {
      id: fileId,
      name: file.name,
      size: file.size,
      mimeType: file.type,
      status: supportedOcr ? "uploading" : "unsupported",
      uploadedAt: new Date().toISOString(),
    };
    setWorkflowStepValues(current => {
      const entries = [...readSourceWorkflowFiles(current, schema.id), queuedFile];
      return {
        ...current,
        [`${schema.id}-files`]: entries.map(item => item.name).join(" · "),
        [`${schema.id}-fileEntries`]: JSON.stringify(entries),
        [`${schema.id}-fileStatus`]: supportedOcr ? "Đang tải và chạy OCR" : "Đã ghi nhận tệp; loại này không chạy OCR",
      };
    });
    if (!supportedOcr) {
      toast.info(`${file.name} đã được ghi nhận. OCR hiện áp dụng cho ảnh và PDF.`);
      return;
    }
    try {
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || "").split(",")[1] || "");
        reader.onerror = () => reject(new Error("Không đọc được tệp"));
        reader.readAsDataURL(file);
      });
      const stepFields = [...SOURCE_COMMON_STEP_FIELDS, ...schema.fields].map(field => ({ id: field.id, label: field.label }));
      const intakeFields = (sourceType ? SOURCE_INTAKE_FIELDS[sourceType] : []).map(field => ({ id: field.id, label: field.label }));
      const fields = Array.from(new Map([...stepFields, ...intakeFields].map(field => [field.id, field])).values());
      const result = await sourceWorkflowOcr.mutateAsync({ sourceLabel: source?.label || "Nguồn hàng", stepTitle: schema.title, fileName: file.name, mimeType: file.type as "image/jpeg" | "image/png" | "image/webp" | "application/pdf", data, fields });
      const mappedOcr = mapSourceWorkflowOcrFields(stepFields, intakeFields, result.fields);
      const autofilledValues = mappedOcr.workflowValues;
      const intakeAutofilledValues = mappedOcr.intakeValues;
      const preview = mappedOcr.preview.map((item, index) => ({ ...item, id: `${fileId}-${item.id}-${index}` }));
      const filledIds = mappedOcr.filledFieldIds;
      const warnings = result.warnings.length ? ` Cảnh báo: ${result.warnings.join("; ")}` : "";
      const log: SourceWorkflowStepAiLog = { id: `${schema.id}-ocr-${Date.now()}`, timestamp: new Date().toISOString(), step: schema.title, checkType: "OCR tài liệu và tự điền form", inputData: `Tệp: ${file.name}; ${result.fields.length} trường nhận diện; độ tin cậy ${Math.round(result.overallConfidence * 100)}%`, result: `Đã nhận diện ${result.fields.filter(field => field.value.trim()).length}/${result.fields.length} trường.${warnings}`, severity: result.warnings.length || result.overallConfidence < 0.7 ? "warning" : "info", recommendation: "Đối chiếu từng trường với bản gốc rồi xác nhận kết quả OCR trước khi chuyển bước.", reviewerStatus: "pending" };
      setWorkflowStepValues(current => {
        const entries = readSourceWorkflowFiles(current, schema.id).map(item => item.id === fileId ? { ...item, status: "ocr_complete" as const, url: result.fileUrl, storageKey: result.storageKey, ocrFieldIds: filledIds } : item);
        const logs = [...readSourceWorkflowStepAiLogs(current, schema.id), log];
        return {
          ...current,
          ...autofilledValues,
          ...intakeAutofilledValues,
          [`${schema.id}-files`]: entries.map(item => item.name).join(" · "),
          [`${schema.id}-fileEntries`]: JSON.stringify(entries),
          [`${schema.id}-fileUrl`]: result.fileUrl,
          [`${schema.id}-fileStatus`]: "OCR hoàn tất · chờ người duyệt",
          [`${schema.id}-ocrPreview`]: JSON.stringify(preview),
          [`${schema.id}-ocrFilledFields`]: JSON.stringify(filledIds),
          [`${schema.id}-ocrFilledAt`]: new Date().toISOString(),
          [`${schema.id}-aiLogs`]: JSON.stringify(logs),
        };
      });
      if (Object.keys(intakeAutofilledValues).length) setIntakeValues(current => ({ ...current, ...intakeAutofilledValues }));
      if (!Object.keys(autofilledValues).length && result.fields.length) toast.warning("OCR đã đọc được nội dung nhưng chưa khớp trường form. Hãy kiểm tra phần xem trước hoặc chỉnh tay.");
      toast.success(`OCR đã hoàn tất và đề xuất điền form ${schema.title}.`);
    } catch (error) {
      setWorkflowStepValues(current => {
        const entries = readSourceWorkflowFiles(current, schema.id).map(item => item.id === fileId ? { ...item, status: "error" as const, error: error instanceof Error ? error.message : "Không thể chạy OCR" } : item);
        return { ...current, [`${schema.id}-fileEntries`]: JSON.stringify(entries), [`${schema.id}-fileStatus`]: "OCR lỗi · cần thử lại" };
      });
      toast.error(error instanceof Error ? error.message : "Không thể chạy OCR cho tệp này.");
    }
  };

  return (
    <section id="tao-nguon-hang" className="mt-6 scroll-mt-6 rounded-[2rem] border border-[#BFD7CA] bg-white p-4 shadow-[0_18px_50px_rgba(31,90,74,.1)] sm:p-6">
      <div className="flex flex-col gap-4 border-b border-[#DFEAE3] pb-5 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-xs font-black uppercase tracking-[.18em] text-[#1F5A4A]">01.02 · Quy trình</p>
          <h2 className="mt-2 font-serif text-3xl tracking-[-.035em] text-[#18352D]">Tạo nguồn hàng</h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-[#60766D]">Đây là luồng chính theo file cấu trúc bạn gửi. Dữ liệu được chọn một lần, hệ thống sinh workflow theo loại nguồn và loại BĐS; AI/OCR chỉ đề xuất, môi giới phải kiểm tra trước khi lưu.</p>
        </div>
        <button type="button" onClick={onClose} className="inline-flex items-center justify-center gap-2 self-start rounded-full border border-[#CBDDD3] bg-[#F7FAF7] px-4 py-2 text-sm font-bold text-[#365B4F]">
          <X size={16} /> Đóng
        </button>
      </div>

      <SourceWorkspaceModuleManager />

      <div className="mt-5 overflow-x-auto pb-2 [scrollbar-color:#8aa99a_transparent] [scrollbar-width:thin]">
        <ol className="flex min-w-[860px] gap-2">
          {SOURCE_CREATION_PHASES.map((phase, index) => {
            const active = index === 0 ? Boolean(sourceType) : index === 1 ? Boolean(transactionType) : index === 2 ? Boolean(categoryKey) : index === 3 ? Boolean(propertySubtype) : index === 4 ? Boolean(usePurpose) : index === 5 ? Boolean(context) : false;
            return (
              <li key={phase} className={`min-w-[132px] flex-1 rounded-xl border px-3 py-3 ${active ? "border-[#1F5A4A] bg-[#E8F2EC]" : "border-[#DCE8E1] bg-[#F8FAF8]"}`}>
                <span className="text-[10px] font-black uppercase tracking-[.14em] text-[#789087]">Bước {index + 1}</span>
                <p className="mt-1 text-xs font-bold leading-5 text-[#18352D]">{phase}</p>
              </li>
            );
          })}
        </ol>
      </div>

      <div className="mt-5 rounded-2xl border border-[#D8E5DE] bg-[#F5F9F6] p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-xs font-black uppercase tracking-[.16em] text-[#1F5A4A]">Bước 1 · Tìm và chọn nguồn</p>
            <p className="mt-1 text-sm text-[#60766D]">Bấm vào thanh tìm kiếm để mở 8 bộ nguồn. Chọn nguồn xong mới mở các tầng tiếp theo.</p>
          </div>
          <span className="rounded-full bg-white px-3 py-1.5 text-xs font-black text-[#1F5A4A]">{sourceType ? `Đã chọn: ${source?.shortLabel}` : "Chưa chọn nguồn"}</span>
        </div>
        <div className="mt-3 flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Search size={17} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#789087]" />
            <input value={sourceSearch} onChange={event => { setSourceSearch(event.target.value); setSourcePickerOpen(true); }} onFocus={() => setSourcePickerOpen(true)} placeholder="Tìm CTV, môi giới nội bộ, thị trường, chủ nhà..." className="w-full rounded-xl border border-[#C8DBCF] bg-white py-3 pl-10 pr-4 text-sm text-[#18352D] outline-none focus:border-[#1F5A4A] focus:ring-2 focus:ring-[#1F5A4A]/10" />
          </div>
          <button type="button" onClick={() => setSourcePickerOpen(open => !open)} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#1F5A4A] px-4 py-3 text-sm font-black text-white hover:bg-[#174638]"><Search size={16} />{sourcePickerOpen ? "Đóng 7 bộ nguồn" : "Mở 7 bộ nguồn"}</button>
        </div>
        {sourcePickerOpen && (
          <div className="mt-3 grid gap-2 border-t border-[#D8E5DE] pt-3 sm:grid-cols-2 lg:grid-cols-4">
            {filteredSources.map(item => <button key={item.key} type="button" onClick={() => handleSourceSelect(item.key)} className={`rounded-xl border p-3 text-left ${sourceType === item.key ? "border-[#1F5A4A] bg-white ring-2 ring-[#1F5A4A]/10" : "border-[#D8E5DE] bg-white/70 hover:border-[#9ABCAA]"}`}><span className="text-sm font-black text-[#18352D]">{item.shortLabel}</span><span className="mt-1 block text-xs leading-5 text-[#60766D]">{item.description}</span></button>)}
            {!filteredSources.length && <p className="text-sm text-[#60766D] sm:col-span-2 lg:col-span-4">Không tìm thấy bộ nguồn phù hợp.</p>}
          </div>
        )}
      </div>
      {sourceType && (
        <div className="mt-5 rounded-2xl bg-[#F8F6EF] p-4 sm:p-5">
          <p className="text-xs font-black uppercase tracking-[.16em] text-[#80601C]">Bước 2 · Chọn loại giao dịch</p>
          <p className="mt-1 text-sm leading-6 text-[#60766D]">Chọn loại giao dịch, danh mục và loại BĐS trước; mục đích sử dụng được chọn ở cuối để hệ thống tạo đúng form nguồn và hồ sơ tư vấn.</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {SOURCE_TRANSACTION_TYPES.map(item => <button key={item.key} type="button" onClick={() => { setTransactionType(item.key); setUsePurpose(""); setCategoryKey(""); setPropertySubtype(""); }} className={`rounded-xl border px-3 py-3 text-left text-sm font-black ${transactionType === item.key ? "border-[#1F5A4A] bg-[#E8F2EC] text-[#1F5A4A] ring-2 ring-[#1F5A4A]/10" : "border-[#D9D1B8] bg-white text-[#365B4F] hover:border-[#9ABCAA]"}`}>{item.label}</button>)}
          </div>
          <div className="mt-5 border-t border-[#E4DCC7] pt-4">
            <p className="text-xs font-black uppercase tracking-[.16em] text-[#80601C]">Bước 3 · Chọn danh mục và loại BĐS</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5 text-xs font-bold text-[#365B4F]">Danh mục BĐS<select value={categoryKey} disabled={!transactionType} onChange={event => { setCategoryKey(event.target.value); setPropertySubtype(""); setUsePurpose(""); }} className="rounded-xl border border-[#D9D1B8] bg-white p-3 text-sm text-[#18352D] disabled:cursor-not-allowed disabled:opacity-50"><option value="">Chọn danh mục BĐS</option>{SOURCE_PROPERTY_CATEGORIES.map(item => <option key={item.key} value={item.key}>{item.label}</option>)}</select></label>
              <label className="grid gap-1.5 text-xs font-bold text-[#365B4F]">Loại BĐS<select value={propertySubtype} disabled={!category} onChange={event => { setPropertySubtype(event.target.value); setUsePurpose(""); }} className="rounded-xl border border-[#D9D1B8] bg-white p-3 text-sm text-[#18352D] disabled:cursor-not-allowed disabled:opacity-50"><option value="">Chọn loại BĐS</option>{(category?.subtypes || []).map(item => <option key={item} value={item}>{item}</option>)}</select></label>
            </div>
          </div>
          <div className="mt-5 border-t border-[#E4DCC7] pt-4">
            <p className="text-xs font-black uppercase tracking-[.16em] text-[#80601C]">Bước 4 · Mục đích sử dụng</p>
            <div className="mt-3 grid gap-3 sm:grid-cols-2 md:grid-cols-4">
              {SOURCE_USE_PURPOSES.map(item => <button key={item.key} type="button" disabled={!propertySubtype} onClick={() => setUsePurpose(item.key)} className={`rounded-xl border px-3 py-3 text-left text-sm font-black disabled:cursor-not-allowed disabled:opacity-45 ${usePurpose === item.key ? "border-[#1F5A4A] bg-[#E8F2EC] text-[#1F5A4A] ring-2 ring-[#1F5A4A]/10" : "border-[#D9D1B8] bg-white text-[#365B4F] hover:border-[#9ABCAA]"}`}>{item.label}</button>)}
            </div>
            <p className="mt-3 rounded-xl border border-dashed border-[#D9D1B8] bg-white/80 p-3 text-xs leading-5 text-[#60766D]">Sau khi chọn đủ loại giao dịch, danh mục, loại BĐS và mục đích sử dụng, form nhập thông tin, OCR giấy tờ, ảnh/camera và video sẽ hiện.</p>
          </div>
        </div>
      )}

      {source && (
        <div className="mt-5 rounded-2xl border border-[#D8E5DE] bg-[#FBFDFC] p-4 sm:p-5">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-xs font-black uppercase tracking-[.16em] text-[#1F5A4A]">Workflow tự động · {source.label}</p>
              <p className="mt-1 text-sm text-[#60766D]">Hệ thống đã chọn chuỗi xử lý theo nguồn. Mỗi bước hỗ trợ nhập dữ liệu, upload/chụp ảnh, OCR, AI phân tích, xác nhận và lưu kết quả.</p>
            </div>
            <span className="shrink-0 rounded-full bg-[#E8F2EC] px-3 py-1.5 text-xs font-black text-[#1F5A4A]">{source.workflow.length} bước</span>
          </div>
          <div className="mt-4 flex gap-2 overflow-x-auto pb-2 [scrollbar-color:#8aa99a_transparent] [scrollbar-width:thin]">
            {source.workflow.map((step, index) => (
              <button key={`${step}-${index}`} type="button" onClick={() => { setActiveWorkflowStep(step); window.setTimeout(() => document.getElementById("workflow-step-form")?.scrollIntoView({ behavior: "smooth", block: "start" }), 0); }} className={`min-w-[165px] rounded-xl border px-3 py-3 text-left ${activeWorkflowStep === step ? "border-[#1F5A4A] bg-[#E8F2EC] ring-2 ring-[#1F5A4A]/10" : "border-[#DDE9E2] bg-white hover:border-[#9ABCAA]"}`}>
                <span className="text-[10px] font-black text-[#91A59B]">{String(index + 1).padStart(2, "0")}</span>
                <p className="mt-1 text-xs font-bold text-[#18352D]">{step}</p>
                <span className="mt-2 block text-[10px] font-bold text-[#71877D]">Mở form bước này</span>
              </button>
            ))}
          </div>
          {activeWorkflowStep && sourceType ? (() => {
            const schema = getSourceWorkflowStepSchema(activeWorkflowStep, sourceType);
            const responsibility = getWorkflowStepResponsibility(activeWorkflowStep, sourceType);
            const stepDeadline = workflowStepValues[`${schema.id}-processingDeadline`] || workflowStepValues.processingDeadline || "";
            const stepStatus = workflowStepValues[`${schema.id}-status`] || "";
            const isStepOverdue = Boolean(stepDeadline && new Date(`${stepDeadline}T23:59:59`).getTime() < Date.now() && !["Đã chuyển bước tiếp theo", "Đã hoàn tất"].includes(stepStatus));
            const stepFiles = readSourceWorkflowFiles(workflowStepValues, schema.id);
            const ocrPreview = readSourceWorkflowOcrPreview(workflowStepValues, schema.id);
            const isIntakeStep = sourceStepFormKey(activeWorkflowStep) === "intake";
            const visibleFields = Array.from(new Map([
              ...SOURCE_COMMON_STEP_FIELDS,
              ...schema.fields,
              ...(isIntakeStep ? (SOURCE_INTAKE_FIELDS[sourceType] || []).map(field => ({ ...field, type: "text" as const, hint: undefined, options: undefined })) : []),
            ].map(field => [field.id, field])).values()) as SourceProcedureField[];
            const getWorkflowFieldValue = (field: SourceProcedureField | { id: string }) => workflowStepValues[field.id] ?? intakeValues[field.id] ?? "";
            let filledFieldIds: string[] = [];
            try {
              const parsed = JSON.parse(workflowStepValues[`${schema.id}-ocrFilledFields`] || "[]");
              filledFieldIds = Array.isArray(parsed) ? parsed.map(String) : [];
            } catch {
              filledFieldIds = [];
            }
            const intakeFieldIds = new Set((sourceType ? SOURCE_INTAKE_FIELDS[sourceType] : []).map(field => field.id));
            const updateWorkflowField = (field: SourceProcedureField, value: string | boolean) => {
              const nextValue = String(value);
              setWorkflowStepValues(current => ({ ...current, [field.id]: nextValue }));
              if (isIntakeStep && intakeFieldIds.has(field.id)) {
                setIntakeValues(current => ({ ...current, [field.id]: nextValue }));
              }
            };
            const removeWorkflowFile = (fileId: string) => {
              setWorkflowStepValues(current => {
                const entries = readSourceWorkflowFiles(current, schema.id).filter(item => item.id !== fileId);
                const next = { ...current, [`${schema.id}-files`]: entries.map(item => item.name).join(" · ") };
                if (entries.length) next[`${schema.id}-fileEntries`] = JSON.stringify(entries);
                else {
                  delete next[`${schema.id}-fileEntries`];
                  delete next[`${schema.id}-files`];
                  delete next[`${schema.id}-fileUrl`];
                  next[`${schema.id}-fileStatus`] = "Chưa có tệp";
                }
                return next;
              });
              toast.success("Đã xóa tệp khỏi gói dữ liệu của bước này.");
            };
            return <div id="workflow-step-form" className="mt-4 scroll-mt-6 rounded-2xl border border-[#BFD7CA] bg-white p-4 sm:p-5">
              {isStepOverdue ? <div role="alert" className="mb-4 flex flex-col gap-2 rounded-xl border border-[#E7B6A6] bg-[#FFF3EE] px-3 py-3 text-sm text-[#8A3F2D] sm:flex-row sm:items-center sm:justify-between"><div><b>Cảnh báo quá hạn xử lý</b><p className="mt-1 text-xs">Bước này đã quá hạn {stepDeadline}. Vui lòng cập nhật hồ sơ hoặc chuyển cho người phụ trách.</p></div><span className="rounded-full bg-[#F8D8CC] px-2.5 py-1 text-xs font-black">Cần xử lý ngay</span></div> : null}
              <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-black uppercase tracking-[.16em] text-[#1F5A4A]">Form bước {source.workflow.indexOf(activeWorkflowStep) + 1} · {schema.title}</p><h3 className="mt-1 text-lg font-black text-[#18352D]">{schema.task}</h3></div><span className="rounded-full bg-[#FFF5D8] px-3 py-1.5 text-xs font-black text-[#80601C]">Độc lập theo nguồn</span></div>
              <div className="mt-4 rounded-2xl border border-[#BFD7CA] bg-[#F5F9F6] p-4"><p className="text-xs font-black uppercase tracking-[.14em] text-[#1F5A4A]">Luồng xử lý của nguồn</p><div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-5"><div className="rounded-xl border border-[#CFE3D6] bg-white p-3"><b className="text-xs text-[#1F5A4A]">👤 Con người</b><p className="mt-1 text-xs leading-5 text-[#60766D]">Nhập và xác nhận dữ liệu bước này.</p></div><div className="rounded-xl border border-[#CFE3D6] bg-white p-3"><b className="text-xs text-[#1F5A4A]">📦 Data Package</b><p className="mt-1 text-xs leading-5 text-[#60766D]">Gom dữ liệu gốc, tài liệu và media.</p></div><div className="rounded-xl border border-[#D9D1B8] bg-[#FFF9E8] p-3"><b className="text-xs text-[#80601C]">🤖 AI</b><p className="mt-1 text-xs leading-5 text-[#60766D]">{responsibility.action}</p></div><div className="rounded-xl border border-[#D9D1B8] bg-[#FFF9E8] p-3"><b className="text-xs text-[#80601C]">👤 Duyệt</b><p className="mt-1 text-xs leading-5 text-[#60766D]">Đối chiếu và xác nhận kết quả AI.</p></div><div className="rounded-xl border border-[#D9D1B8] bg-[#FFF9E8] p-3"><b className="text-xs text-[#80601C]">⚙️ Code → Inventory</b><p className="mt-1 text-xs leading-5 text-[#60766D]">{responsibility.warehouseCondition}</p></div></div></div>
              {schema.automationMode === "ai_review" ? <div className="mt-4 rounded-xl border border-[#D9D1B8] bg-[#FFF9E8] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><b className="text-xs font-black uppercase tracking-[.14em] text-[#80601C]">🤖 AI tự động · Người dùng duyệt sau</b><p className="mt-1 text-xs text-[#60766D]">AI đã đọc toàn bộ dữ liệu các bước trước, tạo kết quả đề xuất và mở form để bạn kiểm tra, chỉnh sửa rồi xác nhận.</p></div><button type="button" onClick={() => runStepAiAnalysis(schema)} className="rounded-lg border border-[#80601C] px-3 py-2 text-xs font-black text-[#80601C]">Chạy lại AI</button></div></div> : null}
              <div className="mt-4 rounded-xl border border-[#CFE3D6] bg-[#F4F8F5] p-3"><b className="text-xs text-[#1F5A4A]">👤 Phần con người · {schema.task}</b><p className="mt-1 text-xs leading-5 text-[#60766D]">Đăng nhập để nhập dữ liệu, tải/chụp tài liệu và hoàn tất các trường bắt buộc trước khi đóng gói.</p></div>
              <div className="mt-4 grid gap-3 md:grid-cols-2">{visibleFields.map(field => { const isAutofilled = filledFieldIds.includes(field.id); const fieldClass = `rounded-xl border px-3 py-2.5 text-sm text-[#18352D] ${isAutofilled ? "border-[#B88A2A] bg-[#FFF9E8] ring-2 ring-[#FFF0BC]" : "border-[#CADDD2] bg-[#F8FBF9]"}`; return <label key={field.id} className="grid gap-1.5 text-xs font-bold text-[#365B4F]"><span className="flex items-center gap-2">{field.label}{field.required ? <b className="text-red-600">*</b> : null}{isAutofilled ? <em className="rounded-full bg-[#FFF0BC] px-2 py-0.5 text-[10px] font-black not-italic text-[#80601C]">OCR tự điền</em> : null}</span>{field.type === "select" ? <select value={String(getWorkflowFieldValue(field))} onChange={event => updateWorkflowField(field, event.target.value)} className={fieldClass}><option value="">Chọn trạng thái</option>{(field.options || []).map(option => <option key={option} value={option}>{option}</option>)}</select> : field.type === "textarea" ? <textarea value={String(getWorkflowFieldValue(field))} onChange={event => updateWorkflowField(field, event.target.value)} placeholder={field.placeholder} className={`min-h-[92px] ${fieldClass}`} /> : field.type === "checkbox" ? <span className={`flex items-center gap-3 ${fieldClass}`}><input type="checkbox" checked={String(getWorkflowFieldValue(field)) === "true"} onChange={event => updateWorkflowField(field, event.target.checked)} className="h-4 w-4 accent-[#1F5A4A]" /><span className="font-normal text-[#60766D]">{String(getWorkflowFieldValue(field)) === "true" ? "Đã xác nhận" : "Chưa xác nhận"}</span></span> : <input type={field.type} value={String(getWorkflowFieldValue(field))} onChange={event => updateWorkflowField(field, event.target.value)} placeholder={field.placeholder} className={fieldClass} />}{field.hint ? <small className="font-normal text-[#71877D]">{field.hint}</small> : null}</label>; })}</div>
              <div className="mt-4 rounded-2xl border border-[#BFD7CA] bg-[#F8FBF9] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><b className="text-xs font-black uppercase tracking-[.14em] text-[#1F5A4A]">📦 Source Data Package</b><p className="mt-1 text-xs text-[#60766D]">Gói dữ liệu nguồn ban đầu trước khi chuyển sang AI: thông tin người cung cấp, BĐS, hồ sơ, media và kết quả form bước.</p></div><span className="rounded-full bg-[#E8F2EC] px-2.5 py-1 text-[11px] font-black text-[#1F5A4A]">{Object.keys(workflowStepValues).filter(key => key.startsWith(`${schema.id}-`)).length} dữ liệu bước</span></div><div className="mt-3 grid gap-2 sm:grid-cols-3"><div className="rounded-xl bg-white p-3 text-xs"><b className="text-[#1F5A4A]">Nguồn</b><p className="mt-1 text-[#60766D]">{context?.sourceLabel || source?.label || "Chưa chọn nguồn"}</p></div><div className="rounded-xl bg-white p-3 text-xs"><b className="text-[#1F5A4A]">Tài sản</b><p className="mt-1 text-[#60766D]">{context?.propertyCategory || "Chưa chọn nhóm"} · {context?.propertySubtype || "Chưa chọn loại"}</p></div><div className="rounded-xl bg-white p-3 text-xs"><b className="text-[#1F5A4A]">Trạng thái gói</b><p className="mt-1 text-[#60766D]">{workflowStepValues[`${schema.id}-status`] || "Đang nhập dữ liệu"}</p></div></div></div><div className="mt-4 rounded-2xl border border-[#D9E7DE] bg-[#FBFDFC] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><b className="text-xs font-black uppercase tracking-[.14em] text-[#1F5A4A]">Tài liệu & media</b><p className="mt-1 text-xs text-[#60766D]">Tải ảnh, video, PDF hoặc chụp trực tiếp cho bước đang xử lý.</p></div><label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#FFF0BC] px-3 py-2 text-xs font-black text-[#80601C]"><Upload className="h-4 w-4" />Thêm tệp<input type="file" multiple accept="image/*,video/*,.pdf" className="hidden" onChange={async event => { const files = Array.from(event.currentTarget.files || []); for (const file of files) await handleWorkflowFileUpload(schema, file); event.currentTarget.value = ""; }} /></label></div><div className="mt-3 rounded-xl border border-dashed border-[#BFD7CA] bg-white p-3 text-xs text-[#60766D]">Kéo thả tệp vào đây hoặc chọn từ thiết bị · JPG, PNG, MP4, PDF · tối đa 12MB / tệp cho OCR</div><p className="mt-2 text-xs font-bold text-[#80601C]">{workflowStepValues[`${schema.id}-fileStatus`] || (workflowStepValues[`${schema.id}-files`] ? `Tệp đã chọn: ${workflowStepValues[`${schema.id}-files`]}` : "Chưa có tệp. Ảnh/PDF sẽ tự chạy OCR và đề xuất điền form.")}</p>{stepFiles.length ? <div className="mt-3 overflow-x-auto rounded-xl border border-[#D9E7DE] bg-white"><div className="min-w-[660px]"><div className="grid grid-cols-[1.5fr_.8fr_1fr_1fr_auto] gap-3 border-b border-[#E5EEE8] bg-[#F4F8F5] px-3 py-2 text-[11px] font-black uppercase tracking-wide text-[#60766D]"><span>Tệp</span><span>Dung lượng</span><span>Loại</span><span>Trạng thái</span><span>Thao tác</span></div>{stepFiles.map(item => <div key={item.id} className="grid grid-cols-[1.5fr_.8fr_1fr_1fr_auto] items-center gap-3 border-b border-[#EEF4F0] px-3 py-3 text-xs last:border-0"><div className="min-w-0"><p className="truncate font-bold text-[#18352D]" title={item.name}>{item.name}</p><p className="mt-0.5 text-[10px] text-[#71877D]">{new Date(item.uploadedAt).toLocaleString("vi-VN")}</p></div><span className="text-[#60766D]">{formatSourceWorkflowFileSize(item.size)}</span><span className="truncate text-[#60766D]">{item.mimeType || "Tệp cũ"}</span><span className={`font-bold ${item.status === "ocr_complete" ? "text-[#1F5A4A]" : item.status === "error" ? "text-red-700" : item.status === "unsupported" ? "text-[#80601C]" : "text-[#60766D]"}`}>{item.status === "ocr_complete" ? "OCR hoàn tất" : item.status === "error" ? "OCR lỗi" : item.status === "unsupported" ? "Đã lưu · chưa OCR" : item.status === "uploading" ? "Đang xử lý" : "Đã lưu"}</span><div className="flex items-center gap-1.5">{item.url ? <a href={item.url} target="_blank" rel="noreferrer" aria-label={`Xem ${item.name}`} className="inline-flex items-center gap-1 rounded-lg border border-[#BFD7CA] px-2 py-1 font-bold text-[#1F5A4A]"><Eye className="h-3.5 w-3.5" />Xem</a> : null}<button type="button" onClick={() => removeWorkflowFile(item.id)} aria-label={`Xóa ${item.name}`} className="inline-flex items-center gap-1 rounded-lg border border-red-200 px-2 py-1 font-bold text-red-700"><Trash2 className="h-3.5 w-3.5" />Xóa</button></div></div>)}</div></div> : null}{ocrPreview.length ? <div className="mt-3 rounded-xl border border-[#D9D1B8] bg-[#FFFDF4] p-3"><div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between"><b className="text-xs font-black uppercase tracking-[.12em] text-[#80601C]">Preview dữ liệu OCR</b><span className="text-[11px] font-bold text-[#60766D]">Đã tự điền vào form · cần reviewer đối chiếu bản gốc</span></div><div className="mt-2 space-y-2">{ocrPreview.map(item => { const destination = [...SOURCE_COMMON_STEP_FIELDS, ...schema.fields].find(field => field.id === item.fieldId); return <div key={item.id} className="grid gap-1 rounded-lg bg-white p-2.5 text-xs sm:grid-cols-[1fr_1.2fr_1fr_auto] sm:items-center"><div><span className="font-bold text-[#365B4F]">{item.label}</span><span className="block text-[10px] text-[#71877D]">Trường đích: {destination?.label || item.fieldId || "Chưa khớp"}</span></div><span className="break-words text-[#18352D]">{item.value}</span><span className="text-[11px] text-[#60766D]">{item.evidence || "Không có bằng chứng bổ sung"}</span><span className="rounded-full bg-[#E8F2EC] px-2 py-1 text-center text-[10px] font-black text-[#1F5A4A]">{Math.round(item.confidence * 100)}%</span></div>; })}</div></div> : null}<div className="mt-3 grid gap-3 md:grid-cols-2"><label className="grid gap-1.5 text-xs font-bold text-[#365B4F]"><span>Checklist hồ sơ còn thiếu</span><textarea value={workflowStepValues[`${schema.id}-missingDocuments`] || ""} onChange={event => setWorkflowStepValues({ ...workflowStepValues, [`${schema.id}-missingDocuments`]: event.target.value })} placeholder="Nhập giấy tờ còn thiếu hoặc ghi Không" className="min-h-[76px] rounded-xl border border-[#CADDD2] bg-[#F8FBF9] p-3 text-sm text-[#18352D]" /></label><div className="rounded-xl bg-[#F4F8F5] p-3 text-xs text-[#60766D]"><b className="text-[#1F5A4A]">OCR & AI tự điền</b><p className="mt-1">AI chỉ đề xuất; người duyệt phải đối chiếu hồ sơ gốc trước khi xác nhận.</p><p className="mt-2 font-bold text-[#80601C]">{readStepLogs(schema.id).length ? `${readStepLogs(schema.id).length} nhật ký đã lưu theo bước` : "Chưa có nhật ký. Bấm Chạy OCR / AI để bắt đầu phân tích."}</p></div></div><div className="mt-4 rounded-2xl border border-[#D9D1B8] bg-[#FFFDF4] p-4"><div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between"><div><b className="text-xs font-black uppercase tracking-[.14em] text-[#80601C]">NHẬT KÝ KẾT QUẢ AI</b><p className="mt-1 text-xs text-[#60766D]">Lưu theo từng bước: loại kiểm tra, dữ liệu đầu vào, kết quả, mức độ cảnh báo, đề xuất và trạng thái người duyệt.</p></div><span className="rounded-full bg-[#FFF0BC] px-2.5 py-1 text-[11px] font-black text-[#80601C]">{readStepLogs(schema.id).filter(log => log.reviewerStatus === "confirmed").length}/{readStepLogs(schema.id).length} đã xác nhận</span></div>{readStepLogs(schema.id).length === 0 ? <p className="mt-3 rounded-xl bg-white p-3 text-xs text-[#71877D]">Chưa có kết quả AI. Chạy OCR hoặc AI để bắt đầu phân tích.</p> : <div className="mt-3 space-y-3">{readStepLogs(schema.id).map(log => <article key={log.id} className="rounded-xl border border-[#E6DEC2] bg-white p-3 text-xs"><div className="flex flex-wrap items-center justify-between gap-2"><b className="text-[#18352D]">{log.checkType}</b><span className={`rounded-full px-2 py-1 font-black ${log.severity === "critical" ? "bg-red-100 text-red-700" : log.severity === "warning" ? "bg-amber-100 text-amber-800" : "bg-[#E8F2EC] text-[#1F5A4A]"}`}>{log.severity === "critical" ? "Nghiêm trọng" : log.severity === "warning" ? "Cảnh báo" : "Thông tin"}</span></div><p className="mt-2 text-[#365B4F]"><b>Kết quả:</b> {log.result}</p><p className="mt-1 text-[#60766D]"><b>Đề xuất:</b> {log.recommendation}</p><details className="mt-2"><summary className="cursor-pointer font-bold text-[#1F5A4A]">Xem dữ liệu đầu vào · {new Date(log.timestamp).toLocaleString("vi-VN")}</summary><p className="mt-2 rounded-lg bg-[#F8FBF9] p-2 leading-5 text-[#60766D]">{log.inputData}</p></details><div className="mt-3 grid gap-2 sm:grid-cols-[1fr_auto] sm:items-end"><label className="grid gap-1 text-[11px] font-bold text-[#60766D]"><span>Ghi chú xác nhận của reviewer</span><textarea defaultValue={log.reviewerNotes || ""} onBlur={event => updateAiLogReview(schema.id, log.id, log.reviewerStatus, event.target.value)} placeholder="Ghi căn cứ đối chiếu hoặc yêu cầu bổ sung..." className="min-h-[54px] rounded-lg border border-[#D9E7DE] bg-[#F8FBF9] p-2 text-xs text-[#18352D]" /></label><div className="flex flex-wrap items-center gap-2"><span className={`rounded-full px-2 py-1 font-bold ${log.reviewerStatus === "confirmed" ? "bg-[#E8F2EC] text-[#1F5A4A]" : log.reviewerStatus === "rejected" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-700"}`}>{log.reviewerStatus === "confirmed" ? "Đã xác nhận" : log.reviewerStatus === "rejected" ? "Đã từ chối" : "Chờ người duyệt"}</span><button type="button" onClick={() => updateAiLogReview(schema.id, log.id, "confirmed", log.reviewerNotes)} className="rounded-lg border border-[#1F5A4A] px-2.5 py-1.5 font-black text-[#1F5A4A]">Xác nhận</button><button type="button" onClick={() => updateAiLogReview(schema.id, log.id, "rejected", log.reviewerNotes)} className="rounded-lg border border-red-200 px-2.5 py-1.5 font-black text-red-700">Yêu cầu kiểm tra lại</button></div></div>{log.reviewedAt ? <p className="mt-2 text-[11px] text-[#71877D]">Reviewer cập nhật lúc {new Date(log.reviewedAt).toLocaleString("vi-VN")}</p> : null}</article>)}</div>}</div></div><div className="mt-4 grid gap-3 md:grid-cols-3"><div className="rounded-xl bg-[#F4F8F5] p-3"><b className="text-xs text-[#80601C]">🤖 AI · Kiểm tra và phân tích</b><ul className="mt-1 list-disc pl-4 text-xs leading-5 text-[#60766D]">{schema.validation.map(item => <li key={item}>{item}</li>)}</ul></div><div className="rounded-xl bg-[#F4F8F5] p-3"><b className="text-xs text-[#80601C]">🤖 AI Action</b><p className="mt-1 text-xs leading-5 text-[#60766D]">{schema.aiAction}</p><p className="mt-1 text-[11px] text-[#71877D]">Tài liệu: {schema.document}</p></div><div className="rounded-xl bg-[#F4F8F5] p-3"><b className="text-xs text-[#80601C]">👤 Duyệt kết quả AI</b><div className="mt-2 flex flex-wrap gap-1.5">{schema.results.map(result => <button key={result} type="button" onClick={() => setWorkflowStepValues({ ...workflowStepValues, [`${schema.id}-result`]: result })} className={`rounded-full border px-2.5 py-1 text-[11px] font-bold ${workflowStepValues[`${schema.id}-result`] === result ? "border-[#1F5A4A] bg-[#E8F2EC] text-[#1F5A4A]" : "border-[#D9D1B8] text-[#60766D]"}`}>{result}</button>)}</div></div></div>
              <div className="mt-4 flex flex-wrap gap-2"><button type="button" onClick={() => { const allFields = [...SOURCE_COMMON_STEP_FIELDS, ...schema.fields]; const missing = allFields.filter(field => field.required && !String(workflowStepValues[field.id] || "").trim()); if (missing.length) { toast.error(`Vui lòng bổ sung: ${missing.map(field => field.label).join(", ")}`); return; } const savedAt = new Date().toISOString(); setWorkflowStepValues({ ...workflowStepValues, [`${schema.id}-savedAt`]: savedAt, [`${schema.id}-status`]: "Đã lưu - chờ xác nhận", [`${schema.id}-audit`]: `Đã lưu bởi người phụ trách lúc ${new Date(savedAt).toLocaleString("vi-VN")}` }); toast.success(`Đã lưu & kiểm tra bước ${schema.title}`); }} className="rounded-xl bg-[#1F5A4A] px-4 py-2.5 text-xs font-black text-white">Lưu & kiểm tra bước</button><button type="button" onClick={() => runStepAiAnalysis(schema)} className="rounded-xl border border-[#1F5A4A] px-4 py-2.5 text-xs font-black text-[#1F5A4A]">Chạy OCR / AI</button><button type="button" onClick={() => advanceWorkflowStep(schema, source.workflow.indexOf(activeWorkflowStep))} className="rounded-xl border border-[#80601C] px-4 py-2.5 text-xs font-black text-[#80601C]">{source.workflow.indexOf(activeWorkflowStep) === source.workflow.length - 1 ? "Hoàn tất bước cuối" : "Chuyển bước tiếp theo"}</button></div>
            </div>;
          })() : null}
        </div>
      )}

      {!context ? (
        <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900">Hãy chọn đủ <strong>nguồn</strong>, <strong>loại giao dịch</strong>, <strong>mục đích sử dụng</strong>, <strong>nhóm BĐS</strong> và <strong>loại BĐS chi tiết</strong>. Sau đó biểu mẫu nhập thông tin, ảnh/camera, video, giấy tờ và OCR thật sẽ xuất hiện ngay trong quy trình này.</div>
      ) : activeWorkflowStep !== source?.workflow[0] ? null : (
        <div className="mt-5">
          <div className="rounded-2xl bg-[#18352D] p-4 text-white sm:p-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-xs font-black uppercase tracking-[.16em] text-[#E6C478]">Bước 6 · Nhập thông tin ban đầu</p><p className="mt-2 text-sm text-white/75">Form riêng theo nguồn đã sẵn sàng. Sau khi lưu, hồ sơ sẽ đi vào kho tương ứng.</p></div><div className="shrink-0 rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-right"><p className="text-[10px] font-black uppercase tracking-[.12em] text-white/60">Mã nguồn</p><p className="mt-1 text-sm font-black text-[#E6C478]">{sourceCode || "Chưa sinh mã"}</p><p className="mt-1 text-[11px] text-white/70">Kho: {source?.label || "Chưa chọn"}</p></div></div>
            <div className="mt-2 flex flex-wrap gap-2 text-xs font-bold">
              <span className="rounded-full bg-white/10 px-3 py-1.5">Nguồn: {context.sourceLabel}</span>
              <span className="rounded-full bg-white/10 px-3 py-1.5">Giao dịch: {context.transactionPurposeLabel}</span>
              <span className="rounded-full bg-white/10 px-3 py-1.5">Sử dụng: {context.usePurposeLabel}</span>
              <span className="rounded-full bg-white/10 px-3 py-1.5">Nhóm: {context.propertyCategory}</span>
              <span className="rounded-full bg-white/10 px-3 py-1.5">Loại: {context.propertySubtype}</span>
            </div>
            <p className="mt-3 text-sm leading-6 text-white/75">Tải giấy tờ để OCR tự đọc và đề xuất điền form; tải/chụp ảnh, quay/tải video trong cùng biểu mẫu. Mọi kết quả AI phải được người dùng kiểm tra trước khi lưu Nháp.</p>
            <div className="mt-4 grid gap-2 sm:grid-cols-3">
              <div className={`rounded-xl border px-3 py-2 text-xs ${warehouseStage === "initial_intake" ? "border-[#E6C478] bg-[#E6C478]/15" : "border-white/15 bg-white/5"}`}><b>1. Kho tiếp nhận</b><p className="mt-1 text-white/70">Dữ liệu đầu vào do môi giới nhập và xác nhận.</p></div>
              <div className={`rounded-xl border px-3 py-2 text-xs ${warehouseStage === "post_draft" ? "border-[#E6C478] bg-[#E6C478]/15" : "border-white/15 bg-white/5"}`}><b>2. Bài đăng nháp</b><p className="mt-1 text-white/70">{postSyncStatus}</p></div>
              <div className={`rounded-xl border px-3 py-2 text-xs ${warehouseStage === "sales_warehouse" ? "border-[#E6C478] bg-[#E6C478]/15" : "border-white/15 bg-white/5"}`}><b>3. Kho nguồn tổng</b><p className="mt-1 text-white/70">Chờ Sale kiểm tra và nhận việc.</p></div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2"><button type="button" disabled={warehouseStage !== "post_draft"} onClick={() => { setWarehouseStage("sales_warehouse"); setPostSyncStatus("Đã chuyển bài đăng và hồ sơ vào Kho nguồn tổng cho Sale"); toast.success("Đã chuyển hồ sơ vào Kho nguồn tổng cho bộ phận Sale."); }} className="rounded-xl border border-[#E6C478] px-3 py-2 text-xs font-black text-[#E6C478] disabled:cursor-not-allowed disabled:opacity-40">AI xác nhận → Kho nguồn tổng</button></div>
          </div>
          {activeWorkflowStep === source?.workflow[0] ? <>
            <SourceSpecificIntake sourceType={sourceType as SourceChannelKey} values={intakeValues} workflowValues={workflowStepValues} onChange={setIntakeValues} />
            <BrokerageForm tab="properties" onSubmit={handleSourceSubmit} areas={areas} sourceContext={sourceContext} onCancel={onClose} />
          </> : <div className="mt-4 rounded-2xl border border-dashed border-[#BFD7CA] bg-[#F5F9F6] p-4 text-sm text-[#60766D]">Đang mở form nghiệp vụ riêng của bước <b className="text-[#18352D]">{activeWorkflowStep}</b>. Các trường, validation, tài liệu, AI và kết quả được hiển thị ở form bước phía trên.</div>}
        </div>
      )}
    </section>
  );
}

async function fileToBase64(file: File) {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Không thể đọc tệp đã chọn."));
    reader.readAsDataURL(file);
  });
  return dataUrl.split(",")[1] || "";
}

export default function BrokerageAdmin() {
  const [tab, setTab] = useState<Tab>("properties");
  const [showForm, setShowForm] = useState(false);
  const [showSourceCreation, setShowSourceCreation] = useState(() => {
    if (typeof window === "undefined") return false;
    return new URLSearchParams(window.location.search).has("process");
  });
  const [editingProperty, setEditingProperty] = useState<Record<
    string,
    unknown
  > | null>(null);
  const [previewProperty, setPreviewProperty] = useState<Record<
    string,
    unknown
  > | null>(null);
  const [scanProperty, setScanProperty] = useState<{
    id: number;
    title: string;
  } | null>(null);
  const [mediaProperty, setMediaProperty] = useState<{
    id: number;
    title: string;
  } | null>(null);
  const [mediaAssets, setMediaAssets] = useState<
    Array<{
      id?: number;
      assetType: string;
      url: string;
      fileName: string;
      mimeType: string;
      status: string;
    }>
  >([]);
  const [analysisPreview, setAnalysisPreview] = useState<string | null>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const scan3dInputRef = useRef<HTMLInputElement>(null);
  const {
    config: layoutConfig,
    setConfig,
    setDefaultLayout,
    setCategoryLayout,
    clearCategoryLayout,
  } = usePersistentPropertyLayoutConfig();
  const { user, loading: authLoading } = useAuth();
  const isAdmin = user?.role === "admin";
  const canQueryProperties = tab === "properties" && !authLoading && !!user;
  const serverLayout = trpc.propertyLayoutSettings.get.useQuery(undefined, {
    enabled: canQueryProperties && isAdmin,
  });
  const saveLayout = trpc.propertyLayoutSettings.save.useMutation({
    onSuccess: data => {
      setConfig({
        defaultLayout: data.defaultLayout as PropertyDisplayLayout,
        byCategory: data.overrides as PropertyLayoutConfig["byCategory"],
      });
      toast.success("Đã lưu cấu hình bố cục lên tài khoản quản trị.");
    },
    onError: error => toast.error(`Không lưu được bố cục: ${error.message}`),
  });
  useEffect(() => {
    if (serverLayout.data)
      setConfig({
        defaultLayout: serverLayout.data.defaultLayout as PropertyDisplayLayout,
        byCategory: serverLayout.data
          .overrides as PropertyLayoutConfig["byCategory"],
      });
  }, [serverLayout.data, setConfig]);
  const persistLayout = (next: PropertyLayoutConfig) => {
    setConfig(next);
    saveLayout.mutate({
      defaultLayout: next.defaultLayout,
      overrides: next.byCategory,
    });
  };
  const adminProperties = trpc.properties.adminList.useQuery(undefined, {
    enabled: canQueryProperties && isAdmin,
  });
  const ownProperties = trpc.properties.mine.useQuery(undefined, {
    enabled: canQueryProperties && !isAdmin,
  });
  const properties = isAdmin ? adminProperties : ownProperties;
  const [selectedPropertyIds, setSelectedPropertyIds] = useState<number[]>([]);
  const togglePropertySelection = (id: number) => {
    setSelectedPropertyIds(current =>
      current.includes(id) ? current.filter(itemId => itemId !== id) : [...current, id]
    );
  };
  const toggleAllPropertySelection = (checked: boolean) => {
    setSelectedPropertyIds(checked ? (properties.data || []).map(item => item.id) : []);
  };
  const bulkUpdatePropertyStatus = async (
    status: "published" | "reserved" | "sold"
  ) => {
    if (!selectedPropertyIds.length) {
      toast.info("Hãy chọn ít nhất một hồ sơ trước.");
      return;
    }
    const confirmed = window.confirm(
      `Xác nhận cập nhật ${selectedPropertyIds.length} hồ sơ sang trạng thái ${status === "published" ? "Công khai" : status === "reserved" ? "Đặt chỗ" : "Đã bán"}?`
    );
    if (!confirmed) return;
    try {
      await Promise.all(
        selectedPropertyIds.map(id => updateProperty.mutateAsync({ id, status }))
      );
      setSelectedPropertyIds([]);
      await properties.refetch();
      toast.success(`Đã cập nhật ${selectedPropertyIds.length} hồ sơ hàng loạt.`);
    } catch {
      toast.error("Một số hồ sơ chưa thể cập nhật. Vui lòng kiểm tra lại.");
    }
  };
  const layoutPreviewItems = (properties.data || []).slice(0, 5) as Array<
    Record<string, unknown>
  >;
  const areas = trpc.properties.areas.useQuery();
  const owners = trpc.brokerage.owners.useQuery(undefined, {
    enabled: tab === "owners",
  });
  const buyers = trpc.brokerage.buyers.useQuery(undefined, {
    enabled: tab === "buyers",
  });
  const surveys = trpc.brokerage.surveys.useQuery(undefined, {
    enabled: tab === "survey",
  });
  const legal = trpc.brokerage.legalChecks.useQuery(undefined, {
    enabled: tab === "legal",
  });
  const valuations = trpc.brokerage.valuations.useQuery(undefined, {
    enabled: tab === "valuation",
  });
  const deals = trpc.brokerage.deals.useQuery(undefined, {
    enabled: tab === "deals",
  });
  const createProperty = trpc.properties.create.useMutation({
    onSuccess: result => {
      toast.success(
        `Đã lưu bài ở trạng thái Nháp và đồng bộ vào Nguồn hàng · Hồ sơ AI điện tử #${result.dossierId || "đã tạo"}. Tài khoản quản trị có thể chuyển sang Công khai.`
      );
      setShowForm(false);
      setShowSourceCreation(false);
      properties.refetch();
    },
    onError: e => toast.error(getBrokerageErrorMessage(e.message)),
  });
  const updateProperty = trpc.properties.updateStatus.useMutation({
    onSuccess: result => {
      properties.refetch();
      const propertyId = updateProperty.variables?.id;
      const dealId =
        "deal" in result && result.deal?.dealId ? result.deal.dealId : null;
      if ("sold" in result && result.sold && result.dossierId && propertyId) {
        const action = getSoldPropertyToastAction(propertyId, dealId);
        toast.success(
          `Đã chuyển sang Đã bán và ${dealId ? "đã tạo/liên kết giao dịch" : "đưa vào sản xuất hồ sơ AI"}.`,
          {
            duration: 12000,
            action: {
              label: action.label,
              onClick: () => window.location.assign(action.href),
            },
          }
        );
      } else toast.success("Đã cập nhật trạng thái");
    },
    onError: error => toast.error(getBrokerageErrorMessage(error.message)),
  });
  const editPropertyMutation = trpc.properties.update.useMutation({
    onSuccess: () => {
      toast.success("Đã cập nhật bài đăng");
      setEditingProperty(null);
      setShowForm(false);
      properties.refetch();
    },
    onError: e => toast.error(getBrokerageErrorMessage(e.message)),
  });
  const deleteProperty = trpc.properties.delete.useMutation({
    onSuccess: () => {
      toast.success("Đã xóa bài đăng");
      properties.refetch();
    },
    onError: e => toast.error(getBrokerageErrorMessage(e.message)),
  });
  const analyzePropertyMediaAsset =
    trpc.properties.analyzePropertyMediaAsset.useMutation({
      onSuccess: result => {
        setMediaAssets(current =>
          current.map(asset =>
            asset.url === result.mediaUrl
              ? { ...asset, status: "needs_review" }
              : asset
          )
        );
        setAnalysisPreview(JSON.stringify(result.storyboard, null, 2));
        toast.success(
          "AI đã tạo bản nháp storyboard. Hãy kiểm tra trước khi sử dụng."
        );
      },
      onError: error => toast.error(error.message),
    });
  const uploadPropertyMediaAsset =
    trpc.properties.uploadPropertyMediaAsset.useMutation({
      onSuccess: (result, variables) => {
        setMediaAssets(current => [
          ...current,
          {
            id: result.id,
            assetType: result.assetType,
            url: result.url,
            fileName: variables.fileName,
            mimeType: variables.mimeType,
            status: "uploaded",
          },
        ]);
        toast.success(
          `Đã lưu ${result.assetType === "3d" ? "dữ liệu 3D" : "media"} cho bài BĐS. Có thể chuyển sang bước AI phân tích sau.`
        );
      },
      onError: error => toast.error(error.message),
    });
  const handlePropertyMediaFiles = async (
    event: React.ChangeEvent<HTMLInputElement>,
    assetType: "video" | "image" | "360" | "3d"
  ) => {
    if (!mediaProperty) {
      toast.error("Hãy chọn bài BĐS trước.");
      event.currentTarget.value = "";
      return;
    }
    const files = Array.from(event.target.files || []);
    for (const file of files.slice(0, assetType === "3d" ? 1 : 4)) {
      const is3d = assetType === "3d";
      const valid = is3d
        ? isAcceptedProperty3DFile(file.name)
        : assetType === "video"
          ? file.type.startsWith("video/")
          : file.type.startsWith("image/");
      if (!valid) {
        toast.error(`${file.name}: định dạng không phù hợp.`);
        continue;
      }
      const max = assetType === "video" ? 50 : assetType === "3d" ? 100 : 15;
      if (file.size > max * 1024 * 1024) {
        toast.error(`${file.name} vượt quá ${max}MB.`);
        continue;
      }
      try {
        uploadPropertyMediaAsset.mutate({
          propertyId: mediaProperty.id,
          assetType,
          fileName: file.name,
          mimeType:
            file.type || (is3d ? "application/octet-stream" : "image/jpeg"),
          data: await fileToBase64(file),
        });
      } catch (error) {
        toast.error(
          error instanceof Error ? error.message : "Không thể đọc tệp."
        );
      }
    }
    event.currentTarget.value = "";
  };
  const createOwner = trpc.brokerage.createOwner.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu chủ nhà");
      setShowForm(false);
      owners.refetch();
    },
  });
  const createBuyer = trpc.brokerage.createBuyer.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu khách mua");
      setShowForm(false);
      buyers.refetch();
    },
  });
  const createSurvey = trpc.brokerage.createSurvey.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu phiếu khảo sát");
      setShowForm(false);
      surveys.refetch();
    },
  });
  const createLegal = trpc.brokerage.createLegalCheck.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu kiểm tra pháp lý");
      setShowForm(false);
      legal.refetch();
    },
  });
  const createValuation = trpc.brokerage.createValuation.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu định giá");
      setShowForm(false);
      valuations.refetch();
    },
  });
  const createDeal = trpc.brokerage.createDeal.useMutation({
    onSuccess: () => {
      toast.success("Đã lưu giao dịch");
      setShowForm(false);
      deals.refetch();
    },
  });
  const current = {
    properties,
    owners,
    buyers,
    survey: surveys,
    legal,
    valuation: valuations,
    deals,
  }[tab];
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const f = new FormData(event.currentTarget);
    const text = (key: string) => String(f.get(key) || "");
    const num = (key: string) => Number(f.get(key));
    if (tab === "properties") {
      const payload = getPropertySubmission(f);
      if (editingProperty?.id) {
        const editable = {
          id: Number(editingProperty.id),
          title: payload.title,
          slug: payload.slug,
          propertyType: payload.propertyType,
          listingType: payload.listingType,
          price: payload.price,
          area: payload.area,
          buildArea: payload.buildArea ?? null,
          bedrooms: payload.bedrooms ?? null,
          bathrooms: payload.bathrooms ?? null,
          location: payload.location,
          orientation: payload.orientation ?? null,
          description: payload.description ?? null,
          legalStatus: payload.legalStatus ?? null,
          certificateType: payload.certificateType ?? null,
          certificateArea: payload.certificateArea ?? null,
          landUsePurpose: payload.landUsePurpose ?? null,
          planningStatus: payload.planningStatus ?? null,
          mortgageStatus: payload.mortgageStatus ?? null,
          propertyCode: payload.propertyCode ?? null,
          listingDetails: payload.listingDetails,
          brokerName: payload.brokerName ?? null,
          brokerPhone: payload.brokerPhone ?? null,
          brokerZalo: payload.brokerZalo ?? null,
          ownerName: payload.ownerName ?? null,
          ownerPhone: payload.ownerPhone ?? null,
        };
        editPropertyMutation.mutate(editable);
      } else createProperty.mutate(payload);
    }
    if (tab === "owners")
      createOwner.mutate({
        name: text("name"),
        phone: text("phone"),
        email: text("email") || undefined,
        notes: text("notes") || undefined,
      });
    if (tab === "buyers")
      createBuyer.mutate({
        name: text("name"),
        phone: text("phone"),
        budget: text("budget") || undefined,
        preferredArea: text("preferredArea") || undefined,
        propertyType: text("propertyType") || undefined,
        notes: text("notes") || undefined,
      });
    if (tab === "survey")
      createSurvey.mutate({
        propertyId: num("propertyId") || undefined,
        buyerLeadId: num("buyerLeadId") || undefined,
        purpose: text("purpose") || undefined,
        budget: text("budget") || undefined,
        timeline: text("timeline") || undefined,
        mustHave: text("mustHave") || undefined,
        notes: text("notes") || undefined,
      });
    if (tab === "legal")
      createLegal.mutate({
        propertyId: num("propertyId"),
        status: text("status") as
          | "pending"
          | "in_review"
          | "verified"
          | "issue_found",
        documents: text("documents") || undefined,
        notes: text("notes") || undefined,
      });
    if (tab === "valuation")
      createValuation.mutate({
        propertyId: num("propertyId"),
        estimatedPrice: text("estimatedPrice"),
        method: text("method") || undefined,
        comparableNotes: text("comparableNotes") || undefined,
      });
    if (tab === "deals")
      createDeal.mutate({
        propertyId: num("propertyId"),
        buyerLeadId: num("buyerLeadId") || undefined,
        ownerId: num("ownerId") || undefined,
        stage: text("stage") as
          | "new"
          | "negotiating"
          | "deposit"
          | "contracted"
          | "completed"
          | "cancelled",
        agreedPrice: text("agreedPrice") || undefined,
        notes: text("notes") || undefined,
      });
  };
  return (
    <DashboardLayout allowNonAdmin>
      <main className="min-h-screen bg-[#F5F2EA] p-4 text-[#18352D] sm:p-8">
        <div className="mx-auto max-w-[1180px]">
          <div className="rounded-[2rem] bg-[#18352D] p-6 text-white shadow-xl sm:p-10">
            <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.2em] text-[#E6C478]">
                  Bất động sản xanh
                </p>
                <h1 className="mt-3 font-serif text-4xl tracking-[-.04em] sm:text-5xl">
                  Quản lý nguồn hàng
                </h1>
                <p className="mt-3 max-w-2xl text-sm leading-6 text-white/75">
                  Tiếp nhận nguồn, chọn loại BĐS, chạy workflow, kiểm duyệt và
                  theo dõi toàn bộ kho nguồn tại một nơi.
                </p>
              </div>
              <button
                onClick={() => {
                  setEditingProperty(null);
                  setShowForm(false);
                  setShowSourceCreation(value => !value);
                }}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#E6C478] px-5 py-3 text-sm font-bold text-[#18352D] transition hover:bg-[#F2D99E] active:scale-[.98]"
              >
                <Plus size={17} />{" "}
                {showSourceCreation ? "Đóng quy trình" : "Tạo nguồn hàng"}
              </button>
            </div>
            <p className="mt-6 rounded-xl border border-white/15 bg-white/10 px-4 py-3 text-sm leading-6 text-white/80">
              {getBrokerageAccessGuidance(user)}
            </p>
          </div>
          {showSourceCreation && (
            <SourceCreationWorkspace
              areas={areas.data || []}
              onSubmit={submit}
              onClose={() => setShowSourceCreation(false)}
            />
          )}
          <section className="mt-6 rounded-2xl border border-[#C9DDD2] bg-white p-5 shadow-sm sm:p-6">
            <div className="grid gap-6 lg:grid-cols-[minmax(240px,0.8fr)_minmax(0,1.6fr)] lg:items-start lg:gap-8">
              <div className="lg:pt-2">
                <p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">
                  Thiết lập storefront
                </p>
                <h2 className="mt-1 font-serif text-2xl tracking-[-.03em] text-[#18352D]">
                  Bố cục hiển thị sản phẩm
                </h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-[#60766D]">
                  Chọn một chế độ cho các bài Công khai. Lựa chọn được lưu trên
                  thiết bị này và tự áp dụng ở trang chủ cùng mục Sản phẩm đang
                  bán.
                </p>
              </div>
              <div className="w-full min-w-0 space-y-3">
                <div className="flex flex-col gap-2 rounded-xl bg-[#F5FAF6] p-3">
                  <div>
                    <p className="text-xs font-bold text-[#18352D]">
                      Bố cục mặc định
                    </p>
                    <p className="text-[11px] text-[#60766D]">
                      Dùng cho trang tổng hợp hoặc danh mục chưa có thiết lập
                      riêng.
                    </p>
                  </div>
                  <PropertyLayoutPicker
                    value={layoutConfig.defaultLayout}
                    onChange={value =>
                      persistLayout({ ...layoutConfig, defaultLayout: value })
                    }
                  />
                </div>
                <div className="grid max-h-[360px] gap-2 overflow-y-auto overscroll-contain pr-1 [scrollbar-color:#8aa99a_transparent] [scrollbar-width:thin] [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#8aa99a] [&::-webkit-scrollbar-thumb:hover]:bg-[#1f5a4a]">
                  <div className="sm:col-span-2">
                    <p className="text-xs font-bold text-[#18352D]">
                      Bố cục theo từng danh mục
                    </p>
                    <p className="text-[11px] text-[#60766D]">
                      Vuốt lên hoặc xuống để xem các nhóm khác. Chọn “Tự động”
                      để xóa thiết lập riêng và quay về bố cục mặc định.
                    </p>
                  </div>
                  {(
                    Object.entries(LISTING_KIND_LABELS) as Array<
                      [ListingKind, string]
                    >
                  ).map(([kind, label]) => (
                    <div
                      key={kind}
                      className="flex min-w-0 flex-col gap-2 rounded-xl border border-[#E5EEE8] bg-white p-2.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-xs font-bold text-[#18352D]">
                          {label}
                        </span>
                        {layoutConfig.byCategory[kind] ? (
                          <span className="rounded-full bg-[#EAF4ED] px-2 py-0.5 text-[9px] font-bold text-[#1F5A4A]">
                            Riêng
                          </span>
                        ) : (
                          <span className="text-[9px] text-[#8A9A91]">
                            Mặc định
                          </span>
                        )}
                      </div>
                      <PropertyLayoutPicker
                        value={layoutConfig.byCategory[kind] || "auto"}
                        onChange={value => {
                          const nextByCategory = { ...layoutConfig.byCategory };
                          if (value === "auto") delete nextByCategory[kind];
                          else nextByCategory[kind] = value;
                          persistLayout({
                            ...layoutConfig,
                            byCategory: nextByCategory,
                          });
                        }}
                      />
                    </div>
                  ))}
                </div>
                <div className="mt-4 border-t border-[#E5EEE8] pt-4">
                  <div className="flex items-end justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">
                        Preview trực tiếp
                      </p>
                      <p className="mt-1 text-xs text-[#60766D]">
                        Xem cách bài đăng đang hiển thị trước khi khách hàng
                        truy cập storefront.
                      </p>
                    </div>
                    <span className="text-[11px] text-[#8A9A91]">
                      {layoutPreviewItems.length} bài mẫu
                    </span>
                  </div>
                  {layoutPreviewItems.length ? (
                    <div className="mt-3 max-h-[560px] overflow-y-auto overscroll-contain pr-1 [scrollbar-color:#8aa99a_transparent] [scrollbar-width:thin] [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#8aa99a] [&::-webkit-scrollbar-thumb:hover]:bg-[#1f5a4a]">
                      <PropertyLayoutRenderer
                        items={layoutPreviewItems}
                        layout={layoutConfig.defaultLayout}
                        itemKey={item => String(item.id)}
                        renderItem={(item, _index, density) => (
                          <PropertyPostingTemplate
                            title={String(item.title || "Bài đăng mẫu")}
                            location={String(item.location || "Đà Nẵng")}
                            typeLabel={String(
                              item.propertyType || "Bất động sản"
                            )}
                            price={`${String(item.price || "Đang cập nhật")} tỷ`}
                            pricePerM2={
                              item.area
                                ? `${String(item.area)} m²`
                                : "Đang cập nhật"
                            }
                            area={String(item.area || "")}
                            bedrooms={
                              item.bedrooms
                                ? `${String(item.bedrooms)} phòng`
                                : undefined
                            }
                            images={(Array.isArray(item.imageUrls)
                              ? item.imageUrls
                              : item.imageUrl
                                ? [item.imageUrl]
                                : []
                            ).map(String)}
                            galleryLayout={readGalleryLayout(
                              item.listingDetails
                            )}
                            detailHref="#"
                            onSelect={() => undefined}
                            density={density}
                          />
                        )}
                      />
                    </div>
                  ) : (
                    <div className="mt-3 rounded-xl border border-dashed border-[#D7E2D9] bg-[#F7FAF7] p-5 text-center text-sm text-[#60766D]">
                      Tạo hoặc tải một bài đăng để xem preview layout.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </section>
          {showForm && (
            <div className="mt-6">
              <BrokerageForm
                tab="properties"
                onSubmit={submit}
                areas={areas.data || []}
                initialProperty={editingProperty}
                onCancel={() => {
                  setEditingProperty(null);
                  setShowForm(false);
                }}
              />
            </div>
          )}
          <section className="mt-6 rounded-2xl border border-[#C9DDD2] bg-white p-5 shadow-sm sm:p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">
                  Media & không gian
                </p>
                <h2 className="mt-1 font-serif text-2xl tracking-[-.03em] text-[#18352D]">
                  Chuẩn bị video và 3D AI
                </h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-[#60766D]">
                  Chọn bài BĐS để quay/tải dữ liệu thật hoặc đưa file quét 3D
                  vào hồ sơ. Đây là bước chuẩn bị; AI sẽ xử lý ở bước tiếp theo
                  và luôn cần môi giới kiểm tra.
                </p>
              </div>
              <div className="flex w-full flex-col gap-2 sm:w-[min(100%,360px)]">
                <select
                  value={mediaProperty?.id || ""}
                  onChange={event => {
                    const item = (properties.data || []).find(
                      property => String(property.id) === event.target.value
                    );
                    setMediaProperty(
                      item
                        ? {
                            id: item.id,
                            title: String(item.title || "Bài BĐS"),
                          }
                        : null
                    );
                  }}
                  className="rounded-xl border border-[#D7E2D9] bg-[#F7FAF7] p-3 text-sm text-[#18352D]"
                >
                  <option value="">Chọn bài BĐS</option>
                  {(properties.data || []).map(property => (
                    <option key={property.id} value={property.id}>
                      {String(property.title || `Bài #${property.id}`)}
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    ref={videoInputRef}
                    type="file"
                    accept="video/*,image/*"
                    capture="environment"
                    multiple
                    className="hidden"
                    onChange={event => {
                      void handlePropertyMediaFiles(event, "video");
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!mediaProperty) {
                        toast.error("Hãy chọn bài BĐS trước.");
                        return;
                      }
                      videoInputRef.current?.click();
                    }}
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#1F5A4A] px-3 py-3 text-xs font-bold text-white transition hover:bg-[#174437] active:scale-[.98]"
                  >
                    <Video size={16} /> Quay/Tải video
                  </button>
                  <input
                    ref={scan3dInputRef}
                    type="file"
                    accept=".usdz,.glb,.gltf,.obj,.ply,.e57,model/gltf-binary,model/gltf+json"
                    className="hidden"
                    onChange={event => {
                      void handlePropertyMediaFiles(event, "3d");
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!mediaProperty) {
                        toast.error("Hãy chọn bài BĐS trước.");
                        return;
                      }
                      scan3dInputRef.current?.click();
                    }}
                    className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#1F5A4A] bg-white px-3 py-3 text-xs font-bold text-[#1F5A4A] transition hover:bg-[#F0F7F2] active:scale-[.98]"
                  >
                    <ScanLine size={16} /> Quét 3D
                  </button>
                </div>
              </div>
            </div>
            {mediaAssets.length > 0 && (
              <div className="mt-4 rounded-xl border border-[#D7E2D9] bg-white p-4">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-xs font-bold uppercase tracking-[.14em] text-[#1F5A4A]">
                    Media đã lưu
                  </p>
                  <span className="text-[11px] text-[#8A9A91]">
                    {mediaAssets.length} tệp trong phiên này
                  </span>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  {mediaAssets.map(asset => (
                    <div
                      key={`${asset.url}-${asset.fileName}`}
                      className="flex items-center justify-between gap-3 rounded-lg bg-[#F7FAF7] px-3 py-2"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-xs font-semibold text-[#18352D]">
                          {asset.fileName}
                        </p>
                        <p className="text-[11px] text-[#60766D]">
                          {asset.assetType === "3d"
                            ? "3D · chờ mô-đun không gian"
                            : asset.status === "needs_review"
                              ? "AI đã phân tích · chờ duyệt"
                              : "Đã lưu · chưa phân tích"}
                        </p>
                      </div>
                      {asset.assetType === "3d" ? (
                        <div className="min-w-0 flex-1">
                          {/\.(glb|gltf)$/i.test(asset.fileName) && (
                            <ThreeDAnnotationPanel
                              propertyId={mediaProperty!.id}
                              assetUrl={asset.url}
                              assetFileName={asset.fileName}
                            />
                          )}
                          <a
                            href={asset.url}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-2 inline-flex rounded-full border border-[#1F5A4A]/30 px-3 py-1.5 text-[11px] font-bold text-[#1F5A4A]"
                          >
                            Mở file 3D
                          </a>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={analyzePropertyMediaAsset.isPending}
                          onClick={() =>
                            analyzePropertyMediaAsset.mutate({
                              propertyId: mediaProperty!.id,
                              assetType: asset.assetType as
                                | "video"
                                | "image"
                                | "360",
                              mediaUrl: asset.url,
                              mimeType: asset.mimeType as
                                | "video/mp4"
                                | "video/webm"
                                | "video/quicktime"
                                | "image/jpeg"
                                | "image/png"
                                | "image/webp"
                                | "image/gif",
                              propertyContext: mediaProperty?.title,
                            })
                          }
                          className="shrink-0 rounded-full border border-[#1F5A4A]/30 px-3 py-1.5 text-[11px] font-bold text-[#1F5A4A] disabled:opacity-50"
                        >
                          {analyzePropertyMediaAsset.isPending
                            ? "Đang phân tích…"
                            : "Phân tích AI"}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
            {analysisPreview && (
              <div className="mt-4 rounded-xl border-2 border-[#E6C478] bg-[#FFF8E7] p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[.14em] text-[#8A6A1E]">
                      Bản nháp AI · cần duyệt
                    </p>
                    <p className="mt-1 text-sm font-semibold text-[#18352D]">
                      Storyboard, lời đọc và phụ đề chưa được xuất bản
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setAnalysisPreview(null)}
                    className="rounded-full border border-[#8A6A1E]/30 px-3 py-1.5 text-xs font-bold text-[#8A6A1E]"
                  >
                    Đóng bản nháp
                  </button>
                </div>
                <pre className="mt-3 max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-white/80 p-3 text-[11px] leading-5 text-[#60766D]">
                  {analysisPreview}
                </pre>
                <p className="mt-3 text-xs leading-5 text-[#765B18]">
                  Môi giới cần đối chiếu cảnh quay, thông tin pháp lý, giá và
                  tiện ích thực tế trước khi tạo video hoặc đăng công khai.
                </p>
              </div>
            )}
            <div className="mt-4 rounded-xl bg-[#F7FAF7] px-4 py-3 text-xs leading-5 text-[#60766D]">
              Video/ảnh thật và file 3D sẽ được gắn theo đúng bài đã chọn. Địa
              chỉ hoặc giấy tờ chỉ cung cấp thông tin tham khảo; phân tích khu
              vực 3D chỉ dùng bản đồ/ảnh có nguồn và không thay thế khảo sát
              thực địa; không thể tự tạo mô hình 3D chính xác nếu chưa có dữ
              liệu quét hoặc media thật.
            </div>
          </section>
          <section className="mt-6 rounded-2xl border-2 border-[#E6C478] bg-[#FFF8E7] p-5 shadow-sm">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.16em] text-[#8A6A1E]">
                  Mục mới · Camera hồ sơ
                </p>
                <h2 className="mt-1 text-xl font-bold text-[#18352D]">
                  Chụp sổ đỏ / sổ hồng
                </h2>
                <p className="mt-1 max-w-2xl text-sm leading-6 text-[#60766D]">
                  Có thể chọn bài đã lưu hoặc bắt đầu trực tiếp bằng camera. Hệ
                  thống sẽ tạo bài Nháp và lưu giấy tờ vào Kho lưu trữ Pháp lý.
                </p>
              </div>
              <div className="flex w-full flex-col gap-2 sm:w-auto sm:min-w-[300px]">
                <select
                  value={scanProperty?.id || ""}
                  onChange={event => {
                    const item = (properties.data || []).find(
                      property => String(property.id) === event.target.value
                    );
                    setScanProperty(
                      item ? { id: item.id, title: item.title } : null
                    );
                  }}
                  className="rounded-xl border border-[#D8C98E] bg-white p-3 text-sm text-[#18352D]"
                >
                  <option value="">Chọn bài BĐS cần quét</option>
                  {(properties.data || []).map(property => (
                    <option key={property.id} value={property.id}>
                      {property.title}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    document
                      .getElementById("legal-scanner")
                      ?.scrollIntoView({ behavior: "smooth", block: "center" });
                  }}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#1F5A4A] px-4 py-3 text-sm font-bold text-white"
                >
                  <FileCheck2 size={17} /> Mở camera hồ sơ
                </button>
              </div>
            </div>
            {!(properties.data || []).length && (
              <div className="mt-4 rounded-xl bg-white/70 p-3 text-sm text-[#765B18]">
                <p>
                  Không cần tạo bài trước. Bạn có thể mở camera ngay bên dưới;
                  sau khi nhận diện, hệ thống sẽ tự tạo bài Nháp và lưu giấy tờ.
                </p>
              </div>
            )}
          </section>
          <div id="legal-scanner">
            <LegalDocumentScanner
              propertyId={scanProperty?.id}
              propertyTitle={scanProperty?.title}
              onPropertyCreated={property => {
                setScanProperty(property);
                properties.refetch();
              }}
            />
          </div>
          <div className="mt-8 flex items-end justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.2em] text-[#1F5A4A]">
                Nguồn hàng của tôi
              </p>
              <h2 className="mt-2 font-serif text-3xl tracking-[-.03em] sm:text-4xl">
                Sản phẩm đã đăng
              </h2>
              <p className="mt-2 text-sm text-[#60766D]">
                Bài Nháp có thể tiếp tục chỉnh sửa; bài Công khai sẽ hiển thị
                với khách hàng.
              </p>
            </div>
            <span className="hidden rounded-full bg-white px-4 py-2 text-sm font-bold text-[#1F5A4A] shadow-sm sm:inline-flex">
              {properties.data?.length || 0} sản phẩm
            </span>
          </div>
          {previewProperty && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center bg-[#18352D]/60 p-4"
              role="dialog"
              aria-modal="true"
              aria-label="Xem trước bài đăng"
            >
              <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-[#F5F2EA] shadow-2xl">
                <div className="sticky top-0 flex items-center justify-between border-b bg-white px-5 py-4">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
                      Xem trước
                    </p>
                    <h2 className="text-lg font-bold text-[#18352D]">
                      {String(previewProperty.title || "Bài đăng")}
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPreviewProperty(null)}
                    aria-label="Đóng xem trước"
                    className="rounded-full p-2 text-[#60766D] hover:bg-[#E8F1EC]"
                  >
                    <X size={18} />
                  </button>
                </div>
                <div className="p-5">
                  <PropertyPostingTemplate
                    title={String(previewProperty.title || "Bài đăng")}
                    location={String(
                      previewProperty.location || "Chưa cập nhật"
                    )}
                    typeLabel={String(
                      previewProperty.propertyType || "Bất động sản"
                    )}
                    price={`${String(previewProperty.price || "Chưa cập nhật")} tỷ`}
                    pricePerM2={
                      String(previewProperty.area || "")
                        ? `${String(previewProperty.area || "")} m²`
                        : "Đang cập nhật"
                    }
                    area={String(previewProperty.area || "")}
                    bedrooms={
                      previewProperty.bedrooms
                        ? `${String(previewProperty.bedrooms)} phòng`
                        : undefined
                    }
                    bathrooms={
                      previewProperty.bathrooms
                        ? `${String(previewProperty.bathrooms)} phòng`
                        : undefined
                    }
                    images={(Array.isArray(previewProperty.imageUrls)
                      ? previewProperty.imageUrls
                      : previewProperty.imageUrl
                        ? [previewProperty.imageUrl]
                        : []
                    ).map(String)}
                    galleryLayout={readGalleryLayout(
                      previewProperty.listingDetails
                    )}
                    detailHref="#"
                    onSelect={() => undefined}
                  />
                </div>
              </div>
            </div>
          )}
          <div className="mt-5 overflow-hidden rounded-2xl bg-white shadow-sm">
            {properties.isLoading ? (
              <p className="p-10 text-center text-[#60766D]">
                Đang tải sản phẩm...
              </p>
            ) : (
              <PropertyTable
                data={properties.data || []}
                onStatus={(id, status) => updateProperty.mutate({ id, status })}
                onDelete={id => deleteProperty.mutate({ id })}
                selectedIds={selectedPropertyIds}
                onToggleSelect={togglePropertySelection}
                onToggleSelectAll={toggleAllPropertySelection}
                onBulkStatus={bulkUpdatePropertyStatus}
                onScan={(id, title) => setScanProperty({ id, title })}
                onEdit={id => {
                  const item = (properties.data || []).find(
                    property => property.id === id
                  );
                  if (item) {
                    setEditingProperty(
                      item as unknown as Record<string, unknown>
                    );
                    setShowForm(true);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }
                }}
                onPreview={id => {
                  const item = (properties.data || []).find(
                    property => property.id === id
                  );
                  if (item)
                    setPreviewProperty(
                      item as unknown as Record<string, unknown>
                    );
                }}
                deletingId={
                  deleteProperty.isPending
                    ? deleteProperty.variables?.id
                    : undefined
                }
              />
            )}
          </div>
        </div>
      </main>
    </DashboardLayout>
  );
}

function BrokerageForm({
  tab,
  onSubmit,
  areas = [],
  initialProperty,
  sourceContext,
  onCancel,
}: {
  tab: Tab;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  areas?: Array<{ id: number; name: string; province: string }>;
  initialProperty?: Record<string, unknown> | null;
  sourceContext?: SourceCreationContext | null;
  onCancel?: () => void;
}) {
  const formRef = useRef<HTMLFormElement>(null);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [uploadedVideos, setUploadedVideos] = useState<string[]>([]);
  const [selectedProvince, setSelectedProvince] = useState("");
  const [listingType, setListingType] = useState<ListingTransaction>("sale");
  const [propertyType, setPropertyType] = useState<ListingKind>("house");
  const [galleryLayoutChoice, setGalleryLayoutChoice] =
    useState<GalleryLayout>("single");
  const filteredAreas = filterAreasByProvince(areas, selectedProvince);
  useEffect(() => {
    if (sourceContext?.propertyKind)
      setPropertyType(sourceContext.propertyKind);
  }, [sourceContext?.propertyKind]);
  useEffect(() => {
    if (!initialProperty || !formRef.current) return;
    const property = initialProperty;
    let listingDetails: Record<string, unknown> = {};
    try {
      const parsed = JSON.parse(String(property.listingDetails || "{}"));
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
        listingDetails = parsed as Record<string, unknown>;
    } catch {
      listingDetails = {};
    }
    const transaction = property.listingType === "rent" ? "rent" : "sale";
    const kind = normalizePropertyType(
      String(property.propertyType || "house")
    ) as ListingKind;
    setGalleryLayoutChoice(readGalleryLayout(listingDetails.galleryLayout));
    setListingType(transaction);
    setPropertyType(kind);
    const province = String(property.areaProvince || "");
    if (province) setSelectedProvince(province);
    const form = formRef.current;
    const fields = [
      "title",
      "slug",
      "propertyCode",
      "location",
      "price",
      "area",
      "buildArea",
      "roadWidth",
      "bedrooms",
      "bathrooms",
      "constructionYear",
      "orientation",
      "distanceToMainRoad",
      "nearbySchools",
      "nearbyMarket",
      "nearbyHospital",
      "distanceToCenter",
      "legalStatus",
      "certificateType",
      "certificateArea",
      "landUsePurpose",
      "planningStatus",
      "mortgageStatus",
      "legalSource",
      "brokerageFee",
      "depositTerms",
      "transactionTerms",
      "ownerName",
      "ownerPhone",
      "brokerName",
      "brokerPhone",
      "brokerZalo",
      "description",
    ];
    fields.forEach(name => {
      const field = form.elements.namedItem(name) as
        | HTMLInputElement
        | HTMLTextAreaElement
        | null;
      if (field && property[name] !== undefined && property[name] !== null)
        field.value = String(property[name]);
    });
    Object.entries(listingDetails).forEach(([name, value]) => {
      const field = form.elements.namedItem(name) as
        | HTMLInputElement
        | HTMLTextAreaElement
        | HTMLSelectElement
        | null;
      if (field && value !== undefined && value !== null)
        field.value = String(value);
    });
    const propertyImages = Array.isArray(property.imageUrls)
      ? property.imageUrls
      : property.imageUrl
        ? [property.imageUrl]
        : [];
    setUploadedImages(
      propertyImages.filter(
        value => typeof value === "string" && isAcceptedPropertyImageUrl(value)
      ) as string[]
    );
    const videos = Array.isArray(property.videoUrls) ? property.videoUrls : [];
    setUploadedVideos(
      videos.filter(
        value => typeof value === "string" && isAcceptedPropertyImageUrl(value)
      ) as string[]
    );
  }, [initialProperty, listingType, propertyType]);
  const selectAreaAutomatically = () => {
    const form = formRef.current;
    if (!form) return;
    const location = String(new FormData(form).get("location") || "");
    const result = findAutomaticArea(location, areas);
    const provinceSelect = form.elements.namedItem(
      "province"
    ) as HTMLSelectElement | null;
    const areaSelect = form.elements.namedItem(
      "areaId"
    ) as HTMLSelectElement | null;
    if (provinceSelect && result.province) {
      provinceSelect.value = result.province;
      setSelectedProvince(result.province);
    }
    if (areaSelect && result.areaId) areaSelect.value = String(result.areaId);
    if (!result.province && !result.areaId)
      toast.info("Chưa nhận diện được tỉnh/khu vực. Bạn có thể chọn thủ công.");
    else
      toast.success(`Đã tự động chọn ${result.province || "khu vực phù hợp"}.`);
  };
  const uploadImage = trpc.properties.uploadImage.useMutation({
    onSuccess: result =>
      setUploadedImages(current =>
        [...current, result.url].filter(isAcceptedPropertyImageUrl).slice(0, 8)
      ),
    onError: error => toast.error(error.message),
  });
  const uploadMedia = trpc.properties.uploadMedia.useMutation({
    onSuccess: result => {
      if (result.mediaType === "video")
        setUploadedVideos(current =>
          [...current, result.url]
            .filter(isAcceptedPropertyImageUrl)
            .slice(0, 4)
        );
      else
        setUploadedImages(current =>
          [...current, result.url]
            .filter(isAcceptedPropertyImageUrl)
            .slice(0, 8)
        );
    },
    onError: error => toast.error(error.message),
  });
  const handleFiles = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const available = Math.max(0, 8 - uploadedImages.length);
    const selected = Array.from(event.target.files || []);
    if (!available) {
      toast.error("Bài đăng chỉ được tối đa 8 ảnh.");
      event.target.value = "";
      return;
    }
    if (selected.length > available)
      toast.error(`Chỉ có thể thêm ${available} ảnh nữa.`);
    const files = selected.slice(0, available);
    for (const file of files) {
      if (!file.type.startsWith("image/")) {
        toast.error("Chỉ được chọn tệp hình ảnh.");
        continue;
      }
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} vượt quá 10MB.`);
        continue;
      }
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () =>
          resolve(String(reader.result).split(",")[1] || "");
        reader.onerror = () => reject(new Error("Không thể đọc ảnh"));
        reader.readAsDataURL(file);
      });
      uploadImage.mutate({
        fileName: file.name,
        mimeType: file.type as
          | "image/jpeg"
          | "image/png"
          | "image/webp"
          | "image/gif",
        data,
      });
    }
    event.target.value = "";
  };
  const applyListingOcr = (data: ListingOcrData, sourceUrl: string) => {
    const form = formRef.current;
    if (sourceUrl && isAcceptedPropertyImageUrl(sourceUrl))
      setUploadedImages(current =>
        current.includes(sourceUrl)
          ? current
          : [...current, sourceUrl].slice(0, 8)
      );
    if (!form) return;
    const values: Record<string, unknown> = {
      ...getListingOcrFormValues(data),
      bedrooms: data.bedrooms,
      bathrooms: data.bathrooms,
    };
    Object.entries(values).forEach(([key, value]) => {
      if (value === null || value === undefined || value === "") return;
      const field = form.elements.namedItem(key) as
        | HTMLInputElement
        | HTMLTextAreaElement
        | HTMLSelectElement
        | null;
      if (field) field.value = String(value);
    });
    const title = String(data.title || "").trim();
    const slug = form.elements.namedItem("slug") as HTMLInputElement | null;
    if (slug && !slug.value && title)
      slug.value = title
        .toLocaleLowerCase("vi")
        .normalize("NFD")
        .replace(/[\\u0300-\\u036f]/g, "")
        .replace(/đ/g, "d")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");
    const province = String(data.province || "").trim();
    if (province) {
      const provinceField = form.elements.namedItem(
        "province"
      ) as HTMLSelectElement | null;
      if (provinceField) provinceField.value = province;
      setSelectedProvince(province);
    }
    if (data.location) {
      const result = findAutomaticArea(String(data.location), areas);
      const areaField = form.elements.namedItem(
        "areaId"
      ) as HTMLSelectElement | null;
      if (areaField && result.areaId) areaField.value = String(result.areaId);
      if (!province && result.province) {
        const provinceField = form.elements.namedItem(
          "province"
        ) as HTMLSelectElement | null;
        if (provinceField) provinceField.value = result.province;
        setSelectedProvince(result.province);
      }
    }
  };
  const handleVideos = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const available = Math.max(0, 4 - uploadedVideos.length);
    const selected = Array.from(event.target.files || []);
    if (!available) {
      toast.error("Bài đăng chỉ được tối đa 4 video.");
      event.target.value = "";
      return;
    }
    if (selected.length > available)
      toast.error(`Chỉ có thể thêm ${available} video nữa.`);
    for (const file of selected.slice(0, available)) {
      if (!/^video\/(mp4|webm|quicktime)$/.test(file.type)) {
        toast.error("Chỉ được chọn video MP4, WebM hoặc MOV.");
        continue;
      }
      if (file.size > 50 * 1024 * 1024) {
        toast.error(`${file.name} vượt quá 50MB.`);
        continue;
      }
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () =>
          resolve(String(reader.result).split(",")[1] || "");
        reader.onerror = () => reject(new Error("Không thể đọc video"));
        reader.readAsDataURL(file);
      });
      uploadMedia.mutate({ fileName: file.name, mimeType: file.type, data });
    }
    event.target.value = "";
  };
  const input = (name: string, placeholder: string, required = false) => (
    <input
      name={name}
      required={required}
      placeholder={placeholder}
      className="rounded-xl border border-[#18352D]/15 bg-[#F8F7F1] p-3"
    />
  );
  const area = (name: string, placeholder: string) => (
    <textarea
      name={name}
      placeholder={placeholder}
      className="min-h-24 rounded-xl border border-[#18352D]/15 bg-[#F8F7F1] p-3 md:col-span-2"
    />
  );
  const galleryImages = uploadedImages.slice(0, 8);
  const effectiveGalleryChoice =
    galleryLayoutChoice === "mosaic" && galleryImages.length > 2
      ? "mosaic"
      : galleryLayoutChoice === "split" && galleryImages.length > 1
        ? "split"
        : "single";
  const galleryConfig =
    effectiveGalleryChoice === "mosaic"
      ? { columns: 3, label: "3+ ảnh" }
      : effectiveGalleryChoice === "split"
        ? { columns: 2, label: "2 ảnh" }
        : getGalleryLayout(galleryImages.length);
  const galleryLayout =
    galleryConfig.columns === 1
      ? "grid-cols-1"
      : galleryConfig.columns === 2
        ? "grid-cols-2"
        : "grid-cols-3";
  return (
    <form
      ref={formRef}
      onSubmit={onSubmit}
      className="mt-6 grid gap-5 rounded-[1.5rem] border border-[#DCE9E1] bg-[#FBFDFC] p-4 shadow-[0_18px_42px_rgba(31,90,74,.08)] sm:p-6 md:grid-cols-2"
    >
      {sourceContext && (
        <>
          <input type="hidden" name="sourceType" value={sourceContext.sourceType} />
          <input type="hidden" name="sourceLabel" value={sourceContext.sourceLabel} />
          <input type="hidden" name="transactionPurpose" value={sourceContext.transactionPurpose} />
          <input type="hidden" name="transactionPurposeLabel" value={sourceContext.transactionPurposeLabel} />
          <input type="hidden" name="sourcePropertyCategory" value={sourceContext.propertyCategory} />
          <input type="hidden" name="sourcePropertySubtype" value={sourceContext.propertySubtype} />
          <input type="hidden" name="sourceWorkflow" value={sourceContext.workflow.join(" → ")} />
          <input type="hidden" name="sourceCode" value={sourceContext.sourceCode || ""} />
          <input type="hidden" name="warehouseGroup" value={sourceContext.warehouseGroup || ""} />
          <input type="hidden" name="sourceIntakeValues" value={JSON.stringify(sourceContext.intakeValues || {})} />
          <input type="hidden" name="sourceWorkflowStepValues" value={JSON.stringify(sourceContext.workflowStepValues || {})} />
          <input type="hidden" name="sourceWarehouseStage" value={sourceContext.warehouseStage || "initial_intake"} />
          <input type="hidden" name="sourcePostSyncStatus" value={sourceContext.postSyncStatus || "Chưa tạo bài đăng"} />
        </>
      )}
      {tab === "properties" && (
        <>
          <ListingDocumentAutofill onApply={applyListingOcr} />
          <DynamicListingFields
            transaction={listingType}
            propertyType={propertyType}
            onTransactionChange={setListingType}
            onPropertyTypeChange={setPropertyType}
          />
          <p className="md:col-span-2 text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
            1. Tiêu đề & thông tin nhanh
          </p>
          {input("title", "Tiêu đề bài đăng", true)}
          {input("slug", "slug-bai-dang", true)}
          {input("propertyCode", "Mã BĐS")}
          <p className="md:col-span-2 text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
            2. Vị trí
          </p>
          {input("location", "Địa chỉ/khu vực", true)}
          <select
            name="province"
            required
            value={selectedProvince}
            onChange={event => {
              setSelectedProvince(event.target.value);
              const areaSelect = formRef.current?.elements.namedItem(
                "areaId"
              ) as HTMLSelectElement | null;
              if (areaSelect) areaSelect.value = "";
            }}
            className="rounded-xl border p-3"
          >
            <option value="">Chọn tỉnh/thành phố</option>
            {PROVINCE_OPTIONS.map(province => (
              <option key={province} value={province}>
                {province}
              </option>
            ))}
          </select>
          <div className="flex gap-2">
            <select
              name="areaId"
              className="min-w-0 flex-1 rounded-xl border p-3"
            >
              <option value="">
                {selectedProvince
                  ? `Chọn khu vực chi tiết tại ${selectedProvince}`
                  : "Chọn tỉnh trước để xem khu vực chi tiết"}
              </option>
              {filteredAreas.map(item => (
                <option key={item.id} value={item.id}>
                  {item.name} · {item.province}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={selectAreaAutomatically}
              className="inline-flex shrink-0 items-center gap-1 rounded-xl border border-[#1F5A4A]/25 bg-[#E8F1EC] px-3 text-xs font-bold text-[#1F5A4A]"
              title="Tự động chọn khu vực"
            >
              Tự động chọn
            </button>
          </div>
          {input("price", "Giá bán (tỷ), ví dụ 7.9", true)}
          {input("area", "Diện tích đất (m²)", true)}
          {input("buildArea", "Diện tích xây dựng (m²)")}
          {input("roadWidth", "Đường trước nhà (m), ví dụ 5.5")}
          {input("bedrooms", "Số phòng ngủ")}
          {input("bathrooms", "Số WC")}
          {input("constructionYear", "Năm xây dựng")}
          {input("orientation", "Hướng")}
          {input("distanceToMainRoad", "Khoảng cách đến đường lớn")}
          {input("nearbySchools", "Trường học lân cận")}
          {input("nearbyMarket", "Chợ lân cận")}
          {input("nearbyHospital", "Bệnh viện lân cận")}
          {input("distanceToCenter", "Khoảng cách trung tâm")}
          {
            <p className="md:col-span-2 text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
              4. Pháp lý
            </p>
          }
          {input("legalStatus", "Tình trạng pháp lý tổng quát")}
          {input("certificateType", "Loại giấy chứng nhận")}
          {input("certificateArea", "Diện tích trên giấy (m²)")}
          {input("landUsePurpose", "Mục đích sử dụng đất")}
          {input("planningStatus", "Tình trạng quy hoạch")}
          {input("mortgageStatus", "Tình trạng thế chấp")}
          {input(
            "legalSource",
            "Nguồn pháp lý (mặc định theo hồ sơ/chủ nhà cung cấp)"
          )}
          {
            <p className="md:col-span-2 text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
              5. Giá & điều kiện giao dịch
            </p>
          }
          {input("brokerageFee", "Hoa hồng môi giới")}
          {input("depositTerms", "Điều kiện đặt cọc")}
          {input("transactionTerms", "Điều kiện giao dịch")}
          {
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" name="negotiable" defaultChecked /> Có
              thương lượng
            </label>
          }
          {
            <p className="md:col-span-2 text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
              6. Thông tin môi giới
            </p>
          }
          {input("ownerName", "Tên chủ nhà")}
          {input("ownerPhone", "Số điện thoại chủ nhà")}
          {input("brokerName", "Tên môi giới")}
          {input("brokerPhone", "Số điện thoại môi giới")}
          {input("brokerZalo", "URL Zalo")}
          {
            <p className="md:col-span-2 text-xs font-bold uppercase tracking-widest text-[#1F5A4A]">
              7. Ảnh BĐS
            </p>
          }
          <p className="md:col-span-2 text-xs text-[#60766D]">
            Tối đa 8 ảnh. Bạn có thể chọn ảnh trực tiếp từ điện thoại hoặc máy
            tính; các URL không hợp lệ sẽ được bỏ qua.
          </p>
          <div className="md:col-span-2 rounded-2xl border border-[#1F5A4A]/15 bg-[#F8F7F1] p-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-black text-[#18352D]">
                  Bố cục gallery khi đăng
                </p>
                <p className="mt-1 text-xs leading-5 text-[#60766D]">
                  Chọn cách hiển thị ảnh trên trang nguồn hàng, chi tiết và bản
                  xem trước.
                </p>
              </div>
              <select
                name="galleryLayout"
                value={galleryLayoutChoice}
                onChange={event =>
                  setGalleryLayoutChoice(event.target.value as GalleryLayout)
                }
                className="rounded-xl border border-[#B8D4C6] bg-white px-3 py-2.5 text-sm font-bold text-[#1F5A4A] sm:min-w-[180px]"
              >
                <option value="single">1 ảnh · ảnh lớn</option>
                <option value="split">2 ảnh · chia đôi</option>
                <option value="mosaic">3+ ảnh · mosaic</option>
              </select>
            </div>
            {galleryImages.length <
              (galleryLayoutChoice === "mosaic"
                ? 3
                : galleryLayoutChoice === "split"
                  ? 2
                  : 1) && (
              <p className="mt-3 rounded-lg bg-[#FFF7E1] px-3 py-2 text-xs font-semibold text-[#80601C]">
                Bố cục đã chọn sẽ tự chuyển về 1 ảnh cho đến khi tải đủ số ảnh
                tương ứng.
              </p>
            )}
          </div>
          <label className="md:col-span-2 flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-[#1F5A4A]/35 bg-[#F8F7F1] p-4 text-sm font-bold text-[#1F5A4A] hover:bg-[#E8F1EC]">
            <Upload size={18} />{" "}
            {uploadImage.isPending
              ? "Đang tải ảnh lên…"
              : "Đính kèm hình ảnh từ điện thoại hoặc máy tính"}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              multiple
              onChange={handleFiles}
              className="sr-only"
            />
          </label>
          {uploadedImages.length > 0 && (
            <div className="md:col-span-2 space-y-4">
              <div className="rounded-2xl border border-[#1F5A4A]/15 bg-[#18352D] p-3 sm:p-4">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[.16em] text-[#E6C478]">
                      Xem trước bài đăng
                    </p>
                    <p className="mt-1 text-sm font-bold text-white">
                      {uploadedImages.length} ảnh · tự động cập nhật
                    </p>
                  </div>
                  <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold text-white/80">
                    Gallery {galleryConfig.label}
                  </span>
                </div>
                <div
                  className={`grid ${galleryLayout} gap-1.5 overflow-hidden rounded-xl bg-[#102B24] ${galleryImages.length >= 3 ? "grid-rows-2" : ""}`}
                >
                  {galleryImages.map((url, index) => (
                    <div
                      key={`preview-${url}`}
                      className={`${galleryImages.length === 3 && index === 0 ? "row-span-2" : ""} relative min-h-28 overflow-hidden sm:min-h-36`}
                    >
                      <img
                        src={url}
                        alt={`Xem trước ảnh ${index + 1}`}
                        className="h-full w-full object-cover"
                      />
                      {index === 0 && (
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 to-transparent px-3 pb-2 pt-8">
                          <p className="truncate text-sm font-black text-white">
                            Bài đăng mới
                          </p>
                          <p className="text-[10px] font-semibold text-white/85">
                            Ảnh {index + 1}/{galleryImages.length}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {uploadedImages.map((url, index) => (
                  <div
                    key={url}
                    className="relative overflow-hidden rounded-xl border bg-[#F8F7F1]"
                  >
                    <img
                      src={url}
                      alt={`Ảnh đã tải lên ${index + 1}`}
                      className="h-24 w-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setUploadedImages(current =>
                          removeUploadedImage(current, url)
                        )
                      }
                      aria-label={`Xóa ảnh ${index + 1}`}
                      className="absolute right-2 top-2 inline-flex h-8 w-8 items-center justify-center rounded-full bg-red-700/90 text-white shadow-sm hover:bg-red-800"
                    >
                      <Trash2 size={15} />
                    </button>
                    <p className="truncate px-2 py-1 text-xs text-[#60766D]">
                      Ảnh {index + 1}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
          <input
            type="hidden"
            name="imageUrls"
            value={uploadedImages.join("\n")}
          />
          <div className="md:col-span-2 mt-2 rounded-xl border border-[#1F5A4A]/15 bg-[#F8F7F1] p-4">
            <div className="flex items-start gap-3">
              <Video size={20} className="mt-0.5 text-[#1F5A4A]" />
              <div>
                <p className="text-sm font-bold text-[#18352D]">
                  Video giới thiệu BĐS
                </p>
                <p className="mt-1 text-xs leading-5 text-[#60766D]">
                  Tối đa 4 video, mỗi video không quá 50MB. Hỗ trợ MP4, WebM,
                  MOV và có thể quay/chọn trực tiếp trên điện thoại.
                </p>
              </div>
            </div>
            <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-[#C75C45]/40 bg-white p-4 text-sm font-bold text-[#C75C45] hover:bg-[#FFF3EF]">
              <Video size={18} />{" "}
              {uploadMedia.isPending
                ? "Đang tải video lên…"
                : "Đính kèm hoặc quay video"}
              <input
                type="file"
                name="videoFiles"
                accept="video/mp4,video/webm,video/quicktime"
                capture="environment"
                multiple
                onChange={handleVideos}
                className="sr-only"
              />
            </label>
            {uploadedVideos.length > 0 && (
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {uploadedVideos.map((url, index) => (
                  <div
                    key={url}
                    className="relative overflow-hidden rounded-xl border bg-white"
                  >
                    <video
                      src={url}
                      controls
                      preload="metadata"
                      className="h-36 w-full bg-black object-contain"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setUploadedVideos(current =>
                          removeUploadedImage(current, url)
                        )
                      }
                      aria-label={`Xóa video ${index + 1}`}
                      className="absolute right-2 top-2 inline-flex h-8 w-8 items-center justify-center rounded-full bg-red-700/90 text-white shadow-sm hover:bg-red-800"
                    >
                      <Trash2 size={15} />
                    </button>
                    <p className="truncate px-2 py-1 text-xs text-[#60766D]">
                      Video {index + 1}
                    </p>
                  </div>
                ))}
              </div>
            )}
            <input
              type="hidden"
              name="videoUrls"
              value={uploadedVideos.join("\n")}
            />
          </div>
          {input("imageFront", "URL ảnh mặt tiền")}
          {input("imageLivingRoom", "URL ảnh phòng khách")}
          {input("imageBedroom", "URL ảnh phòng ngủ")}
          {input("imageKitchen", "URL ảnh bếp")}
          {input("imageOutdoor", "URL ảnh sân / ban công")}
          {input("imageRoad", "URL ảnh đường trước nhà")}
          {input("imageLegal", "URL ảnh sổ / hồ sơ nếu được phép chia sẻ")}
          {area(
            "description",
            "Mô tả tình trạng nhà, công năng, vị trí và ưu điểm"
          )}
          {
            <p className="md:col-span-2 rounded-xl bg-[#F5F2EA] p-3 text-sm text-[#60766D]">
              Bài mới sẽ được lưu ở trạng thái Nháp. Tài khoản đã đăng nhập có
              thể gửi bài; tài khoản quản trị sẽ kiểm tra và chọn “Công khai”
              trong bảng Nguồn hàng để bài xuất hiện tại mục Sản phẩm đang bán.
            </p>
          }
        </>
      )}
      {tab === "owners" && (
        <>
          {input("name", "Tên chủ nhà", true)}
          {input("phone", "Số điện thoại", true)}
          {input("email", "Email")}
          {area("notes", "Ghi chú")}
        </>
      )}
      {tab === "buyers" && (
        <>
          {input("name", "Tên khách mua", true)}
          {input("phone", "Số điện thoại", true)}
          {input("budget", "Ngân sách (tỷ)")}
          {input("preferredArea", "Khu vực mong muốn")}
          {input("propertyType", "Loại BĐS")}
          {area("notes", "Ghi chú")}
        </>
      )}
      {tab === "survey" && (
        <>
          {input("propertyId", "Mã BĐS (nếu có)")}
          {input("buyerLeadId", "Mã khách mua (nếu có)")}
          {input("purpose", "Mục đích mua")}
          {input("budget", "Ngân sách")}
          {input("timeline", "Thời gian dự kiến")}
          {area("mustHave", "Tiêu chí bắt buộc")}
          {area("notes", "Ghi chú")}
        </>
      )}
      {tab === "legal" && (
        <>
          {input("propertyId", "Mã BĐS", true)}
          <select name="status" className="rounded-xl border p-3">
            <option value="pending">Chờ kiểm tra</option>
            <option value="in_review">Đang kiểm tra</option>
            <option value="verified">Đã xác minh</option>
            <option value="issue_found">Có vấn đề</option>
          </select>
          {area("documents", "Tài liệu / đường dẫn hồ sơ")}
          {area("notes", "Ghi chú")}
        </>
      )}
      {tab === "valuation" && (
        <>
          {input("propertyId", "Mã BĐS", true)}
          {input("estimatedPrice", "Giá ước tính (tỷ)", true)}
          {input("method", "Phương pháp định giá")}
          {area("comparableNotes", "Căn cứ so sánh")}
        </>
      )}
      {tab === "deals" && (
        <>
          {input("propertyId", "Mã BĐS", true)}
          {input("buyerLeadId", "Mã khách mua")}
          {input("ownerId", "Mã chủ nhà")}
          {input("agreedPrice", "Giá thỏa thuận (tỷ)")}
          <select name="stage" className="rounded-xl border p-3">
            <option value="new">Mới</option>
            <option value="negotiating">Đàm phán</option>
            <option value="deposit">Đặt cọc</option>
            <option value="contracted">Đã ký hợp đồng</option>
            <option value="completed">Hoàn tất</option>
            <option value="cancelled">Đã hủy</option>
          </select>
          {area("notes", "Ghi chú")}
        </>
      )}
      <div className="sticky bottom-3 z-10 flex flex-col gap-3 rounded-2xl border border-[#C8DDD2] bg-white/95 p-3 shadow-[0_12px_30px_rgba(24,53,45,.12)] backdrop-blur sm:flex-row sm:items-center sm:justify-between md:col-span-2">
        <div>
          <p className="text-sm font-bold text-[#18352D]">
            Sẵn sàng cập nhật bài đăng?
          </p>
          <p className="mt-0.5 text-xs text-[#60766D]">
            Bài mới vẫn là Nháp; chỉ công khai sau khi kiểm tra đủ thông tin.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => toast.info("Đã mở chế độ xem trước bài đăng.")}
            className="rounded-full border border-[#1F5A4A]/25 bg-white px-4 py-2.5 text-sm font-bold text-[#1F5A4A]"
          >
            Xem trước
          </button>
          <button
            type="submit"
            className="rounded-full bg-[#1F5A4A] px-5 py-2.5 text-sm font-bold text-white shadow-sm"
          >
            {initialProperty ? "Lưu thay đổi" : "Lưu bài Nháp"}
          </button>
          {(initialProperty || onCancel) && (
            <button
              type="button"
              onClick={onCancel}
              className="rounded-full border border-[#E3B3A7] bg-[#FFF7F4] px-4 py-2.5 text-sm font-bold text-[#B44D37]"
            >
              {initialProperty ? "Hủy chỉnh sửa" : "Hủy tạo nguồn"}
            </button>
          )}
        </div>
      </div>
    </form>
  );
}

export function PropertyTable({
  data,
  onStatus,
  onDelete,
  onScan,
  onEdit,
  onPreview,
  deletingId,
  selectedIds = [],
  onToggleSelect,
  onToggleSelectAll,
  onBulkStatus,
}: {
  data: Array<{
    id: number;
    title: string;
    location: string;
    price: string;
    area: string;
    status: "draft" | "published" | "reserved" | "sold";
    areaName?: string | null;
    areaProvince?: string | null;
  }>;
  onStatus: (
    id: number,
    status: "draft" | "published" | "reserved" | "sold"
  ) => void;
  onDelete: (id: number) => void;
  onScan: (id: number, title: string) => void;
  onEdit: (id: number) => void;
  onPreview: (id: number) => void;
  deletingId?: number;
  selectedIds?: number[];
  onToggleSelect?: (id: number) => void;
  onToggleSelectAll?: (checked: boolean) => void;
  onBulkStatus?: (status: "published" | "reserved" | "sold") => void;
}) {
  const sold = data.filter(item => item.status === "sold");
  const available = data.filter(item => item.status !== "sold");
  const statusLabel = (status: string) =>
    status === "sold"
      ? "Đã bán"
      : status === "published"
        ? "Đang đăng bán"
        : status === "reserved"
          ? "Đang giữ chỗ"
          : "Chưa bán";
  const renderTable = (items: typeof data) => {
    const itemIds = items.map(item => item.id);
    const allSelected = itemIds.length > 0 && itemIds.every(id => selectedIds.includes(id));
    return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[920px] text-left text-sm">
        <thead className="bg-[#18352D] text-xs uppercase tracking-wider text-white">
          <tr>
            <th className="p-4">
              <input
                type="checkbox"
                aria-label="Chọn tất cả hồ sơ trong nhóm"
                checked={allSelected}
                onChange={event => onToggleSelectAll?.(event.target.checked)}
              />
            </th>
            <th className="p-4">Nguồn hàng</th>
            <th className="p-4">Vị trí</th>
            <th className="p-4">Giá</th>
            <th className="p-4">Phân loại</th>
            <th className="p-4">Thao tác</th>
          </tr>
        </thead>
        <tbody>
          {items.map(item => (
            <tr key={item.id} className="border-b last:border-0">
              <td className="p-4">
                <input
                  type="checkbox"
                  aria-label={`Chọn hồ sơ ${item.title}`}
                  checked={selectedIds.includes(item.id)}
                  onChange={() => onToggleSelect?.(item.id)}
                />
              </td>
              <td className="p-4 font-bold">
                {item.title}
                <span className="mt-1 block text-xs font-normal text-[#60766D]">
                  {item.area} m²
                </span>
              </td>
              <td className="p-4 text-[#60766D]">
                {item.location}
                <span className="mt-1 block text-xs text-[#1F5A4A]">
                  {item.areaName
                    ? `${item.areaName} · ${item.areaProvince || ""}`
                    : "Chưa gắn khu vực"}
                </span>
              </td>
              <td className="p-4 font-bold text-[#1F5A4A]">{item.price} tỷ</td>
              <td className="p-4">
                <span
                  className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${item.status === "sold" ? "bg-[#E8E5D9] text-[#6B5B37]" : "bg-[#E8F1EC] text-[#1F5A4A]"}`}
                >
                  {statusLabel(item.status)}
                </span>
              </td>
              <td className="p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onStatus(
                        item.id,
                        item.status === "sold" ? "draft" : "sold"
                      )
                    }
                    className={`inline-flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-bold transition ${item.status === "sold" ? "border border-[#B8D4C6] bg-[#F4FAF6] text-[#1F5A4A] hover:bg-[#E8F1EC]" : "bg-[#E6C478] text-[#18352D] hover:bg-[#F2D99E]"}`}
                  >
                    {item.status === "sold" ? "Chưa bán" : "Đã bán"}
                  </button>
                  {item.status === "sold" && (
                    <button
                      type="button"
                      onClick={() => onStatus(item.id, "sold")}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#D8B15A] bg-[#FFF9EA] px-2 py-1 text-xs font-bold text-[#80601C] transition hover:bg-[#F4E7BF]"
                    >
                      Thử lại sản xuất
                    </button>
                  )}
                  <select
                    aria-label={`Trạng thái chi tiết ${item.title}`}
                    value={item.status}
                    onChange={e =>
                      onStatus(
                        item.id,
                        e.target.value as
                          | "draft"
                          | "published"
                          | "reserved"
                          | "sold"
                      )
                    }
                    className="rounded-lg border px-2 py-1 text-xs"
                  >
                    <option value="draft">Nháp</option>
                    <option value="published">Công khai</option>
                    <option value="reserved">Đặt chỗ</option>
                    <option value="sold">Đã bán</option>
                  </select>
                  {item.status !== "published" && item.status !== "sold" && (
                    <button
                      type="button"
                      onClick={() => onStatus(item.id, "published")}
                      className="inline-flex items-center gap-1 rounded-lg bg-[#1F5A4A] px-2 py-1 text-xs font-bold text-white transition hover:bg-[#164638]"
                    >
                      <Globe2 size={14} /> Công khai
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => onPreview(item.id)}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#B8D4C6] bg-white px-2 py-1 text-xs font-bold text-[#1F5A4A] transition hover:bg-[#E8F1EC]"
                  >
                    <Eye size={14} /> Xem trước
                  </button>
                  <button
                    type="button"
                    onClick={() => onEdit(item.id)}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#D8B15A] bg-[#FFF9EA] px-2 py-1 text-xs font-bold text-[#80601C] transition hover:bg-[#F4E7BF]"
                  >
                    <Pencil size={14} /> Chỉnh sửa
                  </button>
                  <button
                    type="button"
                    onClick={() => onScan(item.id, item.title)}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#B8D4C6] bg-[#F4FAF6] px-2 py-1 text-xs font-bold text-[#1F5A4A] transition hover:bg-[#E8F1EC]"
                  >
                    <FileCheck2 size={14} /> Quét sổ
                  </button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button
                        type="button"
                        disabled={deletingId === item.id}
                        aria-label={`Xóa ${item.title}`}
                        className="inline-flex items-center gap-1 rounded-lg border border-red-200 px-2 py-1 text-xs font-bold text-red-700 transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <Trash2 size={14} />
                        {deletingId === item.id ? "Đang xóa" : "Xóa"}
                      </button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Xóa bài đăng này?</AlertDialogTitle>
                        <AlertDialogDescription>
                          {getPropertyDeleteDescription(item.title)}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Hủy</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() =>
                            confirmPropertyDeletion(item.id, true, onDelete)
                          }
                          className="bg-red-700 text-white hover:bg-red-800"
                        >
                          Xóa bài đăng
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!items.length && (
        <p className="p-8 text-center text-[#60766D]">Chưa có dữ liệu.</p>
      )}
    </div>
  );
  };
  return (
    <div className="space-y-5">
      {selectedIds.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#B8D4C6] bg-[#F4FAF6] p-4">
          <p className="text-sm font-bold text-[#1F5A4A]">Đã chọn {selectedIds.length} hồ sơ</p>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => onBulkStatus?.("published")} className="rounded-lg bg-[#1F5A4A] px-3 py-2 text-xs font-bold text-white">Duyệt & công khai</button>
            <button type="button" onClick={() => onBulkStatus?.("reserved")} className="rounded-lg border border-[#D8B15A] bg-[#FFF9EA] px-3 py-2 text-xs font-bold text-[#80601C]">Chuyển đặt chỗ</button>
            <button type="button" onClick={() => onBulkStatus?.("sold")} className="rounded-lg bg-[#E6C478] px-3 py-2 text-xs font-bold text-[#18352D]">Chuyển đã bán</button>
          </div>
        </div>
      )}
      {renderTable(available)}
      <section className="rounded-2xl border border-[#D8CFAE] bg-[#FFFDF5] p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="font-serif text-xl text-[#18352D]">
              BĐS đã bán · lưu trữ
            </h3>
            <p className="text-xs text-[#80601C]">
              Các bài đã chuyển sang Đã bán vẫn giữ nguyên dữ liệu để tiếp tục
              làm hồ sơ.
            </p>
          </div>
          <span className="rounded-full bg-[#E8E5D9] px-3 py-1 text-xs font-bold text-[#6B5B37]">
            {sold.length} bài
          </span>
        </div>
        {renderTable(sold)}
      </section>
    </div>
  );
}

function GenericTable({
  tab,
  data,
}: {
  tab: string;
  data: Array<Record<string, unknown>>;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="bg-[#E8E5D9] text-xs uppercase tracking-wider text-[#18352D]">
          <tr>
            <th className="p-4">Mã</th>
            <th className="p-4">Thông tin chính</th>
            <th className="p-4">Trạng thái</th>
            <th className="p-4">Cập nhật</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr
              key={String(item.id || index)}
              className="border-b last:border-0"
            >
              <td className="p-4">#{String(item.id || index + 1)}</td>
              <td className="p-4 font-medium">
                {String(
                  item.name ||
                    item.title ||
                    item.purpose ||
                    item.method ||
                    `Hồ sơ ${tab}`
                )}
              </td>
              <td className="p-4">
                {String(item.status || item.stage || "Đang cập nhật")}
              </td>
              <td className="p-4 text-[#60766D]">
                {String(
                  item.updatedAt || item.createdAt || item.assessedAt || ""
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!data.length && (
        <p className="p-10 text-center text-[#60766D]">
          Chưa có dữ liệu trong mục này.
        </p>
      )}
    </div>
  );
}
