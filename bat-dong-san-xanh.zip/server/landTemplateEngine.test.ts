import { describe, expect, it } from "vitest";
import JSZip from "jszip";
import { fillVerifiedDocx, inspectVerifiedTemplate, sha256Hex, assertVerifiedTemplateAsset, type VerifiedTemplateAsset } from "./landTemplateEngine";

const baseAsset: VerifiedTemplateAsset = {
  id: "test-template",
  fileName: "test.docx",
  format: "docx",
  mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  sourceUrl: "https://example.gov.vn/test.docx",
  sourceCheckedAt: "17/08/2026",
  sha256: "",
  storageKey: "templates/test.docx",
  sourceStatus: "verified",
};

describe("verified land template engine", () => {
  it("rejects an unverified source before any binary processing", () => {
    const asset = { ...baseAsset, sourceStatus: "needs_review" as never };
    expect(() => assertVerifiedTemplateAsset(asset, new Uint8Array([0x50, 0x4b, 0x03, 0x04]))).toThrow("chưa có trạng thái nguồn");
  });

  it("fills DOCX XML placeholders only after signature and checksum validation", async () => {
    const zip = new JSZip();
    zip.file("[Content_Types].xml", "<Types/>");
    zip.file("word/document.xml", "<w:document>Chủ sử dụng: {{ownerName}}</w:document>");
    const source = await zip.generateAsync({ type: "uint8array" });
    const asset = { ...baseAsset, sha256: sha256Hex(source), placeholderMap: { "Chủ sử dụng": "{{ownerName}}" } };
    const filled = await fillVerifiedDocx(asset, source, [{ label: "Chủ sử dụng", value: "Nguyễn Văn A" }]);
    const output = await JSZip.loadAsync(filled);
    expect(await output.file("word/document.xml")!.async("string")).toContain("Nguyễn Văn A");
  });

  it("fills official DOCX labels with dotted blanks when no placeholder token exists", async () => {
    const zip = new JSZip();
    zip.file("word/document.xml", "<w:document><w:body><w:p><w:r><w:t>1. Địa chỉ:................................................</w:t></w:r></w:p></w:body></w:document>");
    const source = await zip.generateAsync({ type: "uint8array" });
    const asset = { ...baseAsset, sha256: sha256Hex(source) };
    const inspection = await inspectVerifiedTemplate(asset, source, [{ label: "Địa chỉ", value: "Đà Nẵng" }]);
    expect(inspection.fillable).toBe(true);
    expect(inspection.matchedFields).toContain("Địa chỉ");
    const filled = await fillVerifiedDocx(asset, source, [{ label: "Địa chỉ", value: "Đà Nẵng" }]);
    const output = await JSZip.loadAsync(filled);
    expect(await output.file("word/document.xml")!.async("string")).toContain("Đà Nẵng");
  });

  it("reports when an official DOCX has no matching placeholder token", async () => {
    const zip = new JSZip();
    zip.file("word/document.xml", "<w:document>Mẫu in sẵn không có token</w:document>");
    const source = await zip.generateAsync({ type: "uint8array" });
    const asset = { ...baseAsset, sha256: sha256Hex(source) };
    const inspection = await inspectVerifiedTemplate(asset, source, [{ label: "Chủ sử dụng", value: "A" }]);
    expect(inspection.fillable).toBe(false);
    expect(inspection.warning).toContain("không có placeholder");
    await expect(fillVerifiedDocx(asset, source, [{ label: "Chủ sử dụng", value: "A" }])).rejects.toThrow("không có placeholder");
  });

  it("rejects a checksum mismatch instead of producing a document", async () => {
    const zip = new JSZip();
    zip.file("word/document.xml", "{{ownerName}}");
    const source = await zip.generateAsync({ type: "uint8array" });
    const asset = { ...baseAsset, sha256: "0".repeat(64) };
    await expect(fillVerifiedDocx(asset, source, [{ label: "ownerName", value: "A" }])).rejects.toThrow("Checksum template không khớp");
  });
});
