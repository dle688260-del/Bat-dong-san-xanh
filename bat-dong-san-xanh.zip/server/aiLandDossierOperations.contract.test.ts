import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("AI land dossier operations contract", () => {
  const routerSource = readFileSync(
    resolve(process.cwd(), "server/routers.ts"),
    "utf8"
  );
  const pageSource = readFileSync(
    resolve(process.cwd(), "client/src/pages/AiLandDossierOperations.tsx"),
    "utf8"
  );
  const appSource = readFileSync(
    resolve(process.cwd(), "client/src/App.tsx"),
    "utf8"
  );
  const serverSource = readFileSync(
    resolve(process.cwd(), "server/_core/index.ts"),
    "utf8"
  );
  const syncSource = readFileSync(
    resolve(process.cwd(), "server/scheduledLegalSync.ts"),
    "utf8"
  );

  it("exposes persistence-backed operations under a dedicated router", () => {
    expect(routerSource).toContain("aiLandDossierAdmin: router({");
    expect(routerSource).toContain("versionHistory: adminProcedure");
    expect(routerSource).toContain("createVersion: adminProcedure");
    expect(routerSource).toContain("templateMappings: adminProcedure");
    expect(routerSource).toContain("saveTemplateMappings: adminProcedure");
    expect(routerSource).toContain("dossierAudits: adminProcedure");
    expect(routerSource).toContain("appendAudit: adminProcedure");
    expect(routerSource).toContain("crawlerStatus: adminProcedure");
  });

  it("mounts a Heartbeat-safe scheduled legal source sync", () => {
    expect(serverSource).toContain(
      'app.all("/api/scheduled/sync-legal-sources", scheduledLegalSyncHandler)'
    );
    expect(serverSource).toContain(
      'app.all("/api/scheduled/sync-legal-sources/", scheduledLegalSyncHandler)'
    );
    expect(serverSource).toContain('app.all("/api/scheduled/heartbeat-ping"');
    expect(serverSource).toContain('service: "heartbeat"');
    expect(syncSource).toContain("if (!user.isCron || !user.taskUid)");
    expect(syncSource).toContain("listLegalProcedureVersions(dbProcedure.id)");
    expect(syncSource).toContain('status === "verified_binary"');
    expect(syncSource).toContain("officialFiles");
    expect(syncSource).toContain("sourceHash");
    expect(syncSource).toContain("finishLegalSyncRun(syncRunId");
  });

  it("keeps the operations UI connected to the real tRPC contracts", () => {
    expect(pageSource).toContain(
      "trpc.aiLandDossierAdmin.versionHistory.useQuery"
    );
    expect(pageSource).toContain(
      "trpc.aiLandDossierAdmin.crawlerStatus.useQuery"
    );
    expect(pageSource).toContain(
      "trpc.aiLandDossierAdmin.templateMappings.useQuery"
    );
    expect(pageSource).toContain(
      "trpc.aiLandDossierAdmin.dossierAudits.useQuery"
    );
    expect(pageSource).toContain(
      "trpc.aiLandDossierAdmin.appendAudit.useMutation"
    );
    expect(appSource).toContain('path="/ai-ho-so-dat-dai-van-hanh"');
    expect(appSource).toContain("component={AiLandDossierOperations}");
  });
});

it("integrates the procedure chooser and reusable land profile into the existing dossier page", () => {
  const pipelineSource = readFileSync(
    resolve(process.cwd(), "client/src/pages/AiLandDossierPipeline.tsx"),
    "utf8"
  );
  expect(pipelineSource).toContain("Tôi muốn làm thủ tục");
  expect(pipelineSource).toContain("selectedCategory");
  expect(pipelineSource).toContain("categoryFor");
  expect(pipelineSource).toContain("Nhập một lần, dùng cho nhiều biểu mẫu");
  expect(pipelineSource).toContain("mapSheet");
  expect(pipelineSource).toContain("certificate");
  expect(pipelineSource).toContain("officialSearch.data?.items");
  expect(pipelineSource).toContain("autoDiscoverDvcBinaryCandidates");
});
