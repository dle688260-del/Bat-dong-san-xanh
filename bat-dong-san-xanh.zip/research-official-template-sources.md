# Ghi chú nguồn mẫu chính thức

Trong lần tìm kiếm ngày 2026-08-19, các kết quả liên quan gồm:

- Cổng Dịch vụ công: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc — trang thủ tục đăng ký biến động quyền sử dụng đất.
- Cổng tỉnh Nhà Bè/TP.HCM: https://vptt-nhabe.tphcm.gov.vn/kiosk/KioskThuTucHanhChinh/LoadPartialThongTinThuTucChiTiet?ThuTucID — kết quả hiển thị liên kết “mau so09.docx” trong thành phần hồ sơ.
- Cổng tỉnh Ninh Bình: https://trungson.ninhbinh.gov.vn/public/files/vanban/M%E1%BA%ABu%20s%E1%BB%91%2015_%20Don%20dang%20ky%20dat%20dai.pdf — kết quả hiển thị PDF Mẫu số 15.
- Cổng Chính phủ về Nghị định 101/2024/NĐ-CP: http://www.gov.vn/?pageid= — nguồn văn bản chính thức được kết quả tìm kiếm xác định, nhưng liên kết truy vấn cụ thể cần được kiểm tra lại trước khi lưu.

Kết luận triển khai: có thể tự động tìm liên kết DOCX/PDF trên miền nhà nước được phép, tải về, kiểm tra MIME/kích thước/checksum và đưa vào khu “Binary mẫu gốc cần xác minh”. Không được tự chuyển thành Official chỉ vì tải được từ một trang .gov.vn; vẫn phải kiểm tra đúng thủ tục, phiên bản, địa phương và cơ quan tiếp nhận.

## Kiểm tra trực tiếp nguồn Chính phủ ngày 2026-08-19

- Bài viết chính thức: https://xaydungchinhsach.chinhphu.vn/mau-don-dang-ky-bien-dong-dat-dai-tai-san-gan-lien-voi-dat-119240801154458481.htm
- Liên kết DOCX được bài viết Chính phủ công khai: https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkybiendongdat-17225018464101254582634.docx
- Trang xác nhận mẫu được quy định tại Nghị định 101/2024/NĐ-CP ngày 29/7/2024.
- Phần xem mẫu trên trang ghi rõ “Mẫu số 11/ĐK” và tiêu đề “ĐƠN ĐĂNG KÝ BIẾN ĐỘNG ĐẤT ĐAI, TÀI SẢN GẮN LIỀN VỚI ĐẤT”.
- Hướng dẫn trên trang nêu hộ gia đình/cá nhân ghi Văn phòng đăng ký đất đai/Chi nhánh Văn phòng đăng ký đất đai nơi có đất; tổ chức ghi Văn phòng đăng ký đất đai nơi có đất.

### Kết luận đối với tệp người dùng đã tải
Tệp đang có tiêu đề “Mẫu 09/ĐK” và dòng “CONFIRMED DRAFT”; đó là bản AI dựng, không phải binary gốc Chính phủ. Với nguồn Chính phủ đã kiểm tra, binary ứng viên là DOCX ở trên và mẫu hiển thị là Mẫu 11/ĐK theo bài viết ngày 02/08/2024. Không được gắn Official chỉ bằng tên hoặc điểm matcher; phải lưu binary, checksum, nguồn, ngày kiểm tra, thủ tục và phạm vi áp dụng. Cần tiếp tục kiểm tra hiệu lực hiện hành và nguồn địa phương trước khi người dùng in, ký, nộp.

## Binary Mẫu 11/ĐK đã nạp vào allowlist

- Tệp nguồn: https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkybiendongdat-17225018464101254582634.docx
- Tên lưu trữ: `mau-11-dk-nd101-2024.docx`
- Storage key: `official-land-templates/mau-11-dk-nd101-2024_38358437.docx`
- Kích thước kiểm tra: 18,801 bytes
- SHA-256: `6d029d2c8bc920380de658dfc4e69cb2ecc19261c4ff6fbc9f3579da4774026c`
- Ngày kiểm tra binary: 2026-08-19
- Lưu ý kỹ thuật: DOCX gốc không chứa token `{{...}}`; engine phải chặn việc tuyên bố đã điền Official nếu chưa có mapping thủ công/placeholder hợp lệ.
