import { describe, expect, it } from "vitest";
import { getPropertyCtaLinks } from "./PropertyDetail";

describe("PropertyDetail CTAs", () => {
  it("provides the four required contact actions", () => {
    const links = getPropertyCtaLinks("Nhà Thanh Khê 2 tầng", "https://batdongsan-7bupubgw.manus.space/bat-dong-san/nha-thanh-khe");
    expect(links.phone).toBe("tel:0989682825");
    expect(links.zalo).toBe("https://zalo.me/0989682825");
    expect(links.viewing).toContain("/?interest=Nh%C3%A0%20Thanh%20Kh%C3%AA%202%20t%E1%BA%A7ng#lien-he");
    expect(links.facebook).toContain("https://www.facebook.com/sharer/sharer.php?u=");
    expect(links.facebook).toContain("batdongsan-7bupubgw.manus.space");
  });
});
