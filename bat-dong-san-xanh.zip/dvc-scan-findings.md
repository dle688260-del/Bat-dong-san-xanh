# Kết quả rà soát nguồn DVC ngày 2026-08-19

Nguồn chính: Cổng Dịch vụ công Quốc gia, các trang thủ tục do Văn phòng Chính phủ công bố.

| Mã thủ tục | Cơ quan/nơi nộp được nêu trên DVC | Cơ quan xử lý được nêu trên DVC | Biểu mẫu/liên kết quan sát được |
|---|---|---|---|
| 2.000889 | Văn phòng đăng ký đất đai hoặc Chi nhánh; cơ quan tiếp nhận theo quy định UBND cấp tỉnh; hộ gia đình/cá nhân có thể nộp tại UBND cấp xã nếu có nhu cầu | Văn phòng đăng ký đất đai hoặc Chi nhánh | Mẫu 09/ĐK, liên kết tệp từ csdl.dichvucong.gov.vn |
| 1.013978 | Trung tâm Phục vụ hành chính công | UBND cấp xã; Chi nhánh Văn phòng đăng ký đất đai cập nhật hồ sơ địa chính | Mẫu 15/ĐK, Mẫu 16, 17, 19 theo nội dung trang |
| 1.012783 | Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh | Văn phòng đăng ký đất đai/Chi nhánh | Có viện dẫn Mẫu 19; cần đọc tiếp phần biểu mẫu nếu cần |
| 1.012784 | Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh | Văn phòng đăng ký đất đai/Chi nhánh | Mẫu 21 và Mẫu 22 từ csdl.dichvucong.gov.vn |

Các trang DVC có vùng “Chọn cơ quan thực hiện” và danh sách tỉnh/thành, phường/xã; vì vậy hệ thống không được tự suy đoán tên chi nhánh theo chuỗi địa bàn. Cần truy xuất kết quả sau khi chọn địa phương hoặc yêu cầu người dùng xác nhận nếu nguồn địa phương không trả về bản ghi cụ thể.

URL nguồn:
- https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889
- https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
- https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783
- https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784
