import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { PwaInstallButton } from "./PwaInstallButton";

describe("PwaInstallButton", () => {
  it("renders the storefront install label", () => {
    const html = renderToStaticMarkup(<PwaInstallButton appName="Website bán hàng" />);
    expect(html).toContain("Cài Website bán hàng vào điện thoại");
  });

  it("renders the CRM install label", () => {
    const html = renderToStaticMarkup(<PwaInstallButton appName="CRM" />);
    expect(html).toContain("Cài CRM vào điện thoại");
  });
});
