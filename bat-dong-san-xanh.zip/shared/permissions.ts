export type AppRole = "admin" | "user";
export type SensitiveDossierAction = "view" | "download" | "manage";

/** Hồ sơ pháp lý, giao dịch và bản quét giấy tờ luôn được xem là nhạy cảm. */
export const sensitiveArchiveCategories = ["legal", "transaction"] as const;

export function canAccessSensitiveDossier(role: AppRole, action: SensitiveDossierAction): boolean {
  if (role === "admin") return true;
  return action === "view" || action === "download" ? false : false;
}

export function permissionMessage(role: AppRole, action: SensitiveDossierAction): string {
  if (canAccessSensitiveDossier(role, action)) return "Được phép";
  const actionLabel = action === "view" ? "xem" : action === "download" ? "tải xuống" : "quản lý";
  return `Vai trò ${role} không được phép ${actionLabel} hồ sơ nhạy cảm.`;
}
