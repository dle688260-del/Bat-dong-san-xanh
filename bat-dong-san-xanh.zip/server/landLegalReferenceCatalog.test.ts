import { describe, expect, it } from "vitest";
import {
  LAND_LEGAL_REFERENCE_CATALOG,
  getReferencesForProcedure,
} from "./landLegalReferenceCatalog";

describe("land legal reference catalog", () => {
  it("keeps government legal bases separate from public reference templates", () => {
    const legalBases = LAND_LEGAL_REFERENCE_CATALOG.filter(
      candidate => candidate.kind === "legal_basis",
    );
    const referenceTemplates = LAND_LEGAL_REFERENCE_CATALOG.filter(
      candidate => candidate.kind === "reference_template",
    );

    expect(legalBases.map(candidate => candidate.documentNumber)).toEqual(
      expect.arrayContaining([
        "96/2024/NĐ-CP",
        "101/2024/NĐ-CP",
        "102/2024/NĐ-CP",
        "103/2024/NĐ-CP",
        "151/2025/NĐ-CP",
      ]),
    );
    expect(legalBases.every(candidate => candidate.sourceLayer === "government")).toBe(true);
    expect(referenceTemplates.every(candidate => candidate.sourceLayer === "public_reference")).toBe(true);
    expect(referenceTemplates.every(candidate => candidate.notes.includes("Reference"))).toBe(true);
  });

  it("matches procedure 1.012789 with the Mẫu 14 reference candidate", () => {
    const references = getReferencesForProcedure({
      code: "1.012789",
      name: "Cung cấp thông tin, dữ liệu đất đai",
    });

    expect(references.some(candidate => candidate.documentNumber === "Mẫu 14")).toBe(true);
    expect(
      references
        .filter(candidate => candidate.documentNumber === "Mẫu 14")
        .every(candidate => candidate.sourceLayer === "public_reference"),
    ).toBe(true);
  });

  it("matches change-registration workflows with Mẫu 09 and Mẫu 18 references", () => {
    const references = getReferencesForProcedure({
      code: "2.000889",
      name: "Đăng ký biến động đất đai do chuyển nhượng, tặng cho, thừa kế",
    });
    const documentNumbers = references.map(candidate => candidate.documentNumber);

    expect(documentNumbers).toEqual(expect.arrayContaining(["Mẫu 09/ĐK", "Mẫu 18"]));
    expect(
      references
        .filter(candidate => candidate.kind === "reference_template")
        .every(candidate => candidate.sourceLayer === "public_reference"),
    ).toBe(true);
  });
});
