import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("OAuth callback resilience contract", () => {
  const source = readFileSync(resolve(process.cwd(), "server/_core/oauth.ts"), "utf8");

  it("retries transient upstream authentication failures", () => {
    expect(source).toContain("function isTransientOAuthError");
    expect(source).toContain('candidate.response?.status === 503');
    expect(source).toContain("async function withOAuthRetry");
    expect(source).toContain("attempt < 3");
    expect(source).toContain("withOAuthRetry(() => sdk.exchangeCodeForToken(code, state))");
    expect(source).toContain("withOAuthRetry(() => sdk.getUserInfo(tokenResponse.accessToken))");
  });

  it("redirects callback failures back to the app with an actionable state", () => {
    expect(source).toContain('"/?authError=oauth_unavailable"');
    expect(source).toContain('"/?authError=oauth_failed"');
    expect(source).not.toContain('res.status(500).json({ error: "OAuth callback failed" })');
  });
});
