import { afterEach, describe, expect, it } from "vitest";
import { getAppMode } from "@shared/const";

type WindowLike = { location: { hostname: string } };

const setHostname = (hostname: string) => {
  (globalThis as typeof globalThis & { window?: WindowLike }).window = {
    location: { hostname },
  };
};

afterEach(() => {
  delete (globalThis as typeof globalThis & { window?: WindowLike }).window;
});

describe("getAppMode", () => {
  it("exposes both storefront and CRM on the shared preview host", () => {
    setHostname("3000-preview.manus.computer");
    expect(getAppMode()).toBe("both");
  });

  it("keeps CRM-only routing on a crm subdomain", () => {
    setHostname("crm.batdongsanxanh.vn");
    expect(getAppMode()).toBe("crm");
  });

  it("keeps the public production domain storefront-only by default", () => {
    setHostname("batdongsan-7bupubgw.manus.space");
    expect(getAppMode()).toBe("storefront");
  });
});
