import { describe, expect, it } from "vitest";
import { getListingOcrFormValues } from "./ListingDocumentAutofill";

describe("getListingOcrFormValues", () => {
  it("maps listing fields and ignores empty or uncertain values", () => {
    const result = getListingOcrFormValues({
      title: "Đất nền ven sông",
      propertyType: "land",
      location: "Hòa Xuân, Đà Nẵng",
      province: "Đà Nẵng",
      area: "120",
      price: "3.5",
      buildArea: null,
      roadWidth: "7.5",
      bedrooms: null,
      bathrooms: null,
      orientation: "Đông Nam",
      legalStatus: "Có giấy chứng nhận",
      certificateType: "Sổ hồng",
      certificateArea: "120",
      landUsePurpose: "Đất ở tại đô thị",
      planningStatus: null,
      mortgageStatus: null,
      ownerName: "Nguyễn Văn A",
      ownerPhone: null,
      propertyCode: "BDX-001",
      description: "Mô tả từ ảnh",
      confidence: 86,
      notes: "Cần đối chiếu bản gốc",
    });

    expect(result).toMatchObject({ title: "Đất nền ven sông", propertyType: "land", area: "120", price: "3.5", certificateArea: "120" });
    expect(result).not.toHaveProperty("buildArea");
    expect(result).not.toHaveProperty("planningStatus");
    expect(result).not.toHaveProperty("ownerPhone");
  });
});
