# Nguồn DVC đất đai đã đối chiếu

Ngày kiểm tra: 2026-08-20.

| Nguồn | Dữ liệu xác nhận |
|---|---|
| https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8 | Danh mục lĩnh vực Đất đai của Hệ thống thông tin giải quyết TTHC Bộ Nông nghiệp và Môi trường; hiển thị mã 2.002317 Cung cấp thông tin, dữ liệu đất đai và mã 1.004278 Giải quyết tranh chấp đất đai thuộc thẩm quyền Bộ trưởng. |
| https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 | URL chi tiết chính thức cho mã 2.002317. |
| https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=69 | URL chi tiết chính thức cho mã 1.004278. |
| https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783 | Trang DVC Quốc gia cho cấp đổi Giấy chứng nhận. |
| https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784 | Trang DVC Quốc gia cho tách thửa/hợp thửa. |
| https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978 | Trang DVC Quốc gia cho đăng ký đất đai/cấp Giấy chứng nhận lần đầu. |
| https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013949 | Trang DVC Quốc gia cho giao đất, cho thuê đất, chuyển mục đích sử dụng đất. |
| https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410 | Trang DVC Quốc gia được kết quả tìm kiếm xác nhận cho thủ tục chuyển quyền sử dụng đất. |
| https://vukhcn.monre.gov.vn/thong-tin-tuyen-truyen/-danh-muc-thu-tuc-hanh-chinh-trong-linh-vuc-nong-nghiep-va-moi-truong/tt-7996 | Kết quả tìm kiếm xác nhận danh mục lĩnh vực Nông nghiệp và Môi trường có 66 TTHC lĩnh vực Đất đai; trang không trích xuất được nội dung đầy đủ nên chưa dùng để tự bịa thêm mã. |

Ghi chú: URL và metadata được dùng làm nguồn discovery; file DOCX/PDF chỉ được đưa sang verified_binary sau khi tải được binary thật, kiểm tra chữ ký, SHA-256 và lưu S3. Không tự gắn Official nếu binary không vượt cổng xác minh.

## Bổ sung nguồn danh mục tìm thấy ngày 2026-08-20

- Bộ Nông nghiệp và Môi trường: https://vukhcn.monre.gov.vn/thong-tin-tuyen-truyen/-danh-muc-thu-tuc-hanh-chinh-trong-linh-vuc-nong-nghiep-va-moi-truong/tt-7996 — kết quả công khai nêu lĩnh vực Đất đai có 66 thủ tục hành chính; cần đọc và đối chiếu danh sách chi tiết trước khi nhập mã.
- Cổng DVC Bộ: https://dichvucong.monre.gov.vn/Pages/dichvucong.aspx — trang tra cứu dịch vụ công chính thức.
- Dịch vụ “Cung cấp thông tin, dữ liệu đất đai”: https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67 — nguồn chính thức của Bộ để đối chiếu mã 2.002317.
- Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783 — cấp đổi Giấy chứng nhận.
- Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978 — đăng ký đất đai/cấp Giấy chứng nhận lần đầu.
- Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013949 — giao đất, cho thuê đất, chuyển mục đích sử dụng đất.

Ghi chú: kết quả tìm kiếm xác nhận nguồn và con số 66, nhưng chưa đủ dữ liệu mã để tuyên bố đã đồng bộ toàn bộ. Cần đọc trang MONRE/DVC chính thức, trích mã và URL từng thủ tục, sau đó chạy batchDiscover theo từng mã; không dùng nguồn thương mại làm nguồn chuẩn.

## Tra cứu MONRE/Bộ và nguồn pháp lý — 20/08/2026

- Trang DVC Bộ Nông nghiệp và Môi trường/MONRE: https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8. Trang xác nhận lĩnh vực Đất đai và hiện hiển thị mã 2.002317 “Cung cấp thông tin, dữ liệu đất đai” cùng mã 1.004278 “Giải quyết tranh chấp đất đai thuộc thẩm quyền của Bộ trưởng Bộ Tài nguyên và Môi trường”. Kết quả đọc được là danh mục thủ tục; chưa thấy URL DOC/DOCX/PDF mẫu trực tiếp trong phần danh mục.
- Trang MONRE về danh mục thủ tục: https://vukhcn.monre.gov.vn/thong-tin-tuyen-truyen/-danh-muc-thu-tuc-hanh-chinh-trong-linh-vuc-nong-nghiep-va-moi-truong/tt-7996. Web extraction hiện không trả nội dung, chưa dùng làm bằng chứng file mẫu.
- Nghị định 151/2025/NĐ-CP trên Cổng thông tin điện tử Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=213927. Trang chính thức xác nhận văn bản và cung cấp binary pháp lý https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/6/151-ndcp.signed.pdf. Đây là văn bản pháp lý, không mặc định là file mẫu hồ sơ của thủ tục 1.012789.

Kết luận tạm thời: các nguồn Bộ/MONRE đã xác nhận được danh mục và nguồn pháp lý; chưa tìm thấy trên trang danh mục một URL file mẫu DOC/DOCX/PDF thay thế cho endpoint động của DVC Quốc gia. Không gắn Official Template File dựa riêng trên tên mẫu hoặc nghị định.

## Tra cứu nghị định đất đai — 20/08/2026

| Văn bản | Nguồn chính thức | Kết quả tra cứu ban đầu |
|---|---|---|
| Nghị định 101/2024/NĐ-CP | https://vanban.chinhphu.vn/?pageid=27160&docid=210791 | Trang văn bản Chính phủ; nội dung về điều tra cơ bản đất đai, đăng ký và cấp Giấy chứng nhận. Cần kiểm tra tệp đính kèm thực tế. |
| Nghị định 102/2024/NĐ-CP | https://vanban.chinhphu.vn/?pageid=27160&docid=210795 | Trang văn bản Chính phủ; quy định chi tiết thi hành Luật Đất đai, ban hành 30/07/2024, hiệu lực 01/08/2024. Cần kiểm tra tệp đính kèm thực tế. |
| Nghị định 151/2025/NĐ-CP | https://vanban.chinhphu.vn/?pageid=27160&docid=213927 | Trang văn bản Chính phủ; phân định thẩm quyền, phân quyền và phân cấp trong lĩnh vực đất đai. Cần kiểm tra tệp đính kèm thực tế. |
| Danh mục lĩnh vực đất đai của DVC Bộ | https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8 | Nguồn danh mục thủ tục; không mặc nhiên là nguồn binary mẫu của từng thủ tục. |
| Trang MONRE công bố danh mục TTHC | https://vukhcn.monre.gov.vn/thong-tin-tuyen-truyen/-danh-muc-thu-tuc-hanh-chinh-trong-linh-vuc-nong-nghiep-va-moi-truong/tt-7996 | Nguồn công bố danh mục; cần phân biệt với URL tải PDF/DOC cụ thể. |

Ghi chú: kết quả tìm kiếm cũng phát hiện Nghị định 49/2026/NĐ-CP và Văn bản hợp nhất 46/VBHN-BNNMT là nguồn mới liên quan Luật Đất đai, nhưng chưa đưa vào registry cho đến khi kiểm tra trực tiếp trang và tệp đính kèm. Nghị định 96/2019 và 103/2024 cần tra cứu theo đúng số hiệu đầy đủ vì số hiệu trùng nhiều văn bản không thuộc đất đai.

## URL tải PDF đã xác nhận từ trang Chính phủ

- **Nghị định 101/2024/NĐ-CP**: trang chính thức https://vanban.chinhphu.vn/?pageid=27160&docid=210791 ; tệp đính kèm `101-nd.signed.pdf`: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf
- **Nghị định 102/2024/NĐ-CP**: trang chính thức https://vanban.chinhphu.vn/?pageid=27160&docid=210795 ; tệp `102-cp.signed.pdf`: https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/10/102-cp.signed.pdf ; phụ lục `pl.pdf`: https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/10/pl.pdf
- **Nghị định 151/2025/NĐ-CP**: trang chính thức https://vanban.chinhphu.vn/?pageid=27160&docid=213927 ; tệp `151-ndcp.signed.pdf`: https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/6/151-ndcp.signed.pdf

Các URL trên là liên kết `Tài liệu đính kèm` được trích trực tiếp từ trang văn bản Chính phủ, khác với URL mẫu DOCX của Cổng Dịch vụ công. Cần tải byte và tính SHA-256 trước khi đưa trạng thái `verified_legal_document` vào kho pháp lý.

## Bổ sung kết quả kiểm tra trang Chính phủ

| Văn bản | Nội dung xác nhận | URL file chính thức |
|---|---|---|
| Nghị định 96/2024/NĐ-CP | Luật Kinh doanh bất động sản; có PDF đính kèm trên trang Chính phủ | https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/8/96-nd.signed.pdf |
| Nghị định 103/2024/NĐ-CP | Tiền sử dụng đất, tiền thuê đất; có PDF đính kèm trên trang Chính phủ | https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/8/103-nd.signed.pdf |
| Nghị định 101/2024/NĐ-CP | Điều tra cơ bản đất đai, đăng ký/cấp GCN và hệ thống thông tin đất đai; có PDF đính kèm | https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf |
| Nghị định 102/2024/NĐ-CP | Quy định chi tiết Luật Đất đai; có PDF chính và phụ lục đính kèm | https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/10/102-cp.signed.pdf ; https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/10/pl.pdf |

Nguồn trang văn bản: https://vanban.chinhphu.vn/?pageid=27160&docid=210798&classid=1 (96), https://vanban.chinhphu.vn/?pageid=27160&docid=210797 (103), https://vanban.chinhphu.vn/?pageid=27160&docid=210791 (101), https://vanban.chinhphu.vn/?pageid=27160&docid=210795 (102). Nghị định 96/2024/NĐ-CP liên quan kinh doanh bất động sản, không phải nghị định thi hành Luật Đất đai trực tiếp; cần phân loại riêng trong kho pháp lý.

## Kết quả tải binary ngày 2026-08-20

| Văn bản | HTTP/MIME | Kích thước | SHA-256 | Storage |
|---|---|---:|---|---|
| Nghị định 101/2024/NĐ-CP | 200 / PDF 1.4 | 5,546,344 bytes | `dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e` | `/manus-storage/101_0eeb309b.pdf` |
| Nghị định 102/2024/NĐ-CP | 200 / PDF 1.4 | 6,834,421 bytes | `664987299fe49b7641cd5c1bc62f0803ce4f346535008e83f26ba1e0bd4deaaa` | `/manus-storage/102_9b8d6241.pdf` |
| Phụ lục Nghị định 102/2024/NĐ-CP | 200 / PDF 1.4 | 1,448,182 bytes | `2b7d71311fc85b9e3cb36e2ce1dcba6c212bb50fce83a492e5ffd413e952d77c` | `/manus-storage/102-pl_0060b348.pdf` |
| Nghị định 96/2024/NĐ-CP | 200 / PDF 1.4 | 13,809,926 bytes | `c46e3d8dfd1c96a9900d741453f89df92ffc242f79b4ceb2680744319ebbd98d` | `/manus-storage/96_c76302f7.pdf` |
| Nghị định 103/2024/NĐ-CP | 200 / PDF 1.4 | 5,028,692 bytes | `01db4fbbed2e8d593947fa959b687bc70c2e2012c525ad6fb104f62d7f352a55` | `/manus-storage/103_02d486c4.pdf` |

Kết luận: năm file tải thành công từ `datafiles.chinhphu.vn`, có HTTP 200, đúng MIME PDF và đã lưu storage. Đây là văn bản pháp lý Official đã xác minh nguồn; chúng không tự động biến thành mẫu đơn của từng thành phần hồ sơ.

| Nghị định 151/2025/NĐ-CP | 200 / PDF 1.4 | 8,434,610 bytes | `fc534e89997b61b6c8c1538824063c1b2e42c1d2b1da1acdde5aa62eaf1fec52` | `/manus-storage/151_c391f2c8.pdf` |

URL trang Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=213927
URL PDF: https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/6/151-ndcp.signed.pdf

## Văn bản đất đai bổ sung đã rà soát và tải được

- Nghị định 101/2024/NĐ-CP: nguồn https://vanban.chinhphu.vn/?pageid=27160&docid=210791; PDF chính thức https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf; HTTP 200, PDF 1.4, 5,546,344 bytes, SHA-256 `dc5764aa9ce1332e044be3b41b74eeb4f5b831af72deb740e8f9975dad96592e`, storage `/manus-storage/101_0eeb309b.pdf`.
- Nghị định 102/2024/NĐ-CP: nguồn https://vanban.chinhphu.vn/?pageid=27160&docid=210795; PDF chính thức https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/10/102-cp.signed.pdf; HTTP 200, PDF 1.4, 6,834,421 bytes, SHA-256 `664987299fe49b7641cd5c1bc62f0803ce4f346535008e83f26ba1e0bd4deaaa`, storage `/manus-storage/102_9b8d6241.pdf`; phụ lục HTTP 200, 1,448,182 bytes, SHA-256 `2b7d71311fc85b9e3cb36e2ce1dcba6c212bb50fce83a492e5ffd413e952d77c`, storage `/manus-storage/102-pl_0060b348.pdf`.
- Nghị định 96/2024/NĐ-CP: nguồn https://vanban.chinhphu.vn/?pageid=27160&docid=210798&classid=1; PDF https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/8/96-nd.signed.pdf; HTTP 200, PDF 1.4, 13,809,926 bytes, SHA-256 `c46e3d8dfd1c96a9900d741453f89df92ffc242f79b4ceb2680744319ebbd98d`, storage `/manus-storage/96_c76302f7.pdf`. Phân loại: kinh doanh bất động sản, liên quan nhưng không phải nghị định thi hành Luật Đất đai trực tiếp.
- Nghị định 103/2024/NĐ-CP: nguồn https://vanban.chinhphu.vn/?pageid=27160&docid=210797; PDF https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/8/103-nd.signed.pdf; HTTP 200, PDF 1.4, 5,028,692 bytes, SHA-256 `01db4fbbed2e8d593947fa959b687bc70c2e2012c525ad6fb104f62d7f352a55`, storage `/manus-storage/103_02d486c4.pdf`.
- Nghị định 151/2025/NĐ-CP: nguồn https://vanban.chinhphu.vn/?pageid=27160&docid=213927; PDF https://datafiles.chinhphu.vn/cpp/files/vbpq/2025/6/151-ndcp.signed.pdf; HTTP 200, PDF 1.4, 8,434,610 bytes, SHA-256 `fc534e89997b61b6c8c1538824063c1b2e42c1d2b1da1acdde5aa62eaf1fec52`, storage `/manus-storage/151_c391f2c8.pdf`.

Kết luận: cả 5 văn bản và phụ lục 102 đã tải thành công từ `datafiles.chinhphu.vn`, có binary và checksum. Đây là văn bản pháp lý Official đã xác minh nguồn; không tự coi chúng là file mẫu DOCX/PDF của thành phần hồ sơ thủ tục.

## Bổ sung rà soát văn bản Chính phủ
- Nghị định 71/2024/NĐ-CP — Quy định về giá đất. Trang chính thức: https://vanban.chinhphu.vn/?pageid=27160&docid=210523. File đính kèm chính thức: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/71-cp.signed.pdf
- Nghị định 101/2024/NĐ-CP — Điều tra cơ bản đất đai; đăng ký, cấp Giấy chứng nhận và Hệ thống thông tin đất đai. Trang: https://vanban.chinhphu.vn/?pageid=27160&docid=210791. File: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf
- Nghị định 96/2024/NĐ-CP — Quy định chi tiết một số điều của Luật Kinh doanh bất động sản; có liên quan đến BĐS nhưng không phải nghị định đất đai trực tiếp. Trang: https://vanban.chinhphu.vn/?pageid=27160&docid=210798. File: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/8/96-nd.signed.pdf
- Nghị định 117/2024/NĐ-CP — Văn bản xử phạt trong các lĩnh vực tư pháp, không phải nguồn đất đai trực tiếp; không đưa vào nhóm cốt lõi đất đai. Trang: https://vanban.chinhphu.vn/?pageid=27160&docid=211238. File: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/9/117-cp.signed.pdf
- Ghi chú: chỉ đánh dấu văn bản pháp lý Official khi trang chính thức và file tải được xác minh độc lập; không đồng nhất PDF nghị định với file mẫu DOC/DOCX của thành phần hồ sơ.

## Kết quả tải bổ sung ngày 2026-08-20
| Văn bản | MIME | Kích thước | SHA-256 | Storage |
|---|---:|---:|---|---|
| Nghị định 71/2024/NĐ-CP | application/pdf | 3,157,878 bytes | `f4156152dde6a111b00a9d7bddc7877c5a389f0df965f2c3ae6d1757e50ddb11` | `/manus-storage/71-2024-ND-CP_c0fdb61e.pdf` |
| Nghị định 117/2024/NĐ-CP | application/pdf | 1,530,956 bytes | `140b36efa22a71bfb6e459d825279b99b7a776b7d861108e0a18e6b02bbc32fb` | `/manus-storage/117-2024-ND-CP_3596f300.pdf` |

Nguồn tải: Cổng Thông tin điện tử Chính phủ tại các URL `datafiles.chinhphu.vn` đã lưu ở phần nguồn văn bản. Nghị định 71/2024 được giữ trong nhóm đất đai cốt lõi; Nghị định 117/2024 chỉ giữ tham chiếu nếu thủ tục cần, không xếp nhầm vào văn bản đất đai trực tiếp.

## Ghi nhận rà soát nguồn thay thế — 2026-08-20

Search đã xác nhận các trang văn bản chính thức của Cổng Thông tin điện tử Chính phủ gồm Nghị định 151/2025/NĐ-CP tại https://vanban.chinhphu.vn/?pageid=27160&docid=213927 và Nghị định 102/2024/NĐ-CP tại https://vanban.chinhphu.vn/?pageid=27160&docid=210795. Các URL này là nguồn văn bản pháp lý, không mặc nhiên là nguồn file mẫu thủ tục. Pipeline fallback chỉ được phép dùng file DOC/DOCX/PDF nếu liên kết nằm trên miền được allowlist, tên/mã file khớp thành phần/mẫu và binary vượt qua kiểm tra định dạng, checksum và provenance.

Kết quả rà soát hiện chưa cung cấp bằng chứng rằng các trang kết quả trên có file mẫu thủ tục thay thế trực tiếp cho Mus14.docx; do đó không được gắn Official Template chỉ dựa trên việc tìm thấy nghị định. File mẫu DVC vẫn phải được xác minh từ byte nguồn chính thức hoặc một bản thay thế chính thức khớp chính xác.

## Nguồn mẫu 14 và thủ tục 1.012789 — rà soát bổ sung

Nguồn chính thức Cổng Thông tin điện tử Chính phủ: https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-cung-cap-thong-tin-du-lieu-dat-dai-119250805161025964.htm. Bài viết xác nhận thủ tục cung cấp thông tin, dữ liệu đất đai theo Quyết định 2304/QĐ-BNNMT ngày 23/6/2025; thành phần hồ sơ là Phiếu yêu cầu theo các Mẫu 14, 14a, 14b, 14c, 14d, 14đ; căn cứ gồm Luật Đất đai 31/2024/QH15, Nghị định 101/2024/NĐ-CP, Nghị định 118/2025/NĐ-CP và Nghị định 151/2025/NĐ-CP. Bài viết cũng nêu cơ quan tiếp nhận/thực hiện là Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai/Chi nhánh hoặc UBND cấp xã theo phân cấp.

Nguồn file DOCX chính thức cấp địa phương được search phát hiện: https://sxd.danang.gov.vn/documents/20121/43428/M%E1%BA%ABu%2014%20-%20Phi%E1%BA%BFu%20y%C3%AAu%20c%E1%BA%A7u%20cung%20c%E1%BA%A5p%20th%C3%B4ng%20tin,d%E1%BB%AF%20li%E1%BB%87u%20%C4%91%E1%BA%A5t%20%C4%91ai.docx. Browser extraction đọc được tiêu đề “Mẫu số 14. Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai”, nội dung phù hợp thủ tục 1.012789 và ghi cơ quan nhận là Văn phòng đăng ký đất đai thành phố Đà Nẵng. Curl từ sandbox gặp lỗi TLS/SSL khi tải byte, nên chưa được gắn verified_binary/Official; cần retry bằng browser/session hoặc nguồn mirror chính thức khác trước khi lưu S3.

Nguồn Cổng Chính phủ có file DOCX trực tiếp cho Mẫu 04/ĐK, không phải Mẫu 14: https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkydatdai-17225027906701732310327.docx, được liên kết từ bài https://xaydungchinhsach.chinhphu.vn/mau-don-dang-ky-dat-dai-tai-san-gan-lien-voi-dat-119240801160735957.htm. File này chỉ được map cho thủ tục đăng ký đất đai phù hợp, không được gán cho thủ tục 1.012789.

## Kiểm tra lại DVC 1.012789 — 2026-08-20
Trang DVC Quốc gia mở được và hiển thị thủ tục “Cung cấp thông tin, dữ liệu đất đai”, mã 1.012789. Nội dung xác nhận quy trình 5 bước; hồ sơ có thể nộp tại Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh Văn phòng đăng ký đất đai. Trang chi tiết liên kết tới bản thủ tục nội bộ mã 348167. Trang HTML mở được không đồng nghĩa endpoint binary luôn trả byte; file mẫu vẫn phải kiểm tra response, MIME và SHA-256 độc lập trước khi gắn Official.

## Multi-source discovery Mus14/Mẫu 14 — 2026-08-20
Từ tìm kiếm web công khai, ứng viên `https://cdn.thuvienphapluat.vn/uploads/khoinghiep/2025/06/27/mau-so-14.doc` tải được qua trình duyệt về `/home/ubuntu/Downloads/mau-so-14.doc`. Metadata: Composite Document File V2, 41,472 bytes, SHA-256 `308c0deaa8bf45faef1b6a98175155fc3ee392b0d22fab9f6f76c8c966b5a00d`. Checksum trùng tệp `mau-so-14.doc` người dùng đã cung cấp trước đó. Đây là bằng chứng file khớp về byte với bản tham chiếu, nhưng miền tải là nguồn tư liệu ngoài cơ quan nhà nước; vì vậy chỉ ghi là `reference_candidate`, không gắn `Official Template`. Cần tiếp tục đối chiếu với phụ lục chính thức của Nghị định 151/2025/NĐ-CP hoặc URL cơ quan nhà nước trước khi cấp Official.

## Multi-source MFS14/Mẫu 14 — 2026-08-20

Cổng Chính sách của Chính phủ xác nhận thủ tục cung cấp thông tin, dữ liệu đất đai sử dụng Phiếu yêu cầu theo các Mẫu số 14, 14a, 14b, 14c, 14d và 14đ; Mẫu số 14 bao gồm thông tin người yêu cầu, thửa đất/dữ liệu cần cung cấp, hình thức nhận kết quả và cam kết sử dụng dữ liệu. Nguồn: https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-cung-cap-thong-tin-du-lieu-dat-dai-119250805161025964.htm

Các ứng viên công khai đã tải được để đối chiếu, nhưng chưa gắn Official vì không phải miền cơ quan nhà nước:

| File | URL | HTTP | MIME | Bytes | SHA-256 | Phân loại |
|---|---|---:|---|---:|---|---|
| mau-so-14-thuvienphapluat.doc | https://cdn.thuvienphapluat.vn/uploads/khoinghiep/2025/06/27/mau-so-14.doc | 200 | application/msword | 41472 | 308c0deaa8bf45faef1b6a98175155fc3ee392b0d22fab9f6f76c8c966b5a00d | reference_only; nội dung khớp Mẫu số 14 |
| ms-14-nd-151-thuviennhadat.docx | https://cdn.thuviennhadat.vn/upload/hinh-anh-bai-viet/TTTP/Thang-6-2025/MS-14-nd-151.docx | 200 | application/vnd.openxmlformats-officedocument.wordprocessingml.document | 33279 | 2d72db15edfc0f4bcf868e553febc92059f2831b5212d1ebdf588621c9e9a571 | reference_only; cần đối chiếu nội dung trước khi ghép |

Các file tạm được lưu tại `/home/ubuntu/webdev-static-assets/official-candidates/`. Chỉ file đúng mẫu mới được ghép dưới `matched_reference/ready_reference`; không được cấp Official chỉ dựa trên kết quả tìm kiếm web.

## Search results MFS14/Mẫu 14 — bổ sung

Search engine returned these candidates:

- https://cdn.thuvienphapluat.vn/uploads/khoinghiep/2025/06/27/mau-so-14.doc — DOC candidate; snippet says “Mẫu số 14. cấp thông tin, dữ liệu đất đai”. Non-government domain; reference_only.
- https://cdn.thuviennhadat.vn/upload/hinh-anh-bai-viet/TTTP/Thang-6-2025/MS-14-nd-151.docx — DOCX candidate; snippet references Mẫu 14 and variants 14c/14đ. Non-government domain; must content-match; reference_only.
- https://xaydungchinhsach.chinhphu.vn/quy-dinh-thu-tuc-cung-cap-thong-tin-du-lieu-dat-dai-119250805161025964.htm — official Government article confirming the procedure accepts Mẫu 14, 14a, 14b, 14c, 14d, 14đ under Nghị định 151/2025/NĐ-CP.
- https://vanban.chinhphu.vn/?pageid=27160&docid=213927 — official Government legal-document page for Nghị định 151/2025/NĐ-CP; legal provenance, not automatically a template binary.
- https://thuvienphapluat.vn/phap-luat/ho-tro-phap-luat/mau-so-14-phieu-yeu-cau-cung-cap-thong-tin-du-lieu-dat-dai-2025-va-cac-mau-lien-quan-theo-nghi-dinh-248941-226925.html — non-government explanatory page; reference_only.
- https://thuviennhadat.vn/bat-dong-san/tai-mau-so-14-mau-phieu-cung-cap-thong-tin-du-lieu-dat-dai-theo-nghi-dinh-151-trinh-tu-thu-tuc-cung-20852.html — non-government explanatory/download page; reference_only.
- https://hoatieu.vn/bieu-mau/mau-01-pyc-mau-phieu-yeu-cau-cung-cap-du-lieu-dat-dai-214341 — non-government explanatory page; reference_only.

The official Government source confirms the legal form family; only binary files downloaded from an eligible government source can receive Official Template status. Search candidates can be matched and assembled as ready_reference.
