export const COOKIE_NAME = "app_session_id";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
export const AXIOS_TIMEOUT_MS = 30_000;
export const UNAUTHED_ERR_MSG = 'Please login (10001)';
export const NOT_ADMIN_ERR_MSG = 'You do not have required permission (10002)';

export type AppMode = "storefront" | "crm" | "both";

export const getAppMode = (): AppMode => {
  if (typeof window === "undefined") return "both"; // Server-side default
  
  // Detection via env or hostname
  const envMode = (import.meta as any).env?.VITE_APP_MODE;
  if (envMode === "storefront" || envMode === "crm" || envMode === "both") return envMode;

  const host = window.location.hostname;
  if (host.startsWith("crm.")) return "crm";
  if (host.includes("quanly")) return "crm";
  // Shared preview and local development expose both surfaces until
  // dedicated subdomains are configured. The production storefront remains
  // public-only by default.
  if (host === "localhost" || host === "127.0.0.1" || host.endsWith(".manus.computer")) return "both";

  return "storefront";
};

// One-time nonce cookie that binds an OAuth login to the browser that started
// it. The `__Host-` prefix forces the cookie host-only (Secure, Path=/, no
// Domain), so a sibling *.manus.space site cannot plant a matching value in a
// victim's browser.
export const OAUTH_STATE_COOKIE = "__Host-oauth_state";

// `state` carries the callback redirect URI (used at token exchange) plus the
// CSRF nonce. Defined here so the client encoder and server decoder never drift.
export type OAuthState = { redirectUri: string; nonce?: string };

export const encodeOAuthState = (state: OAuthState): string =>
  btoa(JSON.stringify(state));

export const decodeOAuthState = (state: string): OAuthState => {
  let decoded: string;
  try {
    decoded = atob(state);
  } catch {
    // Malformed base64 (e.g. attacker-supplied garbage). Return no nonce so the
    // callback's CSRF guard rejects it with 403 — never throw, since the caller
    // runs outside the request handler's try/catch.
    return { redirectUri: "" };
  }
  try {
    const parsed = JSON.parse(decoded);
    if (parsed && typeof parsed.redirectUri === "string") return parsed;
  } catch {
    // Legacy links: `state` was a bare base64(redirectUri) with no nonce.
  }
  return { redirectUri: decoded };
};
