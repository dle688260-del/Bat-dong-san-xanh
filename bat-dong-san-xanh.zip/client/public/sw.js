const CACHE_NAME = "bdsxanh-shell-v3";
const APP_SHELL = [
  "/",
  "/manifest.webmanifest",
  "/crm",
  "/crm/login",
  "/crm-manifest.webmanifest",
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then(async response => {
          if (response.ok) return response;
          const path = new URL(request.url).pathname.replace(/\/+$/, "") || "/";
          const fallback = path === "/crm" || path.startsWith("/crm/") ? "/crm" : "/";
          return (await caches.match(fallback)) || response;
        })
        .catch(async () => {
          const path = new URL(request.url).pathname.replace(/\/+$/, "") || "/";
          const fallback = path === "/crm" || path.startsWith("/crm/") ? "/crm" : "/";
          return (await caches.match(fallback)) || caches.match("/");
        })
    );
  }
});

self.addEventListener("message", event => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});
