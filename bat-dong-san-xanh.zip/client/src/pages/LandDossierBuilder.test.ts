import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { LAND_DOSSIER_OFFICIAL_SOURCES, LAND_DOSSIER_TEMPLATE_REGISTRY, PUBLIC_POST_CHANNELS, buildPublicPostText, landDossierBuilderBundle, landDossierBuilderFindProcedures, landDossierBuilderGuidance, landDossierBuilderLocalSource, landDossierBuilderPipelinePlan, landDossierBuilderProcedureTitles, landDossierBuilderTemplates, landDossierProcedureSyncSnapshot, landDossierNextProcedureRecommendations, landDossierRecommendationDocuments, landDossierBinarySearchKeywords, landBundleStatusLabel } from "./LandDossierBuilder";
import { auditLandDossierLegalSources } from "@/lib/legalSourceAudit";

describe("standalone land dossier builder", () => {
  it("reports loading, timeout, error and loaded bundle states without indefinite fallback", () => {
    expect(landBundleStatusLabel({ isLoading: true, timedOut: false, hasError: false, hasData: false })).toBe("Đang nạp bundle pháp lý…");
    expect(landBundleStatusLabel({ isLoading: true, timedOut: true, hasError: false, hasData: false })).toContain("Bundle đang chậm");
    expect(landBundleStatusLabel({ isLoading: false, timedOut: true, hasError: true, hasData: false })).toContain("có thể thử lại");
    expect(landBundleStatusLabel({ isLoading: false, timedOut: false, hasError: false, hasData: true })).toBe("Bundle pháp lý đã nạp");
    expect(landBundleStatusLabel({ isLoading: false, timedOut: false, hasError: false, hasData: true, hasMetadata: true, hasOfficialBinary: false })).toBe("Metadata đã nạp · chưa có Official binary");
    expect(landBundleStatusLabel({ isLoading: false, timedOut: false, hasError: false, hasData: true, hasMetadata: true, hasOfficialBinary: true })).toBe("Official binary verified");
    expect(landBundleStatusLabel({ isLoading: false, timedOut: false, hasError: true, hasData: false, hasMetadata: true })).toContain("Metadata đã nạp");
  });
  it("treats a survey bundle with components and metadata but no binary as loaded metadata", () => {
    expect(landBundleStatusLabel({
      isLoading: false,
      timedOut: false,
      hasError: false,
      hasData: false,
      hasMetadata: true,
      hasOfficialBinary: false,
    })).toBe("Metadata đã nạp · chưa có Official binary");
  });

  it("keeps a broad land procedure catalog separate from existing dossier hubs", () => {
    expect(landDossierBuilderProcedureTitles()).toContain("Đăng ký biến động đất đai");
    expect(landDossierBuilderProcedureTitles()).toContain("Tách thửa");
    expect(landDossierBuilderProcedureTitles().length).toBeGreaterThanOrEqual(9);
  });

  it("finds related procedures from natural language instead of exact title only", () => {
    expect(landDossierBuilderFindProcedures("sang tên khi mua bán nhà").map(([id]) => id)).toEqual(expect.arrayContaining(["sale-house", "transfer"]));
    expect(landDossierBuilderFindProcedures("cho thuê đất").map(([id]) => id)).toContain("lease");
    expect(landDossierBuilderFindProcedures("xin trích lục thông tin đất đai").map(([id]) => id)).toContain("data-request");
    expect(landDossierBuilderFindProcedures("xin trích lục bản đồ địa chính").map(([id]) => id)).toContain("data-request");
  });

  it("refreshes procedure-specific templates, checklist and legal query when the procedure changes", () => {
    const transfer = landDossierProcedureSyncSnapshot("transfer", "Đà Nẵng");
    const merge = landDossierProcedureSyncSnapshot("merge", "Đà Nẵng");
    expect(transfer.procedureTitle).toContain("Chuyển nhượng");
    expect(transfer.bundle.map(item => item.label)).toContain("Tờ khai thuế thu nhập cá nhân");
    expect(transfer.query).toContain("Chuyển nhượng");
    expect(merge.procedureTitle).toContain("Hợp thửa");
    expect(merge.bundle.map(item => item.label)).toContain("Đơn đề nghị hợp thửa");
    expect(merge.bundle.map(item => item.label)).not.toContain("Tờ khai thuế thu nhập cá nhân");
    expect(merge.query).toContain("Hợp thửa");
    expect(merge.templates.map(item => item.id)).not.toContain("m09-dk-transfer");
  });

  it("creates non-empty binary search keywords when the user leaves keywords blank", () => {
    const automatic = landDossierBinarySearchKeywords("transfer", "");
    expect(automatic.length).toBeGreaterThan(0);
    expect(automatic).toContain("Chuyển nhượng quyền sử dụng đất");
    expect(landDossierBinarySearchKeywords("transfer", "09/ĐK, đơn")).toEqual(["09/ĐK", "đơn"]);
  });

  it("suggests sourced next procedures and documents after a completed transfer", () => {
    const recommendations = landDossierNextProcedureRecommendations("transfer");
    const inheritance = recommendations.find(item => item.procedureId === "inheritance");
    expect(inheritance?.confidence).toBe("Cao");
    expect(inheritance?.legalSources.some(source => source.url.includes("chinhphu.vn"))).toBe(true);
    expect(landDossierRecommendationDocuments("inheritance")[0]?.status).toContain("cần rà soát");
    expect(recommendations.map(item => item.procedureId)).toEqual(expect.arrayContaining(["inheritance", "variation"]));
  });

  it("builds a combined transfer dossier with the land form and conditional tax/fee documents", () => {
    const bundle = landDossierBuilderBundle("transfer");
    expect(bundle.map(item => item.label)).toEqual(expect.arrayContaining([
      "Mẫu 09/ĐK — Đơn đăng ký biến động do chuyển nhượng",
      "Tờ khai thuế thu nhập cá nhân",
      "Tờ khai lệ phí trước bạ",
    ]));
    expect(bundle.find(item => item.id === "pit-declaration")?.required).toBe(false);
    expect(bundle.find(item => item.id === "registration-fee-declaration")?.condition).toContain("phát sinh");
  });

  it("exposes bundles for additional land procedures", () => {
    expect(landDossierBuilderBundle("lease").map(item => item.label)).toEqual(expect.arrayContaining(["Hợp đồng cho thuê/cho thuê lại đất", "Hồ sơ đăng ký biến động do cho thuê/cho thuê lại"]));
    expect(landDossierBuilderBundle("sale-house").map(item => item.label)).toEqual(expect.arrayContaining(["Hợp đồng mua bán/chuyển nhượng nhà, đất", "Đơn đăng ký biến động/sang tên"]));
  });

  it("builds public post copy and exposes website plus personal social channels", () => {
    expect(PUBLIC_POST_CHANNELS.map(([, label]) => label)).toEqual(["Website", "Facebook cá nhân", "Zalo cá nhân"]);
    expect(buildPublicPostText({ landAddress: "Thanh Khê, Đà Nẵng", area: "200", transferPrice: "2,8 tỷ", landUse: "Đất ở" }, "Gần trường học")).toContain("Diện tích: 200 m²");
    expect(buildPublicPostText({ landAddress: "Thanh Khê, Đà Nẵng", area: "200", transferPrice: "2,8 tỷ", landUse: "Đất ở" }, "Gần trường học")).toContain("Gần trường học");
  });

  it("renders the transfer input and export document set", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("Họ tên bên chuyển nhượng");
    expect(source).toContain("Số Giấy chứng nhận");
    expect(source).toContain("Hợp đồng chuyển nhượng quyền sử dụng đất");
    expect(source).toContain("Đơn đăng ký biến động/sang tên");
    expect(source).toContain("Tờ khai lệ phí trước bạ");
    expect(source).toContain("LandExportDocumentType");
    expect(source).toContain("lease-contract");
    expect(source).toContain("purpose-application");
  });

  it("marks all current templates as metadata-only until verified binaries are integrated", () => {
    const templates = Object.values(LAND_DOSSIER_TEMPLATE_REGISTRY).flat();
    expect(templates.length).toBeGreaterThan(0);
    expect(templates.every(template => template.provenance === "metadata-only")).toBe(true);
    expect(templates.some(template => template.provenance === "verified-binary")).toBe(false);
  });

  it("plans the end-to-end pipeline and blocks Official autofill without verified binaries", () => {
    const plan = landDossierBuilderPipelinePlan("transfer", "Đà Nẵng");
    expect(plan.selectedProcedure).toContain("Chuyển nhượng");
    expect(plan.status).toBe("needs-review");
    expect(plan.autoFillEnabled).toBe(false);
    expect(plan.items.some(item => item.label.includes("Mẫu 09/ĐK"))).toBe(true);
    expect(plan.items.filter(item => item.category === "form").every(item => item.status !== "verified-binary")).toBe(true);
  });

  it("requires province context before marking the pipeline reviewable", () => {
    const plan = landDossierBuilderPipelinePlan("transfer", "");
    expect(plan.missingLocalContext).toBe(true);
    expect(plan.status).toBe("needs-review");
    expect(plan.autoFillEnabled).toBe(false);
  });

  it("keeps the end-to-end and print actions visible in the builder", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("AI Land Dossier Pipeline");
    expect(source).toContain("AI lập bộ hồ sơ end-to-end");
    expect(source).toContain("In hồ sơ đã xác nhận");
    expect(source).toContain("land-dossier-pipeline");
    expect(source).toContain("dossier-workflow-steps");
    expect(source).toContain("mergeConfirmedOcrIntoInput");
    expect(source).toContain("legal-source-audit");
    expect(source).toContain("Kiểm toán nguồn pháp lý");
  });

  it("keeps a mobile-safe direct download fallback for generated files", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("readyDownload");
    expect(source).toContain("download={readyDownload.fileName}");
    expect(source).toContain("URL.createObjectURL(blob)");
    expect(source).toContain("Không tạo được file");
    expect(source).toContain("Không tạo được file ZIP");
  });

  it("keeps official references separate from Official binary templates", () => {
    expect(LAND_DOSSIER_OFFICIAL_SOURCES["variation-2.000889"].procedureCode).toBe("2.000889");
    expect(LAND_DOSSIER_OFFICIAL_SOURCES["variation-2.000889"].sourceName).toBe("Cổng Dịch vụ công Quốc gia");
    expect(LAND_DOSSIER_OFFICIAL_SOURCES["government-decree-151"].status).toBe("verified-reference");
    expect(landDossierBuilderTemplates("purpose-change")[0]?.provenance).toBe("metadata-only");
  });

  it("keeps the three Official states independent for procedure 2.000889", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("trpc.legalKnowledge.officialStatus.useQuery");
    expect(source).toContain('data-testid="official-source-statuses"');
    expect(source).toContain("Nguồn thủ tục đã xác minh");
    expect(source).toContain("Văn bản pháp lý đã xác minh");
    expect(source).toContain("File mẫu Official DOCX/PDF");
    expect(source).toContain("🤖 AI tìm file mẫu Official");
    expect(source).toContain("hồ sơ tham khảo vẫn hoạt động");
    expect(source).toContain("legalDocuments.items");
  });

  it("does not equate missing verified binary with missing Official sources", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("officialStatusInput");
    expect(source).toContain("hasOfficialProcedureUrl");
    expect(source).toContain("hasOfficialLegalDocument");
    expect(source).toContain("hasOfficialTemplateFile");
    expect(source).toContain("Chưa tìm thấy file mẫu Official đã xác minh; hồ sơ tham khảo vẫn hoạt động.");
    expect(source).toContain("Bộ nguồn chuẩn tự động từ Kho AI pháp lý");
    expect(source).toContain("Metadata đã nạp · chưa có Official binary");
    expect(source).toContain("!authorityTimedOut");
    expect(source).not.toContain("0 mẫu đã xác minh");
  });

  it("exposes expanded template metadata for financial and survey workflows", () => {
    expect(landDossierBuilderTemplates("pit-tax")[0]?.label).toContain("thu nhập cá nhân");
    expect(landDossierBuilderTemplates("registration-fee")[0]?.label).toContain("lệ phí trước bạ");
    expect(landDossierBuilderTemplates("survey")[0]?.label).toContain("trích đo");
    expect(landDossierBuilderTemplates("survey").length).toBeGreaterThanOrEqual(1);
    expect(landDossierBuilderTemplates("survey").every(template => template.provenance === "metadata-only")).toBe(true);
    expect(landDossierBuilderTemplates("planning")[0]?.status).toBe("needs-local-review");
  });

  it("provides sourced transfer guidance with the official procedure code", () => {
    const guidance = landDossierBuilderGuidance("transfer");
    expect(guidance.code).toBe("2.000889");
    expect(guidance.steps.length).toBeGreaterThanOrEqual(4);
    expect(guidance.requirements).toContain("Mẫu số 09/ĐK — bản chính 01 bản.");
    expect(guidance.sources.some(source => source.url.includes("dichvucong.gov.vn"))).toBe(true);
  });

  it("keeps the explicit Mẫu 09/ĐK label in the generated document set", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("Mẫu 09/ĐK — Đơn đăng ký biến động/sang tên");
    expect(source).toContain("Hướng dẫn theo nguồn chính thức");
    expect(source).toContain("documentType");
  });

  it("audits every legal-source gate before allowing export or print", () => {
    const missing = auditLandDossierLegalSources({ province: "", sourceUrl: "http://example.com", sourceCheckedAt: "", templateProvenance: "metadata-only", requiredTemplateCount: 1, verifiedTemplateCount: 0, now: new Date("2026-08-18T00:00:00Z") });
    expect(missing.canReview).toBe(false);
    expect(missing.canExportOrPrint).toBe(false);
    expect(missing.checks.map(check => check.id)).toEqual(["province", "https", "checked-date", "freshness", "template-binary"]);

    const stale = auditLandDossierLegalSources({ province: "Đà Nẵng", sourceUrl: "https://example.gov.vn", sourceCheckedAt: "01/01/2024", templateProvenance: "verified-binary", requiredTemplateCount: 1, verifiedTemplateCount: 1, now: new Date("2026-08-18T00:00:00Z") });
    expect(stale.canExportOrPrint).toBe(false);
    expect(stale.blockingReasons.some(reason => reason.includes("ngày"))).toBe(true);

    const ready = auditLandDossierLegalSources({ province: "Đà Nẵng", sourceUrl: "https://example.gov.vn", sourceCheckedAt: "18/08/2026", templateProvenance: "verified-binary", requiredTemplateCount: 1, verifiedTemplateCount: 1, now: new Date("2026-08-18T12:00:00Z") });
    expect(ready.canReview).toBe(true);
    expect(ready.canExportOrPrint).toBe(true);
  });

  it("queries the shared Official catalog by the selected canonical procedure code", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("const officialProcedureCode = useMemo");
    expect(source).toContain("/^\\d(?:\\.\\d)+$/");
    expect(source).toContain("trpc.legalKnowledge.bundle.useQuery({ code: officialProcedureCode }");
    expect(source).toContain("procedureCode: officialProcedureCode");
    expect(source).toContain("landDossierBuilderOfficialSource(procedureId)");
    expect(source).toContain('(item.template.provenance === "verified_binary" || item.template.provenance === "official")');
    expect(source).toContain("Boolean(item.template.storageKey || item.template.fileUrl)");
    expect(source).not.toContain("bundle.useQuery({ code: officialProcedureSource.procedureCode }");
  });

  it("does not route dynamic catalog code 2.002317 through legacy N/A mapping", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("/^\\d(?:\\.\\d)+$/.test(procedureId) ? procedureId");
    expect(source).toContain("officialProcedureCode");
  });

  it("rejects a stale bundle whose procedure code differs from the selected code", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("legalBundleQuery.data?.procedure?.code === officialProcedureCode");
    expect(source).toContain("? legalBundleQuery.data");
    expect(source).toContain(": undefined;");
  });

  it("connects the builder to verified provincial templates before export", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("trpc.legalKnowledge.templates.useQuery");
    expect(source).toContain('item.template.provenance === "verified_binary"');
    expect(source).toContain('name="verified-db-template"');
    expect(source).toContain("templateId: verifiedTemplate?.template.id");
    expect(source).toContain("Mẫu gốc theo tỉnh/cơ quan");
    expect(source).toContain("trpc.legalKnowledge.approveBinaryCandidate.useMutation");
    expect(source).toContain("Kiểm tra & gắn Official");
  });

  it("packages official documents with manifest and legal traceability metadata", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("documents/${docx.fileName}");
    expect(source).toContain("metadata/manifest.json");
    expect(source).toContain("metadata/legal-traceability.json");
    expect(source).toContain("official-verified-binary");
    expect(source).toContain("selectedTemplate: selectedDbTemplate?.template");
  });

  it("requires a province before attaching a local procedure source", () => {
    expect(landDossierBuilderLocalSource("", "variation")).toMatchObject({ status: "required" });
    expect(landDossierBuilderLocalSource("Đà Nẵng", "variation")).toMatchObject({
      status: "review",
      label: "Nguồn thủ tục Đà Nẵng",
    });
  });

  it("keeps dynamic catalog procedure selection connected to the builder", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("dynamicProcedureOptions.find(([id]) => id === procedureId)");
    expect(source).toContain("const dynamicProcedureOptions = useMemo");
    expect(source).toContain("return requested || \"variation\"");
  });
});


  it("exposes a mobile-safe selectable procedure action and next-step anchor", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("onClick={() => selectProcedure(id)}");
    expect(source).toContain("aria-label={`Chọn thủ tục ${title}`} ");
    expect(source).toContain("aria-pressed={procedureId === id}");
    expect(source).toContain("data-testid={`procedure-option-${id}`}");
    expect(source).toContain('id="dossier-select-province"');
    expect(source).toContain('scrollIntoView({ behavior: "smooth", block: "start" })');
    expect(source).toContain(': "Chọn"}</span>');
  });


  it("keeps procedure input responsive by stabilizing catalog and bundle query behavior", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("staleTime: 5 * 60_000");
    expect(source).toContain("refetchOnWindowFocus: false");
    expect(source).toContain("procedureCode: officialProcedureCode }, { enabled: Boolean(procedureId && legalQueriesEnabled)");
    expect(source).not.toContain("procedureCode: officialProcedureCode, query: procedureSync.query");
    expect(source).toContain("enabled: Boolean(procedureId && legalQueriesEnabled && legalBundleQuery.isSuccess)");
  });

  it("prioritizes province-filtered legal templates in the submission builder", () => {
    const source = readFileSync(resolve(process.cwd(), "client/src/pages/LandDossierBuilder.tsx"), "utf8");
    expect(source).toContain("legalTemplatesQuery.isSuccess && dbTemplates.length");
    expect(source).toContain("procedureCode: officialProcedureCode");
    expect(source).toContain("province: province || undefined");
    expect(source).toContain("Mục Nộp cho cơ quan phải ưu tiên mẫu đã lọc theo tỉnh/thẩm quyền");
  });
