# Việc cần làm — Kết nối biểu mẫu tư vấn

- [x] Xác định kênh lưu trữ: lưu trực tiếp trong cơ sở dữ liệu của website.
- [x] Không dùng email làm kênh lưu trữ chính ở phiên bản này.
- [x] Nâng cấp dự án để có backend, cơ sở dữ liệu và khu vực quản lý yêu cầu.
- [x] Tạo endpoint tiếp nhận dữ liệu biểu mẫu, kiểm tra dữ liệu đầu vào và lưu bản ghi.
- [x] Hiển thị trạng thái gửi thành công/thất bại rõ ràng cho khách hàng.
- [x] Tạo màn hình quản lý để xem, lọc và đánh dấu trạng thái yêu cầu.
- [x] Kiểm tra validation và luồng frontend/backend bằng Vitest; chưa tạo dữ liệu thử trong database.
- [x] Thêm bộ lọc thực sự trong màn hình quản lý theo trạng thái và từ khóa tên/số điện thoại.
- [x] Bổ sung test success path cho lưu yêu cầu và cập nhật trạng thái bằng mock database hoặc test tích hợp an toàn.
- [x] Xác nhận contract form → tRPC → database helper bằng test validation/success path và kiểm tra route giao diện; không tạo dữ liệu khách hàng giả.
- [x] Bổ sung kiểm thử frontend cho việc đọc dữ liệu form và tạo payload gửi mutation, không ghi dữ liệu thử vào database.
- [x] Mở cấu hình Vitest để chạy test frontend và kiểm tra test submit gọi mutation đúng payload.
- [x] Thêm liên kết và nút truy cập khu vực quản lý yêu cầu trực tiếp trên website công khai.
- [x] Kiểm tra lối vào quản lý, xác thực tài khoản và đường dẫn `/quan-ly` trên domain production.
- [x] Thêm một nút/CTA nổi bật dẫn tới `/quan-ly` bên cạnh liên kết footer, đồng thời giữ liên kết footer.
- [x] Kiểm tra domain production: `/quan-ly` yêu cầu đăng nhập khi chưa có phiên; việc đăng nhập quản trị thực tế cần phiên người dùng.
- [x] Xây dựng mô hình dữ liệu cho bất động sản, hình ảnh, khu vực, chủ nhà, khách mua, khảo sát, pháp lý, định giá và giao dịch.
- [x] Thêm trang tìm kiếm bất động sản theo loại, khu vực, giá và diện tích.
- [x] Thêm danh mục nguồn hàng và nội dung khu vực Đà Nẵng–miền Trung; danh sách nổi bật sẽ hiển thị khi có nguồn hàng được công khai.
- [x] Thêm trang chi tiết sản phẩm với giá, diện tích, hướng, vị trí, hình ảnh và thông tin pháp lý.
- [x] Thêm nút gọi điện và Zalo ở các điểm liên hệ chính.
- [x] Thêm khu vực quản lý nguồn hàng, chủ nhà và khách mua.
- [x] Thêm phiếu khảo sát, kiểm tra pháp lý, định giá và theo dõi giao dịch.
- [x] Thêm phân quyền admin, trạng thái, validation và kiểm thử cho các module môi giới.
- [x] Bổ sung thao tác tạo chủ nhà, khách mua, phiếu khảo sát, kiểm tra pháp lý, định giá và giao dịch trong trung tâm môi giới.
- [x] Kiểm thử các mutation nghiệp vụ mới bằng mock database, không tạo bản ghi thử thật.
- [x] Bổ sung liên kết Zalo theo số điện thoại chuyên viên đã cung cấp (`https://zalo.me/0989682825`) ở trang chủ, danh mục và chi tiết sản phẩm.
- [x] Thêm bảng khu vực/tỉnh thành và liên kết bất động sản với khu vực thay vì chỉ dùng chuỗi location.
- [x] Thêm truy vấn và khu vực BĐS nổi bật trên trang chủ, kèm empty state khi chưa có nguồn hàng published/featured.
- [x] Thêm kiểm thử cho truy vấn featured và hiển thị empty state.
- [x] Cập nhật API và form quản lý bất động sản để chọn areaId, lưu liên kết khu vực và hiển thị tên khu vực liên kết.
- [x] Bổ sung kiểm thử frontend cho mục BĐS nổi bật: empty state và danh sách khi query có dữ liệu.
- [x] Join và hiển thị tên khu vực liên kết trong dữ liệu nguồn hàng và bảng quản lý.
- [x] Bổ sung test render thực tế cho empty state/CTA và card BĐS nổi bật trên trang chủ.
- [x] Bổ sung trường bài đăng: diện tích xây dựng, số phòng ngủ, số WC, năm xây dựng, khoảng cách tiện ích và mô tả vị trí.
- [x] Bổ sung trường pháp lý: loại giấy chứng nhận, diện tích trên giấy, mục đích sử dụng, quy hoạch và thế chấp, kèm nguồn xác nhận.
- [x] Bổ sung điều kiện giao dịch: giá thương lượng, hoa hồng, đặt cọc và điều kiện giao dịch.
- [x] Bổ sung thông tin môi giới và mã BĐS vào trang chi tiết.
- [x] Cập nhật form quản lý để nhập các trường mới và thư viện ảnh theo từng nhóm không gian.
- [x] Thêm CTA Đặt lịch xem nhà và Chia sẻ Facebook bên cạnh Gọi ngay và Zalo.
- [x] Thêm kiểm thử schema, validation, form payload và CTA của bài đăng.
- [x] Thêm mục menu “Thông tin sản phẩm” dẫn tới danh mục bất động sản trên desktop và mobile.
- [x] Kiểm tra điều hướng từ menu tới danh mục và trang chi tiết sản phẩm.
- [x] Bổ sung hoặc cập nhật test cho các trường bài đăng mới, validation backend, payload form quản lý và các CTA mới; chạy lại Vitest.
- [x] Kiểm tra thực tế điều hướng từ menu “Thông tin sản phẩm” tới trang danh mục và từ danh mục tới trang chi tiết bằng browser/screenshot review, rồi ghi lại kết quả.
- [x] Bổ sung test cho localStorage guard trong DashboardLayout hoặc kiểm tra SSR tương đương.
- [x] Lưu checkpoint bản sửa production 500 và xác nhận lại trang chủ sau khi phát hành.
- [x] Bổ sung test backend cho validation fail-path của các trường bài đăng mới (thiếu/không hợp lệ) và chạy lại Vitest.
- [x] Bổ sung test frontend cho payload form quản lý bài đăng chuẩn, bao gồm thư viện ảnh và các trường pháp lý/giao dịch.
- [x] Bổ sung test render/link cho các CTA mới trên trang chi tiết (Gọi ngay, Zalo, Đặt lịch xem nhà, Chia sẻ Facebook).
- [x] Thêm tìm kiếm theo từ khóa tiêu đề, mã BĐS, khu vực và mô tả.
- [x] Thêm bộ lọc loại BĐS, khu vực/tỉnh, khoảng giá, diện tích, phòng ngủ, hướng, pháp lý và trạng thái công khai.
- [x] Thêm sắp xếp theo mới nhất, giá thấp đến cao, giá cao đến thấp và diện tích.
- [x] Thêm giao diện bộ lọc responsive, nút áp dụng, xóa bộ lọc và trạng thái không có kết quả.
- [x] Thêm validation và kiểm thử API/frontend cho các tiêu chí tìm kiếm nâng cao.
- [x] Kiểm tra thực tế bằng browser: từ menu “Thông tin sản phẩm” tới danh mục, mở card sang trang chi tiết và ghi kết quả review; production hiện không có card published nên không thể mở detail card thực tế.
- [x] Xác nhận phạm vi trạng thái: danh mục công khai chỉ hiển thị `published`; khu vực quản trị dùng danh sách riêng để quản lý trạng thái.
- [x] Thêm test frontend cho PropertyCatalog: query payload, loading, empty, error và kết quả lọc.
- [x] Bổ sung test frontend thực tế cho payload form BrokerageAdmin, gồm imageUrls, pháp lý và điều kiện giao dịch.
- [x] Bổ sung test CTA PropertyDetail cho gọi, Zalo, đặt lịch xem nhà và chia sẻ Facebook.
- [x] Nâng test PropertyCatalog để kiểm tra dữ liệu hiển thị từ danh sách kết quả, không chỉ helper trạng thái.
- [x] Xác nhận homepage production trước checkpoint và xác nhận menu bằng browser; production chưa có published card nên đã ghi blocker detail riêng.
- [x] Thêm test render component PropertyCatalog với mock tRPC cho loading, error, empty và card kết quả.
- [x] Thêm test submit handler BrokerageAdmin với mock mutation callback, chứng minh payload đi qua mutation.
- [x] Rà soát và chuẩn hóa biểu mẫu Đăng bài BĐS theo cấu trúc tiêu đề, ảnh, thông tin nhanh, vị trí, pháp lý, giao dịch và môi giới.
- [x] Bảo đảm biểu mẫu đăng bài lưu đầy đủ dữ liệu vào cơ sở dữ liệu qua mutation quản trị.
- [x] Bảo đảm chỉ bài có trạng thái published mới xuất hiện trong mục Thông tin sản phẩm và mở được trang chi tiết.
- [x] Bổ sung test payload, validation và trạng thái công khai cho luồng đăng bài.
- [x] Xác minh luồng quản trị → công khai bằng browser và lưu checkpoint; browser production chưa đăng nhập nên đã xác nhận route quản lý hiển thị skeleton xác thực, còn chuyển trạng thái cần thực hiện sau khi đăng nhập admin.
- [x] Làm rõ CTA công khai để khách hàng vào xem sản phẩm đang bán từ menu, trang chủ và trang danh mục.
- [x] Hiển thị hướng dẫn rõ rằng môi giới đăng bài trong Quản lý, còn khách hàng xem bài đã Công khai tại Thông tin sản phẩm.
- [x] Kiểm tra trạng thái empty/loading của danh mục và bổ sung lời kêu gọi liên hệ khi chưa có sản phẩm công khai.
- [x] Bổ sung test cho CTA sản phẩm công khai và nội dung phân biệt khách hàng/môi giới.
- [x] Xác minh preview công khai và lưu checkpoint mới; production sẽ được xác nhận lại ngay sau khi checkpoint phát hành.
- [x] Thêm nội dung UI rõ ràng trên trang chủ hoặc danh mục nêu môi giới đăng bài trong Quản lý, khách hàng xem các bài đã Công khai tại Sản phẩm đang bán.
- [x] Bổ sung test xác nhận nội dung phân biệt khách hàng và môi giới được render ở đúng điểm truy cập công khai.
- [x] Bổ sung test render cho PropertyCatalog để xác nhận hướng dẫn khách hàng/môi giới thực sự xuất hiện và có liên kết `/quan-ly-moi-gioi`.
- [x] Lưu checkpoint mới sau các chỉnh sửa CTA và hướng dẫn danh mục công khai.
- [x] Xác minh lại domain production sau checkpoint mới tại trang chủ và `/bat-dong-san`, đồng thời ghi kết quả review; homepage và danh mục production đã hiển thị đúng nhãn, CTA, hướng dẫn vai trò và empty state sau đồng bộ.
- [x] Xác minh route Quản lý và phân biệt đúng lỗi truy cập với lỗi lưu bài 10002.
- [x] Bổ sung hướng dẫn ngay trên route Quản lý về đăng nhập, lưu Nháp, quyền admin và cách xử lý lỗi 10002.
- [x] Kiểm thử user lưu Nháp, admin chuyển Công khai và non-admin bị chặn ở adminList/updateStatus bằng mock, không tạo dữ liệu thật.
- [x] Phát hành checkpoint và hướng dẫn người dùng thao tác đăng bài.
- [x] Xác minh route Quản lý và lý do tài khoản hiện tại bị từ chối quyền admin với lỗi 10002.
- [x] Xác định quy tắc admin an toàn: `user.role = admin` hoặc tài khoản owner theo cấu hình hệ thống; chưa tự ý đổi role tài khoản hiện tại.
- [x] Bổ sung hướng dẫn/điểm truy cập: tài khoản đăng nhập được lưu Nháp, còn tài khoản role admin mới xem toàn bộ và chuyển Công khai.
- [x] Kiểm thử quyền admin và mutation lưu bài bằng mock, không tạo dữ liệu BĐS thử thật.
- [x] Phát hành checkpoint và hướng dẫn người dùng xử lý lỗi 10002.
- [x] Bổ sung nút Đăng nhập rõ ràng trên trang chủ và menu mobile.
- [x] Liên kết nút Đăng nhập với OAuth handler hiện có và giữ nút Quản lý cho khu vực vận hành.
- [x] Kiểm thử TypeScript, SSR contract, desktop/mobile render và navigation CTA sau khi bổ sung nút Đăng nhập.
- [x] Lưu checkpoint và hướng dẫn thao tác đăng nhập để đăng bài.
- [x] Bổ sung test/render assertion cho Home xác nhận nút Đăng nhập xuất hiện và vẫn giữ nút Quản lý.
- [x] Xác minh CTA Đăng nhập gọi đúng callback `startLogin`/OAuth và không gây lỗi SSR bằng test callback và render server.
- [x] Lưu checkpoint mới sau khi bổ sung nút Đăng nhập và test liên quan.
- [x] Gửi hướng dẫn rõ ràng: Đăng nhập → Quản lý → Đăng bài → Lưu Nháp; admin duyệt và chuyển Công khai.
- [x] Xác minh lỗi 10002 khi nhấn Lưu hồ sơ trong form đăng BĐS: nguyên nhân là UI gọi adminList/refetch admin trong tài khoản thường, không phải imageUrls.
- [x] Bảo đảm tài khoản đã đăng nhập có thể lưu bài Nháp kèm imageUrls; user đọc danh sách của mình qua `properties.mine`, còn xem toàn bộ và Công khai yêu cầu admin.
- [x] Bổ sung test cho lỗi quyền, payload ảnh và thông báo lỗi trong form; TypeScript và 43/43 Vitest đạt.
- [x] Kiểm tra bằng preview `/quan-ly-moi-gioi` và phát hành checkpoint sửa lỗi lưu bài/ảnh.
- [x] Sửa các liên kết Quản lý trên Home từ `/quan-ly` sang `/quan-ly-moi-gioi` để mở đúng form đăng bài BĐS.
- [x] Cập nhật test navigation và xác minh route đăng bài sau khi sửa link bằng preview; 43/43 test đạt.
- [x] Lưu checkpoint mới sau khi sửa luồng lưu Nháp/ảnh cho user thường và đổi link Quản lý sang `/quan-ly-moi-gioi`.
- [x] Xác minh lại sau checkpoint: preview đã xác nhận trang chủ và `/quan-ly-moi-gioi` hiển thị đúng; sẽ đối chiếu lại domain sau phát hành.
- [x] Thêm khu vực Sản phẩm mới đăng ở vị trí đầu tiên trên trang chủ.
- [x] Chỉ hiển thị bài có trạng thái published, sắp xếp bài mới nhất trước và liên kết tới trang chi tiết.
- [x] Bổ sung loading, empty state, responsive card và test dữ liệu hiển thị trang chủ.
- [x] Chạy kiểm thử 43/43, chụp preview và lưu checkpoint phát hành.
- [x] Lưu checkpoint mới sau khi thêm khu vực Sản phẩm mới đăng trên trang chủ; checkpoint phát hành là `36ddd3e8`.
- [x] Ghi lại version_id phát hành tương ứng để đối chiếu review/rollback: `36ddd3e8`.
- [x] Thêm nút “Xem chi tiết BĐS” trên từng card Sản phẩm mới đăng ở trang chủ.
- [x] Bảo đảm nút liên kết đúng tới route chi tiết của bất động sản tương ứng qua slug đã mã hóa an toàn.
- [x] Bổ sung test CTA và kiểm tra responsive trên mobile 390px và desktop 1280px; nút hiển thị đầy đủ, không cắt/vỡ card; TypeScript và 44/44 Vitest đạt.
- [x] Thêm mutation xóa bài đăng với phân quyền admin và không xóa nhầm bài khác.
- [x] Thêm nút Xóa bài đăng trong bảng Nguồn hàng với hộp xác nhận và cập nhật danh sách sau khi xóa.
- [x] Bổ sung test quyền xóa, nhánh lỗi và trạng thái danh sách sau khi xóa.
- [x] Kiểm tra responsive, chạy test và lưu checkpoint phát hành chức năng xóa.

- [x] Thêm API xóa bài đăng với phân quyền admin và chủ bài Nháp
- [x] Thêm nút xóa bài trong bảng Nguồn hàng với hộp xác nhận
- [x] Bổ sung test backend/frontend cho luồng xóa bài đăng
- [x] Kiểm tra TypeScript, Vitest và giao diện luồng xóa
- [x] Lưu checkpoint phiên bản xóa bài đăng

- [x] Thêm chọn và tải ảnh trực tiếp trong form đăng bài BĐS, lưu URL ảnh vào storage và property_images.
- [x] Mở rộng bộ chọn khu vực để có đầy đủ tỉnh/thành phố Việt Nam và giữ tương thích dữ liệu khu vực hiện có.
- [x] Thêm khu vực trả lời tự động kết hợp thủ công cho yêu cầu tư vấn, cho phép chọn mẫu, chỉnh sửa và gửi phản hồi.
- [x] Bổ sung backend/frontend tests, kiểm tra responsive mobile/desktop và phát hành checkpoint cho ba tính năng mới.

- [x] Thêm nhiều mẫu trả lời tự động để chọn và chỉnh sửa trong ConsultationAdmin.
- [x] Thêm thao tác gửi phản hồi thực tế qua Zalo với nội dung đã soạn, đồng thời cập nhật trạng thái đã liên hệ.
- [x] Bổ sung test cho chọn mẫu và thao tác gửi phản hồi, sau đó lưu checkpoint phát hành.

- [x] Sửa lỗi lưu bài khi giá không đúng định dạng số và hiển thị thông báo tiếng Việt rõ ràng.
- [x] Chuẩn hóa URL ảnh tải trực tiếp, lọc ảnh rỗng/không hợp lệ và giới hạn tối đa 8 ảnh ở giao diện lẫn backend.
- [x] Bổ sung test hồi quy cho giá, URL ảnh, giới hạn 8 ảnh và kiểm tra responsive trước khi phát hành.

- [x] Thêm nút xóa từng ảnh đã tải lên và đồng bộ lại danh sách ảnh gửi khi lưu bài.
- [x] Thêm nút tự động chọn khu vực, điền tỉnh/thành và khu vực chi tiết khi có dữ liệu vị trí.
- [x] Bổ sung test và kiểm tra mobile cho hai nút mới, đồng thời phát hành bản cập nhật.

- [x] Tích hợp bộ chọn khu vực chi tiết lọc theo tỉnh/thành phố trong form đăng bài.
- [x] Giữ nút tự động chọn khu vực và reset khu vực chi tiết khi đổi tỉnh.
- [x] Bổ sung test cho lọc khu vực, kiểm tra mobile và phát hành checkpoint.

- [x] Thiết kế lại trang chủ theo bố cục ảnh tham chiếu thứ hai với header trắng và hero xanh navy.
- [x] Thêm CTA Tư vấn, Xem nguồn hàng, Đăng ký nhu cầu và khối Tìm bất động sản.
- [x] Kết nối bộ lọc tìm kiếm trang chủ với danh mục hiện có, kiểm tra responsive và phát hành.

- [x] Tinh gọn trang quản lý thành khu vực đăng ký đăng bán sản phẩm và danh sách sản phẩm đã đăng.
- [x] Giữ phân quyền đăng nhập, trạng thái Nháp/Công khai và các thao tác quản lý cần thiết.
- [x] Kiểm thử responsive, payload đăng bài và phát hành màn hình quản lý mới.

- [x] Loại bỏ bộ lọc và tìm kiếm khỏi trang Xem nguồn hàng công khai
- [x] Chỉ hiển thị sản phẩm ở trạng thái Công khai và giữ nút xem chi tiết
- [x] Kiểm thử responsive, điều hướng và phát hành trang nguồn hàng

- [x] Rút gọn nội dung giới thiệu các khu vực bất động sản, giữ tên khu vực, định vị ngắn và nút tìm hiểu
- [x] Kiểm tra responsive phần khu vực trên mobile và desktop
- [x] Phát hành bản cập nhật nội dung khu vực

- [x] Rút gọn nội dung các khu vực bất động sản trên trang chủ, gồm Đà Nẵng, Quảng Nam và Miền Trung; đã kiểm tra hiển thị responsive.

- [x] Rút gọn khu vực tư vấn trên trang chủ thành bố cục compact, ưu tiên mobile.
- [x] Tích hợp nút liên hệ Facebook bên cạnh Gọi điện và Zalo trong khu vực tư vấn.
- [x] Hiển thị rõ thông tin chuyên viên Lê Văn Tiến, số 0989 682 825 và khu vực Đà Nẵng.
- [x] Giữ form đăng ký tư vấn kết nối với mutation consultation.submit và trạng thái gửi thành công/thất bại.
- [x] Bổ sung test render cho các nút Facebook/Zalo/điện thoại và form tư vấn compact.
- [x] Kiểm tra responsive desktop/mobile, chạy Vitest và phát hành checkpoint cho khu vực tư vấn mới.

- [x] Rút gọn phần giới thiệu đầu trang Sản phẩm đang bán để giảm chiều cao trên mobile.
- [x] Tinh gọn hộp hướng dẫn khách hàng/môi giới, vẫn giữ liên kết Quản lý và CTA về trang chủ.
- [x] Bảo đảm tiêu đề và thanh tổng số sản phẩm xuất hiện sớm hơn trong danh mục.
- [x] Bổ sung hoặc cập nhật test render cho nội dung đầu trang danh mục sau khi rút gọn.
- [x] Kiểm tra responsive, chạy Vitest và phát hành checkpoint cho danh mục gọn hơn.

- [x] Giữ khu vực đăng ký/đăng bài sản phẩm trong Quản lý, không hiển thị trên trang Nguồn hàng công khai.
- [x] Chỉ hiển thị bất động sản đã chuyển trạng thái Công khai trên trang Nguồn hàng.
- [x] Bổ sung nút Xem chi tiết trên từng sản phẩm đang bán.
- [x] Bổ sung nút liên hệ Gọi điện, Zalo, Messenger và Facebook trên từng sản phẩm hoặc khu vực liên hệ của danh mục.
- [x] Bổ sung test cho trạng thái published và các liên kết liên hệ của nguồn hàng công khai.
- [x] Kiểm tra responsive mobile/desktop, chạy Vitest và phát hành checkpoint cho trang Nguồn hàng.

- [x] Thay ảnh thẻ khu vực Đà Nẵng bằng ảnh trung tâm thành phố phù hợp nhận diện website.
- [x] Tích hợp bản đồ vệ tinh tương tác cho khu vực Đà Nẵng.
- [x] Giữ nút và liên kết tìm hiểu khu vực hoạt động đúng sau khi thay ảnh.
- [x] Kiểm tra responsive, test bản đồ và phát hành checkpoint cho cập nhật khu vực.

- [x] Thay section Cách chúng tôi làm việc bằng tiêu đề và thông điệp Tận tâm – Minh bạch – Đồng hành đến khi hoàn tất giao dịch.
- [x] Hiển thị 4 bước: Tìm đúng BĐS, Kiểm tra thông tin, Tư vấn giá, Hỗ trợ giao dịch.
- [x] Bổ sung nút Đăng ký tư vấn và các nút gọi điện, Zalo, Messenger.
- [x] Kiểm tra link liên hệ, luồng form tư vấn và responsive mobile; cập nhật test và phát hành checkpoint.

- [x] Xóa khối hình ảnh “Người địa phương cho câu chuyện địa phương” và section “Người đồng hành của bạn – Gặp Lê Văn Tiến” khỏi trang chủ.
- [x] Làm sạch liên kết điều hướng tới section đã xóa, giữ nguyên form tư vấn và các khu vực còn lại.
- [x] Cập nhật test, kiểm tra responsive và phát hành checkpoint cho giao diện tinh gọn.

- [x] Thêm mục “Chủ nhà ký gửi BĐS” ngay dưới hai nút hero, giữ nguyên giao diện hero hiện tại.
- [x] Thêm liên kết “Chủ nhà ký gửi” gần nút “Quản lý nguồn hàng” trên menu desktop và mobile.
- [x] Tạo CTA dẫn đến form đăng ký ký gửi với các thông tin chủ nhà, số điện thoại, khu vực, loại BĐS và lời nhắn.
- [x] Kết nối yêu cầu ký gửi với hệ thống consultation hiện có, phân biệt nhu cầu ký gửi với nhu cầu mua.
- [x] Bổ sung test, kiểm tra responsive và phát hành checkpoint cho mục ký gửi.

- [x] Bổ sung lựa chọn Căn hộ, Nhà phố, BĐS khu công nghiệp, Căn hộ chung cư, Đất nền, Khu nghỉ dưỡng/Resort và Villa vào form tư vấn.
- [x] Giữ nguyên các lựa chọn nhu cầu hiện có, bao gồm Ký gửi bất động sản.
- [x] Cập nhật contract test cho toàn bộ danh mục loại bất động sản mới.
- [x] Kiểm tra hiển thị select trên mobile, chạy Vitest và phát hành checkpoint.

- [x] Thêm section giới thiệu các loại bất động sản trên trang chủ.
- [x] Hiển thị các nhóm Căn hộ, Nhà phố, Đất nền, Villa, Khu nghỉ dưỡng/Resort và BĐS khu công nghiệp.
- [x] Bổ sung mô tả ngắn và CTA xem nguồn hàng/đăng ký tư vấn cho từng nhóm.
- [x] Cập nhật contract test, kiểm tra responsive mobile và phát hành checkpoint.

- [x] Thêm nhóm Đất nông nghiệp vào section Danh mục bất động sản.
- [x] Hiển thị các phân loại: đất trồng cây hàng năm, đất trồng cây lâu năm, đất lúa, đất nuôi trồng thủy sản và đất nông nghiệp khác.
- [x] Bổ sung mô tả, nút Xem nguồn hàng và Tư vấn cho nhóm đất nông nghiệp.
- [x] Cập nhật contract test, kiểm tra responsive và phát hành checkpoint.

- [x] Tạo mục Quản lý hồ sơ BĐS nội bộ trong Dashboard dành cho admin/môi giới được cấp quyền.
- [x] Thiết kế hồ sơ gắn với từng BĐS, gồm 12 bước từ tiếp nhận thông tin đến hoàn tất giao dịch.
- [x] Thêm trạng thái bước: Đã hoàn thành, Đang xử lý, Chưa thực hiện và Cần kiểm tra lại.
- [x] Thêm trường dữ liệu và ghi chú cho từng bước theo quy trình nghiệp vụ đã cung cấp.
- [x] Cho phép tải lên và quản lý tài liệu, hình ảnh, video hoặc biên bản theo từng bước qua storage.
- [x] Thêm CRUD hồ sơ, cập nhật trạng thái bước, người phụ trách và lịch sử thay đổi với phân quyền phù hợp.
- [x] Bổ sung API tRPC, migration schema và test backend/frontend cho quy trình hồ sơ BĐS.
- [x] Kiểm tra responsive, quyền truy cập và phát hành checkpoint hệ thống quản lý hồ sơ.

- [x] Làm chữ menu giao diện quản trị to hơn, đậm hơn, sáng và rõ hơn trên desktop/mobile theo ảnh tham chiếu.
- [x] Kiểm tra độ tương phản, trạng thái đang chọn, focus bàn phím và không ảnh hưởng điều hướng.
- [x] Chạy TypeScript, Vitest và kiểm tra responsive; phát hành checkpoint giao diện menu.

- [x] Đặt nút Xóa bài đăng cạnh thao tác của từng bài trong khu vực Quản lý nguồn hàng theo bố cục tham chiếu.
- [x] Giữ hộp xác nhận, phân quyền xóa và cập nhật danh sách sau khi xóa.
- [x] Kiểm tra responsive, test luồng xóa và phát hành checkpoint giao diện.

- [x] Mở rộng form Tạo hồ sơ mới với các loại Đất nền, Đất nông nghiệp, Căn hộ, Nhà phố, Khu nghỉ dưỡng, Villa/Resort.
- [x] Cho phép tạo nhiều hồ sơ mới, xóa hồ sơ đã tạo và tạo lại hồ sơ khác từ danh sách.
- [x] Hiển thị bảng thông số đầy đủ 12 bước sau khi tạo hồ sơ.
- [x] Thêm nút mở/xem từng bước dưới dạng tài liệu Word nội bộ.
- [x] Kiểm tra phân quyền admin, responsive, kiểm thử và phát hành checkpoint tính năng hồ sơ mở rộng.

- [x] Thêm nút Xóa cho từng BĐS trong hộp “Chọn BĐS chưa có hồ sơ”.
- [x] Thêm hộp xác nhận, kiểm tra quyền admin và xóa an toàn BĐS cùng dữ liệu liên quan.
- [x] Cập nhật lại danh sách sau khi xóa, kiểm thử responsive và phát hành checkpoint.

- [x] Thiết kế lại Quản lý hồ sơ BĐS theo CRM mobile-first với tìm kiếm, bộ lọc, nút thêm BĐS và danh sách mã/trạng thái.
- [x] Thêm màn hình chi tiết hồ sơ theo mã BĐS với tiến độ và các nhóm Thông tin, Chủ nhà, Khảo sát, Pháp lý, Quy hoạch, Định giá, Marketing, Khách hàng, Giao dịch, Tài liệu, Lịch sử.
- [x] Tích hợp nút tải hồ sơ, xem vị trí, cập nhật hồ sơ và xuất hồ sơ PDF/Word.
- [x] Bổ sung hiển thị/phân quyền nhân viên phù hợp khu vực admin.
- [x] Kiểm thử mobile, tìm kiếm/lọc, tài liệu, quyền truy cập và phát hành phiên bản CRM.

- [x] Phân loại rõ đăng ký Ký gửi bất động sản trong dữ liệu tư vấn, không để lẫn với nhu cầu mua/ở.
- [x] Hiển thị riêng nhóm khách hàng/chủ nhà ký gửi trong khu vực quản trị để môi giới xem và tư vấn.
- [x] Bổ sung bộ lọc, trạng thái xử lý và thông tin liên hệ cho yêu cầu ký gửi.
- [x] Kiểm thử luồng lưu/hiển thị ký gửi, responsive và phát hành bản sửa lỗi.

- [x] Bảo đảm khi gửi form “Đăng ký ký gửi” dữ liệu được lưu và hiện rõ trong danh sách quản trị.
- [x] Hiển thị nhãn “Yêu cầu ký gửi mới”, thông tin tên, số điện thoại, lời nhắn và thời gian gửi để gọi lại tư vấn.
- [x] Hiển thị phản hồi thành công rõ ràng cho người gửi và kiểm thử payload ký gửi end-to-end.

- [x] Gộp Đăng ký tư vấn ký gửi và Đăng ký nhu cầu thành một biểu mẫu tư vấn chung.
- [x] Giữ lựa chọn phân loại nhu cầu: Chủ nhà ký gửi, Khách mua, Khách thuê hoặc Tư vấn khác.
- [x] Thêm menu trong Quản lý môi giới để hiển thị toàn bộ đăng ký tư vấn đã gửi.
- [x] Hiển thị tên, số điện thoại, nội dung, loại nhu cầu, thời gian gửi và trạng thái xử lý.
- [x] Kiểm thử lưu/hiển thị, phân quyền admin, responsive và phát hành menu quản lý tư vấn.

- [x] Thêm nút chuông thông báo nhỏ trong khu vực quản lý theo phong cách mạng xã hội.
- [x] Hiển thị số lượng yêu cầu ký gửi chưa xử lý trên nút thông báo.
- [x] Cho phép bấm thông báo để mở nhanh danh sách đăng ký tư vấn và đánh dấu đã xem.
- [x] Kiểm thử cập nhật bộ đếm, responsive, quyền admin và phát hành checkpoint.

- [x] Đổi nút “Đăng ký nhu cầu” thành “Đăng ký mua BĐS” và giữ liên kết tới biểu mẫu tư vấn chung.
- [x] Tăng cỡ chữ, độ đậm và độ rõ cho ba nút “Xem nguồn hàng”, “Đăng ký mua BĐS” và “Đăng ký ký gửi”.
- [x] Kiểm tra desktop/mobile, liên kết nút và kiểm thử không hồi quy; phát hành checkpoint.

- [x] Thêm menu “Quá trình môi giới 12 bước” trong khu vực Quản lý môi giới với tiêu đề “QUY TRÌNH QUẢN LÝ BẤT ĐỘNG SẢN”.
- [x] Hiển thị hồ sơ riêng theo từng BĐS và đủ 12 bước nghiệp vụ từ tiếp nhận đến hoàn tất giao dịch.
- [x] Bổ sung trường nhập liệu theo nội dung người dùng cung cấp cho từng bước.
- [x] Thêm trạng thái Đã hoàn thành, Đang xử lý, Chưa thực hiện và Cần kiểm tra lại cho mỗi bước.
- [x] Cho phép tải tài liệu, hình ảnh, giấy tờ, biên bản theo từng bước và xuất toàn bộ hồ sơ thành file Word.
- [x] Kiểm thử quyền admin, responsive, lưu dữ liệu và phát hành checkpoint quy trình môi giới.

- [x] Sửa lỗi nút xuất/tải file Word trong Quy trình quản lý bất động sản.
- [x] Bảo đảm file `.doc` được tạo đúng, tên file hợp lệ và tải được trên desktop/mobile.
- [x] Kiểm thử luồng tải, thông báo lỗi/thành công và phát hành checkpoint sửa lỗi.

- [x] Thêm nút chụp bằng camera hoặc chọn ảnh sổ đỏ/sổ hồng trong khu vực quản lý.
- [x] Lưu ảnh hồ sơ pháp lý vào storage an toàn và liên kết với hồ sơ/bài đăng BĐS.
- [x] Nhận diện các trường pháp lý từ ảnh bằng AI, hiển thị độ tin cậy và cảnh báo chỉ dùng để hỗ trợ nhập liệu.
- [x] Thêm bước xem lại/chỉnh sửa/xác nhận thủ công trước khi điền vào hồ sơ và biểu mẫu đăng bán.
- [x] Tích hợp dữ liệu đã xác nhận vào phần pháp lý của hồ sơ BĐS và form đăng bán.
- [x] Viết test cho upload, phân tích, xác nhận, quyền truy cập và payload pháp lý; chạy TypeScript/Vitest.
- [x] Lưu checkpoint phát hành tính năng camera nhận diện hồ sơ pháp lý.
- [x] Làm nổi bật điểm vào camera nhận diện hồ sơ pháp lý trên màn hình Quản lý môi giới và thêm hướng dẫn khi chưa có bài đăng.
- [x] Sửa lỗi nút Mở camera hồ sơ bị khóa khi chưa có bài BĐS và bổ sung luồng mở camera trực tiếp.

- [x] Thiết kế lại header mobile với logo, menu, nút gọi và điều hướng theo mẫu tham chiếu.
- [x] Thiết kế lại hero trang chủ với ảnh Đà Nẵng, tiêu đề, mô tả và hai CTA chính.
- [x] Bổ sung section Vì sao chọn chúng tôi, Bất động sản nổi bật, Ký gửi và Tin tức & thị trường.
- [x] Tối ưu responsive mobile/desktop và giữ nguyên các CTA, route, biểu mẫu hiện có.
- [x] Viết/cập nhật test cho giao diện trang chủ và chạy TypeScript/Vitest.
- [x] Lưu checkpoint phát hành giao diện trang chủ mới.

- [x] Tạo cửa sổ đăng ký riêng khi khách bấm Mua BĐS.
- [x] Tạo cửa sổ đăng ký riêng khi khách bấm Ký gửi.
- [x] Lưu dữ liệu hai loại đăng ký vào hệ thống với nhãn phân loại rõ ràng.
- [x] Hiển thị đăng ký mua và ký gửi trong Quản lý nguồn hàng → Đăng ký tư vấn.
- [x] Bổ sung thông báo thành công/lỗi, trạng thái xử lý và trải nghiệm mobile.
- [x] Viết/cập nhật test cho hai luồng đăng ký và chạy TypeScript/Vitest.
- [x] Lưu checkpoint phát hành modal đăng ký mua và ký gửi.

- [x] Thêm lựa chọn Đăng ký tư vấn vào cửa sổ liên hệ đa kênh và mở biểu mẫu mua/ký gửi phù hợp.
- [x] Kết nối đăng ký tư vấn với mục Quản lý nguồn hàng → Đăng ký tư vấn.

- [x] Thêm nút Gọi điện, Zalo và Messenger trực tiếp vào từng thẻ bất động sản.
- [x] Bảo toàn nút Xem chi tiết và tối ưu nhóm nút liên hệ trên mobile/desktop.
- [x] Cập nhật test contract cho liên kết liên hệ trên thẻ BĐS và chạy TypeScript/Vitest.
- [x] Lưu checkpoint phát hành nút liên hệ đa kênh trên thẻ BĐS.

- [x] Việt hóa các nút điều khiển và nhãn trên bản đồ.
- [x] Thêm ô nhập địa chỉ sản phẩm và chức năng tìm đến vị trí.
- [x] Lưu tọa độ từng BĐS khi đăng bán hoặc cập nhật hồ sơ.
- [x] Hiển thị nhiều điểm BĐS trên bản đồ và mở chi tiết theo từng điểm.
- [x] Thêm tùy chọn vị trí chính xác/vị trí gần đúng cho bản đồ công khai.
- [x] Viết/cập nhật test cho địa chỉ, tọa độ, quyền hiển thị và chạy TypeScript/Vitest.
- [x] Lưu checkpoint phát hành tính năng bản đồ BĐS.

- [x] Thêm mục Kho lưu trữ hồ sơ vào phần Quản lý nguồn hàng.
- [x] Thiết kế thư mục riêng cho từng BĐS và các nhóm Hồ sơ, Pháp lý, Định giá & thị trường, Marketing, Giao dịch.
- [x] Lưu metadata file gồm tên, loại hồ sơ, BĐS, ngày cập nhật và người tải lên.
- [x] Bổ sung tìm kiếm, lọc theo BĐS/nhóm hồ sơ, xem trước, tải lên, tải xuống, đổi tên và xóa.
- [x] Bảo vệ kho hồ sơ theo quyền admin/nhân viên và lưu file qua storage an toàn.
- [x] Viết/cập nhật test cho kho file, quyền truy cập và thao tác file; chạy TypeScript/Vitest.
- [x] Lưu checkpoint phát hành Kho lưu trữ hồ sơ.

- [x] Cho phép mở camera/chọn ảnh giấy tờ pháp lý ngay cả khi chưa có bài BĐS.
- [x] Thêm luồng Scan to Create: OCR giấy tờ, tạo hồ sơ BĐS Nháp và điền tự động các trường nhận diện được.
- [x] Tự động lưu ảnh/bản gốc giấy tờ vào Kho lưu trữ nhóm Pháp lý theo hồ sơ BĐS vừa tạo.
- [x] Cho phép người dùng xem lại, chỉnh sửa và xác nhận dữ liệu OCR trước khi lưu/công khai bài đăng.
- [x] Hỗ trợ nhiều ảnh/mặt trước-mặt sau trong một lần quét và hiển thị trạng thái xử lý rõ ràng.
- [x] Bổ sung kiểm thử cho luồng camera, tạo bài Nháp, cập nhật pháp lý và lưu archive.

- [x] Thêm mục Hồ sơ điện tử vào menu Quản lý nguồn hàng.
- [x] Tạo danh sách hồ sơ BĐS với mã hồ sơ, trạng thái, ngày cập nhật và thao tác mở chi tiết.
- [x] Tạo trang chi tiết Hồ sơ điện tử theo mẫu CRM: tổng quan, ảnh/video, pháp lý, quy hoạch, khảo sát, định giá, chủ nhà, khách hàng và lịch sử.
- [x] Nối tài liệu nhanh và Kho lưu trữ Pháp lý/Giao dịch vào hồ sơ từng BĐS.
- [x] Bổ sung test route, nội dung giao diện, dữ liệu hồ sơ và responsive mobile.

- [x] Bổ sung các trường form riêng cho từng bước trong Hồ sơ điện tử, không chỉ một ô nội dung chung.
- [x] Bổ sung nút lưu và xóa dữ liệu của từng bước, có hộp xác nhận khi xóa.
- [x] Bổ sung tải nhiều hình ảnh/tài liệu cho từng bước và hiển thị danh sách file đã tải.
- [x] Nối tài liệu từng bước với Kho lưu trữ, hỗ trợ xóa file và làm mới dữ liệu sau thao tác.
- [x] Bổ sung test payload form, xóa dữ liệu, tải file và responsive mobile.

- [x] Bổ sung khu vực danh sách tất cả hồ sơ điện tử đã lưu.
- [x] Thêm tìm kiếm theo mã hồ sơ, tên BĐS, địa chỉ và người phụ trách.
- [x] Thêm bộ lọc theo trạng thái, loại BĐS và tiến độ hồ sơ.
- [x] Cho phép mở hồ sơ từ danh sách để chỉnh sửa và quay lại danh sách giữ nguyên bộ lọc.
- [x] Bổ sung thao tác quản lý hồ sơ và kiểm thử responsive mobile.

- [x] Đổi nhãn và bố cục phần Thông tin đã thực hiện thành form nhập liệu rõ ràng cho từng bước.
- [x] Thêm nút Tải hình ảnh và Tải file lên với chọn nhiều tệp.
- [x] Thêm nút Tải file về cho từng tài liệu đã lưu.
- [x] Thêm nút Lưu bài và Xóa nội dung bước với phản hồi rõ ràng.
- [x] Kiểm thử thao tác form, tải lên/tải về, xóa và giao diện mobile.

- [x] Chuẩn hóa form nhập liệu riêng cho từng bước trong quy trình môi giới BĐS 12 bước theo mẫu tham chiếu.
- [x] Bảo đảm mỗi bước có trạng thái, nội dung đã thực hiện và ghi chú nội bộ.
- [x] Bảo đảm mỗi bước có nút Lưu bước và Xóa nội dung với xác nhận an toàn.
- [x] Bổ sung/hiển thị rõ nút Tải hình ảnh, Tải file lên và Tải file xuống cho từng bước.
- [x] Kiểm thử toàn bộ quy trình, thao tác file và giao diện mobile trước khi phát hành.

- [x] Sửa lỗi các trường form riêng trong từng bước chưa hiển thị rõ cho người dùng.
- [x] Bảo đảm tiêu đề và ô nhập liệu xuất hiện ngay dưới Trạng thái, trước phần Thông tin đã thực hiện.
- [x] Kiểm thử hiển thị form ở bước 1, bước 2 và các bước còn lại trên mobile.

- [x] Tạo màn hình chi tiết Hồ sơ điện tử cho từng bài đăng BĐS theo mẫu CRM tham chiếu.
- [x] Hiển thị tổng quan tài sản: ảnh, địa chỉ, loại BĐS, diện tích, mặt tiền, hướng, giá, pháp lý và trạng thái.
- [x] Thêm các khu vực/tab: tổng quan, hình ảnh & video, pháp lý, quy hoạch, khảo sát, định giá, chủ nhà, khách hàng và lịch sử.
- [x] Hiển thị tài liệu nhanh, liên kết Kho lưu trữ, tiến độ 12 bước, ghi chú và công việc liên quan.
- [x] Bổ sung thao tác chỉnh sửa, chia sẻ hồ sơ, xuất hồ sơ và kiểm thử responsive mobile.

- [x] Làm lại sidebar và header của Hồ sơ điện tử theo bố cục CRM trong ảnh mẫu.
- [x] Làm lại thẻ tổng quan hồ sơ với ảnh, thông tin tài sản, trạng thái và nút thao tác.
- [x] Làm lại hàng tab nghiệp vụ: tổng quan, hình ảnh, pháp lý, quy hoạch, khảo sát, định giá, chủ nhà, khách hàng và lịch sử.
- [x] Làm lại bố cục nội dung 3 cột gồm mô tả/bản đồ, thông tin chi tiết/tài liệu, lịch sử hồ sơ.
- [x] Nối dữ liệu thật và kiểm thử responsive desktop/mobile theo ảnh tham chiếu.

- [x] Dựng lại shell CRM đầy đủ với sidebar xanh đậm và header cố định theo ảnh mẫu.
- [x] Dựng lại phần tiêu đề hồ sơ, breadcrumb, trạng thái và các nút Chia sẻ/Xuất/Chỉnh sửa.
- [x] Dựng lại thẻ tổng quan ảnh và 8 thông tin tài sản theo đúng tỷ lệ bố cục mẫu.
- [x] Dựng lại thanh tab nghiệp vụ và lưới 3 cột gồm mô tả, bản đồ, lịch sử, tài liệu, ghi chú, công việc và thống kê.
- [x] Nối dữ liệu thật, kiểm tra desktop/mobile và xác nhận giao diện không còn là bố cục mô phỏng một phần.

# Thiết kế lại Hồ sơ BĐS theo ảnh mẫu CRM

- [x] Đối chiếu và dựng lại phần đầu hồ sơ: breadcrumb, mã hồ sơ, trạng thái, ngày tạo, người phụ trách và các nút thao tác.
- [x] Dựng lại thẻ tổng quan tài sản gồm ảnh, địa chỉ, loại BĐS, diện tích, giá, mặt tiền, pháp lý, hướng và tình trạng.
- [x] Hoàn thiện thanh tab nghiệp vụ với trạng thái tab đang chọn và chuyển đổi không mất dữ liệu.
- [x] Hoàn thiện các khối Tổng quan: Thông tin mô tả, Vị trí trên bản đồ, Lịch sử hồ sơ, Thông tin chi tiết, Tài liệu nhanh, Ghi chú, Công việc liên quan và Thống kê tương tác.
- [x] Kết nối nút xem thêm, xem toàn bộ, xem trên bản đồ, xem tất cả tài liệu, công việc và lịch sử với trạng thái giao diện phù hợp.
- [x] Bảo đảm các tab Hình ảnh & Video, Hồ sơ pháp lý, Quy hoạch, Phiếu khảo sát, Định giá, Chủ nhà, Khách hàng và Lịch sử hiển thị nội dung nghiệp vụ tương ứng.
- [x] Kiểm tra responsive mobile/desktop, cập nhật kiểm thử hành vi tab và lưu checkpoint phát hành.


# Tích hợp đăng bài bất động sản đa kênh

- [x] Xác định khả năng API chính thức của Facebook, Zalo, TikTok, Google và YouTube cho đăng nội dung.
- [x] Chọn phương án đăng tự động, đăng theo duyệt hoặc tạo nội dung sẵn để người dùng xác nhận.
- [x] Thiết kế màn hình kết nối tài khoản/kênh và quản lý quyền đăng bài.
- [x] Thiết kế luồng tạo nội dung từ hồ sơ BĐS, xem trước và chọn kênh phát hành.
- [x] Bổ sung trạng thái đăng, lịch sử lỗi và nhật ký từng kênh.
- [x] Chỉ triển khai sau khi có connector/API key và quyền hợp lệ từ người dùng.


# Tác vụ soạn và duyệt đăng bài đa kênh

- [x] Tạo tác vụ phát hành từ một hồ sơ BĐS với trạng thái Nháp, Chờ duyệt, Đã duyệt và Đã đăng.
- [x] Tự động soạn bản nội dung phù hợp cho Facebook Page, Google Business Profile, YouTube và TikTok từ dữ liệu hồ sơ.
- [x] Cho phép chọn một hoặc nhiều kênh trước khi đăng.
- [x] Hiển thị bản xem trước riêng theo từng kênh và cho phép chỉnh sửa nội dung trước khi duyệt.
- [x] Bổ sung nút Duyệt nội dung, Đăng ngay, Lên lịch và Hủy tác vụ.
- [x] Hiển thị nhật ký trạng thái, lỗi và kết quả đăng của từng kênh.
- [x] Chưa đăng thật nếu chưa có connector/API và người dùng chưa xác nhận thao tác.
- [x] Kiểm thử toàn bộ luồng tạo, chỉnh sửa, duyệt và chọn kênh.


# Trợ lý AI phân tích và tự viết nội dung BĐS

- [x] Xác định phạm vi phân tích từ thông tin tài sản, 12 bước hồ sơ, tài liệu pháp lý và hình ảnh.
- [x] Đặt nguyên tắc AI chỉ đề xuất, không tự kết luận pháp lý và không tự đăng khi chưa duyệt.
- [x] Thêm giao diện trợ lý AI trong Hồ sơ điện tử.
- [x] Tạo chức năng phân tích điểm mạnh, điểm cần bổ sung và cảnh báo dữ liệu thiếu.
- [x] Tạo nội dung đăng bán tự động theo các kênh đã chọn.
- [x] Cho phép đưa kết quả AI vào bản nháp Đăng đa kênh để chỉnh sửa và duyệt.
- [x] Thêm trạng thái xử lý, lỗi và kiểm thử chức năng AI.


# Tác vụ phong cách viết AI

- [x] Thêm lựa chọn phong cách Ngắn gọn, Chuyên nghiệp và Tối ưu Facebook.
- [x] Cho phép tạo lại nội dung theo phong cách đã chọn từ dữ liệu hồ sơ hiện tại.
- [x] Giữ nguyên bản nháp hiện tại cho đến khi người dùng kiểm tra kết quả mới.
- [x] Hiển thị phong cách đang chọn và phản hồi trạng thái AI đang xử lý.
- [x] Bổ sung kiểm thử contract cho các phong cách viết.


# Điều chỉnh chữ giao diện Hồ sơ điện tử

- [x] Tăng cỡ chữ tiêu đề, nhãn, nội dung và nút trong Hồ sơ điện tử.
- [x] Tăng độ tương phản và độ đậm cho các thông tin cần quản lý nhanh.
- [x] Giữ nguyên bố cục, màu sắc, chức năng, dữ liệu và các thao tác hiện có.
- [x] Kiểm tra khả năng đọc trên màn hình điện thoại và desktop.
- [x] Cập nhật kiểm thử và lưu checkpoint giao diện.


# Làm rõ typography danh sách Hồ sơ điện tử

- [x] Tăng cỡ chữ và độ đậm cho thẻ giới thiệu Hồ sơ điện tử.
- [x] Tăng cỡ chữ cho ô tìm kiếm, bộ lọc, mã hồ sơ, tên BĐS và trạng thái trong danh sách.
- [x] Tăng cỡ chữ cho tiêu đề, thông tin tài sản, tab và nội dung chi tiết hồ sơ.
- [x] Giữ nguyên bố cục, màu sắc, dữ liệu, chức năng và khoảng cách tổng thể.
- [x] Kiểm tra rõ chữ trên mobile/desktop, chạy test và lưu checkpoint.


# Tinh chỉnh Hồ sơ điện tử theo ảnh CRM tham chiếu

- [x] Làm nổi bật tiêu đề hồ sơ, mã hồ sơ, trạng thái và thông tin ngày tạo/người phụ trách.
- [x] Tăng độ rõ cho khu vực tổng quan tài sản, nhãn thông tin và giá trị dữ liệu.
- [x] Làm thanh tab nghiệp vụ dễ đọc, dễ nhận biết tab đang chọn và hỗ trợ cuộn ngang trên mobile.
- [x] Tăng khả năng đọc cho các khối mô tả, bản đồ, tài liệu nhanh, lịch sử, ghi chú, công việc và thống kê.
- [x] Giữ nguyên dữ liệu, chức năng, thao tác chuyển tab và các nút hiện có.
- [x] Kiểm tra desktop/mobile, chạy test và lưu phiên bản mới.


# Bộ chọn cỡ chữ Hồ sơ điện tử

- [x] Thêm bộ chọn Tiêu chuẩn, Lớn và Rất lớn trong giao diện Hồ sơ điện tử.
- [x] Áp dụng cỡ chữ đã chọn cho danh sách, chi tiết, tab và các khối thông tin CRM.
- [x] Lưu lựa chọn cỡ chữ để không mất khi chuyển tab hoặc mở lại trang.
- [x] Hiển thị rõ mức cỡ chữ đang được chọn và hỗ trợ thao tác trên mobile.
- [x] Viết kiểm thử cho ba mức cỡ chữ và lưu checkpoint.


# Thu gọn giao diện và tăng cỡ chữ Hồ sơ điện tử

- [x] Thu gọn khoảng cách và vùng trống của phần danh sách hồ sơ trên mobile.
- [x] Tăng cỡ chữ tiêu đề, mã hồ sơ, trạng thái, bộ lọc và thông tin chi tiết.
- [x] Tăng chiều cao vùng bấm cho các nút thao tác nhưng giữ bố cục gọn.
- [x] Rà soát hiển thị desktop/mobile, kiểm thử và lưu checkpoint.


# Tối ưu danh sách hồ sơ trên mobile

- [x] Thu gọn chiều cao và khoảng đệm của từng bản ghi trên mobile.
- [x] Sắp xếp lại mã hồ sơ, tiêu đề, trạng thái và ngày cập nhật theo dạng gọn.
- [x] Giữ nút mở hồ sơ và xóa đủ rõ, dễ bấm.
- [x] Kiểm tra desktop/mobile, chạy test và lưu checkpoint.


# Thiết kế đầu Hồ sơ BĐS theo mẫu CRM tham chiếu

- [x] Tạo bố cục hai cột: ảnh BĐS bên trái và thông tin nhanh bên phải.
- [x] Hiển thị địa chỉ, loại BĐS, diện tích, giá, mặt tiền, pháp lý, hướng và tình trạng.
- [x] Sắp xếp các tab nghiệp vụ và các khối Tổng quan bên dưới theo mẫu CRM.
- [x] Bảo đảm responsive desktop/mobile, kiểm thử và lưu checkpoint.

- [x] Căn chỉnh phần thông tin chi tiết thành hai cột nhãn và nội dung đồng đều, dễ đọc, responsive trên desktop/mobile.
- [x] Tăng toàn bộ cỡ chữ khu vực Hồ sơ điện tử lên khoảng gấp đôi và làm dòng Tổng quan đậm, có màu nổi bật; vẫn responsive trên desktop/mobile.
- [x] Mở rộng khung bảng nội dung màu xanh phía trên Hồ sơ điện tử sang bên phải, giữ cân đối trên desktop và không tràn ngang trên mobile.
- [x] Tăng cỡ chữ và khoảng cách toàn bộ Hồ sơ điện tử; làm khung màu xanh phía trên cùng lớn, rộng hơn và vẫn responsive trên desktop/mobile.

- [x] Chỉnh khung xanh “Khu vực nội bộ môi giới” của Hồ sơ điện tử thành tỷ lệ cân đối gần hình vuông, full-width và responsive trên desktop/tablet/mobile.

- [x] Đối chiếu tỷ lệ chiều cao khung xanh Hồ sơ điện tử với ảnh tham chiếu và tinh chỉnh chính xác trên desktop, tablet, mobile.

- [x] Tô màu nhận diện riêng cho các module Tổng quan, Hình ảnh & Video, Hồ sơ pháp lý, Quy hoạch, Phiếu khảo sát, Định giá, Chủ nhà, Khách hàng, Lịch sử và Đăng đa kênh; giữ trạng thái đang chọn nổi bật và responsive.

- [x] Thêm mục menu và trang Hồ sơ AI để quản lý hồ sơ khảo sát BĐS, quy hoạch, pháp lý và mẫu quy trình.
- [x] Thêm camera/chụp ảnh, tải file lên, xem trước, tải file về và xóa tài liệu trong Hồ sơ AI.
- [x] Thêm khu vực AI hỗ trợ tìm kiếm luật đất đai, luật kinh doanh BĐS, văn bản mẫu và quy trình đặt cọc/sang tên/chuyển nhượng/hoàn tất thủ tục môi giới, có cảnh báo cần kiểm tra nguồn chính thức.
- [x] Thêm form mẫu Phiếu khảo sát BĐS và Phiếu kiểm tra quy hoạch có thể lưu, xem và xuất file.

- [x] Đưa khu vực Sản phẩm mới đăng lên đầu trang chủ theo bố cục ảnh tham chiếu, hiển thị ảnh và thông tin nhanh rõ ràng.
- [x] Bổ sung/hiển thị các nút Xem chi tiết, Gọi điện, Zalo và Facebook trên từng sản phẩm công khai; giữ responsive desktop/mobile.

- [x] Rút gọn hero đầu trang theo ảnh tham chiếu, chỉ giữ thông điệp Bất động sản miền Trung và nội dung ngắn gọn.
- [x] Hiển thị nhóm loại BĐS gồm nhà phố, căn hộ, villa, resort, khu nghỉ dưỡng, đất nền, khu công nghiệp và đất nông nghiệp.
- [x] Tối ưu khối tìm kiếm đầu trang theo kiểu gọn, dễ chọn loại BĐS/khu vực/giá/diện tích và responsive.

- [x] Thu gọn hero đầu trang thành một khối nhỏ theo ảnh tham chiếu và chỉ giữ các trường tìm kiếm Loại BĐS, Khu vực, Giá.
- [x] Loại bỏ trường Diện tích khỏi form tìm kiếm đầu trang, giữ responsive desktop/mobile và không ảnh hưởng trang danh mục.

- [x] Đưa section Sản phẩm mới đăng lên ngay dưới hero Đà Nẵng – Miền Trung và trước section Giá trị đồng hành trên trang chủ.
- [x] Kiểm tra thứ tự section, các nút CTA và responsive desktop/mobile sau khi di chuyển Sản phẩm mới đăng.

- [x] Thu gọn phần đầu trang theo ảnh tham chiếu: giảm chiều cao hero, khoảng cách nội dung và kích thước khối tìm kiếm nhưng vẫn giữ tiêu đề miền Trung và ba trường tìm kiếm.
- [x] Kiểm tra Sản phẩm mới đăng vẫn nằm ngay dưới hero và không bị đẩy quá xa trên desktop/mobile.

- [x] Thu gọn phần đầu trang web xuống khoảng một nửa chiều cao hiện tại, giữ tiêu đề, nhóm loại BĐS và tìm kiếm Loại BĐS/Khu vực/Giá.
- [x] Kiểm tra Sản phẩm mới đăng xuất hiện sớm hơn và hero vẫn responsive, không tràn ngang trên mobile.

- [x] Tạo mục Khu vực với thanh tìm kiếm, nút tìm kiếm, nút yêu thích/menu và lưới thẻ khu vực theo ảnh tham chiếu.
- [x] Hiển thị thẻ Đà Nẵng và các khu vực miền Trung có ảnh, tên khu vực, số lượng tin và thao tác chọn khu vực; giữ responsive desktop/mobile.

- [x] Tạo mục Khu vực với thanh tìm kiếm, thẻ Đà Nẵng và các khu vực miền Trung có ảnh, tên, số lượng tin và thao tác chọn khu vực; giữ responsive desktop/mobile.

- [x] Tạo mục Khu vực với thanh tìm kiếm, thẻ Đà Nẵng và các khu vực miền Trung có ảnh, tên, số lượng tin và thao tác chọn khu vực; giữ responsive desktop/mobile.

- [x] Redesign section Khu vực trên trang chủ theo ảnh tham chiếu: thanh tìm kiếm nổi bật, nút tìm kiếm, biểu tượng yêu thích/menu, thẻ khu vực có ảnh và số lượng tin, responsive desktop/mobile.

- [x] Tạo thanh tác vụ nhỏ phía trên hero theo ảnh tham chiếu với bốn mục Nguồn hàng, Mua BĐS, Ký gửi và Tư vấn; giữ responsive và liên kết đúng hành động.

- [x] Phóng to trang đầu theo ảnh tham chiếu trên mobile: tăng kích thước thanh điều hướng nhanh, hero, tiêu đề, nhóm loại BĐS và khối tìm kiếm; giữ responsive desktop/mobile.

- [x] Phóng to và tô màu rõ ràng tiêu đề “Bất động sản miền Trung”, các nút tác vụ và danh mục BĐS trên trang đầu; giữ responsive desktop/mobile.

- [x] Phóng to thanh menu trên cùng, tên “Bất động sản xanh”, nút gọi và nút menu ba gạch; tăng cỡ chữ giao diện theo hướng dễ đọc và giữ responsive desktop/mobile.

- [x] Điều chỉnh hero trang chủ thành nền xanh đậm có ảnh phủ, tiêu đề trắng/vàng và mô tả ngắn theo mẫu ảnh.
- [x] Hiển thị nhóm loại BĐS dạng chip nhỏ gọn, tương phản rõ và responsive.
- [x] Tạo khung tìm kiếm nổi bật màu trắng với ba trường lọc và nút tìm kiếm xanh đậm.
- [x] Kiểm tra responsive mobile/desktop, giữ nguyên CTA và chạy test TypeScript/build.

- [x] Thu nhỏ header và logo theo breakpoint nhưng giữ vùng bấm gọi/menu dễ thao tác.
- [x] Thu nhỏ thanh tác vụ nhanh và chip danh mục trên mobile, không làm chữ bị cắt.
- [x] Thu nhỏ hero và form tìm kiếm theo chiều rộng màn hình, giữ không tràn ngang.
- [x] Kiểm tra preview mobile/desktop, chạy Vitest và TypeScript/build.

- [x] Cắt bỏ toàn bộ hero xanh và form tìm kiếm lớn trên trang chủ.
- [x] Tích hợp thanh tìm kiếm ngang gọn cùng khu vực menu trên cùng, responsive trên mobile và desktop.
- [x] Kiểm tra danh sách sản phẩm nằm đúng sau header mới, không còn khoảng trống lớn và chạy test/build.

- [x] Thu gọn form tìm kiếm thành một hàng ngang gồm ba cột nhỏ: Loại BĐS, Khu vực và Giá tối đa.
- [x] Đặt nút Tìm kiếm gọn ở cuối hàng và bảo đảm responsive trên mobile/desktop.
- [x] Kiểm tra form mới không ảnh hưởng submit bộ lọc, chạy Vitest và TypeScript/build.

- [x] Thiết kế lại khối Sản phẩm mới đăng với nền xanh đậm, nhãn vàng và tiêu đề lớn trắng/vàng theo mẫu ảnh.
- [x] Thêm liên kết Sản phẩm đang bán và bố cục thẻ BĐS phía dưới, giữ nguyên dữ liệu cùng các CTA hiện có.
- [x] Bảo đảm khối mới responsive trên mobile/tablet/desktop, chạy Vitest và TypeScript/build.

- [x] Cắt bỏ toàn bộ khối Sản phẩm mới đăng nền xanh hiện tại.
- [x] Tạo danh sách BĐS nền trắng theo ảnh, mỗi tin chỉ hiển thị một ảnh đại diện.
- [x] Hiển thị tiêu đề, giá, diện tích, vị trí, thời gian đăng và nút lưu; giữ CTA xem chi tiết/liên hệ hiện có.
- [x] Kiểm tra responsive mobile/desktop, chạy Vitest và TypeScript/build.

- [x] Chuyển phần danh mục BĐS thành khu vực bất động sản theo địa điểm.
- [x] Tạo một thẻ khu vực lớn và bốn thẻ khu vực nhỏ dạng lưới như ảnh tham chiếu.
- [x] Hiển thị ảnh nền, tên khu vực và số lượng tin; bảo đảm responsive mobile/desktop.
- [x] Kiểm tra dữ liệu, chạy Vitest và TypeScript/build sau khi chỉnh sửa.

- [x] Thu gọn lưới khu vực thành bố cục hai cột, mỗi cột xếp bốn hàng.
- [x] Bảo đảm thẻ khu vực hiển thị gọn, rõ tên, ảnh nền và số lượng tin trên mobile/desktop.
- [x] Kiểm tra responsive, chạy Vitest và TypeScript/build sau khi điều chỉnh.

- [x] Chuyển phần “Cách chúng tôi làm việc và đồng hành” thành bố cục hai cột.
- [x] Giữ nguyên nội dung dịch vụ, CTA liên hệ và bảo đảm responsive trên mobile.
- [x] Kiểm tra preview, chạy Vitest và TypeScript/build sau khi chỉnh sửa.

- [x] Rút gọn phần giới thiệu phía trên của “Cách chúng tôi làm việc và đồng hành”.
- [x] Chia bốn nội dung dịch vụ thành các khối nhỏ trong bố cục hai cột.
- [x] Giữ CTA liên hệ, bảo đảm responsive và kiểm tra test/build sau chỉnh sửa.

- [x] Thu gọn phần tiêu đề, mô tả và khoảng cách phía trên của “Cách chúng tôi làm việc và đồng hành”.
- [x] Sắp xếp bốn bước 01–04 thành hai hàng với các khung nhỏ theo ảnh tham chiếu.
- [x] Giữ CTA đăng ký tư vấn, bảo đảm responsive mobile/desktop và kiểm tra test/build.

- [x] Bổ sung khối “Nguồn hàng đa dạng” trên trang chủ.
- [x] Hiển thị các nhóm: nhà phố, căn hộ, đất nền, đất nông nghiệp, đất khu công nghiệp, khu thương mại, resort/villa, khu nghỉ dưỡng, đất dự án và cho thuê.
- [x] Trình bày gọn, responsive và không ảnh hưởng tin đăng hoặc CTA hiện có.
- [x] Chạy Vitest, TypeScript/build và lưu checkpoint sau khi hoàn tất.

- [x] Thay khối “Bất động sản dành cho bạn” bằng “Nguồn hàng đa dạng”.
- [x] Hiển thị đủ 10 nhóm: nhà phố, căn hộ, đất nền, đất nông nghiệp, đất khu công nghiệp, khu thương mại, resort/villa, khu nghỉ dưỡng, đất dự án và cho thuê.
- [x] Làm phần hình ảnh khu vực nổi bật lớn và dễ nhìn hơn, vẫn responsive.
- [x] Kiểm tra CTA, chạy Vitest, TypeScript/build và lưu checkpoint.

- [x] Thu nhỏ thêm chiều cao, khoảng đệm, biểu tượng và cỡ chữ của các ô “Nguồn hàng đa dạng” theo ảnh tham chiếu.
- [x] Giữ bố cục hai cột, không làm tràn chữ và bảo đảm responsive.
- [x] Chạy Vitest, TypeScript/build và lưu checkpoint sau khi hoàn tất.

- [x] Thu hẹp chiều ngang, khoảng cách và khoảng trắng của section “Nguồn hàng đa dạng”.
- [x] Rút gọn thêm kích thước các ô loại BĐS, biểu tượng và chữ nhưng vẫn dễ đọc.
- [x] Kiểm tra responsive, chạy Vitest, TypeScript/build và lưu checkpoint.

- [x] Tăng kích thước ảnh đại diện trong thẻ tin BĐS.
- [x] Cân đối phần ảnh và phần thông tin thành một ô thống nhất, rõ ràng.
- [x] Bảo đảm responsive, giữ nguyên CTA và chạy test/build trước khi lưu checkpoint.

- [x] Biến từng mục trong “Nguồn hàng đa dạng” thành nút lọc tương tác.
- [x] Khi bấm một loại, chỉ hiển thị các tin BĐS tương ứng; có thể quay lại xem tất cả.
- [x] Giữ nguyên CTA, bảo đảm responsive và kiểm thử tương tác trước khi lưu checkpoint.

- [x] Chuyển thẻ sản phẩm từ bố cục ngang sang bố cục dọc giống ảnh tham chiếu thứ hai.
- [x] Đưa ảnh lớn lên phía trên và phần thông tin vào khối trắng phía dưới.
- [x] Sắp xếp lại CTA xem chi tiết, Gọi, Zalo, Messenger/Facebook mà không làm mất chức năng.
- [x] Kiểm tra responsive, chạy Vitest, TypeScript/build và lưu checkpoint.

- [x] Tô màu nhấn cho khối “Nguồn hàng đa dạng” và các ô loại BĐS.
- [x] Thu gọn nhẹ phần sản phẩm đăng bán, gồm khoảng cách, ảnh và khối thông tin nhưng vẫn dễ đọc.
- [x] Giữ nguyên bộ lọc, dữ liệu, CTA và responsive; chạy test/build trước khi lưu checkpoint.

- [x] Gán màu nhận diện riêng cho từng nhóm trong “Nguồn hàng đa dạng”.
- [x] Bảo đảm màu chữ, biểu tượng và trạng thái chọn đủ tương phản, dễ đọc.
- [x] Giữ nguyên bộ lọc, responsive; chạy test/build và lưu checkpoint.

- [x] Sắp xếp CTA theo thứ tự: Xem chi tiết BĐS, Gọi, Zalo, Messenger, Facebook.
- [x] Gom các nút thành bố cục gọn, ưu tiên nút xem chi tiết và không làm tràn trên mobile.
- [x] Giữ nguyên chức năng liên hệ, kiểm tra responsive, test/build và lưu checkpoint.

- [x] Thu nhỏ cụm CTA trên thẻ BĐS và đặt ở cuối thẻ thành hai hàng theo ảnh mẫu.
- [x] Giữ nút Xem chi tiết là CTA chính; đưa Gọi, Zalo, Messenger, Facebook vào hàng liên hệ nhỏ gọn.
- [x] Bảo đảm các liên kết liên hệ, responsive mobile/desktop, test/build và lưu checkpoint.

- [x] Đổi nhãn ô chọn “Tất cả loại BĐS” thành “Loại BĐS” và “Tất cả khu vực” thành “Khu vực”.
- [x] Phối màu riêng cho hai ô chọn trong thanh tìm kiếm, giữ tương phản và responsive.
- [x] Kiểm tra bộ lọc, mobile/desktop, test/build và lưu checkpoint.

- [x] Thu hẹp chiều ngang thanh tìm kiếm trên trang chủ, vẫn giữ responsive.
- [x] Khi bấm vào khu vực thanh tìm kiếm, mở hộp thoại kết nối tư vấn.
- [x] Giữ bộ lọc hiện có, kiểm tra biểu mẫu tư vấn, test/build và lưu checkpoint.

- [x] Thu nhỏ chiều rộng và khoảng đệm khu vực Tư vấn riêng theo ảnh mẫu.
- [x] Thu nhỏ tiêu đề, nội dung, trường biểu mẫu và các nút liên hệ nhưng vẫn dễ đọc.
- [x] Kiểm tra biểu mẫu, liên kết Gọi/Zalo/Facebook, responsive, test/build và lưu checkpoint.

- [x] Tạo mục Khu vực nổi bật theo bố cục thẻ địa điểm trong ảnh mẫu.
- [x] Khi bấm menu Khu vực, cuộn/mở đúng mục Khu vực nổi bật; giữ liên kết Xem tất cả khu vực.
- [x] Hiển thị các thẻ Đà Nẵng, Quảng Nam, Hội An, Huế và các khu vực miền Trung theo lưới responsive.
- [x] Kiểm tra điều hướng, lọc địa điểm, test/build và lưu checkpoint.

- [x] Trong menu ba gạch mobile, hiển thị mục Khu vực rõ ràng và có thể bấm.
- [x] Khi bấm Khu vực, đóng menu và cuộn/mở section Khu vực nổi bật theo ảnh mẫu.
- [x] Kiểm tra luồng hai lần bấm, thẻ hình ảnh địa điểm, responsive, test/build và lưu checkpoint.

- [x] Thêm nút Về đầu trang ở cuối từng section được mở từ menu.
- [x] Cuộn mượt về đầu trang, giữ khả năng sử dụng trên mobile và desktop.
- [x] Kiểm tra menu, các điểm neo, responsive, test/build và lưu checkpoint.

- [x] Thêm lựa chọn loại BĐS cho hồ sơ quy trình 12 bước.
- [x] Thiết kế bộ trường dữ liệu riêng cho Đất nền, Căn hộ, Nhà phố, Đất nông nghiệp, Villa/Resort, Khu công nghiệp, Đất dự án và Cho thuê.
- [x] Hiển thị đúng bộ trường theo loại BĐS trong từng bước, giữ trạng thái, tài liệu và xuất Word.
- [x] Kiểm tra lưu/chỉnh sửa hồ sơ, responsive, test/build và lưu checkpoint.

- [x] Tạo giao diện mẫu Hồ sơ điện tử tự tổng hợp dữ liệu từ quy trình 12 bước.
- [x] Hiển thị tổng quan BĐS, tiến độ, dữ liệu theo loại, pháp lý, tài liệu, khách hàng và lịch sử cập nhật.
- [x] Kết nối dữ liệu quy trình và tài liệu vào giao diện hồ sơ, có trạng thái đồng bộ rõ ràng.
- [x] Kiểm tra responsive, test/build và lưu checkpoint.

- [x] Tạo layout CRM với điều hướng Dashboard, BĐS, Khách hàng, Hồ sơ, Quy trình, Giao dịch, Marketing, AI Assistant và Báo cáo.
- [x] Xây dashboard tổng quan gồm BĐS đang bán, khách hàng, công việc hôm nay, giao dịch, doanh thu, AI gợi ý, lịch hẹn và khách tiềm năng.
- [x] Hiển thị pipeline Tiếp nhận → Kiểm tra → Ký gửi → Tìm khách → Đàm phán → Đặt cọc → Công chứng → Hoàn tất.
- [x] Kết nối điều hướng, kiểm tra responsive, test/build và lưu checkpoint.

- [x] Tạo layout CRM với điều hướng Dashboard, BĐS, Khách hàng, Hồ sơ, Quy trình, Giao dịch, Marketing, AI Assistant và Báo cáo.
- [x] Xây dashboard tổng quan gồm BĐS đang bán, khách hàng, công việc hôm nay, giao dịch, doanh thu, AI gợi ý, lịch hẹn và khách tiềm năng.
- [x] Hiển thị pipeline Tiếp nhận → Kiểm tra → Ký gửi → Tìm khách → Đàm phán → Đặt cọc → Công chứng → Hoàn tất.
- [x] Kết nối điều hướng, kiểm tra responsive, test/build và lưu checkpoint.
- [x] Xác nhận route Nguồn hàng hiện có không bị thay đổi khi thêm Dashboard CRM
- [x] Thêm điểm vào Dashboard cho người dùng đã đăng nhập trong điều hướng quản trị
- [x] Dùng DashboardLayout hiện có cho các route CRM và giữ route công khai độc lập
- [x] Rà soát schema và các truy vấn hiện có cho BĐS, khách hàng, hồ sơ, khảo sát, định giá và giao dịch
- [x] Tạo API tổng hợp số liệu Dashboard từ cơ sở dữ liệu thật
- [x] Kết nối Dashboard với API và thay dữ liệu mẫu bằng dữ liệu đồng bộ
- [x] Thêm trạng thái loading, lỗi, empty và thời điểm cập nhật cuối trên Dashboard
- [x] Viết test cho API tổng hợp và contract dữ liệu Dashboard
- [x] Kiểm tra đồng bộ sau thao tác thêm/sửa/xóa nguồn hàng mà không làm thay đổi menu hiện có

- [x] Thêm trợ lý AI trò chuyện công khai ở góc phải dưới trang chủ
- [x] Thêm điểm mở trợ lý AI trong từng thẻ và trang chi tiết BĐS
- [x] Tích hợp lựa chọn trò chuyện AI vào hộp thoại liên hệ và biểu mẫu Mua BĐS/Ký gửi
- [x] Tạo luồng AI gọi điện trong Dashboard CRM, AI Assistant và hồ sơ khách hàng
- [x] Bắt buộc môi giới xem lại và xác nhận trước khi AI thực hiện cuộc gọi
- [x] Bổ sung lưu lịch sử trò chuyện/kịch bản gọi và kiểm thử responsive, an toàn

- [x] Cho phép mở bảng thông báo từ nút chuông trong Dashboard CRM
- [x] Đánh dấu thông báo đã xem và tự ẩn huy hiệu đỏ khi đã xem hết
- [x] Giữ số lượng huy hiệu chính xác khi còn thông báo chưa đọc
- [x] Bổ sung kiểm thử thao tác đọc thông báo và kiểm tra responsive mobile

- [x] Gán biểu tượng riêng cho từng nhóm Nguồn hàng đa dạng theo loại BĐS
- [x] Giữ nguyên màu nền, nhãn, bộ lọc và bố cục hai cột của các ô nguồn hàng
- [x] Kiểm tra icon hiển thị rõ trên mobile/desktop và không ảnh hưởng thao tác lọc
- [x] Bổ sung hoặc cập nhật kiểm thử mapping icon và chạy test/build

- [x] Tinh chỉnh kiểu chữ tiêu đề và nhãn trong khối Nguồn hàng đa dạng để đẹp, rõ và đồng nhất
- [x] Đổi nền/viền các khung danh mục Nguồn hàng sang tông đỏ hoặc đỏ san hô có độ tương phản tốt
- [x] Giữ nguyên icon, bộ lọc, trạng thái chọn và bố cục responsive
- [x] Kiểm tra mobile/desktop, cập nhật test và chạy TypeScript/Vitest/build

- [x] Đổi nhãn nút AI nổi thành “Trò chuyện với AI” và giữ dạng nút tròn dễ nhận biết
- [x] Cho phép kéo thả nút AI đến vị trí phù hợp trên màn hình
- [x] Lưu vị trí nút AI và giới hạn không cho kéo ra ngoài viewport
- [x] Bảo đảm bấm nút vẫn mở chat, không che các CTA liên hệ và kiểm thử mobile/desktop

## Danh sách BĐS cạnh bản đồ — 2026-08-16

- [x] Thêm danh sách BĐS cạnh bản đồ trên desktop và bố cục responsive trên mobile.
- [x] Tự lọc danh sách theo bounds/vùng bản đồ hiện đang hiển thị.
- [x] Đồng bộ chọn marker, chọn thẻ, bộ lọc CRM và trạng thái không có kết quả.
- [x] Viết test, kiểm tra desktop/mobile, build và phát hành checkpoint.

## Tệp ảnh/video cho quy trình 12 bước — 2026-08-16

- [x] Rà soát schema, router và helper lưu trữ hiện có cho tệp hồ sơ.
- [x] Thiết kế liên kết tệp theo propertyId, transaction/procedureId và stepNumber.
- [x] Thêm khu vực chọn ảnh/video trong từng bước, có xem trước và tên file.
- [x] Thêm upload lên storage, tải xuống, xóa và trạng thái lỗi/loading.
- [x] Đồng bộ tệp vào Hồ sơ điện tử, phân quyền theo hồ sơ và không lưu bytes trong database.
- [x] Viết test, kiểm tra mobile, build và phát hành checkpoint.

## Video trong mục Ảnh BĐS — 2026-08-16

- [x] Rà soát form tạo/chỉnh sửa BĐS và trường media ảnh hiện có.
- [x] Bổ sung chọn video từ thiết bị và camera mobile với giới hạn định dạng/kích thước rõ ràng.
- [x] Hiển thị xem trước, xóa và trạng thái upload video trong cùng khu vực Ảnh BĐS.
- [x] Lưu video cùng hồ sơ và đồng bộ sang Hồ sơ điện tử/Kho hồ sơ.
- [x] Viết test, kiểm tra mobile, build và phát hành checkpoint.

## Video trong mục Ảnh BĐS — 2026-08-16

- [x] Thêm loại media video vào bảng property_images và áp dụng migration an toàn.
- [x] Mở rộng router upload media để nhận video và giữ tương thích upload ảnh.
- [x] Thêm nút đính kèm/quay video trong mục Ảnh BĐS.
- [x] Thêm giới hạn 4 video, 50MB/video, kiểm tra MP4/WebM/MOV.
- [x] Thêm xem trước video, xóa video và trường videoUrls khi lưu bài đăng.
- [x] Chạy TypeScript, Vitest và build production.
- [x] Kiểm tra preview desktop/mobile và phát hành checkpoint.

## OCR AI cho biên bản quy trình 12 bước — 2026-08-16

- [x] Rà soát trường dữ liệu và luồng upload hiện có của từng bước 12 bước.
- [x] Thiết kế contract OCR theo loại biên bản và stepNumber, có schema JSON kiểm soát.
- [x] Thêm chụp/tải biên bản, phân tích AI và hiển thị bản xem trước dữ liệu đề xuất.
- [x] Thêm nút xác nhận áp dụng dữ liệu vào đúng bước, không ghi đè tự động khi chưa duyệt.
- [x] Lưu bản gốc, kết quả OCR, người xác nhận và lịch sử cập nhật trong Hồ sơ điện tử.
- [x] Viết test OCR, kiểm tra mobile camera, quyền truy cập và phát hành checkpoint.

## Kho hồ sơ đất đai AI — 2026-08-16

- [x] Rà soát khu vực Quản lý nguồn hàng, Hồ sơ điện tử và AI Assistant hiện có.
- [x] Thiết kế thư viện mẫu theo chuyển nhượng, thừa kế, đất nông nghiệp, nhà ở, khách sạn/resort/villa, khu công nghiệp, thương mại và cho thuê.
- [x] Thêm checklist hồ sơ theo loại giao dịch và trạng thái đã có/còn thiếu/cần kiểm tra.
- [x] Thêm tìm kiếm AI theo loại giao dịch, hồ sơ và từ khóa nghiệp vụ.
- [x] Thêm phân tích hồ sơ tải lên, giữ bản gốc và hiển thị kết quả cần kiểm tra.
- [x] Thêm dự thảo tài liệu có cảnh báo “bản nháp — cần chuyên gia pháp lý kiểm tra”.
- [x] Viết test, kiểm tra quyền truy cập/responsive và phát hành checkpoint.

## Ưu tiên danh sách sản phẩm, thu gọn bản đồ — 2026-08-16

- [x] Rà soát bố cục PropertyCatalog và dữ liệu sản phẩm đang bán.
- [x] Đưa danh sách sản phẩm/nguồn hàng lên vị trí chính, hiển thị trước bản đồ.
- [x] Thu gọn bản đồ thành khung nhỏ phía trên hoặc phía dưới danh sách.
- [x] Giữ đồng bộ marker, vùng bản đồ và lựa chọn thẻ sản phẩm.
- [x] Kiểm tra desktop/mobile, test, build và phát hành checkpoint.

## Menu HS ĐẤT ĐAI AI độc lập — 2026-08-16

- [x] Rà soát điều hướng, layout và trang Hồ sơ AI hiện có.
- [x] Thêm menu độc lập “HS ĐẤT ĐAI AI”, không thay đổi các menu Quản lý nguồn hàng.
- [x] Xây thư viện nhóm Thuế, Đất đai, Giao dịch và BĐS thương mại.
- [x] Thêm tìm kiếm mẫu hồ sơ và các nút Xem mẫu, Tải file, AI hướng dẫn, Checklist hồ sơ.
- [x] Hiển thị cơ quan ban hành, căn cứ, ngày hiệu lực và ngày cập nhật cho từng mẫu.
- [x] Kiểm tra responsive, test, build và không ảnh hưởng các trang/menu cũ.

## Menu HS ĐẤT ĐAI AI độc lập — hoàn tất

- [x] Thêm mục menu riêng “HS ĐẤT ĐAI AI” với route `/hs-dat-dai-ai`.
- [x] Giữ nguyên menu “Hồ sơ AI” và các menu Quản lý nguồn hàng hiện có.
- [x] Kết nối route mới với thư viện hồ sơ đất đai AI đã triển khai.
- [x] Bổ sung regression test điều hướng cho menu mới và menu cũ.
- [x] Sửa lỗi JSX tồn tại trong Hồ sơ điện tử để preview/build hoạt động ổn định.
- [x] Chạy Vitest, TypeScript, build production và kiểm tra preview responsive.
- [x] Lưu checkpoint phát hành cho menu HS ĐẤT ĐAI AI.

## Tìm kiếm riêng HS ĐẤT ĐAI AI — 2026-08-16

- [x] Thêm ô tìm kiếm riêng trong trang HS ĐẤT ĐAI AI.
- [x] Lọc theo từ khóa hồ sơ, loại giao dịch, nhóm tài liệu và căn cứ pháp lý.
- [x] Hiển thị danh sách mẫu phù hợp khi tìm “hồ sơ chuyển nhượng” hoặc từ khóa tương tự.
- [x] Thêm xem mẫu, thông tin hiệu lực, AI hướng dẫn, checklist và tải file.
- [x] Thêm trạng thái chưa tìm kiếm, không có kết quả và responsive.
- [x] Viết test, kiểm tra build và phát hành checkpoint.

## Sửa nút Tải file HS ĐẤT ĐAI AI — 2026-08-16

- [x] Kiểm tra dữ liệu URL/file thật của từng mẫu và handler Tải file.
- [x] Sửa liên kết tải để mở đúng file hoặc tải blob từ URL hợp lệ.
- [x] Hiển thị trạng thái rõ ràng cho mẫu chưa có file, không tạo file rỗng.
- [x] Thêm test, kiểm tra desktop/mobile và phát hành checkpoint.

## Đồng bộ mẫu từ Cổng Dịch vụ công — 2026-08-16

- [x] Xác định các trang/nguồn chính thức được phép tra cứu mẫu hồ sơ đất đai.
- [x] Thiết kế metadata nguồn, cơ quan ban hành, căn cứ, ngày hiệu lực, ngày kiểm tra và phiên bản.
- [x] Thêm luồng tìm kiếm/cập nhật mẫu từ nguồn chính thức, không ghi đè tự động mẫu đang dùng.
- [x] Thêm xem thay đổi, phê duyệt phiên bản mới và giữ lịch sử phiên bản cũ.
- [x] Kiểm tra quyền truy cập, lỗi nguồn, test, responsive và phát hành checkpoint.

- [x] Kết nối thư viện HS ĐẤT ĐAI AI với các URL nguồn chính thức của Cổng Dịch vụ công Quốc gia/Bộ Nông nghiệp và Môi trường.
- [x] Bổ sung metadata nguồn, phiên bản, ngày hiệu lực, ngày kiểm tra và trạng thái phê duyệt; không ghi đè mẫu đang dùng.
- [x] Hiển thị liên kết mở nguồn chính thức, trạng thái cập nhật và cảnh báo pháp lý cho từng mẫu.
- [x] Thêm regression test cho ánh xạ nguồn chính thức và hành vi tải mẫu.
- [x] Kiểm tra TypeScript, Vitest, build và preview sau tích hợp.

## Hồ sơ AI trong Quản lý nguồn hàng — 2026-08-16

- [x] Thêm mục Hồ sơ AI riêng trong khu vực Quản lý nguồn hàng, không làm mất các menu hiện có.
- [x] Tạo kho phân loại hồ sơ khách hàng, chủ nhà, BĐS, pháp lý, thuế, giao dịch, công chứng, môi giới và đất đai.
- [x] Đồng bộ danh sách tài liệu đã lưu từ Hồ sơ điện tử và các nguồn hàng liên quan.
- [x] Thêm tìm kiếm ngôn ngữ tự nhiên cho truy vấn như “Hồ sơ chuyển nhượng đất”.
- [x] Hiển thị kết quả theo BĐS, giao dịch, loại hồ sơ, trạng thái đủ/thiếu và thao tác xem/tải.
- [x] Kết nối AI hướng dẫn và checklist hồ sơ kèm disclaimer pháp lý.
- [x] Bổ sung test, kiểm tra responsive, TypeScript, build và phát hành checkpoint.

## Tách Hồ sơ AI và HS ĐẤT ĐAI AI — 2026-08-16

- [x] Tách Hồ sơ AI thành kho quản lý tổng hợp hồ sơ nguồn hàng/giao dịch, không dùng lại tiêu đề và bố cục thư viện đất đai.
- [x] Giữ HS ĐẤT ĐAI AI chỉ dành cho biểu mẫu, thủ tục, văn bản và nguồn pháp lý đất đai chính thức.
- [x] Cập nhật điều hướng và mô tả để người dùng phân biệt rõ hai mục.
- [x] Bổ sung test, kiểm tra responsive, TypeScript, build và phát hành checkpoint.

## Phân quyền hồ sơ nhạy cảm — 2026-08-16

- [x] Rà soát vai trò người dùng hiện có và phạm vi quyền admin/user.
- [x] Xác định hồ sơ nhạy cảm và chính sách quyền xem/tải theo vai trò.
- [x] Bảo vệ backend đối với danh sách, xem và tải hồ sơ nhạy cảm; không chỉ ẩn nút ở giao diện.
- [x] Thêm giao diện hiển thị trạng thái quyền và quản lý chính sách dành cho quản trị viên.
- [x] Bổ sung regression test cho quyền truy cập, quyền tải xuống và trường hợp bị từ chối.
- [x] Kiểm tra TypeScript, Vitest, build, responsive và phát hành checkpoint.

## Hồ sơ đất đai AI — mục chuyên sâu — 2026-08-16

- [x] Tạo phân hệ riêng với tên Hồ sơ đất đai AI, không trộn với Hồ sơ AI tổng hợp.
- [x] Bổ sung danh mục thủ tục: biến động, cấp giấy chứng nhận, chuyển mục đích, tách/hợp thửa, chuyển nhượng, tặng cho, thừa kế, thế chấp, xóa thế chấp, thuế/lệ phí.
- [x] Tạo checklist hồ sơ riêng cho từng thủ tục, có trạng thái đã có/chưa có/tùy trường hợp.
- [x] Liên kết mỗi thủ tục với biểu mẫu, căn cứ pháp lý, nguồn Cổng Dịch vụ công và ngày kiểm tra.
- [x] Cho phép tải lên, xem, tải về, xuất bộ hồ sơ và xóa hồ sơ có xác nhận.
- [x] Thêm AI tìm thủ tục, lập checklist và kiểm tra thiếu/đủ với disclaimer pháp lý.
- [x] Bổ sung test, TypeScript, build, responsive và phát hành checkpoint.

## Sửa lỗi tra cứu HS ĐẤT ĐAI AI — 2026-08-16

- [x] Xác định nguyên nhân truy vấn đã nhập nhưng không hiển thị hồ sơ/thủ tục.
- [x] Sửa logic chuẩn hóa và lọc truy vấn tiếng Việt, bao gồm từ khóa không dấu và cụm “chuyển nhượng đất”.
- [x] Hiển thị kết quả mặc định, gợi ý truy vấn và trạng thái không có kết quả rõ ràng.
- [x] Bổ sung regression test cho tra cứu thủ tục và hồ sơ.
- [x] Kiểm tra TypeScript, Vitest, build, responsive và phát hành bản sửa.

## Mở rộng tìm kiếm Hồ sơ đất đai AI — 2026-08-16

- [x] Xác định các nguồn dữ liệu đang bị giới hạn trong 10 thủ tục mặc định.
- [x] Mở rộng chỉ mục tìm kiếm sang bộ hồ sơ, mẫu biểu, tài liệu đã tải lên, căn cứ pháp lý và nguồn chính thức.
- [x] Cho phép tìm theo tên thủ tục, tên mẫu, từ khóa pháp lý, loại giấy tờ và nội dung hồ sơ.
- [x] Hiển thị kết quả đa nguồn, phân nhóm rõ và giữ 10 thủ tục hiện tại làm gợi ý nhanh.
- [x] Bổ sung regression test, TypeScript, build, responsive và phát hành bản sửa.

## AI tóm tắt và checklist kết quả tìm kiếm — 2026-08-16

- [x] Thêm procedure AI trả về tóm tắt và checklist có cấu trúc cho từng kết quả tìm kiếm.
- [x] Hiển thị nút Tóm tắt AI và Checklist AI ngay trên từng kết quả tìm kiếm Hồ sơ đất đai AI.
- [x] Thêm trạng thái đang xử lý, lỗi, thử lại và lưu kết quả trong phiên làm việc.
- [x] Hiển thị disclaimer pháp lý rõ ràng cho mọi nội dung do AI sinh.
- [x] Bổ sung regression test, TypeScript, build, responsive và phát hành checkpoint.

## Nâng cấp tạo lập Hồ sơ đất đai AI — 2026-08-16
- [x] Tạo khu vực riêng cho Kho biểu mẫu, Tạo lập hồ sơ AI và Hồ sơ của tôi trong /hs-dat-dai-ai.
- [x] Bổ sung lựa chọn thủ tục đất đai và luồng hỏi thông tin theo từng trường hợp.
- [x] Tạo checklist hồ sơ theo các bước điều kiện, công chứng, thuế phí, sang tên và theo dõi xử lý.
- [x] Hiển thị trạng thái Đã có, Còn thiếu, Cần bổ sung và tiến độ của từng hồ sơ.
- [x] Giữ nguyên Hồ sơ AI tổng hợp tại /ho-so-ai, kiểm thử và phát hành.

## Hoàn thiện Tách thửa và Hợp thửa — 2026-08-16
- [x] Kiểm tra dữ liệu, từ khóa tìm kiếm và kết quả của thủ tục Tách thửa.
- [x] Kiểm tra dữ liệu, từ khóa tìm kiếm và kết quả của thủ tục Hợp thửa.
- [x] Bổ sung/hoàn thiện checklist, nguồn chính thức, xem mẫu và tải file nếu còn thiếu.
- [x] Chạy test, kiểm tra preview và phát hành checkpoint sau khi hoàn thiện.

## Tự động điền mẫu Tách thửa và Hợp thửa — 2026-08-16
- [x] Xác định dữ liệu người dùng/hồ sơ có thể ánh xạ vào hai mẫu Tách thửa và Hợp thửa.
- [x] Thêm chức năng tự động điền, giữ ô trống rõ ràng khi thiếu dữ liệu.
- [x] Bổ sung xem trước, chỉnh sửa thủ công và tải mẫu đã điền.
- [x] Thêm cảnh báo kiểm tra thông tin trước khi sử dụng/nộp hồ sơ.
- [x] Chạy test, kiểm tra preview và phát hành checkpoint.

## Nâng cấp Mục 2 — Hồ sơ của tôi theo BĐS — 2026-08-16
- [x] Liên kết Hồ sơ của tôi với dữ liệu bất động sản đã có trong hệ thống.
- [x] Cho phép chọn bất động sản và thủ tục đất đai tương ứng.
- [x] Kiểm tra dữ liệu thiếu theo từng thủ tục và hướng dẫn bổ sung.
- [x] Tạo bộ hồ sơ pháp lý, xem trước, chỉnh sửa, lưu và tải tài liệu.
- [x] Giữ nguyên Mục 1, Hồ sơ AI tổng hợp và kiểm thử/phát hành đầy đủ.

## Hủy và Xóa hồ sơ trong Mục 2 — 2026-08-16
- [x] Thêm thao tác Hủy hồ sơ cho các hồ sơ đã tạo, giữ lại lịch sử và lý do hủy.
- [x] Thêm thao tác Xóa hồ sơ có xác nhận, kiểm tra đúng quyền người dùng.
- [x] Cập nhật trạng thái, bộ lọc và giao diện Hồ sơ của tôi.
- [x] Bổ sung test, kiểm tra preview và phát hành checkpoint.

## Mở rộng Mục 1 — Trình tạo hồ sơ dùng chung — 2026-08-16
- [x] Bổ sung quy trình 6 bước cho thủ tục Chuyển mục đích sử dụng đất trong Mục 1. (Đã được thay thế bằng khung dùng chung trong Mục 2 theo phạm vi cuối cùng.)
- [x] Thêm các nhóm thông tin người sử dụng đất, Giấy chứng nhận, mục đích xin chuyển và giấy tờ đính kèm. (Đã tích hợp trong bộ dữ liệu đa thủ tục của Mục 2.)
- [x] Bổ sung kiểm tra thiếu/đối chiếu dữ liệu, dựng bộ hồ sơ, xem/chỉnh sửa và xuất PDF/DOCX. (Đã tích hợp trong workflow 6 bước của Mục 2.)
- [x] Giữ nguyên Mục 2, Hồ sơ AI tổng hợp và các menu khác; chạy test, preview và phát hành. (Đã xác nhận phạm vi cuối cùng tập trung vào Mục 2.)

## Điều chỉnh phạm vi theo hình tham chiếu — 2026-08-16
- [x] Đưa trình tạo hồ sơ dùng chung vào đúng Mục 2 – Tạo hồ sơ mới.
- [x] Giữ nguyên Mục 1 – Hồ sơ của tôi, Kho biểu mẫu, Hồ sơ AI tổng hợp và các mục khác.
- [x] Kiểm thử riêng Mục 2 và phát hành checkpoint sau khi hoàn thiện.

## Mở rộng khung Mục 2 cho toàn bộ hồ sơ đất đai — 2026-08-16
- [x] Thiết kế khung dữ liệu chung cho tất cả thủ tục hồ sơ đất đai.
- [x] Mở rộng bộ chọn thủ tục và nhóm giấy tờ, không giới hạn ở Tách thửa, Hợp thửa, Chuyển nhượng.
- [x] Tích hợp checklist, kiểm tra thiếu, tài liệu đính kèm, xem/chỉnh sửa và xuất bộ hồ sơ.
- [x] Giữ nguyên Mục 1, Hồ sơ AI tổng hợp và các mục khác; kiểm thử và phát hành checkpoint.

## Triển khai khung hồ sơ đất đai dùng chung trong Mục 2 — 2026-08-16
- [x] Rà soát và chuẩn hóa dữ liệu chung cho mọi hồ sơ đất đai.
- [x] Mở rộng Mục 2 – Tạo hồ sơ mới cho toàn bộ nhóm thủ tục đất đai.
- [x] Tạo bộ hồ sơ, checklist và cảnh báo thiếu theo thủ tục đã chọn.
- [x] Bổ sung xem/chỉnh sửa, tệp đính kèm và xuất hồ sơ.
- [x] Kiểm thử giữ nguyên Mục 1 và các phân hệ khác, sau đó phát hành checkpoint.

## Triển khai khung hồ sơ đất đai dùng chung trong Mục 2 — 2026-08-16
- [x] Rà soát và chuẩn hóa dữ liệu chung cho mọi hồ sơ đất đai.
- [x] Mở rộng Mục 2 – Tạo hồ sơ mới cho toàn bộ nhóm thủ tục đất đai.
- [x] Tạo bộ hồ sơ, checklist và cảnh báo thiếu theo thủ tục đã chọn.
- [x] Bổ sung xem/chỉnh sửa, tệp đính kèm và xuất hồ sơ.
- [x] Kiểm thử giữ nguyên Mục 1 và các phân hệ khác, sau đó phát hành checkpoint.

# Nâng cấp Mục 2 — Hồ sơ đất đai AI đa thủ tục

- [x] Chuẩn hóa khung 6 bước dùng chung cho mọi thủ tục đất đai, không giới hạn ở tách thửa/hợp thửa/chuyển nhượng.
- [x] Bổ sung dữ liệu đầu vào và auto-fill từ BĐS đã chọn cho từng nhóm thủ tục.
- [x] Tạo checklist và tài liệu liên quan theo thủ tục, hiển thị trạng thái đã có/còn thiếu/cần kiểm tra.
- [x] Cho phép rà soát, chỉnh sửa dữ liệu và bản nháp trước khi lưu hồ sơ.
- [x] Xuất bộ hồ sơ hoàn chỉnh có mục lục sang DOCX và bản in lưu PDF.
- [x] Bổ sung test cho quy tắc đa thủ tục, auto-fill, checklist và nội dung xuất hồ sơ.
- [x] Kiểm tra TypeScript, Vitest, build và preview riêng route /hs-dat-dai-ai; bảo đảm /ho-so-ai không bị ảnh hưởng.
- [x] Lưu checkpoint phát hành cho nâng cấp Mục 2.

# Bổ sung chọn thủ tục ở Bước 1 — 2026-08-16

- [x] Thêm nút rõ ràng ở Bước 1 để chọn thủ tục đất đai.
- [x] Cho phép tìm/lọc thủ tục và xem bộ mẫu, quy trình tương ứng trước khi nhập dữ liệu.
- [x] Đồng bộ thủ tục đã chọn với workflow 6 bước và không ảnh hưởng Kho biểu mẫu, Mục 1, Hồ sơ AI tổng hợp.
- [x] Viết test, kiểm tra preview và phát hành checkpoint cho thay đổi này.

# Hiển thị mẫu theo thủ tục — 2026-08-16

- [x] Ánh xạ mỗi thủ tục đất đai với danh sách mẫu hồ sơ và các bước quy trình tương ứng.
- [x] Hiển thị tự động các mẫu ngay trong khung Tạo hồ sơ mới sau khi chọn thủ tục.
- [x] Cho phép xem mẫu, chọn mẫu và tiếp tục nhập dữ liệu theo thủ tục đã chọn.
- [x] Kiểm thử ánh xạ, giao diện và bảo đảm không ảnh hưởng Hồ sơ AI tổng hợp.
- [x] Lưu checkpoint phát hành cho thay đổi hiển thị mẫu theo thủ tục.

# Mở rộng danh sách mẫu theo thủ tục — 2026-08-16

- [x] Bỏ giới hạn cứng 6 mẫu trong ánh xạ thủ tục.
- [x] Hiển thị đầy đủ các mẫu phù hợp, có thể cuộn hoặc mở rộng danh sách khi cần.
- [x] Giữ mẫu ưu tiên ở đầu và tránh đưa mẫu của thủ tục đối nghịch vào kết quả.
- [x] Bổ sung test, kiểm tra preview và phát hành checkpoint.

# Chọn thủ tục trước, hiển thị hồ sơ động — 2026-08-16

- [x] Đặt trạng thái ban đầu là chưa chọn thủ tục, không tự chọn sẵn Hợp thửa.
- [x] Thêm vùng chọn thủ tục bằng AI với danh sách thủ tục rõ ràng.
- [x] Khi chọn thủ tục, hiển thị đúng nội dung hồ sơ, mẫu biểu, checklist và quy trình tương ứng.
- [x] Kiểm thử ví dụ Đăng ký đất đai và các thủ tục khác, giữ nguyên Hồ sơ AI tổng hợp.
- [x] Lưu checkpoint phát hành cho luồng chọn thủ tục mới.

# Xây lại Mục 1 — Tạo hồ sơ mới đầy đủ workflow — 2026-08-16

- [x] Đưa Mục 1 về trạng thái chọn thủ tục trước, không tự chọn thủ tục mặc định.
- [x] Bổ sung nhập/chọn dữ liệu BĐS, người sử dụng đất, thửa đất và giấy tờ.
- [x] Bổ sung AI kiểm tra thiếu dữ liệu và dựng checklist/bộ hồ sơ theo thủ tục.
- [x] Bổ sung xem trước, chỉnh sửa, lưu hồ sơ và theo dõi tiến độ trong Mục 1.
- [x] Bổ sung xuất DOCX/PDF từ dữ liệu đã rà soát.
- [x] Kiểm thử Mục 1, bảo đảm Mục 2 và Hồ sơ AI tổng hợp không bị ảnh hưởng.
- [x] Lưu checkpoint phát hành và hướng dẫn sử dụng Mục 1 mới.

# Sửa Mục 1 chưa hiển thị trong preview — 2026-08-16

- [x] Xác định đúng route/tab của Mục 1 và nguyên nhân giao diện chưa xuất hiện.
- [x] Sửa liên kết/render để Mục 1 hiển thị workflow Tạo hồ sơ mới đầy đủ.
- [x] Kiểm tra trực quan từ chọn thủ tục đến nhập liệu, xem/chỉnh sửa và xuất file.
- [x] Lưu checkpoint sửa lỗi và hướng dẫn mở đúng Mục 1.

# Tách Mục 1 thành workflow đất đai riêng theo bố cục tham chiếu — 2026-08-16

- [x] Giữ bố cục Mục 1 gồm chọn thủ tục, Tìm mẫu, trạng thái workflow 6 bước và vùng nhập dữ liệu như ảnh tham chiếu.
- [x] Tách dữ liệu Mục 1 chỉ dùng cho hồ sơ pháp lý đất đai, không dùng quy trình nguồn hàng/CRM 12 bước.
- [x] Hiển thị mẫu, checklist, AI phân tích, xem/chỉnh sửa và xuất file theo thủ tục đất đai đã chọn.
- [x] Giữ nguyên Mục 2, Hồ sơ AI tổng hợp và các menu nguồn hàng.
- [x] Bổ sung test, kiểm tra preview và phát hành checkpoint.

# Đồng bộ Mục 1 theo bố cục BĐS và thủ tục — 2026-08-16

- [x] Tái tạo khối BĐS của tôi và danh sách BĐS dùng riêng cho hồ sơ đất đai.
- [x] Tái tạo khối Thủ tục cần lập với danh sách thủ tục đất đai.
- [x] Thêm nút Kiểm tra & dựng hồ sơ cho quy trình đất đai riêng.
- [x] Hiển thị khối BĐS đã chọn, dữ liệu đã lấy và trạng thái bộ hồ sơ.
- [x] Giữ nguyên Mục 2, Hồ sơ AI tổng hợp và quy trình nguồn hàng; kiểm thử và phát hành.

# Khóa phạm vi Mục 1 — chỉ hồ sơ đất đai — 2026-08-16

- [x] Sửa lỗi JSX/biên dịch phát sinh ở Mục 1 sau bản chỉnh bố cục.
- [x] Bảo đảm Mục 1 chỉ dùng dữ liệu thủ tục và giấy tờ pháp lý đất đai.
- [x] Loại bỏ mọi liên kết logic với workflow nguồn hàng/CRM 12 bước khỏi Mục 1.
- [x] Kiểm thử Mục 1, Mục 2 và Hồ sơ AI tổng hợp sau khi sửa.
- [x] Lưu checkpoint phát hành cho workspace hồ sơ đất đai riêng.

# Workflow hồ sơ đất đai khép kín — 2026-08-16

- [x] Sửa lỗi JSX hiện tại để Mục 1 biên dịch và hiển thị ổn định.
- [x] Bổ sung nhập/chọn dữ liệu và tải/chụp giấy tờ cho hồ sơ đất đai.
- [x] Hiển thị bước OCR/AI phân tích, phát hiện thiếu và kiểm tra điều kiện hồ sơ.
- [x] Tự dựng bộ hồ sơ, điền biểu mẫu, cho phép rà soát và chỉnh sửa.
- [x] Bổ sung trạng thái xuất/in, ký và chuẩn bị nộp tại bộ phận một cửa.
- [x] Kiểm thử toàn luồng và bảo đảm không ảnh hưởng CRM nguồn hàng, Mục 2 và Hồ sơ AI tổng hợp.
- [x] Lưu checkpoint phát hành cho workflow khép kín.
# Tiếp tục hoàn thiện workflow khép kín Mục 1 — 2026-08-16
- [x] Sửa lỗi JSX hiện tại để Mục 1 biên dịch và hiển thị ổn định.
- [x] Bổ sung vùng tải/chụp giấy tờ đất đai và trạng thái OCR/AI phân tích trong Mục 1.
- [x] Hiển thị kiểm tra thiếu dữ liệu, dựng bộ hồ sơ, rà soát/chỉnh sửa và xuất DOCX/PDF.
- [x] Bổ sung trạng thái chuẩn bị in, ký và nộp tại bộ phận một cửa.
- [x] Kiểm thử toàn luồng Mục 1, Mục 2, Hồ sơ AI tổng hợp và CRM nguồn hàng.
- [x] Lưu checkpoint phát hành sau khi xác nhận preview.

# Tách riêng khối Chọn thủ tục Mục 1 — 2026-08-16
- [x] Bỏ phần chọn thủ tục/tìm mẫu khỏi panel màu xanh hiện tại.
- [x] Tạo khối Bước 1 · Chọn thủ tục riêng với đầy đủ thủ tục đất đai.
- [x] Khi chọn thủ tục, hiển thị AI phân tích, yêu cầu hồ sơ và quy trình tương ứng.
- [x] Giữ nguyên workflow tải giấy tờ, nhập dữ liệu, dựng hồ sơ, xuất file và trạng thái in–ký–nộp.
- [x] Kiểm thử TypeScript/Vitest, preview Mục 1 và phát hành checkpoint.

# Loading OCR và phân tích AI — 2026-08-16
- [x] Thêm trạng thái loading khi tải/chụp giấy tờ và OCR đang xử lý.
- [x] Thêm thanh tiến trình theo giai đoạn OCR → chuẩn hóa dữ liệu → phân tích thiếu hồ sơ.
- [x] Hiển thị bước hiện tại, phần trăm, trạng thái hoàn tất/lỗi và giữ tương thích với workflow Mục 1.
- [x] Kiểm thử TypeScript, Vitest, preview và lưu checkpoint phát hành.

# Tìm kiếm thủ tục AI trong Bước 1 — 2026-08-16
- [x] Chuyển danh sách thủ tục thành ô tìm kiếm/chọn có thể gõ từ khóa.
- [x] Hiển thị kết quả thủ tục có sẵn theo từ khóa, hỗ trợ có dấu/không dấu.
- [x] Thêm nút AI tìm thủ tục liên quan đất đai và đưa kết quả vào cùng khung chọn.
- [x] Giữ nối lựa chọn vào phân tích AI, workflow OCR và tiến trình xử lý hiện có.
- [x] Kiểm thử và phát hành checkpoint.

# Nhập và quét dữ liệu đầu vào Mục 1 — 2026-08-16
- [x] Xóa khối “BĐS dùng để tự điền hồ sơ” khỏi Mục 1.
- [x] Xóa Bước 2 nhập thủ công hiện tại.
- [x] Tạo khối mới nhập thông tin đầu vào và tải/chụp ảnh giấy tờ.
- [x] Hỗ trợ tải video/tư liệu hiện trường để AI ghi nhận dữ liệu liên quan.
- [x] Nối OCR/loading với việc tự cập nhật dữ liệu hồ sơ.
- [x] Cho AI phân tích dữ liệu đã quét và dựng bộ hồ sơ theo thủ tục.
- [x] Kiểm thử, preview và lưu checkpoint phát hành.

# Phân hệ AI cấp Giấy chứng nhận riêng — 2026-08-16
- [x] Tạo phân hệ riêng cạnh Mục 1, không dùng CRM 12 bước và không phụ thuộc quy trình nguồn hàng.
- [x] Tạo quy trình 10 bước: chọn thủ tục, nhập thông tin, chụp/tải giấy tờ, OCR, kiểm tra AI, dựng bộ hồ sơ, rà soát, kiểm tra cuối, xuất, quản lý hồ sơ.
- [x] Ưu tiên nhóm thủ tục cấp Giấy chứng nhận lần đầu, cấp đổi/cấp lại và đăng ký biến động liên quan.
- [x] Tạo màn hình nhập liệu động theo từng thủ tục, hỗ trợ ảnh/video/tài liệu và OCR.
- [x] Bổ sung xem trước, chỉnh sửa, xác nhận kết quả OCR trước khi tự điền biểu mẫu.
- [x] Bổ sung AI kiểm tra đủ/thiếu/mâu thuẫn và màn hình kiểm tra trước khi xuất.
- [x] Bổ sung bộ hồ sơ tự điền, xuất DOCX/PDF, in–ký–nộp và quản lý hồ sơ riêng.
- [x] Kiểm thử TypeScript, Vitest, preview và lưu checkpoint phát hành.

# Lưu nháp tiến trình hồ sơ đất đai — 2026-08-16
- [x] Lưu nháp thủ tục, bước hiện tại và toàn bộ dữ liệu nhập của hồ sơ.
- [x] Bảo toàn kết quả OCR đã xác nhận, chứng từ và trạng thái phân tích khi lưu nháp.
- [x] Tự động lưu khi dữ liệu thay đổi và có nút lưu nháp thủ công với trạng thái rõ ràng.
- [x] Hiển thị danh sách hồ sơ nháp và nút Tiếp tục để khôi phục đúng tiến trình.
- [x] Cho phép xóa nháp có xác nhận, không ảnh hưởng hồ sơ đã hoàn tất.
- [x] Kiểm thử, preview, cập nhật todo và lưu checkpoint phát hành.

# Mở rộng Bước 1 Trung tâm AI cấp Giấy chứng nhận — 2026-08-16
- [x] Bổ sung đầy đủ trường hợp đăng ký biến động đất đai và cấp Giấy chứng nhận.
- [x] Bổ sung chuyển mục đích, tách thửa, hợp thửa, chuyển nhượng, thừa kế và tặng cho.
- [x] Bổ sung đăng ký/xóa đăng ký thế chấp và thuế–phí liên quan.
- [x] Làm cho mô tả, trường OCR, checklist và phân tích AI thay đổi theo trường hợp đã chọn.
- [x] Kiểm thử, preview, cập nhật todo và lưu checkpoint phát hành.

# Tinh gọn Hồ sơ của tôi — 2026-08-16
- [x] Xóa khối Checklist hồ sơ khỏi phần Hồ sơ của tôi.
- [x] Xóa khối Tìm kiếm mẫu hồ sơ khỏi phần Hồ sơ của tôi.
- [x] Giữ nguyên dữ liệu hồ sơ, thao tác xem/chỉnh sửa/xuất và các phân hệ AI khác.
- [x] Kiểm thử TypeScript, Vitest, preview và lưu checkpoint phát hành.

# Điều chỉnh phạm vi xóa giao diện — 2026-08-16
- [x] Chỉ xóa khối Checklist hồ sơ đúng theo ảnh tham chiếu.
- [x] Giữ nguyên khối tài liệu BĐS quản lý, tải file/camera, tài liệu đã lưu và các phần khác.
- [x] Khôi phục phần Tìm kiếm mẫu hồ sơ nếu lần chỉnh trước đã xóa nhầm ngoài phạm vi yêu cầu.
- [x] Kiểm thử, preview, cập nhật todo và lưu checkpoint.

# Xóa thêm BĐS quản lý trong Hồ sơ của tôi — 2026-08-16
- [x] Xóa khối BĐS quản lý khỏi phần Hồ sơ của tôi.
- [x] Giữ nguyên khối tài liệu, tải file/camera, tài liệu đã lưu và các phần khác.
- [x] Kiểm thử, preview, cập nhật todo và lưu checkpoint.

# Chỉ xóa Tài liệu của BĐS — 2026-08-16
- [x] Xóa riêng section “Tài liệu của BĐS” theo ảnh tham chiếu.
- [x] Giữ nguyên “Tài liệu đã lưu”, kết quả tìm kiếm, AI tra cứu pháp lý và các phần khác.
- [x] Kiểm thử TypeScript, Vitest và preview; cập nhật checkpoint.

Đề nghị chỉ xóa giao diện section “Tài liệu của BĐS”, không xóa dữ liệu lưu trữ hay logic quản lý file nền.

# Xóa các khối trong Mục 1 · Tạo hồ sơ mới — 2026-08-16
- [x] Xóa khối “AI lập bộ hồ sơ cho bạn” theo ảnh.
- [x] Xóa khối “Bước 1.5 · Chứng từ đất đai” theo ảnh.
- [x] Xóa khối “Nguồn dữ liệu đầu vào” theo ảnh.
- [x] Xóa khối “Bước 2 · Nhập và quét dữ liệu đầu vào” theo ảnh.
- [x] Giữ nguyên khối chọn thủ tục, hồ sơ của tôi, Trung tâm AI cấp Giấy chứng nhận và các phần khác.
- [x] Kiểm thử TypeScript, Vitest, preview và cập nhật checkpoint.

# Xóa Tài liệu đã lưu ở hai phần — 2026-08-16
- [x] Xác định hai vị trí giao diện có mục “Tài liệu đã lưu”.
- [x] Xóa riêng mục “Tài liệu đã lưu” ở cả hai vị trí theo ảnh.
- [x] Giữ nguyên thẻ hồ sơ, tìm kiếm, nút Tải file và AI tra cứu pháp lý.
- [x] Kiểm thử TypeScript, Vitest, preview và cập nhật checkpoint.

# Màu riêng cho từng thẻ Nguồn hàng — 2026-08-16
- [x] Rà soát component hiển thị danh mục Nguồn hàng đa dạng.
- [x] Áp dụng một màu nền/điểm nhấn riêng cho từng loại nguồn hàng.
- [x] Giữ nguyên nội dung, biểu tượng, bố cục và hành vi lọc/chọn.
- [x] Kiểm thử responsive, TypeScript, Vitest, preview và cập nhật checkpoint.

# Hover chi tiết cho thẻ Nguồn hàng — 2026-08-16
- [x] Bổ sung mô tả ngắn cho từng loại nguồn hàng.
- [x] Hiển thị mô tả khi hover/focus vào thẻ, hỗ trợ desktop và bàn phím.
- [x] Giữ nguyên màu riêng, bố cục và hành vi chọn/lọc.
- [x] Kiểm thử TypeScript, Vitest, responsive, preview và cập nhật checkpoint.

# Phân quyền khu vực quản lý — 2026-08-16
- [x] Chỉ admin/chủ website được truy cập các trang Quản lý nguồn hàng, Hồ sơ AI, HS ĐẤT ĐAI AI, CRM và kho hồ sơ.
- [x] Người dùng thường chỉ thấy Mua BĐS, chi tiết BĐS và luồng gửi liên hệ.
- [x] Thêm chặn route và trạng thái hướng dẫn đăng nhập/không đủ quyền phù hợp.
- [x] Ẩn menu nội bộ với người dùng không phải admin.
- [x] Kiểm thử quyền, TypeScript, Vitest, preview và cập nhật checkpoint.

# Trang lỗi 403 thân thiện — 2026-08-16
- [x] Rà soát trạng thái 403 và luồng đăng nhập hiện tại.
- [x] Thiết kế trang 403 thân thiện, giải thích rõ lý do bị giới hạn quyền.
- [x] Thêm nút Đăng nhập và nút quay về Mua BĐS.
- [x] Kiểm thử điều hướng, TypeScript, Vitest, responsive và cập nhật checkpoint.

# Checklist trước khi in hồ sơ — 2026-08-16
- [x] Rà soát bước rà soát/xuất hồ sơ trong Trung tâm AI.
- [x] Tạo checklist kiểm tra nhanh giấy tờ, dữ liệu, chữ ký và bản sao.
- [x] Cho phép đánh dấu từng mục, hiển thị mục còn thiếu và chặn/nhắc trước khi in.
- [x] Kiểm thử checklist, TypeScript, Vitest, preview và cập nhật checkpoint.

# Tải checklist PDF — 2026-08-16
- [x] Thêm nút tải checklist hiện tại dưới dạng PDF.
- [x] Đảm bảo PDF phản ánh đúng thủ tục, các mục checklist và trạng thái đã đánh dấu.
- [x] Kiểm thử tải file, TypeScript, Vitest, preview và cập nhật checkpoint.

# Xóa yêu cầu tư vấn đã xem/đã liên hệ — 2026-08-17
- [x] Chỉ hiển thị nút Xóa cho yêu cầu có trạng thái Đã xem hoặc Đã liên hệ.
- [x] Thêm hộp xác nhận trước khi xóa và cập nhật danh sách sau khi xóa.
- [x] Giữ nguyên yêu cầu Mới/chưa xử lý và kiểm soát quyền xóa trong khu vực quản trị.
- [x] Kiểm thử xóa, TypeScript, Vitest, preview và cập nhật checkpoint.

- [x] Redesign trang chủ công khai theo ảnh tham chiếu: header responsive, hero “Nguồn hàng đa dạng”, bộ lọc và điều hướng rõ trên mobile/desktop.
- [x] Cập nhật khu vực nguồn hàng với thẻ danh mục màu sắc, biểu tượng và hành vi chọn/lọc phù hợp.
- [x] Cập nhật khu vực sản phẩm bất động sản nổi bật với card responsive, hình ảnh, vị trí, giá và thông tin nhanh.
- [x] Kiểm tra visual desktop/mobile, TypeScript và Vitest sau redesign trang chủ.

- [x] Thay hero đầu trang bằng dashboard “Nguồn hàng” theo ảnh tham chiếu, bỏ dòng Đà Nẵng · Miền Trung và bộ tìm kiếm hero cũ.
- [x] Thêm header dashboard, các nút thao tác, thẻ tổng quan nguồn hàng và panel thông báo responsive.
- [x] Thêm bộ lọc/tìm kiếm nguồn hàng và card sản phẩm theo bố cục mới, bảo toàn dữ liệu và CTA hiện có.
- [x] Kiểm tra desktop/mobile, regression TypeScript/Vitest và đảm bảo các section cũ phía dưới vẫn giữ nguyên.
- [x] Giữ nguyên hoàn toàn section “Nguồn hàng / Bất động sản nổi bật”, chỉ chèn dashboard mới ở phía trên và kiểm tra regression giao diện.

- [x] Thêm AI phân tích tự động yêu cầu tư vấn mới: nhu cầu, loại BĐS, khu vực, ngân sách, thời hạn và mức độ ưu tiên.
- [x] Lưu kết quả phân tích AI, trạng thái xử lý và thời điểm phân tích để xem lại trong mục Yêu cầu tư vấn.
- [x] Gửi thông báo cho chủ website khi có yêu cầu mới hoặc khi AI phát hiện nhu cầu ưu tiên cao.
- [x] Cập nhật giao diện Yêu cầu tư vấn với nhãn AI, tóm tắt nhu cầu, mức ưu tiên và bộ lọc.
- [x] Viết/chạy Vitest và kiểm tra TypeScript cho luồng phân tích, thông báo và hiển thị kết quả.

- [x] Tạo phân hệ riêng “AI Quản lý nhu cầu” trong khu vực Yêu cầu tư vấn, gồm Yêu cầu mới, Khách tiềm năng, AI ghép nhu cầu và Thông báo.
- [x] Cho phép AI hỏi bổ sung loại BĐS, khu vực, ngân sách, mục đích, diện tích, phòng ngủ và thời điểm mua để tạo hồ sơ nhu cầu.
- [x] Phân loại tự động Ưu tiên cao, Tiềm năng và Tham khảo; sắp xếp khách ưu tiên lên trên.
- [x] Ghép nhu cầu với nguồn hàng hiện có theo loại BĐS, khu vực, ngân sách, diện tích và pháp lý nếu có dữ liệu.
- [x] Hiển thị thông báo chi tiết cho admin gồm khách, nhu cầu, mức ưu tiên, BĐS phù hợp và nút xem yêu cầu/liên hệ.

- [x] Thu gọn các thẻ Nguồn hàng theo kích thước và phong cách nút “Thêm nguồn hàng”, tránh chiếm quá nhiều chiều cao.
- [x] Chia khu vực tìm kiếm BĐS thành các cột dữ liệu gọn: từ khóa, loại BĐS, khu vực, mức giá, diện tích và pháp lý.
- [x] Thêm panel Thông báo yêu cầu tư vấn ở góc phải cạnh khu vực thao tác, có số lượng, bản tóm tắt và nút xem chi tiết.
- [x] Kiểm tra responsive desktop/mobile, TypeScript và Vitest sau khi chỉnh giao diện Nguồn hàng.

- [x] Thêm luồng AI tự động hỏi bổ sung khách về loại BĐS, khu vực, ngân sách, mục đích và thời gian mua.
- [x] Hiển thị câu trả lời AI và các đề xuất bất động sản phù hợp trong cuộc hội thoại tư vấn.
- [x] Gửi thông báo admin khi khách hoàn tất hồ sơ nhu cầu hoặc được AI đánh giá ưu tiên cao.
- [x] Thêm nút chuyển cuộc hội thoại từ AI sang môi giới và trạng thái đã tiếp nhận/đang tư vấn.
- [x] Bảo đảm quyền riêng tư, chỉ hiển thị dữ liệu tư vấn cho đúng khách và admin; viết/chạy Vitest và kiểm tra TypeScript.

- [x] Thêm khu vực trả lời tự động trên từng yêu cầu tư vấn theo mẫu tham chiếu.
- [x] Thêm nút AI soạn tin, soạn thủ công, trạng thái AI đang phân tích/đã liên hệ và chọn trạng thái tiếp nhận.
- [x] Thêm nút Sao chép, Gửi qua Zalo và Gọi điện với nội dung tin nhắn được soạn sẵn.
- [x] Lưu/hiển thị nội dung phản hồi và trạng thái xử lý theo quyền admin; kiểm thử responsive, TypeScript và Vitest.

- [x] Sắp xếp 5 mục Nguồn hàng và nút Thông báo thành một hàng ngang nhỏ gọn ở đầu dashboard.
- [x] Giữ màu sắc, biểu tượng, số liệu và thao tác chọn/lọc của từng mục; không làm mất bộ lọc và sản phẩm nổi bật.
- [x] Bảo đảm hàng thẻ co giãn trên mobile, có thể cuộn ngang hoặc chuyển thành lưới gọn khi màn hình hẹp.
- [x] Kiểm tra TypeScript, Vitest và preview desktop/mobile sau khi chỉnh bố cục.

- [x] Thu gọn 6 mục nguồn hàng thành một hàng ngang nhỏ theo phong cách mục Ký gửi ở đầu trang.
- [x] Thu nhỏ 4 nút Kho nguồn hàng/Thêm nguồn hàng/Tìm nguồn hàng/Thêm theo cùng tỷ lệ compact.
- [x] Thiết kế toàn bộ bộ tìm kiếm thành một hàng ngang trên desktop và bố cục cuộn/gọn trên mobile.
- [x] Kiểm tra TypeScript, Vitest và preview desktop/mobile sau khi chỉnh layout.

- [x] Điều chỉnh SourceDashboard theo mẫu mobile: tiêu đề, thông báo, 4 nút thao tác và nhóm thẻ nguồn hàng gọn.
- [x] Thiết kế bộ lọc ngang cuộn được trên mobile, giữ lại các trường tìm kiếm hiện có.
- [x] Bổ sung/điều chỉnh trạng thái trống nguồn hàng với minh họa, hướng dẫn và nút Thêm nguồn hàng.
- [x] Giữ nguyên dữ liệu, quyền admin, trợ lý AI và khu vực sản phẩm nổi bật; kiểm tra desktop/mobile, TypeScript và Vitest.

- [x] Thu nhỏ thanh nội bộ gồm 6 mục nguồn hàng và Thông báo thành một hàng ngang gọn giống phong cách Ký gửi/Mua BĐS/Tư vấn.
- [x] Giữ nguyên thanh điều hướng phía trên, dữ liệu, màu sắc, biểu tượng và thao tác của từng mục.
- [x] Kiểm tra responsive trên desktop/mobile, TypeScript và Vitest sau khi chỉnh thanh nội bộ.

- [x] Trên mobile hiển thị đầy đủ Nguồn hàng, Tìm kiếm, 4 mục nguồn hàng và các thanh bất động sản; không ẩn khu vực do breakpoint.
- [x] Sắp xếp các khu vực theo hàng dọc hoặc hàng cuộn ngang nhỏ gọn, tránh tràn và vẫn xem được toàn bộ thao tác.
- [x] Kiểm tra mobile thực tế, desktop, TypeScript và Vitest sau khi sửa responsive.

- [x] Bỏ wrapper Workspace trong khu vực Nguồn hàng.
- [x] Đưa 4 nút thao tác vào hàng nhỏ ngay dưới thanh menu xanh.
- [x] Gom 6 mục nguồn hàng và Thông báo tư vấn thành một thanh ngang compact bên dưới hàng thao tác.
- [x] Tối ưu hiển thị mobile bằng cuộn ngang có thể quan sát đầy đủ, tương tự thanh menu xanh.

- [x] Thu nhỏ thêm chiều cao, cỡ chữ, icon và khoảng cách của các hàng Source Dashboard theo phản hồi người dùng.
- [x] Kiểm tra lại khả năng quan sát đầy đủ trên mobile sau khi thu nhỏ.

- [x] Gom mỗi nhóm thao tác Source Dashboard thành một thanh ngang duy nhất, không xuống dòng trên mobile.

- [x] Đưa thanh Thông báo lên phía trên, ngay dưới khu vực Đăng ký.
- [x] Gom 3 mục nguồn hàng còn lại thành một thanh ngang đồng bộ với thanh 4 mục đầu tiên.

- [x] Kiểm tra và cho phép người dùng zoom trang trên thiết bị mobile.
- [x] Xác nhận zoom không làm vỡ bố cục responsive.

- [x] Đổi nhãn nguồn hàng thành Tôi, Cộng tác, Thị trường, Nổi bật và Yêu thích.
- [x] Thu gọn 5 mục nguồn hàng để hiển thị trọn trong một thanh duy nhất, không kéo ngang.

- [x] Thêm mục Tìm kiếm pháp lý vào bộ lọc nguồn hàng.
- [x] Thêm mục Diện tích và thu gọn các trường bộ lọc thành một thanh ngang giống thanh menu xanh.

- [x] Gom nút Tìm kiếm vào cùng một thanh ngang với các bộ lọc nguồn hàng, không tách thành dòng riêng.

- [x] Cố định toàn bộ bộ lọc nguồn hàng trong một thanh duy nhất, không cho kéo ngang trên mobile.

- [x] Gom Thêm nguồn hàng, Kho nguồn hàng, Tìm nguồn hàng, Thêm và một nút Thông báo tròn vào một hàng duy nhất không cuộn.
- [x] Đặt nút Thông báo ở phía trên cùng của hàng thao tác và thu gọn nhãn trên mobile.

- [x] Khi bấm nút Thông báo, mở trực tiếp danh sách yêu cầu tư vấn mới/chưa xử lý.
- [x] Hiển thị badge số lượng yêu cầu chưa xử lý trên nút Thông báo tròn.

- [x] Khảo sát các trang và breakpoint để phát hiện tràn ngang, nội dung bị che hoặc nút khó thao tác.
- [x] Xây dựng cơ chế AI UI Optimization kiểm tra và đề xuất tối ưu Responsive/Mobile-first.
- [x] Tích hợp thao tác áp dụng tối ưu bố cục theo từng trang hoặc toàn website cho admin.
- [x] Kiểm tra lại mobile, tablet và desktop sau khi tối ưu.

- [x] Loại bỏ khu vực Quản lý nguồn hàng khỏi trang đầu theo ảnh tham chiếu.
- [x] Giữ thanh menu công khai, bất động sản nổi bật và các nội dung khách hàng trên trang đầu.
- [x] Kiểm tra responsive sau khi bỏ Source Dashboard.

- [x] Thu nhỏ các thẻ danh mục bất động sản khoảng một nửa kích thước hiện tại.
- [x] Chia 10 danh mục thành hai hàng ngang gọn, responsive trên mobile.

- [x] Thu nhỏ tiêu đề Nguồn hàng chính chủ và Bất động sản nổi bật khoảng một phần ba.
- [x] Thu nhỏ toàn bộ thẻ Nhà phố đến Cho thuê khoảng một phần ba nhưng vẫn dễ đọc trên mobile.

- [x] Đổi riêng thẻ sản phẩm trong Bất động sản nổi bật sang bố cục ngang: ảnh trái, thông tin phải.
- [x] Giữ nguyên các khu vực khác của trang chủ và kiểm tra responsive.

- [x] Thay logo đầu trang bằng logo mới do người dùng cung cấp.
- [x] Gom logo, nút gọi, nút Thông báo và nút menu 3 gạch vào cùng một thanh responsive.
- [x] Kiểm tra kích thước logo và thao tác các nút trên mobile/desktop.

- [x] Tải logo mới của Bất động sản xanh lên webdev storage và tích hợp URL lưu trữ ổn định.
- [x] Refactor header trang chủ thành một hàng compact gồm logo, nút gọi tròn, nút thông báo tròn và nút menu tròn.
- [x] Giữ nút thông báo liên kết tới `/quan-ly#yeu-cau-moi`, menu responsive và quyền truy cập quản lý nguồn hàng.
- [x] Đảm bảo header nằm trên widget AI nổi để logo không bị che trên mobile; kiểm tra preview 390px.
- [x] Chạy TypeScript và Vitest: 126/126 bài test đạt.

# Đồng bộ giao diện nội bộ theo mẫu compact — 2026-08-17
- [x] Tinh gọn layout dùng chung cho các màn hình nội bộ nhưng giữ nguyên dữ liệu, route và nghiệp vụ.
- [x] Đồng bộ các khung và biểu mẫu của Kho lưu trữ hồ sơ, Đăng ký tư vấn, Quản lý môi giới và Quy trình môi giới 12 bước.
- [x] Đồng bộ các khung và biểu mẫu của Hồ sơ đất đai AI, Hồ sơ AI và Hồ sơ điện tử.
- [x] Kiểm tra responsive mobile/desktop, khả năng thao tác và không tràn ngang.
- [x] Chạy TypeScript, Vitest và lưu checkpoint phát hành.

# Giao diện sản phẩm đất nền đang đăng — 2026-08-17
- [x] Rà soát route, dữ liệu và component danh sách sản phẩm đất nền hiện có.
- [x] Tạo thanh tìm kiếm, bộ lọc và trạng thái xác thực compact theo mẫu tham chiếu.
- [x] Thiết kế thẻ sản phẩm đất nền với ảnh chính/ảnh phụ, giá, diện tích, vị trí và nút liên hệ.
- [x] Giữ và kết nối thao tác Danh sách/Bản đồ, yêu thích, xem ảnh/video và hiển thị số điện thoại.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint.

# Chỉnh CTA liên hệ sản phẩm đất nền — 2026-08-17
- [x] Đổi nhãn nút “Hiện số” thành “Gọi” trong thẻ sản phẩm đất nền.
- [x] Sắp xếp hàng CTA Gọi/Xem chi tiết/Zalo/Messenger/Facebook responsive, không che lấp trên mobile.
- [x] Điều chỉnh khoảng an toàn với trợ lý AI nổi và kiểm tra desktop/mobile.
- [x] Chạy TypeScript, Vitest và lưu checkpoint.

# Trang Nguồn hàng chính chủ — Đất nền — 2026-08-17
- [x] Xác định route và dữ liệu sản phẩm đất nền chính chủ hiện có.
- [x] Dựng giao diện mobile-first theo mẫu: header tìm kiếm, ảnh lớn, nhãn Đất nền, yêu thích và trạng thái Đã xem.
- [x] Hiển thị thông tin giá, diện tích, vị trí, người đăng và CTA Gọi/Xem chi tiết/Zalo/Messenger/Facebook.
- [x] Giữ trợ lý AI và thanh chuyển Danh sách/Bản đồ không che nội dung.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint.

# Chỉ tinh chỉnh card Đất nền trên trang chủ — 2026-08-17
- [x] Khoanh vùng card Đất nền trong khu vực Bất động sản nổi bật.
- [x] Áp dụng riêng bố cục ảnh, nhãn, giá, vị trí, CTA và thanh Danh sách/Bản đồ theo mẫu.
- [x] Bảo đảm các danh mục bất động sản khác không thay đổi dữ liệu hoặc giao diện.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint.

# Card Đất nền theo mẫu thẻ xanh mới — 2026-08-17
- [x] Đổi riêng card Đất nền sang bố cục nền kem, thẻ xanh lớn và nhãn “Đất”.
- [x] Sắp xếp lại thông tin vị trí, tiêu đề, ngày đăng, giá, diện tích và CTA theo mẫu mới.
- [x] Giữ nguyên dữ liệu, thao tác liên hệ và không ảnh hưởng các danh mục khác.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint.

# Tự động đồng bộ sản phẩm công khai theo danh mục — 2026-08-17
- [x] Khi bài đăng chuyển sang Công khai, tự động hiển thị bài trong đúng nhóm Bất động sản nổi bật.
- [x] Khi bài chuyển Nháp/Ẩn hoặc bị xóa, tự động loại khỏi nhóm hiển thị công khai tương ứng.
- [x] Bảo đảm Nhà phố và các danh mục khác không bị trộn dữ liệu hoặc thay đổi giao diện.
- [x] Bổ sung kiểm tra điều kiện hiển thị và trạng thái đồng bộ cho quản trị viên.
- [x] Chạy TypeScript, Vitest và lưu checkpoint.

# Trang Xem chi tiết sản phẩm bất động sản — 2026-08-17
- [x] Rà soát PropertyDetail và dữ liệu sản phẩm hiện có.
- [x] Thiết kế gallery ảnh, tiêu đề, giá, diện tích, vị trí, pháp lý và mô tả theo bố cục marketplace responsive.
- [x] Tích hợp CTA Gọi/Zalo/Messenger/Đặt lịch, yêu thích, chia sẻ và bản đồ mà không che nội dung.
- [x] Giữ nguyên dữ liệu, route và các trang khác; kiểm tra mobile/desktop.
- [x] Chạy TypeScript, Vitest và lưu checkpoint.

# Sửa lỗi trang Xem chi tiết sản phẩm — 2026-08-17
- [x] Xác định nguyên nhân lỗi route/dữ liệu/render ở trang Xem chi tiết.
- [x] Sửa trạng thái không tìm thấy, lỗi ảnh hoặc lỗi CTA nếu có.
- [x] Kiểm tra bằng route mẫu, TypeScript và Vitest; route mẫu không còn lỗi console và 128/128 Vitest đạt.
- [x] Lưu checkpoint sau khi khắc phục; phiên bản `5d233ac8`.

# Sửa lỗi React #310 trang Xem chi tiết — 2026-08-17
- [x] Rà soát toàn bộ hook và nhánh render trong PropertyDetail.
- [x] Loại bỏ mọi useMemo/hook được gọi không ổn định khi dữ liệu loading hoặc rỗng.
- [x] Kiểm tra preview route, TypeScript và Vitest sau khi sửa; build Vite bị giới hạn heap sandbox ở bước rendering chunks, không ghi nhận lỗi TypeScript/runtime.
- [x] Lưu checkpoint bản sửa lỗi; phiên bản `5d233ac8`.

# Đặt lịch xem và Messenger trên PropertyDetail — 2026-08-17
- [x] Khi bấm Đặt lịch xem, mở biểu mẫu yêu cầu tư vấn có thông tin bất động sản và lịch hẹn.
- [x] Lưu yêu cầu đặt lịch vào luồng tư vấn hiện có và làm mới số/thông báo yêu cầu trên đầu trang.
- [x] Thêm nút Messenger cùng hàng với Zalo trong các cụm CTA của PropertyDetail, giữ responsive mobile.
- [x] Bổ sung test cho payload đặt lịch, CTA Messenger và trạng thái thông báo; TypeScript không lỗi, 130/130 Vitest đạt, preview mobile đã kiểm tra; chờ checkpoint phát hành.

# AI tối ưu responsive trang chủ — 2026-08-17
- [x] Rà soát trang chủ ở desktop, tablet và mobile bằng screenshot để xác định vùng bài đăng bị kéo dài hoặc tràn bố cục.
- [x] Chuyển khu vực bài đăng sang lưới thích ứng 4 cột desktop, 2 cột tablet và 1 cột mobile.
- [x] Thu gọn chiều cao card, ảnh, tiêu đề, thông số và CTA để bài đăng cân đối trên từng breakpoint.
- [x] Kiểm tra toàn bộ trang chủ ở ba chế độ, cập nhật test và lưu checkpoint phát hành; checkpoint `dba7257d`.

# Tích hợp nguồn pháp lý chính thức cho Hồ sơ đất đai AI — 2026-08-17
- [x] Khảo sát Cổng Dịch vụ công Quốc gia, cổng địa phương và nguồn văn bản pháp luật chính thức liên quan hồ sơ đất đai; lưu tại `legal-research-notes.md`.
- [x] Xác định dữ liệu cần lưu: URL nguồn, mã thủ tục, cơ quan ban hành, ngày hiệu lực, phiên bản biểu mẫu và ngày kiểm tra.
- [x] Thiết kế cơ chế đồng bộ/kiểm duyệt nguồn, không tự coi nội dung AI là văn bản được cơ quan nhà nước chứng nhận.
- [x] Đề xuất cách hiển thị nguồn, cảnh báo phiên bản và trạng thái “bản dự thảo — cần rà soát/ký trước khi nộp”.
- [x] Chỉ triển khai code sau khi chốt nguồn dữ liệu và phương án tích hợp an toàn; đã bổ sung bộ chọn nguồn và helper metadata trong AIDossierAdmin.

# Chọn và áp dụng văn bản pháp lý mới nhất — 2026-08-17
- [x] Tạo danh mục nguồn ưu tiên gồm Luật Đất đai, nghị định và thủ tục từ nguồn Chính phủ/Cổng Dịch vụ công.
- [x] Lưu metadata văn bản: số hiệu, loại, ngày ban hành, ngày hiệu lực, nguồn URL, phạm vi áp dụng và trạng thái kiểm duyệt.
- [x] Tạo giao diện AI cho phép tìm/chọn văn bản chính thức theo thủ tục đất đai và chỉ dùng nguồn đã xác minh metadata.
- [x] Hiển thị nguồn, phiên bản, ngày kiểm tra và cảnh báo dự thảo trước khi người dùng xuất/in hồ sơ.
- [x] Bổ sung test nguồn và metadata; TypeScript không lỗi, 132/132 Vitest đạt; phần phát hành nền tảng chờ checkpoint.

# Hồ sơ đất đai theo biểu mẫu chính thức — 2026-08-17
- [x] Lọc nguồn theo Luật Đất đai, nghị định và thủ tục chính thức đã xác minh trước khi tạo hồ sơ.
- [x] Mô hình hóa từng thủ tục gồm điều kiện, trình tự, thành phần hồ sơ và biểu mẫu tương ứng trong workflow 6 bước.
- [x] Tạo biểu mẫu theo nguồn chính thức, không dùng nội dung AI tự suy đoán làm mẫu pháp lý.
- [x] Cho người dùng xem trước, chỉnh sửa và xác nhận bản nháp từng biểu mẫu trước khi ghép bộ hồ sơ.
- [x] Xuất bản xem trước để in kiểm tra; chỉ mở bản xuất cuối sau khi người dùng xác nhận và hiển thị đầy đủ nguồn, phiên bản, ngày kiểm tra.
- [x] Bổ sung test nguồn, phiên bản và cảnh báo; 132/132 Vitest đạt; luồng xuất chính thức vẫn cần hoàn thiện.

- [x] Mapping biểu mẫu đất đai theo từng thủ tục với metadata file gốc, trạng thái nguồn và liên kết tra cứu; hiển thị trực tiếp trong Mục 1.
- [x] Thêm xác nhận hai lớp cho Certificate AI: rà soát OCR/checklist, xác nhận bản nháp, rồi mới mở khóa DOCX/PDF/in.
- [x] Chỉ ghi nhãn OFFICIAL có điều kiện sau xác nhận người dùng và nêu rõ đây không phải chứng nhận của cơ quan nhà nước.
- [x] Hủy xác nhận lớp hai khi người dùng tải tài liệu mới, sửa dữ liệu OCR hoặc đổi thủ tục.
- [x] Bổ sung test hồi quy mapping mẫu chính thức; TypeScript và 133/133 Vitest đạt.
- [x] Kiểm tra trực quan preview header và test notification/CTA: đặt lịch được đưa vào badge thông báo, nút Gọi dùng 0989 682 825; production cần phiên admin và dữ liệu thật để kiểm tra bổ sung.

# Mở rộng bộ nguồn pháp lý tự động — 2026-08-17
- [x] Tự gom bộ nguồn pháp lý và biểu mẫu liên quan sau khi người dùng chọn thủ tục, không bắt người dùng chọn từng nghị định.
- [x] Hiển thị nút xem toàn bộ nguồn được AI sử dụng, phân nhóm thủ tục, luật, nghị định/thông tư và biểu mẫu.
- [x] Bổ sung test cho bộ nguồn tự động và danh sách nguồn hiển thị trong bản xem trước.

# Tích hợp thông tin thủ tục theo tỉnh/thành — 2026-08-17
- [x] Xác định dữ liệu dùng chung và dữ liệu thay đổi theo tỉnh/thành phố, gồm mã thủ tục, cơ quan tiếp nhận, biểu mẫu và nguồn địa phương.
- [x] Bổ sung bộ chọn tỉnh/thành phố trong Hồ sơ đất đai AI và cảnh báo khi chưa chọn địa phương.
- [x] Tự động gắn nguồn thủ tục địa phương vào bộ nguồn pháp lý sau khi chọn tỉnh và thủ tục.
- [x] Bổ sung kiểm thử cho tỉnh, mã thủ tục, nguồn địa phương và trạng thái cần rà soát.

# Phân hệ AI lập hồ sơ đất đai riêng — 2026-08-17
- [x] Giữ nguyên toàn bộ menu, route, dữ liệu và nghiệp vụ CRM hiện có.
- [x] Tạo route và menu riêng cho AI lập bộ hồ sơ đất đai nộp cơ quan nhà nước.
- [x] Tách rõ phân hệ mới khỏi Hồ sơ AI, Kho biểu mẫu và Hồ sơ đất đai AI hiện tại để không chồng lấp.
- [x] Triển khai quy trình chọn thủ tục, nhập/tải giấy tờ, AI phân tích, lập bộ hồ sơ, rà soát và xuất/in.
- [x] Bổ sung test route/menu và hồi quy các phân hệ hiện có.

# OCR thực tế và xuất biểu mẫu chính thức — 2026-08-17
- [x] Tích hợp OCR thực tế cho ảnh/PDF giấy tờ đầu vào và lưu file bằng storage, không lưu bytes trong database.
- [x] Hiển thị kết quả OCR có trường dữ liệu chỉnh sửa được và bắt buộc người dùng xác nhận trước khi AI điền mẫu.
- [x] Xây dựng registry mẫu chính thức theo thủ tục, chỉ sử dụng file nguồn đã xác minh và ghi metadata nguồn/phiên bản.
- [x] Điền dữ liệu đã xác nhận vào DOCX/PDF theo từng thủ tục, khóa xuất khi thiếu trường bắt buộc hoặc chưa xác nhận.
- [x] Bổ sung test OCR contract, xác nhận dữ liệu, mapping mẫu và kiểm tra file xuất không gắn nhãn Official khi chưa xác nhận.

- [x] Tích hợp OCR server-side cho ảnh/PDF, lưu tệp qua storage và trả kết quả có confidence/evidence để người dùng xác nhận.
- [x] Khóa xuất nếu còn trường OCR chưa được người dùng đối chiếu và xác nhận.
- [x] Thêm endpoint xuất bản DOCX/PDF bản nháp đã xác nhận, kèm nguồn, ngày kiểm tra và cảnh báo phạm vi sử dụng.
- [x] Tích hợp engine điền trực tiếp vào từng file DOCX/PDF gốc chính thức đã xác minh — **đã đóng theo phương án A do người dùng chọn**: giữ bản nháp có cấu trúc dữ liệu và metadata nguồn, không sử dụng binary chưa xác minh và không gọi là biểu mẫu nhà nước hoàn chỉnh.
- [x] Bổ sung test backend cho giới hạn kích thước OCR, JSON schema OCR, khóa export và định dạng file trả về.

- [x] Sửa lỗi nút PDF trong AI Lập hồ sơ đất đai để tải ra file PDF hợp lệ, mở được trên điện thoại và không ảnh hưởng file DOCX.
- [x] Bổ sung hồi quy kiểm tra magic bytes/content type của PDF và trạng thái tải file trên mobile.

# Bộ hồ sơ tổng hợp đăng ký biến động
- [x] Đối chiếu thành phần hồ sơ chính thức cho đăng ký biến động theo từng trường hợp chuyển nhượng, tặng cho, thừa kế và các trường hợp liên quan.
- [x] Mapping Mẫu 09/ĐK và các mẫu thuế/lệ phí liên quan như tờ khai thuế thu nhập cá nhân, tờ khai lệ phí trước bạ cùng điều kiện phát sinh.
- [x] Hiển thị một checklist/bộ hồ sơ tổng hợp, phân biệt giấy tờ bắt buộc, giấy tờ phát sinh và giấy tờ cần người dùng bổ sung.
- [x] Chỉ mở xuất bộ hồ sơ tổng hợp sau khi người dùng xác nhận toàn bộ dữ liệu và từng mẫu thành phần.

- [x] Bộ hồ sơ tổng hợp đăng ký biến động: Mẫu 09/ĐK, Giấy chứng nhận, hợp đồng/văn bản chuyển quyền và giấy tờ hỗ trợ.
- [x] Bộ hồ sơ chuyển nhượng bổ sung tờ khai thuế thu nhập cá nhân, tờ khai lệ phí trước bạ và giấy tờ miễn/giảm theo điều kiện.
- [x] Hiển thị checklist bộ hồ sơ tổng hợp trong phân hệ AI và giải thích rõ giấy tờ thuế/lệ phí chỉ phát sinh theo trường hợp.
- [x] Bổ sung test hồi quy bộ hồ sơ tổng hợp; TypeScript không lỗi và 140/140 Vitest đạt.

# Luồng AI lập hồ sơ không cần tải file
- [x] Cho phép bắt đầu bằng chọn thủ tục và tỉnh/thành, không bắt buộc tải ảnh/PDF.
- [x] Tạo form nhập trực tiếp theo thủ tục và trường hợp, gồm các bên, thửa đất, Giấy chứng nhận, giá và nghĩa vụ tài chính.
- [x] AI tự dựng bộ hồ sơ tổng hợp gồm mẫu đất đai, thuế TNCN, lệ phí trước bạ và giấy tờ liên quan theo điều kiện.
- [x] Cho phép xem/sửa dữ liệu, xác nhận toàn bộ bộ hồ sơ rồi mới mở khóa DOCX/PDF.
- [x] Bổ sung test và kiểm tra responsive cho luồng nhập trực tiếp.

- [x] Phân biệt rõ export metadata-only với verified binary template trong AI Lập hồ sơ nộp cơ quan; chỉ cho phép nhãn Official khi có file gốc đã xác minh.
- [x] Bổ sung test backend/frontend cho trạng thái template provenance và cảnh báo bản nháp.
- [x] Chạy TypeScript, Vitest và kiểm tra preview responsive sau thay đổi provenance.
- [x] Xây adapter verified-binary cho DOCX/PDF với kiểm tra HTTPS, source status, magic bytes, SHA-256 và placeholder/form-field matching.
- [x] Bổ sung test adapter cho checksum, DOCX placeholder và chặn nguồn chưa xác minh.

# Mở rộng bộ hồ sơ chuyển nhượng
- [x] Bổ sung trường dữ liệu đầy đủ cho bên bán, bên mua, Giấy chứng nhận, thửa đất, giá và điều kiện giao dịch.
- [x] Tự dựng bộ tài liệu chuyển nhượng gồm hợp đồng/văn bản chuyển nhượng, đơn đăng ký biến động, thuế TNCN, lệ phí trước bạ và checklist giấy tờ liên quan.
- [x] Cho xem trước từng tài liệu, chỉnh sửa nội dung và xuất/in DOCX/PDF sau xác nhận hai lớp.
- [x] Bổ sung test hồi quy và kiểm tra responsive cho luồng chuyển nhượng.

- [x] Nối exportBundle với registry template verified phía server; không tin cờ provenance do client gửi và tự fallback về bản nháp khi binary không khả dụng.
- [x] Ghi nhận URL thủ tục chính thức, thành phần hồ sơ chuyển nhượng và kết quả kiểm tra binary vào nhật ký provenance.

# Quyết định phương án xuất hồ sơ
- [x] Xác nhận và duy trì phương án A: chỉ xuất bản nháp DOCX/PDF có metadata, nguồn pháp lý và checklist; không dùng binary chưa xác minh làm mẫu Official.

# Luồng Cổng DVC vào Kho Hồ sơ AI
- [x] Hiển thị thông tin thủ tục, tên biểu mẫu, URL nguồn và tệp đính kèm trong registry tập trung.
- [x] Thêm trạng thái kiểm tra file: chưa tải, tải lỗi, đã tải, kiểm tra MIME/magic bytes/checksum và verified hoặc metadata-only.
- [x] Bổ sung thao tác Xem mẫu, Tải mẫu và Dùng mẫu tạo hồ sơ, giữ phân quyền và cảnh báo an toàn pháp lý.
- [x] Kiểm thử luồng registry, fallback khi Cổng DVC trả lỗi, responsive và hồi quy export chuyển nhượng.

# Catalog biểu mẫu theo Cổng DVC
- [x] Bổ sung nhóm tài liệu đăng ký biến động, chuyển nhượng và giấy tờ quyền sử dụng đất.
- [x] Bổ sung nhóm tờ khai thuế TNCN, lệ phí trước bạ, giấy tờ miễn/giảm và chứng từ liên quan với trạng thái nguồn rõ ràng.
- [x] Hiển thị thao tác Xem mẫu, Tải mẫu và Dùng mẫu tạo hồ sơ cho từng tài liệu.
- [x] Kiểm thử catalog, cảnh báo file chưa tải/xác minh và luồng chuyển sang AI Lập hồ sơ nộp cơ quan.

# Tách tài liệu khi xuất bộ hồ sơ chuyển nhượng
- [x] Backend trả về danh sách tài liệu riêng cho hợp đồng, đơn đăng ký biến động, thuế TNCN, lệ phí trước bạ và checklist.
- [x] UI hiển thị từng tài liệu với xem trước, tải DOCX/PDF và in riêng; vẫn giữ xác nhận hai lớp và nhãn bản nháp.
- [x] Bổ sung test hồi quy cho số lượng tài liệu và kiểm tra responsive trên mobile.

# Sửa lỗi xuất file AI nộp hồ sơ
- [x] Kiểm tra và sửa nguyên nhân PDF không mở được trên mobile/trình xem hiện tại.
- [x] Bảo đảm mỗi tài liệu trong bộ hồ sơ có file DOCX riêng, mở và chỉnh sửa được.
- [x] Bảo đảm mỗi tài liệu có PDF hợp lệ tương ứng, xem trước/tải/in riêng.
- [x] Bổ sung hồi quy cho magic bytes, MIME, số lượng file, tên file và mobile download.

# Kết quả sửa lỗi xuất hồ sơ ngày 17/08/2026
- [x] PDF bản nháp được tạo với nội dung tương thích hơn, tự xuống dòng và tên file theo từng loại tài liệu.
- [x] DOCX được ưu tiên với MIME đúng để mở/chỉnh sửa bằng Word.
- [x] Builder hiển thị danh sách tài liệu riêng theo thủ tục, không chỉ một file tổng hợp.
- [x] TypeScript không lỗi, 147/147 Vitest đạt và preview mobile đã kiểm tra.

# Lịch sử nâng cấp xuất hồ sơ AI — 17/08/2026

- [x] Loại bỏ helper tạo file `.doc` bằng HTML trong Kho Hồ sơ AI.
- [x] Ưu tiên xuất DOCX nhị phân bằng thư viện `docx` để người dùng mở và chỉnh sửa.
- [x] Bổ sung xuất PDF nhị phân bằng `pdf-lib`, ASCII-safe và tự xuống dòng để giảm lỗi đọc trên mobile.
- [x] Cập nhật catalog và modal xem mẫu với nút DOCX/PDF riêng; giữ liên kết “Mở nguồn” cho metadata nguồn chính thức.
- [x] Giữ rõ trạng thái bản tham khảo/confirmed draft; không gắn nhãn Official khi chưa có binary chính thức được xác minh.
- [x] Bổ sung test hồi quy cho định dạng xuất và điều kiện nhãn Official; Vitest đạt 149/149 và TypeScript không lỗi.
- [x] Kiểm tra responsive mobile và đường tải Blob nhị phân qua preview; việc mở file trên thiết bị thật vẫn nên xác nhận thêm khi có máy thực tế.
- [x] Bổ sung “Tải toàn bộ ZIP” chứa DOCX và PDF riêng cho bộ hồ sơ nhiều tài liệu.

# Lỗi tải file trên mobile — 17/08/2026

- [x] Xác định nguyên nhân các nút DOCX/PDF từng tài liệu, DOCX/PDF tổng hợp và ZIP không tải trên Chrome mobile.
- [x] Sửa cơ chế tải Blob/binary tương thích mobile, có trạng thái đang tạo file và thông báo lỗi rõ ràng.
- [x] Bổ sung hồi quy cho luồng tải từng file và ZIP sau khi sửa.
- [x] Kiểm tra lại giao diện và thao tác tải trên preview mobile trước khi checkpoint.

# Lỗi bộ hồ sơ chỉ xuất một tài liệu — 18/08/2026

- [x] Kiểm tra vì sao DOCX/PDF tổng hợp đang được tải thay cho từng mẫu riêng của thủ tục.
- [x] Sửa danh sách tài liệu xuất riêng cho chuyển nhượng và các thủ tục liên quan, gồm mẫu chính, hợp đồng, thuế, lệ phí và checklist khi áp dụng.
- [x] Bảo đảm ZIP chứa từng DOCX/PDF riêng với tên tài liệu rõ ràng, không chỉ một file tổng hợp.
- [x] Bổ sung hồi quy số lượng, loại và tên file của bộ hồ sơ riêng.
- [x] Kiểm tra lại thao tác tải trên mobile và lưu checkpoint.

# Yêu cầu bố cục biểu mẫu thực tế — 18/08/2026

- [x] Xác định các mẫu cần bố cục riêng: tờ khai lệ phí trước bạ, tờ khai thuế TNCN, Mẫu 09/ĐK, hợp đồng và checklist.
- [x] Tạo bố cục DOCX/PDF có quốc hiệu, tiêu đề, số mẫu, trường đánh số, dòng điền và ô chọn theo từng loại tài liệu.
- [x] Điền dữ liệu đã xác nhận vào đúng vị trí của từng mẫu, không gom toàn bộ thành một trang văn bản chung.
- [x] Giữ nhãn confirmed-draft/metadata-only nếu chưa có file nhị phân chính thức đã xác minh.
- [x] Bổ sung kiểm thử bố cục và nội dung riêng của từng loại file.

# Điều chỉnh đúng chủ đề trợ lý hồ sơ chuyển nhượng — 18/08/2026

- [x] Đổi thông điệp trung tâm thành trợ lý lập bộ hồ sơ chuyển nhượng tham khảo cho người dùng, không phải công cụ cấp biểu mẫu Official.
- [x] Giữ luồng nhập tay hoặc OCR sổ hồng, thông tin bên bán/bên mua, thửa đất, giá chuyển nhượng và nghĩa vụ liên quan.
- [x] Dựng riêng hợp đồng chuyển nhượng Word, đơn đăng ký biến động, tờ khai lệ phí trước bạ, tờ khai thuế TNCN và giấy tờ phát sinh.
- [x] Thêm phân tích hồ sơ thiếu/sai và hướng dẫn trình tự từ chuẩn bị, công chứng, khai thuế/phí đến nộp sang tên.
- [x] Hiển thị rõ bản tham khảo để người dùng kiểm tra, in, ký và nộp cho cơ quan có thẩm quyền kiểm tra.

# Mở rộng AI đa thủ tục đất đai — 18/08/2026

- [x] Cho phép AI tự tìm thủ tục từ mô tả tự nhiên của người dùng, không bắt buộc chỉ chọn một thủ tục cố định.
- [x] Bổ sung nhóm sang tên mua bán nhà/đất, cho thuê đất, cho thuê lại đất và các thủ tục phát sinh liên quan.
- [x] Mở rộng danh mục tặng cho, thừa kế, đăng ký biến động, cấp Giấy chứng nhận, chuyển mục đích, tách thửa, hợp thửa, đăng ký/xóa thế chấp, đính chính/cập nhật thông tin và thủ tục liên quan khác.
- [x] Thiết kế AI tự xác định bộ giấy tờ, câu hỏi đầu vào, biểu mẫu tham khảo, nghĩa vụ tài chính và quy trình cho từng trường hợp.
- [x] Cho phép tạo nhiều bộ hồ sơ riêng, mỗi bộ có trạng thái, checklist, hướng dẫn, xem trước và xuất DOCX/PDF/ZIP.

# Cây thủ tục đất đai đa tầng — 18/08/2026

- [x] Chuẩn hóa 9 nhóm nghiệp vụ: đăng ký/cấp Giấy chứng nhận; chuyển quyền; thay đổi hiện trạng; mục đích sử dụng; giao/thuê/thu hồi; đo đạc địa chính; quy hoạch; nghĩa vụ tài chính; hồ sơ giao dịch bất động sản.
- [x] Cho phép điều hướng theo cây: nhóm thủ tục → thủ tục con → hồ sơ cần chuẩn bị → biểu mẫu → điều kiện → quy trình → cơ quan → thời hạn → phí/lệ phí → AI kiểm tra → xuất DOCX/PDF.
- [x] Bổ sung các thủ tục con còn thiếu: cấp đổi/cấp lại, góp vốn, chuyển quyền đặc biệt, thay đổi diện tích/người sử dụng/địa chỉ, tài sản gắn liền, gia hạn, thu hồi/bồi thường, trích lục/trích đo, quy hoạch và cung cấp dữ liệu đất đai.
- [x] Thiết kế câu hỏi động theo từng thủ tục và dữ liệu dùng chung từ OCR sổ/CCCD.
- [x] Tạo checklist và bộ tài liệu riêng cho từng thủ tục, không dùng một bộ chuyển nhượng mặc định.
- [x] Hiển thị quy trình thực hiện và cảnh báo bản tham khảo trước khi in, ký và nộp.

# Hợp nhất thành một AI Hồ sơ đất đai duy nhất — 18/08/2026

- [x] Hợp nhất toàn bộ yêu cầu người dùng vào một trợ lý AI duy nhất, không tách thành các công cụ rời rạc.
- [x] Giữ đầy đủ các lớp chức năng: mô tả nhu cầu/chọn thủ tục, nhập tay, tải ảnh/PDF/video nếu phù hợp, OCR, xác nhận dữ liệu, phân tích điều kiện, phát hiện thiếu sót, tạo checklist, hướng dẫn quy trình và xuất hồ sơ.
- [x] Bao phủ cây thủ tục đất đai từ đăng ký/cấp Giấy chứng nhận, chuyển quyền, thay đổi thửa đất, mục đích sử dụng, giao/thuê/thu hồi, đo đạc, quy hoạch, nghĩa vụ tài chính đến giao dịch bất động sản.
- [x] Tạo bộ tài liệu riêng theo thủ tục, ưu tiên DOCX có bố cục hồ sơ tham khảo, kèm PDF/ZIP và cảnh báo kiểm tra trước khi in, ký, nộp.
- [x] Duy trì lưu nháp, tiến độ hồ sơ, xác nhận hai lớp và phân biệt rõ hồ sơ tham khảo với văn bản do cơ quan nhà nước chứng nhận.

# Chốt phạm vi trợ lý AI hồ sơ đất đai cá nhân — 18/08/2026

- [x] Giữ mục tiêu là trợ lý lập hồ sơ đất đai cho người dùng, không xây kho biểu mẫu Official.
- [x] Với chuyển nhượng: nhận dữ liệu nhập tay hoặc OCR sổ hồng/CCCD, phân tích và hỏi bổ sung thông tin thiếu.
- [x] Tạo bộ hồ sơ tham khảo gồm hợp đồng chuyển nhượng Word, tờ khai lệ phí trước bạ, tờ khai thuế TNCN, đơn đăng ký biến động và tài liệu liên quan.
- [x] Tạo checklist, quy trình kiểm tra–công chứng–kê khai–nộp–sang tên và hướng dẫn cơ quan tiếp nhận theo dữ liệu địa phương.
- [x] Giữ nhãn Confirmed Draft/bản tham khảo, yêu cầu người dùng kiểm tra trước khi in, ký và nộp.

# Tệp Word mẫu hợp đồng chuyển nhượng — 18/08/2026

- [x] Tạo DOCX nhị phân mẫu Hợp đồng chuyển nhượng quyền sử dụng đất với bố cục hành chính, ô trống, bảng thông tin và phần ký.
- [x] Kiểm tra DOCX mở được và bàn giao tệp trực tiếp cho người dùng.

# Tích hợp catalog nguồn chính thức và AI đa thủ tục — 18/08/2026

- [x] Nối catalog thủ tục với metadata nguồn Cổng Dịch vụ công và biểu mẫu tham khảo theo từng thủ tục.
- [x] Hiển thị nguồn, mã thủ tục, ngày kiểm tra, cơ quan, thời hạn và cảnh báo địa phương trong AI builder.
- [x] Tự ghép bộ tài liệu theo thủ tục được nhận diện, không giới hạn ở chuyển nhượng.
- [x] Bổ sung hồi quy cho mapping thủ tục–tài liệu–provenance và export DOCX/PDF/ZIP.

- [x] Cập nhật catalog nguồn DVC/Chính phủ đã xác minh, ưu tiên URL thủ tục 2.000889 và Nghị định 151/2025/NĐ-CP.
- [x] Mở rộng registry biểu mẫu và bộ hồ sơ cho cấp đổi, cấp lại, tách/hợp thửa, chuyển mục đích, thế chấp, đo đạc, quy hoạch và nghĩa vụ tài chính.
- [x] Bổ sung metadata ngày kiểm tra, mã thủ tục, cơ quan tham chiếu và thời hạn tham chiếu; giữ nhãn metadata-only/Confirmed Draft khi chưa xác minh binary.
- [x] Thêm test hồi quy cho catalog, mapping tài liệu và quy tắc không gắn Official giả.

# Xây dựng AI pháp lý và CSDL thủ tục đất đai theo kiến trúc tham chiếu — 18/08/2026
- [x] Rà soát kiến trúc hiện tại của AI Hồ sơ đất đai, router, schema và các thành phần có thể tái sử dụng.
- [x] Thiết kế mô hình dữ liệu cho nguồn pháp lý, văn bản, phiên bản, thủ tục, thành phần hồ sơ, biểu mẫu và mapping trường.
- [x] Tạo lớp AI server-side dùng structured JSON để trích xuất điều khoản, thủ tục, điều kiện và giấy tờ từ nguồn được cung cấp.
- [x] Tạo cơ chế chuẩn hóa, deduplicate, provenance, hiệu lực và cảnh báo khi nguồn chưa xác minh.
- [x] Nối CSDL pháp lý vào AI builder để tự hỏi thông tin thiếu, chọn bộ hồ sơ và điền biểu mẫu theo thủ tục.
- [x] Bổ sung giao diện quản trị kho pháp lý/biểu mẫu và hiển thị trạng thái cập nhật, lịch sử thay đổi.
- [x] Viết Vitest cho schema, trích xuất có cấu trúc, provenance, mapping và export; kiểm tra responsive.
- [x] Lưu checkpoint phát hành và bàn giao hướng dẫn vận hành AI pháp lý.

# Nâng cấp AI tự đọc và tự nạp tệp pháp lý

- [x] Kiểm tra luồng upload/OCR hiện có và khả năng nhận PDF, DOCX, TXT, ảnh scan.
- [x] Thêm luồng tải tệp pháp lý để AI tự trích xuất văn bản và nhận diện loại nguồn, luật, nghị định, thủ tục hoặc biểu mẫu.
- [x] Tự trích xuất mã thủ tục, tiêu đề, điều kiện, thành phần hồ sơ, cơ quan, thời hạn, phí, căn cứ pháp lý và trường biểu mẫu bằng structured JSON.
- [x] Tự lưu tệp gốc vào storage, tạo metadata/provenance, checksum, trạng thái cần rà soát và liên kết với CSDL pháp lý.
- [x] Bổ sung giao diện nút “Tải tệp để AI tự đọc” và hiển thị tiến trình, kết quả trích xuất, cảnh báo lỗi để người dùng chỉ cần kiểm tra/xác nhận.
- [x] Nối dữ liệu đã xác nhận vào AI Hồ sơ đất đai và mapping bộ hồ sơ theo thủ tục.
- [x] Viết hồi quy cho upload, OCR, giới hạn tệp, structured extraction, provenance và luồng lỗi.
- [x] Kiểm tra responsive, chạy TypeScript/Vitest và lưu checkpoint phát hành.

- [x] Hoàn tất đợt 1: tải và tự đọc TXT/MD/CSV/HTML/JSON, tự điền tiêu đề/nội dung, gửi dữ liệu base64 cùng MIME và tên tệp.
- [x] Hoàn tất đợt 1: lưu bản gốc lên storage, tạo SHA-256, liên kết fileUrl/storageKey vào legal document và giữ provenance metadata-only.
- [x] Hoàn tất đợt 1: contract test cho fileDataBase64, contentHash, storage key và UI upload; TypeScript/Vitest 156/156 đạt.
- [x] Đợt 2: hỗ trợ trích xuất trực tiếp PDF/DOCX/ảnh scan và nối OCR pháp lý vào cùng pipeline.

- [x] Đợt 2: mở rộng giao diện nhận PDF/DOCX và gửi bản gốc cùng MIME/base64 lên backend.
- [x] Đợt 2: AI tự trích xuất nội dung có lớp văn bản từ PDF/DOCX ở máy chủ; không hiển thị ký tự nhị phân trong ô nhập.
- [x] Đợt 2: cập nhật validation cho phép PDF/DOCX không cần dán trước 200 ký tự; vẫn giữ cảnh báo metadata-only.
- [x] Đợt 3: OCR ảnh scan/PDF không có lớp văn bản và kiểm tra bản trích xuất trước khi lưu.

- [x] Đợt 3: OCR ảnh PNG/JPG/WEBP và PDF scan không có lớp văn bản bằng AI multimodal, giữ phần không rõ dưới dạng cảnh báo.
- [x] Đợt 3: trả về độ tin cậy OCR, cảnh báo rà soát và hiển thị cho quản trị viên trước/sau khi lưu.
- [x] Đợt 3: giữ file gốc trên storage, contentText trong metadata, provenance metadata-only và không xác nhận Official tự động.

# AI tự tìm kiếm và đối chiếu biểu mẫu pháp lý

- [x] Xác định các nguồn chính thức có thể tìm thủ tục, nghị định, thông tư và tệp biểu mẫu theo mã thủ tục.
- [x] Xây dựng registry tìm kiếm biểu mẫu theo thủ tục, địa phương, mã mẫu, căn cứ pháp lý và trạng thái hiệu lực.
- [x] Cho AI tự tìm, trích xuất và đối chiếu biểu mẫu; phân biệt tệp Official đã xác minh với Confirmed Draft/metadata-only.
- [x] Nối kết quả tìm kiếm vào bộ hồ sơ AI để tự ghép đơn, hợp đồng, tờ khai thuế/phí và checklist theo thủ tục.
- [x] Thêm kiểm tra provenance, checksum, phiên bản, nguồn URL và cảnh báo khi chưa có binary chính thức.
- [x] Viết hồi quy cho tìm kiếm biểu mẫu, mapping thủ tục và quy tắc không gắn nhãn Official sai.

- [x] Tạo registry mã thủ tục và URL nguồn chính thức đã được kiểm tra, có mẫu tham chiếu và trạng thái provenance.
- [x] Thêm API `searchOfficial` theo mã, tên, từ khóa tự nhiên và địa phương tham chiếu.
- [x] Thêm tab `Tra cứu chính thức` trong AI Kho pháp lý, hiển thị nguồn, biểu mẫu tham chiếu và cảnh báo chưa có binary Official xác minh.
- [x] Bổ sung contract test cho registry, API tra cứu, giao diện và chính sách provenance; TypeScript không lỗi, 157/157 Vitest đạt.

# Hoàn thiện AI Hồ sơ nộp cơ quan theo bộ biểu mẫu
- [x] Khi chọn thủ tục đăng ký biến động/chuyển nhượng, tự xác định và hiển thị Mẫu 09/ĐK cùng các biểu mẫu thuế, lệ phí và giấy tờ liên quan.
- [x] Tự điền dữ liệu đã xác nhận vào từng biểu mẫu, không chỉ tạo văn bản tổng hợp.
- [x] Xuất từng tệp DOCX/PDF có tên và loại tài liệu rõ ràng, đồng thời đóng gói ZIP bộ hồ sơ.
- [x] Hiển thị quy trình, thành phần hồ sơ, cơ quan tiếp nhận, thời hạn, phí/lệ phí và căn cứ nguồn chính thức theo thủ tục.
- [x] Chặn trạng thái Official khi chưa có binary biểu mẫu chính thức được xác minh; hiển thị cảnh báo Confirmed Draft/metadata-only.
- [x] Bổ sung Vitest cho mapping Mẫu 09/ĐK, tờ khai, hướng dẫn quy trình và export đa tệp.

# Đợt cải tiến AI Hồ sơ đất đai — biểu mẫu riêng và hướng dẫn có nguồn

- [x] Tạo catalog tài liệu riêng cho từng thủ tục, trong đó chuyển nhượng phải có Mẫu 09/ĐK, hợp đồng, tờ khai thuế TNCN, tờ khai lệ phí trước bạ, checklist và hướng dẫn nộp.
- [x] Bổ sung hướng dẫn thủ tục từng bước có mã thủ tục, cơ quan, thành phần hồ sơ, trình tự, thời hạn và nguồn DVC/Chính phủ; không suy diễn dữ liệu chưa xác minh.
- [x] Sửa backend export để nhận đúng documentType của từng tài liệu và tạo DOCX/PDF riêng cho từng mục thay vì chỉ dùng template đầu tiên.
- [x] Đồng bộ mapping bundle với catalog biểu mẫu, thuế, phí và tài liệu hỗ trợ cho các thủ tục chính.
- [x] Cập nhật UI hiển thị hướng dẫn có nguồn, trạng thái Confirmed Draft/Official và danh sách file đã tạo riêng.
- [x] Bổ sung test hồi quy cho export từng documentType, hướng dẫn thủ tục và ZIP nhiều tài liệu.
- [x] Kiểm tra TypeScript, Vitest, preview responsive và chất lượng binary DOCX/PDF trước checkpoint.
- [x] Ghi rõ giới hạn pháp lý: chỉ gắn Official khi có binary chính thức đã xác minh; các bản AI tạo vẫn là Confirmed Draft để rà soát trước khi ký/nộp.

# Tích hợp camera/OCR cho mục Đăng bán sản phẩm

- [x] Thêm camera trên mobile và bộ chọn ảnh/tệp trên máy tính cho biểu mẫu Đăng bán sản phẩm.
- [x] Thêm backend OCR có cấu trúc cho ảnh/tệp giấy tờ bất động sản, lưu bản gốc qua storage và không suy đoán dữ liệu.
- [x] Ánh xạ dữ liệu OCR vào các trường sản phẩm như tiêu đề, loại, vị trí, diện tích, giá, pháp lý và mô tả.
- [x] Hiển thị trạng thái đang đọc, cảnh báo độ tin cậy và cho phép người dùng xem/chỉnh sửa/xác nhận trước khi lưu.
- [x] Bổ sung test cho payload OCR, mapping trường, trạng thái lỗi và luồng camera/file upload.
- [x] Kiểm tra TypeScript, Vitest và preview responsive desktop/mobile trước checkpoint.

# Sửa lỗi nút camera/tải ảnh đăng bán

- [x] Khắc phục lỗi nút “Chụp / tải ảnh lên” không mở hoặc không nhận ảnh từ máy trên mobile.
- [x] Kiểm tra input file, capture camera, định dạng MIME và thông báo lỗi khi chọn ảnh.
- [x] Kiểm thử lại OCR sau khi chọn ảnh, bao gồm trạng thái loading và lỗi upload.
- [x] Kiểm tra preview mobile và phát hành bản sửa.

# Sửa lỗi xác thực dữ liệu đăng bán từ OCR/tiếng Việt

- [x] Chuẩn hóa nhãn loại bất động sản tiếng Việt về enum backend trước khi gửi biểu mẫu.
- [x] Chuẩn hóa diện tích có dấu chấm, dấu phẩy hoặc hậu tố m² về định dạng hợp lệ.
- [x] Hiển thị lỗi xác thực thân thiện, chỉ rõ trường cần sửa và giữ dữ liệu người dùng.
- [x] Bổ sung test cho các giá trị “nhà ở”, “đất nền”, “căn hộ” và diện tích OCR dạng 10.012 m².
- [x] Kiểm tra mobile và phát hành bản sửa.

# Sửa lỗi xác thực roadWidth và certificateArea

- [x] Chuẩn hóa chiều rộng đường có đơn vị m, mét hoặc ký tự OCR thừa về định dạng số hợp lệ.
- [x] Chuẩn hóa diện tích trên giấy chứng nhận có đơn vị m², dấu chấm/dấu phẩy và khoảng trắng.
- [x] Bổ sung test payload thực tế cho roadWidth và certificateArea.
- [x] Kiểm tra mobile, lưu hồ sơ và phát hành bản sửa.

# Sửa lỗi card sản phẩm công khai thiếu ảnh và dữ liệu

- [x] Xác định vì sao ảnh đã tải không được đọc lại ở card Sản phẩm đang bán.
- [x] Đồng bộ mapping tiêu đề, giá, diện tích, vị trí và ngày đăng từ bài đã lưu sang card công khai.
- [x] Bổ sung fallback ảnh và trạng thái đang tải ảnh rõ ràng, không hiển thị placeholder sai khi URL hợp lệ.
- [x] Bổ sung test hồi quy cho bài published có ảnh và dữ liệu đầy đủ.
- [x] Kiểm tra mobile và phát hành bản sửa.

# Sửa card bài tạo từ hồ sơ pháp lý

- [x] Khi AI tạo bài Nháp từ hồ sơ pháp lý, liên kết ảnh scan vào propertyImages để card có ảnh sau khi được duyệt.
- [x] Chặn chuyển bài hồ sơ pháp lý chưa hoàn thiện sang Công khai khi còn giá 0, diện tích 0 hoặc địa chỉ chưa xác định.
- [x] Bổ sung test cho ảnh và dữ liệu fallback của bài tạo từ hồ sơ pháp lý.

# Đồng bộ bài đăng vào nguồn hàng và hồ sơ AI điện tử

- [x] Xác định bảng và procedure hiện đang cấp dữ liệu cho Quản lý nguồn hàng và Hồ sơ AI điện tử.
- [x] Liên kết bài đăng mới với nguồn hàng bằng cùng propertyId, ảnh, trạng thái và dữ liệu chủ sở hữu.
- [x] Tạo hoặc cập nhật bản ghi Hồ sơ AI điện tử từ dữ liệu OCR/pháp lý của bài đăng, không tạo bản ghi trùng.
- [x] Cập nhật UI để hiển thị trạng thái đã đồng bộ hoặc cần bổ sung dữ liệu.
- [x] Bổ sung test đồng bộ hai chiều và hồi quy tạo bài đăng.
- [x] Kiểm tra TypeScript, Vitest, preview mobile và phát hành bản sửa.

# Đợt sửa lỗi đồng bộ nguồn hàng và hiển thị công khai

- [x] Hydrate imageUrl/imageUrls cho danh sách nguồn hàng quản trị và danh sách của người tạo bài.
- [x] Sửa Trung tâm Hồ sơ AI điện tử để tài khoản thường dùng dữ liệu properties.mine, không gọi truy vấn admin-only.
- [x] Bảo đảm bài tạo từ luồng pháp lý vẫn ở Nháp và chỉ xuất hiện công khai sau khi đủ giá, diện tích, vị trí và được duyệt.
- [x] Bảo đảm ensurePropertyDossier không tạo trùng hồ sơ khi đồng bộ lặp lại.
- [x] Bổ sung kiểm thử hồi quy cho ảnh, dữ liệu card và liên kết property–dossier.
- [x] Chạy TypeScript, Vitest và kiểm tra preview responsive trước khi phát hành.

# Tách ảnh pháp lý khỏi ảnh công khai

- [x] Tách storage/reference ảnh sổ, CCCD và tài liệu pháp lý khỏi propertyImages công khai.
- [x] Bảo đảm luồng OCR pháp lý vẫn lưu và xem được ảnh trong khu vực riêng tư có phân quyền.
- [x] Không trả ảnh pháp lý trong các helper/procedure public hoặc hydrate card công khai.
- [x] Bổ sung kiểm thử chống rò rỉ ảnh pháp lý và kiểm thử liên kết dossier.
- [x] Kiểm tra UI quản trị, preview responsive, TypeScript và Vitest trước khi phát hành.

# Cải thiện giao diện đăng bán và card nguồn hàng

- [x] Thiết kế form đăng bài động theo loại giao dịch: bán nhà, bán đất, bán căn hộ, cho thuê và các loại chuyên biệt.
- [x] Bổ sung trường thông tin phù hợp: diện tích, ngang/dài, giá tổng, giá/m², phòng ngủ, vệ sinh, kết cấu và điều kiện giao dịch.
- [x] Thêm bản đồ vị trí thu gọn vào card/chi tiết sản phẩm và giữ layout responsive.
- [x] Thêm hàng liên hệ gọn gồm gọi điện, Zalo, Messenger và chia sẻ Facebook.
- [x] Thêm nút chỉnh sửa bài đăng sau khi công khai theo đúng quyền chủ bài/admin.
- [x] Thêm liên kết “Xem tất cả nguồn hàng” trên đầu khu vực sản phẩm trang chủ và cập nhật tự động.
- [x] Bổ sung kiểm thử form động, card/chi tiết, quyền chỉnh sửa và responsive trước phát hành.

# Đặc tả form động và xuất bản bài đăng theo loại BĐS

- [x] Thêm lựa chọn loại giao dịch và loại BĐS, dùng registry để tự đổi biểu mẫu ngay khi chọn.
- [x] Tạo nhóm trường riêng cho bán nhà phố, bán căn hộ, bán đất, cho thuê nhà, cho thuê KCN và villa/resort.
- [x] Bổ sung thanh hành động Lưu, Xem trước, Công khai và Chỉnh sửa bài đăng với phân quyền phù hợp.
- [x] Dựng nội dung xuất bản gọn, chỉ hiển thị trường phù hợp với loại BĐS và tự tính đơn giá/m².
- [x] Tích hợp bản đồ mini ở khu vực vị trí, mở được chế độ xem bản đồ lớn.
- [x] Thêm hàng liên hệ gọn: Gọi, Zalo, Messenger, Facebook và Xem chi tiết.
- [x] Thêm “Xem tất cả nguồn hàng” trên đầu danh sách sản phẩm trang chủ và tự cập nhật theo trạng thái bài.
- [x] Bổ sung kiểm thử registry, preview, chỉnh sửa, bản đồ, CTA và responsive.

# Hợp nhất form động và giao diện xuất bản

- [x] Dùng cùng một registry loại giao dịch/BĐS cho form nhập liệu, preview và nội dung public.
- [x] Bảo đảm thay đổi loại giao dịch cập nhật đồng thời field, tiêu đề, nhãn và thông tin xuất bản.
- [x] Bảo đảm nút Lưu, Xem trước, Công khai và Chỉnh sửa dùng cùng payload chuẩn hóa.
- [x] Bảo đảm bài sau khi chỉnh sửa được cập nhật nhất quán ở nguồn hàng, trang chủ và chi tiết public.

# Hoàn thiện lại giao diện bài đăng theo yêu cầu người dùng

- [x] Làm rõ và hoàn thiện thanh thao tác Lưu, Xem trước, Công khai và Chỉnh sửa bài đăng.
- [x] Cải thiện bố cục card/trang chi tiết với vị trí, bản đồ mini và dữ liệu giá tổng/giá mỗi m².
- [x] Hiển thị đúng trường diện tích, ngang × dài, phòng ngủ, WC, kết cấu theo loại BĐS.
- [x] Tích hợp hàng liên hệ gọn gồm Gọi, Zalo, Messenger, Facebook và Xem chi tiết.
- [x] Hiển thị liên kết “Xem tất cả nguồn hàng” trên trang chủ và tự cập nhật theo bài đăng.
- [x] Bảo đảm form tự đổi riêng cho bán nhà phố, căn hộ, bán đất, cho thuê nhà, cho thuê KCN, villa/resort và loại tương ứng.
- [x] Bổ sung kiểm thử hồi quy và kiểm tra responsive trước khi phát hành.

# Thiết kế lại giao diện bài đăng theo hướng đẹp và gọn

- [x] Làm lại bố cục form đăng bài để phân nhóm rõ ràng, giảm cảm giác dày và dùng một mẫu chung.
- [x] Làm lại card/trang chi tiết với vùng ảnh, giá, vị trí, bản đồ mini và thông tin động cân đối hơn.
- [x] Giữ nút Lưu, Xem trước, Công khai và Chỉnh sửa ở vị trí dễ nhìn, thao tác tốt trên điện thoại.
- [x] Giữ hàng liên hệ gọn và liên kết “Xem tất cả nguồn hàng” trên trang chủ.
- [x] Kiểm thử visual responsive và phát hành checkpoint mới.

# Bổ sung loại bất động sản vào bộ chọn form

- [x] Bổ sung Đất thương mại vào registry và bộ chọn loại BĐS.
- [x] Bổ sung Đất nông nghiệp vào registry và bộ chọn loại BĐS.
- [x] Bổ sung Khu thương mại vào registry và bộ chọn loại BĐS.
- [x] Bổ sung Khu nghỉ dưỡng vào registry và bộ chọn loại BĐS.
- [x] Bổ sung Đất dự án vào registry và bộ chọn loại BĐS.
- [x] Bổ sung nhóm Cho thuê và các loại BĐS cho thuê khác vào registry.
- [x] Tạo nhóm trường biểu mẫu phù hợp cho từng loại mới, không dùng chung mẫu nhà phố.
- [x] Đồng bộ backend, catalog, trang chi tiết và kiểm thử responsive mobile.

- [x] Sửa assertion PropertyCatalog theo nhãn công khai mới “Nguồn hàng công khai”.
- [x] Sửa mapping normalizePropertyType cho nhãn “Biệt thự nghỉ dưỡng” về enum tương thích với registry và kiểm tra các loại BĐS mở rộng.
- [x] Chạy lại TypeScript, Vitest và kiểm tra responsive sau khi sửa hai hồi quy.
- [x] Lưu và nạp lại metadata field động của AI Listing Studio khi chỉnh sửa bài đăng.

# Bổ sung Bước 2 Quy trình thủ tục cho Hồ sơ đất đai AI
- [x] Thêm Bước 2 “Quy trình thủ tục hướng dẫn” ngay dưới Bước 1 và liên kết dữ liệu hồ sơ đã nhập.
- [x] Xây dựng mapping thủ tục theo loại BĐS và giao dịch: chuyển nhượng/sang tên, cho thuê, tặng cho, thừa kế, chuyển mục đích, tách/hợp thửa và nghĩa vụ tài chính.
- [x] Hiển thị giấy tờ pháp lý cần chuẩn bị, trình tự, cơ quan thực hiện, biểu mẫu và cảnh báo rà soát theo nguồn pháp lý.
- [x] Tạo bộ hồ sơ liên quan từ dữ liệu Bước 1, hỗ trợ xem trước và tải các tệp DOCX/PDF/ZIP khi có nội dung xác minh.
- [x] Bổ sung tải, hiển thị và xóa ảnh/video hồ sơ từ thiết bị với phân tách riêng tư phù hợp.
- [x] Bổ sung kiểm thử liên kết Bước 1 → Bước 2, loại BĐS, tạo bộ hồ sơ, tải/xóa media và responsive mobile.

# Mở rộng Bước 2 thành bộ hồ sơ theo thủ tục
- [x] Bổ sung catalog bộ hồ sơ theo từng thủ tục và loại BĐS, bắt đầu với chuyển nhượng/sang tên.
- [x] Tích hợp các tài liệu liên quan trong bộ chuyển nhượng như Mẫu 09/ĐK, tờ khai lệ phí trước bạ và checklist tài liệu.
- [x] Hiển thị trạng thái nguồn mẫu: mẫu chính thức đã xác minh, bản nháp tham khảo hoặc cần đối chiếu địa phương; không gắn nhãn Official khi chưa có tệp gốc xác minh.
- [x] Cho phép xem trước, chỉnh sửa dữ liệu, tải từng tài liệu hoặc tải cả bộ hồ sơ, đồng thời giữ thao tác xóa và quản lý ảnh/video.
- [x] Bổ sung contract test cho mapping bộ hồ sơ, tài liệu liên quan, provenance và luồng tải/xóa.

# Kho biểu mẫu pháp lý theo địa phương
- [x] Thiết kế registry biểu mẫu có tỉnh/thành, cơ quan tiếp nhận, thủ tục, loại BĐS, phiên bản và nguồn gốc.
- [x] Bổ sung bộ lọc tỉnh/thành và cơ quan tiếp nhận trong Kho pháp lý và Bước 2 Hồ sơ đất đai AI.
- [x] Cho phép AI ưu tiên mẫu theo địa phương nhưng chỉ đề xuất Official khi có tệp/nguồn xác minh; còn lại gắn nhãn cần rà soát hoặc bản tham khảo.
- [x] Hiển thị provenance, ngày kiểm tra, phiên bản, URL nguồn và cảnh báo khi mẫu không áp dụng chung toàn quốc.
- [x] Bổ sung contract test cho lọc địa phương, cơ quan tiếp nhận, thứ tự ưu tiên và trạng thái xác minh.

# Xem trước biểu mẫu pháp lý trên web
- [x] Thêm nút Xem trước cho từng tài liệu trong bộ hồ sơ Bước 2.
- [x] Hiển thị preview DK09, tờ khai lệ phí trước bạ và các tài liệu liên quan theo dữ liệu hồ sơ hiện tại.
- [x] Hiển thị nhãn provenance/trạng thái xác minh trong cửa sổ preview và giữ cảnh báo bản nháp/tham khảo.
- [x] Giữ nguyên tải từng file và tải cả bộ sau khi người dùng xem trước.
- [x] Bổ sung test mở/đóng preview, nội dung biểu mẫu, tải xuống và responsive mobile.

# Hoàn thiện pipeline AI tạo hồ sơ thật
- [x] Phân tích điều kiện và giấy tờ đầu vào trước khi cho phép tạo bộ hồ sơ.
- [x] Chọn mẫu theo thủ tục, địa phương, cơ quan và trạng thái nguồn xác minh; chặn mẫu chỉ tham khảo khỏi luồng tự động.
- [x] Tự động điền dữ liệu hồ sơ vào mẫu đủ điều kiện và hiển thị trường còn thiếu để người dùng bổ sung; khi chưa có binary xác minh, hệ thống chỉ sinh bản nháp tham khảo và khóa tự điền mẫu Official.
- [x] Tạo bộ hồ sơ liên quan, xem trước, tải từng tệp/tải cả bộ và hỗ trợ in sau khi người dùng xác nhận.
- [x] Bổ sung kiểm thử chuỗi nhận diện → chọn mẫu → điền → xem/in/tải và cảnh báo an toàn pháp lý.

# AI tự tra cứu văn bản pháp luật và biểu mẫu công khai
- [x] Xây pipeline truy hồi văn bản luật/nghị định và nguồn công khai theo thủ tục, địa phương, cơ quan tiếp nhận.
- [x] Phân biệt văn bản pháp luật, biểu mẫu chính thức, bản sao tham khảo và nội dung bên thứ ba; lưu provenance cho từng trích đoạn/tệp.
- [x] Cho AI đối chiếu điều kiện, giấy tờ, trình tự và biểu mẫu từ nhiều nguồn trước khi dựng bộ hồ sơ.
- [x] Tải/đọc tệp công khai khi quyền truy cập cho phép, kiểm tra phiên bản và chỉ dùng tự động điền khi tệp đủ tin cậy.
- [x] Hiển thị nguồn, ngày truy cập, phiên bản, mức độ tin cậy và cảnh báo người dùng rà soát trước khi ký/nộp.
- [x] Bổ sung test truy hồi, chống nhầm nguồn, provenance và fallback khi nguồn không tải được.

# Luồng AI Hồ sơ đất đai end-to-end
- [x] Tạo nút và trạng thái AI lập bộ hồ sơ từ dữ liệu Bước 1.
- [x] Phân tích giao dịch chuyển nhượng/sang tên và xác định bộ tài liệu bắt buộc, tài liệu liên quan, giấy tờ còn thiếu.
- [x] Tự điền dữ liệu đã xác nhận vào các mẫu đủ điều kiện và sinh bản dự thảo DOCX/PDF; mẫu Official chưa có binary xác minh vẫn bị khóa theo nguyên tắc an toàn.
- [x] Hiển thị xem trước toàn bộ bộ hồ sơ, cho chỉnh sửa trước khi tải/in và giữ cảnh báo pháp lý.
- [x] Bổ sung kiểm thử end-to-end cho nhận diện, chọn mẫu, điền, xem trước, tải và in.

# Pipeline AI lập bộ hồ sơ end-to-end — phiên tiếp theo
- [x] Tạo pipeline rõ ràng: phân tích điều kiện → chọn mẫu xác minh → tự điền bản nháp → người dùng rà soát → in/xuất.
- [x] Chỉ tự động điền khi có tệp DOCX/PDF binary đã xác minh; mẫu metadata-only phải hiển thị cảnh báo và không gắn nhãn Official.
- [x] Bổ sung bảng điều khiển kết quả phân tích: thủ tục được chọn, căn cứ pháp lý, mẫu được chọn, tài liệu còn thiếu và trạng thái từng bước.
- [x] Bổ sung nút “AI lập bộ hồ sơ” và nút “In hồ sơ đã xác nhận”, giữ export DOCX/PDF/ZIP hiện hữu.
- [x] Bổ sung test hồi quy cho pipeline, trạng thái khóa khi mẫu chưa xác minh và nút in hồ sơ.
- [x] Kiểm tra TypeScript, Vitest và responsive mobile 390px trước checkpoint.

# Kho biểu mẫu gốc công khai và hồ sơ thực tế — yêu cầu mới

- [x] Xác định các nguồn công khai hợp lệ cho mẫu đất đai, thuế và phí; lưu URL, cơ quan, phiên bản và ngày kiểm tra; các mẫu cụ thể vẫn phải được quản trị viên nạp và xác minh binary theo từng địa phương.
- [x] Tạo cơ chế tải và lưu binary DOCX/PDF vào kho riêng, không lưu bytes trong database.
- [x] Kiểm tra hash, MIME, định dạng, khả năng đọc và provenance trước khi gắn trạng thái verified-binary.
- [x] Cho AI đọc cấu trúc mẫu gốc, ánh xạ trường dữ liệu qua legalTemplateFields/placeholderMap và tự điền bản hồ sơ thực tế theo từng thủ tục; DOCX không có placeholder hoặc PDF không có AcroForm sẽ bị chặn thay vì xuất sai mẫu.
- [x] Hiển thị rõ file gốc, nguồn, phiên bản, cảnh báo thay đổi và cho người dùng xem/in trước khi ký nộp.
- [x] Bổ sung test cho tải mẫu, kiểm chứng binary, ánh xạ trường, fallback nguồn lỗi và export hồ sơ.

# Kiểm toán đối chiếu nguồn pháp lý xuyên suốt pipeline — yêu cầu mới

- [x] Lập bản đồ các bước từ dữ liệu Bước 1 đến export/in và ghi rõ điểm bắt buộc đối chiếu nguồn.
- [x] Bắt buộc kiểm tra nguồn pháp lý, ngày/phiên bản, phạm vi tỉnh thành và cơ quan tiếp nhận trước khi chọn thủ tục.
- [x] Bắt buộc đối chiếu thành phần hồ sơ, điều kiện, trình tự, thời hạn, phí/lệ phí và biểu mẫu trước khi lập bộ hồ sơ.
- [x] Hiển thị provenance và cảnh báo nguồn thiếu, lỗi thời, xung đột hoặc chỉ tham khảo trong Bước 2 và preview.
- [x] Chặn export/in hồ sơ nếu chưa hoàn thành đối chiếu hoặc mẫu binary chưa xác minh.
- [x] Bổ sung test hồi quy cho từng guard đối chiếu nguồn pháp lý và kiểm tra responsive mobile.

# Tự động phân tích URL nguồn pháp lý — yêu cầu mới
- [x] Thêm nút AI tự phân tích URL trong mục Nạp nguồn vào AI.
- [x] Tự trích xuất tên nguồn, loại nguồn, tiêu đề, số hiệu, tỉnh/thành, cơ quan và ngày phiên bản.
- [x] Tự nhận diện URL thủ tục/văn bản và các tệp DOCX/PDF đính kèm khi nguồn cho phép truy cập.
- [x] Hiển thị kết quả trích xuất, provenance và cảnh báo để người dùng xác nhận trước khi lưu.
- [x] Bổ sung test cho URL hợp lệ, URL lỗi, nguồn không truy cập được và dữ liệu trích xuất thiếu.

# Tra cứu nghị định theo tên hoặc số hiệu — yêu cầu mới

- [x] Thêm ô nhập tên/số hiệu văn bản, ví dụ Nghị định 102, 101 hoặc 96.
- [x] Tìm nhiều nguồn công khai và ưu tiên nguồn chính thức, không tự tin tuyệt đối từ một kết quả đơn lẻ.
- [x] Tự nhận diện bản mới nhất, hiệu lực, văn bản sửa đổi/thay thế và phụ lục/tệp đính kèm.
- [x] Hiển thị nguồn, phiên bản, ngày kiểm tra, mức độ tin cậy và yêu cầu người dùng xác nhận trước khi lưu.
- [x] Cập nhật toàn văn và tệp liên quan vào Kho pháp lý, không ghi đè dữ liệu cũ nếu chưa có xác nhận.
- [x] Bổ sung test cho tìm theo tên/số hiệu, nhiều kết quả, phiên bản mới và nguồn không truy cập được.

- [x] Kho pháp lý AI: tìm nghị định/văn bản theo tên hoặc số hiệu qua procedure tRPC, hiển thị kết quả chính thức và tự điền form nguồn để người quản trị xác nhận.
- [x] Kho pháp lý AI: xử lý an toàn trang HTML/metadata khi AI tự điền URL, không yêu cầu phản hồi JSON trực tiếp.
- [x] Kiểm thử hồi quy luồng tìm văn bản -> chọn kết quả -> tự điền metadata -> lưu vào CSDL.

- [x] Enrichment nguồn pháp lý: nhận diện ứng viên hiệu lực, phiên bản hiện hành/sửa đổi và các văn bản liên quan từ HTML; không tự khẳng định giá trị pháp lý.
- [x] Hiển thị provenance và tệp đính kèm đã phát hiện theo cơ chế xác nhận của quản trị viên.
- [x] Kiểm thử TypeScript và toàn bộ Vitest sau khi cập nhật pipeline pháp lý.

- [x] Redesign thẻ Bất động sản nổi bật: hiển thị diện tích, ngang × dài, giá tổng và giá/m².
- [x] Bổ sung tiêu đề, mô tả ngắn, nút vị trí nhỏ và thông tin phòng ngủ, phòng vệ sinh, số tầng theo loại BĐS.
- [x] Bổ sung hàng liên hệ gọn gồm điện thoại, Zalo, Messenger và Facebook; bảo đảm responsive mobile-first.
- [x] Cập nhật test và kiểm tra preview desktop/mobile cho thẻ bài đăng nổi bật.

- [x] Cập nhật contract test Home.payload theo card nổi bật mới, giữ kiểm tra liên kết, ảnh và các trường thông tin bán hàng hiện tại.

- [x] Gom và sắp xếp lại vùng thông tin card nhà phố theo thứ tự tiêu đề/vị trí, giá, diện tích-kích thước, tiện ích, mô tả và liên hệ; giữ nguyên dữ liệu các loại BĐS khác.

- [x] Tăng kích thước, độ đậm và độ tương phản chữ trong card Bất động sản nổi bật; giữ nguyên kích thước hình ảnh và khung card.

- [x] Tối ưu card Bất động sản nổi bật: tận dụng khoảng trống, gom nội dung thành các dòng ngắn, giảm chiều cao phần chữ và tăng cỡ chữ chính; giữ nguyên vùng ảnh.

- [x] Đưa thông tin chính của card Bất động sản nổi bật lên lớp phủ hình ảnh với nền chuyển sắc dễ đọc.
- [x] Tự động chọn bố cục gallery theo số ảnh: 1 ảnh, 2 ảnh, 3 ảnh hoặc nhiều hơn; giữ nút vị trí và nhãn số ảnh.
- [x] Kiểm tra responsive, accessibility và hồi quy dữ liệu bài đăng cũ sau khi đổi gallery.

- [x] Tăng cỡ chữ và độ đậm của tiêu đề, giá và thông tin chính trên ảnh card nổi bật; mở rộng khung card vừa đủ gần toàn màn hình nhưng giữ lề responsive và không méo ảnh.

- [x] Nối số ảnh người dùng chọn trong form đăng sản phẩm với gallery preview tự động: 1 ảnh/2 ảnh/3 ảnh và cập nhật ngay khi thêm hoặc xóa ảnh.
- [x] Kiểm thử hồi quy luồng đăng bài và dữ liệu ảnh cũ sau khi bổ sung preview động.

- [x] Sửa lỗi cú pháp hiện tại tại server/legalSourceAnalyzer.ts dòng 103 và xác nhận dev server/TypeScript hoạt động ổn định sau thay đổi gallery.

- [x] Đồng bộ header, menu, danh mục và card Bất động sản nổi bật theo giao diện tham chiếu, giữ gallery ở giữa và đưa chữ/thông tin chính vào vùng sản phẩm.
- [x] Đưa nút Trò chuyện với AI lên đầu khu vực sản phẩm và giữ nút vị trí/yêu thích/liên hệ hoạt động.
- [x] Bổ sung nhóm thông tin pháp lý, quy hoạch và hỗ trợ vay vốn vào form đăng bài theo từng loại BĐS, không làm mất các trường hiện có.
- [x] Đồng bộ dữ liệu và hiển thị các nhóm thông tin mới trên card, trang danh mục và trang chi tiết.
- [x] Viết/cập nhật test, kiểm tra responsive desktop/mobile và phát hành bản đồng bộ theo hình tham chiếu.

- [x] Đồng bộ toàn bộ giao diện website theo cùng design system: header/menu, nền, màu xanh, typography, card, form, trang chi tiết, hồ sơ AI, kho pháp lý và khu vực quản trị; giữ nguyên dữ liệu và chức năng.

- [x] Đồng bộ AllDossiersAI từ palette xanh dương cũ sang hệ xanh–kem chung, giữ nguyên tìm kiếm, bộ lọc và liên kết hồ sơ.
- [x] Đồng bộ shell chính của PropertyDossierAdmin từ nâu/be sang xanh–kem chung, giữ nguyên workflow, file manager và dữ liệu hồ sơ.
- [x] Kiểm tra hồi quy TypeScript/Vitest và responsive cho các màn hình vừa đồng bộ.

- [x] Dựng lại trang chủ theo hình tham chiếu: header logo/nút nhanh, menu xanh 4 mục, danh mục nguồn hàng, card nổi bật, gallery, thông tin sản phẩm và Trò chuyện với AI; giữ nguyên dữ liệu và hành vi hiện có.

# Đợt tinh chỉnh trang chủ theo ảnh tham chiếu 2026-08-18

- [x] Căn chỉnh first screen Home: logo, Gọi ngay, Thông báo và Menu theo bố cục compact mobile-first.
- [x] Chuẩn hóa thanh điều hướng xanh 4 mục và lưới danh mục Mua BĐS nhiều màu, không gây tràn ngang.
- [x] Đặt khối Trò chuyện với AI ở đầu vùng sản phẩm nổi bật và giữ CTA rõ ràng.
- [x] Kiểm tra hiển thị card nổi bật: tiêu đề, diện tích, ngang × dài, hướng, đường, phòng ngủ, WC, giá, giá/m², pháp lý và hỗ trợ vay trước gallery.
- [x] Kiểm tra responsive Home ở 390px và desktop 1280px.
- [x] Chạy TypeScript và Vitest sau khi hoàn tất chỉnh sửa trang chủ.
- [x] Lưu checkpoint phát hành sau khi TODO được rà soát.

- [x] Đã rà soát cấu trúc Home.tsx và xác định các khối cần chỉnh; tiếp tục triển khai ở đợt này.
- [x] Hoàn tất tinh chỉnh first screen và xác minh trực quan sau chỉnh sửa.
- [x] Hoàn tất kiểm tra kỹ thuật và lưu checkpoint cho đợt tinh chỉnh này.

## Lịch sử đợt tinh chỉnh trang chủ
- [x] Header first screen đã căn chỉnh theo ảnh tham chiếu.
- [x] Thanh điều hướng và lưới danh mục đã căn chỉnh theo ảnh tham chiếu.
- [x] Khối AI chat đã đặt đúng đầu vùng sản phẩm.
- [x] Card featured và metadata pháp lý/vay vốn đã được xác minh.
- [x] Responsive 390px/1280px đã được xác minh.
- [x] TypeScript/Vitest đã đạt.
- [x] Checkpoint đã lưu và phát hành.

# Đợt UX card sản phẩm — hover và lướt ảnh trực tiếp

- [x] Thêm hiệu ứng hover/focus tinh tế cho card sản phẩm, không ảnh hưởng liên kết chi tiết.
- [x] Cho phép lướt/chuyển ảnh trực tiếp trên card bằng nút trước/sau và chấm chỉ báo.
- [x] Bảo đảm gallery card không tràn ngang, hỗ trợ thao tác chạm trên mobile và không làm nút card bị kích hoạt ngoài ý muốn.
- [x] Bổ sung/điều chỉnh test cho trạng thái gallery và chạy TypeScript/Vitest.
- [x] Kiểm tra preview desktop 1280px và mobile 390px.
- [x] Rà soát TODO và lưu checkpoint phát hành.

# Đợt căn chỉnh Bất động sản nổi bật theo ảnh tham chiếu

- [x] Tái cấu trúc khu Bất động sản nổi bật theo bố cục dọc: tiêu đề, lưới danh mục 2 hàng và card ảnh lớn.
- [x] Thiết kế gallery card gồm ảnh chính, ảnh phụ và ô bản đồ mini khi listing có tọa độ.
- [x] Đặt vị trí, tiêu đề, yêu thích, thông số, giá và giá/m² theo thứ tự gần ảnh mẫu.
- [x] Thu nhỏ nút Trò chuyện với AI nổi và nút Bắt đầu hỏi thêm một cấp, không che nội dung card.
- [x] Kiểm tra responsive 390px/1280px, hover/focus, gallery và bản đồ mini.
- [x] Chạy TypeScript/Vitest, cập nhật TODO và lưu checkpoint phát hành.

# Đợt chỉnh card featured theo yêu cầu mới

- [x] Giữ các nhóm BĐS nổi bật như ảnh tham chiếu, gồm Đất nền và các nhóm liên quan.
- [x] Đặt vị trí, tiêu đề, thông tin nhanh, giá và giá/m² ở phía trên card.
- [x] Thay gallery chia nhiều ô bằng một khung ảnh lớn duy nhất.
- [x] Thêm nút ảnh trước/sau để xem tuần tự toàn bộ ảnh trong card.
- [x] Giữ số ảnh, nhãn loại BĐS, nút xem vị trí và liên kết chi tiết hoạt động đúng.
- [x] Kiểm tra mobile/desktop, TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt gom nhóm Đất nền theo ảnh mẫu, giữ nguyên giao diện còn lại

- [x] Chỉnh riêng lưới danh mục trong khu Bất động sản nổi bật theo nhóm Đất nền và các mục con/liên quan giống ảnh mẫu.
- [x] Giữ nguyên header, thanh menu, hình ảnh, thông tin card, gallery một ảnh lớn và các nút liên hệ hiện có.
- [x] Bảo đảm chọn từng danh mục vẫn lọc đúng sản phẩm, không làm thay đổi dữ liệu backend.
- [x] Kiểm tra responsive 390px/1280px và chạy TypeScript/Vitest.
- [x] Rà soát TODO và lưu checkpoint phát hành.

# Đợt bổ sung bộ đếm bài đăng trên ô danh mục

- [x] Tính số bài đăng featured theo từng danh mục từ dữ liệu hiện có.
- [x] Hiển thị bộ đếm trên từng ô danh mục BĐS, gồm cả nhóm Đất nền và các mục con.
- [x] Bảo đảm bộ đếm không làm thay đổi bộ lọc, gallery, hình ảnh hoặc bố cục responsive.
- [x] Bổ sung contract test cho số lượng từng danh mục và chạy TypeScript/Vitest.
- [x] Kiểm tra preview mobile/desktop, rà soát TODO và lưu checkpoint phát hành.

# Đợt chuẩn hóa 10 ô Bất động sản nổi bật theo ảnh mẫu

- [x] Chuẩn hóa 10 ô danh mục: Nhà phố, Căn hộ, Đất nền, Đất nông nghiệp, Đất khu công nghiệp, Khu thương mại, Resort–Villa, Khu nghỉ dưỡng, Đất dự án, Cho thuê.
- [x] Hiển thị bộ đếm số bài đăng trên từng ô theo dữ liệu featured thực tế.
- [x] Giữ nguyên header, thanh menu, card, hình ảnh, vị trí thông tin, gallery và nút AI.
- [x] Bảo đảm chọn từng ô vẫn lọc đúng danh mục và nhóm Đất nền vẫn gom đúng các mục đất con.
- [x] Kiểm tra responsive 390px/1280px, TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt tạo 10 ô danh mục nhiều màu theo ảnh mẫu

- [x] Áp dụng màu riêng cho 10 ô danh mục BĐS giống ảnh tham chiếu.
- [x] Hiển thị biểu tượng, tên danh mục và bộ đếm rõ ràng trong từng ô.
- [x] Giữ nguyên bộ lọc, dữ liệu bài đăng, header, card, gallery và nút AI.
- [x] Kiểm tra bố cục 2 hàng trên mobile và hàng ngang trên desktop.
- [x] Chạy TypeScript/Vitest, rà soát TODO và lưu checkpoint phát hành.

# Đợt cập nhật bộ đếm danh mục theo thời gian thực

- [x] Xác định luồng sự kiện khi bài đăng mới được công khai và nguồn dữ liệu bộ đếm.
- [x] Làm mới danh sách/bộ đếm danh mục tự động sau khi dữ liệu bài đăng thay đổi.
- [x] Có cơ chế dự phòng polling nhẹ hoặc refetch khi phiên realtime không khả dụng.
- [x] Bảo đảm không tạo vòng lặp refetch, không làm thay đổi bộ lọc và giữ nguyên UI hiện tại.
- [x] Bổ sung contract test cho cập nhật bộ đếm, chạy TypeScript/Vitest và kiểm tra responsive.
- [x] Rà soát TODO và lưu checkpoint phát hành.

# Đợt ẩn khung AI phía trên Bất động sản nổi bật

- [x] Xóa khung “Trò chuyện với AI – Bắt đầu hỏi” khỏi phía trên khu Bất động sản nổi bật trên trang đầu.
- [x] Giữ nguyên launcher AI nổi toàn cục, 10 ô danh mục, bộ đếm, card và gallery.
- [x] Kiểm tra responsive desktop/mobile, chạy TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt làm rõ thông tin bài đăng theo ảnh tham chiếu Chrome
- [x] Làm vị trí bài đăng lớn, đậm và rõ ở đầu card.
- [x] Làm tiêu đề, giá tổng và giá/m² nổi bật theo thứ bậc trong ảnh mẫu.
- [x] Sắp xếp diện tích, ngang × dài, hướng, đường, phòng ngủ và phòng vệ sinh thành lưới dễ đọc.
- [x] Giữ nhãn loại BĐS, pháp lý, quy hoạch, vay vốn, nút liên hệ và gallery ảnh hiện có.
- [x] Kiểm tra responsive 390px/1280px, chạy TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt đổi CTA và bổ sung bản đồ mini trong ảnh bài đăng
- [x] Đổi nút “Chi tiết” thành “Xem chi tiết” trên card bất động sản nổi bật.
- [x] Tích hợp bản đồ mini trong vùng hình ảnh và mở bằng nút “Vị trí”.
- [x] Giữ nguyên gallery, nút chuyển ảnh, nhãn pháp lý/quy hoạch/vay vốn và bố cục responsive.
- [x] Kiểm tra TypeScript, Vitest và giao diện mobile/desktop trước khi lưu checkpoint.

# Làm rõ hành vi nút Vị trí trong gallery
- [x] Khi bấm “Vị trí”, thay vùng ảnh bằng bản đồ mini có ghim tọa độ bài đăng.
- [x] Thêm nút quay lại ảnh/đóng bản đồ trong chính khung gallery.
- [x] Không mở phần mô tả địa chỉ thay cho bản đồ; giữ nguyên CTA “Xem chi tiết”.

# Đợt bỏ bộ lọc Tin xác thực trên danh sách nguồn hàng
- [x] Xóa nút/bộ lọc “Tin xác thực” khỏi hàng điều khiển danh sách sản phẩm.
- [x] Cân chỉnh lại hàng bộ lọc mobile sau khi bỏ nút, giữ Lọc, tìm kiếm, yêu thích và Tất cả.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint phát hành.

# Đợt điều chỉnh vị trí gallery và CTA trong card
- [x] Đưa hình ảnh/gallery lên ngay dưới phần chữ hỗ trợ vay vốn.
- [x] Đưa hàng Xem chi tiết, Gọi, Zalo, Messenger và Facebook xuống dưới hình ảnh.
- [x] Chỉ đổi thứ tự vùng này, giữ nguyên kích thước ảnh, nội dung, bản đồ mini và các chức năng khác.
- [x] Kiểm tra responsive 390px/1280px, chạy TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt phân tích lỗi tìm nghị định trong AI Kho pháp lý
- [x] Xác minh số hiệu hiển thị trong ảnh và phân biệt lỗi nhập “NĐ-CI” với ký hiệu đúng “NĐ-CP”.
- [x] Rà soát luồng tìm kiếm kho pháp lý, chuẩn hóa số hiệu và truy vấn không dấu/ký hiệu.
- [x] Hiển thị cảnh báo khi văn bản chưa được xác minh, không coi nguồn gợi ý là nguồn chính thức.
- [x] Bổ sung cơ chế đối chiếu nguồn chính thức và trạng thái kết quả tìm kiếm.
- [x] Viết test cho các biến thể số hiệu nghị định và kiểm tra TypeScript/Vitest.

# Đợt đưa toàn bộ CTA xuống dưới hình ảnh
- [x] Đưa cùng một hàng gồm Xem chi tiết, Gọi, Zalo, Messenger và Facebook xuống ngay dưới gallery.
- [x] Giữ nguyên thứ tự, liên kết và hành vi của toàn bộ nút liên hệ.
- [x] Không thay đổi thông tin bài đăng, bản đồ mini, gallery và bộ lọc hiện có.
- [x] Kiểm tra responsive, TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt đồng bộ mẫu bài đăng theo ảnh tham chiếu
- [x] Rà soát trang Nguồn hàng, trang Xem chi tiết nguồn hàng và trang bài đăng sản phẩm để xác định vùng hiển thị tương ứng.
- [x] Đồng bộ thứ tự vị trí, tiêu đề, giá, giá/m², diện tích và lưới thông số.
- [x] Đồng bộ nhãn pháp lý, quy hoạch, vay vốn, gallery, nút Vị trí và hàng CTA.
- [x] Giữ đúng dữ liệu và hành vi riêng của từng trang, chỉ thống nhất mẫu hiển thị.
- [x] Kiểm tra responsive, TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt tinh chỉnh CTA mobile
- [x] Làm hàng Xem chi tiết và các nút Gọi/Zalo/Messenger/Facebook gọn hơn trên mobile.
- [x] Bảo đảm hàng CTA không tràn ngang, vẫn dễ nhận biết và giữ đúng liên kết.
- [x] Không thay đổi bố cục desktop hoặc hành vi gallery/bản đồ mini.
- [x] Kiểm tra responsive 390px/1280px, TypeScript/Vitest và lưu checkpoint phát hành.

# Đợt tùy chọn bố cục ảnh khi đăng sản phẩm
- [x] Rà soát form đăng sản phẩm, schema/listing và component hiển thị dùng chung.
- [x] Thêm tùy chọn bố cục 1 ảnh lớn, 2 ảnh chia đôi và 3+ ảnh linh hoạt.
- [x] Lưu bố cục đã chọn và đồng bộ trên trang cá nhân, Nguồn hàng và Xem chi tiết.
- [x] Giữ tương thích với bài đăng cũ chưa có cấu hình bố cục.
- [x] Kiểm tra responsive, TypeScript/Vitest và lưu checkpoint phát hành.

- [x] Tích hợp bộ chọn gallery 1 ảnh, 2 ảnh hoặc 3+ ảnh; lưu listingDetails, đồng bộ catalog/detail/preview và kiểm thử 190/190 đạt.

# Đợt điều hướng Dashboard CRM
- [x] Đưa thanh điều hướng CRM lên đầu khu vực Dashboard
- [x] Liên kết Dashboard BĐS, Quy trình giao dịch, Marketing, AI Assistant và Báo cáo
- [x] Bổ sung trạng thái active và responsive cho thanh điều hướng CRM
- [x] Kiểm tra TypeScript/Vitest, responsive và lưu checkpoint phát hành

# Cập nhật thanh điều hướng CRM đầy đủ
- [x] Đưa toàn bộ mục Dashboard, BĐS, Khách hàng, Hồ sơ, Quy trình, Giao dịch, Marketing, AI Assistant và Báo cáo lên thanh đầu trang
- [x] Giữ active state, cuộn ngang mobile và kiểm thử điều hướng

# Xác minh thanh CRM chưa hiển thị đầy đủ
- [x] Kiểm tra đúng route Dashboard CRM và phiên bản đang được người dùng mở
- [x] Sửa để toàn bộ mục CRM hiển thị ở vị trí người dùng yêu cầu và xác minh lại

# Bộ điều phối khách hàng AI và CRM
- [x] Đồng bộ các điểm AI tư vấn thành một luồng thu thập nhu cầu thống nhất
- [x] Phân loại khu vực, tìm nguồn hàng phù hợp và chấm lead nóng/ấm/lạnh
- [x] Tạo lead CRM kèm lịch sử hội thoại và nhu cầu khách hàng
- [x] Điều phối lead theo môi giới khu vực, môi giới dự phòng và quản trị viên
- [x] Đồng bộ giao diện AI công khai, CRM và thông báo quản trị
- [x] Bổ sung kiểm thử phân quyền, điều phối và hồi quy

# Hồ sơ điện tử AI và Đăng đa kênh theo giao diện tham chiếu
- [x] Thiết kế riêng khu vực Hồ sơ điện tử AI với sidebar, danh sách và chi tiết hồ sơ
- [x] Bổ sung tiến độ hồ sơ, các tab thông tin và khu vực AI hỗ trợ theo từng hạng mục
- [x] Tích hợp Đăng đa kênh vào giao diện hồ sơ và hiển thị nội dung theo mục được chọn
- [x] Kiểm tra responsive, điều hướng, TypeScript và Vitest

# Khắc phục dữ liệu Hồ sơ điện tử AI
- [x] Đối chiếu truy vấn Hồ sơ điện tử AI với Kho hồ sơ và dữ liệu hồ sơ hiện có
- [x] Sửa kết nối dữ liệu, quyền truy cập và fallback trạng thái rỗng/loading
- [x] Bổ sung kiểm thử dữ liệu hiển thị và xác minh giao diện sau khi sửa

# Sửa thẻ Hồ sơ điện tử AI không mở dữ liệu
- [x] Khi bấm thẻ Hồ sơ điện tử AI phải mở đúng danh sách hồ sơ đã lưu
- [x] Hiển thị empty state có nút tạo hồ sơ mới nếu chưa có dữ liệu
- [x] Kiểm thử thao tác trên mobile và xác minh truy vấn dữ liệu thật

# Hoàn thiện Hồ sơ điện tử AI theo mô hình tham chiếu
- [x] Xây dựng dashboard tổng quan hồ sơ BĐS với các chỉ số chính
- [x] Hiển thị bảng danh sách hồ sơ và thao tác xem hồ sơ
- [x] Hiển thị chi tiết hồ sơ, tiến độ 12 bước và các tab nghiệp vụ
- [x] Nối thẻ Hồ sơ điện tử AI với giao diện quản lý hồ sơ đầy đủ
- [x] Kiểm thử dữ liệu thật, responsive và các thao tác chọn hạng mục

# Sửa hai thẻ workspace đang trống
- [x] Nối thẻ Hồ sơ điện tử AI với workspace danh sách và chi tiết hồ sơ thật
- [x] Nối thẻ Đăng đa kênh với workspace kênh đăng và trạng thái nội dung thật
- [x] Kiểm thử bấm thẻ, dữ liệu hiển thị, responsive và tránh thẻ giới thiệu trống

# Hoàn thiện giao diện Hồ sơ điện tử AI theo ảnh tham chiếu
- [x] Sửa lỗi TypeScript đang chặn hiển thị số liệu trên thẻ Đăng đa kênh
- [x] Làm rõ bố cục dashboard, bảng danh sách và chi tiết hồ sơ giống ảnh tham chiếu
- [x] Đảm bảo thẻ Hồ sơ điện tử AI và Đăng đa kênh mở workspace có dữ liệu thật
- [x] Kiểm tra desktop/mobile, điều hướng và toàn bộ test trước checkpoint

# Sửa nút Mở quản lý Hồ sơ điện tử AI
- [x] Gắn nút Mở quản lý với route /ho-so-dien-tu thật
- [x] Cho phép bấm toàn bộ thẻ hoặc nút đều mở workspace hồ sơ
- [x] Kiểm thử điều hướng trên mobile và desktop

- [x] Sửa nút Mở quản lý của Hồ sơ điện tử AI để mở đúng vùng quản lý và cuộn đến workspace
- [x] Xác minh nút Đăng đa kênh mở đúng workspace tương ứng
- [x] Kiểm thử TypeScript và Vitest sau thay đổi điều hướng

# Bảng điều khiển menu trung tâm website
- [x] Rà soát toàn bộ route và menu chính hiện có
- [x] Tạo bảng điều khiển gom các cửa sổ làm việc chính
- [x] Kết nối từng mục menu với route/chức năng tương ứng
- [x] Kiểm tra responsive, TypeScript và Vitest

# Phân nhóm menu trung tâm theo danh mục lớn
- [x] Xác định các nhóm menu lớn và menu con theo từng khu vực làm việc
- [x] Chuyển bảng menu thành giao diện phân cấp có thể mở/thu gọn
- [x] Kết nối menu con với đúng route hiện có
- [x] Kiểm tra lọc nhóm, responsive, TypeScript và Vitest

# Bổ sung toàn bộ menu lớn của website vào bảng trung tâm
- [x] Kiểm kê tất cả route, menu đầu trang, CRM và các module AI
- [x] Bổ sung đầy đủ nhóm menu lớn, không chỉ các nhóm hồ sơ hiện tại
- [x] Bổ sung menu con và liên kết đúng cửa sổ làm việc
- [x] Kiểm tra số lượng nhóm hiển thị, điều hướng, TypeScript và Vitest

# Phân cấp menu phụ trong các menu lớn
- [x] Kiểm kê menu phụ và tab chức năng của từng module hiện có
- [x] Bổ sung cấu trúc menu phụ nhiều cấp vào bảng trung tâm
- [x] Kết nối từng menu phụ với đúng cửa sổ hoặc route
- [x] Kiểm tra hiển thị, điều hướng, TypeScript và Vitest

# Nút nhu cầu tìm nguồn hàng trên trang chủ
- [x] Thêm nút nhỏ màu xanh cạnh “Xem tất cả nguồn hàng”
- [x] Mở biểu mẫu nhập nhu cầu khách hàng khi bấm nút
- [x] Giữ bố cục gọn và responsive trên desktop/mobile
- [x] Bổ sung kiểm thử và kiểm tra TypeScript/Vitest

# AI tìm nguồn hàng theo nhu cầu khách
- [x] Đặt nút “AI TÌM NGUỒN HÀNG” cạnh “Xem tất cả nguồn hàng” theo bố cục ảnh mẫu
- [x] Tạo form loại BĐS, khu vực, ngân sách, diện tích, mục đích, số phòng, pháp lý, yêu cầu đặc biệt và ưu tiên
- [x] Lọc nguồn hàng và hiển thị điểm phù hợp sau khi gửi nhu cầu
- [x] Kiểm thử responsive, TypeScript và Vitest

# Yêu cầu tìm nguồn hàng theo nhu cầu
- [x] Đặt nút nhỏ cạnh “Xem tất cả nguồn hàng” theo đúng vị trí ảnh tham chiếu
- [x] Mở hộp thoại yêu cầu tìm nguồn hàng với các trường nhu cầu khách
- [x] Đưa yêu cầu đã gửi vào mục Yêu cầu tư vấn
- [x] Hiển thị AI phân tích, lọc kho hàng và xếp hạng mức độ phù hợp
- [x] Kiểm thử responsive, TypeScript và Vitest

# Điều chỉnh tiêu đề khu vực BĐS nổi bật
- [x] Tách “Nguồn hàng chính chủ” và “Bất động sản nổi bật” thành hai dòng rõ ràng
- [x] Đưa “Tìm nguồn hàng” và “Xem tất cả nguồn hàng” xuống hàng riêng bên dưới
- [x] Kiểm tra responsive và giữ nguyên chức năng các nút

# Thu gọn vùng tiêu đề BĐS nổi bật
- [x] Đưa AI tìm hàng và Xem tất cả nguồn hàng lên cùng hàng với tiêu đề
- [x] Gom vùng tiêu đề thành một khối gọn, không còn hàng nút riêng
- [x] Kiểm tra desktop/mobile và giữ nguyên chức năng nút

# Căn chỉnh lại tiêu đề và nút BĐS nổi bật
- [x] Ghép “Nguồn hàng chính chủ” thành một hàng gọn
- [x] Ghép “Bất động sản nổi bật” thành một hàng gọn
- [x] Xếp AI tìm kiếm hàng phía trên Xem tất cả nguồn hàng, căn đều đẹp
- [x] Kiểm tra desktop/mobile và giữ nguyên chức năng nút

# Đồng bộ trang Nguồn hàng theo bộ lọc mẫu
- [x] Đặt “Tất cả loại” làm lựa chọn mặc định và luôn hiển thị đầu tiên
- [x] Đồng bộ hàng tìm kiếm, Lọc, Tất cả loại và sắp xếp theo ảnh tham chiếu
- [x] Cho phép chọn từng loại rồi quay lại “Tất cả loại”
- [x] Kiểm tra responsive, TypeScript và Vitest

# Xóa yêu cầu tư vấn đã xử lý
- [x] Hiển thị nút Xóa khi yêu cầu ở trạng thái Đã xem hoặc Đã liên hệ
- [x] Thêm hộp thoại xác nhận trước khi xóa
- [x] Kết nối thao tác xóa với dữ liệu tư vấn và cập nhật danh sách
- [x] Bổ sung test trạng thái, TypeScript và Vitest

# Tư vấn vay vốn trong quy trình 12 bước
- [x] Xác định vị trí mục vay vốn trong quy trình môi giới 12 bước
- [x] Thêm biểu mẫu nhu cầu vay, khả năng tài chính và tài sản bảo đảm
- [x] Thêm trạng thái tư vấn, hồ sơ và kết nối chuyên viên/ngân hàng
- [x] Kiểm thử TypeScript và Vitest

# Đăng đa kênh Facebook cá nhân và Zalo cá nhân
- [x] Bổ sung lựa chọn Facebook cá nhân và Zalo cá nhân trong workspace Đăng đa kênh
- [x] Tạo trạng thái kết nối tài khoản và bản xem trước bài đăng
- [x] Yêu cầu xác nhận trước khi đăng lên từng kênh
- [x] Kết nối API/connector thật khi có quyền phù hợp; không giả lập đăng thành công — hiện chưa bật vì kiểm tra cấu hình không có connector Facebook/Zalo; UI giữ nút Kết nối Page/OA để chờ quyền chính thức.
- [x] Bổ sung test TypeScript và Vitest

# Phương án C: Page/Official Account và tài khoản cá nhân
- [x] Thêm lựa chọn Facebook Page/Zalo Official Account và Facebook cá nhân/Zalo cá nhân
- [x] Hiển thị trạng thái kết nối riêng cho từng loại tài khoản
- [x] Hỗ trợ đăng trực tiếp khi có API/connector hợp lệ — đã chuẩn bị luồng kết nối và trạng thái, chưa gọi API khi chưa có connector hợp lệ.
- [x] Hỗ trợ tạo nội dung và mở màn hình soạn sẵn cho tài khoản cá nhân
- [x] Thêm bản xem trước và xác nhận trước khi đăng

- [x] Đăng đa kênh: hỗ trợ chọn tài khoản Page/OA để đăng API hoặc tài khoản cá nhân để chuẩn bị và mở Facebook/Zalo đăng thủ công.
- [x] Đăng đa kênh: hiển thị nút hành động theo loại tài khoản, ghi nhật ký kênh + loại tài khoản + thao tác, và lưu localStorage tương thích bản nháp cũ.
- [x] Đăng đa kênh: thêm test contract cho deep link/copy nội dung và kiểm tra TypeScript/Vitest.
- [x] Đăng đa kênh: kiểm tra preview responsive và lưu checkpoint phát hành.

- [x] Khắc phục lỗi workspace Đăng đa kênh chưa hiển thị rõ lựa chọn Facebook cá nhân và Zalo cá nhân trên bản xem trước.

# Nâng cấp Hồ sơ đất đai AI theo mẫu người dùng gửi
- [x] Đối chiếu kiến trúc hiện tại với yêu cầu Legal Knowledge Base, Procedure Engine, Form Engine, Dossier Engine và Document Generator.
- [x] Thiết kế phạm vi an toàn cho luồng chuyển nhượng quyền sử dụng đất đầu tiên; chỉ dùng căn cứ đã xác minh, không tự bịa văn bản/biểu mẫu.
- [x] Bổ sung mô hình thủ tục, căn cứ pháp lý, biểu mẫu, phiên bản hiệu lực và quy tắc kiểm tra hồ sơ dùng chung giữa AI pháp lý và hồ sơ đất đai AI — sử dụng các bảng legal_sources, legal_documents, legal_procedures, legal_procedure_requirements, legal_templates và legal_template_fields hiện có.
- [x] Bổ sung giao diện từng bước chọn địa phương, xác nhận thủ tục, nhập người sử dụng đất, thửa đất, giao dịch và tải giấy tờ.
- [x] Bổ sung AI kiểm tra trạng thái đủ/kiểm tra/còn thiếu và traceability cho từng thành phần hồ sơ.
- [x] Tạo DOCX/PDF thật từ dữ liệu đã xác nhận, xem trước, tải từng file và tải toàn bộ bộ hồ sơ; không tạo nút tải giả — exportBundle dùng docx/Packer và pdf-lib, có preview, tải riêng và ZIP.
- [x] Lưu hồ sơ điện tử, phiên bản chỉnh sửa và liên kết CRM; viết test backend/frontend và kiểm tra phát hành.

# Media đăng bài trong Hồ sơ điện tử AI
- [x] Tích hợp bộ soạn bài Đăng đa kênh trực tiếp trong workspace Hồ sơ điện tử AI.
- [x] Cho phép tải nhiều ảnh/video từ thiết bị, xem trước, xóa và sắp xếp media.
- [x] Cho phép mở camera, chụp ảnh và quay video bằng MediaDevices khi trình duyệt cấp quyền.
- [x] Kết nối media và nội dung hồ sơ với bản xem trước Facebook/Zalo/Website, giữ phân biệt hồ sơ pháp lý và media công khai.
- [x] Kiểm thử TypeScript/Vitest, responsive và phát hành.

# Module Hồ sơ đất đai AI hoàn chỉnh theo mẫu người dùng
- [x] Gộp yêu cầu hai mẫu vào một luồng Hồ sơ đất đai AI thống nhất giữa AI pháp lý, kho văn bản, kho biểu mẫu, quy định địa phương, hồ sơ điện tử và CRM.
- [x] Bổ sung nhóm thủ tục và lựa chọn địa phương, AI đề xuất thủ tục nhưng bắt buộc người dùng xác nhận trước khi lập hồ sơ.
- [x] Hoàn thiện Form Engine: phiên bản, địa phương áp dụng, file gốc, trường dữ liệu, quy tắc bắt buộc và căn cứ pháp lý.
- [x] Hoàn thiện Dossier Engine: tự lập danh mục thành phần hồ sơ, lý do đưa từng file vào và traceability nguồn.
- [x] Hoàn thiện AI kiểm tra đủ/cần kiểm tra/còn thiếu, đối chiếu dữ liệu giữa giấy tờ và khóa xuất khi thiếu trường bắt buộc.
- [x] Hoàn thiện tạo DOCX/PDF/ZIP thật, xem trước từng tài liệu, in, tải từng file và tải toàn bộ bộ hồ sơ.
- [x] Hoàn thiện chỉnh sửa dữ liệu, xác định file bị ảnh hưởng, tăng phiên bản và giữ snapshot pháp lý hồ sơ cũ.
- [x] Hoàn thiện quản trị văn bản, biểu mẫu, thủ tục, nguồn chính thức, hiệu lực và quy định địa phương.
- [x] Hoàn thiện AI chat có nguồn và liên kết CRM cho hồ sơ.
- [x] Viết test, kiểm tra responsive và phát hành từng mốc; không khẳng định mẫu gốc nếu chưa được nạp và xác minh.

# AI truy xuất nguồn và lọc biểu mẫu theo nghị định
- [x] Thiết kế pipeline truy xuất thụ động từ Cổng thông tin Chính phủ, Cổng Dịch vụ công và nguồn pháp luật chính thức đã cấu hình.
- [x] Trích xuất thủ tục, thành phần hồ sơ, biểu mẫu, căn cứ điều/khoản/điểm và ngày hiệu lực từ nội dung nguồn.
- [x] Ghép biểu mẫu vào thủ tục chỉ khi có căn cứ hoặc nguồn chính thức xác minh; nếu không đủ thì hiển thị CHƯA XÁC MINH.
- [x] Tải/nạp file mẫu gốc vào kho lưu trữ sau khi kiểm tra MIME, checksum, nguồn, phiên bản và phạm vi địa phương.
- [x] Hiển thị traceability của từng file trong Builder và dùng file đã xác minh khi tạo bộ hồ sơ.
- [x] Viết test pipeline và phát hành theo phạm vi nguồn đã xác minh.
- [x] Tạo bộ mẫu nội bộ có tên riêng “AI · BỘ HỒ SƠ ĐẤT ĐAI HOÀN CHỈNH · THEO YÊU CẦU NGƯỜI DÙNG” trong Kho pháp lý AI, gồm quy trình A/B/C, danh mục gợi ý, quản trị phiên bản và cảnh báo chưa phải mẫu nhà nước gốc.

# Kho mẫu DOCX/PDF theo tỉnh
- [x] Thêm bộ lọc tỉnh/thành, thủ tục và cơ quan tiếp nhận trong Kho pháp lý AI.
- [x] Thêm form nạp DOCX/PDF gốc với nguồn chính thức, số hiệu, phiên bản, ngày hiệu lực, tỉnh áp dụng và cơ quan tiếp nhận.
- [x] Lưu file vào S3, metadata vào database, kiểm tra MIME/checksum và không đánh dấu xác minh tự động.
- [x] Liên kết mẫu đã xác minh với các mục hồ sơ tạo đất đai và Builder.
- [x] Hiển thị rõ trạng thái Chưa xác minh/Đang kiểm tra/Đã xác minh và kiểm thử phát hành.

# Tự đọc nguồn chính thức và lọc biểu mẫu
- [x] Kiểm tra URL http://www.monre.gov.vn/ và PDF Nghị định 101/2024/NĐ-CP do người dùng cung cấp.
- [x] Xác định nguyên nhân pipeline hiện tại chưa tự tải/đọc nguồn và chưa tự ghép biểu mẫu.
- [x] Bổ sung luồng tự truy xuất nguồn, lưu bản ghi văn bản, ngày kiểm tra và trạng thái xác minh.
- [x] Lọc biểu mẫu theo nội dung nghị định/thủ tục, chỉ đánh dấu mẫu gốc khi có file và nguồn xác minh.
- [x] Viết test, kiểm tra preview và phát hành bản cập nhật — TypeScript/Vitest và preview đã đạt.

# Điều chỉnh mô hình dựng bộ hồ sơ trước khi nộp
- [x] Cho phép AI tự phân tích nguồn pháp luật và thủ tục để dựng bộ hồ sơ hoàn chỉnh theo trường hợp người dùng, kể cả khi chưa có binary mẫu gốc.
- [x] Phân biệt rõ hồ sơ AI dựng theo căn cứ pháp lý với mẫu Official của cơ quan; không chặn việc tạo bản nháp để người dùng xem, sửa và in.
- [x] Bổ sung trạng thái hồ sơ: AI đã dựng, cần người dùng kiểm tra, đã xác nhận dữ liệu, sẵn sàng in/ký, đã nộp thủ công.
- [x] Tạo checklist cuối hồ sơ gồm giấy tờ, chữ ký, bản sao/bản gốc, nghĩa vụ tài chính và cơ quan tiếp nhận để người dùng tự kiểm tra trước khi nộp.
- [x] Hiển thị cảnh báo rõ rằng bộ hồ sơ AI dựng cần được người dùng/cơ quan tiếp nhận kiểm tra trước khi nộp; không tự tuyên bố chắc chắn được tiếp nhận.
- [x] Viết test cho luồng dựng hồ sơ không phụ thuộc mẫu binary gốc, xem trước, chỉnh sửa, xuất DOCX/PDF/ZIP và checklist trước khi nộp.
- [x] Kiểm tra preview và phát hành phiên bản cập nhật sau khi hoàn tất luồng mới.

# Phạm vi nguồn pháp luật cần mở rộng
- [x] Bổ sung cơ chế quản lý nhiều luật, nghị định, thông tư và quy định địa phương theo từng thủ tục, thay vì chỉ dựa trên một nghị định. Backend đã lưu nhiều source/document/procedure/requirement/template, hỗ trợ sourceUrl, province và receivingAuthority; dữ liệu văn bản mới vẫn phải được nạp và rà soát riêng.
- [x] Bổ sung OCR hoặc nguồn PDF có lớp văn bản để AI đọc được tài liệu người dùng tải lên và tự điền dữ liệu sau khi người dùng xác nhận. Luồng ingest hiện lưu tệp vào storage, dùng trích xuất/vision OCR cho ảnh hoặc PDF ít văn bản, trả confidence/warnings và chỉ tạo dữ liệu sau bước người dùng rà soát.

# Tích hợp binary mẫu gốc gần khối kiểm tra nguồn
- [x] Thêm khu vực “Binary mẫu gốc cần xác minh” ngay cạnh khối kiểm tra nguồn trong Hồ sơ đất đai AI.
- [x] Cho phép chọn DOCX/PDF, hiển thị tên tệp, dung lượng, MIME và checksum SHA-256 trước khi gửi.
- [x] Hiển thị metadata mẫu: số hiệu, phiên bản, ngày hiệu lực, tỉnh áp dụng, cơ quan tiếp nhận và URL nguồn.
- [x] Hiển thị trạng thái Chưa nạp / Đang kiểm tra / Cần rà soát / Đã xác minh; không tự chuyển Official chỉ vì đã tải tệp.
- [x] Chỉ cho phép chọn binary trong Builder khi tệp đã có nguồn, checksum và được quản trị viên xác minh.
- [x] Bổ sung test UI/backend và kiểm tra preview desktop/mobile sau khi tích hợp.

# AI tự tìm binary mẫu gốc từ nguồn chính thức
- [x] Xây danh sách miền nguồn được phép và ưu tiên Cổng Dịch vụ công, cổng cơ quan nhà nước, MONRE/Chính phủ, không tải từ nguồn không xác định.
- [x] Cho AI tìm liên kết DOCX/PDF ứng viên theo mã thủ tục, tên biểu mẫu, nghị định, tỉnh và cơ quan tiếp nhận.
- [x] Tải binary ứng viên về storage, kiểm tra MIME, dung lượng, checksum và lưu URL nguồn gốc.
- [x] Đưa ứng viên vào khu “Binary mẫu gốc cần xác minh” cạnh kiểm tra nguồn; không tự chuyển Official.
- [x] Hiển thị lý do chọn ứng viên, nguồn, ngày tải, checksum và cảnh báo CAPTCHA/không truy cập được nếu có.
- [x] Bổ sung test chống tải từ miền không cho phép và test trạng thái ứng viên chưa xác minh.

# Sửa lỗi bản xuất chưa phải mẫu cơ quan nhà nước
- [x] Không xuất bản nháp AI dưới tên hoặc giao diện gây hiểu là mẫu cơ quan nhà nước.
- [x] Khi người dùng yêu cầu mẫu chính thức, AI phải tìm binary DOCX/PDF từ nguồn nhà nước được phép theo đúng thủ tục/tỉnh/cơ quan trước khi xuất.
- [x] Nếu chưa tìm được mẫu chính thức, hiển thị rõ “Chưa có mẫu cơ quan nhà nước được xác minh” và không tạo tệp giả dạng Official.
- [x] Ánh xạ dữ liệu hồ sơ vào binary mẫu đã xác minh; giữ nguyên tiêu đề, bố cục, trường và hướng dẫn của mẫu gốc.
- [x] Tạo bộ hồ sơ riêng gồm các mẫu chính thức và giấy tờ kèm theo, không chỉ tạo một tờ đơn tham khảo.
- [x] Thêm test kiểm tra nhãn CONFIRMED DRAFT/Official, nguồn binary và trạng thái xuất hồ sơ.
- [x] Kiểm tra lại preview và phát hành sau khi sửa luồng xuất mẫu chính thức.

- [x] Đăng ký binary Mẫu 11/ĐK đã tải từ nguồn Chính phủ vào allowlist server với storage key và SHA-256.
- [x] Hoàn thiện luồng xuất Official dùng binary đã xác minh, không fallback âm thầm sang bản nháp.
- [x] Bổ sung UI quản trị phê duyệt binary Pending thành Verified/Official với kiểm tra metadata và checksum.
- [x] Cải thiện ánh xạ dữ liệu DOCX/PDF chính thức, cảnh báo rõ khi binary không có token/AcroForm.
- [x] Hoàn thiện ZIP hồ sơ gồm tài liệu Official, metadata và traceability.

- [x] Khi đổi thủ tục trong Land Dossier AI, tự động làm mới nguồn pháp lý, quy trình, checklist giấy tờ và mẫu tương ứng.
- [x] Bảo đảm không giữ mẫu Official của thủ tục trước khi chuyển sang thủ tục mới; chỉ hiển thị mẫu phù hợp tỉnh/cơ quan/thủ tục hiện tại.
- [x] Thêm kiểm thử chuyển từ chuyển nhượng sang hợp thửa và các thủ tục khác để xác nhận dữ liệu được đồng bộ.

- [x] Thêm logic AI đề xuất thủ tục tiếp theo từ thủ tục vừa hoàn thành, có điểm phù hợp và lý do.
- [x] Liên kết mỗi đề xuất với mẫu đơn, nghị định/căn cứ, nguồn chính thức và trạng thái xác minh.
- [x] Cho phép tải tài liệu đề xuất; phân biệt rõ Official, đã kiểm tra tệp và Chưa xác minh.
- [x] Tích hợp khu vực “Bước tiếp theo AI đề xuất” trong Land Dossier Builder.
- [x] Bổ sung test cho kịch bản chuyển nhượng → thừa kế và chặn tài liệu không có nguồn hợp lệ.

- [x] Sửa lỗi `keywords` rỗng khi bấm AI tìm bản gốc trong Binary mẫu gốc.
- [x] Tự động sinh từ khóa theo thủ tục/mẫu hiện tại nếu người dùng không nhập từ khóa.
- [x] Bổ sung test payload không nhập từ khóa và kiểm tra thông báo lỗi thân thiện.

- [x] Tự động quét trang nghị định/văn bản Chính phủ và các tệp đính kèm liên quan đến thủ tục hiện tại.
- [x] Nhận diện tên mẫu, mã mẫu, phiên bản và thủ tục áp dụng từ nội dung văn bản/đính kèm.
- [x] Tự tải binary DOCX/PDF phù hợp vào hàng chờ xác minh, kèm nguồn URL và checksum.
- [x] Hiển thị danh sách mẫu AI đã sàng lọc trong Builder/Kho pháp lý, không bắt người dùng nhập từ khóa thủ công.
- [x] Bổ sung test chống chọn nhầm mẫu giữa các thủ tục và địa phương.

- [x] Xây checklist xác minh mẫu gốc: nguồn nhà nước, đúng thủ tục, đúng tỉnh/cơ quan, phiên bản và ngày hiệu lực.
- [x] Kiểm tra lại tệp từ URL, MIME, dung lượng, SHA-256 và nội dung DOCX/PDF.
- [x] Kiểm tra khả năng điền DOCX token hoặc PDF AcroForm, cảnh báo nếu chỉ là mẫu tĩnh.
- [x] Tích hợp trạng thái xác minh và phê duyệt quản trị trước khi tạo bản Official.
- [x] Bổ sung test chặn Official khi thiếu nguồn, checksum, phạm vi hoặc khả năng điền.

- [x] Lập registry nguồn Cổng Dịch vụ công công khai theo từng tỉnh/thành và thủ tục đất đai.
- [x] Tự quét trang thủ tục DVC để phát hiện liên kết DOCX/PDF và metadata mẫu theo tỉnh.
- [x] Chuẩn hóa mã mẫu, cơ quan tiếp nhận, phiên bản và ngày hiệu lực từ nguồn DVC.
- [x] Đưa mẫu DVC tìm được vào hàng chờ xác minh, không tự gắn Official khi chưa qua checklist.
- [x] Bổ sung test chống trộn mẫu giữa tỉnh/thành và giữa các thủ tục.

- [x] Tự tra cơ quan tiếp nhận theo tỉnh/thành, quận/huyện, xã/phường và thủ tục từ nguồn Cổng Dịch vụ công.
- [x] Ghép Văn phòng đăng ký đất đai/Chi nhánh hoặc Bộ phận Một cửa đúng địa bàn vào hồ sơ.
- [x] Tự điền cơ quan tiếp nhận trong Builder, lưu URL nguồn và thời điểm kiểm tra.
- [x] Cho phép người dùng xem và xác nhận cơ quan khi có nhiều cơ quan hoặc nguồn mâu thuẫn.
- [x] Bổ sung test địa bàn Đà Nẵng và các trường hợp cơ quan xử lý khác nơi nộp hồ sơ.
- [x] Chạy quét trực tiếp các nguồn Cổng Dịch vụ công đã đăng ký theo tỉnh/thành và địa bàn hồ sơ.
- [x] Trích xuất Văn phòng đăng ký đất đai, Chi nhánh, Bộ phận Một cửa, nơi tiếp nhận và cơ quan thực hiện.
- [x] Đối chiếu kết quả theo từng thủ tục và lưu URL/thời điểm kiểm tra.
- [x] Hiển thị kết quả quét trực tiếp trong Builder, kèm cảnh báo khi thiếu hoặc mâu thuẫn dữ liệu.

- [x] Tách độc lập trạng thái URL thủ tục Official, văn bản pháp lý Official và file mẫu DOCX/PDF Official; không khóa luồng khi thiếu binary.
- [x] Cập nhật Builder hiển thị ba trạng thái riêng và nút AI tìm file mẫu Official mà không đổi giao diện tổng thể.
- [x] Kiểm thử trực tiếp mã thủ tục 2.000889 qua Search → Official URL → Verification → Database → AI lập hồ sơ, kèm screenshot kết quả.

- [x] Sửa lỗi mã thủ tục 2.000889 hiển thị thiếu URL thủ tục Official và URL văn bản pháp lý Official dù registry đã có nguồn.
- [x] Kiểm tra mapping registry → endpoint `officialStatus` → Builder và hiển thị link thật cho từng trạng thái.
- [x] Bổ sung regression test chống tái diễn lỗi URL rỗng và chụp lại preview mobile.

- [x] Tìm và đối chiếu URL văn bản pháp lý chính thức cho thủ tục 2.000889 từ nguồn nhà nước.
- [x] Tìm DOCX/PDF mẫu chính thức từ nguồn nhà nước cho thủ tục 2.000889; nếu không có, lưu trạng thái chưa tìm thấy và không tự tạo Official.
- [x] Tích hợp kết quả tìm nguồn vào registry/endpoint/UI hiện tại, có bằng chứng URL và trạng thái xác minh riêng.
- [x] Kiểm thử nút AI tìm file mẫu Official, checksum/fillability và chụp màn hình kết quả.

- [x] Mở rộng DVC Scanner để đọc phần Hướng dẫn hồ sơ của từng thủ tục đất đai.
- [x] Trích xuất danh sách thành phần hồ sơ và mọi URL file đính kèm thực tế từ trang DVC.
- [x] Đưa file phát hiện được vào hàng chờ Pending với nguồn, checksum và cảnh báo; không tự gắn Official.
- [x] Kiểm thử luồng sâu với mã thủ tục 2.000889 và cập nhật Builder hiển thị kết quả.

- [x] Mở rộng scanner DVC đọc sâu phần Hướng dẫn làm hồ sơ, trích xuất thành phần hồ sơ và file đính kèm vào hàng chờ Pending, nối endpoint và kiểm thử end-to-end cho thủ tục 2.000889.

- [x] Kiểm toán và hoàn thiện luồng xuất hồ sơ Official: xác minh trạng thái file, hàng chờ Pending, phê duyệt quản trị viên, checksum/fillability, traceability và test không cho xuất khi thiếu căn cứ.

- [x] Sửa lỗi checklist hồ sơ chưa được AI phân tích/ghép với mẫu đơn tương ứng; hiển thị trạng thái mẫu theo từng thành phần và chỉ gắn Official sau xác minh.

- [x] Tạo module/menu độc lập cho quy trình Hồ sơ pháp lý AI theo tệp người dùng gửi, tách khỏi các module hiện có; hoàn thiện backend, giao diện, upload/preview/validation, test và phát hành.

- [x] Nối module AI Hồ sơ đất đai tự động với scanner DVC/API thủ tục thật, phân tích nguồn, kho mẫu, upload/OCR, mapping, verification queue và xuất hồ sơ; kiểm thử end-to-end thay cho khung UI hiện tại.

- [x] Xây AI sinh quy trình động theo từng mã thủ tục: đọc DVC, nguồn Chính phủ/Bộ/văn bản luật, phân tích hướng dẫn hồ sơ, phát hiện mẫu và dựng bộ hồ sơ riêng; kiểm thử thủ tục 1.012789.

- [x] Thay workflow 8 bước cố định bằng pipeline động theo từng mã thủ tục; mã 1.012789 phải sinh tên bước, thứ tự, thành phần hồ sơ, biểu mẫu và điều kiện kiểm tra từ dữ liệu DVC đã quét.

- [x] Triển khai module Hồ sơ đất đai AI hoàn chỉnh theo đặc tả tệp: crawler/analyzer/form discovery/parser/mapping/dossier builder/validation, schema dữ liệu, upload/OCR, quản trị, đồng bộ định kỳ và kiểm thử end-to-end.

- [x] Hoàn thiện module Hồ sơ đất đai AI: persistence workflow/version, template mapping review, dossier audit, dashboard đồng bộ và kiểm thử đa thủ tục.
- [x] Thêm UI lịch sử phiên bản, hàng chờ duyệt Official và nhật ký audit cho quản trị viên.
- [x] Xác minh end-to-end các thủ tục ngoài 1.012789 và cập nhật trạng thái từng nguồn độc lập.
- [x] Cập nhật test contract cho API persistence và dashboard crawler.

# Đợt hoàn thiện theo đặc tả AI Hồ sơ đất đai
- [x] Đối chiếu toàn bộ đặc tả người dùng với route, schema, router và UI hiện tại; lập ma trận thiếu/đã có.
- [x] Hoàn thiện màn hình “Tôi muốn làm thủ tục” với tìm kiếm và danh mục thủ tục động từ nguồn đã thu thập.
- [x] Mở rộng pipeline động cho nhiều thủ tục, không hard-code 1.012789; giữ fallback và trạng thái nguồn minh bạch.
- [x] Hoàn thiện luồng phát hiện/tải/phân tích nhiều file DOCX/PDF/XLS/XLSX/scan và mapping với thành phần hồ sơ.
- [x] Hoàn thiện hồ sơ người dùng nhập một lần, OCR xác nhận, tự điền có kiểm soát và cảnh báo không bịa dữ liệu.
- [x] Mở rộng validation, lịch sử phiên bản, quản trị Official, audit pháp lý và xuất DOCX/PDF có traceability.
- [x] Bổ sung bộ test tổng quát cho nhiều mã thủ tục và kiểm tra trực quan các route liên quan.

# Điều chỉnh phạm vi tích hợp
- [x] Tích hợp toàn bộ đặc tả người dùng trực tiếp vào module Hồ sơ đất đai AI hiện có; không tạo module/menu riêng và không làm mất pipeline hiện tại.

# Đợt tích hợp toàn bộ đặc tả vào module hiện tại
- [x] Đối chiếu toàn bộ tệp đặc tả với module Hồ sơ đất đai AI hiện tại và lập ma trận chức năng đã có/còn thiếu.
- [x] Đưa cửa vào “Tôi muốn làm thủ tục” vào đúng module Hồ sơ đất đai AI hiện tại, không tạo menu/module riêng.
- [x] Hoàn thiện tìm thủ tục, quét nguồn chính thức, phát hiện nhiều file và sinh workflow riêng theo từng thủ tục.
- [x] Hoàn thiện nhập dữ liệu một lần, OCR có xác nhận, mapping trường, validation và xuất DOCX/PDF có truy vết.
- [x] Kiểm thử 1.012789 và thêm thủ tục khác không cần viết code riêng; kiểm tra UI, đồng bộ và phát hành.

# Đặc tả 21 mục — tiêu chí tích hợp trực tiếp
- [x] Đối chiếu và triển khai đầy đủ quy trình tìm thủ tục chính thức, đọc trang, phát hiện toàn bộ file, phân tích PDF/DOC/DOCX/XLS/XLSX/scan, mapping, workflow động, hồ sơ dùng một lần, tự điền có xác nhận, validation, xuất DOCX/PDF, Official verification, đồng bộ định kỳ và test đa thủ tục ngay trong Hồ sơ đất đai AI hiện có.

# Sửa lỗi cửa vào hồ sơ đất đai AI
- [x] Kiểm tra vì sao người dùng không thấy nhãn/cửa vào “Tôi muốn làm hồ sơ” trong module hiện tại.
- [x] Đổi nhãn và bố trí CTA rõ ràng trong Hồ sơ đất đai AI, vẫn giữ luồng “Tôi muốn làm thủ tục”.
- [x] Chụp preview desktop/mobile, chạy test và phát hành bản sửa.

# Module mới AI hồ sơ đất đai tự động
- [x] Tạo module mới độc lập theo đặc tả 21 mục trong tệp người dùng; không sửa hỏng module Hồ sơ đất đai AI hiện tại.
- [x] Tạo route/menu riêng, cửa vào “Tôi muốn làm thủ tục”, danh mục động và workflow theo thủ tục.
- [x] Nối crawler, parser, file discovery, OCR, mapping, profile dùng một lần, validation, export và cổng Official.
- [x] Bổ sung persistence/audit/sync cần thiết và test module mới với 1.012789 cùng một thủ tục khác.
- [x] Kiểm tra desktop/mobile, lưu checkpoint và bàn giao module mới.

# Điều chỉnh module mới độc lập hoàn toàn
- [x] Phân rã lại tệp đặc tả thành contract riêng cho module mới, không dùng tên/state/flow của pipeline cũ.
- [x] Xây giao diện và state riêng cho module mới, chỉ tái sử dụng backend service ở mức API cần thiết.
- [x] Xây logic riêng để đọc nguồn, phân tích thủ tục, sinh workflow, hồ sơ, OCR, validation và export theo tệp.
- [x] Bổ sung test riêng chứng minh module mới không phụ thuộc UI/state của module cũ.

# Contract đặc tả 21 mục — module AI tự động độc lập
- [x] Chuyển toàn bộ 21 mục trong pasted_content.txt thành contract kiểm thử và checklist chức năng; xác nhận không hard-code 1.012789, không bắt người dùng nhập URL/tự tìm file, workflow sinh theo từng thủ tục và có test thủ tục thứ hai.

- [x] Điều tra vì sao binary trong phần Thành phần hồ sơ DVC chưa được tải và lưu tự động.
- [x] Tải binary trực tiếp từ URL/metadata trong Hướng dẫn làm hồ sơ và Thành phần hồ sơ, lưu S3, tính SHA-256 và kiểm tra định dạng/fillability.
- [x] Ghép từng file phát hiện với đúng dossier component và hiển thị trạng thái trong module AI hồ sơ tự động.
- [x] Chỉ gắn Official Template File sau khi binary từ nguồn chính thức vượt toàn bộ cổng xác minh; giữ phân biệt URL thủ tục, văn bản pháp lý và file mẫu.
- [x] Mở rộng catalog với các mã thủ tục đất đai đã đối chiếu từ DVC Quốc gia và MONRE; không tự bịa mã khi nguồn phân trang chưa đọc được.
- [x] Kiểm thử nhiều mã thủ tục đất đai mới theo luồng discovery → binary → mapping → Official gate → build plan.
- [x] Chụp preview và lưu checkpoint sau khi hoàn thành thay đổi.

# Ghép file DVC theo từng thủ tục
- [x] Gom quy trình, hướng dẫn, thành phần hồ sơ và toàn bộ URL file theo mã thủ tục.
- [x] Ghép mỗi file Binary vào đúng dossier component bằng mã/tên/khóa liên kết và lưu provenance.
- [x] Tạo bộ hồ sơ theo từng thủ tục, giữ các mục thiếu file ở trạng thái cần bổ sung thay vì bỏ qua.
- [x] Xuất bộ hồ sơ theo thủ tục với danh sách file nguồn, trạng thái Official/Pending và liên kết truy xuất.
- [x] Kiểm thử luồng ghép và xuất với nhiều mã thủ tục DVC.

# Resolver mẫu DVC hiển thị trong Thành phần hồ sơ
- [x] Truy nguyên URL/API tải thật đứng sau tên file Mus01.docx, Mus26.docx và các mẫu tương tự trên trang DVC.
- [x] Bổ sung resolver cho link động, data attribute, JSON/API và nút tải mẫu của DVC.
- [x] Đã xác minh luồng tải byte DOCX/PDF thật, lưu S3, checksum/fillability và gắn component; endpoint DVC hiện trả HTTP 503 nên hệ thống giữ Pending/Reference, không gắn Official giả.
- [x] Kiểm thử thủ tục có Mus*.docx: đã nhận diện 11 thành phần và ghép 3 attachment vào component; trạng thái vẫn failed/Pending vì DVC trả 503.

# Resolver mẫu DVC hiển thị trong Thành phần hồ sơ — cập nhật
- [x] Giải mã HTML entity tiếng Việt và đọc đúng bảng Thành phần hồ sơ từ trang chi tiết DVC.
- [x] Resolve tên mẫu dạng downloadMaudon(code) thành URL tải chính thức của DVC.
- [x] Ghép Mus14*.docx vào đúng component trong thủ tục 1.012789.
- [x] Bổ sung retry/backoff và Referer khi máy chủ csdl.dichvucong.gov.vn trả HTTP 503; không gắn Official khi chưa tải được.

# Xác minh tệp người dùng gửi — Mẫu49
- [x] Kiểm tra định dạng .doc, kích thước, SHA-256 và nội dung tệp Mẫu49-Pl2-151-2025-ND-CP.doc.
- [x] Đối chiếu Mẫu49 với Nghị định 151/2025/NĐ-CP và nguồn DVC địa phương công khai mẫu tương ứng.
- [x] Khi xác định được component, lưu metadata/provenance và ghép tệp vào bundle; không gắn Official nếu thiếu URL nguồn DVC hoặc xác minh bổ sung.

# Pipeline DVC theo mã thủ tục — ví dụ 1.012789
- [x] Dùng mã thủ tục làm khóa chính để đọc trang chi tiết DVC và snapshot nguồn.
- [x] Sinh tự động quy trình, thành phần hồ sơ, điều kiện, thời hạn, phí và cơ quan từ trang DVC.
- [x] Resolve toàn bộ file mẫu của từng thành phần, tải/verify khi endpoint DVC cho phép và ghép vào procedure bundle.
- [x] Cho phép chạy cùng pipeline tự động cho từng mã trong catalog thủ tục đất đai, không hard-code thành phần.
- [x] Kiểm thử 1.012789 và tối thiểu các mã thủ tục đất đai kế tiếp.

# Pipeline DVC theo mã thủ tục — trạng thái hoàn tất
- [x] Dùng mã thủ tục làm khóa chính để đọc trang chi tiết DVC và snapshot nguồn.
- [x] Sinh workflow động từ phần Trình tự thực hiện, cùng thành phần hồ sơ và file theo snapshot DVC.
- [x] Resolve file mẫu theo downloadMaudon khi DVC công bố URL_DOWNLOAD; giữ Pending/Failed khi endpoint trả 503.
- [x] Thêm endpoint batchDiscover chạy cùng pipeline theo các mã đã đăng ký trong catalog, tối đa 25 mã mỗi lượt.
- [x] Kiểm tra TypeScript và 46 file test với 237/237 Vitest đạt.
- [x] Đã xác nhận giới hạn an toàn: chỉ quét mở rộng khi DVC phân trang trả đủ mã và URL chính thức; hiện catalog giữ phạm vi đã có để tránh bịa thủ tục/URL.

# Đồng bộ tải file theo luồng trình duyệt DVC
- [x] Đối chiếu URL/redirect và mã file của mẫu người dùng tải thành công với resolver server.
- [x] Bổ sung Referer, User-Agent, accept headers, retry/backoff và URL resolver theo luồng tải đã phát hiện; cookie phiên người dùng vẫn là fallback tùy chọn.
- [x] Đã kiểm tra contract xác nhận response DOCX/PDF, lưu S3, checksum/fillability và cập nhật trạng thái; chưa chuyển Pending do nguồn DVC chưa trả response binary hợp lệ.
- [x] Kiểm thử lại 1.012789 với file người dùng xác nhận tải được; checksum đã đối chiếu `308c0de...b5a00d`.

# Kiểm tra mẫu người dùng tải từ DVC — mau-so-14.doc
- [x] Kiểm tra metadata, kích thước, SHA-256 và nội dung tệp mau-so-14.doc.
- [x] Đối chiếu mẫu với thủ tục 1.012789 và thành phần hồ sơ tương ứng.
- [x] Ghi nhận provenance tệp người dùng cung cấp; chỉ gắn Official khi có URL DVC và byte xác minh phù hợp.
- [x] Xác định component tương ứng trong procedure bundle 1.012789: “Phiếu yêu cầu cung cấp thông tin, dữ liệu đất đai”; tệp người dùng được lưu tham chiếu, chưa thay thế binary nguồn DVC.

# Tìm đường tải file DVC thay thế
- [x] Kiểm tra các endpoint/redirect/API tải file hợp lệ mà trang DVC sử dụng.
- [x] Xác định trường hợp DVC trả 503 và yêu cầu retry/Referer; nếu cần cookie phiên thì không tự vượt qua khi chưa có phiên người dùng.
- [x] Thêm fallback retry/backoff và endpoint rà URL ứng viên web; cơ chế phiên người dùng vẫn là tùy chọn khi DVC yêu cầu cookie.
- [x] Đã hoàn thiện nhánh lưu byte vào storage, checksum/fillability và cập nhật component khi đạt; các mẫu chưa có byte hợp lệ vẫn được giữ Pending theo chính sách.
- [x] Kiểm thử thực tế với `mau-so-14.doc` và ứng viên Mẫu 14 tải qua web; helper test và toàn bộ Vitest đạt 240/240.

# Fallback khi AI chưa tải được file DVC
- [x] Đã xác nhận My Browser hiện không khả dụng trên thiết bị mobile; hệ thống tiếp tục dùng Heartbeat và endpoint upload thủ công, không yêu cầu kết nối ngoài ý muốn.
- [x] Nếu không có phiên trình duyệt, cung cấp endpoint nhận file người dùng tải, lưu S3, tính SHA-256, kiểm tra chữ ký và ghép component; trạng thái vẫn `reference_only` cho tới khi có provenance Official.
- [x] Không chuyển Official khi chưa có byte và provenance phù hợp.

# Tìm file mẫu từ Bộ Tài nguyên và Môi trường/MONRE
- [x] Tìm các trang/văn bản chính thức của Bộ/MONRE có công bố file mẫu đất đai.
- [x] Đối chiếu tên file, mã mẫu và thủ tục với 1.012789.
- [x] Kiểm tra URL tải và byte file cho ứng viên web; nguồn ngoài allowlist chỉ được lưu reference_only, không dùng để cấp Official.
- [x] Cập nhật provenance/registry nếu tìm thấy nguồn phù hợp và chạy regression tests.

# Rà soát nghị định đất đai từ MONRE và Cổng Chính phủ
- [x] Tra cứu nguồn chính thức cho Nghị định 101/2024/NĐ-CP.
- [x] Tra cứu nguồn chính thức cho Nghị định 102/2024/NĐ-CP.
- [x] Tra cứu nguồn chính thức cho Nghị định 96/2019/NĐ-CP và xác định phạm vi: nguồn đã xác nhận Nghị định 96/2024/NĐ-CP về kinh doanh bất động sản; chưa gán nhầm thành văn bản đất đai.
- [x] Tra cứu nguồn chính thức cho Nghị định 103/2024/NĐ-CP và xác định phạm vi liên quan đất đai.
- [x] Tra cứu nguồn chính thức cho Nghị định 151/2025/NĐ-CP.
- [x] Kiểm tra URL tải PDF/DOC/DOCX, tải thử từng file công khai, tính SHA-256 và ghi trạng thái.
- [x] Cập nhật kho pháp lý với provenance và binary đã tải; vẫn phân biệt văn bản pháp lý Official với mẫu biểu thủ tục.

# Mở rộng kho pháp lý đất đai — đợt mới
- [x] Lập danh mục thêm các luật, nghị định, thông tư, quyết định và văn bản hướng dẫn liên quan trực tiếp đến đất đai.
- [x] Ưu tiên các nhóm về Luật Đất đai, đăng ký/cấp giấy chứng nhận, thu hồi-bồi thường, giá đất, quy hoạch, hồ sơ địa chính và thủ tục hành chính.
- [x] Tìm URL văn bản và file PDF/DOC chính thức từ Cổng Chính phủ, MONRE/Bộ Nông nghiệp và Môi trường hoặc cơ quan nhà nước có thẩm quyền.
- [x] Tải, kiểm tra MIME/kích thước/SHA-256, lưu storage và ghi provenance cho từng văn bản.
- [x] Cập nhật legal knowledge base/registry và kiểm thử không gắn nhầm văn bản pháp lý với file mẫu thủ tục.

# Rà soát nghị định đất đai bổ sung — kết quả
- [x] Đã xác nhận nguồn chính thức và file PDF của Nghị định 71/2024/NĐ-CP; đã tải, kiểm tra MIME/kích thước/SHA-256 và lưu storage.
- [x] Đã kiểm tra Nghị định 117/2024/NĐ-CP; đã tải và lưu PDF nhưng phân loại là văn bản tham chiếu, không phải nhóm đất đai cốt lõi.
- [x] Đã cập nhật hồ sơ nguồn docs/dvc-land-sources-2026-08-20.md với URL, checksum và storage path.
- [x] Bổ sung các luật/nghị định/thông tư/quyết định đất đai đã xác định được URL chính thức và file tải được; phần chưa có nguồn xác minh tiếp tục giữ Pending.

- [x] Rà soát file mẫu thay thế trên Bộ Tài nguyên và Môi trường, Cổng Thông tin điện tử Chính phủ và phụ lục nghị định khi nguồn DVC trả HTTP 503 bằng pipeline fallback có allowlist miền.
- [x] Đối chiếu ứng viên file thay thế với tên/mã mẫu và thành phần hồ sơ; bộ lọc không coi PDF nghị định không khớp mẫu là file Official Template.
- [x] Đã hoàn thiện nhánh tải file thay thế, SHA-256, kiểm tra định dạng/fillability và đồng bộ Procedure Bundle; chưa có ứng viên thay thế đủ provenance/mẫu khớp để nâng trạng thái.
- [x] Chạy lại kiểm thử batch và báo cáo: 9 mã đã quét, 2 mã có `verified_binary` từ DVC, 7 mã chưa có binary xác minh, fallback chưa có ứng viên khớp; test lõi đạt 239/239.

- [x] Mở rộng validation và giới hạn batchDiscover lên tối đa 66 mã theo danh mục đất đai công bố.
- [x] Kiểm tra TypeScript sau khi mở rộng batch; dev server đã chạy lại và không còn lỗi TypeScript mới.

- [x] Chạy tự động discovery và tải file mẫu từ các nguồn DVC, Chính phủ, Bộ Nông nghiệp và Môi trường/MONRE và cơ quan nhà nước được allowlist cho toàn bộ catalog hiện có (9 mã; batch hỗ trợ tối đa 66).
- [x] Ghi nhận kết quả từng nguồn: batch report ghi rõ 2 mã có `verified_binary`, 7 mã chưa có binary xác minh và fallback hiện chưa tìm được ứng viên file mẫu khớp.
- [x] Xác minh và đồng bộ các binary tải thành công vào đúng Procedure Bundle; batchDiscover/buildPlan assemble các binary `verified_binary`, còn cổng Official riêng vẫn không tự cấp.

- [x] Mở rộng discovery với từ khóa biến thể `Mus14`, `Mẫu 14`, `Mẫu số 14`, phụ lục hướng dẫn và mã thủ tục trên các nguồn web công khai; đã tìm được ứng viên Mẫu 14 DOC.
- [x] Kiểm tra đường dẫn ứng viên qua web/Google; tải được DOC, ghi nhận HTTP tải thành công, MIME/định dạng, kích thước 41,472 bytes và SHA-256 `308c0de...b5a00d`.
- [x] Phân loại ứng viên ngoài miền cơ quan nhà nước là `reference_only`, không gắn Official; helper và test mới khóa `officialEligible=false`.
- [x] Bổ sung kết quả multi-source vào provenance report và Procedure Bundle của thủ tục tương ứng; ứng viên đúng mẫu dùng `ready_reference`, không tự cấp Official.

- [x] Cho phép file được nhận diện đúng mẫu (Mus14/Mẫu số 14 và các mẫu tương tự) được ghép vào Procedure Bundle với trạng thái `matched_reference` hoặc `assembled`, không phụ thuộc Official.
- [x] Tách rõ các trạng thái `assembled/matched_reference`, `verified_binary` và `official_template` trong mapping, export và giao diện.
- [x] Kiểm thử ghép mẫu đúng với 1.012789 và bảo đảm mẫu sai hoặc không khớp component vẫn bị loại khỏi bundle; regression bundle matched_reference đạt.

- [x] Thêm trạng thái `matched_reference` cho file đúng mẫu và `ready_reference` cho thành phần đã ghép nhưng chưa Official.
- [x] Cập nhật UI Procedure Bundle để phân biệt “Đã ghép file Official” với “Đã ghép đúng mẫu · chưa Official”.
- [x] Regression tests cho bundle matched_reference: 9/9 test scanner/fallback đạt; TypeScript sạch.

- [x] Kiểm thử riêng luồng Mẫu 14/Mus14: dvcSourceRegistry 6/6, officialTemplateFetcher 3/3, UI module 3/3; tổng 12/12 test mục tiêu đạt và TypeScript sạch.

- [x] Tích hợp endpoint inspect/upload reference với `mergeDvcReferenceBinaries`; file tải được và khớp mẫu được trả trong Procedure Bundle dưới `ready_reference`.
- [x] Regression test trực tiếp cho merge Mẫu 14 đạt; nhóm scanner/fallback hiện 10/10 và TypeScript sạch.

- [x] Tìm công khai các biến thể `MFS14`, `Mus14`, `Mẫu FS14`, `Mẫu số 14`, `Mẫu 14` và tên file tương đương; đã xác định hai ứng viên tải được.
- [x] Tải ứng viên MFS14/Mẫu 14, kiểm tra MIME, kích thước, nội dung và SHA-256; DOC 41,472 bytes khớp nội dung Mẫu số 14, DOCX 33,279 bytes đang cần đối chiếu riêng.
- [x] Ghép ứng viên khớp thủ tục 1.012789 vào Procedure Bundle dưới `matched_reference/ready_reference` qua merge reference; ứng viên ngoài miền nhà nước không cấp Official.

- [x] Không khóa buildPlan khi DVC trả 503 nếu đã xác định được mẫu/phụ lục từ nguồn công khai khác; buildPlan tiếp tục trả snapshot và trạng thái ready_reference.
- [x] Đã hoàn thiện helper tạo truy vấn theo tên/mã mẫu và thành phần, endpoint nhận ứng viên URL và matcher; runtime không tự gọi Google khi chưa có connector, nên không tự thu thập ngoài nguồn.
- [x] Đối chiếu ứng viên với quy trình, ghép đúng component và xuất bộ hồ sơ ở trạng thái `ready_reference` khi chưa đủ Official provenance.
- [x] Kiểm thử orchestration end-to-end mô phỏng DVC 503 nhưng mẫu công khai tải được; `matched_reference/ready_reference` được trả đúng, không cấp Official. Batch mạng thật vẫn ghi nhận directVerified=0.
- [x] Tự động tải DOCX/PDF cho từng mã thủ tục đất đai đã có trong catalog, đọc thành phần hồ sơ và ghép đúng Procedure Bundle.
- [x] Chạy đồng bộ theo lô cho toàn bộ danh mục thủ tục đất đai, không yêu cầu người dùng gửi lại từng mã.
- [x] Hiển thị báo cáo riêng cho Official, Reference và Pending sau mỗi đợt đồng bộ.
- [x] Hỗ trợ tiếp tục luồng trên điện thoại bằng cách nhận file người dùng tải lên khi không có phiên Trình duyệt của tôi.

- [x] Thay cơ chế bấm đồng bộ thủ công bằng job tự động chạy nền theo catalog thủ tục đất đai.
- [x] Tự động tải binary DOC/DOCX/PDF từ allowlist nguồn cơ quan nhà nước và lưu provenance, URL cuối, MIME, SHA-256.
- [x] Chỉ nâng nhãn Official khi nguồn thuộc allowlist nhà nước, binary đúng chữ ký định dạng, tải thành công, kiểm tra được và ghép đúng component.
- [x] Ghi rõ Pending/Reference khi DVC bị 503, nguồn ngoài nhà nước hoặc file chưa đủ bằng chứng; không tự nâng nhãn trong các trường hợp này.

- [x] Tạo lịch Heartbeat tự động mỗi 6 giờ cho callback `/api/scheduled/sync-legal-sources` và lưu taskUid `EcZLeMSzGSq9Ktpx7R6hXa` để quản lý/resume/pause.

- [x] Tách rõ Official Procedure URL, Official Legal Document và Official Template/Annex trong kết quả AI.
- [x] Nhận diện phụ lục có biểu mẫu trong nghị định/văn bản và chỉ ghép phụ lục đúng mẫu vào Procedure Bundle.
- [x] Hiển thị riêng căn cứ pháp lý, nguồn thủ tục và file mẫu/phụ lục trong giao diện hồ sơ.
- [x] Bổ sung kiểm thử không coi toàn bộ nghị định là mẫu đơn; chỉ cấp Official Template khi phụ lục/file đúng mẫu được xác minh.

- [x] Cho phép file ngoài nguồn nhà nước được ghép khi khớp chính xác mã/tên/nội dung mẫu, nhưng giữ nhãn `matched_reference/ready_reference`, không gọi là Official.
- [x] Hiển thị lý do khớp, nguồn file và cảnh báo “chưa phải mẫu Official” cho từng file Reference.
- [x] Trả trạng thái `template_not_found` khi thủ tục yêu cầu mẫu nhưng không có ứng viên đủ điểm khớp; không tự đoán hoặc ghép mẫu khác mã.
- [x] Kiểm thử trực tiếp Mus14 và trường hợp mẫu không nhận diện được.

- [x] Khớp file theo tên/mã mẫu với thành phần thủ tục, ví dụ `Mus14` với yêu cầu `Mus14`, trước khi ghép vào bundle.
- [x] Hiển thị nhãn `Đã ghép đúng mẫu — nguồn tham khảo` khi chỉ khớp tên/mã mà chưa có provenance Official.
- [x] Không nâng Official chỉ dựa trên tên file; kiểm thử riêng trường hợp cùng tên nhưng nội dung không khớp.

- [x] Thêm trạng thái `awaiting_manual_review` cho file khớp tên/mã và cho phép ghép ngay vào bộ hồ sơ.
- [x] Hiển thị rõ “Official dự kiến — chưa xác nhận” hoặc “Đã ghép theo mẫu — chờ kiểm tra thủ công”, không gọi là Official đã xác minh.
- [x] Thêm thao tác xác nhận thủ công sau khi người dùng kiểm tra file trước khi nộp.

- [x] Tách rõ hai khu trong Procedure Bundle: `reference_templates` cho file tham khảo thật và `official_templates` cho bản gốc nhà nước.
- [x] Giữ file tham khảo được dùng để làm nháp/đối chiếu nhưng không tính vào số lượng Official Nhà nước.
- [x] Chỉ chuyển file sang khu Official Nhà nước khi có bản gốc nguồn nhà nước được tải và xác minh; không tự chuyển file tham khảo.
- [x] Hiển thị hai khu riêng trong giao diện và kiểm thử không trộn trạng thái.

- [x] Sinh bộ trường Thông tin điền vào theo đúng thủ tục đang chọn; đổi thủ tục phải đổi toàn bộ trường và nhãn tương ứng.
- [x] Giữ giá trị nhập theo từng thủ tục, không dùng trường của thủ tục A cho thủ tục B.
- [x] Thêm chụp ảnh trực tiếp bằng camera trên mobile và tải ảnh từ thiết bị.
- [x] Gắn từng ảnh vào đúng hồ sơ/thành phần thủ tục và hiển thị xem trước, xóa ảnh.
- [x] Kiểm thử chuyển thủ tục, camera/tải ảnh và giao diện mobile.

- [x] Thêm schema Thông tin điền vào động theo mã thủ tục, không dùng một form cố định cho mọi thủ tục.
- [x] Gắn camera/tải ảnh trực tiếp vào từng thành phần hồ sơ và hiển thị đúng mục tiêu upload.
- [x] Bổ sung test cho schema thủ tục 1.012789, 2.000889 và mapping file vào thành phần hồ sơ.
- [x] Xác minh giao diện mobile/desktop của module AI Hồ sơ đất đai sau khi thêm form động và upload.

- [x] Kiểm tra và sửa trạng thái hiển thị bản tham khảo trong Procedure Bundle: không để file reference đã ghép chỉ hiện như Draft chung chung.
- [x] Bổ sung test hồi quy cho nhãn Reference/ready_reference và phân biệt với Official/Pending.

- [x] Rà soát vì sao Procedure Bundle chỉ có thành phần/tên file nhưng chưa có binary Reference thật.
- [x] Đồng bộ ứng viên DOCX/PDF tham khảo theo mã/tên mẫu cho toàn bộ catalog khi có nguồn tải hợp lệ.
- [x] Hiển thị bản tham khảo trong Kho pháp lý AI và Procedure Bundle, không nâng lên Official nếu thiếu provenance/binary xác minh.
- [x] Bổ sung test cho đồng bộ toàn catalog, trạng thái thiếu file và file lỗi như Mus18.docx.

- [x] Sửa lỗi Mus14/Mẫu 14 và các attachment đã có ứng viên nhưng UI vẫn hiển thị “Chưa có file”.
- [x] Bảo đảm file 503 có fallback Reference thật hoặc trạng thái chờ rõ ràng kèm đường dẫn nguồn, không nhầm với thiếu dữ liệu hoàn toàn.
- [x] Bổ sung regression test cho matched_reference/ready_reference và UI tải bản tham khảo.

- [x] Kiểm tra lịch `land-dossier-official-sync-6h` hiện tại và xác định có cần bật lại hay chỉ chạy lại.
- [x] Bảo đảm Heartbeat tự động retry các URL binary DVC lỗi 503 khi nguồn khôi phục, vẫn giữ Reference/Official gate.
- [x] Kiểm tra log/lịch sử chạy và ghi lại taskUid, trạng thái enable, lần chạy kế tiếp.

- [x] Thiết kế lớp nguồn ưu tiên: DVC/MONRE/Chính phủ trước, nguồn công khai bên ngoài chỉ là Reference.
- [x] Mở rộng catalog nghị định đất đai liên quan, gồm 96, 101, 102, 103, 151 và các văn bản được xác định thêm theo thủ tục.
- [x] Tự động tìm, tải, checksum và lưu S3 mẫu tham khảo khi khớp chính xác mã/tên mẫu; ghép cạnh file Official nếu có.
- [x] Đồng bộ các reference legal documents vào Kho pháp lý AI và Procedure Bundle theo từng thủ tục.
- [x] Bổ sung test đa nguồn, chống gắn nhầm Official, và xác minh export bundle có file thật hoặc cảnh báo rõ ràng.

- [x] Đối chiếu luồng `failed`/Pending xác minh với luồng `điểm 0` để không hiển thị trùng hoặc gây hiểu nhầm cho cùng URL DVC.
- [x] Khi URL DVC trả lỗi, hiển thị rõ trạng thái chờ retry và tìm ứng viên Reference theo mã/tên mẫu nếu có.
- [x] Gắn ứng viên Reference khớp vào component tương ứng trước khi cho phép xuất bản nháp hồ sơ.

- [x] Tách trạng thái “Official nháp/Reference dùng được” khỏi Official Nhà nước trong contract và UI.
- [x] Tạo đúng mẫu nháp theo mã thủ tục/thành phần, cho phép điền và xuất bản nháp có cảnh báo rõ.
- [x] Tách kho lưu trữ, nút export và nhãn cho Draft Reference với Official, không cho nháp nâng Official tự động.
- [x] Bổ sung regression test bảo đảm hai luồng dùng được song song và không gắn nhầm provenance.

- [x] Thêm nút quản trị “Đồng bộ ngay” để kích hoạt legal sync thủ công qua tRPC.
- [x] Hiển thị tiến trình đồng bộ file-by-file qua các bước Discovery -> Download -> Checksum -> Storage -> Mapping.
- [x] Đồng bộ trạng thái realtime/polling của lần chạy thủ công trong giao diện AI Hồ sơ đất đai.
- [x] Bổ sung kiểm thử mutation, trạng thái tiến trình và kiểm tra responsive cho màn hình đồng bộ.

- [x] Sửa luồng mobile sau phần chọn luật/nghị định để hiển thị rõ thủ tục đã chọn và nút xác minh tiếp.
- [x] Thêm bước phân tích tiếp theo sau xác minh nguồn pháp lý, không để màn hình dừng ở thẻ nguồn.
- [x] Bổ sung regression test và kiểm tra responsive cho luồng chọn thủ tục → xác minh → phân tích.

- [x] Làm rõ lý do nút AI phân tích bị khóa khi chưa tải giấy tờ hoặc chưa xác nhận OCR.
- [x] Hiển thị hướng dẫn theo trạng thái: chưa có file, đang OCR, cần kiểm tra, đã xác nhận.
- [x] Bổ sung test cho luồng OCR → xác nhận → AI phân tích và kiểm tra mobile.

- [x] Chạy lại tìm kiếm nguồn chính thức cho thủ tục 1.012784 và các tên mẫu liên quan tách/hợp thửa.
- [x] Hiển thị kết quả từng nguồn, trạng thái tải file và lý do Pending nếu không có binary xác minh.
- [x] Bổ sung test cho thao tác thử lại và phân loại Official/Reference của file tìm được.

- [x] Xác minh file từ nguồn Bộ có đúng mã thủ tục 1.012784 và đúng thành phần hồ sơ.
- [x] Đối chiếu căn cứ pháp lý, tên mẫu, cơ quan ban hành và metadata file.
- [x] Cập nhật kết luận Official/Reference/Pending kèm lý do và checksum nếu đủ điều kiện.

- [x] Hiển thị SHA-256 và URL nguồn gốc cho từng file Official/Reference trong giao diện hồ sơ pháp lý AI.
- [x] Thêm thao tác sao chép checksum và mở URL nguồn an toàn trên desktop/mobile.
- [x] Bổ sung test metadata file, thao tác sao chép/mở nguồn và responsive layout.

- [x] Lập danh sách toàn bộ module hồ sơ đất đai và catalog thủ tục/file cần đồng bộ Official.
- [x] Mở rộng pipeline tải, đối chiếu mã mẫu, checksum và lưu `legal-official` cho từng file đủ điều kiện.
- [x] Liên kết file Official đã xác minh vào Hồ sơ AI đất đai, Hồ sơ đất đai AI, AI lập hồ sơ cho cơ quan, AI hồ sơ đất đai tự động và module tạo hồ sơ mới.
- [x] Hiển thị tiến trình và kết quả Official/Reference/Pending trong Kho pháp lý AI.
- [x] Bổ sung regression test cho đồng bộ đa module và phát hành sau khi toàn bộ kiểm tra đạt.

- [x] Lọc toàn bộ thủ tục, biểu mẫu và file trong Kho pháp lý AI thay vì chỉ mã 1.012784.
- [x] Đối chiếu từng file với mã thủ tục, thành phần hồ sơ, nguồn nhà nước và checksum.
- [x] Đồng bộ kết quả lọc vào tất cả module hồ sơ đất đai, giữ riêng Official/Reference/Pending.

- [x] Chạy batch lọc toàn bộ file theo mã thủ tục/thành phần trong Kho pháp lý AI và các module hồ sơ.
- [x] Tải và xác minh file từ nguồn nhà nước bằng nội dung, provenance và SHA-256; chỉ gắn Official khi đủ điều kiện.
- [x] Đồng bộ kết quả batch vào Hồ sơ AI đất đai, Hồ sơ đất đai, AI lập hồ sơ cho cơ quan, AI hồ sơ tự động và module tạo hồ sơ mới.
- [x] Hiển thị tiến trình từng file và danh sách Official/Reference/Pending sau batch.

- [x] Lập danh mục đầy đủ file và thành phần hồ sơ cần lọc cho tất cả thủ tục trong Kho pháp lý AI.
- [x] Chạy batch tải file từ nguồn chính thức, đối chiếu nội dung và checksum cho từng thành phần.
- [x] Đồng bộ kết quả vào các luồng Hồ sơ AI đất đai, Hồ sơ đất đai, AI lập hồ sơ cho cơ quan, AI hồ sơ tự động và module tạo hồ sơ mới.
- [x] Hiển thị tiến trình batch cùng phân loại Official/Reference/Pending và danh sách file còn thiếu.

- [x] Tải các file DOCX/PDF đã phát hiện từ nguồn chính thức và lưu metadata nguồn gốc.
- [x] Kiểm tra mã thủ tục, thành phần hồ sơ, MIME và SHA-256 trước khi gắn Official.
- [x] Lưu file đủ điều kiện vào lớp `legal-official` và liên kết vào các module lập hồ sơ.
- [x] Giữ file chưa đủ chứng cứ ở Reference/Pending, đồng thời hiển thị lý do.

- [x] Bổ sung thủ tục tách thửa đất vào phạm vi batch lọc toàn bộ.
- [x] Xác minh mẫu biểu, nghị định áp dụng, điều kiện diện tích và thời hạn theo từng địa phương trong metadata/pipeline; batch binary thực tế phụ thuộc nguồn địa phương có thể truy cập.
- [x] Chỉ gắn Official cho file mẫu có nguồn cơ quan nhà nước, đúng thủ tục và có checksum; nguồn thương mại giữ Reference.

- [x] Bổ sung thủ tục hợp thửa đất vào phạm vi batch lọc toàn bộ.
- [x] Xác minh mẫu biểu, nghị định áp dụng, điều kiện cùng chủ sử dụng/quy hoạch và thời hạn theo từng địa phương trong metadata/pipeline; không suy đoán khi thiếu nguồn.
- [x] Chỉ gắn Official cho file mẫu có nguồn cơ quan nhà nước, đúng thủ tục và có checksum; nguồn thương mại giữ Reference.

- [x] Lập danh sách các URL website nhà nước đã cung cấp và phạm vi mẫu đơn hành chính cần quét.
- [x] Quét các URL, nhận diện và tải toàn bộ DOCX/PDF mẫu đơn có thể truy cập.
- [x] Kiểm tra MIME, nội dung, mã thủ tục và SHA-256 cho từng file tải được.
- [x] Lưu metadata nguồn và phân loại Official/Reference/Pending trong Kho pháp lý AI.
- [x] Bổ sung test batch và bàn giao danh sách file đã tải cùng các URL lỗi/chưa truy cập được.

- [x] Bổ sung vào catalog các thủ tục DVC: cung cấp thông tin dữ liệu đất đai; đăng ký đất đai/cấp Giấy chứng nhận lần đầu; cấp đổi Giấy chứng nhận; đăng ký biện pháp bảo đảm bằng quyền sử dụng đất.
- [x] Quét thành phần hồ sơ, mã thủ tục và liên kết DOCX/PDF của từng nhóm trên Cổng Dịch vụ công Quốc gia.
- [x] Đối chiếu tầng nguồn Chính phủ/Bộ/Sở trong pipeline, kiểm checksum và phân loại Official/Reference/Pending theo từng file.

- [x] Đăng ký các cổng DVC địa phương: dichvucong.hanoi.gov.vn, dichvucong.hochiminhcity.gov.vn và hcc.danang.gov.vn vào hàng đợi discovery.
- [x] Kiểm tra miền chính thức, trang thủ tục đất đai và khả năng truy cập tệp DOCX/PDF của từng cổng địa phương.
- [x] Tích hợp fallback địa phương vào fetcher nhưng chỉ gắn Official sau khi xác minh provenance, nội dung thủ tục và SHA-256.
- [x] Hiển thị riêng nguồn DVC địa phương, Reference/Pending và lý do nếu cổng hoặc tệp trả lỗi/chưa xác minh.

- [x] Mở rộng catalog nguồn gồm DVC Quốc gia, Bộ Tài nguyên và Môi trường/Bộ Nông nghiệp và Môi trường, Văn phòng Chính phủ và các cổng công khai Chính phủ liên quan.
- [x] Xây dựng danh mục cổng DVC địa phương cho toàn bộ tỉnh/thành, kèm trạng thái miền đã kiểm tra/chưa kiểm tra; không tự suy đoán URL tệp.
- [x] Thiết lập fallback theo thứ tự DVC Quốc gia → Bộ/Chính phủ → DVC địa phương → nguồn Reference, với lý do và trạng thái từng nguồn.
- [x] Chạy batch quét toàn bộ thủ tục và thành phần hồ sơ trong Kho pháp lý AI, tải DOCX/PDF có thể truy cập và ghi checksum.
- [x] Đồng bộ kết quả vào toàn bộ module hồ sơ đất đai, giữ tách biệt Official/Reference/Pending và hiển thị danh sách file còn thiếu/lỗi.
- [x] Bổ sung kiểm thử toàn quốc cho catalog nguồn, fallback, tiến trình batch và phân loại Official không giả mạo.

- [x] Chuẩn hóa quy tắc quét DVC theo cơ quan thực hiện: Sở Tài nguyên và Môi trường, Văn phòng Đăng ký đất đai và cơ quan tiếp nhận tương ứng.
- [x] Bổ sung discovery tệp DOC/DOCX/PDF trong mục Thành phần hồ sơ của DVC địa phương sau khi miền được kiểm tra thực tế.
- [x] Ghi nhận fallback DVC Quốc gia → DVC địa phương theo tỉnh → nguồn Bộ/Chính phủ, kèm URL, cơ quan, thủ tục và trạng thái truy cập.

- [x] Chuẩn bị batch quét thủ tục và mẫu hồ sơ cho Hà Nội, Thành phố Hồ Chí Minh và Đà Nẵng qua cùng pipeline; thực thi live cần phiên truy cập nguồn tương ứng.
- [x] Ghi kết quả từng thủ tục/tệp theo Discovery, Download, Checksum, Storage và Mapping trong state machine và báo cáo batch.
- [x] Hiển thị thống kê Official/Reference/Pending và giữ điều kiện không nâng Official khi chưa tải, lưu và xác minh SHA-256.

- [x] Phân loại lỗi tải file theo HTTP 503, yêu cầu đăng nhập, URL hết hạn hoặc máy chủ chặn tải.
- [x] Thử và tích hợp fallback từ DVC địa phương Hà Nội/TP.HCM/Đà Nẵng cùng nguồn Bộ/Chính phủ khi DVC Quốc gia không tải được; chỉ Official khi binary và SHA-256 hợp lệ.
- [x] Hiển thị rõ nguyên nhân lỗi và giữ file ở Pending nếu chưa có binary và SHA-256 hợp lệ.

- [x] Thêm mục tải mẫu riêng trong Kho pháp lý AI, không thay đổi các mục hiện có.
- [x] Cho phép chọn thủ tục và thành phần hồ sơ rồi tải DOC/DOCX/PDF/ảnh lên S3.
- [x] Tự nhận diện tên/mã mẫu, gắn file vào đúng component và cập nhật luồng AI lập hồ sơ.
- [x] Phân loại file người dùng tải là User Upload/Reference; chỉ gắn Official Nhà nước khi có provenance và SHA-256 được xác minh.
- [x] Hiển thị trạng thái tải, checksum, thành phần mapping và kết quả xử lý.

- [x] Tiếp tục phương án mục tải mẫu riêng trên nền phiên bản 247f2305, giữ nguyên các mục Kho pháp lý AI hiện có.
- [x] Kiểm tra lại upload theo thủ tục/thành phần, mapping AI và phân loại User Upload/Reference sau rollback.
- [x] Chạy lại kiểm thử, preview và lưu phiên bản mới sau khi hoàn tất phương án.

- [x] Hợp nhất 5 nhóm vào pipeline: batch địa phương, quét catalog, đồng bộ module AI, fallback Pending/503 và upload mẫu riêng.
- [x] Tổng hợp tiến trình và kết quả riêng cho từng nhóm; không gắn Official khi thiếu xác minh binary/SHA-256.

- [x] Bổ sung đường vào đăng nhập rõ ràng cho Kho pháp lý AI khi người dùng chưa xác thực.
- [x] Kiểm tra CTA đăng nhập và route nội bộ trước khi chạy batch quản trị.

- [x] Xác minh tài khoản lyuanchin0203@gmail.com đã có role admin trong cơ sở dữ liệu.
- [x] Kiểm tra lại quyền truy cập Kho pháp lý AI sau khi cập nhật role.
- [x] Chẩn đoán và khắc phục lỗi “Failed to fetch” khi chạy batch Tải và gắn Official toàn bộ file; kiểm tra lại API nội bộ, timeout và lỗi nguồn dự phòng.
- [x] Bổ sung kiểm thử hồi quy cho trạng thái lỗi batch và khả năng chạy lại an toàn sau lỗi kết nối.
- [x] Kiểm thử lại batch trên giao diện mobile, xác nhận bố cục kết quả Official/Reference/Pending và thanh tiến trình không tràn; preview trang chủ 390px hiển thị đúng điều hướng, danh mục và thẻ nguồn hàng.

- [x] Xử lý file DVC trả HTTP 503 bằng retry có kiểm soát và chuyển sang nguồn dự phòng phù hợp.
- [x] Cô lập lỗi từng nhóm thủ tục để một nguồn 503/Failed to fetch không làm hỏng toàn bộ batch; nhóm lỗi được ghi riêng và nhóm sau tiếp tục.
- [x] Bổ sung kiểm thử cho fallback, allowlist nguồn và giữ Pending khi chưa đủ điều kiện Official; regression batch client đạt 265/265 Vitest.
- [x] Kiểm thử lại đồng bộ 11 thủ tục và cập nhật kết quả Official/Reference/Pending; ảnh production mới nhất ghi nhận 158 Official, Reference 0, Pending 0, Lỗi 0.

- [x] Bổ sung registry nguồn Văn phòng đăng ký đất đai và Chi nhánh theo từng tỉnh/thành/khu vực.
- [x] Đối chiếu cơ quan tiếp nhận địa phương với mã thủ tục và địa bàn người dùng chọn.
- [x] Tìm file mẫu trên cổng dịch vụ công địa phương khi nguồn Quốc gia hoặc Bộ trả 503; nếu không có binary hợp lệ thì giữ Pending.
- [x] Hiển thị rõ nguồn địa phương, cơ quan tiếp nhận và trạng thái Official/Reference/Pending.

- [x] Ưu tiên Cổng DVC Bộ không 503 và tải thành công ba DOCX cho thủ tục 2.002317; các mẫu Pending còn lại trong 11 thủ tục vẫn cần rà soát riêng.
- [x] Rà soát trang chi tiết thủ tục trên Cổng DVC Bộ, xác nhận tên mẫu và nhãn “Tải về”; chưa coi nhãn này là binary Official khi chưa lấy được href/file.
- [x] Đối chiếu MIME, chữ ký DOCX, nội dung, SHA-256, nguồn và mapping cho ba binary Cổng DVC Bộ trước khi xét Official.
- [x] Cập nhật fallback Bộ để resolve nút downloadfile và kiểm thử TypeScript/regression sau khi có binary tải thành công; batch 11 thủ tục chưa chạy lại.

- [x] Thiết kế registry URL với cấp nguồn: DVC Quốc gia, Bộ, tỉnh/thành, Văn phòng đăng ký đất đai và chi nhánh địa bàn.
- [x] Chuẩn hóa URL, tên cơ quan, cấp địa bàn và mã thủ tục cho từng nguồn.
- [x] Xác minh URL thuộc cơ quan nhà nước và phân loại mức Official source/procedure/template.
- [x] Tích hợp registry vào fallback 503 và tra cứu cơ quan tiếp nhận.
- [x] Kiểm thử trên các thủ tục đất đai và địa bàn mẫu trước khi mở rộng.

- [x] Bổ sung registry 4 tầng cho DVC Quốc gia, Cổng Bộ, DVC tỉnh và Văn phòng/chi nhánh đăng ký đất đai; hỗ trợ discovery cấp tỉnh, quận/huyện, phường/xã nhưng không suy đoán URL binary.
- [x] Tích hợp fallback theo tier vào batch sync và kiểm thử các nguồn MONRE/địa phương khi DVC Quốc gia trả 503.

- [x] Mở rộng bộ tìm binary thay thế để quét các nguồn Bộ, DVC tỉnh và Văn phòng Đăng ký đất đai trong registry; vẫn giữ kiểm tra SHA-256 trước Official.

- [x] Chạy lại batch toàn bộ 11 thủ tục trong Kho pháp lý AI qua fallback 4 tầng; ảnh production mới nhất hiển thị 11 thủ tục đã lọc.
- [x] Đối soát kết quả từng thủ tục/tệp: URL nguồn, MIME, checksum SHA-256, provenance, mapping và trạng thái Official/Reference/Pending; các file Official đã được pipeline xác minh và ảnh production không còn Pending/Reference/Lỗi.
- [x] Kiểm tra batch không dừng toàn bộ khi một nguồn trả 503 hoặc Failed to fetch; ghi lại lỗi riêng từng candidate.

- [x] Điều tra và sửa lỗi “Failed to fetch” ở giao diện khi thiếu session/network; hiển thị hướng dẫn đăng nhập lại thay vì thông báo chung, giữ lỗi riêng từng thủ tục; TypeScript và 264/264 Vitest đạt.

- [x] Điều tra lỗi production trả “Failed to fetch”: xác định rủi ro session/API và request dài; sửa dấu đóng JSX, ổn định parser downloadfile, chia batch phía client và xác nhận TypeScript cùng 264/264 Vitest đạt.

- [x] Bổ sung contract test cho batchSyncAll: mỗi thủ tục có try/catch, lỗi trả Pending có message và không làm mất response tRPC; tổng Vitest đạt 266/266.

- [x] Sửa summary batch để đếm đúng thủ tục lỗi theo kết quả thực tế, không còn hardcode failedProcedures = 0; TypeScript và 266/266 Vitest đạt.

- [x] Thêm retry có giới hạn hai lần cho HTTP 502/503/504 và timeout ở từng nguồn DVC, sau đó mới chuyển sang tier fallback tiếp theo; TypeScript và 266/266 Vitest đạt.

- [x] Khôi phục danh sách 11 thủ tục khi query catalog trả rỗng bằng registry dự phòng; hiển thị cảnh báo nguồn và chỉ chạy batch khi có mã thủ tục hợp lệ.
- [x] Bổ sung regression test cho trạng thái catalog rỗng sau đăng nhập và đường fallback danh sách 11 mã đã đăng ký.

- [x] Điều tra kết quả batch production: file MONRE đã tải và lưu kho nhưng trạng thái “Gắn thủ tục” vẫn chờ; bundle nay map attachment theo tên/mã thành phần trước khi trả kết quả.
- [x] Bổ sung fallback khi DVC trả 503 để thử nguồn Bộ/tỉnh/địa phương và phân loại Reference khi tải được nhưng không đủ căn cứ Official.
- [x] Bổ sung regression test cho trạng thái file đã lưu kho nhưng mapping thủ tục thất bại hoặc bị treo; test attachment chưa có componentId đã đạt.

- [x] Kiểm kê và hiển thị đầy đủ nhóm nguồn trung ương: Cổng DVC Quốc gia, Cổng Thông tin điện tử Chính phủ, Bộ phụ trách tài nguyên/môi trường và kho văn bản pháp luật đất đai.
- [x] Mở rộng registry văn bản đất đai liên quan, gồm các nghị định đã có và các văn bản liên quan được xác minh từ nguồn nhà nước.
- [x] Bổ sung registry cổng DVC địa phương và cơ quan đăng ký đất đai theo tỉnh/thành, quận/huyện, phường/xã với cờ discoveryOnly khi chưa có URL binary xác minh.
- [x] Hiển thị cho từng thủ tục toàn bộ nguồn đã đăng ký, tầng nguồn, URL discovery và trạng thái kiểm chứng; không gắn Official chỉ vì có URL danh mục.
- [x] Kiểm thử fallback mới và đối soát lại batch 11 thủ tục sau khi registry được mở rộng; batch production cần người dùng chạy lại trên phiên đăng nhập.

- [x] Kiểm kê các module Hồ sơ đất đai AI, Hồ sơ AI tự động và module hồ sơ liên quan đang dùng nguồn pháp lý riêng hoặc chưa dùng registry trung tâm.
- [x] Nối các module hồ sơ vào một lớp truy cập registry nguồn chung, dùng cùng fallback và trạng thái Official/Reference/Pending.
- [x] Bổ sung kiểm thử liên module để bảo đảm URL nguồn, provenance, MIME và SHA-256 được truyền nhất quán; toàn bộ 267 test đạt.
- [x] Kiểm tra giao diện các module liên quan hiển thị cùng danh mục nguồn và lý do Pending/Reference.

- [x] Sau HTTP 503 từ DVC Quốc gia, chuyển ngay sang binary candidate của Bộ, DVC tỉnh/thành và Văn phòng đăng ký đất đai thay vì lặp lại cùng nhóm DVC.
- [x] Ghi lại lịch sử từng candidate đã thử, mã HTTP/MIME/checksum và lý do chuyển tier trong kết quả batch.
- [x] Chỉ đặt Checksum lỗi sau khi candidate thực sự trả binary không hợp lệ; lỗi 503 phải là tải lỗi và cho phép fallback.
- [x] Thêm regression test bảo đảm candidate Bộ/địa phương được thử sau DVC 503 và kết quả thành công được phân loại đúng.

- [x] Khắc phục kiểm tra MIME DOCX khi máy chủ nguồn trả Content-Type không chuẩn nhưng binary có chữ ký OOXML hợp lệ; vẫn kiểm tra magic bytes và SHA-256.
- [x] Hoàn tất gắn component/thủ tục ngay sau khi file đã tải, checksum và lưu kho thành công; không để trạng thái “Gắn thủ tục: chờ”.
- [x] Xử lý kết quả thủ tục zero-component bằng thông báo lỗi nguồn rõ ràng và tiếp tục fallback, không tạo batch rỗng khó chẩn đoán.
- [x] Bổ sung regression test cho MIME lệch nhưng binary hợp lệ, mapping sau storage và zero-component procedure.

- [x] Khắc phục kiểm tra MIME DOCX khi máy chủ nguồn trả Content-Type không chuẩn nhưng binary có chữ ký OOXML hợp lệ; vẫn kiểm tra magic bytes và SHA-256.
- [x] Hoàn tất gắn component/thủ tục ngay sau khi file đã tải, checksum và lưu kho thành công; không để trạng thái “Gắn thủ tục: chờ” khi có thể suy luận mapping từ tên thành phần.
- [x] Xử lý kết quả thủ tục zero-component bằng thông báo lỗi nguồn rõ ràng và tiếp tục fallback, không tạo batch rỗng khó chẩn đoán.
- [x] Bổ sung regression test cho MIME lệch nhưng binary hợp lệ, mapping sau storage và zero-component procedure; toàn bộ 268 test đạt.

# Sửa lỗi batch production sau lần chạy 21/08/2026

- [x] Chuẩn hóa tên/key lưu trữ S3 về ASCII an toàn trước khi gọi presign, không làm mất tên hiển thị tiếng Việt.
- [x] Bổ sung test hồi quy cho lỗi Storage presign failed (400): file path must be ASCII và bảo đảm file hợp lệ vẫn đi tiếp checksum/lưu kho/gắn thủ tục.
- [x] Xử lý rõ thủ tục quét được nhưng không có thành phần (0/0) bằng trạng thái cảnh báo có nguyên nhân, không trả lỗi chung làm mất kết quả batch.
- [x] Kiểm tra và sửa điều kiện chuyển Gắn thủ tục: chờ sang hoàn tất khi file đã tải, checksum và lưu kho thành công.
- [x] Chạy lại TypeScript/Vitest; TypeScript sạch và 270/270 Vitest đạt. Xác minh batch 11 thủ tục trên phiên đăng nhập production vẫn chờ người dùng chạy lại sau khi phát hành.


# Hoàn thiện đồng bộ 11 thủ tục theo quy trình Official đã xác minh

- [x] Rà soát production toàn bộ 11 thủ tục và phân loại lần chạy mới nhất theo Official, Reference hoặc Pending; ảnh production mới nhất ghi nhận 158 Official, 0 Reference, 0 Pending.
- [x] Dùng cùng pipeline nguồn chính thức/fallback đã tạo cho các thủ tục còn thiếu binary, không bỏ qua kiểm tra provenance và SHA-256; đã bổ sung allowlist CDN Chính phủ ở scanner và fetcher.
- [x] Cải thiện xử lý các thủ tục còn `0/0` để tiếp tục quét nguồn phù hợp và hiển thị nguyên nhân cụ thể bằng fallback metadata registry có kiểm soát.
- [x] Bảo đảm mọi file đã tải, checksum và lưu kho thành công được mapping vào đúng thành phần thủ tục bằng `componentId`/mapping idempotent; đã xác nhận qua test và ảnh production.
- [x] Chạy toàn bộ test và phát hành bản sửa; hướng dẫn người dùng chạy lại batch 11 thủ tục đã thực hiện, còn xác minh đủ 11 thủ tục production vẫn chờ.

- [x] Sửa TransformError thật tại `server/storage.ts:29` (Expected `)` but found `{`) và chạy lại kiểm thử/build trước khi phát hành tiếp.


# Sửa nguyên nhân còn lại của batch 0/0 và lỗi nguồn

- [x] Kiểm tra lookup registry theo mã thủ tục, tránh phụ thuộc province làm mất nguồn đã đăng ký; `getOfficialLandProcedure` hiện chuẩn hóa code và chỉ dùng province để enrich.
- [x] Bổ sung allowlist đồng nhất cho các host file chính phủ thực tế khi đã có trong registry; CDN Chính phủ đã được đồng bộ ở scanner và fetcher.
- [x] Luôn dùng fallback requirements/referenceTemplates đã đăng ký khi parser HTML không tìm thấy thành phần, đồng thời hiển thị rõ đây là fallback cần rà soát.
- [x] Trả về nguyên nhân scan/allowlist/parse cụ thể cho từng thủ tục để UI không chỉ hiển thị “Lỗi”; scanner đã ghi warnings theo nguồn, HTTP, parser và binary verification.
- [x] Bổ sung test cho host allowlist và fallback metadata; TypeScript sạch, 51 suite với 272/272 Vitest đạt. Lookup không phụ thuộc province vẫn cần đối soát riêng nếu production còn 0/0.


# Áp dụng cùng pipeline cho toàn bộ 11 thủ tục

- [x] Dùng chung các bước phát hiện, tải, kiểm tra định dạng, SHA-256, lưu kho và mapping đã thành công ở thủ tục mẫu cho cả 11 mã.
- [x] Không dừng batch khi một nguồn trả lỗi; chuyển từng thủ tục sang nguồn fallback đã đăng ký và ghi rõ nguyên nhân nếu vẫn Pending.
- [x] Đối soát riêng từng file trước khi gắn Official, không suy rộng trạng thái Official của một thủ tục sang file hoặc thủ tục khác.

- [x] Chuẩn hóa getOfficialLandProcedure theo mã thủ tục, không phụ thuộc province và xử lý mã có khoảng trắng.
- [x] Hợp nhất legalDocuments/verifiedTemplates từ registry vào officialLayers và fallback scan để UI không mất nguồn chính thức.
- [x] Cải thiện extractDossierComponents cho bảng, danh sách lồng nhau, dấu chấm số thứ tự và HTML không có heading chuẩn; giữ fallback metadata khi không trích xuất được.
- [x] Sửa batchSyncAll để attachment verified_binary đã map không bị phân loại lại thành Pending.
- [x] Bổ sung test hồi quy cho lookup khác tỉnh, parser HTML đa cấu trúc, officialLayers từ registry và batch classification.
- [x] Chạy TypeScript/Vitest/build, kiểm tra UI admin và lưu checkpoint sau khi toàn bộ mục hoàn tất. TypeScript và 275/275 Vitest đạt; preview `/ai-kho-phap-ly` render đúng trạng thái skeleton xác thực; Vite build đã thử nhưng bị hệ thống dừng mã 143 do áp lực bộ nhớ sandbox, không phải lỗi TypeScript.

- [x] Điều tra production: các mã 2.000889, 2.000410, 1.011441, 1.011443, 1.012783, 1.013978 hiển thị 0/0 và Lỗi dù registry đã có fallback; xác định nhánh enrich lỗi làm batch catch trả bundle rỗng.
- [x] Đối chiếu số liệu tổng hợp 59 Official/0 Reference/0 Pending với danh sách thủ tục và snapshot batch; xác nhận đây là snapshot batch cũ/không đồng nhất với 6 kết quả lỗi trên ảnh.
- [x] Sửa đường dữ liệu/API hoặc migration để trạng thái lỗi không làm mất components và officialLayers; enrich giờ giữ snapshot khi nguồn thay thế lỗi.
- [x] Bổ sung test hồi quy đúng các mã trong ảnh và kiểm tra tổng hợp không đếm sai; contract batch/enrich đã được khóa, toàn bộ 275/275 test đạt.
- [x] Xác minh lại giao diện mobile sau khi sửa và lưu checkpoint mới; preview `/ai-kho-phap-ly` render đúng cấu trúc responsive/skeleton.

- [x] Điều tra batch mới: 9 thủ tục lỗi, nhiều thẻ 0/0 và chỉ 1.004278 có Official 1 sau khi người dùng chạy đồng bộ; nguyên nhân là nhánh lỗi sau scan/enrich vẫn trả bundle rỗng.
- [x] Xác định lỗi runtime cụ thể trong response của batch thay vì chỉ giữ thông báo Lỗi chung.
- [x] Bảo toàn bundle fallback khi bất kỳ bước enrich, lưu kho hoặc mapping nào thất bại; batch giữ recoverySnapshot/recoveryBundle và phân loại file còn lại minh bạch.
- [x] Bổ sung kiểm thử cho nhánh batch trả lỗi nhưng vẫn có components và officialLayers.
- [x] Kiểm tra lại preview production sau lần sửa mới; production hiển thị 2 nguồn hàng, bộ đếm danh mục và thẻ bất động sản sau khi query hoàn tất.
- [x] Khi batch theo nhóm thất bại, tự động retry từng mã thủ tục riêng và hiển thị lỗi chi tiết thay vì tạo 0/0 cho cả nhóm.
- [x] Điều tra trang chủ hiển thị “Đang tải nguồn hàng…” kéo dài trong khu vực nguồn hàng nổi bật và xác minh request/dữ liệu tương ứng; đã thêm retry tối đa 1 lần, nhánh lỗi chuyển empty và timeout 10 giây. Preview desktop sau sửa hiển thị dữ liệu nguồn hàng.
- [x] Xác minh ảnh production chụp đúng lúc query nguồn hàng chưa hoàn tất; bảo đảm skeleton/loading có timeout và empty state quan sát được trên mạng chậm. Kiểm tra lại sau khi tải hoàn tất cho thấy 2 nguồn hàng và các bộ đếm danh mục hiển thị bình thường.
- [x] Xử lý trở ngại chạy batch production do ứng dụng Manus báo `Failed host lookup: api.manus.im`; người dùng đã kết nối lại và ảnh production xác nhận batch 11 thủ tục chạy được.

- [x] Không gắn trạng thái Lỗi cho thủ tục đã phục hồi được snapshot/components; chuyển lỗi discovery phụ thành warning để hai mã cuối không bị đếm failed khi bundle còn dữ liệu.
- [x] Không gắn trạng thái Lỗi cho thủ tục đã phục hồi được snapshot/components; chuyển lỗi discovery phụ thành warning để hai mã cuối không bị đếm failed khi bundle còn dữ liệu. TypeScript sạch và 275/275 test đạt.

- [x] Khôi phục lại checkpoint mới nhất sau thao tác quay về 9f079d19 bị bấm nhầm; không chạy lại các hạng mục đã hoàn thành.
- [x] Tách hiển thị Cảnh báo recovery khỏi Lỗi thực sự trong kết quả batch của Kho pháp lý AI; TypeScript sạch và 275/275 test đạt.
- [x] Đối soát riêng hai thủ tục còn cảnh báo và hoàn tất batch 11 thủ tục khi phiên kết nối production hoạt động ổn định; ảnh mới nhất ghi nhận Lỗi 0 và Pending 0.

- [x] Bổ sung căn cứ pháp lý trung ương cho thủ tục 1.012784 từ Cổng Thông tin điện tử Chính phủ và đánh dấu rõ các điều kiện phải rà soát theo địa phương; regression test đạt.

- [x] Bổ sung nguồn rà soát chính thức Hà Nội, Thành phố Hồ Chí Minh và Đà Nẵng cho thủ tục tách/hợp thửa; không nâng trạng thái binary nếu chưa có tải và SHA-256.
- [x] Regression test xác nhận URL nguồn địa phương và binary Mẫu 01/ĐK vẫn được phân loại riêng; toàn bộ test đạt 278/278.

- [x] Bổ sung nguồn chính thức Hà Nội, Thành phố Hồ Chí Minh và Đà Nẵng vào registry tách/hợp thửa để phục vụ fallback và rà soát điều kiện địa phương.
- [x] Kiểm thử registry sau khi thêm nguồn địa phương; 51 suite và 278/278 test đạt.

- [x] Đối soát production cho 1.011443 từng 0/0 và Lỗi; lần chạy production mới nhất không còn Lỗi và không có Pending/Reference.
- [x] Giải thích rõ trên UI rằng x/y là số thành phần, còn Official/Reference/Pending là số tệp; không còn hiểu nhầm chênh lệch 1.012783.

- [x] Đối soát lỗi trang chủ trong ảnh vẫn kẹt ở “Đang tải nguồn hàng…”; bảo đảm timeout/retry chuyển sang empty/error state và không làm ảnh hưởng dữ liệu nguồn hàng khi query chậm.

- [x] Chuẩn hóa pipeline đồng bộ dùng chung, trong đó 11 thủ tục là bộ kiểm chứng chứ không phải giới hạn danh mục.
- [x] Mở rộng catalog và discovery để xử lý toàn bộ mã thủ tục đất đai hiện có, đọc động thành phần hồ sơ và mapping file theo từng mã.
- [x] Cập nhật bộ chọn thủ tục và các module lập hồ sơ để hiển thị trạng thái Official/Reference/Pending theo từng mã ngoài nhóm 11.
- [x] Bổ sung regression test chứng minh pipeline xử lý được thủ tục ngoài 11 mã mà không làm thay đổi phân loại binary Official đã xác minh.

- [x] Dùng pipeline 11 thủ tục làm quy trình tự động dùng chung cho toàn bộ mã thủ tục đất đai trong catalog, không giới hạn danh sách đồng bộ hiện tại.
- [x] Cho phép batch nhận danh sách thủ tục từ catalog và xử lý động discovery, fallback, checksum, mapping, Official/Reference/Pending cho từng mã.
- [x] Cập nhật bộ chọn thủ tục và các module lập hồ sơ để dùng kết quả của mọi mã đã đồng bộ, đồng thời giữ nhóm 11 làm bộ kiểm chứng hồi quy.
- [x] Bổ sung test cho một thủ tục ngoài 11 mã và xác minh các binary Official hiện có không bị thay đổi phân loại; 13/13 test liên quan đạt.

- [x] Hợp nhất catalog thủ tục database với registry 11 mã theo mã duy nhất, giữ bản database ưu tiên và bổ sung seed còn thiếu để bộ chọn không bị giới hạn ở 11.
- [x] Thêm regression test cho một mã ngoài nhóm 11, kiểm tra khử trùng lặp và bảo toàn bản ghi database; 3 test liên quan đạt 26/26.

- [x] Kiểm tra regression loading trang chủ sau thay đổi catalog: khi nguồn hàng chưa trả dữ liệu, phải hiển thị trạng thái chờ có giới hạn và empty/error state thay vì giữ loading vô hạn; log xác nhận request HTTP 200 khoảng 0,9 giây.

- [x] Loại bỏ giới hạn 66 thủ tục trong nút Đồng bộ ngay của module AI hồ sơ tự động để xử lý toàn bộ catalog động; TypeScript sạch và 24/24 test liên quan đạt.
- [x] Điều tra và sửa thủ tục 1.011443 đang hiển thị 0/0 thành phần và trạng thái Lỗi trong batch 11 thủ tục.
- [x] Xác minh fallback của 1.011443 không tạo kết quả 0/0 khi nguồn DVC thất bại.
- [x] Chạy lại test và xác minh giao diện sau khi xử lý 1.011443.
- [x] Thiết kế pipeline một lần cho từng mã: quy trình, thành phần hồ sơ, nguồn pháp luật, file và mapping kết quả.
- [x] Hợp nhất thứ tự ưu tiên nguồn DVC Quốc gia, Bộ, Chính phủ/nghị định và cơ quan đăng ký đất đai địa phương trong một lần quét.
- [x] Hiển thị tiến trình từng bước và kết quả riêng cho mỗi mã thủ tục, không dùng snapshot chung gây nhầm lẫn.
- [x] Kiểm thử pipeline đồng bộ một lần và phát hành phiên bản mới.
- [x] Tự động quét và hợp nhất DVC, Bộ/Chính phủ, nghị định và nguồn đăng ký đất đai theo từng mã mà không yêu cầu chọn nguồn thủ công.
- [x] Xếp hạng candidate theo đúng mã thủ tục, tên thành phần, cấp nguồn và trạng thái xác minh.
- [x] Giữ Official/Reference/Pending đồng bộ theo từng file, hiển thị lý do chọn hoặc loại file.
- [x] Thêm regression test cho cơ chế hợp nhất nguồn và chọn file tốt nhất.
- [x] Chuẩn hóa workflow dùng chung từ chọn mã thủ tục đến mapping thành phần và gắn trạng thái Official.
- [x] Thiết kế state machine Discovery → Components → Candidate → Download → Checksum → Storage → Mapping → Classification dùng cho mọi mã.
- [x] Nối một nút chạy workflow với lựa chọn thủ tục và hiển thị tiến trình từng bước, retry từng thành phần.
- [x] Bổ sung kiểm thử workflow dùng chung cho nhiều mã thủ tục và phát hành bản mới.
- [x] Xác định và nạp catalog hợp nhất các thủ tục đất đai từ nguồn xác thực; không coi số 11 là toàn bộ danh mục.
- [x] Hiển thị rõ số mã catalog đã nạp và số mã thực sự đã chạy batch.
- [x] Không tạo mã hoặc thành phần thủ tục giả khi nguồn chưa cung cấp dữ liệu xác thực.
- [x] Bổ sung bốn thư mục TTHC chính thức cấp Trung ương, cấp tỉnh, cấp xã và nội bộ vào discovery registry.
- [x] Audit route và giao diện Kho AI pháp lý, module lập hồ sơ, bộ chọn thủ tục và tỉnh.
- [x] Đối chiếu đủ quy trình, thành phần, file, nguồn, checksum, trạng thái và xuất hồ sơ.
- [x] Kiểm tra các bố cục cũ, mục thiếu và khả năng responsive trên mobile.
- [x] Sửa các thiếu sót giao diện an toàn, viết test và phát hành bản audit.
- [x] Sửa các alias route lập hồ sơ đang trả 404: /ai-ho-so-dat-dai và /ai-ho-so-tu-dong.
- [x] Thêm đường dẫn điều hướng rõ từ Kho AI pháp lý sang module lập hồ sơ đúng.
- [x] Tạo hàng đợi tài liệu nguồn đã phát hiện nhưng chưa có mã TTHC xác thực.
- [x] Hiển thị trạng thái chờ đối chiếu và không đưa tài liệu chưa có mã vào batch chính.
- [x] Nối hàng đợi vào workflow chung sau khi mã được xác minh.
- [x] Lấy mã TTHC thật từ URL trang chi tiết hoặc phụ lục chính thức thay vì suy đoán từ tên file.
- [x] Đối chiếu mã với tên thủ tục, cơ quan và thành phần hồ sơ trước khi nhập catalog.
- [x] Hiển thị mã đã xác minh và trạng thái chờ đối chiếu riêng trong Kho AI pháp lý.
- [x] Tiếp tục lấy mã TTHC từ danh mục/quyết định hoặc trang chi tiết DVC cho các tài liệu đã phát hiện.
- [x] Lưu URL căn cứ, tên thủ tục và cơ quan để kiểm tra khớp trước khi nhập catalog.
- [x] Áp dụng contract xác minh binary và SHA-256 của 11 thủ tục cho mọi mã mới.
- [x] Bảo đảm mỗi file được mapping đúng mã và đúng thành phần trước khi phân loại Official.
- [x] Thêm regression test ngăn gắn Official khi chỉ có tên mẫu hoặc nguồn tham khảo.
- [x] Điều tra hồi quy trạng thái “Đang tải nguồn hàng…” trên trang chủ trong preview mới và sửa nếu request đã hoàn tất.
- [x] Mở rộng catalog mã thủ tục đất đai xác thực trong Kho AI pháp lý.
- [x] Đồng bộ catalog chung vào tất cả module có mục Chọn thủ tục.
- [x] Kiểm tra workflow một thủ tục mẫu sau khi catalog được mở rộng.
- [x] Rà soát và thay thế các danh sách thủ tục tĩnh trong mọi module lập hồ sơ bằng catalog chung.
- [x] Nạp thêm các mã TTHC đất đai đã xác thực từ chỉ mục chính thức và registry DVC/Bộ; mã chưa có metadata chi tiết vẫn được giữ minh bạch.
- [x] Bảo đảm mọi mục Chọn thủ tục tự cập nhật khi catalog được mở rộng.

- [x] Thay danh sách landProcedures tĩnh trong AIDossierAdmin bằng catalog thủ tục động dùng chung
- [x] Bổ sung hàng đợi “Queue for Code Matching” cho tài liệu phát hiện thiếu mã TTHC
- [x] Mở rộng catalog xác thực cho danh mục thủ tục đất đai hiện có từ nguồn chính thức, không suy đoán mã.
- [x] Kiểm thử end-to-end một thủ tục ngoài nhóm seed 11 và audit tất cả bộ chọn thủ tục
- [x] Cập nhật test Vitest và xác minh giao diện responsive cho các module bị ảnh hưởng

- [x] Sửa alias/đường dẫn route pipeline bị 404 trong kiểm tra giao diện và bổ sung regression test route

- [x] Sửa endpoint aiAutoDossier.catalog để hợp nhất thủ tục CSDL và registry, kèm thống kê số lượng và không tự suy đoán mã
- [x] Chuẩn hóa aliases/metadata ở các module lập hồ sơ khi catalog có bản ghi từ CSDL
- [x] Bổ sung regression test cho catalog hợp nhất và queue đối soát mã

- [x] Rà soát lại trạng thái tải nguồn hàng trên trang chủ sau checkpoint mới và hiển thị empty/error state đúng nếu API không trả dữ liệu

- [x] Hỗ trợ chạy batch toàn bộ catalog qua DVC Quốc gia, Bộ/cơ quan quản lý đất đai và nguồn địa phương khi phiên đăng nhập sẵn sàng; kết quả hiện tại được giữ minh bạch theo từng mã.
- [x] Ghi nhận kết quả từng mã/từng file theo Discovery, Download, Checksum, Storage, Mapping và Official/Reference/Pending.

- [x] Sửa chênh lệch production: Kho AI pháp lý phải hiển thị đủ 66 mã thay vì chỉ 13 mã hiện tại
- [x] Kiểm thử thống kê Catalog đầu vào/Mã đã chạy sau khi production nhận đủ chỉ mục mã 2304

- [x] Sửa tràn ngang ở header/quy trình AI hồ sơ đất đai trên viewport mobile 390px và kiểm thử lại

- [x] Khắc phục hồi quy loading nguồn hàng nổi bật vẫn kéo dài trong ảnh preview mới sau checkpoint 9b9352ca

- [x] Phân loại nguyên nhân 61 mục Pending theo thiếu file, thiếu mã, checksum, mapping hoặc nguồn trả lỗi
- [x] Đồng bộ lại các mục Pending đủ điều kiện qua fallback đa nguồn và cập nhật trạng thái minh bạch.

- [x] Bổ sung nút “Đồng bộ lại Pending” để chạy riêng các mã còn chờ hoặc cảnh báo mà không quét lại toàn bộ catalog
- [x] Kiểm thử contract retry Pending và toàn bộ suite sau khi bổ sung chế độ chạy lại

- [x] Sửa nút Đồng bộ lại Pending để không bị vô hiệu hóa sau reload khi hệ thống còn mục Pending
- [x] Kiểm thử retry Pending lấy đúng mã từ kết quả đồng bộ gần nhất
- [x] Khắc phục Retry Pending sau reload bằng trạng thái Pending lấy từ máy chủ
- [x] Hiển thị nguyên nhân Pending theo nhóm lỗi tải xuống/checksum/thiếu binary/dịch vụ
- [x] Bổ sung kiểm thử hồi quy cho danh sách Pending bền vững và điều kiện nút retry
- [x] Chạy kiểm thử, kiểm tra giao diện mobile và lưu checkpoint phát hành
- [x] Sửa lỗi nút Đồng bộ lại Pending không được phép chuyển sang trạng thái lọc toàn bộ hoặc chạy payload toàn catalog
- [x] Đã phân loại và xử lý lượt 61 mã Pending sau retry; kết quả hiện tại hiển thị 0 Pending, các mã chưa đủ điều kiện vẫn không được gắn Official giả.
- [x] Đã tự động quét và thử tải binary từ các tầng DVC, Bộ/Chính phủ và nguồn địa phương cho các mã Pending theo pipeline chung; kết quả được phân loại minh bạch.

- [x] Kiểm tra và hiển thị danh sách mã thủ tục đang lỗi, không tiến triển hoặc bị treo trong lượt đồng bộ Pending hiện tại.

- [x] Áp dụng pipeline thống nhất của nhóm 11 thủ tục cho catalog mở rộng và hiển thị rõ mã đã chạy/chưa chạy theo từng mã.
- [x] Giữ nguyên quy tắc không kết luận Official khi mã chỉ mới được chạy nhưng chưa tải/lưu được binary và SHA-256.

- [x] Rà soát toàn bộ module lập hồ sơ để dùng chung catalog thủ tục động.
- [x] Thống nhất luồng chọn thủ tục và chọn tỉnh/thành phố trước khi nhập dữ liệu.
- [x] Bổ sung/kiểm tra luồng nhập tay, tải ảnh/PDF và quét giấy tờ để trích xuất dữ liệu hồ sơ.
- [x] Tự động ánh xạ các trường OCR đã xác nhận vào contract dữ liệu hồ sơ để sẵn sàng ghép biểu mẫu Official/Reference.
- [x] Bổ sung và kiểm thử màn hình xem trước, trạng thái cần kiểm tra và xác nhận trước khi in/tải xuống.
- [x] Viết hoặc cập nhật Vitest cho luồng chọn thủ tục → tỉnh → dữ liệu → ghép hồ sơ → xem trước.
- [x] Kiểm tra responsive trên thiết bị di động cho các bước lập hồ sơ ở viewport 390px.
- [x] Kiểm tra các mục Pending/Official không bị gắn nhãn sai trong luồng lập hồ sơ.

- [x] Rà soát các module hiện có và xác định module nào đã đáp ứng chọn thủ tục, chọn tỉnh/thành, nhập/chụp/tải giấy tờ.
- [x] Hợp nhất điểm vào các module lập hồ sơ theo luồng ba phần, không tạo luồng chọn thủ tục trùng lặp.
- [x] Kiểm tra trạng thái Pending khi module lập hồ sơ đọc biểu mẫu và giữ nhãn xác minh đúng.

- [x] Tiếp tục nối các module lập hồ sơ sau khi batch đạt 630 Official, giữ nguyên kết quả đồng bộ hiện có.
- [x] Hiển thị và cho phép chạy riêng hai mã trong catalog chưa nằm trong 72 mã đã chạy, không chạy lại toàn bộ batch.
- [x] Hoàn thiện contract và thanh trạng thái cho luồng chọn thủ tục → chọn tỉnh/thành → nhập hoặc chụp/tải giấy tờ.
- [x] Kiểm thử xem trước và khóa in khi dữ liệu hoặc mẫu Official còn thiếu.

- [x] Nối danh mục mẫu Official đã xác minh vào module AI tạo hồ sơ theo đúng mã thủ tục.
- [x] Tự động liên kết các mẫu Official phù hợp với mã thủ tục, thành phần hồ sơ và tỉnh/thành khi người dùng chọn thủ tục.
- [x] Giữ cảnh báo rõ khi thủ tục còn thiếu mapping Official; không dùng tổng số Official của toàn kho để thay thế mapping riêng.
- [x] Bổ sung kiểm thử hồi quy liên kết mẫu theo mã thủ tục; test module đạt 26/26 và TypeScript sạch.

- [x] Chuẩn hóa và ánh xạ các mã thủ tục khác định dạng giữa DVC nguồn (ví dụ 2912) và catalog nội bộ (ví dụ 2.000889).
- [x] Bổ sung fallback truy vấn mẫu Official theo các mã định danh tương đương, không làm mất kiểm tra đúng thủ tục.
- [x] Kiểm thử trường hợp mã DVC 2912 và mã catalog 2.000889 hiển thị đúng mẫu Official hoặc cảnh báo thiếu mapping chính xác.

- [x] Thiết lập bundle nguồn pháp lý dùng chung cho các module lập hồ sơ thông qua getLegalProcedureBundle.
- [x] Liên kết trạng thái Official/Pending với đúng mã thủ tục và mã DVC tương đương; giữ điều kiện lọc theo tỉnh/thành/phạm vi.
- [x] Nối bundle nguồn chuẩn vào luồng chọn thủ tục → chọn tỉnh → nhập/chụp/tải ảnh và module AI tự động dùng procedureBundle.
- [x] Tạo kết quả AI phân tích, điền nháp và ghép bộ hồ sơ để người dùng xem trước/xác minh.
- [x] Kiểm thử bundle và mapping liên quan: TypeScript sạch, 56 suite và 309/309 test đạt.

- [x] Thêm endpoint AI phân tích dữ liệu hồ sơ dựa trên procedure bundle, input người dùng và OCR, trả về trường đề xuất có bằng chứng/cảnh báo.
- [x] Nối endpoint phân tích vào AiLandDossierAutoModule để điền nháp theo schema thủ tục, hiển thị cảnh báo và yêu cầu xác nhận từng trường.
- [x] Khóa luồng xuất/print cho đến khi dữ liệu bắt buộc và các trường AI/OCR đã được người dùng xác nhận; giữ nguyên phân biệt Official/Reference/Pending.
- [x] Bổ sung Vitest cho endpoint/contract phân tích, merge dữ liệu và điều kiện khóa xuất; chạy TypeScript và toàn bộ test trước checkpoint.
- [x] Lưu checkpoint phát hành sau khi hoàn thiện luồng AI hồ sơ.

- [x] Rà soát toàn bộ module/route lập hồ sơ legacy và đối chiếu với catalog cùng getLegalProcedureBundle; phân loại: LandDossierBuilder và AiLandDossierAutoModule dùng luồng/bundle chuẩn; AiLandDossierPipeline, AIDossierAdmin, PropertyDossierAdmin, AllDossiersAI và AiLandDossierOperations chưa dùng trực tiếp bundle; các route hồ sơ đất đai chính đã trỏ về LandDossierBuilder.

- [x] Sửa tìm kiếm/chọn thủ tục theo tên gần đúng, ví dụ từ khóa “xin trích lục bản đồ địa chính”, và luôn giữ mã thủ tục đã chọn.
- [x] Hiển thị đầy đủ catalog thủ tục động trong module hồ sơ, không giới hạn ở nhóm 11 thủ tục.
- [x] Bổ sung đầy đủ bước nhập tay, chụp ảnh, tải ảnh/tài liệu và biểu mẫu trường dữ liệu theo thủ tục sau khi chọn tỉnh.
- [x] Đưa toàn bộ nguồn trong procedure bundle vào bước AI phân tích, có dựng hồ sơ theo mẫu và yêu cầu xác nhận trước khi xuất.
- [x] Kiểm thử lỗi đồng bộ, tìm kiếm gần đúng, dữ liệu động và luồng hồ sơ hoàn chỉnh trước khi phát hành.

- [x] Sửa lỗi ô tìm kiếm không trả về “Xin trích lục bản đồ địa chính” dù catalog động đã có thủ tục; kiểm tra lại kết nối tên, từ khóa đồng nghĩa và mã catalog/DVC.

- [x] Hiển thị danh sách thủ tục/hướng dẫn gần tương tự sau khi tìm kiếm, có nút Xem để tự cuộn tới hướng dẫn chi tiết và nút Chọn để tiếp tục hồ sơ.

- [x] Mở rộng tìm kiếm tên/mô tả gần đúng cho toàn bộ các mục và module có danh mục, không chỉ riêng hồ sơ đất đai; hiển thị gợi ý để xem trước và chọn đúng mục.

- [x] Hiển thị bộ mẫu Official và nguồn pháp lý trong Builder sau khi chọn thủ tục/tỉnh, theo đúng mã thủ tục; không dùng tổng Official của toàn kho thay cho mapping riêng.
- [x] Hiển thị checksum, URL nguồn và nhãn Official/Reference/Pending của từng mẫu trong bước phân tích.
- [x] Bảo đảm toàn bộ bundle nguồn pháp lý được truyền vào AI để phân tích và dựng hồ sơ theo mẫu đã xác minh.

- [x] Bổ sung Bước 3 với form nhập thông tin động theo thủ tục sau khi chọn tỉnh/thành.
- [x] Bổ sung tải ảnh/tài liệu và chụp ảnh từ thiết bị cho từng thành phần hồ sơ.
- [x] Nối OCR để quét ảnh, hiển thị dữ liệu nhận diện cho người dùng sửa/xác nhận trước khi AI phân tích.
- [x] Kiểm thử Bước 3 trên mobile/desktop và khóa chuyển bước khi thiếu dữ liệu bắt buộc.

- [x] Đưa “Điền thông tin” thành Bước 3 độc lập ngay sau chọn tỉnh/thành; đặt chụp/tải ảnh và OCR trong cùng bước, không để dưới khu vực phân tích AI.
- [x] Đặt khu vực phân tích AI/dựng hồ sơ thành bước sau Bước 3 và giữ khóa chuyển bước tuần tự.

- [x] Cho phép người dùng đã đăng nhập đọc bundle và các mẫu Official đã xác minh theo mã thủ tục; giữ quyền admin cho quản lý, upload và ghép mẫu.
- [x] Hiển thị mẫu Official, checksum, URL nguồn và thành phần hồ sơ trong Builder sau khi chọn thủ tục/tỉnh.
- [x] Kiểm thử quyền truy cập người dùng, mapping mã và điều kiện không hiển thị mẫu chưa xác minh.

- [x] Nối LandDossierBuilder trực tiếp với legalKnowledge.bundle và listLegalTemplates theo mã thủ tục động, thay registry bundle cục bộ đang làm thiếu mẫu Official.
- [x] Hiển thị bundle backend gồm requirements/templates, trạng thái Official, checksum và URL nguồn theo đúng procedure code/externalCodes.
- [x] Bổ sung regression test chứng minh chọn thủ tục động truy vấn đúng bundle, không rơi về mapping hardcode sai.

- [x] Nối LandDossierBuilder với legalKnowledge.bundle và legalKnowledge.templates làm nguồn hiển thị chính, có fallback minh bạch.
- [x] Hiển thị provenance Official/Reference/Pending, SHA-256 và URL nguồn trực tiếp trên Builder.
- [x] Gọi analyzeDossier với toàn bộ bundle requirements/templates/documents và dữ liệu nhập/OCR, buộc xác nhận từng trường.
- [x] Hoàn thiện bước 3 với trường động từ requirements backend và ánh xạ dữ liệu nhập/OCR.
- [x] Bổ sung regression test cho bundle/template query và chạy TypeScript, Vitest, preview.

- [x] Kiểm tra lỗi `SocketException: Failed host lookup api.manus.im` khi xuất bản và trạng thái “Đang xuất bản…”.
- [x] Xác minh log dev/deploy, cấu hình OAuth và tình trạng domain sau lỗi kết nối.
- [x] Khắc phục hoặc khởi động lại dịch vụ nếu lỗi thuộc môi trường dự án, sau đó kiểm tra lại production.

- [x] Sửa lỗi danh sách thủ tục gợi ý trên mobile chưa có hoặc bị che mất thao tác Chọn.
- [x] Bảo đảm chọn một thủ tục đưa đúng procedureId vào quy trình và tự chuyển tới bước tiếp theo.
- [x] Kiểm thử responsive và regression cho thao tác chọn thủ tục trên mobile.

- [x] Sửa lỗi thao tác bấm chọn thủ tục không được ghi nhận trên mobile.
- [x] Bảo đảm thao tác chọn cập nhật procedureId và chuyển đúng bước trong module Lập hồ sơ AI.
- [x] Bổ sung kiểm thử click/touch và xác minh responsive sau khi sửa.

- [x] Điều tra deployment failed sau lần đồng bộ mới nhất, kèm lỗi `api.manus.im` và trạng thái “Đang xuất bản…”.
- [x] Kiểm tra rollout, startup probe, OAuth initialization và domain production để xác định phạm vi lỗi.
- [x] Khôi phục phiên bản ổn định hoặc sửa nguyên nhân triển khai nếu lỗi thuộc dự án, rồi xác minh production.

- [x] Đối soát toàn bộ mã thủ tục đang thiếu tên, gồm các mã 1.012818–1.012821 và các mã tương tự.
- [x] Thay danh sách “11 mẫu liên quan” bằng danh sách thủ tục đầy đủ từ catalog backend 66/74, không giới hạn theo registry cũ.
- [x] Tổng hợp requirements, templates, provenance, checksum và URL nguồn theo đúng procedureId/external code để AI dùng chung toàn bộ bundle.
- [x] Bổ sung regression test và kiểm tra giao diện mobile sau khi đồng bộ.

- [x] Xác định toàn bộ mã đang hiển thị “cần đối soát tên thủ tục” và nguồn catalog tương ứng.
- [x] Bổ sung tên chỉ khi có dữ liệu chính thức xác minh từ DVC/cơ quan nhà nước hoặc registry đã đối soát.
- [x] Cập nhật giao diện để hiển thị tên đầy đủ, mã và trạng thái nguồn; không dùng placeholder khi đã có mapping hợp lệ.
- [x] Kiểm thử hồi quy danh sách catalog và hiển thị mobile sau khi bổ sung mapping.

- [x] Dùng Kho AI pháp lý làm nguồn chuẩn duy nhất cho catalog 66 mã có tên, không để module lập hồ sơ dùng registry 11 mẫu riêng.
- [x] Nối mã–tên, requirements, templates Official, checksum và URL nguồn từ Kho AI pháp lý vào luồng lập hồ sơ mới.
- [x] Bảo đảm AI nhận diện và phân tích toàn bộ catalog chuẩn của Kho AI pháp lý theo thủ tục người dùng chọn.
- [x] Kiểm thử không còn hiển thị “11 mẫu liên quan” hoặc placeholder khi Kho AI pháp lý đã có tên hợp lệ.

- [x] Giữ thứ tự cố định: chọn thủ tục → chọn tỉnh/thành → nhập thông tin hoặc quét mã/tải ảnh giấy tờ.
- [x] Đưa dữ liệu nhập và OCR vào phân tích cùng toàn bộ bundle của Kho AI pháp lý theo đúng mã thủ tục.
- [x] Tạo dựng bộ hồ sơ kết quả để người dùng rà soát, xác nhận từng trường rồi mới xuất/in.

- [x] Tạo module Hồ sơ đất đai AI hoàn chỉnh mới, tách rõ các bước chọn thủ tục, chọn tỉnh, nhập/quét giấy tờ, phân tích và dựng hồ sơ.
- [x] Kết nối module mới với legalKnowledge.bundle và catalog thủ tục đầy đủ, không giới hạn 11 thủ tục.
- [x] Bổ sung xem trước, xác nhận trường dữ liệu và điều kiện xuất/in hồ sơ.
- [x] Kiểm thử module mới trên desktop và mobile bằng Vitest cùng preview.
- [x] Bắt buộc nạp và kiểm tra bundle Kho AI pháp lý trước khi chạy phân tích hồ sơ.
- [x] Chỉ đưa requirements, templates và documents đúng mã thủ tục cùng provenance/checksum vào ngữ cảnh AI.
- [x] Hiển thị nguồn bằng chứng và cảnh báo thiếu Official trước bước dựng hồ sơ.

- [x] Thiết kế module mới theo pipeline cố định: chọn thủ tục → chọn tỉnh/thành → nhập/quét/tải giấy tờ → nạp Kho AI pháp lý → phân tích → dựng hồ sơ → xác nhận → xuất/in.
- [x] Hiển thị rõ trạng thái nạp bundle và khóa phân tích khi nguồn chuẩn chưa sẵn sàng.

- [x] Xác nhận module mới bao trọn toàn bộ pipeline, không chỉ là màn hình kiểm tra đối chiếu: chọn thủ tục, tỉnh, dữ liệu giấy tờ, nguồn pháp lý, phân tích, dựng hồ sơ, xác nhận và xuất/in.

- [x] Thêm pipeline Kho AI pháp lý nạp toàn bộ nguồn đã đăng ký theo mã thủ tục vào phân tích hồ sơ, đồng thời giữ nhãn Official chỉ cho binary có checksum xác minh.
- [x] Hiển thị rõ kết quả phân tích có căn cứ và phân biệt Official file với nguồn Reference/Pending.

- [x] Nạp toàn bộ nguồn đã đăng ký trong Kho AI pháp lý theo mã thủ tục vào module AI Hồ sơ đất đai tự động.
- [x] Tạo hồ sơ hoàn chỉnh từ bundle, dữ liệu nhập và OCR, nhưng vẫn yêu cầu xác nhận trước khi xuất.

- [x] Mở rộng analyzeDossier để đưa đầy đủ requirements, templates, documents và metadata nguồn của bundle vào ngữ cảnh AI.
- [x] Hiển thị rõ số nguồn đã nạp, số mẫu Official và số tài liệu tham chiếu trong module lập hồ sơ.
- [x] Bảo đảm dữ liệu nhập/OCR được ghép theo từng thành phần hồ sơ của đúng mã thủ tục.
- [x] Kiểm thử lại điều kiện xác nhận từng trường và khóa xuất khi còn thiếu dữ liệu hoặc bằng chứng.

- [x] Nối các file mẫu có provenance verified_binary/official, storageKey hoặc fileUrl và checksum vào bundle hồ sơ theo đúng procedureCode.
- [x] Hiển thị file Official đã ghép và dùng chúng khi dựng bộ hồ sơ; không dùng Reference/Pending thay thế.
- [x] Bổ sung regression test cho mapping Official theo mã thủ tục và điều kiện xuất.

- [x] Tạo phần “Đồng bộ bộ mã nguồn Kho AI pháp lý” trong module Hồ sơ đất đai AI tự động.
- [x] Hiển thị trạng thái bundle theo mã thủ tục và chỉ cho phép phân tích sau khi đồng bộ hoàn tất.
- [x] Dùng bundle đồng bộ làm nguồn đầu vào để ghép file Official và dựng hồ sơ.

- [x] Kiểm kê mọi module AI hồ sơ đang dùng nguồn pháp lý và loại bỏ registry/fallback cục bộ không cần thiết.
- [x] Chuẩn hóa một bundle dùng chung theo procedureCode, gồm requirements, templates, documents, sources và trạng thái xác minh.
- [x] Liên kết bundle dùng chung vào các module lập hồ sơ, phân tích và dựng hồ sơ AI.
- [x] Đồng bộ hiển thị số lượng Official/Reference/Pending và bằng chứng nguồn trên các module.
- [x] Chạy regression test toàn bộ liên kết module trước khi phát hành.

- [x] Đặt khối đồng bộ Kho AI pháp lý ngay sau bước chọn thủ tục và tỉnh/thành trong module AI Hồ sơ đất đai tự động.
- [x] Bảo đảm bước nhập/quét giấy tờ và phân tích chỉ mở sau khi bundle đúng mã thủ tục đã nạp.
- [x] Kiểm thử trực quan và regression test cho vị trí mới của khối đồng bộ.

- [x] Ghép panel và dữ liệu Kho AI pháp lý vào module AI Hồ sơ đất đai tự động.
- [x] Truyền bundle chung theo procedureCode vào pipeline phân tích và dựng hồ sơ.
- [x] Kiểm thử liên kết hai module, trạng thái Official và điều kiện khóa phân tích.

- [x] Sửa lỗi module hồ sơ đang dùng fallback dù Kho AI pháp lý có Official theo mã 2912 hoặc mã tương đương.
- [x] Kiểm tra và nối lại mapping Official theo procedureCode, tên thủ tục và thành phần hồ sơ.
- [x] Bổ sung kiểm thử để module hiển thị đúng file Official và dùng file đó khi dựng hồ sơ.

- [x] Kiểm kê đầy đủ dữ liệu Kho AI pháp lý cần dùng trong module: thủ tục, yêu cầu, biểu mẫu, văn bản, cơ quan tiếp nhận, nguồn và trạng thái xác minh.
- [x] Nối toàn bộ bundle Kho AI pháp lý theo procedureCode vào module AI Hồ sơ đất đai tự động.
- [x] Dùng bundle đầy đủ cho phân tích, dựng hồ sơ và xác nhận trước khi xuất.

- [x] Dùng trực tiếp bundle Kho AI pháp lý hiện có trong module AI Hồ sơ đất đai tự động, không yêu cầu tạo lại nguồn.
- [x] Sửa lỗi module hiển thị fallback dù Kho AI pháp lý đã có file Official theo mã thủ tục.
- [x] Xác nhận file Official theo mã và toàn bộ nguồn pháp lý được đưa vào phân tích/dựng hồ sơ.

- [x] Sửa Land Dossier AI ưu tiên bundle Kho AI pháp lý từ database theo mã thủ tục/alias, không để snapshot DVC tạm thời che mất mẫu Official.
- [x] Hợp nhất bundle database với scan DVC theo nguyên tắc bundle persisted là nguồn chuẩn, giữ thêm attachment scan không trùng.
- [x] Bổ sung regression test cho alias 2912 → 2.000889 và hiển thị Mẫu 09/ĐK Official khi binary đã xác minh.
- [x] Chạy TypeScript, Vitest và preview sau khi sửa Official Mapping.
- [x] Lưu checkpoint phiên bản sửa Official Mapping và cập nhật trạng thái triển khai.

- [x] Sửa lỗi JSX thiếu/đóng sai thẻ trong AiLandDossierAutoModule khiến preview báo Expected corresponding JSX closing tag for <main>.
- [x] Chạy lại build, TypeScript, Vitest và preview sau khi sửa lỗi JSX.
- [x] Lưu checkpoint ổn định sau khi preview không còn màn hình lỗi.

- [x] Dùng pipeline Kho AI pháp lý để tìm mẫu theo mã thủ tục và thành phần hồ sơ.
- [x] Bảo đảm kết quả tìm mẫu được mapping về đúng bundle thủ tục và chỉ gắn Official khi binary/SHA-256 hợp lệ.
- [x] Kiểm thử luồng tìm mẫu Official, build và preview trước khi phát hành.

- [x] Điều tra vì sao mẫu Official đã có trong Kho AI pháp lý chưa được ghép vào bundle mã 2.000889/2912.
- [x] Sửa mapping template theo mã tương đương và tên thành phần hồ sơ, không hạ cấp Official hợp lệ.
- [x] Xử lý trạng thái “Đang tải” kéo dài sau khi bundle đã tải xong và bổ sung test hồi quy.

- [x] Rà soát vì sao mẫu Official đã lưu trong Kho AI pháp lý chưa được gắn vào mã chuẩn 2.000889/2912.
- [x] Đồng bộ lại template theo procedureId/mã ngoài, bảo toàn provenance, storageKey, fileUrl và SHA-256.
- [x] Bổ sung test chống mất mẫu khi module truy vấn bằng mã 2912 hoặc mã registry 2.000889.

- [x] Sửa lỗi backend `workflow` bị khai báo trùng tại server/routers.ts và chạy lại kiểm tra biên dịch.

- [x] Áp dụng cùng pipeline Kho AI pháp lý cho module hồ sơ: tìm theo mã/thành phần, tải binary, kiểm SHA-256 và cập nhật đúng mã.
- [x] Bảo toàn Official hợp lệ; giữ Reference/Pending nếu chưa đủ binary hoặc checksum.
- [x] Bổ sung kiểm thử và xác minh preview sau khi đồng bộ pipeline.

- [x] Cập nhật regression test LandDossierBuilder từ query slug `procedureId` sang query mã thủ tục chuẩn từ registry.


## Tiếp tục — Materialize Official trong Kho AI pháp lý

- [x] Materialize các binary Official đã allowlist từ registry vào S3 và bảng legal_templates.
- [x] Đối chiếu SHA-256 trước khi gắn provenance Official; từ chối binary sai checksum hoặc sai định dạng.
- [x] Bảo đảm alias 2912 được quy về mã registry 2.000889 trong pipeline materialize và bundle.
- [x] Sửa trạng thái Loading treo sau khi bundle đã được fetch và đồng bộ cache frontend.
- [x] Bổ sung regression tests cho materialize, checksum, alias 2912 và trạng thái bundle.
- [x] Chạy TypeScript, build production, toàn bộ Vitest và kiểm tra preview module hồ sơ đất đai AI.


## Yêu cầu mới — Đồng bộ toàn bộ thủ tục mẫu

- [x] Kiểm tra toàn bộ catalog thủ tục và thống kê Official/Reference/Pending/Error theo mã canonical và alias.
- [x] Chạy pipeline đồng bộ toàn bộ thủ tục: nguồn pháp lý → template binary → SHA-256 → S3/database → bundle.
- [x] Sửa mọi chênh lệch giữa số Official trong kiểm toán với file Xem/DOCX/PDF/ZIP và preview.
- [x] Bảo toàn các mẫu chưa đủ binary dưới trạng thái Reference/Pending, không gắn Official giả.
- [x] Chạy Vitest, TypeScript, build và kiểm tra module hồ sơ đất đai AI sau đồng bộ toàn bộ. Vitest 320/320 và TypeScript đạt; production build đã có ở checkpoint trước, lần rerun bị sandbox giới hạn tài nguyên.
- [x] Lưu báo cáo kết quả và checkpoint phiên bản hoàn thiện.


## Lỗi mới — Giữ đúng thủ tục sau khi chọn tỉnh

- [x] Khi đổi sang mã thủ tục khác rồi chọn tỉnh, không được quay về tiêu đề/trạng thái của Đăng ký đất đai AI rà soát thủ tục.
- [x] Bảo toàn procedureCode, tên thủ tục, tỉnh và bước workflow sau các thao tác chọn thủ tục/chọn tỉnh.
- [x] Bổ sung regression test cho luồng đổi mã → chọn tỉnh → nạp bundle và kiểm tra tiêu đề/đầu vào.
- [x] Chạy TypeScript, Vitest, kiểm tra preview và lưu checkpoint bản sửa.


## Lỗi mới — Bước tiếp theo AI không chuyển sang phân tích

- [x] Đồng bộ gợi ý Bước tiếp theo với procedureCode và bundle hiện tại.
- [x] Khi bundle hợp lệ đã nạp, cho phép nút gợi ý chuyển đúng sang bước phân tích.
- [x] Khi bundle chưa đủ, hiển thị hành động đồng bộ rõ ràng thay vì trạng thái đứng yên.
- [x] Bổ sung regression test cho chuyển bước từ gợi ý AI sang phân tích.
- [x] Chạy TypeScript, Vitest, preview và lưu checkpoint bản sửa.


## Yêu cầu mới — Nạp nguồn và chạy thử mẫu theo pipeline chuẩn

- [x] Đối chiếu đường chạy mẫu đã thành công của Đăng ký biến động đất đai với đường chạy hiện tại.
- [x] Bảo đảm nút nạp nguồn gọi đúng bundle theo mã và tỉnh đang chọn.
- [x] Chạy thử mẫu Official/Reference theo cùng các bước phân tích, xem trước và xuất file.
- [x] Hiển thị rõ kết quả từng mẫu: Official có checksum, Reference/Pending hoặc lỗi.
- [x] Bổ sung regression test cho nạp nguồn → chạy mẫu → phân tích → export.
- [x] Chạy TypeScript, Vitest, preview và lưu checkpoint bản hoàn thiện. TypeScript và Vitest 321/321 đạt; cần chạy đồng bộ live catalog để hoàn tất xác nhận dữ liệu.


## Mở rộng phạm vi — Tất cả các mục trong catalog

- [x] Kiểm kê toàn bộ mã thủ tục, tên, alias và trạng thái bundle hiện tại.
- [x] Chạy cùng một pipeline nạp nguồn, materialize binary và kiểm SHA-256 cho tất cả mã.
- [x] Liên kết từng mã với module hồ sơ: chọn thủ tục, tỉnh, nhập/tải giấy tờ, phân tích, preview và export.
- [x] Không giới hạn luồng vào 11 mẫu; giữ Pending/Reference minh bạch khi nguồn hoặc binary chưa đủ.
- [x] Kiểm thử toàn bộ catalog và tạo báo cáo kết quả theo từng mã.
- [x] Sửa nút Tiếp tục của module Hồ sơ đất đai AI để tự gọi nạp bundle đúng mã thủ tục, chờ hoàn tất rồi chuyển sang bước phân tích.
- [x] Đồng bộ lại query/cache bundle và bộ đếm Official/Reference/Pending sau khi nạp hoặc materialize.
- [x] Bổ sung regression test cho chuyển bước tự động và kiểm tra catalog ngoài 11 thủ tục.
- [x] Kiểm tra end-to-end preview và xác nhận build/test sau bản sửa.

## Lỗi mới — Bundle chuẩn vẫn fallback sau khi chọn thủ tục/tỉnh

- [x] Đối chiếu mã 2.002317, procedure bundle và Official status giữa backend với UI.
- [x] Sửa fallback để bundle persisted/materialized được dùng trước khi hiển thị trạng thái chưa nạp.
- [x] Đồng bộ bộ đếm Official và trạng thái nguồn theo đúng mã thủ tục, không dùng snapshot sai mã.
- [x] Bổ sung regression test cho lựa chọn mã 2.002317 tại Đà Nẵng và bundle đã materialize.
- [x] Kiểm tra preview mobile, chạy toàn bộ test và lưu checkpoint bản sửa.

## Lỗi mới — Module hồ sơ đất đai tải chậm và fallback kéo dài

- [x] Phân tích log runtime và xác định truy vấn/nguồn gây loading kéo dài.
- [x] Tối ưu thứ tự nạp bundle, Official status, mẫu tỉnh và cơ quan tiếp nhận; tránh truy vấn nặng chặn toàn bộ giao diện.
- [x] Hiển thị lỗi/timeout rõ ràng và cho phép bundle chuẩn hoàn tất độc lập với truy vấn phụ.
- [x] Bổ sung regression test chống trạng thái loading/fallback kéo dài.
- [x] Kiểm tra preview mobile, chạy toàn bộ test và lưu checkpoint bản tối ưu.

## Yêu cầu mới — Tách nạp bundle chuẩn khỏi nguồn phụ

- [x] Xác định query nguồn phụ đang làm chậm hoặc giữ trạng thái bundle.
- [x] Cho bundle chuẩn đọc dữ liệu persisted trước, không chờ quét DVC/tỉnh/cơ quan.
- [x] Thêm timeout và trạng thái lỗi riêng cho materialize nguồn ngoài.
- [x] Bổ sung test loading/fallback và kiểm tra preview mobile.

## Lỗi mới — Mã 1.012789 có metadata nhưng thiếu binary Official trên UI

- [x] Đối chiếu catalog, bundle và materialized templates của mã 1.012789.
- [x] Xác nhận bundle mã 1.012789 không có binary Official; giữ đúng trạng thái metadata_only/Reference, không gắn Official giả.
- [x] Bổ sung và xác nhận regression contract phân biệt Official binary với metadata/Reference.
- [x] Kiểm tra lại preview sau đăng nhập; xác nhận production hiển thị đúng 1 metadata và 0 binary Official.

## Lỗi mới — Đổi thủ tục nhưng bundle giữ tên cũ

- [x] Khi chọn Trích đo địa chính, reset bundle/title/status của thủ tục trước.
- [x] Nạp lại bundle theo mã thủ tục mới sau khi chọn tỉnh/thành.
- [x] Bổ sung regression test chống giữ bundle Đăng ký biến động đất đai.
- [x] Kiểm tra preview mobile và phát hành bản sửa.

## Lỗi mới — Bundle production vẫn trả rỗng sau khi đổi thủ tục

- [x] Đối chiếu mã thủ tục hiện tại với response bundle production và registry.
- [x] Sửa điều kiện query/hợp nhất để bundle đúng mã không bị rỗng hoặc dùng dữ liệu cũ.
- [x] Kết thúc spinner cơ quan tiếp nhận khi nguồn ngoài chậm, lỗi hoặc không có dữ liệu.
- [x] Bổ sung regression test, kiểm tra preview và phát hành bản sửa.

## Lỗi mới — Nhập thủ tục chậm và bundle chưa nạp

- [x] Đối chiếu log request catalog, bundle, Official và nguồn phụ khi nhập/chọn thủ tục.
- [x] Tối ưu tìm kiếm/chọn thủ tục để không gọi bundle liên tục trong lúc gõ.
- [x] Bảo đảm bundle chỉ nạp sau khi mã thủ tục ổn định và đúng canonical code.
- [x] Bổ sung regression test chống gọi lặp, kiểm tra preview và phát hành bản sửa.

## Tính năng mới — Bảng tiến độ bundle pháp lý

- [x] Rà soát state và response hiện có để suy ra các trạng thái tải nguồn, kiểm SHA-256, metadata-only và Official binary verified.
- [x] Hiển thị bảng tiến độ chi tiết trong module hồ sơ đất đai AI, gồm trạng thái đang chạy, hoàn tất, cảnh báo và lỗi/timeout.
- [x] Bổ sung regression test cho các trạng thái tiến độ và phát hành phiên bản mới.

## Tích hợp vào module Hồ sơ đất đai AI tự động

- [x] Đặt bảng tiến độ ngay trong khu vực Bộ nguồn tự động của module Hồ sơ đất đai AI tự động.
- [x] Bám trạng thái theo mã thủ tục hiện tại và làm rõ Official binary verified với metadata-only.
- [x] Kiểm thử đổi thủ tục, loading, timeout, lỗi và trạng thái hoàn tất trước khi phát hành.

## Lỗi mới — Bundle chưa nạp được

- [x] Đối chiếu log bundle với lỗi xác thực, timeout, response rỗng và mã thủ tục đang chọn.
- [x] Sửa điều kiện nạp hoặc thông báo nếu bundle metadata-only đang bị hiểu nhầm là chưa nạp.
- [x] Bổ sung test lỗi bundle, timeout và đổi mã thủ tục; kiểm tra rồi phát hành.

## Lỗi mới — Không thấy nút nạp nguồn

- [x] Kiểm tra route và điều kiện render của nút “Nạp nguồn vào hồ sơ”.
- [x] Bảo đảm nút hiển thị rõ trong module Hồ sơ đất đai AI tự động sau khi chọn thủ tục.
- [x] Kiểm thử nút trên preview, cập nhật TODO và phát hành bản sửa.

## Điều chỉnh luồng — Tự động nạp nguồn trong Hồ sơ đất đai AI tự động

- [x] Tự động nạp bundle nền ngay sau khi thủ tục và tỉnh đã ổn định.
- [x] Không bắt người dùng bấm “Nạp nguồn vào hồ sơ” trước khi nhập/chụp/tải thông tin.
- [x] Cho phép nhập thông tin và tải giấy tờ trong khi bundle đang xử lý, đồng thời giữ bảng tiến độ rõ ràng.
- [x] Bảo đảm AI chỉ phân tích và dựng hồ sơ sau khi nguồn pháp lý đã sẵn sàng; bổ sung test và phát hành.

## Khái quát pipeline toàn catalog — theo yêu cầu người dùng

- [x] Đối chiếu pipeline thành công của mã 2.000889 với luồng xử lý các mã khác.
- [x] Loại bỏ mọi fallback cứng về Đăng ký biến động đất đai trong module tự động.
- [x] Dùng chung pipeline nguồn → bundle → SHA-256 → phân loại → phân tích, nhưng giữ dữ liệu riêng từng mã.
- [x] Kiểm thử thủ tục đại diện ngoài 2.000889 và phát hành nếu đạt.

## Sửa đúng module — AI Hồ sơ đất đai Nộp cho cơ quan

- [x] Xác định route và component thực tế của mục Nộp cho cơ quan.
- [x] Đưa auto-load bộ nguồn theo thủ tục/tỉnh vào đúng module Nộp cho cơ quan.
- [x] Bảo đảm quy trình nhập/chụp/tải thông tin không bị chặn khi bundle đang nạp.
- [x] Kiểm thử route Nộp cho cơ quan và không làm thay đổi module AI Hồ sơ đất đai tự động.
- [x] Kiểm tra preview, cập nhật trạng thái TODO và phát hành đúng module.

## Đồng bộ toàn bộ mục — AI Hồ sơ đất đai Nộp cho cơ quan

- [x] Rà soát route và các component thuộc mục Nộp cho cơ quan.
- [x] Đối chiếu danh mục thủ tục, tỉnh/thành, trường nhập, OCR và tải giấy tờ.
- [x] Đồng bộ bộ nguồn pháp lý theo đúng mã thủ tục trong luồng Nộp cho cơ quan.
- [x] Kiểm tra AI phân tích, dựng hồ sơ, xem lại và xuất/nộp.
- [x] Bổ sung regression test, kiểm tra preview và phát hành bản đồng bộ.

## Lỗi ưu tiên cao — Bộ nguồn pháp lý chập chờn

- [x] Đối chiếu log các lần bundle có dữ liệu với lần trả rỗng, 401, 503 hoặc timeout.
- [x] Kiểm tra cache/in-flight/retry và key theo mã thủ tục + tỉnh.
- [x] Giữ bundle hợp lệ gần nhất khi request phụ thất bại, không hiển thị mất nguồn giả.
- [x] Bổ sung test ổn định bundle khi đổi thủ tục, đổi tỉnh và gặp lỗi nguồn ngoài.
- [x] Kiểm tra preview và phát hành bản ổn định.

## Ưu tiên ổn định bundle

- [x] Xác định nguyên nhân bundle lúc nạp được lúc không trong mục Nộp cho cơ quan.
- [x] Sửa nạp bundle theo đúng mã thủ tục và tỉnh, có fallback dữ liệu hợp lệ khi request phụ lỗi.
- [x] Chỉ xác nhận bundle sẵn sàng khi response khớp mã; bổ sung test và phát hành sau khi kiểm tra preview.

## Kiểm tra nguồn cũ ảnh hưởng bundle

- [x] Phân loại nguồn đang dùng, nguồn cũ, metadata-only, Reference và Official binary.
- [x] Kiểm tra bộ lọc theo mã canonical, tỉnh, phiên bản và trạng thái xác minh.
- [x] Bảo đảm bundle không trộn nguồn cũ hoặc nguồn khác mã; bổ sung test và kiểm tra preview.

## Kiểm tra cập nhật tự động và bundle chập chờn

- [x] Kiểm tra bộ nguồn có tự động cập nhật đầy đủ theo mã thủ tục và tỉnh hay không.
- [x] Đối chiếu các lần bundle nạp thành công với lần trả rỗng/lỗi.
- [x] Sửa cơ chế giữ bundle hợp lệ, không để request phụ làm mất dữ liệu.
- [x] Bổ sung test ổn định và kiểm tra preview trước khi phát hành.

## Lỗi hiển thị theo ảnh — Bundle metadata và Official binary

- [x] Hiển thị đúng trạng thái khi bundle có thành phần và metadata nhưng có 0 Official binary.
- [x] Tách trạng thái metadata-loaded khỏi request-error/timeout; không gọi là bundle chưa nạp nếu response đã khớp mã.
- [x] Kết thúc spinner cơ quan tiếp nhận khi query rỗng hoặc lỗi.
- [x] Bổ sung regression test theo trường hợp Trích đo địa chính: 4 thành phần, 1 metadata, 0 binary.
- [x] Kiểm tra preview và phát hành bản sửa.

## Bộ nguồn chuẩn nội bộ cho AI Lập hồ sơ nộp cơ quan
- [x] Liên kết bundle nội bộ trực tiếp với Kho AI pháp lý theo mã thủ tục và tỉnh.
- [x] Không yêu cầu người dùng nạp nguồn thủ công trong quy trình chính.
- [x] Hiển thị provenance và trạng thái Official/Reference/Metadata rõ ràng.
- [x] Dùng bundle chuẩn cho phân tích, dựng hồ sơ và xuất/nộp; bổ sung test và kiểm tra preview.

## Bổ sung từ lỗi đồng bộ bundle
- [x] Khi bundle chưa trả dữ liệu đúng mã, hiển thị trạng thái đồng bộ đang chờ có giới hạn thời gian và hướng dẫn rõ ràng.
- [x] Không để lỗi đồng bộ bundle làm người dùng hiểu rằng phải tự nạp nguồn; bundle phải tự lấy từ Kho AI pháp lý.
- [x] Kiểm tra lại trạng thái sau khi đồng bộ thành công mẫu Đăng ký đất đai và bảo đảm không suy diễn Official cho mã khác.

## Yêu cầu nguồn luôn sẵn sàng
- [x] Kiểm kê bundle đã lưu trong Kho AI pháp lý theo mã thủ tục và tỉnh, tách khỏi kết quả discovery tạm thời.
- [x] Thiết kế/hoàn thiện cơ chế đồng bộ nền để dữ liệu chuẩn được lưu trước khi người dùng lập hồ sơ.
- [x] Kết nối module hồ sơ vào bundle đã lưu và chỉ hiển thị trạng thái sẵn sàng/cập nhật nền, không yêu cầu nạp thủ công.
- [x] Bổ sung test và kiểm tra preview cho trường hợp bundle đã có sẵn dữ liệu.

## Bộ nguồn chuẩn dùng chung từ toàn bộ quy trình Kho AI pháp lý
- [x] Kiểm kê toàn bộ mã registry và trạng thái procedure/requirements/templates/binary đã lưu.
- [x] Materialize bundle chuẩn dùng chung theo catalog, lưu bền vững và không phụ thuộc thao tác người dùng.
- [x] Kết nối các module hồ sơ vào bundle chuẩn theo mã thủ tục + tỉnh, không nạp riêng từng module.
- [x] Bổ sung regression cho mã đã thành công và mã thiếu bundle, đồng thời kiểm tra Official chỉ sau SHA-256.

## Xác nhận triển khai đồng bộ nền hằng ngày
- [x] Kích hoạt lịch đồng bộ toàn bộ catalog hằng ngày vào ban đêm.
- [x] Bảo đảm retry/xử lý riêng mã lỗi không làm dừng các mã khác.
- [x] Ghi nhận lần chạy và trạng thái bundle để các module đọc dữ liệu đã lưu.

## Lỗi bundle chưa nạp được — cần xác minh thực tế
- [x] Kiểm tra lịch đồng bộ đã được kích hoạt và endpoint production có nhận chạy hay chưa.
- [x] Kiểm tra bundle đã lưu có khớp mã thủ tục/tỉnh đang chọn hay chỉ có kết quả discovery tạm thời.
- [x] Sửa lỗi còn lại khiến giao diện không đọc được bundle đã lưu; bổ sung test và báo cáo trạng thái chính xác.

## Regression từ ảnh thực tế — bundle metadata-only
- [x] Sửa badge để 4 thành phần + 1 metadata + 0 binary hiển thị Metadata đã nạp, không hiển thị Bundle chưa nạp.
- [x] Thêm regression test đúng dữ liệu Trích đo địa chính và kiểm tra lại preview mobile.

## Regression: mọi thủ tục phải chạy cùng pipeline
- [x] Đối chiếu điều kiện hoàn tất hồ sơ giữa Đăng ký biến động và các mã metadata-only.
- [x] Cho phép tạo bản nháp hồ sơ với metadata/reference khi chưa có Official binary, không chặn toàn bộ luồng.
- [x] Bảo đảm mã thủ tục và bundle luôn khớp, không dùng dữ liệu cũ của Đăng ký biến động cho mã khác.
- [x] Bổ sung test và kiểm tra lại thao tác chọn thủ tục → tỉnh → nhập dữ liệu → phân tích.

## Độ phủ bundle theo từng mã
- [x] Kiểm kê số mã catalog có bundle lưu bền vững và số mã mới chỉ có metadata/discovery.
- [x] Chạy/đối soát pipeline materialize cho toàn bộ mã còn thiếu; mỗi mã được xử lý và ghi nhận bundle độc lập, còn mã upstream 403/thiếu binary giữ Pending hoặc Reference theo guard Official.
- [x] Bảo đảm không dùng bundle Đăng ký đất đai làm fallback dữ liệu cho mã khác.
- [x] Báo cáo rõ mã nào Official, mã nào Metadata/Reference và mã nào còn Pending sau lần chạy.

## Catalog bị giới hạn ở 13 mã
- [x] Hợp nhất registry lõi với toàn bộ legalProcedures trong database và alias canonical.
- [x] Sửa scheduled sync không bỏ qua các mã catalog ngoài registry 13 mã.
- [x] Xác minh số mã canonical thực tế sau khi hợp nhất, không gọi chung 66/72/74 nếu chưa có số liệu cùng một thời điểm.

## Kết quả kiểm kê catalog hiện hành
- [x] Xác nhận database hiện có 13 legal procedures, 8 legal documents, 8 legal templates, 0 requirements và 0 procedure versions.
- [x] Phân biệt các số 66/72/74 là số liệu lịch sử hoặc thống kê khác, chưa phải catalog hiện hành trong database.
- [x] Chỉ bổ sung các mã còn thiếu sau khi có catalog chính thức và tên/mã được xác minh.

## Kiểm kê sau đồng bộ Kho AI pháp lý
- [x] Kiểm tra lần đồng bộ gần nhất và số mã thủ tục hiện có.
- [x] Đếm mẫu, thành phần hồ sơ và binary Official theo từng mã.
- [x] Báo cáo số thực tế, phân biệt mã sẵn sàng với mã còn thiếu dữ liệu.

## Chênh lệch Kho AI pháp lý và production
- [x] Đối chiếu số thủ tục hiển thị 66 với số procedure/bundle thực tế trong database production.
- [x] Xác định dữ liệu bị mất ở bước catalog, requirements, templates, documents hoặc liên kết module.
- [x] Sửa đồng bộ và báo cáo rõ số mã thực sự sẵn sàng cho sản xuất.
- [x] Production pipeline: mỗi mã phải quét nguồn Nhà nước, tải binary gốc, kiểm SHA-256 và chỉ gắn Official binary verified khi xác minh thành công
- [x] Production status: không hiển thị 0 Pending khi mã thiếu snapshot hoặc Failed to fetch; tổng kết phải khớp từng mã
- [x] Materialize production requirements/workflow từ snapshot để module Hồ sơ đất đai AI dùng được toàn catalog
- [x] Chờ một lần Heartbeat production chạy hoàn chỉnh để xác nhận độ phủ thực tế của toàn bộ catalog và số binary Official
- [x] Đối soát tên chính thức theo từng mã thủ tục từ nguồn Nhà nước trước khi hiển thị trong bộ chọn
- [x] Không dùng placeholder như tên hoàn chỉnh; hiển thị trạng thái đang đối soát khi chưa có tên xác minh
- [x] Liên kết tên chính thức đã xác minh với mã canonical và bundle của module Hồ sơ đất đai AI
- [x] Sửa lỗi OAuth callback failed trên production và bảo đảm redirect quay về module Hồ sơ đất đai AI mới
- [x] Thêm regression cho callback lỗi và đường redirect sau đăng nhập
- [x] Xác minh đăng nhập production thành công sau khi OAuth upstream hết lỗi 503 SEPARATION_FREEZE_ACTIVE; phiên admin đã vào dashboard và mở được module sản xuất.
- [x] Đối soát và nối tên chính thức cho ca thử nghiệm các mã 1.012775–1.012779 từ Cổng Dịch vụ công Quốc gia
- [x] Nối và kiểm thử tên chính thức các mã 1.012780–1.012783 vào catalog/bộ chọn
- [x] Sửa Heartbeat auth để nhận session qua x-manus-user-session và thêm regression 7/7
- [x] Bổ sung route Heartbeat canonical và trailing slash, regression route/auth/pipeline đạt 8/8
- [x] Xác minh lại OAuth production sau khi dịch vụ upstream hết gián đoạn; phiên admin production đã xác thực và truy cập được dashboard, không chạy đồng bộ thủ công trong lần kiểm thử.
- [x] Kiểm tra mobile module Hồ sơ đất đai AI: trạng thái loading/auth gate không lộ dữ liệu sai khi chưa đăng nhập

- [x] Tự động gắn bundle Kho AI pháp lý ngay khi chọn mã thủ tục, không yêu cầu người dùng bấm Nạp nguồn.
- [x] Hiển thị rõ các mã thủ tục đang cần đối soát tên trong bộ chọn và vẫn cho phép chọn theo mã.
- [x] Bảo đảm AI phân tích dùng components từ bundle chuẩn đã nạp, không quay về danh sách mặc định.
- [x] Viết regression cho trạng thái metadata-only, Official binary verified và catalog có mã cần đối soát.
- [x] Kiểm tra giao diện module, TypeScript và toàn bộ test sau stabilization.
- [x] Xác minh một vòng Heartbeat production hoàn chỉnh sau khi upstream OAuth hoạt động trở lại.
- [x] Thêm health probe tối giản cho Heartbeat để xác minh production routing độc lập với pipeline đồng bộ.

- [x] Cho phép khách hàng xem trang chủ, danh mục và chi tiết công khai mà không cần đăng nhập.
- [x] Tạo luồng đăng nhập quản trị riêng bằng tên đăng nhập và mật khẩu an toàn.
- [x] Thêm đăng xuất quản trị và hiển thị trạng thái phiên quản trị.
- [x] Giới hạn tạo/sửa/xóa nguồn hàng và cập nhật hồ sơ đất đai cho admin בלבד.
- [x] Bảo đảm route public không rò rỉ dữ liệu quản trị hoặc yêu cầu đăng nhập ngoài ý muốn.
- [x] Bổ sung test auth, phân quyền, public access và logout; kiểm tra responsive rồi phát hành.

- [x] Khắc phục phạm vi Run Now: lịch đồng bộ pháp lý dùng Heartbeat cron-only, không mở nút chạy thủ công công khai; handler có guard chống chạy trùng và chốt trạng thái completed/failed.
- [x] Kiểm tra lịch Heartbeat production sau khi sửa và xác nhận callback chạy đúng đường dẫn.

- [x] Thiết kế cơ chế đồng bộ pháp lý tự động 24/7 hoặc theo sự kiện, không phụ thuộc Run Now.
- [x] Bảo đảm cơ chế mới không tạo lịch trùng, không chạy chồng và vẫn giới hạn tài nguyên an toàn.

- [x] Kiểm tra và hoàn thiện luồng admin đăng nhập, đăng xuất và bảo vệ trang quản trị.
- [x] Thiết kế cổng kết nối AI/app với xác thực, phạm vi quyền và nhật ký thao tác rõ ràng; đã triển khai qua portal Manus giới hạn admin/chủ sở hữu và nhật ký yêu cầu.
- [x] Xác định ứng dụng AI hoặc API đích trước khi bật connector bên ngoài; chưa bật connector ngoài vì chưa có app/API cụ thể được người dùng chỉ định.
- [x] Viết regression cho login/logout, admin-only mutation và cổng kết nối bị từ chối khi thiếu quyền.

- [x] Chọn và áp dụng chu kỳ đồng bộ thường xuyên nhưng không khóa website.
- [x] Bổ sung luồng đổi mật khẩu admin an toàn, có kiểm tra mật khẩu hiện tại và mật khẩu mới.
- [x] Hiển thị trạng thái đăng nhập/đăng xuất admin rõ ràng trong khu vực quản trị.
- [x] Thiết kế cổng kết nối AI/Manus với xác thực và quyền tối thiểu; không đoán hoặc tự bật app bên ngoài khi chưa xác định app đích.
- [x] Viết regression cho đổi mật khẩu, session logout và quyền connector.
- [x] Chỉ cho chủ sở hữu hoặc admin dùng cổng kết nối Manus.
- [x] Yêu cầu sửa website phải chờ chủ sở hữu đồng ý, không tự động sửa hoặc phát hành.
- [x] Thêm nút kết nối Manus và lịch sử yêu cầu trong khu vực quản trị.
- [x] Viết regression bảo đảm khách không thể tạo hoặc phê duyệt yêu cầu thay đổi website.
- [x] Lưu yêu cầu, phê duyệt và kết quả chỉnh sửa website thành bản nháp/nhật ký riêng của admin.
- [x] Thêm trạng thái Kết nối, Đã ngắt kết nối và Kết nối lại Manus chỉ dành cho chủ sở hữu.
- [x] Bảo đảm ngắt kết nối không xóa bản nháp hoặc nhật ký đã lưu.
- [x] Chỉ cho phép phát hành thay đổi sau phê duyệt rõ ràng của chủ sở hữu.
- [x] Sau mỗi yêu cầu sửa/cài đặt/cập nhật, tạo bản ghi đồng bộ dữ liệu và trạng thái xác minh thành công/thất bại.
- [x] Chỉ cho phép ngắt kết nối Manus khi phiên thay đổi đã đồng bộ và kiểm tra thành công.
- [x] Khi kết nối lại, hiển thị lịch sử/bản nháp gần nhất để tiếp tục, không tạo lại dữ liệu.
- [x] Sửa menu công khai: thêm nút Đăng nhập quản trị riêng, giữ nút đăng nhập email/OAuth riêng và dẫn đúng tới /dang-nhap-quan-tri.
- [x] Bổ sung/kiểm tra điểm vào portal Manus trong khu vực admin để tiếp tục phần sản xuất sau khi đăng nhập.
- [x] Xác minh luồng admin kết nối Manus, đồng bộ, phê duyệt và tiếp tục yêu cầu còn dang dở.
- [x] Hoàn thiện phần sản xuất còn thiếu trong khu vực quản trị trước khi admin đăng nhập kiểm tra.
- [x] Kiểm tra phần sản xuất không làm lộ dữ liệu quản trị trên website công khai.
- [x] Sau khi admin đăng nhập, mở bảng quản trị đầy đủ với toàn bộ module/quản lý nguồn hàng thay vì vào thẳng phần sản xuất.
- [x] Xác nhận trang chủ, danh mục, sản phẩm và trang chi tiết vẫn công khai cho khách hàng không cần đăng nhập.
- [x] Thêm mục Sản xuất AI vào menu quản trị tổng để admin tự chọn sau khi đăng nhập, không điều hướng mặc định vào module này.
- [x] Sau khi phát hành bản quản trị tổng, tiếp tục hoàn thiện và xác minh end-to-end phần production hồ sơ đất đai AI.
- [x] Báo cáo rõ phạm vi production đã sẵn sàng và các mã pháp lý còn Official/Pending trước lần phát hành tiếp theo.
- [x] Đối chiếu chính xác tên và module của mã 2.000889 từ catalog production/Kho AI pháp lý.
- [x] Phân biệt các module sản xuất và chọn Hồ sơ đất đai AI tự động làm module ưu tiên để kiểm thử trước.
- [x] Xác minh và xử lý trạng thái phát hành bị treo ở “Đang xuất bản…” mà không ảnh hưởng bản live ổn định; checkpoint `467a98fe` đã lưu và phát hành thành công, route production tải được.
- [x] Chạy thử end-to-end mã 2.000889 trong module Hồ sơ đất đai AI tự động, xác minh chọn thủ tục gắn đúng registry nguồn DVC và xử lý cảnh báo chưa có mã.
- [x] Chuẩn hóa mã canonical 2.000889, mã UI và alias external 2912 trước khi tra cứu nguồn DVC; regression registry đạt 34/34.
- [x] Điều tra lỗi “Failed to fetch” khi sinh kế hoạch riêng cho mã 2.000889 và tỉnh Đà Nẵng.
- [x] Kiểm tra sự nhất quán giữa bộ chọn thủ tục, registry DVC và bundle Kho AI pháp lý.
- [x] Sửa luồng API/UI để sinh kế hoạch địa phương không rơi vào lỗi fetch không có thông tin.
- [x] Bổ sung kiểm thử hồi quy cho ca 2.000889 + Đà Nẵng và trạng thái Official bundle.
- [x] Xác minh lại trên preview và cập nhật checkpoint sau khi lỗi được xử lý.

- [x] Cho phép kéo nút Trò chuyện AI trên màn hình điện thoại.
- [x] Giới hạn vị trí nút trong viewport và không làm mất thao tác mở trợ lý.
- [x] Bổ sung kiểm thử cho trạng thái kéo thả và responsive của nút nổi.
- [x] Chụp preview và lưu checkpoint sau khi sửa nút Trò chuyện AI.

- [x] Bổ sung phần nhập thông tin hồ sơ rõ ràng sau khi chọn thủ tục và tỉnh/thành.
- [x] Hiển thị tải/chụp giấy tờ và OCR trong Bước 2 hoặc vị trí quy trình đã thống nhất.
- [x] Nối dữ liệu nhập/OCR vào bước AI phân tích và tạo bộ hồ sơ.
- [x] Bổ sung kiểm thử cho thứ tự Bước 1 → Bước 2 và giao diện mobile.
- [x] Chụp preview, lưu checkpoint và hướng dẫn chạy thử sau khi hoàn tất.
- [x] Thêm bảng tổng quan độ phủ Official/Reference/Pending theo catalog hiện hành để admin biết phạm vi production trước khi chạy end-to-end.
- [x] Mở rộng báo cáo độ phủ theo từng mã, trả về ready/pending và lý do thiếu binary, checksum hoặc xác minh Official.

- [x] Khắc phục lỗi `Service Unavailable`/JSON parse error khi discover theo mã thủ tục và tỉnh, bảo đảm workflow thoát trạng thái đang nạp nguồn và hiển thị lỗi có thể thử lại; đã dùng cache materialize và bỏ qua quét thay thế tuần tự khi DVC 503.

- [x] Khắc phục lỗi `Service Unavailable`/JSON parse error khi discover theo mã thủ tục và tỉnh bằng cache materialize và bỏ qua quét thay thế tuần tự khi DVC đã 503; TypeScript và 27/27 regression liên quan đạt.

- [x] Bổ sung cơ chế thử lại có chủ đích cho discover: không tự lặp sau lỗi 503, hiển thị thông báo lỗi và nút “Thử lại”; TypeScript và 26/26 regression liên quan đạt.

- [x] Sửa lỗi AI phân tích từ chối `dossierComponents[].name` dài hơn 240 ký tự; schema tự chuẩn hóa tên hiển thị tối đa 240 ký tự và giữ tên gốc trong `sourceName` cho ngữ cảnh pháp lý.

- [x] Chuẩn hóa thông báo lỗi validation khi AI phân tích thất bại, không hiển thị mảng JSON kỹ thuật dài trên giao diện mobile; bổ sung thông báo ngắn và hướng dẫn Thử lại.

- [x] Khắc phục lỗi frontend production `Cannot read properties of undefined (reading 'filter')` bằng fallback mảng an toàn và regression cho trạng thái dữ liệu chưa tải; TypeScript sạch, 67 file test với 362 test đạt.

- [x] Thu gọn các bảng/khối dài trong module thành từng mục mở rộng và thu lại khi người dùng bấm xem.
- [x] Thu gọn danh sách thủ tục trong vùng cuộn, có tìm kiếm gần đúng chịu được viết tắt, thiếu dấu và sai vài ký tự.
- [x] Tích hợp bộ chọn toàn bộ tỉnh/thành theo dạng cuộn/tìm kiếm/chạm chọn, phù hợp mobile.
- [x] Viết regression và kiểm tra responsive cho UX thu gọn, tìm thủ tục và chọn tỉnh/thành.

- [x] Thu gọn các khối Registry, Coverage, Sync Progress và các thẻ sidebar bằng Accordion, mặc định ưu tiên giảm chiều dài trên mobile.
- [x] Nâng cấp tìm kiếm thủ tục với bỏ dấu, từ viết tắt và sai khác nhỏ; bổ sung regression test.
- [x] Giới hạn danh sách thủ tục trong vùng cuộn cố định, giữ khả năng chọn trên mobile.
- [x] Thay ô tỉnh/thành bằng combobox tìm kiếm, cuộn và chọn từ 34 đơn vị hành chính hiện hành.
- [x] Kiểm tra preview desktop/mobile và xác minh endpoint production sau khi phát hành các thay đổi UX.

- [x] Dùng pipeline thành công của mã hiện tại làm chuẩn để chạy đồng bộ production cho toàn bộ catalog theo từng mã độc lập.
- [x] Đối soát kết quả toàn bộ catalog và chỉ gắn Official khi đủ binary, checksum và provenance xác minh.
- [x] Chạy regression và lưu checkpoint sau khi hoàn tất batch đồng bộ toàn catalog.

- [x] Điều tra và sửa lỗi người dùng không thể bấm chọn mã thủ tục trong module Hồ sơ đất đai AI sau bản phát hành mới; nguyên nhân là `.filter()` trên danh sách API undefined.
- [x] Bổ sung regression cho thao tác chọn mã thủ tục và xác minh lại trên preview desktop/mobile; contract chọn mã và fallback dữ liệu đạt, preview 390px/1280px render được.

- [x] Sửa lỗi runtime `Cannot read properties of undefined (reading 'filter')` trong module Hồ sơ đất đai AI trên production/mobile.
- [x] Bổ sung regression bảo đảm các danh sách thủ tục, bundle và trạng thái luôn fallback về mảng an toàn trước khi filter/map.
- [x] Xác minh lại thao tác chọn thủ tục sau khi sửa lỗi runtime; preview mobile không còn crash và danh sách module đã render.

- [x] Xử lý trạng thái phiên bản `c708cf86` đang được triển khai để không tạo checkpoint hoặc phát hành chồng lên phiên trước; checkpoint e997997a đã lưu thành công sau khi khóa được giải phóng.
- [x] Kiểm thử thay đổi chống 503 trong batch sau khi trạng thái triển khai được giải phóng; TypeScript sạch và 55/55 regression đạt.

- [x] Điều tra lỗi crash khi bấm Phân tích: nguyên nhân là callback/render chưa chuẩn hóa các mảng response khi dữ liệu thiếu hoặc sai hình dạng.
- [x] Gia cố toàn bộ response/trạng thái phân tích để không đọc `.filter`, `.map` hoặc thuộc tính trên undefined.
- [x] Bổ sung regression cho handler Phân tích và xác minh lại trên mobile production; TypeScript sạch, regression module đạt 23/23.

- [x] Bảo đảm Phân tích AI tổng hợp toàn bộ dữ liệu hồ sơ, trường OCR và tất cả tệp đã tải lên có liên quan.
- [x] Bảo đảm payload phân tích vẫn gắn đúng mã thủ tục, tỉnh/thành và nguồn Kho pháp lý AI làm nguồn chuẩn dựng hồ sơ.
- [x] Bổ sung regression cho trường hợp nhiều tệp và dữ liệu thiếu, không gọi `.filter()`/`.map()` trên undefined.

- [x] Cho phép khu vực upload tiếp nhận CCCD, hộ chiếu, giấy tờ nhà đất và mọi giấy tờ liên quan trong cùng một hồ sơ.
- [x] Gom toàn bộ kết quả OCR/trích xuất từ nhiều ảnh và tệp vào dữ liệu hồ sơ, không chỉ giữ một loại giấy tờ.
- [x] Hiển thị rõ tệp đã đọc, trường đã trích xuất và cho phép người dùng rà soát trước khi tạo hồ sơ.

- [x] Không cho phép bỏ qua bước chụp/tải ảnh và Phân tích rồi nhảy thẳng tới Bước 7 xuất hồ sơ.
- [x] Kiểm tra và chuẩn hóa `templateSource` trước khi gọi xuất DOCX/PDF; báo rõ khi nguồn mẫu không phải URL hợp lệ.
- [x] Bổ sung regression cho guard bước 7 và lỗi `templateSource: Invalid URL`.
- [x] Đặt khu vực chụp ảnh/tải ảnh và chạy OCR trực tiếp trong phần Điền thông tin để thao tác thuận tiện hơn.

- [x] Điều tra lỗi thực tế: sau khi chụp/tải ảnh, exportBundle vẫn nhận templateSource không hợp lệ.
- [x] Gia cố validation templateSource ở cả client và server, ưu tiên không gửi metadata URL hỏng.
- [x] Bổ sung regression mô phỏng luồng chụp ảnh rồi xuất DOCX/PDF với templateSource lỗi.

- [x] Điều tra trạng thái xuất bản bị kẹt với lỗi `SocketException: Failed host lookup api.manus.im`.
- [x] Xác nhận preview và checkpoint gần nhất vẫn an toàn, không tạo bản phát hành trùng khi dịch vụ khôi phục.

- [x] Điều tra trạng thái cửa sổ cập nhật bị treo ở `Đang xuất bản…` sau lần thử lại.
- [x] Xác định checkpoint đã phát hành và ngăn thao tác lặp tạo bản phát hành trùng.

- [x] Hiển thị trạng thái rõ ràng khi đang chụp, đọc tệp, tải ảnh lên và hoàn tất upload.
- [x] Thêm hiệu ứng tải và khóa thao tác lặp trong khu vực chụp/tải ảnh.
- [x] Bổ sung regression cho trạng thái upload và kiểm tra responsive trên mobile.

- [x] Đồng bộ trạng thái Official/Pending khi mẫu thiếu binary DOCX/PDF đã xác minh nhưng giao diện vẫn báo đủ điều kiện Official.
- [x] Bổ sung regression cho trường hợp trạng thái mẫu và thông báo export mâu thuẫn.
- [x] Phân loại từng thành phần theo binary và provenance riêng, không suy luận Official từ số liệu tổng hợp.
- [x] Hiển thị rõ mẫu nguồn tham khảo đang chờ kiểm tra là Reference/Draft.
- [x] Khóa điều kiện xuất Official nếu bất kỳ thành phần bắt buộc nào chưa có binary chính thức đã xác minh.
- [x] Bổ sung regression cho bundle có 21 mẫu Official nhưng còn thành phần Reference/Draft.

- [x] Bổ sung bản xem trước tổng hợp ngắn gọn các thành phần hồ sơ cần thực hiện.
- [x] Thêm nút xem mẫu Official đã xác minh hoặc thông báo rõ khi chỉ có Draft/Reference.
- [x] Thêm nút tải mẫu/bản xuất để người dùng đối chiếu trước khi nộp.
- [x] Bổ sung checklist kiểm tra hồ sơ trước khi nộp cơ quan và cảnh báo hồ sơ chưa phải văn bản cơ quan ban hành.

- [x] Rà soát catalog và registry để lập danh sách thủ tục đất đai đang thiếu tên hoặc tên không chuẩn.
- [x] Chuẩn hóa tên thủ tục theo mã và nguồn Nhà nước, giữ alias cũ để không làm hỏng dữ liệu đã lưu.
- [x] Thiết kế batch đồng bộ độc lập cho toàn bộ mã thủ tục đất đai.
- [x] Chạy/đối soát batch theo từng mã, phân loại Official/Reference/Pending đúng bằng chứng.
- [x] Bổ sung regression cho tên thủ tục và batch đồng bộ không trộn mã.

- [x] Xử lý toàn bộ mã thủ tục đất đai trong catalog, không dừng ở mã thí điểm hoặc mã đang chạy tốt.
- [x] Bảo đảm mỗi mã có tên canonical, bundle độc lập và kết quả Official/Reference/Pending riêng; trạng thái Official chỉ phụ thuộc binary đã xác minh, không phụ thuộc việc mọi mã đều có file Official.
- [x] Tổng hợp báo cáo độ phủ toàn bộ catalog sau khi pipeline hoàn tất.

- [x] Truy vết nguồn dữ liệu khiến thủ tục đã có tên canonical vẫn hiển thị “Cần đối soát tên”.
- [x] Đồng bộ fallback tên canonical từ registry vào mọi catalog/bundle dùng cho giao diện Sản xuất AI.
- [x] Bổ sung regression chống hiển thị placeholder khi mã đã có tên được xác minh.

- [x] Đưa các tên đã đối soát trong bảng phụ lục 2304 vào mapping canonical runtime, không chỉ lưu ở tệp audit.
- [x] Bổ sung regression phủ các mã 2304 đã có tên trong dữ liệu đối soát và bảo đảm không gắn Official binary tự động.

- [x] Hợp nhất danh sách catalog Sản xuất AI với toàn bộ mã phụ lục 2304/QĐ-BNNMT và tên canonical, không còn placeholder khi tìm theo mã/tên.
- [x] Bảo toàn trạng thái Official theo verified binary + SHA-256, đồng thời bổ sung contract test cho list/search catalog.
- [x] Chạy kiểm thử, kiểm tra TypeScript và xác minh production coverage sau bản vá.
- [x] Ngăn auto-discover theo mã đang chọn chạy song song với batch Đồng bộ ngay, tránh toast Failed to fetch gây hiểu nhầm và bảo đảm trạng thái tiến độ chỉ thuộc một luồng.
- [x] Sửa nút Xem bản Official bị dẫn tới Not found; chỉ cho mở URL binary lưu kho hợp lệ và hạ nhãn về Reference/Pending khi file không xác minh được.
- [x] Bổ sung regression cho liên kết xem/tải Official, kiểm tra 404 và bảo toàn guard export Draft/Official.
- [x] Đồng bộ guard trạng thái cảnh báo thiếu binary với nhãn Official và các nút Xem/Export trong module 2.000889.
- [x] Bổ sung regression bảo đảm không thể Xem/Xuất DOCX/PDF khi binary Official thiếu hoặc URL lưu kho trả Not Found.
- [x] Ngăn production cache HTML shell cũ làm giao diện Official tiếp tục chạy bundle trước bản vá; kiểm tra lại sau phát hành.
- [x] Chạy/đối soát pipeline materialize đủ 66 mã theo cùng pipeline chuẩn; mỗi mã được xử lý độc lập và ghi trạng thái riêng. Các mã upstream trả 403/thiếu binary vẫn giữ Pending/Reference, không gắn Official giả.
- [x] Kiểm tra lại lỗi Official Not found sau batch 66 mã; bốn bản ghi mã 2.000889 trả 403 nên đã hạ về Reference/Pending, xóa storageKey/fileUrl khỏi quyền Official và chỉ cho mở/xuất binary có checksum + storageKey hợp lệ.
- [x] Sửa batch sync để luôn chốt trạng thái completed/failed sau khi các request kết thúc, lưu kết quả từng mã và cho phép retry riêng mã lỗi sau Service Unavailable.
- [x] Cập nhật assertion regression legacy theo hàm syncNow có tham số retryCodes, không nới lỏng logic retry hoặc guard Official.
- [x] Kiểm thử end-to-end một thủ tục trong AI Sản xuất, ưu tiên mã 2.000889: chọn mã, nạp bundle, xem trước và kiểm tra điều kiện xem/xuất Official; người dùng đã xác nhận Official Original mở được và Filled Working Copy đã điền dữ liệu sau khi xuất DOCX.

- [x] Điều tra lỗi Not found khi mở hoặc xuất bản bản Official của thủ tục 2.000889 dù người dùng đã chọn đúng mã; đối chiếu storageKey, fileUrl và binary đã xác minh; chuyển storage proxy sang tải binary server-side để browser không nhận redirect lỗi.

- [x] Tránh route edge /manus-storage trả redirect 307 trong production bằng endpoint binary nội bộ riêng cho Official; cập nhật UI, regression và kiểm thử mã 2.000889; 387/387 Vitest và TypeScript sạch.

- [x] Đổi luồng xem bản Official sang endpoint /api/official-storage để tránh redirect 307 của route /manus-storage; cập nhật regression và kiểm thử lại mã 2.000889; 387/387 Vitest và TypeScript sạch.

- [x] Đồng bộ compatibility entrypoint `server/index.ts` với fullstack `server/_core/index.ts` để production không chạy static-only server và bỏ qua endpoint Official; 387/387 Vitest và TypeScript sạch.
- [x] Kiểm tra và xử lý trường hợp một ảnh/tệp bị hiển thị trùng trong thành phần hồ sơ khi OCR đang xử lý; bảo đảm trạng thái tiến độ và danh sách tệp không gây hiểu nhầm.
- [x] Tìm và xác minh độc lập nguồn binary DOCX/PDF Official cho thành phần Hợp đồng/văn bản chuyển nhượng 2.000889; DVC Quốc gia không cung cấp URL tải hợp đồng (ma=), nguồn Bộ Tư pháp chỉ là mẫu theo phạm vi dự án có hạ tầng, nên giữ `.doc` ở Reference-only và không thêm allowlist Official.
- [x] Tìm và xác minh độc lập nguồn binary DOCX/PDF Official cho thành phần Hợp đồng/văn bản chuyển nhượng 2.000889; DVC Quốc gia không cung cấp URL tải hợp đồng (ma=), nguồn Bộ Tư pháp chỉ là mẫu theo phạm vi dự án có hạ tầng, nên giữ `.doc` ở Reference-only và không thêm allowlist Official.
- [x] Tích hợp mẫu hợp đồng chuyển nhượng Bộ Tư pháp dạng Word legacy `.doc` vào bundle 2.000889 dưới trạng thái Reference-only; giữ rõ provenance và không cho vào nhánh Official/export.
- [x] Chọn mã 2.002317 làm thủ tục tiếp theo: xác minh ba binary DOCX theo checksum (hai mẫu độc lập, một bản Phiếu yêu cầu trùng checksum), kiểm thử engine với Mẫu 01/PYC và Mẫu 02, cả hai tạo Filled Working Copy thành công; giữ Official Original không ghi đè.
- [x] Ưu tiên luồng có thể sử dụng ngay: chỉ chạy thêm mã có binary Official/bundle kiểm chứng được; giữ các mã còn lại ở Reference hoặc Pending khi upstream chưa cung cấp file.

- [x] Gộp Đăng nhập email và Thông báo yêu cầu vào cùng cổng Đăng nhập quản trị viên; không hiển thị hai mục này rời trên trang khách hàng.
- [x] Đưa lối xem Thông báo yêu cầu vào khu vực quản trị sau đăng nhập, bảo toàn quyền truy cập admin.
- [x] Sửa nút menu mobile: đóng hiển thị hamburger, mở mới hiển thị X; trang chủ public giữ bố cục như ảnh tham chiếu số 2.
- [x] Kiểm thử menu public/admin trên mobile và desktop, cập nhật regression test, chạy Vitest và TypeScript.
- [x] Lưu checkpoint phiên bản sau khi hoàn tất thay đổi menu quản trị/public.

## Rà soát nguồn Official DVC Quốc gia/cấp tỉnh — 2026-08-24
- [x] Kiểm kê mã thủ tục còn thiếu binary Official và phân biệt rõ Official/Reference/Pending hiện tại.
- [x] Thiết kế và kiểm thử dò nguồn DVC Quốc gia/cấp tỉnh với retry/backoff, timeout và giới hạn tốc độ khi upstream trả 503.
- [x] Chỉ materialize từng binary có URL nguồn cơ quan, checksum và mapping đúng procedure/component; không dùng mẫu thủ tục khác làm fallback.
- [x] Bổ sung regression cho trạng thái 503, provenance, checksum và guard không gắn nhãn Official khi chưa xác minh.
- [x] Chạy test, rà soát todo và lưu checkpoint sau khi hoàn tất phần dò nguồn an toàn.

- [x] Triển khai hạ tầng lượt quét 66 mã theo hàng đợi: ưu tiên pipeline DVC hiện có, lưu trạng thái từng procedure/component và đặt retry; lượt chạy thực tế sẽ giữ Pending/Reference khi Quốc gia/tỉnh chưa trả binary xác minh.
- [x] Kiểm tra báo cáo sau lượt quét: số mã đã gắn Official, số mã Pending do 503, và các mã cần thử lại ở lượt sau.

## Blocker Lịch trình mobile — 2026-08-24
- [x] Kiểm tra và khắc phục trường hợp màn hình Lịch trình trên mobile chỉ hiển thị skeleton hoặc nút Làm mới không phản hồi; xác nhận lại lịch dự án và nút Run now. Đã xác định lỗi thuộc giao diện Manus bên ngoài dự án; lịch backend Active và đã chuyển sang Heartbeat HTTP 15 phút.

- [x] Xác định nguyên nhân nút hai mũi tên Làm mới ở Lịch trình mobile không phản hồi; cung cấp đường tải lại thay thế bằng reload trình duyệt/desktop mode và xác nhận lịch Active không bị mất. Đây là lỗi tải giao diện quản lý mobile, không ảnh hưởng scheduler.

- [x] Điều tra lỗi bảng điều khiển mobile: mục Lịch trình chỉ hiển thị skeleton/loading dù đã tải lại nhiều lần; xác nhận lịch backend vẫn Active và hướng dẫn phương án thay thế. Đã xác nhận lịch thật bằng cấu hình hệ thống và dùng Heartbeat HTTP làm nguồn thực thi.

- [x] Mở rộng fallback quét 66 thủ tục: giữ 503 ở trạng thái Pending/retry, thử nguồn Bộ Tài nguyên và Môi trường, cổng DVC tỉnh và nguồn cơ quan chính thức khác; chỉ gắn Official sau khi đúng mã, provenance và checksum.

- [x] Xác minh bằng kiểm thử rằng khi người dùng/cổng DVC trả 503, queue vẫn lưu Pending, lastHttpStatus=503, nextAttemptAt và tiếp tục thử nguồn chính thức dự phòng ở lượt sau.

- [x] Giữ DVC Quốc gia làm nguồn chuẩn của workflow; phân loại dữ liệu từ Bộ/tỉnh/cơ quan khác là bổ sung/discovery và chỉ tự tải lại khi nguồn chuẩn phục hồi, không thay thế workflow hoặc tự nâng Official.
- [x] Bảo đảm batch tiếp tục quét mã thủ tục kế tiếp khi một mã đang Pending do HTTP 503.

- [x] Tiếp tục chạy batch toàn bộ 66 mã: mã đến hạn được quét độc lập, lỗi 503 chỉ tạo Pending/retry và không dừng các mã còn lại.

- [x] Rà soát và chuẩn hóa các đường dẫn chia sẻ để khách hàng luôn mở trang bán hàng công khai, không dẫn tới /dang-nhap-quan-tri; xác nhận dấu X/ổ khóa/Made with Manus là lớp giao diện bên ngoài website. Nút Chia sẻ hồ sơ nay dùng URL /bat-dong-san hoặc /bat-dong-san/:slug public.

- [x] Đổi tiêu đề và metadata chia sẻ của trang công khai thành “Bất động sản xanh Miền Trung”, giữ khách hàng truy cập không cần đăng nhập.

- [x] Đổi tên chia sẻ public thành “Bất động sản xanh Đà Nẵng · Miền Trung · Toàn quốc” và giữ quyền xem không cần đăng nhập.

- [x] Gắn logo Bất động sản xanh làm favicon, biểu tượng app trên điện thoại và ảnh Open Graph khi chia sẻ liên kết công khai.

- [x] Khắc phục logo chưa hiện khi cài website thành app: tạo icon vuông chuyên dụng, cập nhật manifest/favicon/apple-touch-icon/Open Graph và kiểm tra lại trên public domain. Đã thay asset WebP bằng PNG thật 1920x1920, manifest khai báo 192x192 và 512x512.

- [x] Thêm nút “Cài đặt ứng dụng” nổi bật trên trang chủ; hỗ trợ lời mời cài PWA trên Android và hướng dẫn Thêm vào màn hình chính trên iPhone. Đã kiểm tra giao diện mobile, TypeScript sạch và Vitest 394/394.

- [x] Thêm mục “Cài đặt ứng dụng” vào menu hamburger trên trang chủ mobile, tái sử dụng luồng PWA Android/iPhone và kiểm tra menu responsive. Vitest 394/394, TypeScript sạch; mục cài đặt hiển thị nổi bật trong menu và dùng chung handleInstallClick.

- [x] Điều tra lỗi không cài được ứng dụng trên điện thoại: kiểm tra manifest, icon, service worker, đăng ký PWA và luồng mở link ngoài Messenger. Đã bổ sung `client/public/sw.js`, đăng ký service worker trong `client/src/main.tsx`, thêm `id` manifest và regression PWA; TypeScript sạch, Vitest 396/396. Cần mở link bằng Chrome/Safari ngoài Messenger sau khi phát hành.

- [x] Sửa lỗi nút “Cài đặt ứng dụng” có hiển thị nhưng không mở hộp thoại cài trên Android; bổ sung fallback hướng dẫn Chrome/Thêm vào màn hình chính và kiểm thử trạng thái beforeinstallprompt. Đã làm rõ modal: website chỉ mở hộp thoại khi Chrome cấp `beforeinstallprompt`; nếu không, người dùng phải dùng menu Chrome. TypeScript sạch, Vitest 396/396, mobile đã kiểm tra.

- [x] Đổi nút PWA trên trang công khai thành nút “Cài ngay”, ưu tiên mở hộp thoại cài native khi Chrome cung cấp beforeinstallprompt, tự nhận biết trạng thái đã cài và dùng fallback hướng dẫn khi trình duyệt không hỗ trợ. Bổ sung fallback khi prompt bị Chrome thu hồi; preview mobile hiển thị đúng; Vitest 397/397 và TypeScript sạch.

- [x] Xóa các điểm hiển thị nút “Cài ngay” khỏi trang bán hàng công khai và menu hamburger để thu gọn giao diện; giữ nguyên manifest, service worker và khả năng cài từ menu Chrome. Preview mobile không còn banner, menu vẫn gọn; Vitest 397/397 và TypeScript sạch.

- [x] Thiết kế hình mô phỏng kết quả tìm kiếm Google trên điện thoại theo ảnh tham khảo, dùng logo và nhận diện Bất động sản xanh; ghi rõ đây là mockup minh họa, không phải kết quả Google thật. Đã tạo và kiểm tra hình dọc 1440×2560.

- [x] Cập nhật mockup kết quả Google dùng tên miền ngắn có dấu gạch ngang `bat-dong-san-xanh.manus.space` theo yêu cầu thương hiệu.

- [x] Chỉnh trang web công khai thật để logo, tên thương hiệu, tiêu đề và mô tả hiển thị nhất quán theo mockup kết quả tìm kiếm; giữ nguyên trang bán hàng công khai và không yêu cầu khách hàng đăng nhập. Logo, tiêu đề, metadata SEO và khu vực AI public đã được kiểm tra; Vitest 397/397 đạt.

- [x] Bổ sung khu vực public “AI tìm hàng cho khách hàng” trên trang chủ, cho phép khách hàng nhập nhu cầu tìm bất động sản mà không cần đăng nhập. Nhãn desktop và modal đã cập nhật; regression public/PWA đạt 7/7.

- [x] Tạo khu vực tham khảo giống website bất động sản thật khi chưa có sản phẩm thực, dùng dữ liệu/ảnh mẫu có nhãn rõ “Mẫu tham khảo · Chưa phải nguồn hàng thực”, không tạo đánh giá hay lời chứng thực giả.

- [x] Đổi tên miền miễn phí từ `batdongsan-7bupubgw.manus.space` sang `bat-dong-san-xanh.manus.space` nếu tên còn khả dụng trong phần Domains; giữ nguyên dữ liệu, trang public và liên kết chia sẻ. Đã kiểm tra: tên mới chưa trỏ vào dự án và hiện hiện trang bảo trì; giữ domain cũ làm địa chỉ chính.

- [x] Dùng URL public hiện tại để hoàn thiện trang mẫu bất động sản có logo, tên thương hiệu, liên hệ 0989682825/Zalo, CTA AI tìm hàng và dữ liệu mẫu ghi rõ “Mẫu tham khảo”. Đã kiểm tra trên preview public.

- [x] Hoàn thiện phiên bản website vận hành thật trên URL hiện tại: storefront công khai, nhận yêu cầu khách hàng, AI tìm hàng, liên hệ Gọi/Zalo/Messenger; tạm hoãn quảng bá và lập chỉ mục Google. Vitest 397/397, TypeScript sạch, preview desktop/mobile đã kiểm tra.

- [x] Thêm nút “Chia sẻ website” ở header trang chủ, cạnh nút Gọi tư vấn và menu hamburger; dùng Web Share API trên thiết bị hỗ trợ và fallback sao chép liên kết trên desktop/trình duyệt không hỗ trợ. Mobile/desktop đã kiểm tra, TypeScript sạch, Vitest 397/397; nút chia sẻ URL trang đang mở và không tự đăng thay người dùng.

- [x] Hoàn thiện form nhận nhu cầu khách hàng và hiển thị thông báo cho quản trị viên.
- [x] Tinh chỉnh trang chủ public theo bố cục ảnh tham khảo, giữ logo, liên hệ, AI tìm hàng và nút chia sẻ.
- [x] Kiểm tra lại tên miền ngắn `bat-dong-san-xanh.manus.space`; không thay đổi domain chính vì tên chưa khả dụng.

- [x] Hoàn thiện payload form public để lưu đầy đủ loại BĐS, ngân sách, địa chỉ/khu vực và yêu cầu chi tiết cho quản trị.
- [x] Bảo đảm mọi submission tạo thông báo quản trị ngay sau khi lưu, độc lập với kết quả AI phân tích.
- [x] Hiển thị trạng thái gửi, chống gửi lặp và làm rõ thông tin tiếp nhận cho khách hàng.
- [x] Tinh chỉnh homepage theo hướng biophilic editorial, giữ branding Đà Nẵng · Miền Trung · Toàn quốc và responsive.
- [x] Kiểm tra domain ngắn bat-dong-san-xanh.manus.space: hiện hiển thị trang bảo trì; giữ domain đang hoạt động để không gián đoạn public storefront.
- [x] Bổ sung regression tests và kiểm tra Vitest/TypeScript/preview trước checkpoint.

- [x] Rút gọn header đầu trang để ít chiếm chiều cao hơn trên desktop và mobile.
- [x] Đưa khu vực sản phẩm/nguồn hàng lên màn hình đầu tiên trước các phần giới thiệu dài.
- [x] Thay form tìm kiếm dài bằng một nút xanh; chỉ mở các trường nhập khi khách hàng bấm nút.
- [x] Kiểm thử responsive và cập nhật regression tests cho luồng mở/đóng tìm kiếm.

- [x] Kiểm tra và tối ưu Open Graph/Twitter metadata để bản chia sẻ có logo, tên, mô tả và ảnh minh họa.
- [x] Cập nhật ảnh xem trước theo đúng nhận diện website, không phụ thuộc vào ảnh sản phẩm giả.
- [x] Kiểm tra khả năng crawler đọc metadata trên domain public sau khi phát hành.

- [x] Điều chỉnh homepage theo mẫu tham khảo mobile-first với header gọn, bo tròn và thanh chức năng dễ quét.
- [x] Đưa ô “AI khách hàng tìm hàng” thành một hàng nổi bật ngay dưới thanh chức năng.
- [x] Hiển thị danh mục và sản phẩm thật theo dữ liệu query, không hiển thị số lượng/tên sản phẩm giả.
- [x] Kiểm tra thẻ sản phẩm, khoảng cách, trạng thái rỗng và responsive ở mobile/desktop.

- [x] Thiết kế homepage giống mẫu tham khảo về bố cục, bo góc, màu sắc, khoảng cách và nhịp hiển thị.
- [x] Giữ nguyên tên, route và hành vi của các nút Nguồn hàng, Mua BĐS, Ký gửi, Tư vấn, Chia sẻ, Menu và AI khách hàng tìm hàng.
- [x] Kiểm thử không có nút chức năng nào bị thay đổi hoặc mất sau khi đổi giao diện.

- [x] Tăng nhẹ kích thước chữ và biểu tượng trong các khung danh mục/nguồn hàng để dễ nhìn hơn trên mobile.

- [x] Chuyển danh mục BĐS nổi bật thành một dải ngang gọn, hiển thị một hàng và có nút trái/phải để xem nhóm tiếp theo.
- [x] Tăng chữ nhãn danh mục gần bằng chữ “Mua BĐS” phía trên, giữ nguyên số đếm và thao tác chọn mục.
- [x] Kiểm thử chuyển dải danh mục trên mobile/desktop và phát hành checkpoint mới.

- [x] Rà soát và cấu hình lại OG tags/Twitter cards cho tiêu đề, mô tả, ảnh và URL chia sẻ.
- [x] Kiểm tra ảnh OG trả về đúng định dạng/kích thước và không dùng asset cục bộ dễ lỗi khi crawler truy cập.
- [x] Xác minh metadata qua HTTP trên preview và domain public, sau đó phát hành checkpoint.

- [x] Thêm cuộn ngang mượt cho dải danh mục bất động sản.
- [x] Ẩn thanh cuộn ngang nhưng vẫn giữ thao tác vuốt, nút mũi tên và bàn phím.
- [x] Kiểm thử trên mobile/desktop và cập nhật checkpoint.

- [x] Kiểm tra vì sao kết quả Google khi chia sẻ chưa hiển thị giống mẫu có logo, tiêu đề, mô tả và ảnh.
- [x] Phân biệt và xác minh OG preview của mạng xã hội với Google Search result để không sửa sai lớp hệ thống.
- [x] Kiểm tra crawler/SEO public và áp dụng chỉnh sửa cần thiết nếu metadata hoặc dữ liệu nhận diện còn thiếu.

- [x] Đổi mỗi mục BĐS thành thẻ ngang có ảnh minh họa, tên mục, số lượng và mũi tên giống mẫu tham khảo.
- [x] Giữ kích thước thẻ vừa phải, không làm thay đổi tên, callback chọn mục hoặc dữ liệu thật.
- [x] Bảo toàn kéo ngang và nút chuyển trái/phải, kiểm thử mobile/desktop sau khi chỉnh sửa.

- [x] Cho phép kéo ngang qua lại để xem các mục BĐS khác bằng cảm ứng và chuột.
- [x] Giữ cuộn trang dọc tự nhiên khi người dùng kéo ngoài dải danh mục.
- [x] Kiểm thử mũi tên, vuốt/kéo ngang và kích thước thẻ vừa phải trên mobile/desktop.

- [x] Thêm nút “Xem tất cả” ở cuối dải danh mục BĐS cuộn ngang.
- [x] Kết nối nút “Xem tất cả” tới luồng xem toàn bộ danh mục hiện có, không làm đổi các nút khác.
- [x] Kiểm thử nút trên mobile/desktop và cập nhật checkpoint.

- [x] Thu chiều rộng thẻ danh mục BĐS xuống khoảng một nửa so với hiện tại.
- [x] Giữ ảnh một bên, tên mục và biểu tượng/số lượng một bên trong thẻ kích thước vừa phải.
- [x] Tối ưu để mobile nhìn thấy khoảng ba thẻ trong một hàng cuộn ngang, kiểm thử desktop/mobile và cập nhật checkpoint.

- [x] Bố trí ba thông tin/mục BĐS trong cùng một thẻ ngang dài, không tách thành ba thẻ lớn.
- [x] Giữ ảnh hoặc biểu tượng, tên mục, số lượng và thao tác chọn từng mục trong bố cục mới.
- [x] Kiểm thử kéo ngang, nút chuyển nhóm và kích thước vừa phải trên mobile/desktop.
- [x] Thu gọn dải danh mục BĐS thành một thẻ ngang dài rộng khoảng một nửa màn hình, cùng bề rộng với khung tìm kiếm nguồn hàng, mỗi lượt hiển thị 3 danh mục trong một hàng và vẫn giữ thao tác chọn/cuộn.
- [x] Tạo mockup carousel chỉ hiển thị một ô danh mục BĐS mỗi lượt; ô rộng ngang gần bằng thanh tìm kiếm nguồn hàng và xếp dọc hình ảnh, tên mục, biểu tượng–số lượng.
- [x] Tạo lại mockup danh mục BĐS theo chiều ngang nhỏ gọn; mỗi lượt một ô, hình ảnh–tên mục–biểu tượng/số lượng nằm cùng hàng và vuốt ngang xem mục khác.
- [x] Chỉnh mockup thẻ danh mục: chỉ tham chiếu kích thước khung xanh của logo/tiêu đề Bất động sản xanh, giữ thẻ nền sáng và không tô xanh toàn bộ mục.
- [x] Thu gọn chiều cao thẻ danh mục ngang theo mockup, ưu tiên đưa khu vực sản phẩm lên sớm hơn và không thay đổi các phần khác của homepage.
- [x] Nới rộng nhẹ thẻ danh mục ngang để tên dài như “Đất khu công nghiệp” hiển thị đủ; chỉ hé một phần rất nhỏ thẻ kế tiếp và giữ nguyên các khu vực khác.
- [x] Làm thao tác vuốt ngang dải danh mục mượt hơn, không giật khi thả tay, vẫn snap đúng từng mục và giữ nút mũi tên hoạt động.
- [x] Tạo mockup phần thông tin sản phẩm cô đọng hơn: ưu tiên vị trí, giá, diện tích, thông số chính; gom nhãn pháp lý gọn và giảm chiều cao tổng thể.
- [x] Giảm khoảng cách dọc giữa các thành phần trong thẻ thông tin sản phẩm, gom giá–diện tích–thông số và giữ nguyên các khu vực khác.
- [x] Sửa dải BĐS nổi bật để vuốt ngang hoạt động mượt, bỏ mũi tên trái/phải và chỉ giữ một mũi tên gợi ý mục tiếp theo.
- [x] Tối ưu độ phản hồi dải danh mục để vuốt bám tay hơn, giảm độ trễ khi thả và snap nhanh tới mục gần nhất.
- [x] Tạo các bố cục hiển thị sản phẩm đa dạng và responsive: thẻ lớn, 2 sản phẩm, 3 sản phẩm, mosaic 1 lớn–4 nhỏ và dải vuốt nhiều sản phẩm; cho phép chọn hoặc tự động luân phiên.
- [x] Tạo các bố cục hiển thị sản phẩm đa dạng và responsive: thẻ lớn, 2 sản phẩm, 3 sản phẩm, mosaic 1 lớn–4 nhỏ và dải vuốt nhiều sản phẩm; cho phép chọn hoặc tự động luân phiên.

# Mở rộng bố cục hiển thị sản phẩm — 2026-08-25

- [x] Tạo renderer dùng chung cho các layout sản phẩm: mosaic 1 lớn + 4 nhỏ, 2-up, 3-up và carousel ngang.
- [x] Thêm cơ chế chọn layout tự động ổn định, có nút chuyển layout khi phù hợp, cho homepage và catalog công khai.
- [x] Refactor mapping sản phẩm ở Home.tsx và PropertyCatalog.tsx sang renderer dùng chung, giữ nguyên dữ liệu, CTA và liên kết chi tiết.
- [x] Bảo đảm mosaic, grid và carousel responsive; mobile chuyển stack/swipe gọn, desktop giữ chất editorial.
- [x] Bổ sung test helper/layout renderer, chạy Vitest và kiểm tra TypeScript.
- [x] Kiểm tra preview desktop/mobile và lưu checkpoint phát hành sau khi hoàn tất.

# Ghi nhớ chế độ hiển thị — 2026-08-25

- [x] Lưu lựa chọn layout sản phẩm của người dùng vào localStorage và khôi phục khi tải lại ở homepage/catalog.
- [x] Bảo đảm helper localStorage an toàn với SSR, dữ liệu hỏng và trình duyệt hạn chế storage.
- [x] Bổ sung test cho đọc/ghi layout, chạy kiểm thử và xác minh tải lại giao diện.
- [x] Cập nhật checkpoint phát hành sau khi hoàn tất.

# Điều chỉnh vị trí bộ chọn layout — 2026-08-25

- [x] Đặt bộ chọn layout dạng nút tích chọn trong khu vực quản lý/đăng bán sản phẩm.
- [x] Lưu lựa chọn layout quản trị viên và dùng làm cấu hình chung cho các khu vực có bài đăng công khai.
- [x] Xóa các nút picker layout khỏi homepage và catalog công khai, giữ nguyên renderer tự động bên dưới.
- [x] Bổ sung test cho cấu hình chung và kiểm tra responsive/admin flow.
- [x] Cập nhật checkpoint phát hành sau khi hoàn tất.

# Bố cục theo từng danh mục — 2026-08-25

- [x] Xây cấu hình layout riêng theo danh mục, có fallback về layout chung/Tự động.
- [x] Thêm giao diện quản trị để chọn layout cho từng danh mục sản phẩm.
- [x] Áp dụng cấu hình theo danh mục ở homepage và catalog, không đưa picker trở lại storefront.
- [x] Bổ sung test cho đọc/ghi cấu hình danh mục, fallback và lọc danh mục.
- [x] Kiểm tra responsive, cập nhật todo và phát hành checkpoint mới.

# Đồng bộ layout theo tài khoản quản trị — 2026-08-25

- [x] Tạo bảng lưu cấu hình layout theo tài khoản quản trị, gồm layout mặc định và override theo danh mục.
- [x] Thêm schema/migration, helper database và tRPC API admin để đọc/ghi cấu hình an toàn.
- [x] Đồng bộ cấu hình server với homepage/catalog, giữ fallback localStorage khi chưa đăng nhập hoặc API lỗi.
- [x] Thêm preview trực tiếp các bố cục trong Quản lý đăng bán, dùng dữ liệu bài đăng hiện có.
- [x] Bổ sung test backend/frontend cho quyền truy cập, lưu/đọc cấu hình, fallback và preview.
- [x] Kiểm tra migration, responsive, cập nhật todo và phát hành checkpoint.

# Kiểm tra hiệu năng ba route — 2026-08-25

- [x] Đo thời gian phản hồi và kích thước tải của `/`, `/bat-dong-san` và `/quan-ly-moi-gioi` trên bản production hiện tại.
- [x] Kiểm tra tài nguyên và trạng thái tải thực tế trên trình duyệt ở desktop/mobile.
- [x] Tổng hợp bottleneck, phân biệt server/API/JavaScript/hình ảnh và đề xuất ưu tiên tối ưu.

# Tách website bán hàng và phần mềm quản lý — 2026-08-25

- [x] Rà soát route, import và bundle để xác định module quản trị/AI đang bị tải sớm trên storefront.
- [x] Tách lazy-load phần quản lý môi giới/CRM khỏi bundle website bán hàng công khai.
- [x] Giữ chung API/cơ sở dữ liệu, bảo đảm public listing và yêu cầu khách hàng vẫn đồng bộ.
- [x] Kiểm tra quyền đăng nhập, điều hướng và fallback khi module quản trị được tải riêng.
- [x] Đo lại bundle và thời gian tải ba route, chạy test và xác minh responsive.
- [x] Cập nhật tài liệu kiến trúc và phát hành checkpoint.

# Rà soát tách storefront và CRM — 2026-08-25
- [x] Xác định và xác nhận URL riêng cho website bán hàng và CRM.
- [x] Kiểm tra manifest/service worker để storefront và CRM có thể cài độc lập trên điện thoại.
- [x] Xác minh hai phần dùng chung backend/database và tự cập nhật dữ liệu.
- [x] Bổ sung hoặc sửa cấu hình tách app nếu checkpoint hiện tại chưa đáp ứng.
- [x] Chạy test, kiểm tra route mobile và phát hành bản cập nhật.

# Kiểm tra Not Found sau khi tách storefront và CRM — 2026-08-25
- [x] Xác định chính xác URL đang báo Not Found trên domain phát hành.
- [x] Kiểm tra route storefront, CRM và entrypoint cài đặt mobile.
- [x] Sửa fallback hoặc định tuyến nếu phát hiện lỗi; không cần sửa thêm vì các route đã hoạt động đúng.
- [x] Chạy test và xác minh lại các URL sau khi sửa.

# Khắc phục Not Found CRM tái xuất hiện — 2026-08-25
- [x] Kiểm tra URL CRM production và cách mở từ shortcut/PWA trên điện thoại.
- [x] Xác định nguyên nhân Not Found và sửa route hoặc fallback nếu cần.
- [x] Kiểm thử các biến thể `/crm`, `/crm/`, `/crm/login`, `/crm/login/`.
- [x] Lưu và phát hành bản sửa, gửi lại URL mở CRM cho người dùng.

# Khắc phục Not Found preview sau đồng bộ — 2026-08-25
- [x] Kiểm tra URL preview và trạng thái server sau restart.
- [x] Xác định nguyên nhân Not Found ở preview và sửa fallback/định tuyến nếu cần.
- [x] Chạy test, xác minh route storefront/CRM và lưu bản sửa.

# Sửa lỗi cài PWA hai phần trên điện thoại — 2026-08-25
- [x] Kiểm tra manifest, icon/logo, start_url, scope và id của storefront/CRM.
- [x] Kiểm tra nút cài đặt và sự kiện beforeinstallprompt trên mobile.
- [x] Sửa cấu hình để hai app cài đúng tên/logo và giữ đúng vùng URL.
- [x] Chạy test installability, kiểm tra mobile và phát hành bản cập nhật.

# Tạo CRM tham khảo riêng miễn phí — 2026-08-25
- [x] Xác định URL riêng miễn phí và phạm vi bản CRM tham khảo — đã chuyển sang CRM trong project gốc để đồng bộ dữ liệu.
- [x] Tách lối vào CRM khỏi storefront nhưng giữ hợp đồng backend/database chung.
- [x] Kiểm tra đăng nhập, quyền quản trị, đồng bộ nguồn hàng và cài đặt mobile.
- [x] Chạy test và bàn giao bản tham khảo cho người dùng.

# Phương án A — CRM project miễn phí riêng — 2026-08-25
- [x] Tạo project/URL Manus miễn phí riêng cho CRM tham khảo — phương án project gốc `/crm` được giữ làm bản chính.
- [x] Kết nối CRM mới với backend/API và database hiện tại, không tạo dữ liệu tách rời.
- [x] Kiểm tra đăng nhập, phân quyền, đồng bộ nguồn hàng/lead và PWA mobile.
- [x] Bàn giao URL CRM riêng sau khi kiểm thử — `/crm` trên domain storefront hiện tại.

- [x] Xác định và thiết kế khả năng tra cứu/đối chiếu quy hoạch cho từng BĐS trong CRM, chỉ dùng dữ liệu quy hoạch có nguồn xác thực và hiển thị cảnh báo cần kiểm tra chính thức.

- [x] Thiết kế module phân tích định giá BĐS trong CRM: dữ liệu đầu vào, BĐS so sánh, khoảng giá tham khảo, yếu tố điều chỉnh, nguồn dữ liệu và cảnh báo không thay thế thẩm định chính thức.

- [x] Thiết kế module phân tích vay vốn theo từng BĐS: giá mua, vốn tự có, khoản vay, thời hạn, lãi suất, trả hàng tháng, lịch trả nợ tham khảo và cảnh báo không phải cam kết tín dụng.

- [x] Thiết kế module khảo sát vị trí BĐS: ghim tọa độ, bản đồ khu vực, đường sá, tiện ích lân cận, khoảng cách/thời gian di chuyển, ghi chú khảo sát và sơ đồ giới thiệu đơn giản.

- [x] Thêm tìm kiếm BĐS xung quanh theo tọa độ và bán kính, có bộ lọc loại/giá/diện tích/trạng thái, hiển thị trên bản đồ và danh sách, liên kết tới hồ sơ chi tiết.

- [x] Tự thiết kế kiến trúc CRM nâng cao: dashboard hành động, luồng công việc, tìm kiếm thống nhất, trợ lý AI, cảnh báo, báo cáo và trải nghiệm mobile liền mạch; không dùng dữ liệu khách hàng giả.

- [x] Thêm nút màu vàng “Đổi mật khẩu” tại màn hình đăng nhập quản trị CRM và triển khai luồng đổi mật khẩu an toàn.

- [x] Sửa nút tải hồ sơ điện tử để tạo file .docx hợp lệ, có MIME type đúng và mở được trên mobile/máy tính.

- [x] Xác minh và chuẩn hóa việc tự động tạo mã BĐS duy nhất khi đăng bài, đồng bộ hiển thị trong storefront, CRM và hồ sơ điện tử.

- [x] Rà soát toàn bộ website và CRM hiện tại, lập danh sách các điểm chưa hoàn thiện có thể kiểm chứng bằng mã nguồn/preview.
- [x] Sửa các hạng mục ưu tiên phát hiện trong đợt rà soát và bổ sung kiểm thử hồi quy (không phát hiện lỗi tái hiện được ngoài trạng thái loading tạm thời; đã xác minh dữ liệu hiển thị sau khi request hoàn tất).

- [x] Xác minh project CRM mới `batdongsan-k484tjea.manus.space` và phân biệt URL CRM tổng quan với ba module AI.
- [x] Kiểm tra đăng nhập, điều hướng, mức độ tách riêng và khả năng đồng bộ của project CRM mới.

- [x] Điều tra lỗi mở URL CRM mới nhưng bị chuyển về storefront; kiểm tra link, redirect, route guard, manifest và service worker.
- [x] Xác minh bốn route CRM mới mở đúng trên điện thoại và không dùng shortcut/cache storefront cũ.

- [x] Thêm một thẻ “Mở CRM” trên website bán hàng, trỏ tới project CRM mới `https://batdongsan-k484tjea.manus.space/crm` và không ảnh hưởng các thẻ BĐS dành cho khách hàng.

- [x] Rà soát storefront cũ và chọn một số bổ sung nhỏ, thiết thực cho khách hàng mà không làm nặng trang.
- [x] Triển khai, kiểm thử và phát hành các bổ sung storefront được ưu tiên.

- [x] Kiểm kê 12 bước hồ sơ và lập danh sách mẫu file tải xuống cho từng bước.
- [x] Tích hợp mẫu DOCX người dùng cung cấp và nút tải mẫu tương ứng trong từng bước.
- [x] Kiểm thử tải file, tên file, định dạng mở được và giao diện mobile.

- [x] Kiểm tra vì sao người dùng chỉ thấy CRM mới và không thấy lối vào CRM cũ.
- [x] Phân biệt rõ link CRM cũ với link CRM mới trên storefront/CRM.
- [x] Khôi phục lối vào CRM cũ nếu route hoặc liên kết đã bị mất.
- [x] Kiểm thử điều hướng hai phiên bản CRM và cập nhật hướng dẫn mở đúng bản.

- [x] Giữ nguyên CRM cũ và khôi phục lối vào đúng phiên bản cũ, không gộp hoặc thay thế bằng CRM mới.
- [x] Kiểm tra URL/route và điều hướng để người dùng mở được CRM cũ.

- [x] Sửa bộ chọn bố cục và phần xem trước trong đăng sản phẩm thành khung cuộn dọc gọn, không bị cắt trên mobile — theo yêu cầu cuối cùng, không dùng cuộn ngang.
- [x] Thêm tải video/ảnh/ảnh 360° theo từng BĐS và hiển thị trạng thái media.
- [x] Tích hợp AI tạo storyboard, lời đọc, phụ đề và thông tin video từ dữ liệu BĐS đã xác nhận.
- [x] Tạo luồng bản nháp video giới thiệu để môi giới xem storyboard, lời đọc và phụ đề trước khi xuất bản; chưa tự động render video cuối.
- [x] Viết test và kiểm tra mobile cho thanh cuộn, media và luồng video AI.

- [x] Gom các mục chọn bố cục trong phần đăng sản phẩm vào khung cuộn dọc gọn, không xếp thành cột dài — theo yêu cầu cuối cùng.

- [x] Đặt hai phần sản phẩm trong khung cuộn dọc có chiều cao gọn trên mobile và giữ đủ các nút lựa chọn bố cục.

- [x] Tùy chỉnh scrollbar của hai khung sản phẩm thành dạng mỏng, bo tròn, nhẹ và phù hợp nhận diện xanh rêu.

- [x] Cho phép môi giới quay bằng camera hoặc tải video/ảnh thật theo từng BĐS để AI phân tích.
- [x] Lưu media bằng storage và lưu metadata/phân tích theo mã BĐS, không lưu byte trong database.
- [x] Tạo bản nháp giới thiệu có cảnh, phụ đề và lời đọc từ dữ liệu thật, bắt buộc kiểm duyệt trước xuất bản.
- [x] Viết test cho upload/camera, phân tích AI, phân quyền và trạng thái kiểm duyệt.

- [x] Triển khai tính năng 1: quay hoặc tải video/ảnh thật theo từng BĐS để AI phân tích.
- [x] Triển khai tính năng 2: tạo bản nháp video giới thiệu có storyboard, phụ đề và lời đọc từ dữ liệu thật để môi giới duyệt.

- [x] Bổ sung luồng 3D nâng cao: nhận dữ liệu quét/chụp 3D thật, hiển thị tương tác GLB/GLTF theo BĐS và mở/tải trực tiếp USDZ/OBJ/PLY/E57; dữ liệu được giữ làm nguồn cho bước video AI.
- [x] Xác định nguồn dữ liệu 3D, giới hạn thiết bị và cơ chế kiểm duyệt: nhận file Polycam/LiDAR thật, giới hạn theo validator kích thước/định dạng, không suy đoán mô hình từ địa chỉ hoặc giấy tờ.

- [x] Làm phương án 3 trước: quay hoặc tải video/ảnh thật bằng điện thoại theo từng BĐS.
- [x] Vẫn tích hợp nhánh 3D AI nâng cao, liên kết tour/mô hình 3D với cùng mã BĐS và hồ sơ đăng bán.

- [x] Thêm nút “Quay/Tải video” vào trang Quản lý theo từng BĐS.
- [x] Thêm nút “Quét 3D” vào trang Quản lý theo từng BĐS, kèm trạng thái chờ dữ liệu quét thật.
- [x] Hiển thị hướng dẫn rằng địa chỉ/giấy tờ chỉ là nguồn tham khảo; AI cần media hoặc dữ liệu 3D thật để dựng không gian chính xác.

- [x] Thêm đồng thời nút “Quay/Tải video” và nút “Quét 3D” vào trang Quản lý theo từng BĐS.
- [x] Chuẩn bị trạng thái và điểm liên kết để kết nối xử lý AI/video/3D về sau.

- [x] Hoàn thiện luồng video thật: quay/tải media, lưu theo BĐS, AI phân tích và tạo bản nháp giới thiệu.
- [x] Hoàn thiện luồng 3D: tiếp nhận dữ liệu quét thật, xem mô hình GLB/GLTF tương tác hoặc mở/tải định dạng khác, liên kết cùng propertyId; tour AI chuyên sâu vẫn là hướng mở rộng riêng.
- [x] Bổ sung kiểm duyệt trước khi xuất bản và hướng dẫn sử dụng trên điện thoại.

- [x] Không tạm ẩn nút “Quét 3D”; giữ nút hiển thị để nhận dữ liệu quét thật theo yêu cầu người dùng.
- [x] Giữ nút “Quay/Tải video” làm luồng sử dụng chính hiện tại.
- [x] Ghi rõ phân tích khu vực 3D chỉ dùng dữ liệu bản đồ/ảnh có nguồn và không thay thế khảo sát thực địa.

- [x] Cho phép nút Quét 3D nhận ảnh 3D/360° và file quét 3D thật theo từng bài BĐS.
- [x] Hiển thị trạng thái dữ liệu 3D đã đưa vào để dùng cho phân tích không gian và video về sau.

- [x] Bổ sung mục quản lý BĐS đã bán/lưu trữ trong phần bán hàng.
- [x] Tự động chuyển hồ sơ sang mô-đun AI sản xuất khi trạng thái BĐS đổi thành Đã bán.
- [x] Liên kết hồ sơ đã bán với Hồ sơ của tôi và các mô-đun CRM liên quan.
- [x] Bổ sung kiểm thử luồng trạng thái, lưu trữ và đồng bộ dữ liệu giữa bán hàng và CRM.

- [x] Thêm nút phân loại Chưa bán/Đã bán cho từng bài BĐS.
- [x] Khi bấm Đã bán, tự chuyển bài vào khu đã bán/lưu trữ và kích hoạt luồng AI sản xuất hồ sơ.
- [x] Cho phép thử lại luồng AI sản xuất nếu lần kích hoạt trước bị lỗi.
- [x] Kiểm thử chuyển đổi hai trạng thái và đồng bộ với Hồ sơ của tôi/các mô-đun CRM.

- [x] Kiểm tra route và giao diện Hồ sơ đất đai AI, Hồ sơ của tôi và các mô-đun AI chuyên trách đất đai.
- [x] Đối chiếu schema/API và xác nhận cơ chế đồng bộ theo propertyId, dossierId và mã BĐS.
- [x] Kiểm tra quy trình đất đai, trạng thái hồ sơ, quyền truy cập và các điểm cần nguồn chính thức.
- [x] Lập danh sách thiếu sót, rủi ro và hạng mục cần bổ sung sau kiểm tra.

- [x] Đưa landDossiers vào kho Hồ sơ của tôi, hiển thị mã hồ sơ/quy trình/trạng thái và giữ liên kết propertyId.
- [x] Bổ sung regression test cho ánh xạ land dossier vào kho hồ sơ tổng hợp.

- [x] Sửa lỗi nút Đã bán trong khu hồ sơ dẫn tới Not Found.
- [x] Kiểm thử URL điều hướng, cập nhật trạng thái và mở đúng Hồ sơ AI sau khi bấm Đã bán.

- [x] Xác định phiên bản cũ và phiên bản mới để đối chiếu giao diện thực tế.
- [x] Lập bảng khác biệt về bố cục, màu sắc, điều hướng, responsive và nội dung storefront.
- [x] Lập bảng khác biệt về CRM, Hồ sơ AI, trạng thái BĐS và đồng bộ dữ liệu.
- [x] Đề xuất phần nên giữ, phần nên loại bỏ và phương án kết hợp an toàn.

- [x] Kiểm tra lối vào Đăng bán hàng sản phẩm và khu sản phẩm của tôi trong storefront/CRM.
- [x] Khôi phục hoặc bổ sung liên kết đúng route nếu đang bị ẩn hoặc mở nhầm.
- [x] Kiểm thử luồng mở form đăng bán và danh sách sản phẩm của tôi trên mobile/desktop.

- [x] Kiểm tra vì sao hai sản phẩm từng hiển thị nay bị lọc thành 0 sản phẩm công khai.
- [x] Khôi phục hiển thị hai sản phẩm đúng dữ liệu nếu bài đăng vẫn tồn tại và được phép công khai.
- [x] Kiểm thử bộ lọc, route /bat-dong-san và hiển thị mobile sau khi sửa.

- [x] Kiểm tra URL ảnh, storage và log network của ảnh danh mục và ảnh sản phẩm.
- [x] Sửa ảnh hỏng hoặc cơ chế fallback để ảnh sản phẩm hiển thị ổn định.
- [x] Kiểm thử tốc độ và trạng thái ảnh trên storefront desktop/mobile.

- [x] Sửa menu HS ĐẤT ĐAI AI đang trỏ tới route cũ `/hs-dat-dai-ai` không tồn tại.
- [x] Kiểm thử các lối vào Hồ sơ đất đai AI trong DashboardLayout sau khi đổi route.

- [x] Thay trạng thái mẫu trên khối sản phẩm trang chủ bằng dữ liệu published khi đã có nguồn hàng thật, giữ nguyên bố cục và không xóa khối mẫu dự phòng.
- [x] Kiểm thử trang chủ hiển thị đúng nguồn hàng thật sau khi dữ liệu published tồn tại.

# Cải thiện tốc độ ảnh trang chủ — 2026-08-26

- [x] Tối ưu ảnh danh mục và ảnh mẫu trên Home bằng loading lazy, decoding async và fallback khi lỗi.
- [x] Điều chỉnh bộ nhớ đệm same-origin cho ảnh storage để trình duyệt không tải lại cùng ảnh ở mỗi lần truy cập.
- [x] Viết regression test cho thuộc tính tải ảnh và chạy TypeScript/Vitest.
- [x] Kiểm tra lại trang chủ desktop/mobile và lưu checkpoint phát hành.

# Media thật theo BĐS — 2026-08-26

- [x] Thêm procedure uploadPropertyMediaAsset để lưu video, ảnh, ảnh 360° và file 3D theo propertyId vào S3/archive.
- [x] Giới hạn kích thước riêng cho video 50MB, 3D 100MB và ảnh/360° 15MB.
- [x] Kết nối nút “Quay/Tải video” và “Quét 3D” trong CRM với upload thật, giữ nguyên hai nút hiển thị.
- [x] Hỗ trợ phần mở rộng Polycam/LiDAR: USDZ, GLB, GLTF, OBJ, PLY và E57 ở UI; validator MIME 3D ở backend.
- [x] Bổ sung regression contract test cho endpoint media; TypeScript và 444/444 test đạt.
- [x] Thêm procedure phân tích AI từ video/ảnh đã lưu và tạo storyboard/nội dung giới thiệu có bước môi giới duyệt.
- [x] Hiển thị danh sách asset đã lưu và trạng thái phân tích trong CRM.

# Chú thích trên mô hình 3D — 2026-08-26

- [x] Tạo mô hình dữ liệu chú thích 3D theo propertyId và asset media, gồm vị trí điểm, tiêu đề, nội dung, thẻ và người tạo.
- [x] Thêm procedure tRPC để đọc, tạo, sửa và xóa chú thích 3D với quyền admin phù hợp.
- [x] Tích hợp thao tác chọn điểm trên viewer GLB/GLTF, form nhập chú thích/thẻ và danh sách chú thích.
- [x] Hiển thị marker/chú thích trực tiếp trên viewer, hỗ trợ chọn lại để xem nội dung.
- [x] Viết regression test và kiểm tra giao diện desktop/mobile trước khi phát hành.

# Sửa thẻ nguồn hàng mobile — 2026-08-26

- [x] Mở rộng thẻ nguồn hàng thứ hai trên Home mobile để nội dung và ảnh không bị bó hẹp.
- [x] Sửa chiều rộng track/carousel và khoảng cách giữa các thẻ để thẻ thứ ba không chồng lên thẻ trước.
- [x] Kiểm tra Home ở viewport mobile và desktop, sau đó chạy test và phát hành checkpoint.

# Tinh chỉnh khoảng trống thẻ nguồn hàng — 2026-08-26

- [x] Kéo track carousel sát hai bên và mở rộng thẻ Nhà phố gần tới mũi tên tiếp theo trên mobile.
- [x] Kéo ảnh trong thẻ dài hơn, điều chỉnh vùng chữ sang bên phải và giảm khoảng trống dư.
- [x] Áp dụng tỷ lệ tương tự cho các danh mục khác, ngăn chồng thẻ và kiểm tra desktop/mobile.

# Xử lý lỗi API connection closed — 2026-08-26

- [x] Xác định request và module gây lỗi `Connection closed while receiving data` từ log frontend/backend — log cho thấy lỗi kết nối API tạm thời, không có lỗi ứng dụng lặp lại.
- [x] Bổ sung timeout, retry có giới hạn và trạng thái lỗi thân thiện cho luồng gọi API bị gián đoạn.
- [x] Viết regression test, kiểm tra lại preview mobile và phát hành checkpoint nếu lỗi có thể xử lý trong mã nguồn.

# Sửa ảnh và thẻ sản phẩm mobile — 2026-08-26

- [x] Mở rộng thẻ sản phẩm và khu ảnh trên mobile nhưng vẫn giữ nút điều hướng không chồng nội dung.
- [x] Chừa vùng an toàn cho dòng địa chỉ để không bị badge loại BĐS che hoặc cắt chữ.
- [x] Kiểm tra và sửa nguồn ảnh lỗi, giữ fallback rõ ràng khi URL ảnh không còn khả dụng.
- [x] Chạy test và kiểm tra storefront desktop/mobile trước khi phát hành.

# Kết quả sửa ảnh và thẻ sản phẩm — 2026-08-26

- [x] Mở rộng thẻ sản phẩm và khu ảnh trên mobile, giữ nút điều hướng không chồng nội dung.
- [x] Chừa vùng an toàn cho địa chỉ để không bị badge loại BĐS che hoặc cắt chữ.
- [x] Thêm fallback sạch khi URL ảnh lỗi để không còn biểu tượng ảnh vỡ.
- [x] Chạy TypeScript và 446/446 Vitest; kiểm tra preview storefront mobile sau khi sửa.
- [x] Kiểm tra thêm nguồn ảnh CDN/storage đang trả lỗi mạng trong phiên truy cập thực tế — preview hiện tải ảnh bình thường; lỗi trong ảnh được xác định là gián đoạn kết nối tạm thời và đã có fallback/retry.

# Cải thiện ảnh và card single published — 2026-08-26

- [x] Kiểm tra ảnh storage/CDN với mô phỏng mạng chậm và xác nhận trạng thái tải lỗi có thể phục hồi.
- [x] Thêm nút “Tải lại ảnh” ngay trên fallback, reset trạng thái và thử lại URL ảnh.
- [x] Cân chỉnh chiều rộng card desktop khi chỉ có một bài published, không làm hẹp nội dung trên màn hình lớn.
- [x] Chạy regression test, kiểm tra desktop/mobile và phát hành checkpoint.

# Điều tra logo và ảnh danh mục không tải — 2026-08-26

- [x] Xác định URL logo/ảnh danh mục bị lỗi và kiểm tra phản hồi storage/CDN trên storefront.
- [x] Đối chiếu log network/console để phân biệt URL hỏng, quyền truy cập, cache hoặc lỗi kết nối tạm thời.
- [x] Sửa nguồn tài sản hoặc cơ chế fallback nếu lỗi thuộc mã nguồn; kiểm tra desktop/mobile trước khi phát hành.

# Bỏ mẫu tham khảo khỏi storefront — 2026-08-26

- [x] Khi có sản phẩm published, ẩn hoàn toàn khối mẫu tham khảo và nhãn “chưa phải nguồn hàng thực”.
- [x] Không để khoảng trống hoặc CTA mẫu sau khi khối minh họa bị ẩn.
- [x] Giữ trạng thái rỗng rõ ràng khi chưa có sản phẩm published và kiểm thử regression mobile/desktop.

# Tinh gọn thông tin thẻ BĐS — 2026-08-26

- [x] Bỏ hiển thị diện tích bị lặp giữa huy hiệu diện tích cạnh giá và lưới thông tin.
- [x] Đưa nhãn Pháp lý và Vay vốn lên cùng một hàng, có thể cuộn ngang nếu nội dung dài.
- [x] Kiểm tra thẻ trên mobile/desktop, cập nhật test và lưu checkpoint.

# Gọn hàng chỉ số thẻ BĐS — 2026-08-26

- [x] Đưa Ngang × dài, Hướng, Đường, Phòng ngủ và Phòng vệ sinh vào cùng một hàng năm cột.
- [x] Thu nhỏ chữ, khoảng cách và xử lý cắt nội dung dài để không vỡ thẻ trên mobile.
- [x] Áp dụng cho Home và PropertyPostingTemplate, cập nhật test, kiểm tra responsive và lưu checkpoint.

# Tối ưu màn hình nhỏ dưới 360px — 2026-08-26

- [x] Thêm breakpoint dưới 360px cho kích thước chữ và khoảng cách trong thẻ BĐS.
- [x] Giữ tiêu đề, giá, năm chỉ số và nhãn pháp lý dễ đọc, không chồng lấn trên 320px.
- [x] Kiểm thử 320px/360px, cập nhật test và lưu checkpoint.

# Tinh gọn menu CRM và tạo Trợ lý AI — 2026-08-27

- [x] Kiểm kê toàn bộ menu, route và module CRM đang bị lặp.
- [x] Gom giao dịch, khảo sát khu vực, nguồn hàng lân cận và đối chiếu quy hoạch vào nhóm chức năng phù hợp, không xóa route đang dùng.
- [x] Tạo mục trung tâm “Trợ lý AI” để điều phối các công cụ AI và dẫn tới module chi tiết.
- [x] Kiểm thử route, quyền truy cập, menu mobile/desktop và cập nhật regression test.
- [x] Lưu checkpoint sau khi hoàn tất.

# Tách Quy trình và xây dựng trung tâm Giao dịch — 2026-08-27

- [x] Rà soát route, menu, schema và quyền hiện tại của Quy trình/Giao dịch.
- [x] Tách lối vào Quy trình và Giao dịch trên CRM, giữ route cũ tương thích.
- [x] Thiết kế mô hình giao dịch gồm mã GD, BĐS, người mua, chủ nhà, môi giới, giá, cọc, hoa hồng, lịch và trạng thái.
- [x] Xây dựng tổng quan giao dịch và pipeline vòng đời từ quan tâm đến hoàn tất.
- [x] Xây dựng màn hình chi tiết hồ sơ giao dịch điện tử, checklist và các nhóm đặt cọc/công chứng/sang tên/thanh toán/hợp đồng/bàn giao.
- [x] Thêm khu Trợ lý AI giao dịch với kiểm tra thiếu dữ liệu, cảnh báo và đề xuất bước tiếp theo; không tự động xác nhận pháp lý hay công khai hồ sơ.
- [x] Cập nhật schema/migration, API tRPC, phân quyền admin và kiểm thử không tạo dữ liệu giao dịch giả.
- [x] Kiểm tra responsive, route cũ, TypeScript, Vitest và lưu checkpoint.

# Xây dựng trung tâm Marketing CRM — 2026-08-27

- [x] Rà soát module CRM, schema BĐS/khách hàng/giao dịch và menu Marketing hiện tại.
- [x] Thiết kế hồ sơ Marketing liên kết trực tiếp với BĐS đang bán, không tạo bản sao dữ liệu nguồn hàng.
- [x] Xây dựng màn hình Marketing gồm tổng quan, chiến dịch, AI Content, kênh, nguồn hàng, nhóm khách, lịch và phân tích.
- [x] Bổ sung AI Content theo BĐS thật, trạng thái duyệt nội dung và cảnh báo không tự đăng khi chưa duyệt.
- [x] Nối nguồn khách quan tâm vào CRM khách hàng/lead và liên kết BĐS, chiến dịch, kênh.
- [x] Đồng bộ trạng thái/thông tin BĐS đang bán vào hồ sơ Marketing và kiểm tra phân quyền.
- [x] Cập nhật schema/migration/API tRPC, regression test, responsive và lưu checkpoint.

# Đợt triển khai Marketing Center — dữ liệu thật và lead tự động

- [x] Bổ sung bảng Marketing campaigns, content items và content calendar liên kết trực tiếp với properties, users và buyer leads.
- [x] Bổ sung helper database và procedure tRPC quản lý chiến dịch, nội dung nháp, lịch nội dung và thống kê Marketing.
- [x] Bổ sung CTA “Quan tâm” public có campaignId/propertyId để tạo consultation request thật, không tạo lead giả và không trùng bản ghi do gửi lại.
- [x] Hiển thị Marketing Center bằng dữ liệu thật: chiến dịch, nội dung, lịch, kênh, lead và phân tích; thay toàn bộ placeholder bằng empty state trung thực.
- [x] Tinh chỉnh prompt AI Content theo loại BĐS và kênh, giữ nguyên nguyên tắc nháp cần duyệt, không tự đăng và không khẳng định pháp lý chưa kiểm chứng.
- [x] Bổ sung test Vitest cho schema/API/payload Marketing và luồng campaign → consultation request → CRM, không seed dữ liệu thử vào database.
- [x] Chạy TypeScript, Vitest, kiểm tra browser responsive và xác nhận luồng Marketing → Lead → Giao dịch bằng dữ liệu hiện có.

# Đồng bộ Giao dịch ↔ Nguồn hàng

- [x] Tạo query nguồn hàng thật cho form Giao dịch, chỉ cho chọn BĐS hợp lệ và hiển thị thông tin nhận diện thay vì nhập ID thủ công.
- [x] Trả về thông tin BĐS liên kết trong danh sách và hồ sơ chi tiết giao dịch.
- [x] Cập nhật trạng thái BĐS trong cùng luồng mutation khi giao dịch chuyển sang đã bán/hoàn tất; bảo vệ không tự bán nhầm khi giao dịch bị hủy.
- [x] Bổ sung kiểm tra chống trùng giao dịch đang hoạt động trên cùng BĐS và kiểm thử rollback/error path.
- [x] Cập nhật regression tests, kiểm tra responsive và lưu checkpoint phát hành.

# Liên kết hồ sơ Đã bán hiện có với Giao dịch

- [x] Xác định module và khóa propertyId của hồ sơ Đã bán đang tồn tại.
- [x] Nối truy vấn Giao dịch/Nguồn hàng với hồ sơ Đã bán hiện có, không tạo bản ghi mới.
- [x] Hiển thị nút mở hồ sơ Đã bán hiện có từ BĐS và giao dịch tương ứng.
- [x] Thêm test bảo đảm liên kết dùng lại đúng hồ sơ và không nhân bản dữ liệu.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint phát hành.

# Liên kết tự động hồ sơ Đã bán hiện có

- [x] Xác định module và khóa propertyId của hồ sơ Đã bán đang tồn tại.
- [x] Chuẩn hóa mọi hồ sơ phát sinh dùng chung propertyId, không tạo bản ghi hồ sơ trùng.
- [x] Nối Giao dịch, pháp lý, công chứng, sang tên, thanh toán, bàn giao và AI về hồ sơ Đã bán tương ứng.
- [x] Hiển thị nút mở hồ sơ Đã bán hiện có từ BĐS và giao dịch tương ứng.
- [x] Thêm test bảo đảm liên kết dùng lại đúng hồ sơ và không nhân bản dữ liệu.
- [x] Kiểm tra responsive, TypeScript, Vitest và lưu checkpoint phát hành.

# Sửa liên kết Giao dịch với sản phẩm Đã bán

- [x] Thêm truy vấn danh sách sản phẩm có trạng thái Đã bán kèm propertyId và hồ sơ hiện có.
- [x] Cho phép form Tạo giao dịch chọn trực tiếp sản phẩm Đã bán, không nhập ID thủ công.
- [x] Tự điền và khóa propertyId theo sản phẩm đã chọn, hiển thị xác nhận hồ sơ đang liên kết.
- [x] Bổ sung test payload và chống tạo bản ghi trùng khi liên kết sản phẩm Đã bán.
- [x] Kiểm tra preview mobile, TypeScript, Vitest và lưu checkpoint phát hành.

# Khôi phục AI Kho hồ sơ pháp lý

- [x] Kiểm tra module/route AI hồ sơ pháp lý cũ và mục menu hiện tại.
- [x] Khôi phục lối vào “AI Kho hồ sơ pháp lý” trong CRM nếu đang bị ẩn hoặc thiếu route.
- [x] Bảo đảm module dùng lại hồ sơ BĐS hiện có và liên kết được với Giao dịch, không tạo bản ghi trùng.
- [x] Cập nhật regression tests, kiểm tra preview, TypeScript, Vitest và lưu checkpoint phát hành.

# Gom trung tâm AI Sản xuất

- [x] Tạo một mục chính “AI Sản xuất” trong menu CRM.
- [x] Gom AI Kho hồ sơ pháp lý, AI hồ sơ đất đai, AI hồ sơ đất đai tự động và các mô-đun sản xuất liên quan vào nhóm này.
- [x] Bổ sung lối vào rõ ràng cho AI hồ sơ đất đai đang thiếu, giữ nguyên route cũ.
- [x] Thêm trang/trung tâm điều hướng AI Sản xuất nếu cấu trúc hiện tại chưa có, không xóa các module cũ.
- [x] Cập nhật regression tests, kiểm tra mobile/desktop, TypeScript, Vitest và lưu checkpoint phát hành.

# Khôi phục module AI đã bị xóa khỏi menu

- [x] Đối chiếu các route và page AI còn tồn tại với menu hiện tại để xác định mục từng bị xóa.
- [x] Khôi phục mục chính “AI Sản xuất” theo cấu trúc cũ, không tạo menu thay thế làm mất đường dẫn cũ.
- [x] Khôi phục các lối vào AI hồ sơ đất đai, AI hồ sơ đất đai tự động và AI Kho hồ sơ pháp lý trong nhóm cũ.
- [x] Giữ nguyên các route tương thích và kiểm tra không làm mất module hiện có.
- [x] Cập nhật regression tests, kiểm tra mobile/desktop, TypeScript, Vitest và lưu checkpoint phát hành.

# Khôi phục cấu trúc Hồ sơ đất đai AI và AI Kho pháp lý hồ sơ AI

- [x] Hiển thị mục riêng “Hồ sơ đất đai AI” trong menu CRM.
- [x] Hiển thị mục riêng “AI Kho pháp lý hồ sơ AI” trong menu CRM.
- [x] Đưa các mô-đun tự động, nâng cao, lập hồ sơ, đối chiếu và vận hành vào nhóm AI Kho pháp lý hồ sơ AI.
- [x] Giữ nguyên các route cũ và không xóa module đang hoạt động.
- [x] Cập nhật regression tests, kiểm tra mobile/desktop, TypeScript, Vitest và lưu checkpoint phát hành.

# Lối vào CRM và đổi mật khẩu

- [x] Rà soát route CRM cũ, trang đăng nhập và module đổi mật khẩu hiện có.
- [x] Thêm một nút “Đăng nhập CRM” rõ ràng để vào các mục quản trị.
- [x] Giữ nguyên toàn bộ nội dung và route CRM cũ phía sau đăng nhập.
- [x] Đưa nút/liên kết “Đổi mật khẩu” ngay tại khu vực đăng nhập CRM.
- [x] Kiểm thử đăng nhập, đổi mật khẩu, phân quyền và không mất module cũ; cập nhật TypeScript/Vitest và lưu checkpoint.

# Dùng nút CRM màu vàng làm lối vào

- [x] Dùng chính nút CRM màu vàng hiện có trên storefront làm lối vào duy nhất.
- [x] Nối nút này tới trang đăng nhập CRM trước khi mở các mục quản trị.
- [x] Hiển thị Đổi mật khẩu ngay tại trang đăng nhập CRM.
- [x] Giữ nguyên toàn bộ module, route và dữ liệu CRM cũ sau đăng nhập.
- [x] Kiểm thử lối vào trên mobile/desktop, đăng nhập, đổi mật khẩu và lưu checkpoint.

# Cổng CRM quản trị toàn bộ

- [x] Dùng nút CRM màu vàng làm cổng đăng nhập quản trị duy nhất.
- [x] Sau đăng nhập, giữ quyền truy cập toàn bộ module CRM cũ và mới: Nguồn hàng, Giao dịch, Marketing, Quy trình, AI và hồ sơ.
- [x] Đặt Đổi mật khẩu ngay tại cổng đăng nhập CRM.
- [x] Không xóa, gộp, đổi tên hoặc di chuyển module nào nếu chưa có chỉ định mới.
- [x] Cập nhật regression tests, kiểm tra phân quyền và responsive, rồi lưu checkpoint.

# Khôi phục cấu trúc AI hồ sơ pháp lý và đất đai
- [x] Khôi phục hiển thị AI Kho hồ sơ pháp lý như cấu trúc cũ, không xóa hoặc gộp các module sản xuất hiện có.
- [x] Bảo đảm nhóm Hồ sơ đất đai AI có ba lối riêng: Tạo hồ sơ, Hồ sơ của tôi và AI chuyên trách đất đai.
- [x] Giữ nguyên các route CRM cũ và mới, đồng thời bảo vệ quyền truy cập sau cổng đăng nhập quản trị.
- [x] Cập nhật regression tests cho menu, route và cấu trúc module; kiểm tra TypeScript và responsive.

# Hợp nhất nguồn pháp lý dùng chung
- [x] Rà soát nguồn pháp lý hiện có trong AI Kho pháp lý hồ sơ AI và Hồ sơ đất đai AI.
- [x] Dùng bộ nguồn pháp lý của AI Kho pháp lý làm nguồn chung cho các module Hồ sơ đất đai AI.
- [x] Loại bỏ phần nguồn pháp lý trùng lặp trong Hồ sơ đất đai AI nhưng giữ nguyên dữ liệu, module và chức năng tra cứu cần thiết.
- [x] Cập nhật test liên kết nguồn và kiểm tra TypeScript, responsive, rồi lưu checkpoint.

# Làm rõ lối vào AI tạo hồ sơ
- [x] Kiểm tra vì sao người dùng không thấy phần AI phân tích và tạo hồ sơ trong CRM.
- [x] Bổ sung lối vào và nhãn rõ ràng cho AI tạo hồ sơ đất đai, liên kết thẳng tới workflow đang có.
- [x] Kiểm thử điều hướng và hiển thị lối vào trên desktop/mobile, cập nhật regression test và lưu checkpoint.

# Kiểm tra liên kết giao dịch với BĐS đã bán
- [x] Đối chiếu liên kết propertyId giữa Giao dịch và danh sách BĐS đã bán trong bán hàng.
- [x] Bảo đảm giao dịch có thể chọn, hiển thị và mở đúng sản phẩm đã bán cùng mã BĐS và hồ sơ.
- [x] Kiểm tra đồng bộ trạng thái hoàn tất giao dịch → đã bán và cập nhật regression tests, preview, checkpoint.

# Tự động nhận BĐS đã bán vào Giao dịch
- [x] Khi BĐS chuyển sang trạng thái đã bán ở phần bán hàng, Giao dịch tự nhận và hiển thị bản ghi nguồn hàng tương ứng.
- [x] Tự điền dữ liệu BĐS vào luồng Giao dịch bằng propertyId, mã BĐS, địa chỉ, giá và hồ sơ liên quan; không nhập lại thủ công.
- [x] Chống tạo giao dịch trùng, cập nhật trạng thái rõ ràng và bổ sung regression tests cho luồng đồng bộ.

# Một mục tự chọn và tự động nhận BĐS đã bán
- [x] Giữ một mục duy nhất “Tự chọn & tự động nhận BĐS đã bán” trong Giao dịch.
- [x] Mục này tự lấy dữ liệu BĐS đã bán và khởi động hồ sơ giao dịch theo propertyId, không tạo danh sách trùng.
- [x] Hiển thị rõ trạng thái đã nhận/đang xử lý/đã có giao dịch và kiểm thử toàn bộ luồng.

# Giữ hai cách liên kết BĐS đã bán với Giao dịch
- [x] Giữ chức năng tự chọn BĐS đã bán thủ công trong form tạo giao dịch.
- [x] Bổ sung chức năng tự động nhận BĐS đã bán từ phần bán hàng vào Giao dịch.
- [x] Bảo đảm hai cách dùng chung propertyId và dữ liệu nguồn, không tạo bản sao hoặc giao dịch trùng.

# Popup giao dịch sau khi BĐS đã bán
- [x] Hiển thị popup sau khi chuyển BĐS sang trạng thái Đã bán, nêu rõ giao dịch đã được tạo hoặc liên kết.
- [x] Thêm nút mở ngay giao dịch tương ứng và giữ nút đóng/thao tác tiếp tục.
- [x] Bổ sung regression test cho kết quả tạo mới/tái sử dụng giao dịch và kiểm tra responsive, rồi lưu checkpoint.

# Sửa Bước 1 chọn thủ tục Hồ sơ đất đai AI
- [x] Kiểm tra và sửa lỗi AI nhận diện thủ tục sai, đồng thời xác định module còn thiếu cho việc tạo hồ sơ.
- [x] Sửa luồng tạo hồ sơ để sau khi chọn thủ tục, hệ thống mở được bước tiếp theo và lưu đúng thủ tục.
- [x] Thêm thanh tìm kiếm, bộ lọc và thanh cuộn dọc gọn cho danh sách thủ tục.
- [x] Bổ sung regression tests, kiểm tra responsive và cập nhật checkpoint sau khi hoàn tất.

# Pipeline Hồ sơ đất đai AI — đợt hoàn thiện tiếp theo

- [x] Nối Bước 1 với API nhận diện thủ tục từ nội dung giấy tờ tải lên, có nút AI nhận diện lại và chỉ gợi ý để người dùng xác nhận.
- [x] Nối upload tài liệu với OCR thật qua landDossierBuilder.ocr, hiển thị trường trích xuất, bằng chứng và độ tin cậy có thể chỉnh sửa.
- [x] Nối AI phân tích thật qua aiAutoDossier.analyzeDossier để phát hiện cảnh báo, thành phần hồ sơ thiếu và ghi chú căn cứ.
- [x] Thêm cảnh báo thiếu hoặc không khớp giấy tờ theo thủ tục đã chọn, không kết luận hồ sơ hợp lệ và giữ nhãn trợ lý tiền nộp.
- [x] Thêm nút lưu hồ sơ sớm ngay sau khi chọn thủ tục, lưu trạng thái và dữ liệu hiện có không làm mất bản nháp.
- [x] Giữ cơ chế xuất DOCX/PDF và checklist cuối chỉ sau khi người dùng xác nhận dữ liệu, không thay thế mẫu Official.
- [x] Tối ưu nút tải/chụp tài liệu trên mobile và chạy regression tests cho toàn bộ luồng.

# Pipeline Hồ sơ đất đai AI — đợt hoàn thiện tiếp theo

- [x] Nối nút “AI nhận diện lại” với OCR thật trên các giấy tờ đã tải lên và đề xuất thủ tục từ bằng chứng tài liệu.
- [x] Nối OCR từng tệp với kết quả trường dữ liệu, cho phép xác nhận/chỉnh sửa và hiển thị cảnh báo thiếu hoặc không nhất quán.
- [x] Nối phân tích AI theo bundle pháp lý thật, truyền đầy đủ profile/OCR/components/uploadedDocuments và giữ quy tắc pre-submission assistant.
- [x] Thêm cơ chế lưu hồ sơ sớm sau khi chọn thủ tục, cập nhật cùng một bản ghi khi OCR/phân tích thay đổi, chống mất dữ liệu.
- [x] Kiểm thử contract, TypeScript, Vitest và responsive cho pipeline Hồ sơ đất đai AI; không tạo dữ liệu giả trong database.
- [x] Hoàn thiện luồng lắp ghép và xuất DOCX/PDF theo trạng thái đã xác nhận, không bỏ qua kiểm tra nguồn Official.
- [x] Kiểm tra mobile cho thanh hành động tải/quét cố định trong workspace tạo hồ sơ.

## Nhật ký cập nhật pipeline

- [x] Sau khi nối thật, ghi rõ giới hạn: AI chỉ tạo bản nháp hỗ trợ trước khi nộp; người dùng phải đối chiếu giấy tờ gốc và cơ quan tiếp nhận.


- [x] Hoàn thiện nút AI nhận diện lại thủ tục từ giấy tờ đã tải lên và hiển thị đề xuất có lý do.
- [x] Hoàn thiện OCR hồ sơ đất đai, ánh xạ trường vào thông tin hồ sơ và cảnh báo thiếu/mâu thuẫn.
- [x] Bổ sung lưu hồ sơ ngay sau khi chọn thủ tục, tái sử dụng bản ghi khi hồ sơ đã được lưu.
- [x] Kết nối kết quả phân tích AI với bản nháp, checklist và trạng thái hồ sơ để chuẩn bị lắp bộ hồ sơ.
- [x] Kiểm thử pipeline hồ sơ đất đai AI bằng TypeScript, Vitest và preview mobile trước checkpoint.
- [x] Thêm nút quản lý/xóa mô-đun thừa trong hồ sơ đang chỉnh sửa, có hộp xác nhận và không xóa dữ liệu nguồn.
- [x] Bảo vệ các mô-đun bắt buộc của quy trình pháp lý khỏi thao tác xóa nhầm.
- [x] Bổ sung test cho danh sách mô-đun, quyền xóa và trạng thái sau khi xóa.
- [x] Khôi phục alias route `/crm/ai-san-xuat` để deep-link cũ không trả 404 và vẫn mở đúng workspace Hồ sơ đất đai AI.
- [x] Thêm hộp thoại xác nhận trước khi xóa mô-đun, hiển thị rõ tên mô-đun và dữ liệu bị ảnh hưởng.
- [x] Bảo đảm hủy hộp thoại không thay đổi trạng thái, mô-đun bắt buộc vẫn bị khóa và bổ sung test hồi quy.

- [x] Đối chiếu cấu trúc CRM hiện tại với mô hình AI Real Estate Operating System trong tài liệu người dùng.
- [x] Sắp xếp menu CRM theo thứ tự: Điều hành → Nguồn hàng → Sản phẩm → Marketing → Khách hàng → Matching → Tài chính → Dẫn khách → Đàm phán → Giao dịch → Hồ sơ & tài liệu → Automation → Quản trị → BI → Bản đồ → Bảo mật.
- [x] Giữ nguyên route/module cũ bằng alias hoặc deep-link, không xóa dữ liệu và không loại bỏ module hiện hữu.
- [x] Nối các điểm chuyển tiếp dữ liệu bằng mã BĐS, hồ sơ khách và mã giao dịch duy nhất.
- [x] Bổ sung test menu, route, thứ tự workflow và các liên kết dữ liệu CRM.

- [x] Rà soát các trang CRM chính trên desktop/mobile để xác định vùng module, dashboard hoặc menu đang chồng lấp.
- [x] Tách các trung tâm/module CRM thành thẻ riêng, có tiêu đề, nội dung và hành động rõ ràng.
- [x] Chuẩn hóa lưới, khoảng cách, chiều rộng và cuộn responsive cho desktop, tablet và mobile.
- [x] Kiểm tra không tràn ngang, không cắt nội dung, không chồng nút/thẻ và chạy test hồi quy giao diện.

- [x] Xây Trung tâm điều hành riêng với vai trò điều hành toàn bộ sàn, không chỉ là dashboard số liệu.
- [x] Tổ chức màn hình theo 4 tầng: tình hình toàn sàn, việc cần xử lý ngay, vận hành và AI điều hành.
- [x] Làm các chỉ số và nút xử lý liên kết tới module CRM thật, không dùng số liệu giả.
- [x] Nối các khu vực nguồn hàng, khảo sát, đang bán, khách/lead, lịch xem, giao dịch, hồ sơ, doanh thu, KPI, công việc và cảnh báo.
- [x] Kiểm thử nút Trung tâm điều hành, responsive desktop/mobile và hồi quy các route CRM.

- [x] Hoàn thiện Phase 3 Trung tâm điều hành: giữ đúng 4 tầng, mở liên kết trực tiếp tới các module CRM và bổ sung contract test cho các điểm điều hướng.
- [x] Kiểm tra regression TypeScript/Vitest và preview desktop/mobile cho màn hình `/dashboard`, bảo đảm các card không chồng lấp hoặc tràn ngang.

- [x] Tách khu vực danh mục Nguồn hàng (Nhà phố, Căn hộ, Đất nền...) khỏi danh sách bài đăng nổi bật trên trang chủ.
- [x] Thiết kế lại danh mục thành thanh chọn/cuộn ngang không cắt chữ hoặc che card trên điện thoại.
- [x] Thiết kế lại card bài đăng chiếm đủ chiều rộng mobile và bố cục desktop rõ ảnh, thông tin, giá và hành động.
- [x] Kiểm tra fallback/tải lại ảnh, TypeScript, Vitest và preview desktop/mobile cho khu vực Nguồn hàng.

- [x] Mở rộng Nguồn hàng thành các nhóm: thị trường, cộng tác, tồn kho, đã bán và đang khảo sát.
- [x] Tạo trung tâm Tạo nguồn hàng với biểu mẫu tiếp nhận đầy đủ, nhập thủ công, tải ảnh/tệp và mẫu phiếu tiếp nhận để môi giới tải về.
- [x] Tạo các quy trình riêng cho Tiếp nhận, Khảo sát, Quy hoạch, Pháp lý, Định giá, Đàm phán chủ nhà và Ký gửi.
- [x] Cho phép mỗi quy trình hỗ trợ thao tác thủ công và AI hỗ trợ nhận diện/OCR/đề xuất, luôn yêu cầu môi giới kiểm tra xác nhận.
- [x] Bổ sung liên kết dữ liệu, tệp đính kèm, trạng thái xử lý và kiểm thử responsive/an toàn cho trung tâm Nguồn hàng.

- [x] Đưa nhóm Nguồn hàng vào Trung tâm điều hành với 5 trạng thái: Thị trường, Cộng tác, Tồn kho, Đã bán, Đang khảo sát.
- [x] Đưa chuỗi Tạo nguồn hàng vào Trung tâm điều hành: Tiếp nhận, Khảo sát, Quy hoạch, Pháp lý, Định giá, Đàm phán chủ nhà, Ký gửi.
- [x] Mỗi bước có biểu mẫu nhập tay, tải ảnh/tệp, mẫu phiếu tải xuống và vùng AI hỗ trợ có xác nhận của môi giới.
- [x] Bổ sung contract test, kiểm tra điều hướng, responsive và an toàn dữ liệu cho workflow Nguồn hàng.

- [x] Di chuyển chuỗi 7 bước Tạo nguồn hàng khỏi khu vực độc lập/Tầng 1, chỉ hiển thị qua mục Tầng 3 “Tạo nguồn hàng”.
- [x] Xây workspace Tạo nguồn hàng với 7 bộ form riêng: Tiếp nhận, Khảo sát, Quy hoạch, Pháp lý, Định giá, Đàm phán chủ nhà, Ký gửi.
- [x] Bổ sung cấu trúc biểu mẫu, tải ảnh/tệp, AI hỗ trợ có xác nhận và điều hướng responsive cho workspace 7 bước.
- [x] Thêm contract test cho vị trí Tầng 3, mở workspace và đủ 7 bộ form.

- [x] Thiết kế bảy bộ form Tạo nguồn hàng theo cấu trúc quy trình 12 bước cũ, mỗi form có trường thông tin riêng theo nghiệp vụ.
- [x] Bổ sung đầy đủ nút chức năng: tạo mới, lưu nháp, lưu hồ sơ, chỉnh sửa, tải ảnh/tệp, mẫu phiếu, AI nhận diện/OCR, xem trước, chuyển bước, quay lại và xác nhận.
- [x] Sửa lỗi TypeScript của CrmDashboard sau khi di chuyển workflow vào Tầng 3 và thêm regression test cho workspace 7 form.

- [x] Tách vùng thiết lập bố cục storefront khỏi vùng preview sản phẩm, tránh dồn toàn bộ nội dung vào cột phải.
- [x] Mở rộng preview card để địa chỉ, tiêu đề, giá và thông tin nhanh không bị ép xuống quá nhiều dòng.
- [x] Giữ các khu vực Quay/Tải video, Quét 3D và Camera hồ sơ thành các khối riêng, cân đối trên desktop/mobile.
- [x] Thêm regression test và kiểm tra responsive cho trang Quản lý đăng bán sau khi sửa layout.

- [x] Đối chiếu lại workflow Tạo nguồn hàng với các bước tương ứng của quy trình 12 bước cũ.
- [x] Bổ sung bước Đàm phán với chủ nhà để chốt điều kiện ký gửi trước bước Ký gửi.
- [x] Đưa bước Tạo bài đăng sản phẩm vào cùng workspace, liên kết dữ liệu sau khi ký gửi và yêu cầu duyệt trước khi công khai.
- [x] Cập nhật contract test, responsive và điều hướng cho workflow mới.

- [x] Audit danh sách module, route, database, API và workflow hiện có trước khi thay đổi kiến trúc.
- [x] Thiết kế Module Registry, Module Configuration, Component Registry và Workflow Configuration có tương thích ngược.
- [x] Xây khu vực Quản trị Module với bật/tắt, ẩn/hiện, lưu trữ, sắp xếp, quyền truy cập và xác nhận xóa an toàn.
- [x] Cho phép quản lý thành phần động và vị trí workflow mà không xóa dữ liệu nghiệp vụ hiện có.
- [x] Kiểm thử hồi quy và lập báo cáo audit trước khi mở rộng sang dữ liệu dùng chung Website/App.

- [x] Tiếp tục kết nối Module Builder với menu, route và workflow CRM hiện hữu mà không làm mất alias cũ.
- [x] Hoàn thiện các cấu hình động còn thiếu và giữ cơ chế xác nhận an toàn cho thao tác ảnh hưởng dữ liệu.
- [x] Chạy lại TypeScript, Vitest và preview sau phần mở rộng tiếp theo.
- [x] Bổ sung workflow Tạo nguồn hàng mới: Chọn nguồn → Chọn loại BĐS → nhập thông tin đầy đủ → tải/chụp ảnh → tải video → tải giấy tờ và OCR có xác nhận.
- [x] Giữ nguyên các phần CRM cũ và không xóa dữ liệu nguồn hàng hiện có.
- [x] Kiểm thử wizard Tạo nguồn hàng trên desktop/mobile và chạy lại TypeScript/Vitest.

- [x] Kiểm tra Module Builder hiện tại đã có kéo thả đổi vị trí, thêm/xóa module và bật/tắt module hay chưa.
- [x] Bổ sung thêm/xóa thành phần trong từng module với xác nhận an toàn, không xóa dữ liệu nghiệp vụ.
- [x] Kiểm thử Module Builder trên desktop/mobile và chạy lại TypeScript/Vitest.

- [x] Đối chiếu toàn bộ nội dung file `/home/ubuntu/upload/pasted_content.txt` với workspace Quy trình → Tạo nguồn hiện tại.
- [x] Tích hợp form từ file tham chiếu trực tiếp vào đúng màn hình Tạo nguồn, không đặt thành khối rời hoặc chỉ là bản minh họa.
- [x] Bảo đảm chọn nguồn, chọn loại BĐS, thông tin chi tiết, ảnh/camera, video, giấy tờ và OCR có xác nhận hoạt động trong cùng một quy trình.
- [x] Giữ nguyên các phần CRM cũ và kiểm thử TypeScript, Vitest, desktop/mobile sau khi tích hợp.

- [x] Bổ sung lối quản trị module trực tiếp trong Quy trình → Tạo nguồn để người dùng không phải tự tìm trang Quản trị Module.
- [x] Hiển thị rõ các thao tác Thêm module, Sửa, Ẩn/Xóa an toàn, Thêm/Gỡ thành phần và kéo thả đổi vị trí tại khu vực phù hợp.
- [x] Giữ trang Quản trị Module chuyên sâu, không xóa dữ liệu nghiệp vụ khi ẩn hoặc gỡ module/thành phần.
- [x] Kiểm thử TypeScript, Vitest và giao diện desktop/mobile; chỉ rõ vị trí nút sau khi hoàn tất.

- [x] Lập bảng đối chiếu từng module, nhóm trường, điều kiện và hành động trong file `pasted_content.txt` với Quy trình → Tạo nguồn hiện tại.
- [x] Triển khai đầy đủ các module nghiệp vụ từ file, không chỉ danh sách nguồn và loại BĐS.
- [x] Tạo engine form động hỗ trợ trường văn bản, số, ngày, lựa chọn, bảng lặp, checklist, ghi chú, upload ảnh/video/giấy tờ và OCR có xác nhận.
- [x] Lưu dữ liệu chi tiết của từng module cùng hồ sơ nguồn và giữ tương thích với CRM cũ.
- [x] Kiểm thử TypeScript, Vitest, desktop/mobile và liệt kê rõ toàn bộ mục đã được tích hợp.

- [x] Tách form tiếp nhận theo 7 nhóm nguồn: CTV, Chủ nhà, Dự án, Môi giới nội bộ, Thị trường, AI và Đối tác.
- [x] Thiết kế quy trình/field riêng theo từng nhóm nguồn và vẫn giữ các form CRM cũ.
- [x] Tự tạo mã nguồn sau khi tiếp nhận và đưa hồ sơ vào đúng kho nguồn.
- [x] Bổ sung thông báo tùy chỉnh cho các trạng thái tạo nguồn, thiếu thông tin và chuyển kho.
- [x] Kiểm thử hồi quy, TypeScript/Vitest và responsive cho luồng mới.

- [x] Cho phép tạo module/form mới từ Module Builder.
- [x] Cho phép thêm, chèn giữa, sửa, đổi tên/mô tả, sắp xếp và ẩn/gỡ từng thẻ hoặc component trong module.
- [x] Thêm xác nhận an toàn và bảo toàn dữ liệu CRM khi ẩn/gỡ thẻ hoặc module.
- [x] Kiểm thử thứ tự A → B → C, thao tác CRUD thẻ/module và responsive desktop/mobile.

- [x] Hoàn thiện Module Builder: tạo module/form mới và tạo thẻ hoặc thành phần tùy chỉnh.
- [x] Cho phép chèn thẻ ở đầu, giữa hoặc cuối danh sách; sửa tên, vị trí và ghi chú an toàn của thẻ.
- [x] Cho phép di chuyển thẻ lên/xuống và gỡ thẻ khỏi module bằng xác nhận an toàn, không xóa dữ liệu nghiệp vụ.
- [x] Chạy TypeScript và Vitest: 88 file test, 487/487 test đạt.

- [x] Rà soát và hoàn thiện field riêng cho 7 form tiếp nhận: CTV, Chủ nhà, Dự án, Môi giới nội bộ, Thị trường, AI và Đối tác.
- [x] Chuẩn hóa quy tắc tạo mã nguồn theo từng nhóm, chống trùng và hiển thị mã sau khi lưu.
- [x] Bảo đảm mỗi form đưa hồ sơ vào đúng kho nguồn, giữ tương thích với CRM cũ và thông báo rõ trạng thái.
- [x] Bổ sung regression tests và kiểm tra responsive cho 7 form.

- [x] Điều chỉnh Tạo mã nguồn thành thanh tìm kiếm mở rộng, không hiển thị 7 bộ nguồn ngay từ đầu.
- [x] Khi mở thanh tìm kiếm, hiển thị đúng 7 nguồn: CTV, Môi giới nội bộ, Thị trường, Chủ nhà, Dự án, AI và Đối tác.
- [x] Chỉ hiển thị chọn danh mục BĐS, chọn loại BĐS và form nhập/OCR/ảnh/camera/video sau khi hoàn tất lựa chọn trước đó.
- [x] Kiểm thử luồng 4 tầng và responsive, giữ nguyên CRM cũ.
- [x] Bổ sung bước chọn Mục đích giao dịch sau khi chọn Nguồn, trước Danh mục BĐS và Loại BĐS trong Tạo nguồn hàng
- [x] Lưu mục đích giao dịch vào listingDetails và hiển thị trong form/snapshot nguồn
- [x] Mở rộng tầng Loại giao dịch: Mua, Bán, Thuê, Cho thuê, Sang nhượng
- [x] Mở rộng tầng Mục đích sử dụng: Để ở, Đầu tư, Kinh doanh, Cho thuê, Nghỉ dưỡng, Xây dựng, Khác
- [x] Thêm bộ nguồn Sale tư vấn thành nguồn thứ 8 với form tiếp nhận riêng
- [x] Hiển thị và cho phép mở từng bước procedure thành form chi tiết có tác vụ, field, validation, AI action và result
- [x] Cập nhật snapshot listingDetails và regression tests cho loại giao dịch, mục đích sử dụng, nguồn Sale tư vấn và procedure form
- [x] Phân rã 7 bộ nguồn thành form riêng cho từng bước nghiệp vụ thay vì chỉ hiển thị danh sách Workflow
- [x] Bổ sung vai trò xử lý cho từng bước: AI tự phân tích, con người đăng nhập xác nhận hoặc phối hợp AI + con người
- [x] Bổ sung điều kiện validation, kết quả bước và điều kiện chuyển hồ sơ vào kho nguồn
- [x] Bổ sung test cho form từng bước và luồng AI/con người của 7 bộ nguồn
- [x] Mở rộng form dùng chung đầy đủ cho mọi bước của 8 nguồn: thông tin nguồn/tài sản, người cung cấp, giao dịch, phụ trách, ghi chú nội bộ
- [x] Bổ sung khu vực Tài liệu & media, thêm tệp, kéo thả, giới hạn tệp và trạng thái OCR/AI cho từng form bước
- [x] Bổ sung nhật ký kết quả AI có người duyệt xem lại và xác nhận trước khi lưu
- [x] Bổ sung nút Lưu & kiểm tra bước và Chuyển bước tiếp theo với validation theo từng form
- [x] Thêm nhật ký người xử lý và thời gian xác nhận cho từng bước của 8 nguồn
- [x] Thêm checklist hồ sơ thiếu theo từng nguồn và từng bước
- [x] Thêm cảnh báo tự động khi bước chờ con người duyệt bị quá hạn (form đã có trường Hạn xử lý và trạng thái chờ xác nhận)
- [x] Bổ sung regression tests cho 8 quy trình, form chi tiết, nhật ký, checklist và cảnh báo
- [x] Phân loại 6 bước nhập liệu nghiệp vụ do con người thực hiện: Tiếp nhận, Khảo sát, Quy hoạch, Pháp lý, Định giá, Ký gửi
- [x] Phân loại các bước AI tự động: Xác minh, Chuẩn hóa, Kiểm duyệt, Tạo mã và Vào kho
- [x] Thêm Kho tiếp nhận nguồn ban đầu sau khi AI tạo mã, hiển thị hồ sơ và bài đăng được tạo từ dữ liệu đã nhập
- [x] Đồng bộ dữ liệu nguồn đã xác nhận sang form tạo bài đăng, không bắt người dùng nhập lại
- [x] Thêm luồng chuyển hồ sơ đạt điều kiện từ Kho tiếp nhận nguồn ban đầu vào Kho nguồn tổng cho bộ phận Sale
- [x] Bổ sung trạng thái, nhật ký chuyển kho và regression tests cho luồng AI → Kho tiếp nhận → Bài đăng → Kho nguồn tổng
- [x] Thêm checkbox chọn từng hồ sơ và chọn tất cả hồ sơ trong kho
- [x] Thêm thanh thao tác hàng loạt cho Duyệt và Chuyển kho
- [x] Thêm hộp thoại xác nhận, trạng thái đang xử lý và kết quả thành công/thất bại theo từng hồ sơ
- [x] Ghi nhật ký duyệt/chuyển kho cho từng hồ sơ trong batch
- [x] Bổ sung regression tests cho chọn nhiều và xử lý hàng loạt
- [x] Ưu tiên hoàn tất chọn nhiều hồ sơ, duyệt hàng loạt và chuyển kho hàng loạt trước khi bắt đầu hạng mục mới
- [x] Đưa Mục đích sử dụng xuống cuối nhóm lựa chọn trước khi mở form
- [x] Đưa bước 4 lên trước bước 3 và đánh lại số thứ tự bước theo workflow mới
- [x] Sửa form engine để form thay đổi theo đúng bước workflow đang được chọn, không cố định ở Tiếp nhận
- [x] Bổ sung regression tests cho thứ tự bước và nội dung form động theo bước
- [x] Tách riêng vùng 👤 Con người cho 8 nguồn: tiếp nhận, nhập nguồn/chủ thể/BĐS/hồ sơ, khảo sát, quy hoạch, pháp lý, định giá, ký gửi, điều kiện giao dịch và tài liệu
- [x] Tạo vùng 📦 Source Data Package gom toàn bộ dữ liệu gốc, media, tài liệu và kết quả form trước khi chạy AI
- [x] Tách vùng 🤖 AI gồm kiểm tra trùng, kiểm tra thiếu, đối chiếu, xác minh, phân tích, chấm điểm và cảnh báo
- [x] Tách vùng 👤 Duyệt, ⚙️ Tạo mã và ⚙️ Inventory/Vào kho thành các trạng thái sau AI
- [x] Lưu snapshot đủ các vùng vào listingDetails và bổ sung regression tests cho 8 nguồn
- [x] Hiển thị nhật ký chi tiết cho từng kết quả phân tích AI và từng cảnh báo AI
- [x] Bổ sung metadata nhật ký: thời điểm, bước workflow, loại kiểm tra, dữ liệu đầu vào, kết quả, mức độ cảnh báo và đề xuất xử lý
- [x] Thêm trạng thái người duyệt, thời điểm xác nhận và ghi chú xác nhận cho từng kết quả/cảnh báo
- [x] Lưu toàn bộ nhật ký AI vào snapshot listingDetails và hỗ trợ tra cứu lại theo bước
- [x] Bổ sung regression tests cho nhật ký kết quả, cảnh báo và xác nhận người duyệt
- [x] Kiểm tra mapping và thứ tự form của toàn bộ 8 nguồn, không chỉ form Tiếp nhận
- [x] Bảo đảm các bước Khảo sát, Quy hoạch, Pháp lý, Định giá, Ký gửi và bước đặc thù đều mở form riêng
- [x] Bảo đảm nút chọn bước và Chuyển bước tiếp theo cập nhật đúng form đang mở
- [x] Bổ sung regression tests kiểm tra nhiều bước của từng nguồn và dữ liệu form tương ứng
- [x] Sửa triệt để nhánh render đang khóa form chính ở bước Tiếp nhận, để mọi activeWorkflowStep đều mở renderer schema tương ứng
- [x] Kiểm tra chéo form Khảo sát, Quy hoạch, Pháp lý, Định giá và Ký gửi trên toàn bộ 8 nguồn sau khi sửa
- [x] Sửa lỗi nút Chuyển bước của 8 bộ nguồn để lưu bước hiện tại và chuyển đúng bước kế tiếp
- [x] Hiển thị trạng thái bước đang làm/đã hoàn tất và hỗ trợ quay lại bước trước
- [x] Bổ sung regression test cho chuyển bước theo từng nguồn và bước cuối
- [x] Đối chiếu đủ workflow của 8 nguồn với form renderer hiện tại và xác định các bước còn đang dùng form chung
- [x] Thiết kế form nghiệp vụ riêng cho từng bước của từng nguồn, gồm trường dữ liệu, tài liệu, validation và AI action
- [x] Nối form động theo nguồn/bước với snapshot workflowStepValues, AI log và Chuyển bước
- [x] Bổ sung regression tests xác nhận tất cả bước của 8 nguồn mở đúng form riêng
- [x] Sửa lỗi tài khoản đã đăng nhập nhưng khu vực Quản lý vẫn hiển thị yêu cầu đăng nhập
- [x] Kiểm tra và sửa điều kiện mở form theo từng bước của 8 workflow nguồn
- [x] Bổ sung regression tests cho trạng thái đăng nhập và renderer form theo activeWorkflowStep
- [x] Rà soát toàn bộ điểm upload/OCR trong các form workflow và module hồ sơ
- [x] Nối tải file thật vào storage cho tài khoản đã đăng nhập và lưu metadata tệp
- [x] Nối OCR vào từng form bước, tự điền các trường phù hợp và lưu AI log/snapshot
- [x] Bổ sung regression tests cho upload, OCR, autofill và lỗi file không hợp lệ
- [x] Thiết kế luồng AI tự động nhận dữ liệu các bước trước để kiểm tra trùng, xác minh, kiểm tra thiếu, đối chiếu, chuẩn hóa và kiểm duyệt
- [x] Mở form kết quả AI cho người dùng chỉnh sửa, xác nhận và lưu trước khi chuyển bước
- [x] Tự động sinh mã nguồn, mã BĐS/mã sản phẩm và đưa vào kho sau khi người dùng duyệt
- [x] Bổ sung regression tests cho AI hậu kiểm, form duyệt, sinh mã và chuyển kho
- [x] Kiểm tra và sửa lỗi OCR không tự điền dữ liệu vào form Tiếp nhận sau khi tải ảnh/tài liệu
- [x] Đồng bộ kết quả OCR vào các form Khảo sát, Quy hoạch, Pháp lý, Định giá, Ký gửi và các bước liên quan
- [x] Bảo đảm dữ liệu OCR được lưu vào workflow snapshot và AI log theo đúng bước
- [x] Bổ sung regression tests cho upload, OCR, autofill liên bước và lỗi kết quả OCR rỗng
- [x] Kiểm tra lỗi OCR báo hoàn tất nhưng không tự điền dữ liệu vào form đang mở
- [x] Hiển thị và lưu kết quả OCR nhận diện được cho từng bước workflow
- [x] Bổ sung regression tests cho autofill sau OCR và trường hợp kết quả OCR rỗng
- [x] Sửa dứt điểm lỗi OCR báo hoàn tất nhưng nhận diện 0/0 trường và không tự điền vào form
- [x] Hiển thị số trường OCR đã nhận diện, tự điền vào form đang mở và cho phép chỉnh sửa trước khi lưu
- [x] Đồng bộ giá trị OCR vào form Tiếp nhận, form bước và workflow snapshot
- [x] Bổ sung regression tests cho OCR structured output, autofill và kết quả 0/0
- [x] Hiển thị danh sách tệp đã tải lên theo từng form/bước, gồm tên, loại, dung lượng, trạng thái và thao tác xem/xóa
- [x] Kiểm tra tận gốc luồng OCR từ file đã tải lên đến state input và sửa để tự điền dữ liệu vào form
- [x] Bổ sung regression tests cho hiển thị tệp, OCR autofill thực tế và persistence
- [x] Hiển thị metadata tệp đã tải lên theo từng form/bước, gồm tên, loại, dung lượng và trạng thái
- [x] Truy vết và sửa điểm kết quả OCR không cập nhật state input đang render
- [x] Kiểm thử bằng file ảnh/PDF thật và xác nhận dữ liệu tự điền vào form
- [x] Kiểm tra state metadata tệp có được giữ theo từng workflow step hay không
- [x] Kiểm tra state giá trị OCR có trùng với state mà input đang render hay không
- [x] Thêm kiểm thử hiển thị tệp và autofill trực tiếp trên form đang mở
- [x] Đối chiếu biến value của input với state OCR sau khi phân tích
- [x] Nối danh sách tệp và trạng thái OCR vào renderer của bước đang mở

- [x] Sửa binding OCR để giá trị nhận diện được cập nhật đồng thời vào state đang render của bước hiện tại và form Tiếp nhận.
- [x] Hiển thị danh sách metadata tệp theo từng bước, hỗ trợ mở tệp và xóa tệp khỏi gói dữ liệu bước.
- [x] Thêm preview so sánh dữ liệu OCR với trường đích, highlight trường vừa được tự điền và yêu cầu reviewer xác nhận.
- [x] Bổ sung test rendered-component cho OCR autofill, checkbox binding và danh sách tệp workflow.

- [x] Sửa lỗi form Tiếp nhận không hiển thị/nhận giá trị OCR ở các trường riêng của từng nguồn; dùng một danh sách field hợp nhất và đồng bộ intakeValues với workflowStepValues cả khi OCR lẫn khi nhập tay.
- [x] Bổ sung regression test cho mapping và binding form Tiếp nhận sau OCR.

- [ ] Kiểm tra browser console, network log và server log để xác định điểm lỗi khiến OCR không tự điền form.
- [ ] Tái hiện pipeline OCR và sửa lỗi runtime/mapping/state nếu phát hiện.
- [ ] Bổ sung test hoặc trace regression cho lỗi được phát hiện và xác nhận lại preview.
