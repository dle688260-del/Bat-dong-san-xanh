# Nguồn biểu mẫu đất đai đã tra cứu

- Cơ sở dữ liệu thủ tục hành chính: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fd07c1846d6e054 — kết quả tìm kiếm hiển thị Mẫu số 09/ĐK.
- Cơ sở dữ liệu thủ tục hành chính: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3feb61d7b430b1d1 — kết quả tìm kiếm hiển thị file Mus15DKLD.docx, dùng cho Đơn đăng ký đất đai, tài sản gắn liền với đất.
- Cổng Dịch vụ công Quốc gia, thủ tục đăng ký đất đai/cấp Giấy chứng nhận: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
- Cổng Dịch vụ công Quốc gia, thủ tục cấp đổi Giấy chứng nhận: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783
- Hệ thống văn bản Chính phủ, Luật Đất đai 31/2024/QH15: https://vanban.chinhphu.vn/?pageid=27160&docid=211189
- Hệ thống văn bản Chính phủ, Nghị định 151/2025/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=213927

Ghi chú: Cổng tải file bị trình duyệt sandbox chặn khi mở trực tiếp; không coi snippet tìm kiếm là nội dung pháp lý đầy đủ. Catalog giao diện phải ghi rõ nguồn, tên file, trạng thái cần đối chiếu địa phương và không gắn nhãn văn bản chính thức cho bản AI tự điền.

## Nguồn bổ sung ngày 2026-08-17

- Cơ sở dữ liệu thủ tục hành chính: https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe07820acca4924 — kết quả tìm kiếm hiển thị tên “Phụ lục II.doc”, mô tả có mẫu đề nghị cấp Giấy chứng nhận; trình duyệt sandbox bị chặn khi mở trực tiếp nên chưa tải và chưa đưa vào mẫu xuất.
- Nghị định 151/2025/NĐ-CP trên Cổng thông tin điện tử Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=213927 — nguồn căn cứ phân định thẩm quyền chính quyền địa phương 02 cấp trong lĩnh vực đất đai.

Ghi chú: Không được coi file là mẫu chính thức đã tích hợp cho đến khi tải được file gốc, kiểm tra nội dung/phiên bản và lưu metadata nguồn đầy đủ.

## Đối chiếu nguồn địa phương ngày 2026-08-17

- Hưng Yên, phiếu hướng dẫn thủ tục: https://dichvucong.hungyen.gov.vn/block/phieu-huong-dan/thu-tuc/67161 — xác nhận thủ tục đăng ký đất đai/cấp Giấy chứng nhận lần đầu, cơ quan giải quyết UBND phường Phố Hiến; thành phần hồ sơ nêu rõ “Đơn đăng ký đất đai, tài sản gắn liền với đất — Mus15DKLD.docx”, 01 bộ; phương thức trực tiếp/trực tuyến/bưu chính.
- Phú Lý/Ninh Bình, thủ tục mã 1.013978.H42: https://phuly.ninhbinh.gov.vn/thu-tuc-hanh-chinh/dang-ky-dat-dai-tai-san-gan-lien-voi-dat-cap-giay-chung-nhan-quyen-su-dung-dat-quyen-so-huu-tai-san-gan-lien-voi-dat-lan-dau-doi-voi-ho-gia-dinh-ca-nhan-cong-dong-dan-cu-nguoi-goc-viet-nam-dinh-cu-o-nuoc-ngoai — nêu Mẫu 15, Mẫu 16, Mẫu 17 và Mẫu 19 theo Nghị định 151/2025/NĐ-CP, cấp thực hiện cấp xã và thời hạn thay đổi theo hình thức nộp/địa bàn.

Kết luận triển khai: có thể xây registry mapping thủ tục → mẫu gốc/nguồn, nhưng chưa được đánh dấu “đã tích hợp file gốc” nếu endpoint tải file chính thức vẫn không tải được và chưa kiểm tra binary/template fields.

## Xác minh bộ hồ sơ tổng hợp đăng ký biến động

Nguồn chính: Cổng Dịch vụ công Quốc gia, thủ tục mã `2.000889`, trang `https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889`.

Bộ hồ sơ đăng ký biến động do chuyển nhượng cần được dựng theo điều kiện, không mặc định giống nhau cho mọi trường hợp. Thành phần lõi gồm Đơn đăng ký biến động theo Mẫu số 09/ĐK, hợp đồng hoặc văn bản chuyển quyền phù hợp, bản gốc Giấy chứng nhận đã cấp và các giấy tờ phát sinh theo giao dịch. Khi phát sinh nghĩa vụ tài chính, cơ quan đăng ký đất đai gửi thông tin địa chính để cơ quan thuế xác định nghĩa vụ.

Nguồn biểu mẫu được tham chiếu: `mau so 09-ĐK.docx`, URL tải `https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=3fe4648992ad74c2`. Cần kiểm tra binary trước khi sử dụng làm template gốc.

Nguồn thứ hai: thủ tục đăng ký đất đai/cấp Giấy chứng nhận mã `1.013978`, trang `https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978`, có tham chiếu `Mus15DKLD.docx` và nhóm Mẫu 16, Mẫu 17, Mẫu 19 theo Nghị định 151/2025/NĐ-CP trong các bước liên quan.

Thiết kế registry: khi chọn đăng ký biến động do chuyển nhượng, AI tạo một bộ gồm Mẫu 09/ĐK, hợp đồng/văn bản chuyển quyền, Giấy chứng nhận, nhóm xác định nghĩa vụ tài chính và các giấy tờ phát sinh. Tờ khai thuế thu nhập cá nhân và tờ khai lệ phí trước bạ phải được đánh dấu “cần xác định/phát sinh theo trường hợp”, căn cứ vào loại giao dịch, miễn giảm và hướng dẫn cơ quan thuế; không được mặc định mọi hồ sơ đều có cùng mẫu thuế.

Các mẫu thuế/lệ phí chỉ được gắn vào bộ hồ sơ sau khi xác định đúng trường hợp và nguồn biểu mẫu tương ứng. Bản AI tự điền phải giữ trạng thái bản nháp hỗ trợ, không gắn nhãn văn bản do cơ quan nhà nước cấp.
