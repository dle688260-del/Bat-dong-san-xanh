# Bằng chứng cơ chế tải file mẫu DVC — 2026-08-20

Trang thủ tục: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789

Trang chi tiết được liên kết: https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=348167

Kết quả HTML thực tế của trang chi tiết cho thấy DVC không dùng href trực tiếp cho mẫu. Ví dụ tên file được hiển thị trong span với JavaScript: `downloadMaudon('3fd87368b77cb67c')` và nhãn `Mus14a14b14c14d.docx`; `downloadMaudon('3fe5a2f17d7b2b1e')` và nhãn `Mus14.docx`; `downloadMaudon('3fe4958e71230250')` và nhãn `Mus14a14b14c14d.docx`. Vì vậy parser chỉ đọc tên/metadata nhưng không thể tải file nếu chưa thực thi resolver.

JavaScript chính thức của DVC định nghĩa `getUrlDownload()` gọi POST REST endpoint `/jsp/rest.jsp` với payload `{service: "get_url_downfile", provider: "dvcquocgia", type: "ref"}`. Phản hồi thực tế là `[{'URL_DOWNLOAD':'https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp'}]`. Hàm `downloadMaudon(code)` mở `${URL_DOWNLOAD}?ma=${code}`.

Đã kiểm tra endpoint xuất chi tiết: `https://vpcp.dichvucong.gov.vn/jsp/tthc/export/export_word_detail_tthc.jsp?maTTHC=1.012789&idTTHC=348167` trả HTTP 200, `Content-Type: application/msword`, `Content-disposition: attachment; filename=ChiTietTTHC_1.012789.doc`, kích thước 6081 bytes; `file` nhận diện Microsoft Word 2007+. Đây là file chi tiết thủ tục, khác với từng mẫu Mus*.docx.

Kết luận kỹ thuật: trạng thái Pending hiện tại là do scanner chỉ thu tên file hoặc URL trực tiếp, trong khi DVC công bố mã mẫu qua `downloadMaudon(code)`. Resolver cần: theo link trang chi tiết; lấy URL_DOWNLOAD qua `/jsp/rest.jsp`; tạo URL `https://csdl.dichvucong.gov.vn/web/jsp/download_file.jsp?ma=<code>`; tải byte; xác minh checksum/signature/fillability; rồi gắn file theo tên mẫu vào component tương ứng.

## Pipeline chuẩn theo mã thủ tục 1.012789

Nguồn người dùng yêu cầu đọc: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789

Mã thủ tục phải là khóa chính của snapshot. Scanner cần lấy từ trang/endpoint chi tiết: tên thủ tục, trình tự thực hiện, cách thức nộp, cơ quan tiếp nhận/thực hiện, thời hạn, phí/lệ phí, điều kiện, toàn bộ thành phần hồ sơ và file mẫu. Mỗi file mẫu phải được resolve từ metadata/nút tải/API của DVC, gắn vào đúng component, tải byte nếu endpoint khả dụng, lưu checksum/provenance và chỉ qua Official gate sau khi xác minh.

Nguồn Chính phủ đối chiếu pháp lý cho Nghị định 151/2025/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=213927. Nguồn này dùng để đối chiếu mẫu 49 và căn cứ pháp lý, không thay thế xác minh file mẫu DVC.

Nguồn DVC địa phương đã đọc để xác định cấu trúc mẫu 49: https://dichvucong.bentre.gov.vn/block/phieu-huong-dan/thu-tuc/70115 và https://tthc.hue.gov.vn/Content/Thutuc/chitiet.aspx?iThuTuc=23585. Hai nguồn mô tả thủ tục có Mẫu số 49/Mus49.docx và trích lục vị trí khu đất.

## Bổ sung phân tích đường tải

HTML thực tế của trang chi tiết DVC 1.012789 công bố các mã file: `Mus14a14b14c14d.docx` với mã `3fd87368b77cb67c`, `Mus14.docx` với mã `3fe5a2f17d7b2b1e`, và bản `Mus14a14b14c14d.docx` với mã `3fe4958e71230250`. JavaScript gọi `downloadMaudon(code)`, lấy `URL_DOWNLOAD` qua service `get_url_downfile`, sau đó mở `URL_DOWNLOAD?ma=code`. Resolver phải giữ mã file, session/cookie và Referer của trang chi tiết; không được dùng host test hoặc URL nội bộ làm nguồn Official.
