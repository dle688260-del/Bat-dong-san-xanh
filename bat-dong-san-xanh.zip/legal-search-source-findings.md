# Khảo sát nguồn tra cứu văn bản pháp luật

Ngày khảo sát: 2026-08-18.

## Nguồn ưu tiên

1. Hệ thống văn bản của Cổng Thông tin điện tử Chính phủ: https://chinhphu.vn/he-thong-van-ban
   - Nguồn chính thức để tra cứu hệ thống văn bản của Chính phủ, trong đó có nghị định.

2. Cơ sở dữ liệu quốc gia về pháp luật: https://vbpl.vn/
   - Nguồn chính thức để tra cứu luật, nghị định, thông tư và văn bản pháp luật khác.

3. Cổng Pháp luật quốc gia: https://phapluat.gov.vn/
   - Cổng thông tin pháp luật quốc gia, có khu vực văn bản pháp luật và cơ sở dữ liệu pháp luật.

## Nguồn đối chiếu

4. LuatVietnam: https://luatvietnam.vn/van-ban/tim-van-ban.html
   - Nguồn đối chiếu, không nên dùng làm nguồn Official duy nhất nếu chưa đối chiếu với nguồn nhà nước.

5. Thư viện Pháp luật: https://thuvienphapluat.vn/
   - Nguồn tham khảo/đối chiếu, cần lưu nhãn provenance riêng.

## Quy tắc triển khai

- Khi người dùng nhập tên hoặc số hiệu như “Nghị định 102”, hệ thống cần tìm nhiều nguồn, ưu tiên chinhphu.vn, vbpl.vn và phapluat.gov.vn.
- Không coi một kết quả tìm kiếm đơn lẻ là bản chính thức; cần hiển thị nguồn, ngày kiểm tra, số hiệu, ngày ban hành, hiệu lực và tệp đính kèm.
- Nếu có nhiều phiên bản hoặc văn bản sửa đổi/thay thế, không ghi đè bản cũ trước khi người dùng xác nhận.
- LuatVietnam và Thư viện Pháp luật chỉ là nguồn đối chiếu cho đến khi có URL/tệp chính thức tương ứng.

## Từ khóa văn bản do người dùng cung cấp

Tệp người dùng gửi liệt kê các từ khóa cần hỗ trợ tra cứu, gồm Nghị định 101/2024/NĐ-CP về điều tra cơ bản đất đai, đăng ký/cấp Giấy chứng nhận và hệ thống thông tin đất đai; Nghị định 102/2024/NĐ-CP hướng dẫn Luật Đất đai; Nghị định 103/2024/NĐ-CP về tiền sử dụng đất, tiền thuê đất; Nghị định 104/2024/NĐ-CP về Quỹ phát triển đất; Nghị định 123/2024/NĐ-CP về xử phạt vi phạm hành chính trong lĩnh vực đất đai; Nghị định 71/2024/NĐ-CP về giá đất; Nghị định 88/2024/NĐ-CP về bồi thường, hỗ trợ, tái định cư; và các thông tư đất đai năm 2024.

Nội dung trong tệp là bài tổng hợp bên thứ ba, chỉ dùng làm từ khóa tìm kiếm. Không được gắn nhãn Official hoặc tự động áp dụng trước khi đối chiếu với Cổng Thông tin điện tử Chính phủ, Cơ sở dữ liệu quốc gia về pháp luật, Cổng Pháp luật quốc gia hoặc cơ quan ban hành; cần kiểm tra hiệu lực, sửa đổi/thay thế và tệp gốc.
