# Audit Kho AI pháp lý và module lập hồ sơ — 2026-08-21

## Phạm vi đã kiểm tra

Đã đối chiếu App.tsx, AILegalKnowledgeBase.tsx, AIDossierAdmin.tsx và AiLandDossierAutoModule.tsx; đồng thời chụp preview các route Kho AI pháp lý, hồ sơ đất đai, hồ sơ đất đai tự động và các route liên quan.

## Phát hiện chính

1. **AiLandDossierAutoModule** đã có catalog động qua `aiAutoDossier.catalog`, chọn thủ tục, chọn tỉnh, discovery/build plan, đồng bộ batch, upload file, OCR, validate, điền dữ liệu, review và export. Workflow hiển thị 8 stage nội bộ (`choose` đến `export`) và tiến trình đồng bộ 7 bước cho từng file.
2. Module này đã tách trạng thái binary xác minh khỏi Reference/Pending; `canExportOfficial` chỉ cho phép xuất từ binary có `verified` và item template tồn tại.
3. **AILegalKnowledgeBase** có chức năng quản trị nguồn, batch sync, trạng thái Official/Reference/Pending, URL và checksum theo phần đã triển khai. Số catalog và số mã đã chạy đã được tách trên giao diện.
4. **AIDossierAdmin** và một số route cũ vẫn cần đối chiếu thêm về mức độ dùng catalog động, trạng thái file và kết nối với workflow chung; có nguy cơ là màn hình quản trị/khung cũ chứ chưa phải workspace lập hồ sơ hoàn chỉnh.
5. Preview desktop cho một số route hiện hiển thị skeleton/loading khi request chưa hoàn tất hoặc khi chưa có phiên đăng nhập; đây là trạng thái tải, không đủ căn cứ kết luận mất chức năng. Route `hs-dat-dai-ai` và `ai-ho-so-dat-dai-tu-dong` hiển thị header/workflow rõ; route Kho AI cần kiểm tra thêm sau login để xác nhận dữ liệu thực.
6. Cần xác minh trực tiếp các điểm: lưu hồ sơ nháp theo người dùng, tải file thật từ kho, mapping từng component, chọn tỉnh khác, camera/mobile, export DOCX/PDF và hiển thị lý do Reference/Pending.

## Kết luận tạm thời

Hệ thống đã có khung workflow chính và phần xác minh binary, nhưng **chưa nên tuyên bố mọi giao diện đều hoàn chỉnh**. Điểm còn thiếu quan trọng là bảo đảm các màn hình cũ không tách khỏi workflow chung, và kiểm thử end-to-end sau đăng nhập với dữ liệu thực tế. Không được gắn Official nếu chưa có binary và SHA-256/provenance xác minh.
