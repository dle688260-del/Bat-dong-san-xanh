# Xác minh binary Official — thủ tục 2.002317

Ngày kiểm tra: 2026-08-24.

Các URL nguồn DVC Bộ Nông nghiệp và Môi trường được kiểm tra trực tiếp bằng tải tệp và SHA-256, không thực thi nội dung tải xuống:

| Tệp registry | URL nguồn | Kết quả | Kích thước | SHA-256 |
|---|---|---:|---:|---|
| Mẫu số 01/PYC | https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/0ff8d095-1ea7-4567-a475-781d46b3c9bf | checksum_ok | 23,926 bytes | `3e68adcddb6e249af61fa2a3bdc883b73ad5800fd5af6c89e3b31b4e03fccbb2` |
| Hợp đồng cung cấp dữ liệu đất đai — Mẫu số 02 | https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/13f2af36-a65a-426a-99dd-e098de8d091e | checksum_ok | 19,727 bytes | `d5853a5ee35f4d115e3011007f23364670fed45d9ed95549d5982f5309706dce` |
| Phiếu yêu cầu — bản DOCX công bố | https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/0b362fa7-818b-48ae-ba54-9ce7fd2332b4 | checksum_ok | 23,926 bytes | `3e68adcddb6e249af61fa2a3bdc883b73ad5800fd5af6c89e3b31b4e03fccbb2` |

Kết luận: cả ba binary có thể dùng cho kiểm thử pipeline thủ tục 2.002317; hai bản Phiếu yêu cầu là cùng nội dung theo SHA-256 nên không được tính thành hai biểu mẫu độc lập. Nhãn Official chỉ hợp lệ khi binary được lưu trong kho với checksum/provenance tương ứng.
