import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";
import { LockKeyhole, LogIn, ShieldCheck, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useCrmInstallManifest } from "@/hooks/useCrmInstallManifest";

export default function AdminLogin() {
  const [, navigate] = useLocation();
  const normalizedPath = window.location.pathname.replace(/\/+$/, "");
  const isCrmLogin = normalizedPath === "/crm/login" || normalizedPath === "/dang-nhap-quan-tri";
  useCrmInstallManifest();
  const utils = trpc.useUtils();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const login = trpc.auth.adminLogin.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      toast.success("Đăng nhập quản trị thành công.");
      navigate(isCrmLogin ? "/crm" : "/dashboard");
    },
    onError: error => toast.error(error.message || "Không thể đăng nhập quản trị."),
  });

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    login.mutate({ username, password });
  };
  const changePassword = trpc.auth.changePasswordFromLogin.useMutation({
    onSuccess: () => {
      toast.success("Đổi mật khẩu thành công. Bạn có thể đăng nhập bằng mật khẩu mới.");
      setChangePasswordOpen(false);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    },
    onError: error => toast.error(error.message || "Không thể đổi mật khẩu."),
  });
  const submitChangePassword = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    changePassword.mutate({ username, currentPassword, newPassword, confirmPassword });
  };

  return (
    <main className="min-h-screen bg-[#f5f7f4] px-5 py-12 text-[#123d32]">
      <div className="mx-auto grid min-h-[calc(100vh-6rem)] w-full max-w-5xl items-center gap-10 lg:grid-cols-[1fr_420px]">
        <section className="hidden lg:block">
          <p className="text-xs font-black uppercase tracking-[0.24em] text-[#b27b17]">Khu vực nội bộ</p>
          <h1 className="mt-5 max-w-xl text-6xl font-black tracking-[-0.06em] text-[#1f5a4a]">Quản trị Bất động sản xanh.</h1>
          <p className="mt-6 max-w-lg text-lg leading-8 text-[#63746d]">Quản lý nguồn hàng, hồ sơ và quy trình đất đai trong một không gian riêng. Khách hàng vẫn xem được website công khai mà không cần đăng nhập.</p>
        </section>

        <section className="rounded-[30px] bg-white p-7 shadow-[0_24px_70px_rgba(20,64,50,0.14)] ring-1 ring-[#dce7df] sm:p-10" aria-labelledby="admin-login-title">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#eaf4ed] text-[#1f5a4a]"><ShieldCheck size={28} aria-hidden="true" /></div>
          <p className="mt-7 text-xs font-black uppercase tracking-[0.2em] text-[#b27b17]">Admin access</p>
          <h1 id="admin-login-title" className="mt-2 text-3xl font-black tracking-tight">Đăng nhập quản trị</h1>
          <p className="mt-3 text-sm leading-6 text-[#63746d]">Dùng thông tin quản trị riêng đã được thiết lập cho website.</p>
          <form className="mt-8 space-y-5" onSubmit={submit}>
            <div className="space-y-2"><Label htmlFor="admin-username">Tên đăng nhập</Label><Input id="admin-username" autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} required /></div>
            <div className="space-y-2"><Label htmlFor="admin-password">Mật khẩu</Label><div className="relative"><LockKeyhole size={17} className="pointer-events-none absolute left-3 top-3 text-[#8a9992]" aria-hidden="true" /><Input id="admin-password" className="pl-10" type="password" autoComplete="current-password" value={password} onChange={event => setPassword(event.target.value)} required /></div></div>
            <Button type="submit" disabled={login.isPending} className="min-h-12 w-full rounded-xl bg-[#1f5a4a] font-bold text-white hover:bg-[#164638]"><LogIn size={18} className="mr-2" aria-hidden="true" />{login.isPending ? "Đang xác thực…" : "Đăng nhập"}</Button>
          </form>
          <button type="button" onClick={() => setChangePasswordOpen(value => !value)} className="mt-4 flex min-h-11 w-full items-center justify-center rounded-xl bg-[#e7b93f] px-4 font-bold text-[#183f33] hover:bg-[#d9a92d]" aria-expanded={changePasswordOpen}>
            <KeyRound size={17} className="mr-2" aria-hidden="true" />{changePasswordOpen ? "Đóng đổi mật khẩu" : "Đổi mật khẩu"}
          </button>
          {changePasswordOpen && <form className="mt-5 space-y-4 rounded-2xl bg-[#fff9e8] p-4 ring-1 ring-[#f0d98a]" onSubmit={submitChangePassword}>
            <p className="text-sm leading-6 text-[#63746d]">Nhập đúng tên đăng nhập và mật khẩu hiện tại để đặt mật khẩu mới.</p>
            <div className="space-y-2"><Label htmlFor="change-username">Tên đăng nhập</Label><Input id="change-username" autoComplete="username" value={username} onChange={event => setUsername(event.target.value)} required /></div>
            <div className="space-y-2"><Label htmlFor="current-password">Mật khẩu hiện tại</Label><Input id="current-password" type="password" autoComplete="current-password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} required /></div>
            <div className="space-y-2"><Label htmlFor="new-password">Mật khẩu mới</Label><Input id="new-password" type="password" autoComplete="new-password" minLength={10} value={newPassword} onChange={event => setNewPassword(event.target.value)} required /><p className="text-xs text-[#63746d]">Ít nhất 10 ký tự, gồm chữ và số.</p></div>
            <div className="space-y-2"><Label htmlFor="confirm-password">Xác nhận mật khẩu mới</Label><Input id="confirm-password" type="password" autoComplete="new-password" minLength={10} value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} required /></div>
            <Button type="submit" disabled={changePassword.isPending} className="min-h-11 w-full rounded-xl bg-[#1f5a4a] font-bold text-white hover:bg-[#164638]">{changePassword.isPending ? "Đang cập nhật…" : "Lưu mật khẩu mới"}</Button>
          </form>}
          <Link href={isCrmLogin ? "/crm" : "/"} className="mt-6 block text-center text-sm font-bold text-[#1f5a4a] hover:underline">← {isCrmLogin ? "Quay lại CRM" : "Về trang công khai"}</Link>
        </section>
      </div>
    </main>
  );
}
