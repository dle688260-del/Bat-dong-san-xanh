# Nguồn chính thức đã tra cứu — 18/08/2026

Các nguồn từ Cổng Dịch vụ công Quốc gia/Văn phòng Chính phủ, dùng làm metadata tham khảo cho AI Hồ sơ đất đai. Cần kiểm tra lại theo tỉnh/thành và thời điểm trước khi người dùng nộp hồ sơ.

## 1. Đăng ký biến động do chuyển quyền, cho thuê, thừa kế, tặng cho, góp vốn
- URL: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410
- Nội dung chính: đăng ký biến động trong các trường hợp chuyển nhượng, cho thuê/cho thuê lại, thừa kế, tặng cho, góp vốn và một số trường hợp chuyển quyền khác.
- Thành phần hồ sơ được hiển thị gồm: Đơn đăng ký biến động Mẫu 09/ĐK; hợp đồng/văn bản chuyển quyền; bản gốc Giấy chứng nhận; giấy tờ bổ sung tùy trường hợp; có liên kết PDF Mẫu 09/ĐK tại csdl.dichvucong.gov.vn.
- Thời hạn hiển thị: chuyển đổi/chuyển nhượng/thừa kế/tặng cho/góp vốn không quá 10 ngày; cho thuê/cho thuê lại không quá 03 ngày; chuyển quyền vợ/chồng thành tài sản chung không quá 05 ngày, chưa tính một số khoảng thời gian loại trừ.
- Cơ quan/đường nộp: Văn phòng đăng ký quyền sử dụng đất hoặc cơ quan tiếp nhận theo tỉnh; hộ gia đình/cá nhân có thể nộp tại UBND cấp xã nếu có nhu cầu; có thể điện tử tùy thủ tục.

## 2. Đăng ký đất đai, cấp Giấy chứng nhận lần đầu
- URL: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
- Tên thủ tục: đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận lần đầu cho hộ gia đình, cá nhân, cộng đồng dân cư, người gốc Việt Nam định cư ở nước ngoài.
- Quy trình hiển thị: nộp tại Trung tâm Phục vụ hành chính công; chuyển UBND cấp xã; xác nhận hiện trạng/tranh chấp/nguồn gốc/quy hoạch; niêm yết công khai 15 ngày; xác định điều kiện; chuyển thông tin nghĩa vụ tài chính; cấp và trao Giấy chứng nhận.
- Mẫu được liên kết: Đơn đăng ký đất đai, tài sản gắn liền với đất Mus15DKLD.docx.
- Thời hạn hiển thị: 17 ngày đăng ký lần đầu; 20 ngày đăng ký và cấp Giấy chứng nhận lần đầu; vùng khó khăn có thể 27/30 ngày theo bảng của nguồn.

## 3. Cấp đổi Giấy chứng nhận
- URL: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783
- Cơ quan: Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh.
- Các trường hợp gồm: đổi giấy cũ sang mẫu mới, giấy ố/nhòe/rách/hỏng, tách giấy chung, thay đổi mục đích ghi trên giấy, vị trí không chính xác, bổ sung tên vợ/chồng, cập nhật thành viên hộ gia đình và trường hợp đo đạc.
- Thời hạn hiển thị tùy trường hợp: 05, 10, 15 hoặc 20 ngày làm việc; vùng khó khăn có thể tăng.
- Có nhắc đến Phiếu chuyển thông tin nghĩa vụ tài chính Mẫu 19 theo Nghị định 151/2025/NĐ-CP trong trường hợp phát sinh.

## 4. Tách thửa hoặc hợp thửa
- URL: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784
- Hồ sơ hiển thị: Đơn đề nghị tách/hợp thửa Mẫu 21; Bản vẽ tách/hợp thửa Mẫu 22; Giấy chứng nhận đã cấp; văn bản cơ quan có thẩm quyền nếu có.
- Quy trình: nộp tại Trung tâm Phục vụ hành chính công/Văn phòng đăng ký đất đai/Chi nhánh; kiểm tra thông tin, ranh giới, diện tích, loại đất; đối chiếu điều kiện Điều 220 Luật Đất đai; xác nhận hoặc trả hồ sơ; chỉnh lý/cấp giấy nếu đủ điều kiện.
- Thời hạn hiển thị: 12 ngày làm việc, vùng khó khăn 22 ngày.
- Điều kiện phụ thuộc Điều 220 Luật Đất đai và quy định diện tích tối thiểu của UBND cấp tỉnh.

## Nguyên tắc tích hợp vào AI
- Dùng các URL trên làm nguồn/provenance, không tự gắn nhãn Official cho tài liệu do AI dựng.
- Tài liệu do AI tạo là bản tham khảo/Confirmed Draft; nếu nguồn có tệp DOCX/PDF gốc hợp lệ thì lưu URL, tên mẫu, ngày kiểm tra, trạng thái và hash trước khi cho phép điền trực tiếp.
- Thời hạn, cơ quan tiếp nhận, phí/lệ phí phải hiển thị theo tỉnh/thành và được người dùng xác nhận trước khi in/nộp.
- Các nguồn có thể thay đổi; hệ thống cần hiển thị ngày kiểm tra và cảnh báo đối chiếu tại Cổng Dịch vụ công/đơn vị tiếp nhận.

## Bổ sung xác minh ngày 18/08/2026

- URL thủ tục đăng ký biến động đã kiểm tra lại trên nguồn Văn phòng Chính phủ là https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=2.000889. Trang này hiển thị nhóm trường hợp chuyển đổi, chuyển nhượng, cho thuê, cho thuê lại, thừa kế, tặng cho, góp vốn và một số trường hợp chuyển quyền khác; thành phần hồ sơ có Mẫu 09/ĐK, hợp đồng/văn bản chuyển quyền và bản gốc Giấy chứng nhận. URL cũ `2.000410` vẫn được giữ như lịch sử tra cứu, nhưng registry mới nên ưu tiên URL đã kiểm tra `2.000889`.
- Nghị định 151/2025/NĐ-CP được xác minh trên Cổng Thông tin điện tử Chính phủ: ban hành 12/06/2025, hiệu lực 01/07/2025, có PDF ký số `151-ndcp.signed.pdf`, nội dung về phân định thẩm quyền chính quyền địa phương 02 cấp, phân quyền và phân cấp trong lĩnh vực đất đai: https://vanban.chinhphu.vn/?pageid=27160&docid=213927.
- Thủ tục đăng ký biến động nêu thời hạn tham chiếu không quá 10 ngày cho chuyển đổi/chuyển nhượng/thừa kế/tặng cho/góp vốn, không quá 03 ngày cho cho thuê/cho thuê lại; không tính thời gian thực hiện nghĩa vụ tài chính và một số khoảng thời gian loại trừ. Hệ thống chỉ hiển thị đây là thời hạn tham chiếu, không phải cam kết tiếp nhận.
- Thủ tục cấp đổi 1.012783 có nhắc đến Phiếu chuyển thông tin xác định nghĩa vụ tài chính Mẫu 19 theo Nghị định 151/2025/NĐ-CP và các thời hạn 05/10/15/20 ngày tùy trường hợp; hệ thống phải giữ cờ cần rà soát địa phương.
- Thủ tục đăng ký và cấp Giấy chứng nhận lần đầu 1.013978 liên kết `Mus15DKLD.docx`, đồng thời mô tả Mẫu 16, Mẫu 17 và Mẫu 19 trong quy trình tương ứng. Mẫu 15 chỉ được đánh `metadata-only` nếu chưa tải và kiểm tra được tệp nhị phân chính thức.

## Nguồn tra cứu cho cơ chế AI tự tìm biểu mẫu — 18/08/2026

- Cổng Dịch vụ công Quốc gia — Đăng ký đất đai, tài sản gắn liền với đất, cấp Giấy chứng nhận: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.013978
- Cổng Dịch vụ công Quốc gia — Cấp đổi Giấy chứng nhận: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012783
- Cổng Dịch vụ công Quốc gia — Cung cấp thông tin, dữ liệu đất đai: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
- Cổng Thông tin điện tử Chính phủ — Nghị định 101/2024/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=210791
- Cổng Thông tin điện tử Chính phủ — Nghị định 151/2025/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=213927
- Bộ Nông nghiệp và Môi trường — Phụ lục VII danh sách mẫu biểu: https://mae.gov.vn/noidung/Lists/DuLieuLinhVucCongBo/Attachments/2/ph%E1%BB%A5%20l%E1%BB%A5c%20VII.pdf
- Bộ Nông nghiệp và Môi trường — tài liệu sửa đổi phụ lục/mẫu biểu: https://media.mae.gov.vn/Document/865d817b-2d7e-7305-1c70-694c4607350e/2026/2/3//2.2.%20Ph%E1%BB%A5%20l%E1%BB%A5c%20II%20kem%20cvht__03022026094613_signed_c0ab335888.pdf

Thiết kế đề xuất: AI tìm theo mã thủ tục, tên thủ tục, địa phương và căn cứ pháp lý; lấy URL/tệp từ nguồn chính thức; kiểm tra ngày kiểm tra, hiệu lực, checksum và trạng thái tệp; đối chiếu với danh sách mẫu biểu; chỉ sau đó mới gắn biểu mẫu vào bundle. Tệp do AI tự dựng vẫn là Confirmed Draft/metadata-only nếu chưa xác minh được binary chính thức.
