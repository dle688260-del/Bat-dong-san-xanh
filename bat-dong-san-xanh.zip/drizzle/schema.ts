import { decimal, foreignKey, index, int, mysqlEnum, mysqlTable, text, timestamp, tinyint, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const consultationRequests = mysqlTable("consultation_requests", {
  id: int("id").autoincrement().primaryKey(),
  interest: varchar("interest", { length: 255 }).notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  message: text("message"),
  status: mysqlEnum("status", ["new", "contacted", "closed"]).default("new").notNull(),
  aiStatus: mysqlEnum("aiStatus", ["pending", "analyzed", "failed"]).default("pending").notNull(),
  aiPriority: mysqlEnum("aiPriority", ["high", "potential", "reference"]).default("reference").notNull(),
  aiSummary: text("aiSummary"),
  aiProfile: text("aiProfile"),
  aiMatches: text("aiMatches"),
  aiAnalyzedAt: timestamp("aiAnalyzedAt"),
  aiArea: varchar("aiArea", { length: 255 }),
  aiScore: int("aiScore"),
  routingStage: mysqlEnum("routingStage", ["unassigned", "area_queue", "backup_queue", "admin_queue"]).default("unassigned").notNull(),
  assignedTo: int("assignedTo").references(() => users.id),
  conversationHistory: text("conversationHistory"),
  marketingCampaignId: int("marketingCampaignId"),
  marketingChannel: varchar("marketingChannel", { length: 80 }),
  marketingPropertyId: int("marketingPropertyId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const areas = mysqlTable("areas", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  province: varchar("province", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const properties = mysqlTable("properties", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  propertyType: mysqlEnum("propertyType", ["house", "land", "apartment", "villa", "industrial", "commercial_land", "agricultural", "commercial", "resort", "project", "rental"]).notNull(),
  listingType: mysqlEnum("listingType", ["sale", "rent"]).default("sale").notNull(),
  price: decimal("price", { precision: 18, scale: 2 }).notNull(),
  area: decimal("area", { precision: 10, scale: 2 }).notNull(),
  buildArea: decimal("buildArea", { precision: 10, scale: 2 }),
  roadWidth: decimal("roadWidth", { precision: 6, scale: 2 }),
  bedrooms: int("bedrooms"),
  bathrooms: int("bathrooms"),
  constructionYear: int("constructionYear"),
  orientation: varchar("orientation", { length: 80 }),
  location: varchar("location", { length: 255 }).notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 7 }),
  longitude: decimal("longitude", { precision: 10, scale: 7 }),
  mapVisibility: mysqlEnum("mapVisibility", ["approximate", "exact", "private"]).default("approximate").notNull(),
  distanceToMainRoad: varchar("distanceToMainRoad", { length: 120 }),
  nearbySchools: varchar("nearbySchools", { length: 255 }),
  nearbyMarket: varchar("nearbyMarket", { length: 255 }),
  nearbyHospital: varchar("nearbyHospital", { length: 255 }),
  distanceToCenter: varchar("distanceToCenter", { length: 120 }),
  areaId: int("areaId").references(() => areas.id),
  description: text("description"),
  legalStatus: varchar("legalStatus", { length: 160 }),
  certificateType: varchar("certificateType", { length: 160 }),
  certificateArea: decimal("certificateArea", { precision: 10, scale: 2 }),
  landUsePurpose: varchar("landUsePurpose", { length: 255 }),
  planningStatus: varchar("planningStatus", { length: 255 }),
  mortgageStatus: varchar("mortgageStatus", { length: 255 }),
  legalSource: varchar("legalSource", { length: 255 }).default("Theo hồ sơ/chủ nhà cung cấp"),
  negotiable: tinyint("negotiable").default(1).notNull(),
  brokerageFee: varchar("brokerageFee", { length: 160 }),
  depositTerms: text("depositTerms"),
  transactionTerms: text("transactionTerms"),
  /** JSON metadata for type-specific listing fields; never contains private legal scans. */
  listingDetails: text("listingDetails"),
  propertyCode: varchar("propertyCode", { length: 80 }).unique(),
  brokerName: varchar("brokerName", { length: 120 }),
  brokerPhone: varchar("brokerPhone", { length: 30 }),
  brokerZalo: varchar("brokerZalo", { length: 255 }),
  status: mysqlEnum("status", ["draft", "published", "reserved", "sold"]).default("draft").notNull(),
  featured: int("featured").default(0).notNull(),
  ownerName: varchar("ownerName", { length: 120 }),
  ownerPhone: varchar("ownerPhone", { length: 30 }),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const legalDocumentScans = mysqlTable("legal_document_scans", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  imageUrl: text("imageUrl").notNull(),
  storageKey: text("storageKey").notNull(),
  extractedData: text("extractedData"),
  confidence: decimal("confidence", { precision: 5, scale: 2 }),
  status: mysqlEnum("status", ["pending", "confirmed", "rejected"]).default("pending").notNull(),
  reviewedBy: int("reviewedBy").references(() => users.id),
  reviewedAt: timestamp("reviewedAt"),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const propertyImages = mysqlTable("property_images", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  url: text("url").notNull(),
  altText: varchar("altText", { length: 255 }),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const propertyOwners = mysqlTable("property_owners", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  email: varchar("email", { length: 320 }),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const buyerLeads = mysqlTable("buyer_leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  budget: decimal("budget", { precision: 18, scale: 2 }),
  preferredArea: varchar("preferredArea", { length: 255 }),
  propertyType: varchar("propertyType", { length: 80 }),
  notes: text("notes"),
  status: mysqlEnum("status", ["new", "qualified", "viewing", "converted", "closed"]).default("new").notNull(),
  assignedTo: int("assignedTo").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const surveys = mysqlTable("surveys", {
  id: int("id").autoincrement().primaryKey(),
  buyerLeadId: int("buyerLeadId").references(() => buyerLeads.id),
  propertyId: int("propertyId").references(() => properties.id),
  purpose: varchar("purpose", { length: 120 }),
  budget: decimal("budget", { precision: 18, scale: 2 }),
  timeline: varchar("timeline", { length: 120 }),
  mustHave: text("mustHave"),
  notes: text("notes"),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const legalChecks = mysqlTable("legal_checks", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  checkedBy: int("checkedBy").references(() => users.id),
  status: mysqlEnum("status", ["pending", "in_review", "verified", "issue_found"]).default("pending").notNull(),
  documents: text("documents"),
  notes: text("notes"),
  checkedAt: timestamp("checkedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const valuations = mysqlTable("valuations", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  estimatedPrice: decimal("estimatedPrice", { precision: 18, scale: 2 }).notNull(),
  method: varchar("method", { length: 160 }),
  comparableNotes: text("comparableNotes"),
  assessedBy: int("assessedBy").references(() => users.id),
  assessedAt: timestamp("assessedAt").defaultNow().notNull(),
});

export const propertyDossiers = mysqlTable("property_dossiers", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().unique().references(() => properties.id),
  status: mysqlEnum("status", ["active", "completed", "paused"]).default("active").notNull(),
  currentStep: int("currentStep").default(1).notNull(),
  assignedTo: int("assignedTo").references(() => users.id),
  notes: text("notes"),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const propertyDossierSteps = mysqlTable("property_dossier_steps", {
  id: int("id").autoincrement().primaryKey(),
  dossierId: int("dossierId").notNull().references(() => propertyDossiers.id),
  stepNumber: int("stepNumber").notNull(),
  status: mysqlEnum("status", ["completed", "in_progress", "not_started", "needs_review"]).default("not_started").notNull(),
  details: text("details"),
  notes: text("notes"),
  completedAt: timestamp("completedAt"),
  updatedBy: int("updatedBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const propertyDossierDocuments = mysqlTable("property_dossier_documents", {
  id: int("id").autoincrement().primaryKey(),
  dossierId: int("dossierId").notNull().references(() => propertyDossiers.id),
  stepNumber: int("stepNumber").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  url: text("url").notNull(),
  storageKey: text("storageKey").notNull(),
  uploadedBy: int("uploadedBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const deals = mysqlTable("deals", {
  id: int("id").autoincrement().primaryKey(),
  transactionCode: varchar("transactionCode", { length: 40 }).unique(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  buyerLeadId: int("buyerLeadId").references(() => buyerLeads.id),
  ownerId: int("ownerId").references(() => propertyOwners.id),
  assignedTo: int("assignedTo").references(() => users.id),
  stage: mysqlEnum("stage", ["new", "negotiating", "deposit", "contracted", "completed", "cancelled"]).default("new").notNull(),
  agreedPrice: decimal("agreedPrice", { precision: 18, scale: 2 }),
  depositAmount: decimal("depositAmount", { precision: 18, scale: 2 }),
  depositDate: timestamp("depositDate"),
  expectedNotaryDate: timestamp("expectedNotaryDate"),
  completionDate: timestamp("completionDate"),
  commissionAmount: decimal("commissionAmount", { precision: 18, scale: 2 }),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "partial", "paid"]).default("pending").notNull(),
  paymentMethod: varchar("paymentMethod", { length: 120 }),
  notaryOffice: varchar("notaryOffice", { length: 255 }),
  transferStatus: mysqlEnum("transferStatus", ["not_started", "in_progress", "completed"]).default("not_started").notNull(),
  handoverStatus: mysqlEnum("handoverStatus", ["not_started", "scheduled", "completed"]).default("not_started").notNull(),
  issueNote: text("issueNote"),
  nextAction: text("nextAction"),
  checklist: text("checklist"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type ConsultationRequest = typeof consultationRequests.$inferSelect;
export type InsertConsultationRequest = typeof consultationRequests.$inferInsert;
export type Area = typeof areas.$inferSelect;
export type Property = typeof properties.$inferSelect;
export type InsertProperty = typeof properties.$inferInsert;
export type PropertyImage = typeof propertyImages.$inferSelect;
export type LegalDocumentScan = typeof legalDocumentScans.$inferSelect;
export type BuyerLead = typeof buyerLeads.$inferSelect;
export type PropertyOwner = typeof propertyOwners.$inferSelect;
export type Survey = typeof surveys.$inferSelect;
export type LegalCheck = typeof legalChecks.$inferSelect;
export type Valuation = typeof valuations.$inferSelect;
export type Deal = typeof deals.$inferSelect;
export type PropertyDossier = typeof propertyDossiers.$inferSelect;
export type PropertyDossierStep = typeof propertyDossierSteps.$inferSelect;
export type PropertyDossierDocument = typeof propertyDossierDocuments.$inferSelect;
export type Property3dAnnotation = typeof property3dAnnotations.$inferSelect;
export type InsertProperty3dAnnotation = typeof property3dAnnotations.$inferInsert;

export const propertyArchiveFiles = mysqlTable("property_archive_files", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  category: mysqlEnum("category", ["property", "legal", "valuation", "marketing", "transaction"]).notNull(),
  documentType: varchar("documentType", { length: 160 }).notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  url: text("url").notNull(),
  storageKey: text("storageKey").notNull(),
  uploadedBy: int("uploadedBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});


export const property3dAnnotations = mysqlTable("property_3d_annotations", {
  id: int("id").autoincrement().primaryKey(),
  propertyId: int("propertyId").notNull().references(() => properties.id),
  assetUrl: text("assetUrl").notNull(),
  assetFileName: varchar("assetFileName", { length: 255 }),
  title: varchar("title", { length: 160 }).notNull(),
  body: text("body"),
  tag: varchar("tag", { length: 80 }),
  positionX: decimal("positionX", { precision: 8, scale: 5 }).notNull(),
  positionY: decimal("positionY", { precision: 8, scale: 5 }).notNull(),
  positionZ: decimal("positionZ", { precision: 8, scale: 5 }).notNull(),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const landDossiers = mysqlTable("land_dossiers", {
  id: int("id").autoincrement().primaryKey(),
  dossierCode: varchar("dossierCode", { length: 40 }).notNull().unique(),
  procedureType: varchar("procedureType", { length: 120 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["draft", "in_progress", "completed", "paused", "cancelled"]).default("draft").notNull(),
  currentStep: int("currentStep").default(1).notNull(),
  answers: text("answers"),
  notes: text("notes"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  propertyId: int("propertyId").references(() => properties.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const landDossierSteps = mysqlTable("land_dossier_steps", {
  id: int("id").autoincrement().primaryKey(),
  dossierId: int("dossierId").notNull().references(() => landDossiers.id),
  stepNumber: int("stepNumber").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  status: mysqlEnum("status", ["completed", "in_progress", "not_started", "needs_review"]).default("not_started").notNull(),
  checklist: text("checklist").notNull(),
  relatedTemplates: text("relatedTemplates"),
  notes: text("notes"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LandDossier = typeof landDossiers.$inferSelect;
export type LandDossierStep = typeof landDossierSteps.$inferSelect;


export const legalSources = mysqlTable("legal_sources", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 180 }).notNull(),
  baseUrl: text("baseUrl").notNull(),
  sourceType: mysqlEnum("sourceType", ["government", "public_service", "local_authority", "official_gazette", "other"]).notNull(),
  jurisdiction: varchar("jurisdiction", { length: 160 }),
  active: tinyint("active").default(1).notNull(),
  lastCheckedAt: timestamp("lastCheckedAt"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const legalDocuments = mysqlTable("legal_documents", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").notNull().references(() => legalSources.id),
  title: varchar("title", { length: 255 }).notNull(),
  documentNumber: varchar("documentNumber", { length: 120 }),
  documentType: varchar("documentType", { length: 120 }),
  issuingBody: varchar("issuingBody", { length: 180 }),
  sourceUrl: text("sourceUrl").notNull(),
  fileUrl: text("fileUrl"),
  storageKey: text("storageKey"),
  mimeType: varchar("mimeType", { length: 120 }),
  contentText: text("contentText"),
  contentHash: varchar("contentHash", { length: 128 }),
  status: mysqlEnum("status", ["metadata_only", "extracted", "verified", "superseded", "needs_review"]).default("metadata_only").notNull(),
  effectiveFrom: timestamp("effectiveFrom"),
  effectiveTo: timestamp("effectiveTo"),
  checkedAt: timestamp("checkedAt"),
  extractedBy: varchar("extractedBy", { length: 120 }),
  warnings: text("warnings"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const legalProcedures = mysqlTable("legal_procedures", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  groupName: varchar("groupName", { length: 180 }).notNull(),
  aliases: text("aliases"),
  authority: varchar("authority", { length: 180 }),
  defaultProvince: varchar("defaultProvince", { length: 120 }),
  processingTime: varchar("processingTime", { length: 160 }),
  feeNotes: text("feeNotes"),
  conditions: text("conditions"),
  workflow: text("workflow"),
  status: mysqlEnum("status", ["active", "needs_review", "archived"]).default("active").notNull(),
  sourceDocumentIds: text("sourceDocumentIds"),
  lastReviewedAt: timestamp("lastReviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const legalProcedureRequirements = mysqlTable("legal_procedure_requirements", {
  id: int("id").autoincrement().primaryKey(),
  procedureId: int("procedureId").notNull().references(() => legalProcedures.id),
  sortOrder: int("sortOrder").default(0).notNull(),
  label: varchar("label", { length: 255 }).notNull(),
  requirementType: mysqlEnum("requirementType", ["document", "field", "condition", "fee", "instruction"]).notNull(),
  required: tinyint("required").default(1).notNull(),
  fieldKey: varchar("fieldKey", { length: 100 }),
  sourceDocumentId: int("sourceDocumentId").references(() => legalDocuments.id),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const legalTemplates = mysqlTable("legal_templates", {
  id: int("id").autoincrement().primaryKey(),
  procedureId: int("procedureId").references(() => legalProcedures.id),
  sourceId: int("sourceId").notNull().references(() => legalSources.id),
  name: varchar("name", { length: 255 }).notNull(),
  documentType: varchar("documentType", { length: 120 }).notNull(),
  format: mysqlEnum("format", ["docx", "doc", "pdf", "html", "scan"]).notNull(),
  sourceUrl: text("sourceUrl").notNull(),
  storageKey: text("storageKey"),
  fileUrl: text("fileUrl"),
  sourceDocumentId: int("sourceDocumentId").references(() => legalDocuments.id),
  province: varchar("province", { length: 120 }),
  receivingAuthority: varchar("receivingAuthority", { length: 255 }),
  jurisdictionScope: mysqlEnum("jurisdictionScope", ["national", "provincial", "district", "commune", "agency_specific"]).default("national").notNull(),
  provenance: mysqlEnum("provenance", ["metadata_only", "verified_binary", "official"]).default("metadata_only").notNull(),
  checksum: varchar("checksum", { length: 128 }),
  versionLabel: varchar("versionLabel", { length: 80 }),
  effectiveFrom: timestamp("effectiveFrom"),
  effectiveTo: timestamp("effectiveTo"),
  status: mysqlEnum("status", ["active", "needs_review", "superseded"]).default("active").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const legalTemplateFields = mysqlTable("legal_template_fields", {
  id: int("id").autoincrement().primaryKey(),
  templateId: int("templateId").notNull().references(() => legalTemplates.id),
  fieldKey: varchar("fieldKey", { length: 100 }).notNull(),
  label: varchar("label", { length: 180 }).notNull(),
  dataType: mysqlEnum("dataType", ["text", "number", "date", "boolean", "select"]).default("text").notNull(),
  required: tinyint("required").default(0).notNull(),
  placeholderToken: varchar("placeholderToken", { length: 180 }),
  validationRule: text("validationRule"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const legalSyncRuns = mysqlTable("legal_sync_runs", {
  id: int("id").autoincrement().primaryKey(),
  sourceId: int("sourceId").references(() => legalSources.id),
  status: mysqlEnum("status", ["running", "completed", "failed"]).default("running").notNull(),
  discoveredCount: int("discoveredCount").default(0).notNull(),
  changedCount: int("changedCount").default(0).notNull(),
  summary: text("summary"),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  finishedAt: timestamp("finishedAt"),
});

export const legalScanQueue = mysqlTable("legal_scan_queue", {
  id: int("id").autoincrement().primaryKey(),
  procedureCode: varchar("procedureCode", { length: 32 }).notNull(),
  province: varchar("province", { length: 120 }),
  status: mysqlEnum("status", ["queued", "running", "succeeded", "pending", "failed"]).default("queued").notNull(),
  attempts: int("attempts").default(0).notNull(),
  lastHttpStatus: int("lastHttpStatus"),
  lastSourceUrl: text("lastSourceUrl"),
  lastError: text("lastError"),
  nextAttemptAt: timestamp("nextAttemptAt"),
  lockedAt: timestamp("lockedAt"),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  procedureProvinceUnique: uniqueIndex("legal_scan_queue_procedure_province_unique").on(table.procedureCode, table.province),
  nextAttemptIdx: index("legal_scan_queue_next_attempt_idx").on(table.status, table.nextAttemptAt),
}));

export const legalProcedureVersions = mysqlTable("legal_procedure_versions", {
  id: int("id").autoincrement().primaryKey(),
  procedureId: int("procedureId").notNull(),
  sourceUrl: text("sourceUrl").notNull(),
  sourceHash: varchar("sourceHash", { length: 128 }),
  snapshotKey: text("snapshotKey"),
  workflowJson: text("workflowJson").notNull(),
  requirementsJson: text("requirementsJson").notNull(),
  discoveredAt: timestamp("discoveredAt").defaultNow().notNull(),
  effectiveFrom: timestamp("effectiveFrom"),
  status: mysqlEnum("status", ["discovered", "reviewed", "active", "superseded"]).default("discovered").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  procedureFk: foreignKey({ name: "lpv_procedure_fk", columns: [table.procedureId], foreignColumns: [legalProcedures.id] }),
}));

export const legalTemplateMappings = mysqlTable("legal_template_mappings", {
  id: int("id").autoincrement().primaryKey(),
  procedureId: int("procedureId").notNull(),
  requirementId: int("requirementId"),
  templateId: int("templateId").notNull(),
  mappingJson: text("mappingJson").notNull(),
  confidence: int("confidence").default(0).notNull(),
  status: mysqlEnum("status", ["suggested", "reviewed", "approved", "rejected"]).default("suggested").notNull(),
  reviewedAt: timestamp("reviewedAt"),
  reviewedBy: int("reviewedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  procedureFk: foreignKey({ name: "ltm_procedure_fk", columns: [table.procedureId], foreignColumns: [legalProcedures.id] }),
  requirementFk: foreignKey({ name: "ltm_requirement_fk", columns: [table.requirementId], foreignColumns: [legalProcedureRequirements.id] }),
  templateFk: foreignKey({ name: "ltm_template_fk", columns: [table.templateId], foreignColumns: [legalTemplates.id] }),
  reviewerFk: foreignKey({ name: "ltm_reviewer_fk", columns: [table.reviewedBy], foreignColumns: [users.id] }),
}));

export const landDossierAudits = mysqlTable("land_dossier_audits", {
  id: int("id").autoincrement().primaryKey(),
  dossierId: int("dossierId").notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  status: mysqlEnum("status", ["passed", "warning", "blocked"]).notNull(),
  evidenceJson: text("evidenceJson"),
  actorId: int("actorId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  dossierFk: foreignKey({ name: "lda_dossier_fk", columns: [table.dossierId], foreignColumns: [landDossiers.id] }),
  actorFk: foreignKey({ name: "lda_actor_fk", columns: [table.actorId], foreignColumns: [users.id] }),
}));

export const manusConnectionSettings = mysqlTable("manus_connection_settings", {
  id: int("id").autoincrement().primaryKey(),
  status: mysqlEnum("status", ["connected", "disconnected"]).default("disconnected").notNull(),
  lastSyncStatus: mysqlEnum("lastSyncStatus", ["never", "pending", "success", "failed"]).default("never").notNull(),
  lastSyncMessage: text("lastSyncMessage"),
  lastSyncVersion: varchar("lastSyncVersion", { length: 80 }),
  connectedAt: timestamp("connectedAt"),
  disconnectedAt: timestamp("disconnectedAt"),
  lastSyncedAt: timestamp("lastSyncedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const adminAuthSettings = mysqlTable("admin_auth_settings", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 120 }).notNull().unique(),
  passwordHash: text("passwordHash").notNull(),
  passwordVersion: int("passwordVersion").default(1).notNull(),
  changedAt: timestamp("changedAt").defaultNow().onUpdateNow().notNull(),
});

export const propertyLayoutSettings = mysqlTable("property_layout_settings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  defaultLayout: varchar("defaultLayout", { length: 32 }).default("auto").notNull(),
  overridesJson: text("overridesJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const manusChangeRequests = mysqlTable("manus_change_requests", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  description: text("description").notNull(),
  requestType: mysqlEnum("requestType", ["fix", "update", "configuration"]).default("update").notNull(),
  status: mysqlEnum("status", ["requested", "staged", "synced", "approved", "rejected"]).default("requested").notNull(),
  localDraft: text("localDraft"),
  syncSummary: text("syncSummary"),
  requestedBy: int("requestedBy").notNull(),
  approvedBy: int("approvedBy"),
  requestedAt: timestamp("requestedAt").defaultNow().notNull(),
  syncedAt: timestamp("syncedAt"),
  approvedAt: timestamp("approvedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PropertyLayoutSettings = typeof propertyLayoutSettings.$inferSelect;
export type AdminAuthSettings = typeof adminAuthSettings.$inferSelect;
export type ManusConnectionSettings = typeof manusConnectionSettings.$inferSelect;
export type ManusChangeRequest = typeof manusChangeRequests.$inferSelect;

export const marketingCampaigns = mysqlTable("marketing_campaigns", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 180 }).notNull(),
  objective: mysqlEnum("objective", ["sell", "rent", "consignment", "buyer", "area", "project", "brand"]).default("sell").notNull(),
  propertyId: int("propertyId").references(() => properties.id),
  audience: varchar("audience", { length: 255 }),
  channelsJson: text("channelsJson"),
  budget: decimal("budget", { precision: 18, scale: 2 }),
  startsAt: timestamp("startsAt"),
  endsAt: timestamp("endsAt"),
  status: mysqlEnum("status", ["draft", "active", "paused", "completed"]).default("draft").notNull(),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  propertyIdx: index("marketing_campaigns_property_idx").on(table.propertyId),
  statusIdx: index("marketing_campaigns_status_idx").on(table.status),
}));

export const marketingChannels = mysqlTable("marketing_channels", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  channelType: mysqlEnum("channelType", ["website", "facebook", "tiktok", "zalo", "youtube", "email", "google", "other"]).notNull(),
  handle: varchar("handle", { length: 255 }),
  active: tinyint("active").default(1).notNull(),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  typeIdx: index("marketing_channels_type_idx").on(table.channelType),
}));

export const marketingContents = mysqlTable("marketing_contents", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").references(() => marketingCampaigns.id),
  propertyId: int("propertyId").references(() => properties.id),
  channelType: mysqlEnum("channelType", ["website", "facebook", "tiktok", "zalo", "youtube", "email", "google", "other"]).notNull(),
  contentType: mysqlEnum("contentType", ["title", "description", "facebook_post", "website_copy", "ad_copy", "video_script", "reel_script", "email", "message"]).notNull(),
  title: varchar("title", { length: 255 }),
  body: text("body").notNull(),
  status: mysqlEnum("status", ["draft", "pending_review", "published", "ended"]).default("draft").notNull(),
  aiGenerated: tinyint("aiGenerated").default(0).notNull(),
  scheduledAt: timestamp("scheduledAt"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  campaignIdx: index("marketing_contents_campaign_idx").on(table.campaignId),
  propertyIdx: index("marketing_contents_property_idx").on(table.propertyId),
  statusIdx: index("marketing_contents_status_idx").on(table.status),
}));

export const marketingContentCalendar = mysqlTable("marketing_content_calendar", {
  id: int("id").autoincrement().primaryKey(),
  contentId: int("contentId").notNull().references(() => marketingContents.id),
  campaignId: int("campaignId").references(() => marketingCampaigns.id),
  propertyId: int("propertyId").references(() => properties.id),
  channelType: mysqlEnum("channelType", ["website", "facebook", "tiktok", "zalo", "youtube", "email", "google", "other"]).notNull(),
  scheduledAt: timestamp("scheduledAt").notNull(),
  status: mysqlEnum("status", ["planned", "published", "cancelled"]).default("planned").notNull(),
  note: text("note"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  scheduleIdx: index("marketing_calendar_schedule_idx").on(table.scheduledAt),
  statusIdx: index("marketing_calendar_status_idx").on(table.status),
}));

export type LegalSource = typeof legalSources.$inferSelect;
export type LegalDocument = typeof legalDocuments.$inferSelect;
export type LegalProcedure = typeof legalProcedures.$inferSelect;
export type LegalProcedureRequirement = typeof legalProcedureRequirements.$inferSelect;
export type LegalTemplate = typeof legalTemplates.$inferSelect;
export type LegalTemplateField = typeof legalTemplateFields.$inferSelect;
export type LegalSyncRun = typeof legalSyncRuns.$inferSelect;
