# Ghi nhận kiểm toán Hồ sơ đất đai AI

## Phạm vi đã kiểm tra

Dự án có các route chính: `/hs-dat-dai-ai` (AIDossierAdmin), `/ho-so-ai` (AllDossiersAI), `/ai-ho-so-dat-dai-tu-dong` và các alias (AiLandDossierAutoModule), `/ai-ho-so-dat-dai-van-hanh` (AiLandDossierOperations), `/ai-lap-ho-so-dat-dai` và alias (LandDossierBuilder), `/ai-kho-phap-ly` (AILegalKnowledgeBase), `/ho-so-dien-tu` và `/quan-ly-ho-so` (PropertyDossierAdmin), cùng `/kho-luu-tru`.

## Kết quả sơ bộ

`AIDossierAdmin` đang dùng đồng thời `landDossiers`, `properties`, `brokerage.dossiers`, `archives`, các module brokerage và các mutation AI nghiên cứu/tóm tắt. `LandDossierBuilder` dùng `landDossiers`, `aiAutoDossier`, `legalKnowledge` và export hồ sơ. `AiLandDossierAutoModule` có catalog, discover, batchDiscover, buildPlan, analyzeDossier, confirmReference, syncProcedure và pendingStatuses. `AiLandDossierOperations` hiện tập trung vào crawler status, template mappings, version history và audit. `AllDossiersAI` chủ yếu đọc properties, archives, owners/buyers và auth; cần đối chiếu tiếp xem có đọc trực tiếp landDossiers hay chỉ là màn hình tổng hợp khác.

Schema đã có khóa `land_dossiers.propertyId`, `land_dossier_steps.dossierId`, `property_archive_files.propertyId` và các bảng pháp lý riêng. Vì vậy nền tảng liên kết property–dossier đã có. Tuy nhiên `land_dossiers` chỉ lưu `procedureType`, `status`, `currentStep`, `answers`, `notes`; chưa thấy trong vùng đã đọc các trường riêng để ghi nguồn AI, phiên bản quy trình đã dùng, mức xác minh, thời điểm đồng bộ hoặc liên kết trực tiếp đến một `legalProcedureVersion`.

## Nguồn chính thức

Schema có `legal_sources` với `sourceType` gồm government/public_service/local_authority/official_gazette, `legal_documents` có `sourceUrl`, `contentHash`, `status`, thời điểm kiểm tra và cảnh báo; `legal_templates` có `provenance` gồm metadata_only/verified_binary/official, checksum, sourceUrl, thời hạn hiệu lực và trạng thái. Có `legal_sync_runs`, `legal_scan_queue`, `legal_procedure_versions` và `legal_template_mappings`.

Registry hiện tham chiếu Cổng Dịch vụ công Quốc gia và ghi rõ nhiều mẫu vẫn là `metadata_only`/`needs_review`; ghi chú nêu chưa gắn Official binary nếu chưa tải tệp thực tế, kiểm MIME/nội dung và đối chiếu SHA-256. Bộ fetcher cũng phân biệt `official_source` với `reference_only`, và fallback public không được nâng thành Official. Vì vậy hệ thống **có thể gắn nguồn chính thức về mặt kiến trúc**, nhưng không được coi tất cả mẫu hiện tại là hồ sơ Official cho tới khi binary được tải, kiểm tra chữ ký, checksum và người quản trị duyệt.

## Nguồn đã kiểm tra trực tiếp

- Cổng Dịch vụ công Quốc gia, thủ tục đăng ký biện pháp bảo đảm bằng quyền sử dụng đất, mã `1.011441`: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.011441
- Cổng Dịch vụ công Quốc gia, thủ tục đăng ký biến động quyền sử dụng đất, mã `2.000410`: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-nganh-doc.html?ma_thu_tuc=2.000410

Hai trang hiển thị nội dung thủ tục và thành phần hồ sơ chính thức. Nguồn trang thủ tục không đồng nghĩa mọi file mẫu đã được lưu và xác minh trong S3; cần kiểm tra từng tệp tải xuống, MIME, chữ ký định dạng, checksum, phiên bản và phạm vi địa phương trước khi xuất hồ sơ.

## Điểm cần kiểm tra tiếp

Cần xác nhận bằng test/runtime rằng các màn hình cùng dùng một dossier/property thay vì chỉ có các route song song. Cần rà soát version snapshot được chọn khi AI lập kế hoạch, trạng thái approve/review trước khi xuất, quyền admin ở các mutation, liên kết trực tiếp từ Hồ sơ của tôi tới land dossier, và cơ chế cập nhật khi thủ tục chính thức thay đổi. 
