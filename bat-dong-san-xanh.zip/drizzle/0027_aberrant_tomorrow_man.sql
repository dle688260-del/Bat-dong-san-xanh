CREATE TABLE `marketing_campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`objective` enum('sell','rent','consignment','buyer','area','project','brand') NOT NULL DEFAULT 'sell',
	`propertyId` int,
	`audience` varchar(255),
	`channelsJson` text,
	`budget` decimal(18,2),
	`startsAt` timestamp,
	`endsAt` timestamp,
	`status` enum('draft','active','paused','completed') NOT NULL DEFAULT 'draft',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marketing_campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `marketing_channels` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`channelType` enum('website','facebook','tiktok','zalo','youtube','email','google','other') NOT NULL,
	`handle` varchar(255),
	`active` tinyint NOT NULL DEFAULT 1,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marketing_channels_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `marketing_content_calendar` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentId` int NOT NULL,
	`campaignId` int,
	`propertyId` int,
	`channelType` enum('website','facebook','tiktok','zalo','youtube','email','google','other') NOT NULL,
	`scheduledAt` timestamp NOT NULL,
	`status` enum('planned','published','cancelled') NOT NULL DEFAULT 'planned',
	`note` text,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marketing_content_calendar_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `marketing_contents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int,
	`propertyId` int,
	`channelType` enum('website','facebook','tiktok','zalo','youtube','email','google','other') NOT NULL,
	`contentType` enum('title','description','facebook_post','website_copy','ad_copy','video_script','reel_script','email','message') NOT NULL,
	`title` varchar(255),
	`body` text NOT NULL,
	`status` enum('draft','pending_review','published','ended') NOT NULL DEFAULT 'draft',
	`aiGenerated` tinyint NOT NULL DEFAULT 0,
	`scheduledAt` timestamp,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marketing_contents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `marketingCampaignId` int;--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `marketingChannel` varchar(80);--> statement-breakpoint
ALTER TABLE `consultation_requests` ADD `marketingPropertyId` int;--> statement-breakpoint
ALTER TABLE `marketing_campaigns` ADD CONSTRAINT `marketing_campaigns_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_campaigns` ADD CONSTRAINT `marketing_campaigns_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_channels` ADD CONSTRAINT `marketing_channels_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_content_calendar` ADD CONSTRAINT `marketing_content_calendar_contentId_marketing_contents_id_fk` FOREIGN KEY (`contentId`) REFERENCES `marketing_contents`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_content_calendar` ADD CONSTRAINT `marketing_content_calendar_campaignId_marketing_campaigns_id_fk` FOREIGN KEY (`campaignId`) REFERENCES `marketing_campaigns`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_content_calendar` ADD CONSTRAINT `marketing_content_calendar_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_content_calendar` ADD CONSTRAINT `marketing_content_calendar_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_contents` ADD CONSTRAINT `marketing_contents_campaignId_marketing_campaigns_id_fk` FOREIGN KEY (`campaignId`) REFERENCES `marketing_campaigns`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_contents` ADD CONSTRAINT `marketing_contents_propertyId_properties_id_fk` FOREIGN KEY (`propertyId`) REFERENCES `properties`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `marketing_contents` ADD CONSTRAINT `marketing_contents_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `marketing_campaigns_property_idx` ON `marketing_campaigns` (`propertyId`);--> statement-breakpoint
CREATE INDEX `marketing_campaigns_status_idx` ON `marketing_campaigns` (`status`);--> statement-breakpoint
CREATE INDEX `marketing_channels_type_idx` ON `marketing_channels` (`channelType`);--> statement-breakpoint
CREATE INDEX `marketing_calendar_schedule_idx` ON `marketing_content_calendar` (`scheduledAt`);--> statement-breakpoint
CREATE INDEX `marketing_calendar_status_idx` ON `marketing_content_calendar` (`status`);--> statement-breakpoint
CREATE INDEX `marketing_contents_campaign_idx` ON `marketing_contents` (`campaignId`);--> statement-breakpoint
CREATE INDEX `marketing_contents_property_idx` ON `marketing_contents` (`propertyId`);--> statement-breakpoint
CREATE INDEX `marketing_contents_status_idx` ON `marketing_contents` (`status`);