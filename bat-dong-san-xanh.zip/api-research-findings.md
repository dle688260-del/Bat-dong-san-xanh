# Ghi nhận khảo sát API/SDK 3D và video

## Nguồn đã kiểm tra

- Matterport Developer Tools: kết quả tìm kiếm và trang hỗ trợ xác nhận Matterport có API/SDK cho phép kết nối chương trình với không gian và dữ liệu Matterport; trang cụ thể cần kiểm tra thêm bằng tài liệu API chính thức.
- Apple RoomPlan: RoomPlan là Swift API dựa trên ARKit, dùng camera và LiDAR trên iPhone/iPad để tạo floor plan 3D của phòng, gồm kích thước và loại đồ nội thất. Đầu ra là USD/USDZ với kích thước/vị trí các thành phần nhận diện được; phù hợp xây app iOS quét phòng, nhưng không phải API web chạy trực tiếp trong CRM.

## Hàm ý sơ bộ

RoomPlan phù hợp làm ứng dụng mobile companion để thu thập dữ liệu 3D rồi tải USDZ/ảnh/video về CRM. Matterport phù hợp nếu cần tour 3D thương mại có khả năng nhúng và API, nhưng cần xác minh gói thương mại, quyền truy cập API và chi phí trước khi chọn.
