# Nguồn rà soát tách/hợp thửa

Ngày tra cứu: 2026-08-21.

- Cổng DVC Quốc gia: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012784 — thủ tục “Tách thửa hoặc hợp thửa đất”; kết quả tìm kiếm ghi thời hạn không quá 12 ngày làm việc, trường hợp tương ứng có thể 22 ngày.
- Cổng Thông tin điện tử Chính phủ, Nghị định 101/2024/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=210791 — căn cứ đăng ký đất đai, cấp Giấy chứng nhận và hồ sơ địa chính.
- Cổng Thông tin điện tử Chính phủ, Nghị định 151/2025/NĐ-CP: https://vanban.chinhphu.vn/?pageid=27160&docid=213927 — phân định thẩm quyền chính quyền địa phương 02 cấp trong lĩnh vực đất đai.
- Hà Nội / Sở Nông nghiệp và Môi trường: https://sonnmt.hanoi.gov.vn/index.php/tin-t-c/d-t-dai/20689-t-7-10-2024-d-t-nh-hon-50m2-ha-n-i-khong-du-c-tach-th-a — thông tin về Quyết định 61/2024/QĐ-UBND; kết quả tìm kiếm nêu yêu cầu chiều dài/chiều rộng tối thiểu tại phường, thị trấn.
- TP.HCM / UBND thành phố: https://vpub.hochiminhcity.gov.vn/portal/pages/2024-11-1/Ban-hanh-Quy-dinh-ve-dieu-kien-tach-hop-thua-dat-vgqjvhnjhexyf.aspx — thông tin ban hành quy định điều kiện tách, hợp thửa và diện tích tối thiểu.
- Đà Nẵng: https://danang.gov.vn/w/dien-tich-toi-thieu-va-dieu-kien-khi-tach-thua-dat-hop-thua-dat-doi-voi-cac-loai-dat-tren-dia-ban-thanh-pho-i — thông tin diện tích tối thiểu và điều kiện tách/hợp thửa theo địa bàn.

Quy tắc sử dụng: các nguồn trên chỉ là căn cứ discovery/legal reference. Không gắn Official cho binary nếu chưa tải được file, kiểm tra chữ ký định dạng, provenance và SHA-256. Diện tích tối thiểu, kích thước, quy hoạch, lối đi và thời hạn phải tiếp tục đối chiếu theo địa phương/thời điểm cụ thể; không dùng một mức chung toàn quốc.

Nguồn tìm kiếm bổ trợ: https://pbgdpl.hanoi.gov.vn/giai-dap-phap-luat/-/asset_publisher/M248tqbaPaRY/content/nguyen-tac-ieu-kien-tach-thua-at; https://qhkt.hochiminhcity.gov.vn/thong-tin-chi-dao-dieu-hanh/tphcm-quy-dinh-dien-tich-toi-thieu-duoc-tach-thua-tren-dia-ban-thanh-pho-1534.html; https://danang.gov.vn/vi/web/dng/w/quy-dinh-dien-tich-toi-thieu-tach-thua-doi-voi-dat-o-i.

Lưu ý: kết quả tra cứu web là thông tin tham khảo để registry lưu URL; cần mở văn bản/điều khoản gốc khi xây dựng quyết định hồ sơ cụ thể.

## Bổ sung nguồn tra cứu ngày 2026-08-21

- Hà Nội, Cổng phổ biến giáo dục pháp luật: https://pbgdpl.hanoi.gov.vn/quy-dinh-moi/-/asset_publisher/sxBNLsQSLyY8/content/tach-thua-hop-thua-at-tai-ha-noi-tu-ngay-07-10-2024 — nêu điều kiện đất ở tại phường/thị trấn; cần đối chiếu đầy đủ theo loại đất và văn bản hiện hành.
- Hà Nội, Cổng phổ biến giáo dục pháp luật: https://pbgdpl.hanoi.gov.vn/giai-dap-phap-luat/-/asset_publisher/M248tqbaPaRY/content/nguyen-tac-ieu-kien-tach-thua-at — nêu nguyên tắc diện tích tối thiểu theo quy định UBND cấp tỉnh.
- TP.HCM, Cổng Công báo: https://congbao.hochiminhcity.gov.vn/tin-tuc-tong-hop/quy-%C4%91inh-dien-tich-toi-thieu-%C4%91uoc-tach-thua-tai-tp-hcm — nguồn giới thiệu Quyết định 60/2017/QĐ-UBND; cần ưu tiên đối chiếu với quy định hiện hành.
- TP.HCM, Cổng Văn phòng UBND: https://vpub.hochiminhcity.gov.vn/portal/pages/2024-11-1/Ban-hanh-Quy-dinh-ve-dieu-kien-tach-hop-thua-dat-vgqjvhnjhexyf.aspx — nguồn về Quyết định 100/2024/QĐ-UBND.
- Đà Nẵng, Cổng thông tin thành phố: https://danang.gov.vn/w/quy-dinh-moi-ve-dien-tich-toi-thieu-khi-tach-thua-dat-o-tren-dia-ban-thanh-pho-i — nguồn về điều kiện diện tích/kích thước đất ở được bài viết dẫn.
- Đà Nẵng, Cổng thông tin thành phố: https://danang.gov.vn/w/quy-dinh-han-muc-dat-o-va-dien-tich-toi-thieu-tach-thua-dat-i — nguồn bổ trợ về hạn mức và diện tích tối thiểu.

> Các URL địa phương chỉ được dùng làm legal reference/discovery. Không gắn Official cho binary nếu chưa tải file, xác minh provenance, chữ ký định dạng và SHA-256. Không dùng một mức diện tích hoặc thời hạn chung cho mọi địa phương.
