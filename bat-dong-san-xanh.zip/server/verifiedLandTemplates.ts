import type { VerifiedTemplateAsset, VerifiedTemplateFormat } from "./landTemplateEngine";

/**
 * Server-only allowlist. Do not populate this map from client input.
 * Each entry must be added only after the official binary has been downloaded,
 * inspected, checksum-recorded, and stored under the declared storage key.
 */
const VERIFIED_LAND_TEMPLATES: Record<string, VerifiedTemplateAsset> = {
  // Mẫu 11/ĐK (Mẫu số 11/ĐK) được công khai cùng bài viết của Cổng Thông tin điện tử
  // Chính phủ về Nghị định 101/2024/NĐ-CP. Binary đã tải lại, kiểm tra chữ ký
  // DOCX và đối chiếu SHA-256 trước khi đưa vào allowlist.
  "variation-form:docx": {
    id: "mau-11-dk-nd101-2024-official",
    fileName: "mau-11-dk-nd101-2024.docx",
    format: "docx",
    mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    sourceUrl: "https://xdcs.cdnchinhphu.vn/446259493575335936/2024/8/1/dangkybiendongdat-17225018464101254582634.docx",
    sourceCheckedAt: "2026-08-19",
    sha256: "6d029d2c8bc920380de658dfc4e69cb2ecc19261c4ff6fbc9f3579da4774026c",
    storageKey: "official-land-templates/mau-11-dk-nd101-2024_38358437.docx",
    sourceStatus: "verified",
  },
};

export function getVerifiedLandTemplate(documentType: string, format: VerifiedTemplateFormat) {
  return VERIFIED_LAND_TEMPLATES[`${documentType}:${format}`] ?? null;
}

export function listVerifiedLandTemplates() {
  return Object.values(VERIFIED_LAND_TEMPLATES);
}
