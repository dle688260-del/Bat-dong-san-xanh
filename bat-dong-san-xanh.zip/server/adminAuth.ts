import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";

const scrypt = (password: string | Buffer, salt: string | Buffer, keylen: number, options: { N: number; r: number; p: number }) => new Promise<Buffer>((resolve, reject) => {
  scryptCallback(password, salt, keylen, options, (error, derivedKey) => {
    if (error) reject(error);
    else resolve(derivedKey as Buffer);
  });
});

const KEY_LENGTH = 64;
const SCRYPT_N = 16_384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;

type PasswordHashParts = {
  salt: Buffer;
  hash: Buffer;
  n: number;
  r: number;
  p: number;
};

function safeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  if (leftBuffer.length !== rightBuffer.length) return false;
  return timingSafeEqual(leftBuffer, rightBuffer);
}

function safeBufferEqual(left: Buffer, right: Buffer) {
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

function parsePasswordHash(encoded: string): PasswordHashParts | null {
  const [algorithm, nText, rText, pText, saltText, hashText] = encoded.split("$");
  if (algorithm !== "scrypt" || !nText || !rText || !pText || !saltText || !hashText) return null;
  const n = Number(nText);
  const r = Number(rText);
  const p = Number(pText);
  if (!Number.isSafeInteger(n) || !Number.isSafeInteger(r) || !Number.isSafeInteger(p)) return null;
  try {
    return { n, r, p, salt: Buffer.from(saltText, "base64url"), hash: Buffer.from(hashText, "base64url") };
  } catch {
    return null;
  }
}

export async function hashAdminPassword(password: string) {
  if (!password) throw new Error("Password is required");
  const salt = randomBytes(16);
  const derived = (await scrypt(password, salt, KEY_LENGTH, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P })) as Buffer;
  return `scrypt$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt.toString("base64url")}$${derived.toString("base64url")}`;
}

export async function verifyAdminPasswordHash(password: string, encoded: string) {
  const parts = parsePasswordHash(encoded);
  if (!parts || !password || parts.hash.length === 0) return false;
  try {
    const derived = (await scrypt(password, parts.salt, parts.hash.length, { N: parts.n, r: parts.r, p: parts.p })) as Buffer;
    return safeBufferEqual(derived, parts.hash);
  } catch {
    return false;
  }
}

export function verifyAdminCredentials(username: string, password: string) {
  const configuredUsername = process.env.ADMIN_USERNAME ?? "";
  const configuredPassword = process.env.ADMIN_PASSWORD ?? "";
  if (!configuredUsername || !configuredPassword || !username || !password) return false;
  return safeEqual(username, configuredUsername) && safeEqual(password, configuredPassword);
}

export async function verifyAdminPassword(username: string, password: string, storedHash?: string | null) {
  if (storedHash && await verifyAdminPasswordHash(password, storedHash)) return true;
  return verifyAdminCredentials(username, password);
}

export function validateAdminPassword(password: string) {
  return password.length >= 10 && password.length <= 256 && /[A-Za-z]/.test(password) && /\d/.test(password);
}
