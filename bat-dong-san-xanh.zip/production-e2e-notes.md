# Ghi nhận kiểm thử production

- Ngày kiểm thử: 2026-08-23.
- Production: https://batdongsan-7bupubgw.manus.space
- Đăng nhập admin bằng thông tin do người dùng cung cấp đã thành công; dashboard hiển thị Quản trị viên.
- Route `/ai-ho-so-dat-dai-tu-dong` tải thành công sau khi chờ skeleton.
- Danh sách thủ tục production hiển thị `Tất cả 74`.
- Đã chọn được mã `2.000889`: “Đăng ký biến động quyền sử dụng đất do chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn”.
- Module hiển thị 7 bước: chọn thủ tục/nguồn, nhập thông tin, tải/chụp giấy tờ & OCR, AI phân tích, chuẩn bị bản nháp, xem lại & xác nhận, xuất DOCX/PDF.
- Registry dùng chung và các lớp nguồn đang hiển thị; cần tiếp tục cuộn tới khu vực chọn tỉnh/thông tin để kiểm tra chuyển bước.
- Chưa tải giấy tờ, chưa chạy OCR/phân tích và chưa xuất hồ sơ.

- Sau khi chọn mã 2.000889, DOM production có trường `Tỉnh/thành (tùy chọn)` ở Bước 2; trường đang trống và đã được đưa vào giữa viewport để nhập Đà Nẵng.

- Sau thao tác nhập địa phương, production chuyển sang trạng thái “AI đang tự quét nguồn theo mã và tỉnh/thành…” và nút “Đang nạp nguồn…”. Cần đợi hoàn tất rồi xác minh mã đang được chọn; ảnh viewport tại thời điểm này hiển thị một thẻ `1.012820` được tô sáng, nên không được giả định rằng mã 2.000889 vẫn đang active nếu chưa đọc lại trạng thái.

- Kiểm tra DOM xác nhận trường tỉnh vẫn rỗng và thẻ active bị chuyển nhầm sang mã `1.012820`; đã chọn lại trực tiếp thẻ `2.000889` bằng thao tác production có kiểm soát. Chưa coi bước chọn tỉnh hoàn tất cho tới khi đọc lại giá trị input và mã active.

- Sau khi chọn đúng mã `2.000889`, production gửi request `aiAutoDossier.discover` có thời lượng khoảng 25–26 giây; input tỉnh/thành vẫn để trống và không bị disable. Giao diện tiếp tục hiển thị trạng thái quét/nạp nguồn, vì vậy chưa thể chuyển sang Bước 2 hay kết luận bundle theo Đà Nẵng đã được nạp.

- Sau khi chờ thêm, production hiển thị lỗi `Unexpected token 'S', "Service Unavailable" is not valid JSON` tại root; giao diện vẫn ở vùng quét nguồn. Đây là lỗi upstream/runtime 503 của request tRPC discover, không phải bằng chứng bundle 2.000889 đã hoàn tất.

Kết quả lần thử production ngày 2026-08-23: đăng nhập admin thành công và truy cập được dashboard/module. Catalog hiển thị 74 thủ tục; đã chọn đúng mã `2.000889` (đăng ký biến động quyền sử dụng đất do chuyển nhượng, cho thuê, thừa kế, tặng cho, góp vốn) và giữ tỉnh `Đà Nẵng`. Sau khi tải lại, lỗi `Unexpected token 'S', "Service Unavailable" is not valid JSON` tái diễn khi workflow discover gọi backend; giao diện chưa chuyển sang Bước 2. Chưa tải giấy tờ, chưa OCR, chưa phân tích và chưa xuất hồ sơ. Không có dữ liệu hồ sơ thật nào được tạo hoặc xuất.
