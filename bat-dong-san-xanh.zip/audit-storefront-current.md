# Rà soát storefront hiện tại

- Ngày kiểm tra: 2026-08-26.
- URL: https://batdongsan-7bupubgw.manus.space/
- Kết quả browser preview: trang trả về tiêu đề đúng “Bất động sản xanh Đà Nẵng · Miền Trung · Toàn quốc”, nhưng viewport gần như trắng và chỉ thấy nhãn “Made with Manus”.
- Console browser: chưa ghi nhận lỗi JavaScript.
- Ưu tiên tiếp theo: kiểm tra request/network và trạng thái render để xác định storefront production có đang tải bundle/chờ dữ liệu hay không, trước khi bổ sung thêm giao diện.

## Kiểm tra mẫu thủ công trong Hồ sơ AI
- Route kiểm tra: `/hs-dat-dai-ai`.
- Preview mobile 390×844 mở được trang Hồ sơ AI; phần đầu trang không bị lỗi trắng hoặc tràn ngang.
- Thẻ mẫu thủ công được đặt trong bước chọn thủ tục, hiển thị tên mẫu, mục đích dùng để in/mở trên điện thoại và nút tải DOCX.
- File mẫu dùng storage path `/manus-storage/phieu-dam-phan-bds_62098c93.docx`; đã kiểm tra archive DOCX hợp lệ bằng `unzip -t`.
