import DashboardLayout from "@/components/DashboardLayout";
import {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType,
} from "docx";
import { trpc } from "@/lib/trpc";
import { useEffect, useMemo, useState } from "react";
import {
  ClipboardCheck,
  Download,
  FileDown,
  FileUp,
  FolderKanban,
  History,
  Loader2,
  MapPin,
  Megaphone,
  Plus,
  Save,
  Search,
  ShieldAlert,
  SlidersHorizontal,
  Trash2,
  UserRound,
  Users,
  Handshake,
  Scale,
  CheckCircle2,
  Clock3,
  Copy,
  ExternalLink,
  Send,
  Video,
  Globe2,
  Home,
  Ruler,
  DollarSign,
  Compass,
  FileText,
  BadgeCheck,
} from "lucide-react";
import { toast } from "sonner";
import WorkflowFileManager from "@/components/WorkflowFileManager";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export const PROPERTY_DOSSIER_STEP_NAMES = [
  "Tiếp nhận thông tin BĐS",
  "Khảo sát sơ bộ",
  "Khảo sát thực tế",
  "Kiểm tra quy hoạch",
  "Kiểm tra pháp lý",
  "Định giá BĐS",
  "Tiếp nhận ký gửi",
  "Đăng bán",
  "Quản lý khách mua",
  "Xem BĐS",
  "Đàm phán & giao dịch",
  "Hoàn tất",
];

export const PROPERTY_DOSSIER_TYPES = [
  { value: "land", label: "Đất nền" },
  { value: "agricultural_land", label: "Đất nông nghiệp" },
  { value: "apartment", label: "Căn hộ" },
  { value: "house", label: "Nhà phố" },
  { value: "resort", label: "Khu nghỉ dưỡng" },
  { value: "villa_resort", label: "Villa / Resort" },
] as const;

export const PROPERTY_DOSSIER_STATUS_META = {
  completed: {
    label: "Đã hoàn thành",
    className: "bg-[#E4F4EA] text-[#17634D]",
  },
  in_progress: {
    label: "Đang xử lý",
    className: "bg-[#FFF4D7] text-[#6F5617]",
  },
  not_started: {
    label: "Chưa thực hiện",
    className: "bg-[#EEF8F2] text-[#60766D]",
  },
  needs_review: {
    label: "Cần kiểm tra lại",
    className: "bg-red-100 text-red-800",
  },
} as const;

type StepStatus = keyof typeof PROPERTY_DOSSIER_STATUS_META;

export type DossierFontSize = "standard" | "large" | "extra-large";
export const DOSSIER_FONT_SIZES: Array<{
  id: DossierFontSize;
  label: string;
  description: string;
}> = [
  { id: "standard", label: "Tiêu chuẩn", description: "Cỡ chữ mặc định" },
  { id: "large", label: "Lớn", description: "Dễ đọc hơn" },
  { id: "extra-large", label: "Rất lớn", description: "Ưu tiên kiểm tra" },
];

const DOSSIER_FONT_SIZE_STORAGE_KEY = "bdsxanh-dossier-font-size";

export const DOSSIER_STEP_FIELDS: Record<
  number,
  Array<{ key: string; label: string; placeholder: string }>
> = {
  0: [
    {
      key: "ownerName",
      label: "Họ tên chủ nhà",
      placeholder: "Nhập họ tên chủ nhà",
    },
    {
      key: "ownerPhone",
      label: "Số điện thoại",
      placeholder: "Nhập số điện thoại",
    },
    {
      key: "address",
      label: "Địa chỉ BĐS",
      placeholder: "Nhập địa chỉ tài sản",
    },
    {
      key: "propertyType",
      label: "Loại BĐS",
      placeholder: "Nhà phố, đất nền, căn hộ...",
    },
    {
      key: "expectedPrice",
      label: "Giá chủ nhà mong muốn",
      placeholder: "Ví dụ: 7,9 tỷ",
    },
    {
      key: "saleNeed",
      label: "Nhu cầu bán",
      placeholder: "Thời gian, điều kiện, lý do bán...",
    },
    {
      key: "assignee",
      label: "Người tiếp nhận",
      placeholder: "Tên chuyên viên phụ trách",
    },
  ],
  1: [
    { key: "landArea", label: "Diện tích", placeholder: "Ví dụ: 95 m²" },
    { key: "frontage", label: "Mặt tiền", placeholder: "Ví dụ: 5,5 m" },
    { key: "direction", label: "Hướng", placeholder: "Ví dụ: Đông Nam" },
    {
      key: "road",
      label: "Đường giao thông",
      placeholder: "Ví dụ: đường 5,5 m",
    },
    { key: "position", label: "Vị trí", placeholder: "Mô tả vị trí" },
    {
      key: "condition",
      label: "Hiện trạng nhà/đất",
      placeholder: "Mô tả hiện trạng",
    },
  ],
  2: [
    {
      key: "surveyDate",
      label: "Ngày khảo sát",
      placeholder: "Nhập ngày khảo sát",
    },
    {
      key: "observedCondition",
      label: "Hiện trạng thực tế",
      placeholder: "Kết quả kiểm tra tại hiện trường",
    },
    { key: "strengths", label: "Ưu điểm", placeholder: "Các ưu điểm ghi nhận" },
    {
      key: "limitations",
      label: "Hạn chế",
      placeholder: "Các hạn chế cần lưu ý",
    },
  ],
  3: [
    {
      key: "planningStatus",
      label: "Tình trạng quy hoạch",
      placeholder: "Không vướng / cần kiểm tra...",
    },
    {
      key: "roadBoundary",
      label: "Lộ giới và đường dự phóng",
      placeholder: "Thông tin lộ giới",
    },
    {
      key: "constructionLine",
      label: "Chỉ giới xây dựng",
      placeholder: "Thông tin chỉ giới",
    },
  ],
  4: [
    {
      key: "certificateType",
      label: "Loại giấy chứng nhận",
      placeholder: "Sổ đỏ / Sổ hồng",
    },
    {
      key: "certificateArea",
      label: "Diện tích trên giấy",
      placeholder: "Diện tích theo giấy tờ",
    },
    {
      key: "landUse",
      label: "Mục đích sử dụng đất",
      placeholder: "Đất ở, đất nông nghiệp...",
    },
    {
      key: "legalOwner",
      label: "Chủ sở hữu",
      placeholder: "Tên trên giấy chứng nhận",
    },
    {
      key: "mortgage",
      label: "Thế chấp/tranh chấp",
      placeholder: "Tình trạng xác minh",
    },
  ],
  5: [
    { key: "ownerPrice", label: "Giá chủ nhà đưa ra", placeholder: "Nhập giá" },
    {
      key: "marketPrice",
      label: "Giá tham khảo thị trường",
      placeholder: "Nhập giá tham khảo",
    },
    {
      key: "recommendedPrice",
      label: "Giá đề xuất",
      placeholder: "Nhập giá đề xuất",
    },
    {
      key: "negotiation",
      label: "Mức thương lượng dự kiến",
      placeholder: "Ví dụ: 3–5%",
    },
  ],
  6: [
    {
      key: "consignmentTerms",
      label: "Thỏa thuận ký gửi",
      placeholder: "Nội dung thỏa thuận",
    },
    { key: "brokerFee", label: "Phí môi giới", placeholder: "Nhập mức phí" },
    {
      key: "consignmentTerm",
      label: "Thời hạn ký gửi",
      placeholder: "Nhập thời hạn",
    },
    {
      key: "fileStatus",
      label: "Tình trạng hồ sơ",
      placeholder: "Đủ / thiếu giấy tờ...",
    },
  ],
  7: [
    {
      key: "listingTitle",
      label: "Tiêu đề đăng bán",
      placeholder: "Nhập tiêu đề bài đăng",
    },
    {
      key: "listingDescription",
      label: "Mô tả đăng bán",
      placeholder: "Nội dung giới thiệu BĐS",
    },
    {
      key: "publishedChannels",
      label: "Kênh đăng",
      placeholder: "Website, Facebook, Zalo...",
    },
  ],
  8: [
    { key: "buyerName", label: "Khách hàng", placeholder: "Tên khách mua" },
    { key: "buyerNeed", label: "Nhu cầu", placeholder: "Nhu cầu cụ thể" },
    {
      key: "buyerBudget",
      label: "Ngân sách",
      placeholder: "Ngân sách dự kiến",
    },
    {
      key: "contactSchedule",
      label: "Lịch liên hệ/xem",
      placeholder: "Ngày giờ liên hệ",
    },
  ],
  9: [
    { key: "viewingDate", label: "Ngày xem BĐS", placeholder: "Nhập ngày xem" },
    {
      key: "buyerFeedback",
      label: "Ý kiến khách",
      placeholder: "Ghi nhận ý kiến",
    },
    {
      key: "interestLevel",
      label: "Mức độ quan tâm",
      placeholder: "Cao / vừa / thấp",
    },
  ],
  10: [
    {
      key: "offerPrice",
      label: "Giá đề xuất",
      placeholder: "Nhập giá khách đề xuất",
    },
    { key: "deposit", label: "Tiền đặt cọc", placeholder: "Nhập số tiền" },
    {
      key: "dealConditions",
      label: "Điều kiện giao dịch",
      placeholder: "Các điều kiện thỏa thuận",
    },
    {
      key: "dealStatus",
      label: "Trạng thái giao dịch",
      placeholder: "Đang đàm phán...",
    },
  ],
  11: [
    {
      key: "notary",
      label: "Công chứng/thanh toán",
      placeholder: "Tình trạng công chứng và thanh toán",
    },
    { key: "transfer", label: "Sang tên", placeholder: "Tình trạng sang tên" },
    {
      key: "handover",
      label: "Bàn giao hồ sơ/tài sản",
      placeholder: "Ngày và nội dung bàn giao",
    },
    {
      key: "brokerFeeCompletion",
      label: "Hoàn tất phí môi giới",
      placeholder: "Tình trạng thanh toán phí",
    },
  ],
};

export const PROPERTY_DOSSIER_DELETE_LABEL = "Xóa bài";
export const CRM_DOSSIER_MODULES = [
  { label: "Thông tin BĐS", icon: FolderKanban, step: 0 },
  { label: "Chủ nhà", icon: UserRound, step: 0 },
  { label: "Khảo sát thực tế", icon: ClipboardCheck, step: 2 },
  { label: "Pháp lý", icon: Scale, step: 4 },
  { label: "Quy hoạch", icon: MapPin, step: 3 },
  { label: "Định giá", icon: Handshake, step: 5 },
  { label: "Marketing", icon: Megaphone, step: 7 },
  { label: "Khách hàng", icon: Users, step: 8 },
  { label: "Giao dịch", icon: Handshake, step: 10 },
  { label: "Tài liệu", icon: FileDown, step: 0 },
  { label: "Lịch sử cập nhật", icon: History, step: 0 },
] as const;

function formatDate(value: unknown) {
  if (!value) return "—";
  return new Date(value as string | number | Date).toLocaleDateString("vi-VN");
}

function formatPrice(value: unknown) {
  if (value === null || value === undefined || value === "") return "—";
  const number = Number(value);
  return Number.isFinite(number)
    ? `${new Intl.NumberFormat("vi-VN").format(number)} đ`
    : String(value);
}

export type DossierSyncStep = { details?: string | null };

export function getDossierSyncRows(
  steps: DossierSyncStep[] = [],
  property: Record<string, unknown> = {}
) {
  const readFields = (index: number) => {
    try {
      const parsed = steps[index]?.details
        ? JSON.parse(steps[index].details as string)
        : null;
      return (parsed?.fields || {}) as Record<string, string>;
    } catch {
      return {};
    }
  };
  const owner = readFields(0);
  const survey = readFields(2);
  const planning = readFields(3);
  const legal = readFields(4);
  const valuation = readFields(5);
  const buyer = readFields(8);
  const viewing = readFields(9);
  return [
    ["Chủ nhà", owner.ownerName || ""],
    ["Số điện thoại", owner.ownerPhone || ""],
    [
      "Diện tích khảo sát",
      survey.area || survey.landArea || property.area
        ? `${survey.area || survey.landArea || property.area} m²`
        : "",
    ],
    [
      "Mặt tiền / đường",
      survey.frontage || survey.roadWidth || survey.road || "",
    ],
    [
      "Hướng",
      survey.orientation || survey.direction || property.orientation || "",
    ],
    [
      "Pháp lý",
      legal.certificateType ||
        property.certificateType ||
        property.legalStatus ||
        "",
    ],
    ["Quy hoạch", planning.planningStatus || ""],
    [
      "Giá đề xuất",
      valuation.recommendedPrice || property.price
        ? String(valuation.recommendedPrice || formatPrice(property.price))
        : "",
    ],
    ["Khách mua", buyer.buyerName || ""],
    ["Lịch xem nhà", viewing.viewingDate || viewing.contactSchedule || ""],
  ] as const;
}

function propertyTypeLabel(value: unknown) {
  const labels: Record<string, string> = {
    house: "Nhà phố",
    land: "Đất nền",
    apartment: "Căn hộ",
    villa: "Villa / Resort",
  };
  return labels[String(value)] || String(value || "Chưa cập nhật");
}

function dossierStatusLabel(value: unknown) {
  const labels: Record<string, string> = {
    draft: "Bản nháp",
    published: "Đang bán",
    reserved: "Đã giữ chỗ",
    sold: "Đã bán",
  };
  return labels[String(value)] || "Chưa cập nhật";
}

function SummaryItem({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: unknown;
  icon?: React.ElementType;
}) {
  return (
    <div className="flex min-w-0 items-start gap-3 rounded-xl bg-[#FBFCFA] p-3 shadow-sm ring-1 ring-[#EEF2ED]">
      <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#EEF5F0] text-[#2C6A57]">
        {Icon ? <Icon size={17} /> : <FolderKanban size={17} />}
      </span>
      <div className="min-w-0">
        <p className="text-[11px] font-medium text-[#70847A]">{label}</p>
        <p className="mt-1 break-words text-sm font-bold text-[#18352D]">
          {value === null || value === undefined || value === ""
            ? "—"
            : String(value)}
        </p>
      </div>
    </div>
  );
}

function DetailCard({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-[#E1E8E0] bg-white p-4 shadow-sm sm:p-5">
      <h4 className="font-semibold text-[#18352D]">{title}</h4>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function DetailRow({ label, value }: { label: string; value: unknown }) {
  return (
    <div className="grid grid-cols-[minmax(7.5rem,0.85fr)_minmax(0,1.6fr)] items-start gap-x-5 border-b border-[#EEF2ED] py-3 text-sm last:border-b-0 sm:gap-x-8">
      <span className="min-w-0 font-medium leading-6 text-[#70847A]">
        {label}
      </span>
      <span className="min-w-0 break-words text-left font-semibold leading-6 text-[#18352D]">
        {value === null || value === undefined || value === ""
          ? "—"
          : String(value)}
      </span>
    </div>
  );
}

type PublishingChannel = "facebook" | "google" | "youtube" | "tiktok" | "zalo";
type PublishingAccountType = "page_oa" | "personal";
type PublishingTaskStatus = "draft" | "review" | "approved" | "queued";
type WritingStyle = "concise" | "professional" | "facebook";

export function buildManualPublishTarget(
  channelId: "facebook" | "zalo",
  title: string,
  description: string
) {
  const encodedText = encodeURIComponent(`${title}\n\n${description}`);
  return channelId === "facebook"
    ? `https://www.facebook.com/sharer/sharer.php?quote=${encodedText}`
    : "https://chat.zalo.me/";
}

export const AI_WRITING_STYLES: Array<{
  id: WritingStyle;
  label: string;
  description: string;
}> = [
  { id: "concise", label: "Ngắn gọn", description: "Súc tích, dễ đọc" },
  {
    id: "professional",
    label: "Chuyên nghiệp",
    description: "Minh bạch, đáng tin cậy",
  },
  {
    id: "facebook",
    label: "Tối ưu Facebook",
    description: "Có CTA và hashtag",
  },
];

export const DOSSIER_AI_OUTPUT_FIELDS = [
  "summary",
  "strengths",
  "missingInformation",
  "warnings",
  "listingTitle",
  "listingDescription",
  "shortCaption",
  "hashtags",
] as const;

export const PUBLISHING_CHANNELS: Array<{
  id: PublishingChannel;
  label: string;
  description: string;
  icon: typeof Globe2;
  tone: string;
}> = [
  {
    id: "facebook",
    label: "Facebook Page",
    description: "Bài viết, ảnh và video trên Fanpage",
    icon: Globe2,
    tone: "#1877F2",
  },
  {
    id: "google",
    label: "Google Business",
    description: "Bài cập nhật trên Hồ sơ doanh nghiệp",
    icon: Globe2,
    tone: "#4285F4",
  },
  {
    id: "youtube",
    label: "YouTube",
    description: "Video giới thiệu BĐS",
    icon: Video,
    tone: "#D93025",
  },
  {
    id: "tiktok",
    label: "TikTok",
    description: "Video ngắn giới thiệu tài sản",
    icon: Video,
    tone: "#111827",
  },
  {
    id: "zalo",
    label: "Zalo OA",
    description: "Nội dung dành cho Official Account",
    icon: Send,
    tone: "#0068FF",
  },
];

function PublishingTaskPanel({ dossier }: { dossier: any }) {
  const property = dossier.property || {};
  const storageKey = `bdsxanh-publishing-task-${dossier.dossier.id}`;
  const defaultTitle = property.title || "Bất động sản cần cập nhật tiêu đề";
  const defaultDescription =
    property.description ||
    `Thông tin BĐS tại ${property.location || "Đà Nẵng"}. Liên hệ Bất động sản xanh để nhận tư vấn và đặt lịch xem thực tế.`;
  const [title, setTitle] = useState(defaultTitle);
  const [description, setDescription] = useState(defaultDescription);
  const [writingStyle, setWritingStyle] =
    useState<WritingStyle>("professional");
  const [channels, setChannels] = useState<Record<PublishingChannel, boolean>>({
    facebook: true,
    google: true,
    youtube: false,
    tiktok: false,
    zalo: true,
  });
  const [status, setStatus] = useState<PublishingTaskStatus>("draft");
  const [accountTypes, setAccountTypes] = useState<Record<"facebook" | "zalo", PublishingAccountType>>({
    facebook: "page_oa",
    zalo: "page_oa",
  });
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [activityLog, setActivityLog] = useState<
    Array<{ label: string; at: string }>
  >([]);
  const [aiResult, setAiResult] = useState<{
    summary: string;
    strengths: string[];
    missingInformation: string[];
    warnings: string[];
    hashtags: string[];
  } | null>(null);
  const analyzeDossier = trpc.ai.analyzeDossier.useMutation({
    onSuccess: result => {
      setTitle(result.listingTitle);
      setDescription(result.listingDescription);
      setAiResult(result);
      toast.success("AI đã phân tích hồ sơ và tạo bản nháp để bạn kiểm tra");
    },
    onError: error =>
      toast.error(error.message || "Không thể phân tích hồ sơ lúc này"),
  });

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(storageKey);
      if (!saved) return;
      const parsed = JSON.parse(saved);
      if (parsed.title) setTitle(parsed.title);
      if (parsed.description) setDescription(parsed.description);
      if (parsed.channels)
        setChannels(current => ({ ...current, ...parsed.channels }));
      if (parsed.status) setStatus(parsed.status);
      if (parsed.accountTypes)
        setAccountTypes(current => ({ ...current, ...parsed.accountTypes }));
      setSavedAt(parsed.savedAt || null);
      setActivityLog(
        Array.isArray(parsed.activityLog) ? parsed.activityLog : []
      );
    } catch {
      /* Bỏ qua dữ liệu cục bộ không hợp lệ. */
    }
  }, [storageKey]);

  const selectedChannels = PUBLISHING_CHANNELS.filter(
    channel => channels[channel.id]
  );
  const accountLabel = (channelId: PublishingChannel) =>
    channelId === "facebook" || channelId === "zalo"
      ? accountTypes[channelId] === "personal"
        ? "Tài khoản cá nhân · thủ công"
        : channelId === "facebook"
          ? "Facebook Page · API"
          : "Zalo OA · API"
      : "Kênh quản trị · hàng đợi";
  const selectedAccountSummary = selectedChannels
    .map(channel => `${channel.label} (${accountLabel(channel.id)})`)
    .join(" · ");
  const saveTask = (nextStatus: PublishingTaskStatus = status) => {
    if (!title.trim() || !description.trim()) {
      toast.error("Hãy nhập tiêu đề và nội dung trước khi lưu.");
      return;
    }
    if (!selectedChannels.length) {
      toast.error("Hãy chọn ít nhất một kênh phát hành.");
      return;
    }
    const nextSavedAt = new Date().toISOString();
    const logEntry = {
      label:
        `${nextStatus === "review" ? "Chuyển tác vụ sang chờ duyệt" : nextStatus === "approved" ? "Duyệt nội dung, chưa đăng thật" : "Lưu bản nháp phát hành"}${selectedAccountSummary ? ` · ${selectedAccountSummary}` : ""}`,
      at: nextSavedAt,
    };
    const nextLog = [logEntry, ...activityLog].slice(0, 8);
    window.localStorage.setItem(
      storageKey,
      JSON.stringify({
        title,
        description,
        channels,
        accountTypes,
        status: nextStatus,
        savedAt: nextSavedAt,
        activityLog: nextLog,
      })
    );
    setStatus(nextStatus);
    setSavedAt(nextSavedAt);
    setActivityLog(nextLog);
    toast.success(
      nextStatus === "review"
        ? "Đã chuyển tác vụ sang chờ duyệt"
        : nextStatus === "approved"
          ? "Đã duyệt nội dung; chưa đăng thật"
          : "Đã lưu tác vụ phát hành"
    );
  };
  const copyDraft = () =>
    navigator.clipboard
      ?.writeText(`${title}\n\n${description}`)
      .then(() => toast.success("Đã sao chép nội dung bản nháp"))
      .catch(() => toast.error("Không thể sao chép nội dung"));
  const statusMeta = {
    draft: { label: "Bản nháp", className: "bg-[#EEF8F2] text-[#60766D]" },
    review: { label: "Chờ duyệt", className: "bg-[#FFF4D7] text-[#6F5617]" },
    approved: {
      label: "Đã duyệt, chưa đăng",
      className: "bg-[#E4F4EA] text-[#17634D]",
    },
    queued: { label: "Đã xếp hàng", className: "bg-[#E4F4EA] text-[#17634D]" },
  }[status];
  const requestConnection = (channelLabel: string) =>
    toast.info(
      `Cần kết nối ${channelLabel} trong phần Tích hợp trước khi đăng thật.`
    );
  const openManualPost = (channelId: "facebook" | "zalo") => {
    const platformLabel = channelId === "facebook" ? "Facebook cá nhân" : "Zalo cá nhân";
    const confirmed = window.confirm(
      `Bạn sắp mở ${platformLabel} để tự kiểm tra và đăng bài. Nội dung sẽ được sao chép; hệ thống không tự đăng thay bạn. Tiếp tục?`
    );
    if (!confirmed) return;
    const shareText = `${title}\n\n${description}`;
    const target = buildManualPublishTarget(channelId, title, description);
    window.open(target, "_blank", "noopener,noreferrer");
    navigator.clipboard?.writeText(shareText).catch(() => undefined);
    const nextSavedAt = new Date().toISOString();
    const nextLog = [
      { label: `Mở ${channelId === "facebook" ? "Facebook cá nhân" : "Zalo cá nhân"} để đăng thủ công · đã sao chép nội dung`, at: nextSavedAt },
      ...activityLog,
    ].slice(0, 8);
    window.localStorage.setItem(storageKey, JSON.stringify({
      title,
      description,
      channels,
      accountTypes,
      status,
      savedAt: nextSavedAt,
      activityLog: nextLog,
    }));
    setSavedAt(nextSavedAt);
    setActivityLog(nextLog);
    toast.success(`Đã mở ${channelId === "facebook" ? "Facebook" : "Zalo"}; nội dung đã được sao chép để bạn dán và đăng.`);
  };
  const runAiAnalysis = () =>
    analyzeDossier.mutate({
      style: writingStyle,
      property,
      steps: (dossier.steps || []).map((step: any, index: number) => ({
        stepNumber: index + 1,
        name: PROPERTY_DOSSIER_STEP_NAMES[index],
        status: step.status || "not_started",
        details: step.details || null,
        notes: step.notes || null,
      })),
      documentNames: (dossier.documents || [])
        .map((document: any) => document.fileName)
        .filter(Boolean),
    });

  return (
    <div className="space-y-4">
      <DetailCard title="Tác vụ đăng bài đa kênh">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm leading-6 text-[#60766D]">
              Soạn nội dung một lần, chọn các kênh cần phát hành và duyệt thủ
              công trước khi kết nối API đăng thật.
            </p>
            {savedAt && (
              <p className="mt-2 text-xs text-[#70847A]">
                Lưu cục bộ lần cuối: {new Date(savedAt).toLocaleString("vi-VN")}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <div className="flex flex-wrap gap-2">
              {AI_WRITING_STYLES.map(style => (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => setWritingStyle(style.id)}
                  className={`rounded-lg border px-3 py-2 text-left transition ${writingStyle === style.id ? "border-[#C9972B] bg-[#FFF8E7] text-[#7A5B18]" : "border-[#D9DED7] bg-white text-[#60766D] hover:border-[#B9CDBB]"}`}
                >
                  <span className="block text-xs font-bold">{style.label}</span>
                  <span className="block text-[10px]">{style.description}</span>
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={runAiAnalysis}
              disabled={analyzeDossier.isPending}
              className="inline-flex items-center gap-2 rounded-lg bg-[#C9972B] px-3 py-2 text-xs font-bold text-white hover:bg-[#AD7F1F] disabled:opacity-60"
            >
              <Megaphone size={14} />
              {analyzeDossier.isPending
                ? "AI đang phân tích..."
                : "AI tự phân tích & viết"}
            </button>
            <span
              className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold ${statusMeta.className}`}
            >
              <Clock3 size={13} />
              {statusMeta.label}
            </span>
          </div>
        </div>
        <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_0.9fr]">
          <div className="space-y-4">
            <label className="block text-sm font-semibold">
              Tiêu đề bài đăng
              <input
                value={title}
                onChange={event => setTitle(event.target.value)}
                className="mt-2 min-h-11 w-full rounded-xl border border-[#D9DED7] bg-white px-3 text-sm"
              />
            </label>
            <label className="block text-sm font-semibold">
              Nội dung dùng chung
              <textarea
                value={description}
                onChange={event => setDescription(event.target.value)}
                className="mt-2 min-h-36 w-full rounded-xl border border-[#D9DED7] bg-white p-3 text-sm leading-6"
              />
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => saveTask("draft")}
                className="inline-flex items-center gap-2 rounded-lg border border-[#1F5A4A] px-3 py-2 text-xs font-bold text-[#1F5A4A] hover:bg-[#EFF5F0]"
              >
                <Save size={14} />
                Lưu bản nháp
              </button>
              <button
                type="button"
                onClick={() => saveTask("review")}
                className="inline-flex items-center gap-2 rounded-lg bg-[#1F5A4A] px-3 py-2 text-xs font-bold text-white hover:bg-[#174637]"
              >
                <CheckCircle2 size={14} />
                Gửi duyệt
              </button>
              <button
                type="button"
                onClick={copyDraft}
                className="inline-flex items-center gap-2 rounded-lg border border-[#C9D6CB] px-3 py-2 text-xs font-bold text-[#315B4B] hover:bg-[#F1F6F1]"
              >
                <Copy size={14} />
                Sao chép
              </button>
            </div>
          </div>
          <div className="rounded-xl border border-[#E1E8E0] bg-[#F8FAF7] p-4">
            <p className="text-xs font-bold uppercase tracking-[.13em] text-[#2C6A57]">
              Chọn kênh phát hành
            </p>
            <div className="mt-3 space-y-2">
              {PUBLISHING_CHANNELS.map(channel => {
                const Icon = channel.icon;
                return (
                  <label
                    key={channel.id}
                    className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 transition ${channels[channel.id] ? "border-[#2C6A57] bg-white" : "border-transparent bg-[#EEF3EE]"}`}
                  >
                    <input
                      type="checkbox"
                      checked={channels[channel.id]}
                      onChange={event =>
                        setChannels(current => ({
                          ...current,
                          [channel.id]: event.target.checked,
                        }))
                      }
                      className="h-4 w-4 accent-[#1F5A4A]"
                    />
                    <Icon size={18} style={{ color: channel.tone }} />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold text-[#18352D]">
                        {channel.label}
                      </span>
                      <span className="block text-xs text-[#70847A]">
                        {channel.description}
                      </span>
                      {(channel.id === "facebook" || channel.id === "zalo") && channels[channel.id] && (
                        <div
                          className="mt-2 rounded-lg border border-[#D9DED7] bg-[#F8FAF7] p-2"
                          role="group"
                          aria-label={`Chọn loại tài khoản ${channel.label}`}
                          onClick={event => event.stopPropagation()}
                        >
                          <span className="block text-[10px] font-bold uppercase tracking-[.08em] text-[#70847A]">
                            Tài khoản đăng
                          </span>
                          <div className="mt-1.5 grid grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                setAccountTypes(current => ({
                                  ...current,
                                  [channel.id]: "page_oa",
                                }))
                              }
                              className={`rounded-md px-2 py-1.5 text-[11px] font-bold ${accountTypes[channel.id] === "page_oa" ? "bg-[#1F5A4A] text-white" : "bg-white text-[#52685D]"}`}
                            >
                              {channel.id === "facebook" ? "Facebook Page" : "Zalo OA"}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setAccountTypes(current => ({
                                  ...current,
                                  [channel.id]: "personal",
                                }))
                              }
                              className={`rounded-md px-2 py-1.5 text-[11px] font-bold ${accountTypes[channel.id] === "personal" ? "bg-[#DDAF43] text-[#18352D]" : "bg-white text-[#52685D]"}`}
                            >
                              {channel.id === "facebook" ? "Cá nhân" : "Zalo cá nhân"}
                            </button>
                          </div>
                        </div>
                      )}
                    </span>
                  </label>
                );
              })}
            </div>
            <p className="mt-3 text-xs leading-5 text-[#70847A]">
              Facebook Page, Zalo OA, Facebook cá nhân và Zalo cá nhân được chọn riêng. Cá nhân sẽ mở để bạn tự đăng; Page/OA chỉ đăng trực tiếp sau khi kết nối API chính thức.
            </p>
          </div>
        </div>
      </DetailCard>
      <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <DetailCard title="Bản xem trước nội dung">
          <div className="rounded-xl border border-[#E4EAE5] bg-white p-4">
            <p className="text-lg font-bold text-[#18352D]">
              {title || "Chưa có tiêu đề"}
            </p>
            <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-[#52685D]">
              {description || "Chưa có nội dung"}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {selectedChannels.map(channel => (
                <span
                  key={channel.id}
                  className="rounded-full bg-[#EFF5F0] px-3 py-1 text-xs font-semibold text-[#315B4B]"
                >
                  {channel.label}
                </span>
              ))}
            </div>
          </div>
        </DetailCard>
        <DetailCard title="Trạng thái phát hành">
          <div className="space-y-3">
            {selectedChannels.map(channel => (
              <div
                key={channel.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-[#E4EAE5] p-3"
              >
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-semibold">{channel.label}</span>
                  <span className="mt-1 block text-[11px] text-[#70847A]">{accountLabel(channel.id)}</span>
                </span>
                <span className={`rounded-full px-2 py-1 text-[10px] font-bold ${accountTypes[channel.id as "facebook" | "zalo"] === "personal" ? "bg-[#FFF4D7] text-[#6F5617]" : "bg-slate-100 text-slate-700"}`}>
                  {accountTypes[channel.id as "facebook" | "zalo"] === "personal" ? "Thủ công" : "Chưa kết nối"}
                </span>
              </div>
            ))}
            {!selectedChannels.length && (
              <p className="text-sm text-[#70847A]">Chưa chọn kênh nào.</p>
            )}
          </div>
          <div className="mt-4 rounded-lg bg-[#FFF8E7] p-3 text-xs leading-5 text-[#7A5B18]">
            Sau khi bạn duyệt, hệ thống sẽ giữ tác vụ trong hàng đợi để kết nối
            tài khoản và đăng theo từng kênh.
          </div>
        </DetailCard>
      </div>
      {aiResult && (
        <DetailCard title="Kết quả AI cần kiểm tra">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.12em] text-[#2C6A57]">
                Tóm tắt
              </p>
              <p className="mt-1 text-sm leading-6 text-[#52685D]">
                {aiResult.summary}
              </p>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.12em] text-[#2C6A57]">
                Điểm mạnh
              </p>
              <p className="mt-1 text-sm leading-6 text-[#52685D]">
                {aiResult.strengths.length
                  ? aiResult.strengths.join(" · ")
                  : "Chưa nhận diện được"}
              </p>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.12em] text-[#B7791F]">
                Cần bổ sung
              </p>
              <p className="mt-1 text-sm leading-6 text-[#52685D]">
                {aiResult.missingInformation.length
                  ? aiResult.missingInformation.join(" · ")
                  : "Không có đề xuất"}
              </p>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.12em] text-[#B94A48]">
                Cảnh báo
              </p>
              <p className="mt-1 text-sm leading-6 text-[#52685D]">
                {aiResult.warnings.length
                  ? aiResult.warnings.join(" · ")
                  : "Không có cảnh báo"}
              </p>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {aiResult.hashtags.map(tag => (
              <span
                key={tag}
                className="rounded-full bg-[#EFF5F0] px-2.5 py-1 text-xs font-semibold text-[#315B4B]"
              >
                {tag}
              </span>
            ))}
          </div>
        </DetailCard>
      )}
      <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
        <DetailCard title="Kết nối tài khoản phát hành">
          <div className="space-y-2">
            {selectedChannels.map(channel => {
              const Icon = channel.icon;
              return (
                <div
                  key={channel.id}
                  className="flex items-center gap-3 rounded-lg border border-[#E4EAE5] p-3"
                >
                  <Icon size={17} style={{ color: channel.tone }} />
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-semibold text-[#18352D]">
                      {channel.label}
                    </span>
                    <span className="block text-xs text-[#70847A]">
                      Chưa kết nối tài khoản
                    </span>
                  </span>
                  {channel.id === "facebook" || channel.id === "zalo" ? (
                    accountTypes[channel.id] === "personal" ? (
                      <button
                        type="button"
                        onClick={() => openManualPost(channel.id as "facebook" | "zalo")}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#1F5A4A] px-2.5 py-1.5 text-xs font-bold text-white hover:bg-[#174637]"
                      >
                        <ExternalLink size={13} />
                        Mở để đăng
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => requestConnection(channel.label)}
                        className="inline-flex items-center gap-1 rounded-lg border border-[#C9D6CB] px-2.5 py-1.5 text-xs font-bold text-[#315B4B] hover:bg-[#EFF5F0]"
                      >
                        <ExternalLink size={13} />
                        Kết nối Page/OA
                      </button>
                    )
                  ) : (
                    <button
                      type="button"
                      onClick={() => requestConnection(channel.label)}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#C9D6CB] px-2.5 py-1.5 text-xs font-bold text-[#315B4B] hover:bg-[#EFF5F0]"
                    >
                      <ExternalLink size={13} />
                      Kết nối
                    </button>
                  )}
                </div>
              );
            })}
            {!selectedChannels.length && (
              <p className="text-sm text-[#70847A]">
                Chọn kênh ở phía trên để quản lý kết nối.
              </p>
            )}
          </div>
          <p className="mt-3 rounded-lg bg-[#F5F8F4] p-3 text-xs leading-5 text-[#60766D]">
            <strong>Phương án C:</strong> Page/OA sẽ đi theo luồng kết nối OAuth/API rồi <strong>Đăng ngay</strong> khi tích hợp được bật. Tài khoản cá nhân không tự động đăng nhập hay đăng thay bạn; hệ thống chỉ mở nền tảng, sao chép nội dung và ghi nhận thao tác để bạn kiểm tra rồi bấm đăng.
          </p>
        </DetailCard>
        <DetailCard title="Nhật ký tác vụ">
          <div className="space-y-2">
            {activityLog.map(entry => (
              <div
                key={`${entry.at}-${entry.label}`}
                className="flex items-start gap-3 rounded-lg bg-[#F8FAF7] p-3"
              >
                <CheckCircle2
                  size={15}
                  className="mt-0.5 shrink-0 text-[#2C9B67]"
                />
                <div>
                  <p className="text-sm font-semibold text-[#18352D]">
                    {entry.label}
                  </p>
                  <p className="mt-1 text-xs text-[#70847A]">
                    {new Date(entry.at).toLocaleString("vi-VN")}
                  </p>
                </div>
              </div>
            ))}
            {!activityLog.length && (
              <p className="text-sm text-[#70847A]">
                Chưa có hoạt động. Lưu bản nháp hoặc gửi duyệt để tạo nhật ký.
              </p>
            )}
          </div>
        </DetailCard>
      </div>
    </div>
  );
}

function propertyMatchesDossierType(property: any, selectedType: string) {
  if (!selectedType) return true;
  const text =
    `${property.propertyType || ""} ${property.title || ""} ${property.description || ""}`.toLowerCase();
  if (selectedType === "agricultural_land")
    return /nông nghiệp|đất lúa|cây lâu năm|cây hàng năm|nuôi trồng/.test(text);
  if (selectedType === "resort" || selectedType === "villa_resort")
    return /resort|nghỉ dưỡng|villa|vilaa/.test(text);
  if (selectedType === "land")
    return (
      property.propertyType === "land" &&
      !/nông nghiệp|lúa|cây lâu năm|cây hàng năm/.test(text)
    );
  return property.propertyType === selectedType;
}

export const DOSSIER_WORD_MIME_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
export const DOSSIER_WORD_FILE_EXTENSION = ".docx";

async function openDossierAsWordDocx(dossier: any) {
  const title = dossier.property?.title || `Hồ sơ BĐS #${dossier.dossier.id}`;
  const rows = (dossier.steps || []).map((step: any, index: number) => new TableRow({
    children: [
      new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: `Bước ${index + 1}`, bold: true }), new TextRun({ text: `\n${PROPERTY_DOSSIER_STEP_NAMES[index] || "Nghiệp vụ"}` })] })] }),
      new TableCell({ children: [new Paragraph(PROPERTY_DOSSIER_STATUS_META[step.status as StepStatus]?.label || "Chưa thực hiện")] }),
      new TableCell({ children: [new Paragraph(String(step.details || "—"))] }),
      new TableCell({ children: [new Paragraph(String(step.notes || "—"))] }),
    ],
  }));
  const doc = new Document({ sections: [{
    properties: { page: { margin: { top: 720, right: 720, bottom: 720, left: 720 } } },
    children: [
      new Paragraph({ text: title, heading: HeadingLevel.HEADING_1, alignment: AlignmentType.CENTER }),
      new Paragraph({ children: [new TextRun({ text: "Địa chỉ: ", bold: true }), new TextRun(String(dossier.property?.location || "—"))] }),
      new Paragraph({ children: [new TextRun({ text: "Hồ sơ: ", bold: true }), new TextRun(`#${dossier.dossier.id} · cập nhật ${formatDate(dossier.dossier.updatedAt)}`)] }),
      new Paragraph({ text: "Bảng thông số 12 bước nghiệp vụ", heading: HeadingLevel.HEADING_2 }),
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        rows: [
          new TableRow({ children: ["Bước", "Trạng thái", "Nội dung nghiệp vụ", "Ghi chú nội bộ"].map(text => new TableCell({ children: [new Paragraph({ children: [new TextRun({ text, bold: true })] })] })) }),
          ...rows,
        ],
        borders: { top: { style: BorderStyle.SINGLE, size: 4, color: "AFC5B6" }, bottom: { style: BorderStyle.SINGLE, size: 4, color: "AFC5B6" }, left: { style: BorderStyle.SINGLE, size: 4, color: "AFC5B6" }, right: { style: BorderStyle.SINGLE, size: 4, color: "AFC5B6" }, insideHorizontal: { style: BorderStyle.SINGLE, size: 4, color: "AFC5B6" }, insideVertical: { style: BorderStyle.SINGLE, size: 4, color: "AFC5B6" } },
      }),
    ],
  }] });
  const generated = await Packer.toBlob(doc);
  const blob = new Blob([generated], { type: DOSSIER_WORD_MIME_TYPE });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${title.replace(/[^a-zA-Z0-9À-ỹ -]/g, "-")}-12-buoc${DOSSIER_WORD_FILE_EXTENSION}`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function openDossierAsWord(dossier: any) {
  const title = dossier.property?.title || `Hồ sơ BĐS #${dossier.dossier.id}`;
  const rows = (dossier.steps || [])
    .map(
      (step: any, index: number) =>
        `<tr><td><strong>Bước ${index + 1}</strong><br>${PROPERTY_DOSSIER_STEP_NAMES[index]}</td><td>${PROPERTY_DOSSIER_STATUS_META[step.status as StepStatus]?.label || "Chưa thực hiện"}</td><td>${step.details || ""}</td><td>${step.notes || ""}</td></tr>`
    )
    .join("");
  const html = `<html><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;color:#18352D}h1{color:#1F5A4A}table{border-collapse:collapse;width:100%}th,td{border:1px solid #AFC5B6;padding:8px;vertical-align:top}th{background:#E8F0E8}</style></head><body><h1>${title}</h1><p><strong>Địa chỉ:</strong> ${dossier.property?.location || "—"}</p><p><strong>Hồ sơ:</strong> #${dossier.dossier.id} · cập nhật ${formatDate(dossier.dossier.updatedAt)}</p><h2>Bảng thông số 12 bước nghiệp vụ</h2><table><thead><tr><th>Bước</th><th>Trạng thái</th><th>Nội dung nghiệp vụ</th><th>Ghi chú nội bộ</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  const blob = new Blob([html], { type: "application/msword" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${title.replace(/[^a-zA-Z0-9À-ỹ -]/g, "-")}-12-buoc.doc`;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function PublishingWorkspace({
  dossiers,
  selectedId,
  detail,
  onSelect,
}: {
  dossiers: any[];
  selectedId: number | null;
  detail: any;
  onSelect: (id: number) => void;
}) {
  const selected = detail || dossiers.find(row => row.dossier.id === selectedId);
  const channels = [
    { label: "Website", tone: "bg-[#E7F3EC] text-[#17634D]", description: "Nguồn hàng công khai trên website" },
    { label: "Facebook", tone: "bg-[#E8F0FF] text-[#2455A4]", description: "Bài đăng mạng xã hội" },
    { label: "Zalo", tone: "bg-[#E7F5F3] text-[#12635C]", description: "Gửi nội dung cho khách hàng" },
    { label: "Cổng môi giới", tone: "bg-[#FFF3D7] text-[#7A5412]", description: "Chia sẻ cho đội ngũ phụ trách" },
  ];

  return (
    <section className="mt-6 rounded-2xl border border-[#D9E0EA] bg-white p-4 shadow-sm sm:p-7">
      <div className="flex flex-col justify-between gap-4 border-b border-[#E3E8EF] pb-5 md:flex-row md:items-end">
        <div>
          <p className="text-xs font-bold uppercase tracking-[.16em] text-[#403A8C]">TRUNG TÂM ĐĂNG BÀI</p>
          <h2 className="mt-1 font-serif text-3xl text-[#18352D]">Đăng đa kênh</h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-[#60766D]">Chọn một hồ sơ, xem nội dung AI đã chuẩn hóa, rồi quản lý trạng thái đăng trên từng kênh tại một nơi.</p>
        </div>
        <span className="inline-flex items-center gap-2 rounded-full bg-[#F1F0FF] px-3 py-2 text-xs font-bold text-[#403A8C]"><Megaphone size={14} /> {dossiers.length} hồ sơ sẵn sàng</span>
      </div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {channels.map(channel => (
          <div key={channel.label} className={`rounded-xl border border-transparent p-4 ${channel.tone}`}>
            <p className="text-sm font-bold">{channel.label}</p>
            <p className="mt-1 text-xs leading-5 opacity-80">{channel.description}</p>
            <span className="mt-3 inline-flex items-center gap-1 text-[11px] font-bold"><span className="h-1.5 w-1.5 rounded-full bg-current" /> Chưa chọn hồ sơ</span>
          </div>
        ))}
      </div>
      <div className="mt-6 grid gap-5 lg:grid-cols-[minmax(220px,0.75fr)_minmax(0,1.25fr)]">
        <div className="rounded-xl border border-[#E5E9E4] bg-[#FAFBF8] p-3">
          <p className="px-2 pb-2 text-xs font-bold uppercase tracking-[.12em] text-[#60766D]">Chọn hồ sơ để đăng</p>
          <div className="space-y-2">
            {dossiers.length ? dossiers.map(row => (
              <button key={row.dossier.id} type="button" onClick={() => onSelect(row.dossier.id)} className={`w-full rounded-lg border p-3 text-left transition ${selectedId === row.dossier.id ? "border-[#403A8C] bg-[#F1F0FF]" : "border-[#E5E9E4] bg-white hover:border-[#B7B3E7]"}`}>
                <span className="block truncate text-sm font-bold text-[#18352D]">{row.property?.title || `Hồ sơ #${row.dossier.id}`}</span>
                <span className="mt-1 block truncate text-xs text-[#70847A]">{row.property?.location || "Chưa có địa chỉ"}</span>
              </button>
            )) : <p className="p-3 text-sm text-[#70847A]">Chưa có hồ sơ để đăng.</p>}
          </div>
        </div>
        {selected ? <PublishingTaskPanel dossier={selected} /> : (
          <div className="flex min-h-[280px] flex-col items-center justify-center rounded-xl border border-dashed border-[#C7C1E7] bg-[#FBFAFF] p-8 text-center">
            <Megaphone size={38} className="text-[#403A8C]" />
            <h3 className="mt-3 text-xl font-bold text-[#18352D]">Chọn một hồ sơ</h3>
            <p className="mt-2 max-w-md text-sm leading-6 text-[#60766D]">Nội dung Đăng đa kênh sẽ xuất hiện tại đây sau khi bạn chọn hồ sơ ở danh sách bên trái.</p>
          </div>
        )}
      </div>
    </section>
  );
}

export default function PropertyDossierAdmin() {
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [fontSize, setFontSize] = useState<DossierFontSize>(() => {
    if (typeof window === "undefined") return "large";
    const saved = window.localStorage.getItem(DOSSIER_FONT_SIZE_STORAGE_KEY);
    return saved === "standard" || saved === "large" || saved === "extra-large"
      ? saved
      : "large";
  });
  useEffect(() => {
    window.localStorage.setItem(DOSSIER_FONT_SIZE_STORAGE_KEY, fontSize);
  }, [fontSize]);
  const [showCreate, setShowCreate] = useState(false);
  const [workspaceSection, setWorkspaceSection] = useState<"dossiers" | "publishing">("dossiers");
  const openWorkspace = (section: "dossiers" | "publishing") => {
    setWorkspaceSection(section);
    window.requestAnimationFrame(() => {
      document.getElementById("dossier-workspace-content")?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    });
  };
  const [selectedPropertyType, setSelectedPropertyType] = useState<string>(
    PROPERTY_DOSSIER_TYPES[0].value
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<
    "all" | "active" | "completed" | "paused"
  >("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const dossiers = trpc.brokerage.dossiers.list.useQuery();
  const properties = trpc.properties.adminList.useQuery();
  const detail = trpc.brokerage.dossiers.get.useQuery(
    { id: selectedId ?? 1 },
    { enabled: selectedId !== null }
  );
  const utils = trpc.useUtils();
  const create = trpc.brokerage.dossiers.create.useMutation({
    onSuccess: created => {
      toast.success("Đã tạo hồ sơ quy trình BĐS");
      setShowCreate(false);
      setSelectedId(created.id);
      dossiers.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const deleteProperty = trpc.properties.delete.useMutation({
    onSuccess: () => {
      toast.success("Đã xóa BĐS");
      properties.refetch();
      dossiers.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const deleteDossier = trpc.brokerage.dossiers.delete.useMutation({
    onSuccess: (_result, variables) => {
      toast.success("Đã xóa hồ sơ/bài đăng");
      if (selectedId === variables.id) setSelectedId(null);
      dossiers.refetch();
    },
    onError: error => toast.error(error.message),
  });
  const filteredDossiers = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return (dossiers.data || []).filter((row: any) => {
      const searchable =
        `${row.property?.propertyCode || ""} ${row.property?.title || ""} ${row.property?.location || ""}`.toLowerCase();
      const matchesType =
        typeFilter === "all" ||
        propertyMatchesDossierType(row.property, typeFilter);
      return (
        (!query || searchable.includes(query)) &&
        matchesType &&
        (statusFilter === "all" || row.dossier.status === statusFilter)
      );
    });
  }, [dossiers.data, searchQuery, statusFilter, typeFilter]);
  const availableProperties = useMemo(() => {
    const rows = properties.data || [];
    const linked = new Set(
      (dossiers.data || []).map((row: any) => row.property?.id)
    );
    return rows.filter(
      (property: any) =>
        !linked.has(property.id) &&
        propertyMatchesDossierType(property, selectedPropertyType)
    );
  }, [properties.data, dossiers.data, selectedPropertyType]);
  const dossierSummary = useMemo(() => {
    const rows = dossiers.data || [];
    return {
      total: rows.length,
      active: rows.filter((row: any) => row.dossier.status === "active").length,
      completed: rows.filter((row: any) => row.dossier.status === "completed").length,
      inProgress: rows.filter((row: any) => row.dossier.currentStep > 0 && row.dossier.status !== "completed").length,
      sourceProperties: properties.data?.length || 0,
    };
  }, [dossiers.data, properties.data]);

  return (
    <DashboardLayout>
      <main
        className={`dossier-readable dossier-font-${fontSize} min-h-screen bg-[#F5F2EA] p-4 text-[#18352D] sm:p-8`}
      >
        <div className="mx-auto w-full max-w-none">
          <header className="dossier-hero-balanced w-full rounded-[2rem] bg-[#18352D] p-6 text-white shadow-xl sm:p-9">
            <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.2em] text-[#E6C478]">
                  Khu vực nội bộ môi giới
                </p>
                <h1 className="mt-3 font-serif text-4xl tracking-[-.04em] sm:text-5xl">
                  Hồ sơ điện tử BĐS
                </h1>
                <p className="mt-3 max-w-2xl text-sm leading-6 text-white/75">
                  Một nơi quản lý đầy đủ thông tin tài sản, pháp lý, tài liệu,
                  tiến độ 12 bước và lịch sử giao dịch cho từng bất động sản.
                </p>
              </div>
              <button
                onClick={() => setShowCreate(v => !v)}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#E6C478] px-5 py-3 text-sm font-bold text-[#18352D] transition hover:bg-[#F2D99E] active:scale-[.98]"
              >
                <Plus size={17} /> {showCreate ? "Đóng" : "Tạo hồ sơ mới"}
              </button>
            </div>
            <div className="mt-6 flex flex-wrap gap-2 text-xs text-white/80">
              <span className="rounded-full bg-white/10 px-3 py-2">
                12 bước nghiệp vụ
              </span>
              <span className="rounded-full bg-white/10 px-3 py-2">
                Chỉ admin xem
              </span>
              <span className="rounded-full bg-white/10 px-3 py-2">
                Có lưu tài liệu theo bước
              </span>
            </div>
            <fieldset className="mt-6 rounded-2xl border border-white/15 bg-white/10 p-3">
              <legend className="px-1 text-sm font-bold text-[#F2D99E]">
                Cỡ chữ hiển thị
              </legend>
              <div
                className="mt-2 flex flex-wrap gap-2"
                role="radiogroup"
                aria-label="Cỡ chữ Hồ sơ điện tử"
              >
                {DOSSIER_FONT_SIZES.map(size => (
                  <button
                    key={size.id}
                    type="button"
                    role="radio"
                    aria-checked={fontSize === size.id}
                    onClick={() => setFontSize(size.id)}
                    className={`rounded-xl px-3 py-2 text-sm font-bold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[#F2D99E] ${fontSize === size.id ? "bg-[#E6C478] text-[#18352D]" : "bg-white/10 text-white hover:bg-white/20"}`}
                  >
                    {size.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-sm text-white/75">
                Lựa chọn được lưu trên thiết bị này và giữ nguyên khi chuyển
                tab.
              </p>
            </fieldset>
          </header>

          <nav
            className="mt-5 grid gap-3 rounded-2xl border border-[#D9E7D9] bg-white p-3 shadow-sm sm:grid-cols-2"
            aria-label="Khu vực Hồ sơ điện tử AI"
          >
            <button
              type="button"
              onClick={() => openWorkspace("dossiers")}
              className={`group rounded-xl p-4 text-left transition ${workspaceSection === "dossiers" ? "bg-[#1F5A4A] text-white shadow-md" : "bg-[#F7FBF7] text-[#315B4B] hover:bg-[#EFF5F0]"}`}
            >
              <span className="flex items-start justify-between gap-3">
                <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl ${workspaceSection === "dossiers" ? "bg-white/15" : "bg-[#E6F4EC]"}`}><FolderKanban size={20} /></span>
                <span className={`text-xs font-bold ${workspaceSection === "dossiers" ? "text-[#F2D99E]" : "text-[#17634D]"}`}>MỞ QUẢN LÝ →</span>
              </span>
              <span className="mt-4 block text-lg font-black">Hồ sơ điện tử AI</span>
              <span className={`mt-1 block text-sm ${workspaceSection === "dossiers" ? "text-white/75" : "text-[#70847A]"}`}>Danh sách, tiến độ và tài liệu từng BĐS</span>
              <span className={`mt-4 flex flex-wrap gap-2 text-xs font-bold ${workspaceSection === "dossiers" ? "text-white/90" : "text-[#315B4B]"}`}>
                <span className="rounded-full bg-black/5 px-2.5 py-1">{dossierSummary.total} hồ sơ</span>
                <span className="rounded-full bg-black/5 px-2.5 py-1">{dossierSummary.active} đang xử lý</span>
                <span className="rounded-full bg-black/5 px-2.5 py-1">{availableProperties.length} BĐS chờ tạo</span>
              </span>
            </button>
            <button
              type="button"
              onClick={() => openWorkspace("publishing")}
              className={`group rounded-xl p-4 text-left transition ${workspaceSection === "publishing" ? "bg-[#403A8C] text-white shadow-md" : "bg-[#FBFAFF] text-[#403A8C] hover:bg-[#F1F0FF]"}`}
            >
              <span className="flex items-start justify-between gap-3">
                <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl ${workspaceSection === "publishing" ? "bg-white/15" : "bg-[#ECEBFF]"}`}><Megaphone size={20} /></span>
                <span className={`text-xs font-bold ${workspaceSection === "publishing" ? "text-[#F2D99E]" : "text-[#403A8C]"}`}>MỞ TRUNG TÂM →</span>
              </span>
              <span className="mt-4 block text-lg font-black">Đăng đa kênh</span>
              <span className={`mt-1 block text-sm ${workspaceSection === "publishing" ? "text-white/75" : "text-[#7771A5]"}`}>Quản lý nội dung đăng Website, Facebook, Zalo</span>
              <span className={`mt-4 flex flex-wrap gap-2 text-xs font-bold ${workspaceSection === "publishing" ? "text-white/90" : "text-[#403A8C]"}`}>
                <span className="rounded-full bg-black/5 px-2.5 py-1">{dossiers.data?.length || 0} hồ sơ sẵn sàng</span>
                <span className="rounded-full bg-black/5 px-2.5 py-1">4 kênh quản lý</span>
                <span className="rounded-full bg-black/5 px-2.5 py-1">Xem trạng thái đăng</span>
              </span>
            </button>
          </nav>

          {workspaceSection === "dossiers" && (
          <>
          <section id="dossier-workspace-content" className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-5" aria-label="Tổng quan Hồ sơ điện tử AI">
            {[
              { label: "Tổng hồ sơ", value: dossierSummary.total, icon: Home, tone: "bg-[#E6F4EC] text-[#17634D]" },
              { label: "Đang xử lý", value: dossierSummary.active, icon: Clock3, tone: "bg-[#FFF4D7] text-[#6F5617]" },
              { label: "Hoàn tất", value: dossierSummary.completed, icon: CheckCircle2, tone: "bg-[#E8F1FF] text-[#245A9A]" },
              { label: "BĐS có nguồn", value: dossierSummary.sourceProperties, icon: FolderKanban, tone: "bg-[#F1F0FF] text-[#403A8C]" },
              { label: "Cần xử lý", value: dossierSummary.inProgress, icon: ShieldAlert, tone: "bg-[#FCE9E7] text-[#A8473B]" },
            ].map(item => {
              const Icon = item.icon;
              return (
                <div key={item.label} className="rounded-2xl border border-[#E1E8E1] bg-white p-4 shadow-sm">
                  <div className="flex items-center justify-between gap-3">
                    <span className={`inline-flex h-10 w-10 items-center justify-center rounded-xl ${item.tone}`}><Icon size={19} /></span>
                    <span className="text-2xl font-black text-[#18352D]">{item.value}</span>
                  </div>
                  <p className="mt-3 text-xs font-bold uppercase tracking-[.12em] text-[#70847A]">{item.label}</p>
                </div>
              );
            })}
          </section>
          </>
          )}

          {workspaceSection === "dossiers" && (
          <>
          {showCreate && (
            <section className="mt-6 rounded-2xl bg-white p-5 shadow-sm sm:p-7">
              <h2 className="font-serif text-2xl">
                Tạo hồ sơ cho bất động sản
              </h2>
              <p className="mt-1 text-sm text-[#60766D]">
                Mỗi BĐS chỉ có một hồ sơ quy trình.
              </p>
              <div className="mt-5 grid gap-4 sm:grid-cols-[minmax(190px,0.7fr)_minmax(0,1.3fr)]">
                <select
                  aria-label="Loại bất động sản của hồ sơ"
                  value={selectedPropertyType}
                  onChange={event =>
                    setSelectedPropertyType(event.target.value)
                  }
                  className="min-h-12 rounded-xl border border-[#D9DED7] bg-[#FAFBF8] px-4 text-sm outline-none focus:ring-2 focus:ring-[#1F5A4A]"
                >
                  <option value="">Tất cả loại BĐS</option>
                  {PROPERTY_DOSSIER_TYPES.map(type => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
                <div
                  aria-label="Danh sách BĐS chưa có hồ sơ"
                  className="max-h-56 overflow-y-auto rounded-xl border border-[#D9DED7] bg-[#FAFBF8]"
                >
                  {availableProperties.length ? (
                    availableProperties.map((property: any) => (
                      <div
                        key={property.id}
                        className="flex items-center gap-2 border-b border-[#E5E9E4] p-2 last:border-b-0"
                      >
                        <button
                          type="button"
                          onClick={() =>
                            create.mutate({ propertyId: property.id })
                          }
                          disabled={
                            create.isPending || deleteProperty.isPending
                          }
                          className="min-w-0 flex-1 rounded-lg px-3 py-2 text-left text-sm font-semibold text-[#18352D] transition hover:bg-[#EFF5F0] disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          <span className="block truncate">
                            {property.title}
                          </span>
                          <span className="mt-1 block truncate text-xs font-normal text-[#60766D]">
                            {property.location}
                          </span>
                        </button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button
                              type="button"
                              aria-label={`Xóa BĐS ${property.title}`}
                              disabled={
                                deleteProperty.isPending &&
                                deleteProperty.variables?.id === property.id
                              }
                              className="inline-flex shrink-0 items-center gap-1 rounded-lg border border-red-200 px-2 py-2 text-xs font-bold text-red-700 transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                              <Trash2 size={14} />
                              Xóa
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Xóa BĐS này?</AlertDialogTitle>
                              <AlertDialogDescription>
                                BĐS “{property.title}” sẽ bị xóa khỏi nguồn
                                hàng. Thao tác này không thể hoàn tác.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Hủy</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() =>
                                  deleteProperty.mutate({ id: property.id })
                                }
                                className="bg-red-700 text-white hover:bg-red-800"
                              >
                                Xóa BĐS
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    ))
                  ) : (
                    <p className="p-5 text-sm text-[#60766D]">
                      Không còn BĐS phù hợp với loại đã chọn.
                    </p>
                  )}
                </div>
                {create.isPending && (
                  <div className="flex items-center gap-2 text-sm text-[#60766D]">
                    <Loader2 className="animate-spin" size={16} /> Đang tạo hồ
                    sơ...
                  </div>
                )}
              </div>
            </section>
          )}

          <div className="mt-8 grid gap-6 lg:grid-cols-[360px_1fr]">
            <section className="rounded-2xl bg-white p-4 shadow-sm sm:p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F5A4A]">
                    HỒ SƠ ĐIỆN TỬ · CRM MÔI GIỚI
                  </p>
                  <h2 className="mt-1 font-serif text-2xl">
                    Danh sách hồ sơ BĐS
                  </h2>
                </div>
                <span className="rounded-full bg-[#F5F2EA] px-3 py-1 text-xs font-bold">
                  {filteredDossiers.length}/{dossiers.data?.length || 0}
                </span>
              </div>
              <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr]">
                <label className="flex min-h-11 items-center gap-2 rounded-xl border border-[#D9DED7] bg-[#FAFBF8] px-3">
                  <Search size={16} className="shrink-0 text-[#60766D]" />
                  <input
                    aria-label="Tìm hồ sơ"
                    value={searchQuery}
                    onChange={event => setSearchQuery(event.target.value)}
                    placeholder="Tìm mã, tên, địa chỉ..."
                    className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-[#8A9991]"
                  />
                </label>
                <label className="flex min-h-11 items-center gap-2 rounded-xl border border-[#D9DED7] bg-[#FAFBF8] px-3">
                  <SlidersHorizontal size={16} className="text-[#60766D]" />
                  <select
                    aria-label="Lọc trạng thái hồ sơ"
                    value={statusFilter}
                    onChange={event =>
                      setStatusFilter(event.target.value as typeof statusFilter)
                    }
                    className="min-w-0 flex-1 bg-transparent text-sm font-semibold outline-none"
                  >
                    <option value="all">Tất cả trạng thái</option>
                    <option value="active">Đang xử lý</option>
                    <option value="completed">Hoàn tất</option>
                    <option value="paused">Tạm dừng</option>
                  </select>
                </label>
                <label className="flex min-h-11 items-center gap-2 rounded-xl border border-[#D9DED7] bg-[#FAFBF8] px-3">
                  <select
                    aria-label="Lọc loại BĐS"
                    value={typeFilter}
                    onChange={event => setTypeFilter(event.target.value)}
                    className="min-w-0 flex-1 bg-transparent text-sm font-semibold outline-none"
                  >
                    <option value="all">Tất cả loại BĐS</option>
                    {PROPERTY_DOSSIER_TYPES.map(type => (
                      <option key={type.value} value={type.value}>
                        {type.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="mt-4 overflow-hidden rounded-xl border border-[#E5E9E4]">
                <div className="hidden grid-cols-[90px_1fr_100px] gap-3 bg-[#EFF5F0] px-4 py-3 text-[10px] font-bold uppercase tracking-[.12em] text-[#1F5A4A] sm:grid">
                  <span>Mã</span>
                  <span>BĐS</span>
                  <span>Trạng thái</span>
                </div>
                <div className="divide-y divide-[#E5E9E4]">
                  {dossiers.isLoading ? (
                    <p className="p-5 text-sm text-[#60766D]">
                      Đang tải hồ sơ...
                    </p>
                  ) : !filteredDossiers.length ? (
                    <div className="space-y-4 p-5 text-sm text-[#60766D]">
                      <div className="rounded-xl border border-dashed border-[#BFD5C5] bg-[#F7FBF7] p-4 text-center">
                        <p className="font-semibold text-[#18352D]">
                          {dossiers.data?.length ? "Không tìm thấy hồ sơ phù hợp." : "Chưa có hồ sơ điện tử cho các BĐS hiện có."}
                        </p>
                        <p className="mt-1 text-xs leading-5">Chọn một BĐS bên dưới để tạo hồ sơ quy trình 12 bước và đưa hồ sơ vào danh sách quản lý.</p>
                      </div>
                      {dossiers.data?.length ? null : properties.isLoading ? (
                        <p className="text-center text-xs">Đang tải các BĐS đã lưu...</p>
                      ) : availableProperties.length ? (
                        <div className="grid gap-2 sm:grid-cols-2">
                          {availableProperties.slice(0, 6).map((property: any) => (
                            <button
                              key={property.id}
                              type="button"
                              onClick={() => create.mutate({ propertyId: property.id })}
                              disabled={create.isPending}
                              className="rounded-xl border border-[#D9E7D9] bg-white p-3 text-left transition hover:border-[#1F5A4A] hover:bg-[#F7FBF7] disabled:cursor-not-allowed disabled:opacity-60"
                            >
                              <span className="block truncate font-semibold text-[#18352D]">{property.title || `BĐS #${property.id}`}</span>
                              <span className="mt-1 block truncate text-xs text-[#70847A]">{property.location || "Chưa có địa chỉ"}</span>
                              <span className="mt-2 inline-flex rounded-full bg-[#E4F4EA] px-2 py-1 text-[10px] font-bold text-[#17634D]">+ Tạo hồ sơ AI</span>
                            </button>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center">
                          <p className="text-xs">Chưa có BĐS nguồn hàng để tạo hồ sơ.</p>
                          <button type="button" onClick={() => setShowCreate(true)} className="mt-3 rounded-lg bg-[#1F5A4A] px-4 py-2 text-xs font-bold text-white hover:bg-[#17483B]">Tạo hồ sơ mới</button>
                        </div>
                      )}
                    </div>
                  ) : (
                    filteredDossiers.map((row: any) => (
                      <div
                        key={row.dossier.id}
                        role="button"
                        tabIndex={0}
                        onClick={() => setSelectedId(row.dossier.id)}
                        onKeyDown={event => {
                          if (event.key === "Enter" || event.key === " ") {
                            event.preventDefault();
                            setSelectedId(row.dossier.id);
                          }
                        }}
                        className={`dossier-list-row grid w-full cursor-pointer gap-2 p-2.5 text-left transition focus:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#1F5A4A] sm:gap-3 sm:p-4 sm:grid-cols-[90px_1fr_100px] ${selectedId === row.dossier.id ? "bg-[#EFF5F0]" : "hover:bg-[#FAFBF8]"}`}
                      >
                        <div className="text-xs font-bold text-[#1F5A4A]">
                          {row.property?.propertyCode ||
                            `BDS-${String(row.property?.id || row.dossier.propertyId).padStart(3, "0")}`}
                          <p className="mt-1 text-[11px] font-normal text-[#60766D] sm:hidden">
                            {row.property?.location || "Chưa có địa chỉ"}
                          </p>
                        </div>
                        <div className="min-w-0">
                          <p className="truncate font-semibold leading-5">
                            {row.property?.title ||
                              `BĐS #${row.dossier.propertyId}`}
                          </p>
                          <p className="mt-1 hidden truncate text-xs text-[#60766D] sm:block">
                            {row.property?.location || "Chưa có địa chỉ"}
                          </p>
                          <div className="mt-2 flex flex-wrap items-center gap-2 sm:hidden">
                            <span className="rounded-full bg-[#E6C478]/35 px-2 py-1 text-[10px] font-bold">
                              Bước {row.dossier.currentStep}/12
                            </span>
                            <span className="text-[11px] text-[#60766D]">
                              Cập nhật {formatDate(row.dossier.updatedAt)}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-2 sm:block">
                          <span
                            className={`inline-flex rounded-full px-2 py-1 text-[10px] font-bold uppercase ${row.dossier.status === "completed" ? "bg-[#E4F4EA] text-[#17634D]" : row.dossier.status === "paused" ? "bg-[#EEF8F2] text-[#60766D]" : "bg-[#FFF4D7] text-[#6F5617]"}`}
                          >
                            {row.dossier.status === "completed"
                              ? "Hoàn tất"
                              : row.dossier.status === "paused"
                                ? "Tạm dừng"
                                : "Đang xử lý"}
                          </span>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <button
                                type="button"
                                disabled={
                                  deleteDossier.isPending &&
                                  deleteDossier.variables?.id === row.dossier.id
                                }
                                onClick={event => event.stopPropagation()}
                                aria-label={`Xóa bài đăng ${row.property?.title || `BĐS #${row.dossier.propertyId}`}`}
                                className="ml-1 inline-flex items-center gap-1 rounded-lg border border-red-200 px-2 py-1 text-xs font-bold text-red-700 transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                              >
                                <Trash2 size={13} />
                                Xóa
                              </button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>
                                  Xóa bài đăng này?
                                </AlertDialogTitle>
                                <AlertDialogDescription>
                                  Bài đăng “
                                  {row.property?.title ||
                                    `BĐS #${row.dossier.propertyId}`}
                                  ” và hồ sơ quy trình 12 bước, ghi chú cùng tài
                                  liệu liên quan sẽ bị xóa. Thao tác này không
                                  thể hoàn tác.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Hủy</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() =>
                                    deleteDossier.mutate({ id: row.dossier.id })
                                  }
                                  className="bg-red-700 text-white hover:bg-red-800"
                                >
                                  Xóa bài đăng
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </section>
            <section>
              {selectedId === null ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center rounded-2xl border border-dashed border-[#C8D3C9] bg-white/60 p-8 text-center">
                  <FolderKanban className="mb-4 text-[#1F5A4A]" size={42} />
                  <h2 className="font-serif text-3xl">
                    Chọn một hồ sơ để bắt đầu
                  </h2>
                  <p className="mt-2 max-w-md text-sm leading-6 text-[#60766D]">
                    Mỗi bước có thể cập nhật trạng thái, ghi chú và đính kèm tài
                    liệu kiểm tra riêng.
                  </p>
                </div>
              ) : detail.isLoading ? (
                <div className="rounded-2xl bg-white p-12 text-center text-[#60766D]">
                  Đang tải chi tiết hồ sơ...
                </div>
              ) : detail.data ? (
                <DossierDetail
                  dossier={detail.data}
                  onRefresh={() => {
                    detail.refetch();
                    dossiers.refetch();
                    utils.brokerage.dossiers.list.invalidate();
                  }}
                />
              ) : (
                <div className="rounded-2xl bg-white p-12 text-center text-red-700">
                  Không tìm thấy hồ sơ.
                </div>
              )}
            </section>
          </div>
          </>
          )}

          {workspaceSection === "publishing" && (
            <section id="dossier-workspace-content" className="scroll-mt-6">
            <PublishingWorkspace
              dossiers={dossiers.data || []}
              selectedId={selectedId}
              detail={detail.data}
              onSelect={setSelectedId}
            />
            </section>
          )}
        </div>
      </main>
    </DashboardLayout>
  );
}

function DossierDetail({
  dossier,
  onRefresh,
}: {
  dossier: any;
  onRefresh: () => void;
}) {
  const [activeStep, setActiveStep] = useState(0);
  const [activeModule, setActiveModule] = useState("overview");
  const [status, setStatus] = useState<StepStatus>(
    dossier.steps?.[0]?.status || "not_started"
  );
  const [details, setDetails] = useState(dossier.steps?.[0]?.details || "");
  const [notes, setNotes] = useState(dossier.steps?.[0]?.notes || "");
  const [fieldValues, setFieldValues] = useState<Record<string, string>>({});
  const updateStep = trpc.brokerage.dossiers.updateStep.useMutation({
    onSuccess: () => {
      toast.success("Đã cập nhật bước");
      onRefresh();
    },
    onError: e => toast.error(e.message),
  });
  const upload = trpc.brokerage.dossiers.uploadDocument.useMutation({
    onSuccess: () => {
      toast.success("Đã tải tài liệu lên");
      onRefresh();
    },
    onError: e => toast.error(e.message),
  });
  const remove = trpc.brokerage.dossiers.deleteDocument.useMutation({
    onSuccess: () => {
      toast.success("Đã xóa tài liệu");
      onRefresh();
    },
    onError: e => toast.error(e.message),
  });
  const step = dossier.steps?.[activeStep];
  const completedSteps = (dossier.steps || []).filter(
    (item: any) => item.status === "completed"
  ).length;
  const progress = Math.round((completedSteps / 12) * 100);
  const documents = dossier.documents || [];
  const imageDocuments = documents.filter((doc: any) =>
    String(doc.mimeType || "").startsWith("image/")
  );
  const statusText =
    dossier.dossier.status === "completed"
      ? "Hoàn tất"
      : dossier.dossier.status === "paused"
        ? "Tạm dừng"
        : "Đang bán";
  const moduleTabs = [
    {
      id: "overview",
      label: "Tổng quan",
      icon: FolderKanban,
      tone: "bg-[#E7F3EC] text-[#175B3F] border-[#9BC8AB]",
    },
    {
      id: "media",
      label: "Hình ảnh & Video",
      icon: FileUp,
      step: 2,
      tone: "bg-[#E8F2FA] text-[#15547A] border-[#9EC8E6]",
    },
    {
      id: "legal",
      label: "Hồ sơ pháp lý",
      icon: Scale,
      step: 4,
      tone: "bg-[#FFF3D7] text-[#7A5412] border-[#E5C36A]",
    },
    {
      id: "planning",
      label: "Quy hoạch",
      icon: MapPin,
      step: 3,
      tone: "bg-[#E7F5F3] text-[#12635C] border-[#95D0C9]",
    },
    {
      id: "survey",
      label: "Phiếu khảo sát",
      icon: ClipboardCheck,
      step: 2,
      tone: "bg-[#F1ECFB] text-[#563A8A] border-[#C7B6E9]",
    },
    {
      id: "valuation",
      label: "Định giá",
      icon: Handshake,
      step: 5,
      tone: "bg-[#FFF0E5] text-[#8A471F] border-[#E5B58D]",
    },
    {
      id: "owner",
      label: "Chủ nhà",
      icon: UserRound,
      step: 0,
      tone: "bg-[#FCECEF] text-[#8A3046] border-[#E4A8B6]",
    },
    {
      id: "buyer",
      label: "Khách hàng",
      icon: Users,
      step: 8,
      tone: "bg-[#E9F4F7] text-[#165C70] border-[#9BCBD5]",
    },
    {
      id: "history",
      label: "Lịch sử",
      icon: History,
      tone: "bg-[#EEF1F4] text-[#455565] border-[#BEC8D1]",
    },
    {
      id: "publishing",
      label: "Đăng đa kênh",
      icon: Megaphone,
      tone: "bg-[#ECEBFF] text-[#403A8C] border-[#B7B3E7]",
    },
  ] as const;

  useEffect(() => {
    const next = dossier.steps?.[activeStep];
    setStatus(next?.status || "not_started");
    setNotes(next?.notes || "");
    try {
      const parsed = next?.details ? JSON.parse(next.details) : {};
      setFieldValues(
        parsed?.fields && typeof parsed.fields === "object" ? parsed.fields : {}
      );
      setDetails(
        parsed?.summary ||
          (next?.details && !parsed?.fields ? next.details : "")
      );
    } catch {
      setFieldValues({});
      setDetails(next?.details || "");
    }
  }, [activeStep, dossier.steps]);

  const selectModule = (module: (typeof moduleTabs)[number]) => {
    setActiveModule(module.id);
    if ("step" in module && typeof module.step === "number")
      setActiveStep(module.step);
    window.requestAnimationFrame(() =>
      document
        .getElementById("dossier-module-content")
        ?.scrollIntoView({ behavior: "smooth", block: "start" })
    );
  };

  const saveStep = () => {
    if (!step) return;
    const serializedDetails = JSON.stringify({
      fields: fieldValues,
      summary: details,
    });
    updateStep.mutate({
      id: step.id,
      status,
      details:
        serializedDetails === '{"fields":{},"summary":""}'
          ? null
          : serializedDetails,
      notes: notes || null,
    });
  };

  const clearStep = () => {
    if (!step) return;
    setFieldValues({});
    setDetails("");
    setNotes("");
    setStatus("not_started");
    updateStep.mutate({
      id: step.id,
      status: "not_started",
      details: null,
      notes: null,
    });
  };

  const handleFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (!files.length || !step) return;
    for (const file of files) {
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} vượt quá 10MB.`);
        continue;
      }
      const data = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () =>
          resolve(String(reader.result).split(",")[1] || "");
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      upload.mutate({
        dossierId: dossier.dossier.id,
        stepNumber: step.stepNumber,
        fileName: file.name,
        mimeType: file.type || "application/octet-stream",
        data,
      });
    }
    event.target.value = "";
  };

  const openLocation = () => {
    const query = encodeURIComponent(
      dossier.property?.location || dossier.property?.title || "Đà Nẵng"
    );
    window.open(
      `https://www.google.com/maps/search/?api=1&query=${query}`,
      "_blank",
      "noopener,noreferrer"
    );
  };

  const stepData = (index: number) => {
    const item = dossier.steps?.[index];
    let fields: Record<string, string> = {};
    try {
      fields = item?.details ? JSON.parse(item.details)?.fields || {} : {};
    } catch {
      fields = {};
    }
    return { item, fields };
  };
  const legal = stepData(4),
    survey = stepData(2),
    valuation = stepData(5),
    owner = stepData(0),
    buyer = stepData(8);
  const syncedRows = getDossierSyncRows(
    dossier.steps || [],
    (dossier.property || {}) as Record<string, unknown>
  );

  const ModulePanel = () => {
    if (activeModule === "overview")
      return (
        <>
          <section className="mb-5 rounded-2xl border border-[#D9E7D9] bg-[#F1F8F1] p-4 sm:p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-xs font-bold uppercase tracking-[.16em] text-[#2C6A57]">
                  ĐỒNG BỘ TỪ QUY TRÌNH 12 BƯỚC
                </p>
                <h3 className="mt-1 text-xl font-bold text-[#18352D]">
                  Tổng hợp dữ liệu tự động
                </h3>
                <p className="mt-1 text-xs leading-5 text-[#60766D]">
                  Các thông tin đã lưu trong từng bước được gom lại theo hồ sơ
                  BĐS này.
                </p>
              </div>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#DDF1E3] px-3 py-1 text-[11px] font-bold text-[#22724E]">
                <BadgeCheck size={13} />
                Đã đồng bộ
              </span>
            </div>
            <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
              {syncedRows.map(([label, value]) => (
                <div
                  key={label}
                  className="rounded-xl border border-[#DCE9DE] bg-white p-3"
                >
                  <p className="text-[10px] font-bold uppercase tracking-[.08em] text-[#70847A]">
                    {label}
                  </p>
                  <p className="mt-1 line-clamp-2 text-sm font-semibold text-[#18352D]">
                    {value ? String(value) : "Chưa cập nhật"}
                  </p>
                </div>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#D8E7D9] pt-3 text-xs text-[#60766D]">
              <span>{completedSteps}/12 bước đã có trạng thái hoàn thành</span>
              <button
                type="button"
                onClick={() => {
                  setActiveStep(0);
                  setActiveModule("workflow");
                }}
                className="font-bold text-[#214EDE] underline"
              >
                Mở và cập nhật dữ liệu 12 bước
              </button>
            </div>
          </section>
          <div className="grid gap-4 xl:grid-cols-[1.15fr_1fr_280px]">
            <div className="space-y-4">
              <DetailCard title="Thông tin mô tả">
                <p className="text-sm leading-6 text-[#52685D]">
                  {dossier.property?.description ||
                    "Chưa có mô tả. Mở bước Đăng bán để bổ sung nội dung giới thiệu BĐS."}
                </p>
                <button
                  type="button"
                  onClick={() => selectModule(moduleTabs[1])}
                  className="mt-3 text-sm font-bold text-[#214EDE] underline"
                >
                  Xem thêm
                </button>
              </DetailCard>
              <DetailCard title="Thông tin chi tiết">
                <DetailRow
                  label="Mã BĐS"
                  value={
                    dossier.property?.propertyCode ||
                    `BDS-${dossier.dossier.propertyId}`
                  }
                />
                <DetailRow
                  label="Ngày tiếp nhận"
                  value={formatDate(dossier.dossier.createdAt)}
                />
                <DetailRow
                  label="Nguồn hàng"
                  value={dossier.property?.brokerName || "Chưa cập nhật"}
                />
                <DetailRow
                  label="Phòng ngủ / WC"
                  value={`${dossier.property?.bedrooms || "—"} / ${dossier.property?.bathrooms || "—"}`}
                />
                <DetailRow label="Tình trạng nhà" value={statusText} />
                <button
                  type="button"
                  onClick={() => selectModule(moduleTabs[0])}
                  className="mt-3 text-sm font-bold text-[#214EDE] underline"
                >
                  Xem chi tiết
                </button>
              </DetailCard>
            </div>
            <div className="space-y-4">
              <DetailCard title="Vị trí trên bản đồ">
                <div className="flex min-h-40 items-center justify-center rounded-xl bg-[#EAF0EB] text-center text-sm text-[#70847A]">
                  <MapPin size={28} className="mr-2 text-[#D45C50]" />
                  {dossier.property?.location || "Chưa cập nhật vị trí"}
                </div>
                <button
                  type="button"
                  onClick={openLocation}
                  className="mt-3 text-sm font-bold text-[#214EDE]"
                >
                  Xem trên Google Maps
                </button>
              </DetailCard>
              <DetailCard title="Tài liệu nhanh">
                <div className="space-y-2">
                  {documents.slice(0, 4).map((doc: any) => (
                    <a
                      key={doc.id}
                      href={doc.url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center justify-between gap-2 rounded-lg border border-[#E4EAE5] bg-[#FBFCFA] p-3 text-xs font-semibold text-[#315B4B] hover:bg-[#EFF5F0]"
                    >
                      <span className="min-w-0 truncate">{doc.fileName}</span>
                      <Download size={14} className="shrink-0" />
                    </a>
                  ))}
                  {!documents.length && (
                    <p className="text-sm text-[#70847A]">
                      Chưa có tài liệu trong hồ sơ.
                    </p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => selectModule(moduleTabs[2])}
                  className="mt-3 text-sm font-bold text-[#214EDE]"
                >
                  Xem tất cả tài liệu
                </button>
              </DetailCard>
            </div>
            <div className="space-y-4">
              <DetailCard title="Lịch sử hồ sơ">
                <div className="space-y-4">
                  {PROPERTY_DOSSIER_STEP_NAMES.slice(0, 6).map(
                    (name, index) => (
                      <button
                        type="button"
                        key={name}
                        onClick={() => {
                          setActiveStep(index);
                          setActiveModule("history");
                        }}
                        className="flex w-full items-start gap-3 text-left"
                      >
                        <span
                          className={`mt-1 h-3 w-3 shrink-0 rounded-full ${dossier.steps?.[index]?.status === "completed" ? "bg-[#2C9B67]" : dossier.steps?.[index]?.status === "in_progress" ? "bg-[#E6B54A]" : "bg-[#C8D3C9]"}`}
                        ></span>
                        <span>
                          <span className="block text-xs text-[#70847A]">
                            {formatDate(
                              dossier.steps?.[index]?.updatedAt ||
                                dossier.dossier.updatedAt
                            )}
                          </span>
                          <span className="mt-1 block text-xs font-bold text-[#18352D]">
                            {name}
                          </span>
                        </span>
                      </button>
                    )
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveModule("history")}
                  className="mt-4 w-full rounded-lg border border-[#D9E2DA] px-3 py-2 text-xs font-bold text-[#315B4B]"
                >
                  Xem tất cả lịch sử
                </button>
              </DetailCard>
              <DetailCard title="Thống kê tương tác">
                <DetailRow label="Lượt xem hồ sơ" value="—" />
                <DetailRow label="Khách quan tâm" value="—" />
                <DetailRow label="Lượt xem nhà" value="—" />
                <DetailRow
                  label="Tiến độ hồ sơ"
                  value={`${completedSteps}/12 bước`}
                />
              </DetailCard>
            </div>
          </div>
        </>
      );
    if (activeModule === "publishing")
      return <PublishingTaskPanel dossier={dossier} />;
    if (activeModule === "history")
      return (
        <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
          <DetailCard title="Lịch sử hồ sơ">
            <div className="space-y-3">
              {PROPERTY_DOSSIER_STEP_NAMES.map((name, index) => (
                <button
                  type="button"
                  key={name}
                  onClick={() => {
                    setActiveStep(index);
                    setActiveModule("workflow");
                  }}
                  className="flex w-full items-center gap-3 rounded-xl border border-[#E4EAE5] p-3 text-left hover:bg-[#F7FAF6]"
                >
                  <span
                    className={`h-3 w-3 rounded-full ${dossier.steps?.[index]?.status === "completed" ? "bg-[#2C9B67]" : dossier.steps?.[index]?.status === "in_progress" ? "bg-[#E6B54A]" : "bg-[#C8D3C9]"}`}
                  />
                  <span className="flex-1 text-sm font-semibold">{name}</span>
                  <span className="text-xs text-[#70847A]">
                    {formatDate(
                      dossier.steps?.[index]?.updatedAt ||
                        dossier.dossier.updatedAt
                    )}
                  </span>
                </button>
              ))}
            </div>
          </DetailCard>
          <DetailCard title="Thống kê tương tác">
            <DetailRow label="Tiến độ hoàn thành" value={`${progress}%`} />
            <DetailRow
              label="Cập nhật gần nhất"
              value={formatDate(dossier.dossier.updatedAt)}
            />
            <div className="mt-4 h-3 overflow-hidden rounded-full bg-[#E1E8E0]">
              <div
                className="h-full rounded-full bg-[#2C6A57]"
                style={{ width: `${progress}%` }}
              />
            </div>
          </DetailCard>
        </div>
      );
    if (activeModule === "media")
      return (
        <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
          <DetailCard title="Hình ảnh & Video">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {imageDocuments.map((doc: any) => (
                <a
                  key={doc.id}
                  href={doc.url}
                  target="_blank"
                  rel="noreferrer"
                  className="overflow-hidden rounded-xl border border-[#E4EAE5] bg-[#F7FAF6]"
                >
                  <img
                    src={doc.url}
                    alt={doc.fileName}
                    className="aspect-square w-full object-cover"
                  />
                  <span className="block truncate p-2 text-xs font-semibold">
                    {doc.fileName}
                  </span>
                </a>
              ))}
              {!imageDocuments.length && (
                <p className="col-span-full rounded-xl bg-[#F7FAF6] p-5 text-sm text-[#70847A]">
                  Chưa có hình ảnh. Chuyển đến Phiếu khảo sát để tải ảnh lên.
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => {
                setActiveStep(2);
                setActiveModule("workflow");
              }}
              className="mt-4 text-sm font-bold text-[#214EDE]"
            >
              Quản lý hình ảnh khảo sát
            </button>
          </DetailCard>
          <DetailCard title="Tóm tắt media">
            <DetailRow
              label="Hình ảnh"
              value={`${imageDocuments.length} file`}
            />
            <DetailRow
              label="Tổng tài liệu"
              value={`${documents.length} file`}
            />
            <DetailRow label="Bước lưu trữ" value="Khảo sát thực tế" />
          </DetailCard>
        </div>
      );
    if (activeModule === "owner")
      return (
        <div className="grid gap-4 lg:grid-cols-2">
          <DetailCard title="Thông tin chủ nhà">
            <DetailRow
              label="Họ tên"
              value={owner.fields.ownerName || "Chưa cập nhật"}
            />
            <DetailRow
              label="Số điện thoại"
              value={owner.fields.ownerPhone || "Chưa cập nhật"}
            />
            <DetailRow
              label="Địa chỉ tài sản"
              value={owner.fields.address || dossier.property?.location}
            />
            <DetailRow
              label="Nhu cầu bán"
              value={owner.fields.saleNeed || "Chưa cập nhật"}
            />
          </DetailCard>
          <DetailCard title="Công việc liên quan">
            <p className="text-sm leading-6 text-[#60766D]">
              Thông tin chủ nhà được lấy từ Bước 1 — Tiếp nhận thông tin BĐS.
              Bạn có thể cập nhật và lưu trực tiếp trong biểu mẫu nghiệp vụ.
            </p>
            <button
              type="button"
              onClick={() => {
                setActiveStep(0);
                setActiveModule("workflow");
              }}
              className="mt-4 rounded-lg bg-[#1F5A4A] px-4 py-2 text-sm font-bold text-white"
            >
              Mở biểu mẫu chủ nhà
            </button>
          </DetailCard>
        </div>
      );
    if (activeModule === "buyer")
      return (
        <div className="grid gap-4 lg:grid-cols-2">
          <DetailCard title="Thông tin khách hàng">
            <DetailRow
              label="Khách mua"
              value={buyer.fields.buyerName || "Chưa cập nhật"}
            />
            <DetailRow
              label="Nhu cầu"
              value={buyer.fields.buyerNeed || "Chưa cập nhật"}
            />
            <DetailRow
              label="Ngân sách"
              value={buyer.fields.buyerBudget || "Chưa cập nhật"}
            />
            <DetailRow
              label="Lịch liên hệ/xem"
              value={buyer.fields.contactSchedule || "Chưa cập nhật"}
            />
          </DetailCard>
          <DetailCard title="Theo dõi quan tâm">
            <DetailRow
              label="Mức độ quan tâm"
              value={stepData(9).fields.interestLevel || "Chưa cập nhật"}
            />
            <DetailRow
              label="Ý kiến sau khi xem"
              value={stepData(9).fields.buyerFeedback || "Chưa cập nhật"}
            />
            <button
              type="button"
              onClick={() => {
                setActiveStep(8);
                setActiveModule("workflow");
              }}
              className="mt-4 rounded-lg bg-[#1F5A4A] px-4 py-2 text-sm font-bold text-white"
            >
              Mở quản lý khách mua
            </button>
          </DetailCard>
        </div>
      );
    const config =
      activeModule === "legal"
        ? {
            title: "Hồ sơ pháp lý",
            step: 4,
            rows: [
              ["Loại giấy chứng nhận", legal.fields.certificateType],
              ["Diện tích trên giấy", legal.fields.certificateArea],
              ["Mục đích sử dụng", legal.fields.landUse],
              ["Chủ sở hữu", legal.fields.legalOwner],
              ["Thế chấp/tranh chấp", legal.fields.mortgage],
            ],
          }
        : activeModule === "planning"
          ? {
              title: "Thông tin quy hoạch",
              step: 3,
              rows: [
                ["Tình trạng quy hoạch", stepData(3).fields.planningStatus],
                ["Lộ giới/đường dự phóng", stepData(3).fields.roadBoundary],
                ["Chỉ giới xây dựng", stepData(3).fields.constructionLine],
              ],
            }
          : activeModule === "survey"
            ? {
                title: "Phiếu khảo sát",
                step: 2,
                rows: [
                  ["Ngày khảo sát", survey.fields.surveyDate],
                  ["Hiện trạng thực tế", survey.fields.observedCondition],
                  ["Ưu điểm", survey.fields.strengths],
                  ["Hạn chế", survey.fields.limitations],
                ],
              }
            : {
                title: "Định giá BĐS",
                step: 5,
                rows: [
                  ["Giá chủ nhà đưa ra", valuation.fields.ownerPrice],
                  ["Giá tham khảo thị trường", valuation.fields.marketPrice],
                  ["Giá đề xuất", valuation.fields.recommendedPrice],
                  ["Mức thương lượng", valuation.fields.negotiation],
                ],
              };
    return (
      <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <DetailCard title={config.title}>
          <div className="grid gap-1">
            {config.rows.map(([label, value]) => (
              <DetailRow
                key={label}
                label={label}
                value={value || "Chưa cập nhật"}
              />
            ))}
          </div>
          <button
            type="button"
            onClick={() => {
              setActiveStep(config.step);
              setActiveModule("workflow");
            }}
            className="mt-4 rounded-lg bg-[#1F5A4A] px-4 py-2 text-sm font-bold text-white"
          >
            Mở biểu mẫu cập nhật
          </button>
        </DetailCard>
        <DetailCard title="Tài liệu liên quan">
          <div className="space-y-2">
            {documents
              .filter((doc: any) => doc.stepNumber === config.step + 1)
              .map((doc: any) => (
                <a
                  key={doc.id}
                  href={doc.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-between rounded-lg border border-[#E4EAE5] p-3 text-sm font-semibold text-[#315B4B]"
                >
                  <span className="truncate">{doc.fileName}</span>
                  <Download size={14} />
                </a>
              ))}
            {!documents.some(
              (doc: any) => doc.stepNumber === config.step + 1
            ) && (
              <p className="text-sm text-[#70847A]">
                Chưa có tài liệu cho mục này.
              </p>
            )}
          </div>
        </DetailCard>
      </div>
    );
  };

  return (
    <>
      <div className="dossier-readable dossier-large-content overflow-hidden rounded-[1.75rem] border border-[#DCE5DE] bg-[#F8FAF7] shadow-[0_20px_60px_rgba(24,53,45,0.08)]">
        <div className="border-b border-[#E4EAE5] bg-white px-4 py-4 sm:px-7 sm:py-5">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-start gap-3">
              <button
                type="button"
                onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                className="mt-1 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[#D9E2DA] text-lg text-[#18352D] hover:bg-[#EFF5F0]"
                aria-label="Quay lên đầu hồ sơ"
              >
                ←
              </button>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-xs font-bold uppercase tracking-[.12em] text-[#2C6A57]">
                    Hồ sơ BĐS:{" "}
                    {dossier.property?.propertyCode ||
                      `BDS-${dossier.dossier.id}`}
                  </p>
                  <span className="rounded-full bg-[#DDF1E3] px-3 py-1 text-[11px] font-bold text-[#22724E]">
                    {statusText}
                  </span>
                </div>
                <h2 className="mt-2 text-2xl font-bold tracking-[-.03em] text-[#18352D] sm:text-3xl">
                  {dossier.property?.title ||
                    `Bất động sản #${dossier.dossier.propertyId}`}
                </h2>
                <p className="mt-1 text-sm text-[#70847A]">
                  Ngày tạo: {formatDate(dossier.dossier.createdAt)} · Môi giới
                  phụ trách: {dossier.property?.brokerName || "Chưa cập nhật"}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 xl:justify-end">
              <button
                type="button"
                onClick={() => {
                  const isPublished = dossier.property?.status === "published";
                  const publicPath =
                    isPublished && dossier.property?.slug
                      ? `/bat-dong-san/${encodeURIComponent(dossier.property.slug)}`
                      : "/bat-dong-san";
                  const publicUrl = `${window.location.origin}${publicPath}`;
                  navigator.clipboard
                    ?.writeText(publicUrl)
                    .then(() =>
                      toast.success(
                        isPublished
                          ? "Đã sao chép liên kết công khai của sản phẩm"
                          : "Sản phẩm chưa công khai; đã sao chép trang nguồn hàng công khai",
                      ),
                    )
                    .catch(() => toast.error("Không thể sao chép liên kết công khai"));
                }}
                className="inline-flex items-center gap-2 rounded-lg border border-[#C9D6CB] bg-white px-3 py-2 text-xs font-bold text-[#315B4B] hover:bg-[#F1F6F1]"
              >
                Chia sẻ hồ sơ
              </button>
              <button
                type="button"
                onClick={() => { void openDossierAsWordDocx(dossier); }}
                className="inline-flex items-center gap-2 rounded-lg border border-[#C9D6CB] bg-white px-3 py-2 text-xs font-bold text-[#315B4B] hover:bg-[#F1F6F1]"
              >
                <FileDown size={14} />
                Xuất Word
              </button>
              <button
                type="button"
                onClick={() =>
                  document
                    .getElementById("dossier-module-content")
                    ?.scrollIntoView({ behavior: "smooth" })
                }
                className="inline-flex items-center gap-2 rounded-lg bg-[#214EDE] px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-[#173EBF]"
              >
                Chỉnh sửa
              </button>
            </div>
          </div>
        </div>
        <section className="mx-4 mt-4 overflow-hidden rounded-2xl border border-[#DCE5DE] bg-white sm:mx-7">
          <div className="grid lg:grid-cols-[260px_1fr]">
            <div className="relative min-h-[190px] overflow-hidden bg-[#E7F0E8] lg:min-h-[215px]">
              {imageDocuments[0] ? (
                <img
                  src={imageDocuments[0].url}
                  alt="Ảnh hồ sơ bất động sản"
                  className="h-full min-h-[190px] w-full object-cover lg:min-h-[215px]"
                />
              ) : (
                <div className="flex h-full min-h-[190px] flex-col items-center justify-center gap-2 text-center text-sm text-[#6C8175]">
                  <FolderKanban size={38} className="text-[#2C6A57]" />
                  <span>Chưa có ảnh đại diện</span>
                  <span className="text-xs">
                    Tải ảnh tại tab Hình ảnh & Video
                  </span>
                </div>
              )}
            </div>
            <div className="p-4 sm:p-6">
              <div className="grid gap-3 sm:grid-cols-2">
                <SummaryItem
                  icon={MapPin}
                  label="Địa chỉ"
                  value={dossier.property?.location}
                />
                <SummaryItem
                  icon={Home}
                  label="Loại BĐS"
                  value={propertyTypeLabel(dossier.property?.propertyType)}
                />
                <SummaryItem
                  icon={Ruler}
                  label="Diện tích đất"
                  value={
                    dossier.property?.area ? `${dossier.property.area} m²` : "—"
                  }
                />
                <SummaryItem
                  icon={DollarSign}
                  label="Giá bán"
                  value={formatPrice(dossier.property?.price)}
                />
                <SummaryItem
                  icon={Ruler}
                  label="Mặt tiền / đường"
                  value={
                    dossier.property?.roadWidth
                      ? `${dossier.property.roadWidth} m`
                      : "—"
                  }
                />
                <SummaryItem
                  icon={FileText}
                  label="Pháp lý"
                  value={
                    dossier.property?.certificateType ||
                    dossier.property?.legalStatus
                  }
                />
                <SummaryItem
                  icon={Compass}
                  label="Hướng"
                  value={dossier.property?.orientation}
                />
                <SummaryItem
                  icon={BadgeCheck}
                  label="Tình trạng"
                  value={statusText}
                />
              </div>
            </div>
          </div>
        </section>
        <nav
          className="mt-4 flex gap-1 overflow-x-auto border-b border-[#DEE6DF] bg-white px-4 pt-1 sm:px-7"
          aria-label="Các mục hồ sơ"
        >
          {moduleTabs.map(module => {
            const Icon = module.icon;
            return (
              <button
                key={module.id}
                type="button"
                onClick={() => selectModule(module)}
                className={`inline-flex items-center gap-1 whitespace-nowrap rounded-t-xl border-b-2 border px-3 py-3 text-xs font-bold transition ${module.tone} ${module.id === "overview" ? "dossier-overview-tab" : ""} ${activeModule === module.id ? "ring-2 ring-[#214EDE]/35 ring-offset-1 shadow-sm" : "opacity-85 hover:opacity-100 hover:-translate-y-0.5"}`}
              >
                <Icon size={14} />
                {module.label}
              </button>
            );
          })}
        </nav>
        <div id="dossier-module-content" className="p-4 sm:p-7">
          <ModulePanel />
        </div>
        <section className="mx-4 mb-4 rounded-2xl border border-[#DCE5DE] bg-white p-4 sm:mx-7 sm:mb-7 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.15em] text-[#2C6A57]">
                Quy trình hồ sơ
              </p>
              <p className="mt-1 text-sm font-semibold text-[#18352D]">
                {completedSteps}/12 bước đã hoàn thành · {progress}%
              </p>
            </div>
            <span className="rounded-full bg-[#DDF1E3] px-3 py-1 text-xs font-bold text-[#22724E]">
              Đang theo dõi
            </span>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-[#E1E8E0]">
            <div
              className="h-full rounded-full bg-[#2C6A57]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="mt-4 flex gap-1 overflow-x-auto">
            {PROPERTY_DOSSIER_STEP_NAMES.map((name, index) => (
              <button
                key={name}
                type="button"
                onClick={() => {
                  setActiveStep(index);
                  setActiveModule("workflow");
                }}
                title={name}
                aria-label={`Bước ${index + 1}: ${name}`}
                className={`h-3 min-w-3 rounded-full ${dossier.steps?.[index]?.status === "completed" ? "bg-[#2C6A57]" : dossier.steps?.[index]?.status === "in_progress" ? "bg-[#E6B54A]" : "bg-[#C8D3C9]"} ${activeStep === index && activeModule === "workflow" ? "ring-2 ring-[#E6C478] ring-offset-1" : ""}`}
              />
            ))}
          </div>
        </section>
        {activeModule === "workflow" && (
          <div
            id="dossier-update-panel"
            className="grid gap-5 border-t border-[#DCE5DE] p-4 sm:p-7 xl:grid-cols-[minmax(250px,0.8fr)_minmax(0,1.2fr)]"
          >
            <div className="space-y-2">
              {PROPERTY_DOSSIER_STEP_NAMES.map((name, index) => {
                const item = dossier.steps?.[index];
                const meta =
                  PROPERTY_DOSSIER_STATUS_META[
                    (item?.status || "not_started") as StepStatus
                  ];
                return (
                  <button
                    key={name}
                    type="button"
                    onClick={() => setActiveStep(index)}
                    className={`w-full rounded-xl border p-3 text-left ${activeStep === index ? "border-[#214EDE] bg-[#EEF2FF]" : "border-[#E5E9E4] bg-white hover:border-[#AFC5B6]"}`}
                  >
                    <div className="flex items-start gap-3">
                      <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#E6C478]/50 text-xs font-bold">
                        {index + 1}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-semibold">
                          {name}
                        </span>
                        <span
                          className={`mt-1 inline-flex rounded-full px-2 py-1 text-[10px] font-bold ${meta.className}`}
                        >
                          {meta.label}
                        </span>
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="rounded-2xl bg-[#F7F9F5] p-4 sm:p-6">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[.15em] text-[#2C6A57]">
                    Bước {activeStep + 1}
                  </p>
                  <h3 className="mt-2 text-2xl font-bold text-[#18352D]">
                    {PROPERTY_DOSSIER_STEP_NAMES[activeStep]}
                  </h3>
                </div>
                <ClipboardCheck className="text-[#2C6A57]" />
              </div>
              <div className="mt-5 grid gap-4">
                <label className="text-sm font-semibold">
                  Trạng thái
                  <select
                    className="mt-2 min-h-11 w-full rounded-xl border border-[#D9DED7] bg-white px-3 text-sm"
                    value={status}
                    onChange={e => setStatus(e.target.value as StepStatus)}
                  >
                    {Object.entries(PROPERTY_DOSSIER_STATUS_META).map(
                      ([key, value]) => (
                        <option key={key} value={key}>
                          {value.label}
                        </option>
                      )
                    )}
                  </select>
                </label>
                <div className="grid gap-3 sm:grid-cols-2">
                  {(DOSSIER_STEP_FIELDS[activeStep] || []).map(field => (
                    <label key={field.key} className="text-sm font-semibold">
                      {field.label}
                      <input
                        className="mt-2 min-h-11 w-full rounded-xl border border-[#D9DED7] bg-white px-3 text-sm"
                        value={fieldValues[field.key] || ""}
                        onChange={e =>
                          setFieldValues(current => ({
                            ...current,
                            [field.key]: e.target.value,
                          }))
                        }
                        placeholder={field.placeholder}
                      />
                    </label>
                  ))}
                </div>
                <label className="text-sm font-semibold">
                  Thông tin đã thực hiện
                  <textarea
                    className="mt-2 min-h-24 w-full rounded-xl border border-[#D9DED7] bg-white p-3 text-sm"
                    value={details}
                    onChange={e => setDetails(e.target.value)}
                    placeholder="Nhập thêm nội dung nghiệp vụ chưa có trong các trường trên"
                  />
                </label>
                <label className="text-sm font-semibold">
                  Ghi chú nội bộ
                  <textarea
                    className="mt-2 min-h-24 w-full rounded-xl border border-[#D9DED7] bg-white p-3 text-sm"
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Điểm cần theo dõi hoặc kiểm tra lại"
                  />
                </label>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <button
                    type="button"
                    onClick={saveStep}
                    disabled={updateStep.isPending}
                    className="inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-[#1F5A4A] px-4 text-sm font-bold text-white hover:bg-[#174637] disabled:opacity-60"
                  >
                    <Save size={16} />
                    {updateStep.isPending ? "Đang lưu..." : "Lưu bài"}
                  </button>
                  <button
                    type="button"
                    onClick={clearStep}
                    disabled={updateStep.isPending}
                    className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-red-200 px-4 text-sm font-bold text-red-700 hover:bg-red-50 disabled:opacity-60"
                  >
                    <Trash2 size={16} />
                    Xóa nội dung bước
                  </button>
                </div>
              </div>
              <WorkflowFileManager
                dossierId={dossier.dossier.id}
                stepNumber={activeStep + 1}
                documents={documents.filter(
                  (doc: any) => doc.stepNumber === activeStep + 1
                )}
                onRefresh={onRefresh}
                ocrFields={(DOSSIER_STEP_FIELDS[activeStep] || []).map(
                  field => ({ key: field.key, label: field.label })
                )}
                onOcrApplied={result => {
                  const nextFields = Object.fromEntries(
                    Object.entries(result.fields)
                      .filter(
                        ([, value]) =>
                          value !== null &&
                          value !== undefined &&
                          String(value).trim() !== ""
                      )
                      .map(([key, value]) => [key, String(value)])
                  );
                  setFieldValues((current: Record<string, string>) => ({
                    ...current,
                    ...nextFields,
                  }));
                  if (result.summary)
                    setDetails((current: string) =>
                      current
                        ? `${current}\n\n[AI OCR] ${result.summary}`
                        : `[AI OCR] ${result.summary}`
                    );
                  setStatus("needs_review");
                  toast.success(
                    "Đã áp dụng dữ liệu OCR vào biểu mẫu. Vui lòng kiểm tra và bấm Lưu bài."
                  );
                }}
              />
            </div>
          </div>
        )}
      </div>
    </>
  );
}
