# Báo cáo đồng bộ catalog thủ tục pháp lý

## Phạm vi và nguyên tắc

Pipeline áp dụng cho **toàn bộ catalog thủ tục** trả về từ registry/CSDL, không giới hạn 11 mẫu ban đầu. Mỗi mã được canonical hóa trước khi nạp bundle; alias `2912` được quy về `2.000889`. Danh sách chọn thủ tục lấy từ catalog hợp nhất và module không dùng `slice` để giới hạn 66 hoặc 11 mã.

## Danh sách mã canonical trong registry allowlist

| Mã canonical | Alias/ghi chú | Trạng thái pipeline |
|---|---|---|
| `2.000889` | alias `2912` | Canonical hóa, materialize Official nếu binary + SHA-256 hợp lệ |
| `1.012789` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.013978` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.012783` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.011441` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.011443` | — | Cùng pipeline discover → bundle → phân loại → export |
| `2.000410` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.013949` | — | Cùng pipeline discover → bundle → phân loại → export |
| `2.002317` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.004278` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.012784` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.012750` | — | Cùng pipeline discover → bundle → phân loại → export |
| `1.012751` | — | Cùng pipeline discover → bundle → phân loại → export |

Các mã phát sinh thêm trong catalog CSDL cũng đi qua cùng đường `availableProcedures → syncProcedure/batchDiscover → legalKnowledge.bundle`; bảng trên là allowlist registry có binary/metadata được kiểm soát, không phải tuyên bố rằng mọi mã CSDL đã có binary Official.

## Quy trình đã triển khai

| Giai đoạn | Kết quả |
|---|---|
| Đối chiếu catalog và alias | Dùng mã canonical từ registry, loại trùng alias và giữ tên thủ tục theo mã |
| Tìm nguồn | Giữ nguồn DVC, Bộ/Chính phủ và địa phương theo bundle đã đăng ký |
| Materialize binary | Tải mẫu allowlist, lưu bytes vào S3, metadata vào database |
| Kiểm chứng | Chỉ gắn `Official` khi binary hợp lệ và SHA-256 khớp |
| Phân loại thiếu dữ liệu | Giữ `Reference/Pending`, không nâng cấp giả thành Official |
| Đồng bộ giao diện | Invalidate bundle và Official status sau batch hoặc discover, sau đó refetch bundle theo đúng mã |
| Chuyển bước | Nút `Tiếp tục` ở bước chọn/phân tích tự gọi discover nếu bundle chưa có; chỉ chuyển tiếp sau khi refetch hoàn tất |
| Xuất hồ sơ | Xem, DOCX và PDF dùng cùng tập binary Official đã xác minh; Reference/Pending chỉ được xuất dạng nháp có cảnh báo |

## Kiểm thử mẫu và catalog

Luồng mẫu Official và Reference được kiểm tra bằng cùng các contract: nạp bundle, tách `verified_binary` khỏi `matched_reference`, khóa phân tích khi thiếu bundle, cho phép phân tích khi bundle hợp lệ và giữ điều kiện export Official phụ thuộc checksum/storage key. Regression test riêng kiểm tra nút `Tiếp tục` tự gọi discover, invalidate/refetch bundle và lấy bộ đếm Official từ bundle thay vì snapshot DVC cũ.

TypeScript đạt và Vitest đạt **322/322 test**, gồm 58 file test. Preview hai route `/ai-ho-so-dat-dai-tu-dong-moi` và `/ai-ho-so-dat-dai-ai-moi` đã render được skeleton xác thực, không ghi nhận lỗi JSX, TypeScript hoặc runtime trong log preview. Việc chạy đồng bộ dữ liệu thật cho từng mã vẫn phụ thuộc phiên đăng nhập và nguồn bên ngoài; hệ thống không tạo dữ liệu giả để thay thế kết quả đó.

## Quy tắc an toàn dữ liệu

Không dùng tên mẫu, URL trang hướng dẫn hoặc metadata đơn thuần để gắn Official. Nếu chưa có binary và checksum hợp lệ, hồ sơ chỉ được xuất dưới dạng bản nháp/tham khảo và phải hiển thị cảnh báo kiểm tra bản gốc. File người dùng tải lên vẫn được giữ tách khỏi Official Nhà nước.
