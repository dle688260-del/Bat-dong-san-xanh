import { createHash } from "node:crypto";
import { getOfficialLandProcedure } from "./officialLandProcedureRegistry";

import { storagePut } from "./storage";
import { inspectVerifiedTemplate } from "./landTemplateEngine";

export type DvcSourceScope = "national" | "ministry" | "provincial" | "local";
export type DvcSourceTier = "national_dvc" | "ministry_monre" | "provincial_dvc" | "land_registry_office" | "local_branch";
export type DvcAdministrativeLevel = "national" | "ministry" | "province" | "district" | "commune";
export type DvcProvinceCoverageStatus = "verified_domain" | "pending_domain_verification";
export type DvcProvinceCoverage = {
  province: string;
  status: DvcProvinceCoverageStatus;
  sourceIds: string[];
  note: string;
};

export type DvcDossierComponent = {
  id: string;
  name: string;
  required: boolean;
  evidence: string;
};

export type OfficialLayerStatus = "verified" | "not_found" | "pending";
export type OfficialSourceLayers = {
  procedureUrl: { status: OfficialLayerStatus; url: string; evidence: string };
  legalDocument: { status: OfficialLayerStatus; urls: string[]; evidence: string };
  templateFile: { status: OfficialLayerStatus; urls: string[]; evidence: string };
};

export type DvcAttachment = {
  id: string;
  name: string;
  url: string;
  kind: "docx" | "doc" | "pdf" | "xlsx" | "zip" | "other";
  sourceUrl: string;
  checkedAt: string;
  status: "pending" | "matched_reference" | "awaiting_manual_review" | "confirmed_reference" | "verified_binary" | "failed";
  evidence: string;
  storageKey?: string;
  fileUrl?: string;
  checksum?: string;
  fillable?: boolean;
  availableFields?: string[];
  verificationError?: string;
  componentId?: string;
  sourceLayer?: "template_file" | "legal_document" | "procedure_reference";
};

export type DvcSource = {
  id: string;
  province?: string;
  district?: string;
  ward?: string;
  scope: DvcSourceScope;
  tier: DvcSourceTier;
  administrativeLevel: DvcAdministrativeLevel;
  authority: string;
  sourceUrl: string;
  procedureUrls?: Record<string, string>;
  discoveryOnly?: boolean;
  checkedAt: string;
  note: string;
};

export type DvcReceivingAuthority = {
  id: string;
  province: string;
  district?: string;
  ward?: string;
  procedureCode: string;
  name: string;
  role: "receiving" | "processing" | "one-stop";
  sourceUrl: string;
  checkedAt: string;
  confidence: "high" | "medium";
  requiresUserConfirmation: boolean;
  evidence: string;
  note: string;
};

export type DvcScanResult = {
  sourceUrl: string;
  checkedAt: string;
  fetched: boolean;
  httpStatus?: number;
  receivingSection: string;
  processingSection: string;
  items: DvcReceivingAuthority[];
  warnings: string[];
  dossierComponents: DvcDossierComponent[];
  attachments: DvcAttachment[];
  procedureSteps: string[];
  officialLayers?: OfficialSourceLayers;
};

/** Chỉ đăng ký URL đã được kiểm tra; không suy đoán domain tỉnh/thành hoặc URL binary. */
export const DVC_SOURCE_REGISTRY: DvcSource[] = [
  {
    id: "national-vpcp",
    scope: "national",
    tier: "national_dvc",
    administrativeLevel: "national",
    authority: "Cổng Dịch vụ công Quốc gia / Văn phòng Chính phủ",
    sourceUrl: "https://vpcp.dichvucong.gov.vn",
    checkedAt: "2026-08-19",
    note: "Nguồn chuẩn để tra cứu thủ tục, cơ quan thực hiện và liên kết biểu mẫu công khai.",
  },
  {
    id: "ministry-monre-land",
    scope: "ministry",
    tier: "ministry_monre",
    administrativeLevel: "ministry",
    authority: "Hệ thống thông tin giải quyết thủ tục hành chính Bộ Nông nghiệp và Môi trường",
    sourceUrl: "https://dichvucong.monre.gov.vn/pages/linhvuc.aspx?lv=8",
    procedureUrls: {
      "2.002317": "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=67",
      "1.004278": "https://dichvucong.monre.gov.vn/pages/ChiTietDichVuTrucTuyen.aspx?dv=69",
    },
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn fallback cấp Bộ không 503 trong lần kiểm tra; dùng discovery/mapping và chỉ xét binary Official sau khi tải, kiểm tra chữ ký và SHA-256.",
  },
  {
    id: "ministry-mae-template-catalog",
    scope: "ministry",
    tier: "ministry_monre",
    administrativeLevel: "ministry",
    authority: "Bộ Nông nghiệp và Môi trường — Phụ lục VII danh sách mẫu biểu",
    sourceUrl: "https://mae.gov.vn/noidung/Lists/DuLieuLinhVucCongBo/Attachments/2/ph%E1%BB%A5%20l%E1%BB%A5c%20VII.pdf",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Xác minh ký hiệu/tên mẫu; không tự coi PDF danh mục là binary mẫu của từng thủ tục.",
  },
  {
    id: "government-legal-document-search",
    scope: "national",
    tier: "national_dvc",
    administrativeLevel: "national",
    authority: "Cổng Thông tin điện tử Chính phủ — Hệ thống văn bản",
    sourceUrl: "https://chinhphu.vn/he-thong-van-ban",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn discovery văn bản trung ương; lọc lĩnh vực Đất đai - Nhà ở, Luật, Nghị định và Thủ tục hành chính. Không phải URL binary mẫu.",
  },
  {
    id: "government-land-law-document",
    scope: "national",
    tier: "national_dvc",
    administrativeLevel: "national",
    authority: "Cổng Thông tin điện tử Chính phủ — Luật Đất đai",
    sourceUrl: "https://chinhphu.vn/?pageid=27160&docid=211189&classid=1&typegroupid=3",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn legal-document đã xác minh cho Luật Đất đai; chỉ dùng làm căn cứ pháp lý, không coi là mẫu hồ sơ.",
  },
  {
    id: "land-administration-legal-catalog",
    scope: "ministry",
    tier: "ministry_monre",
    administrativeLevel: "ministry",
    authority: "Cục Quản lý đất đai — Danh sách văn bản",
    sourceUrl: "https://qldd.mae.gov.vn/danh-sach-van-ban.htm",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn discovery văn bản lĩnh vực Đất đai, hỗ trợ lọc Luật/Nghị định/Thông tư/Quyết định theo cơ quan ban hành; cần ghi nhận từng URL văn bản cụ thể sau khi kiểm tra.",
  },
  {
    id: "government-national-dvc-directory",
    scope: "national",
    tier: "national_dvc",
    administrativeLevel: "national",
    authority: "Cổng Dịch vụ công Quốc gia — danh mục tỉnh/thành và thủ tục",
    sourceUrl: "https://dichvucong.gov.vn/p/home/dvc-index-tinhthanhpho-tiendogiaiquyet.html",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Directory discovery cấp quốc gia cho tỉnh/thành; nếu cổng yêu cầu CAPTCHA hoặc bị chặn, không suy đoán URL tỉnh và chuyển sang nguồn đã xác minh.",
  },
  {
    id: "land-administration-central-procedure-pack",
    scope: "national",
    tier: "ministry_monre",
    administrativeLevel: "national",
    authority: "Cục Quản lý đất đai — thư mục TTHC cấp Trung ương",
    sourceUrl: "https://drive.google.com/drive/folders/1oxvmBtTmJ3jEtDMkzN-4FL_5DKXjX1u0c",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn discovery chính thức; tên tài liệu chỉ dùng để đối chiếu với mã thật trên DVC, không tự tạo mã hoặc gắn Official.",
  },
  {
    id: "land-administration-provincial-procedure-pack",
    scope: "provincial",
    tier: "provincial_dvc",
    administrativeLevel: "province",
    authority: "Cục Quản lý đất đai — thư mục TTHC cấp tỉnh",
    sourceUrl: "https://drive.google.com/drive/folders/1OWX_co3__UjeNlT6JIykZpZrrBhS05Or",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Thư mục công bố 32 bộ tài liệu TTHC cấp tỉnh; tên tệp dùng để discovery/mapping, chưa tự suy ra mã thủ tục hoặc gắn Official khi chưa có binary và provenance xác thực.",
  },
  {
    id: "land-administration-commune-procedure-pack",
    scope: "local",
    tier: "local_branch",
    administrativeLevel: "commune",
    authority: "Cục Quản lý đất đai — thư mục TTHC cấp xã",
    sourceUrl: "https://drive.google.com/drive/folders/1oBu3P8lxOTDK92FUho4jD2BZxUY7k3tL",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn discovery cấp xã; chỉ dùng khi mã, cơ quan và URL được đối chiếu từ nguồn chính thức, không tự suy đoán phường/xã.",
  },
  {
    id: "land-administration-internal-procedure-pack",
    scope: "ministry",
    tier: "ministry_monre",
    administrativeLevel: "ministry",
    authority: "Cục Quản lý đất đai — thư mục TTHC nội bộ",
    sourceUrl: "https://drive.google.com/drive/folders/13qbgnsfzOOZxm9Dc50gXWVrCbpw6MG_L",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn riêng cho 10 thủ tục nội bộ; không trộn vào catalog hồ sơ dân sự/doanh nghiệp nếu chưa có phạm vi phù hợp.",
  },
  {
    id: "local-hanoi",
    province: "Hà Nội",
    scope: "provincial",
    tier: "provincial_dvc",
    administrativeLevel: "province",
    authority: "Hệ thống thông tin giải quyết thủ tục hành chính Thành phố Hà Nội",
    sourceUrl: "https://dichvucong.hanoi.gov.vn",
    checkedAt: "2026-08-20",
    note: "Cổng địa phương đã kiểm tra; dùng để discovery thủ tục đất đai và nguồn biểu mẫu công khai, không suy đoán URL tệp.",
  },
  {
    id: "local-ho-chi-minh",
    province: "Hồ Chí Minh",
    scope: "provincial",
    tier: "provincial_dvc",
    administrativeLevel: "province",
    authority: "Hệ thống thông tin giải quyết thủ tục hành chính Thành phố Hồ Chí Minh",
    sourceUrl: "https://dichvucong.hochiminhcity.gov.vn",
    checkedAt: "2026-08-20",
    note: "Cổng địa phương đã kiểm tra; trang hiện hướng người dùng về DVC Quốc gia từ 19/06/2025, nên chỉ dùng làm fallback discovery và không tự gắn Official.",
  },
  {
    id: "local-da-nang",
    province: "Đà Nẵng",
    scope: "provincial",
    tier: "provincial_dvc",
    administrativeLevel: "province",
    authority: "Trung tâm Phục vụ hành chính công Thành phố Đà Nẵng",
    sourceUrl: "https://hcc.danang.gov.vn",
    checkedAt: "2026-08-20",
    note: "Cổng địa phương đã kiểm tra; tiếp tục quét mục công bố thủ tục và biểu mẫu trước khi xác minh binary.",
  },
  {
    id: "land-registry-hanoi-discovery",
    province: "Hà Nội",
    scope: "local",
    tier: "land_registry_office",
    administrativeLevel: "province",
    authority: "Văn phòng Đăng ký đất đai Hà Nội / Trung tâm Phục vụ hành chính công Hà Nội",
    sourceUrl: "https://ttpvhcc.hanoi.gov.vn/loi-ich-khi-su-dung-dvc-truc-tuyen/tu-ngay-3-9-trien-khai-tiep-nhan-ho-so-thu-tuc-dat-dai-truc-tuyen-khong-phu-thuoc-dia-gioi-hanh-chinh-2850250902173649545.htm",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn xác định kênh tiếp nhận và phạm vi Văn phòng Đăng ký đất đai; không tự suy đoán URL chi nhánh/phường/xã hoặc binary.",
  },
  {
    id: "land-registry-ho-chi-minh-discovery",
    province: "Hồ Chí Minh",
    scope: "local",
    tier: "land_registry_office",
    administrativeLevel: "province",
    authority: "Cổng Thông tin Đất đai TP. Hồ Chí Minh",
    sourceUrl: "https://hcm.mplis.gov.vn/og",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Nguồn đất đai địa phương để tra cứu/mapping; không tự suy đoán URL mẫu và cần đối chiếu DVC Quốc gia.",
  },
  {
    id: "land-registry-da-nang-discovery",
    province: "Đà Nẵng",
    scope: "local",
    tier: "land_registry_office",
    administrativeLevel: "province",
    authority: "Văn phòng Đăng ký đất đai TP. Đà Nẵng",
    sourceUrl: "https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-co-quan-chi-tiet.html?id=423787",
    discoveryOnly: true,
    checkedAt: "2026-08-21",
    note: "Trang cơ quan trên DVC Quốc gia dùng để xác định cơ quan; không mặc định là URL binary.",
  },
];

function normalizeProvinceName(value?: string) {
  return value?.trim().toLocaleLowerCase("vi").replace(/^thành phố\s+/, "") || "";
}

export function getDvcSourcesForProcedure(input: { procedureCode: string; province?: string; receivingAuthority?: string }): DvcSource[] {
  const procedure = getOfficialLandProcedure(input.procedureCode, input.province);
  if (!procedure) return [];
  return DVC_SOURCE_REGISTRY
    .filter(source => (source.scope === "national" && procedure.baseUrl.includes("vpcp.dichvucong.gov.vn")) || source.scope === "ministry" || Boolean(input.province && normalizeProvinceName(source.province) === normalizeProvinceName(input.province)))
    .map(source => ({
      ...source,
      sourceUrl: source.procedureUrls?.[input.procedureCode] || (source.scope === "national" ? procedure.sourceUrl : source.sourceUrl),
      province: input.province,
      authority: input.receivingAuthority || procedure.authority || source.authority,
    }));
}

function cleanPart(value?: string) {
  return value?.trim().replace(/\s+/g, " ") || "";
}

function decodeHtml(value: string) {
  const namedEntities: Record<string, string> = {
    agrave: "à", aacute: "á",  acirc: "â", atilde: "ã", ả: "ả", ạ: "ạ", ằ: "ằ", ắ: "ắ", ặ: "ặ", ẳ: "ẳ", ẵ: "ẵ", ầ: "ầ", ấ: "ấ", ậ: "ậ", ẩ: "ẩ", ẫ: "ẫ",
    egrave: "è", eacute: "é", ecirc: "ê", ẻ: "ẻ", ẹ: "ẹ", ẽ: "ẽ", ề: "ề", ế: "ế", ệ: "ệ", ể: "ể", ễ: "ễ",
    igrave: "ì", iacute: "í", ỉ: "ỉ", ị: "ị", ĩ: "ĩ",
    ograve: "ò", oacute: "ó", ocirc: "ô", ỏ: "ỏ", ọ: "ọ", õ: "õ", ồ: "ồ", ố: "ố", ộ: "ộ", ổ: "ổ", ỗ: "ỗ", ờ: "ờ", ớ: "ớ", ợ: "ợ", ở: "ở", ỡ: "ỡ",
    ugrave: "ù", uacute: "ú", ủ: "ủ", ụ: "ụ", ũ: "ũ", ừ: "ừ", ứ: "ứ", ự: "ự", ử: "ử", ữ: "ữ",
    yacute: "ý", ỳ: "ỳ", ỷ: "ỷ", ỹ: "ỹ", ỵ: "ỵ",
    Agrave: "À", Aacute: "Á", Acirc: "Â", Egrave: "È", Eacute: "É", Ecirc: "Ê", Igrave: "Ì", Iacute: "Í", Ograve: "Ò", Oacute: "Ó", Ocirc: "Ô", Ugrave: "Ù", Uacute: "Ú", Yacute: "Ý",
  };
  return value
    .replace(/&([A-Za-z][A-Za-z0-9]+);/g, (match, name: string) => namedEntities[name] || match)
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<br\s*\/?\s*>/gi, "\n")
    .replace(/<\/(p|div|li|tr|h[1-6]|section|article|td|th)>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&#x2F;/gi, "/")
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number(code)))
    .replace(/\r/g, "")
    .split("\n")
    .map(line => line.replace(/\s+/g, " ").trim())
    .filter(Boolean)
    .join("\n");
}

function sectionBetween(text: string, startLabels: string[], endLabels: string[]) {
  const lower = text.toLocaleLowerCase("vi");
  const start = startLabels.map(label => lower.indexOf(label.toLocaleLowerCase("vi"))).filter(index => index >= 0).sort((a, b) => a - b)[0];
  if (start === undefined) return "";
  const endPositions = endLabels.map(label => lower.indexOf(label.toLocaleLowerCase("vi"), start + 10)).filter(index => index > start);
  const end = endPositions.length ? Math.min(...endPositions) : Math.min(text.length, start + 8000);
  return text.slice(start, end).trim();
}

function uniqueMatches(text: string, patterns: Array<{ role: DvcReceivingAuthority["role"]; name: string; confidence: DvcReceivingAuthority["confidence"] }>) {
  const lower = text.toLocaleLowerCase("vi");
  return patterns.filter(item => lower.includes(item.name.toLocaleLowerCase("vi")));
}

function absoluteUrl(href: string, sourceUrl: string) {
  try {
    const url = new URL(href.replace(/\\\\\//g, "/"), sourceUrl);
    url.pathname = url.pathname.replace(/\/{2,}/g, "/");
    return url.toString();
  } catch { return ""; }
}

function attachmentKind(url: string, name = ""): DvcAttachment["kind"] {
  const match = `${url} ${name}`.toLocaleLowerCase("vi").match(/\.(docx?|pdf|xlsx|zip)(?:$|[?#\s\/])/);
  return (match?.[1] as DvcAttachment["kind"] | undefined) || "other";
}

async function hydrateDvcAttachment(attachment: DvcAttachment, checkedAt: string, component?: DvcDossierComponent, sessionCookie = ""): Promise<DvcAttachment> {
  if (!/^https:\/\/(?:[^/]+\.)?(?:gov\.vn|dichvucong\.gov\.vn|chinhphu\.vn|cdnchinhphu\.vn|monre\.gov\.vn|mae\.gov\.vn)(?:\/|$)/i.test(attachment.url)) {
    return { ...attachment, status: "failed", verificationError: "URL không thuộc miền nguồn nhà nước được phép." };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 60_000);
  try {
    const headers: Record<string, string> = { Accept: "application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/octet-stream", "Accept-Language": "vi,en-US;q=0.8,en;q=0.6", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126 Safari/537.36", Referer: attachment.sourceUrl, Origin: new URL(attachment.sourceUrl).origin, "Sec-Fetch-Dest": "document", "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Site": "same-site" };
    if (sessionCookie) headers.Cookie = sessionCookie;
    let response: Response | undefined;
    let lastStatus: number | undefined;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      response = await fetch(attachment.url, { redirect: "follow", signal: controller.signal, headers });
      lastStatus = response.status;
      if (response.ok || ![502, 503, 504].includes(response.status) || attempt === 2) break;
      await new Promise(resolve => setTimeout(resolve, 500 * (attempt + 1)));
    }
    if (!response?.ok) return { ...attachment, status: "failed", verificationError: `Không tải được binary (${lastStatus ?? "unknown"}) sau 3 lần thử; máy chủ DVC có thể đang tạm thời không phục vụ file.` };
    const bytes = Buffer.from(await response.arrayBuffer());
    if (!bytes.length || bytes.length > 12 * 1024 * 1024) return { ...attachment, status: "failed", verificationError: "Binary rỗng hoặc vượt giới hạn 12 MB." };
    const checksum = createHash("sha256").update(bytes).digest("hex");
    const contentType = (response.headers.get("content-type") || "application/octet-stream").split(";")[0].toLowerCase();
    const isDocx = attachment.kind === "docx";
    const isLegacyDoc = attachment.kind === "doc";
    const isPdf = attachment.kind === "pdf";
    const isOleCompoundDocument = bytes.subarray(0, 8).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
    const signatureOk = isDocx
      ? bytes.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04]))
      : isPdf
        ? bytes.subarray(0, 5).toString() === "%PDF-"
        : isLegacyDoc
          ? isOleCompoundDocument
          : bytes.length > 4;
    if (!signatureOk) return { ...attachment, status: "failed", checksum, verificationError: "Chữ ký binary không khớp định dạng công bố." };
    const fileName = attachment.name || `${attachment.id}.${attachment.kind}`;
    const stored = await storagePut(`dvc-official/${new URL(attachment.url).hostname}/${checksum}-${fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`, bytes, contentType);
    let fillable: boolean | undefined;
    let availableFields: string[] | undefined;
    let fillWarning = "";
    if (isDocx || isPdf) {
      try {
        const inspected = await inspectVerifiedTemplate({ id: attachment.id, fileName, format: isDocx ? "docx" : "pdf", mimeType: contentType, sourceUrl: attachment.url, sourceCheckedAt: checkedAt, sha256: checksum, storageKey: stored.key, sourceStatus: "verified" }, bytes, []);
        fillable = inspected.fillable;
        availableFields = inspected.availableFields;
        fillWarning = inspected.warning || "";
      } catch (error) {
        fillWarning = error instanceof Error ? error.message : "Không kiểm tra được fillability.";
      }
    }
    return { ...attachment, status: isLegacyDoc ? "matched_reference" : "verified_binary", checkedAt, storageKey: stored.key, fileUrl: stored.url, checksum, fillable, availableFields, componentId: component?.id, sourceLayer: "template_file", evidence: `${attachment.evidence} Binary đã tải từ URL công bố và lưu S3. SHA-256: ${checksum}.${isLegacyDoc ? " Word legacy .doc chỉ được giữ dưới dạng Reference-only; không được đưa vào engine Official/fill. " : ""}${fillWarning ? ` ${fillWarning}` : ""}` };
  } catch (error) {
    return { ...attachment, status: "failed", verificationError: error instanceof Error ? error.message : "Lỗi không xác định khi tải binary." };
  } finally {
    clearTimeout(timer);
  }
}

function normalizeTemplateToken(value: string) {
  return value
    .toLocaleLowerCase("vi")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/mfs|mus/g, "mau")
    .replace(/mau\s*(?:so\s*)?/g, "mau")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function mapAttachmentToComponent(attachment: DvcAttachment, components: DvcDossierComponent[]) {
  const haystack = `${attachment.name} ${attachment.evidence}`.toLocaleLowerCase("vi");
  const normalizedHaystack = normalizeTemplateToken(haystack);
  const attachmentCodes = extractTemplateCodes(haystack);
  return components.find(component => {
    const componentName = component.name.toLocaleLowerCase("vi");
    const normalizedComponent = normalizeTemplateToken(componentName);
    const componentCodes = extractTemplateCodes(componentName);
    const exactName = normalizedHaystack.includes(normalizedComponent) || normalizedComponent.includes(normalizedHaystack);
    const sharedCode = componentCodes.some(code => attachmentCodes.includes(code));
    const meaningfulToken = normalizedComponent.split(/\s+/).some(token => token.length > 4 && normalizedHaystack.includes(token));
    return exactName || sharedCode || meaningfulToken;
  })?.id;
}

function extractDvcAttachments(html: string, sourceUrl: string, checkedAt: string, instructionSection = "", downloadBaseUrl = ""): DvcAttachment[] {
  const results: DvcAttachment[] = [];
  const seen = new Set<string>();
  const push = (rawUrl: string, rawName: string, evidence: string) => {
    const normalizedHref = rawUrl.replace(/\\\\\//g, "/").replace(/\\u0026/gi, "&").replace(/&amp;/gi, "&").trim();
    const url = absoluteUrl(normalizedHref, sourceUrl);
    const name = decodeHtml(rawName).replace(/\s+/g, " ").trim() || url.split(/[?#]/)[0].split("/").pop() || "Tệp đính kèm DVC";
    if (!url || seen.has(url)) return;
    if (url.includes("download_file.jsp?ma=") && !/download_file\.jsp\?ma=[^&?#]+/i.test(url)) return;
    const lower = `${url} ${name}`.toLocaleLowerCase("vi");
    const kind = attachmentKind(url, name);
    const isCandidate = kind !== "other" || /(mẫu|mau|đơn|don|tờ khai|to khai|biểu mẫu|bieu mau|file đính kèm|file dinh kem|phụ lục|phu luc|download|tai[-_]?xuong|file|attachment)/i.test(lower);
    if (!isCandidate) return;
    seen.add(url);
    results.push({ id: `dvc-attachment-${results.length}`, name, url, kind, sourceUrl, checkedAt, status: "pending", evidence });
  };

  if (downloadBaseUrl) {
    const maudonPattern = /<span\b[^>]*onclick=["']downloadMaudon\(\s*["']([^"']+)["']\s*\)["'][^>]*>([\s\S]*?)<\/span>/gi;
    for (const match of Array.from(html.matchAll(maudonPattern))) {
      const code = match[1] || "";
      const label = decodeHtml(match[2] || "").replace(/\\s+/g, " ").trim();
      if (code && label) push(`${downloadBaseUrl}?ma=${encodeURIComponent(code)}`, label, `Mẫu ${label} được DVC công bố bằng downloadMaudon(${code}); scanner tự resolve URL_DOWNLOAD chính thức.`);
    }
  }

  const anchorPattern = /<a\b([^>]*?)>([\s\S]*?)<\/a>/gi;
  for (const match of Array.from(html.matchAll(anchorPattern))) {
    const attributes = match[1] || "";
    const label = decodeHtml(match[2] || "");
    const hrefPattern = /(?:href|data-href|data-url|download)=["']([^"']+)["']/gi;
    let hrefMatch: RegExpExecArray | null;
    while ((hrefMatch = hrefPattern.exec(attributes)) !== null) {
      const rawUrl = hrefMatch[1] || "";
      push(rawUrl, label, `Liên kết trích từ phần Hướng dẫn làm hồ sơ trên DVC: ${label.trim() || rawUrl}`);
    }
  }

  // Nhiều cổng hành chính không đặt URL binary trong href mà gọi endpoint từ onclick/data-download-url.
  // Chỉ nhận các mẫu có dấu hiệu tải file và vẫn để hydrateDvcAttachment kiểm tra MIME/chữ ký/SHA-256.
  const scriptDownloadPattern = /(?:onclick|data-download-url|data-file-url|data-attachment-url)=["']([^"']+)["']/gi;
  for (const match of Array.from(html.matchAll(scriptDownloadPattern))) {
    const raw = match[1] || "";
    const candidates = raw.match(/(?:https?:\/\/|\/)[^'"\s)]+/gi) || [raw];
    for (const candidate of candidates) {
      if (/(download|file|attachment|tai|mau|phu.?luc|export)/i.test(candidate)) {
        push(candidate, "Tệp tải từ nút biểu mẫu", "URL endpoint tải file được trích từ thuộc tính JavaScript/data-* công khai của trang nguồn; scanner tiếp tục kiểm MIME, chữ ký và SHA-256.");
      }
    }
  }
  if (/^https:\/\/dichvucong\.monre\.gov\.vn\//i.test(sourceUrl)) {
    const monreDownloadPattern = /onclick=["']downloadfile\(\s*["']([^"']+)["'][^)]*\)["']/gi;
    for (const match of Array.from(html.matchAll(monreDownloadPattern))) {
      const fileId = match[1]?.trim();
      if (!fileId) continue;
      const before = html.slice(Math.max(0, (match.index ?? 0) - 1400), match.index ?? 0);
      const cellPattern = /<td\b[^>]*>([\s\S]*?)<\/td>/gi;
      const labels = Array.from(before.matchAll(cellPattern)).map(item => decodeHtml(item[1] || "").replace(/\s+/g, " ").trim()).filter(Boolean);
      const label = labels.at(-1) || "Tệp đính kèm DVC Bộ";
      const binaryUrl = `https://mdm.monre.gov.vn:8800/api/core/mdm/nodes/viewbyid/${encodeURIComponent(fileId)}`;
      push(binaryUrl, label, `Nút Tải về công khai của Cổng DVC Bộ gọi downloadfile(${fileId}); endpoint binary được trả về bởi cơ chế tải của chính trang.`);
    }
  }

  const urlPattern = /https?:[^"'< >\s]+/gi;
  for (const match of Array.from(html.matchAll(urlPattern))) {
    const candidate = match[0].replace(/\\\\\//g, "/");
    if (/\.(?:docx|pdf|xlsx|zip)(?:[?#]|$)/i.test(candidate) || /(download|tai[-_]?xuong|file|attachment|export_word|maudon)/i.test(candidate)) {
      push(candidate, "Tệp được công bố trong dữ liệu trang DVC", "URL tệp được trích từ HTML/JSON công khai của trang DVC; scanner sẽ tự tải và kiểm tra binary trước khi trả snapshot.");
    }
  }
  if (instructionSection) {
    const sectionLinks = instructionSection.match(/https?:[^\s<>"']+/gi) || [];
    for (const candidate of sectionLinks) push(candidate, "Tệp trong phần Hướng dẫn làm hồ sơ", "URL tệp được trích trong phần Hướng dẫn làm hồ sơ; scanner sẽ tự tải, lưu S3 và kiểm tra checksum trước khi trả snapshot.");
  }
  return results.slice(0, 50);
}

function extractProcedureSteps(text: string): string[] {
  const section = sectionBetween(text, ["Trình tự thực hiện"], ["Cách thức thực hiện", "Thành phần hồ sơ", "Cơ quan thực hiện"]);
  if (!section) return [];
  return section.split(/\n|(?=\b(?:Bước\s*)?\d{1,2}[.)\-:]\s+)/i)
    .map(item => item.replace(/^\s*(?:Bước\s*)?\d{1,2}[.)\-:]\s*/i, "").trim())
    .filter(item => item.length > 12)
    .filter((item, index, values) => values.findIndex(value => value.toLocaleLowerCase("vi") === item.toLocaleLowerCase("vi")) === index)
    .slice(0, 30);
}

function registryFallbackDossierComponents(procedureCode: string): DvcDossierComponent[] {
  const procedure = getOfficialLandProcedure(procedureCode);
  if (!procedure) return [];
  const labels = [
    ...(procedure.requirements || []).map(item => item.label),
    ...(procedure.referenceTemplates || []).map(item => item.name),
  ].filter((label, index, values) => label.trim().length > 8 && values.findIndex(value => value.toLocaleLowerCase("vi") === label.toLocaleLowerCase("vi")) === index);
  // A registered procedure must never become an empty 0/0 bundle merely
  // because its live HTML has no parseable attachment section.
  if (!labels.length) labels.push(`Thành phần hồ sơ theo hướng dẫn thủ tục: ${procedure.name}`);
  return labels.map((name, index) => ({
    id: `registry-component-${index}`,
    name,
    required: false,
    evidence: `Metadata registry đã đăng ký cho thủ tục ${procedureCode}; cần đối chiếu lại với trang hướng dẫn trước khi nộp hồ sơ.`,
  }));
}

function registryOfficialLayers(procedureCode: string): OfficialSourceLayers {
  const procedure = getOfficialLandProcedure(procedureCode);
  const legalUrls = (procedure?.legalDocuments || []).filter(document => document.status === "verified").map(document => document.sourceUrl).filter(Boolean);
  const verifiedTemplateUrls = (procedure?.verifiedTemplates || []).map(template => template.sourceUrl).filter(Boolean);
  return {
    procedureUrl: {
      status: procedure?.sourceUrl ? "verified" : "not_found",
      url: procedure?.sourceUrl || "",
      evidence: procedure?.sourceUrl ? "URL thủ tục được đăng ký từ nguồn chính thức; province không ảnh hưởng tra cứu theo mã." : "Chưa có URL thủ tục trong registry.",
    },
    legalDocument: {
      status: legalUrls.length ? "verified" : "not_found",
      urls: Array.from(new Set(legalUrls)),
      evidence: legalUrls.length ? "URL văn bản pháp lý được registry ghi nhận riêng với mẫu hồ sơ." : "Chưa có URL văn bản pháp lý xác minh trong registry.",
    },
    templateFile: {
      status: verifiedTemplateUrls.length ? "pending" : "not_found",
      urls: Array.from(new Set(verifiedTemplateUrls)),
      evidence: verifiedTemplateUrls.length ? "Registry có candidate binary; chỉ sau khi tải, kiểm chữ ký và SHA-256 mới chuyển Official." : "Chưa có candidate binary Official trong registry.",
    },
  };
}

function extractDossierComponents(text: string, procedureCode?: string): DvcDossierComponent[] {
  const lower = text.toLocaleLowerCase("vi");
  const startLabels = [
    "hướng dẫn làm hồ sơ",
    "thành phần hồ sơ",
    "thành phần hồ sơ gồm",
    "thành phần, số lượng hồ sơ",
    "hồ sơ gồm",
    "hồ sơ cần chuẩn bị",
    "giấy tờ cần nộp",
  ];
  const endLabels = ["thời hạn giải quyết", "cơ quan thực hiện", "yêu cầu, điều kiện thực hiện", "kết quả thực hiện", "trình tự thực hiện", "phí, lệ phí", "cách thức thực hiện"];
  const candidates: string[] = [];

  for (const label of startLabels) {
    const normalizedLabel = label.toLocaleLowerCase("vi");
    let from = 0;
    while (from < lower.length) {
      const start = lower.indexOf(normalizedLabel, from);
      if (start < 0) break;
      const endPositions = endLabels
        .map(endLabel => lower.indexOf(endLabel, start + normalizedLabel.length + 1))
        .filter(index => index > start);
      const end = endPositions.length ? Math.min(...endPositions) : Math.min(text.length, start + 12000);
      const section = text.slice(start, end).trim();
      if (section) candidates.push(section);
      from = start + normalizedLabel.length;
    }
  }

  const parseSection = (section: string) => {
    const lines = section
      // DVC pages alternate between table rows, nested <li>, numbered text,
      // and inline semicolon-separated requirements after HTML decoding.
      .split(/\n|(?=\b\d{1,2}\s*[.)\-:]\s*)|(?=\b[IVX]{1,4}\s*[.)\-:]\s*)|(?=\s*[•●▪◦*\-]\s+)/)
      .flatMap(item => item.split(/\s*;\s*(?=[A-ZÀ-ỸĐĂÂÊÔƠƯÁÀẢÃẠÉÈẺẼẸÍÌĨỊÓÒỎÕỌÚÙỦŨỤÝỲỶỸỴ])/))
      .map(item => item
        .replace(/^\s*(?:\d{1,2}|[IVX]{1,4})\s*[.)\-:]\s*/i, "")
        .replace(/^[-•●▪◦*]\s*/, "")
        .replace(/^\(?[a-zđ]\)?[.)\-:]\s*/i, "")
        .replace(/\s+/g, " ")
        .trim())
      .filter(item => item.length > 8)
      .filter(item => !/^(hướng dẫn làm hồ sơ|thành phần hồ sơ|thành phần,?\s*số lượng hồ sơ|hồ sơ gồm|giấy tờ|tài liệu)$/i.test(item))
      .filter(item => !/^(thời hạn giải quyết|cơ quan thực hiện|yêu cầu, điều kiện thực hiện|kết quả thực hiện|cách thức thực hiện|trình tự thực hiện|phí,? lệ phí)$/i.test(item))
      .filter(item => !/^\d+\s*(ngày|giờ|tháng)\b/i.test(item));
    return lines.filter((name, index, values) => values.findIndex(value => value.toLocaleLowerCase("vi") === name.toLocaleLowerCase("vi")) === index).slice(0, 50);
  };

  const names = candidates.map(parseSection).sort((a, b) => b.length - a.length)[0] || [];
  if (!names.length && procedureCode) return registryFallbackDossierComponents(procedureCode);
  return names.map((name, index) => ({
    id: `dvc-component-${index}`,
    name,
    required: !/(nếu có|trường hợp|khi cần|tùy trường hợp|theo yêu cầu)/i.test(name),
    evidence: `Trích nguyên văn từ phần thành phần/hướng dẫn hồ sơ: ${name}`,
  }));
}

function findDvcDetailUrl(html: string, sourceUrl: string) {
  const matches = html.match(/(?:href|data-href|data-url)=["']([^"']*dvc-tthc-thu-tuc-hanh-chinh-(?:lien-thong-)?chi-tiet\.html\?ma_thu_tuc=\d+(?:\.\d+)*[^"']*)["']/i);
  return matches?.[1] ? absoluteUrl(matches[1], sourceUrl) : "";
}

async function resolveDvcDownloadBaseUrl() {
  try {
    const response = await fetch("https://vpcp.dichvucong.gov.vn/jsp/rest.jsp", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json", "User-Agent": "BatDongSanXanh-DVC-Scanner/2.1" },
      body: `params=${encodeURIComponent(JSON.stringify({ service: "get_url_downfile", provider: "dvcquocgia", type: "ref" }))}`,
    });
    if (!response.ok) return "";
    const payload = await response.json() as Array<{ URL_DOWNLOAD?: string }>;
    return typeof payload?.[0]?.URL_DOWNLOAD === "string" ? payload[0].URL_DOWNLOAD : "";
  } catch { return ""; }
}

async function fetchDvcPage(sourceUrl: string) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetch(sourceUrl, {
      signal: controller.signal,
      headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "vi,en-US;q=0.8,en;q=0.6", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/126 Safari/537.36" },
    });
    const html = await response.text();
    const setCookie = response.headers.get("set-cookie") || "";
    const cookie = setCookie.split(/, (?=[^;=]+=[^;]+)/).map(value => value.split(";")[0]).filter(Boolean).join("; ");
    return { ok: response.ok, status: response.status, html, text: decodeHtml(html), cookie };
  } finally {
    clearTimeout(timer);
  }
}

async function fetchFirstAvailableSource(input: { procedureCode: string; province?: string; receivingAuthority?: string }) {
  const candidates = getDvcSourcesForProcedure(input);
  const failures: string[] = [];
  const transientStatuses = new Set([502, 503, 504]);
  for (const source of candidates) {
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      try {
        const fetched = await fetchDvcPage(source.sourceUrl);
        if (fetched.ok) return { source, fetched, failures };
        failures.push(`${source.tier}: ${source.sourceUrl} trả HTTP ${fetched.status} (lần ${attempt})`);
        // 502/503/504 là lỗi tạm thời của nguồn. Ghi nhận URL và tiếp tục
        // thử nguồn chính thức kế tiếp; không coi nguồn dự phòng là Official
        // cho đến khi trang/binary đúng mã được xác minh riêng.
        if (transientStatuses.has(fetched.status)) {
          if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 400));
          continue;
        }
        break;
      } catch (error) {
        const message = error instanceof Error ? error.message : "không xác định";
        failures.push(`${source.tier}: ${source.sourceUrl} lỗi ${message} (lần ${attempt})`);
        if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 400));
      }
    }
    // Khi một nguồn 503, vòng lặp tiếp tục sang nguồn chính thức kế tiếp.
    // Mỗi nguồn vẫn giới hạn tối đa hai lần thử để không tạo tải lớn lên
    // các cổng đang quá tải.
  }
  return { source: candidates[0], fetched: undefined, failures };
}

/**
 * Quét nội dung trang DVC thật. Không dựng tên chi nhánh từ chuỗi tỉnh/huyện/xã.
 * Nếu trang chỉ công bố loại cơ quan mà chưa trả tên địa phương cụ thể, kết quả
 * được giữ ở trạng thái cần người dùng xác nhận.
 */
export async function scanDvcProcedureSource(input: { procedureCode: string; province?: string; district?: string; ward?: string }): Promise<DvcScanResult> {
  const procedure = getOfficialLandProcedure(input.procedureCode, input.province);
  const checkedAt = new Date().toISOString();
  const initialSourceUrl = procedure?.sourceUrl || "";
  if (!initialSourceUrl) return { sourceUrl: initialSourceUrl, checkedAt, fetched: false, receivingSection: "", processingSection: "", items: [], warnings: ["Không tìm thấy URL thủ tục trong registry."], dossierComponents: [], attachments: [], procedureSteps: [], officialLayers: registryOfficialLayers(input.procedureCode) };
  try {
    const resolved = await fetchFirstAvailableSource({ procedureCode: input.procedureCode, province: input.province });
    const fetched = resolved.fetched;
    const sourceUrl = resolved.source?.sourceUrl || initialSourceUrl;
    if (!fetched) {
      return { sourceUrl, checkedAt, fetched: false, httpStatus: 503, receivingSection: "", processingSection: "", items: [], warnings: ["Không nguồn nào trong registry trả về được nội dung thủ tục; đang dùng thành phần fallback từ metadata registry để không tạo trạng thái 0/0 mù mờ.", ...resolved.failures], dossierComponents: registryFallbackDossierComponents(input.procedureCode), attachments: [], procedureSteps: [], officialLayers: registryOfficialLayers(input.procedureCode) };
    }
    const detailUrl = findDvcDetailUrl(fetched.html, sourceUrl);
    const detail = detailUrl && detailUrl !== sourceUrl ? await fetchDvcPage(detailUrl) : undefined;
    const combinedHtml = `${fetched.html}\n${detail?.html || ""}`;
    const combinedText = decodeHtml(combinedHtml);
    const downloadBaseUrl = combinedHtml.includes("downloadMaudon") ? await resolveDvcDownloadBaseUrl() : "";
    const receivingSection = sectionBetween(combinedText, ["Trình tự thực hiện", "Cách thức thực hiện"], ["Cách thức thực hiện", "Thành phần hồ sơ", "Cơ quan thực hiện"]);
    const instructionSection = sectionBetween(combinedText, ["Hướng dẫn làm hồ sơ", "Thành phần hồ sơ", "Thành phần, số lượng hồ sơ", "Hồ sơ gồm"], ["Thời hạn giải quyết", "Cơ quan thực hiện", "Yêu cầu, điều kiện thực hiện", "Kết quả thực hiện"]);
    const dossierComponents = extractDossierComponents(combinedText, input.procedureCode);
    const procedureSteps = extractProcedureSteps(combinedText);
    const discoveredAttachments = extractDvcAttachments(combinedHtml, detailUrl || sourceUrl, checkedAt, instructionSection, downloadBaseUrl);
    const hydrateAttachments = async (items: DvcAttachment[], cookie = "") => Promise.all(items.map(async attachment => {
      const componentId = mapAttachmentToComponent(attachment, dossierComponents);
      const component = dossierComponents.find(item => item.id === componentId);
      return hydrateDvcAttachment({ ...attachment, componentId }, checkedAt, component, cookie);
    }));
    let attachments = await hydrateAttachments(discoveredAttachments, [fetched.cookie, detail?.cookie].filter(Boolean).join("; "));
    const attachmentFallbackNotes: string[] = [];
    const needsAttachmentFallback = attachments.length === 0 || attachments.some(item => item.status === "failed");
    if (needsAttachmentFallback) {
      const fallbackSources = getDvcSourcesForProcedure({ procedureCode: input.procedureCode, province: input.province }).filter(candidate => candidate.sourceUrl !== sourceUrl);
      for (const fallbackSource of fallbackSources) {
        try {
          const fallbackPage = await fetchDvcPage(fallbackSource.sourceUrl);
          if (!fallbackPage.ok) {
            attachmentFallbackNotes.push(`${fallbackSource.tier}: ${fallbackSource.sourceUrl} trả HTTP ${fallbackPage.status}`);
            continue;
          }
          attachmentFallbackNotes.push(`${fallbackSource.tier}: ${fallbackSource.sourceUrl} phản hồi HTML`);
          const fallbackDetailUrl = findDvcDetailUrl(fallbackPage.html, fallbackSource.sourceUrl);
          const fallbackDetail = fallbackDetailUrl && fallbackDetailUrl !== fallbackSource.sourceUrl ? await fetchDvcPage(fallbackDetailUrl) : undefined;
          const fallbackHtml = `${fallbackPage.html}\n${fallbackDetail?.html || ""}`;
          const fallbackText = decodeHtml(fallbackHtml);
          const fallbackInstruction = sectionBetween(fallbackText, ["Hướng dẫn làm hồ sơ", "Thành phần hồ sơ", "Thành phần, số lượng hồ sơ", "Hồ sơ gồm"], ["Thời hạn giải quyết", "Cơ quan thực hiện", "Yêu cầu, điều kiện thực hiện", "Kết quả thực hiện"]);
          const fallbackBaseUrl = fallbackHtml.includes("downloadMaudon") ? await resolveDvcDownloadBaseUrl() : "";
          const fallbackDiscovered = extractDvcAttachments(fallbackHtml, fallbackDetailUrl || fallbackSource.sourceUrl, checkedAt, fallbackInstruction, fallbackBaseUrl);
          if (!fallbackDiscovered.length) {
            attachmentFallbackNotes.push(`${fallbackSource.tier}: không phát hiện liên kết binary phù hợp`);
            continue;
          }
          attachmentFallbackNotes.push(`${fallbackSource.tier}: phát hiện ${fallbackDiscovered.length} candidate attachment`);
          const hydrated = await hydrateAttachments(fallbackDiscovered, [fallbackPage.cookie, fallbackDetail?.cookie].filter(Boolean).join("; "));
          const successful = hydrated.filter(item => item.status === "verified_binary");
          if (successful.length) attachments = [...attachments.filter(item => item.status !== "failed"), ...successful];
          else if (!attachments.length) attachments = hydrated;
          if (successful.length) break;
        } catch (error) {
          attachmentFallbackNotes.push(`${fallbackSource.tier}: lỗi ${error instanceof Error ? error.message : "không xác định"}`);
        }
      }
    }
    const processingSection = sectionBetween(fetched.text, ["Cơ quan thực hiện"], ["Yêu cầu, điều kiện thực hiện", "Thông tin phí, lệ phí", "Câu hỏi thường gặp"]);
    const patterns: Array<{ role: DvcReceivingAuthority["role"]; name: string; confidence: DvcReceivingAuthority["confidence"] }> = [
      { role: "receiving", name: "Văn phòng đăng ký đất đai", confidence: "high" },
      { role: "receiving", name: "Chi nhánh Văn phòng đăng ký đất đai", confidence: "high" },
      { role: "one-stop", name: "Trung tâm Phục vụ hành chính công", confidence: "high" },
      { role: "one-stop", name: "Ủy ban nhân dân cấp xã", confidence: "medium" },
      { role: "processing", name: "Ủy ban nhân dân cấp xã", confidence: "high" },
    ];
    const seen = new Set<string>();
    const items = uniqueMatches(`${receivingSection}\n${processingSection}`, patterns)
      .filter(item => { const key = `${item.role}:${item.name}`; if (seen.has(key)) return false; seen.add(key); return true; })
      .map((item, index) => ({
        id: `${input.procedureCode}-${index}-${item.role}`,
        province: cleanPart(input.province),
        district: cleanPart(input.district) || undefined,
        ward: cleanPart(input.ward) || undefined,
        procedureCode: input.procedureCode,
        name: item.name,
        role: item.role,
        sourceUrl,
        checkedAt,
        confidence: item.confidence,
        requiresUserConfirmation: true,
        evidence: item.role === "processing" ? processingSection.slice(0, 900) : receivingSection.slice(0, 900),
        note: "Tên cơ quan được trích nguyên văn từ trang DVC Quốc gia; trang nguồn chưa trả tên chi nhánh cụ thể theo địa bàn đã chọn.",
      }));
    const warnings: string[] = [];
    if (resolved.failures.length) warnings.push(`Đã fallback qua ${resolved.failures.length} nguồn trước khi chọn nguồn hoạt động: ${resolved.failures.join("; ")}`);
    if (attachmentFallbackNotes.length) warnings.push(`Đã thử fallback binary sau lỗi/thiếu file: ${attachmentFallbackNotes.join("; ")}`);
    if (!items.length) warnings.push("Không trích xuất được cơ quan từ nội dung trang; không được tự suy đoán nơi nộp hồ sơ.");
    if (input.district || input.ward) warnings.push("Cần mở/tra cứu thêm nguồn DVC địa phương để xác định đúng chi nhánh theo quận/huyện/xã/phường.");
    if (!procedureSteps.length) warnings.push("Không trích xuất được Trình tự thực hiện từ trang DVC; workflow sẽ cần rà soát.");
    if (!dossierComponents.length) warnings.push("Không trích xuất được thành phần hồ sơ từ phần hướng dẫn DVC.");
    if (!attachments.length) warnings.push("Trang DVC không công bố liên kết file mẫu có thể tải; giữ trạng thái chưa tìm thấy file Official.");
    if (combinedHtml.includes("downloadMaudon") && !downloadBaseUrl) warnings.push("DVC có tên mẫu và mã downloadMaudon nhưng chưa resolve được URL_DOWNLOAD.");
    if (attachments.some(item => item.status === "failed")) warnings.push("Một hoặc nhiều URL binary đã phát hiện nhưng không tải/kiểm tra được; xem verificationError của từng file.");
    const registryLayers = registryOfficialLayers(input.procedureCode);
    const officialLayers: OfficialSourceLayers = {
      procedureUrl: registryLayers.procedureUrl.url ? registryLayers.procedureUrl : { status: sourceUrl ? "verified" : "not_found", url: sourceUrl, evidence: sourceUrl ? "URL thủ tục lấy từ nguồn đã quét." : "Chưa có URL thủ tục." },
      legalDocument: registryLayers.legalDocument,
      templateFile: attachments.some(item => item.status === "verified_binary")
        ? { status: "verified", urls: attachments.filter(item => item.status === "verified_binary").map(item => item.fileUrl || item.url), evidence: "Binary đã tải, kiểm chữ ký và SHA-256 thành công." }
        : registryLayers.templateFile,
    };
    return { sourceUrl, checkedAt, fetched: fetched.ok, httpStatus: fetched.status, receivingSection, processingSection, items, warnings, dossierComponents, attachments, procedureSteps, officialLayers };
  } catch (error) {
    return { sourceUrl: initialSourceUrl, checkedAt, fetched: false, receivingSection: "", processingSection: "", items: [], warnings: [`Không thể truy cập nguồn DVC: ${error instanceof Error ? error.message : "lỗi không xác định"}`, "Đang dùng thành phần fallback từ metadata registry nếu thủ tục đã được đăng ký."], dossierComponents: registryFallbackDossierComponents(input.procedureCode), attachments: [], procedureSteps: [], officialLayers: registryOfficialLayers(input.procedureCode) };
  }
}

export async function discoverDvcReceivingAuthorities(input: { procedureCode: string; province?: string; district?: string; ward?: string }) {
  const province = cleanPart(input.province);
  const district = cleanPart(input.district);
  const ward = cleanPart(input.ward);
  const procedure = getOfficialLandProcedure(input.procedureCode, province || undefined);
  if (!procedure || !province) return { items: [], notice: "Cần chọn tỉnh/thành và thủ tục trước khi tra cơ quan tiếp nhận." };
  const scan = await scanDvcProcedureSource({ ...input, province });
  return {
    items: scan.items,
    sourceUrl: scan.sourceUrl,
    checkedAt: scan.checkedAt,
    procedureName: procedure.name,
    scan,
    notice: scan.items.length
      ? "Đã quét nội dung DVC và trích xuất cơ quan có bằng chứng nguồn. Hãy xác nhận nơi nộp hồ sơ theo địa phương trước khi xuất Official."
      : "DVC chưa trả về cơ quan cụ thể cho địa bàn này; không tự suy đoán chi nhánh. Hãy mở nguồn hoặc bổ sung nguồn DVC địa phương.",
  };
}

export type DvcProcedureBundle = {
  procedureCode: string;
  sourceUrl: string;
  checkedAt: string;
  components: Array<DvcDossierComponent & { attachments: DvcAttachment[]; status: "ready" | "ready_reference" | "needs_file" | "failed" }>;
  allAttachments: DvcAttachment[];
  missingComponents: string[];
  readyCount: number;
  totalCount: number;
  officialLayers: OfficialSourceLayers;
  referenceTemplates: DvcAttachment[];
  officialTemplates: DvcAttachment[];
};

export type DvcReferenceBinary = {
  id?: string;
  name: string;
  url: string;
  kind: "docx" | "doc" | "pdf";
  sourceUrl: string;
  checkedAt?: string;
  checksum?: string;
  storageKey?: string;
  fileUrl?: string;
  fillable?: boolean;
  evidence?: string;
  matchedKeywords?: string[];
};

/** Chuẩn hóa để đối chiếu mã mẫu như Mus14, MFS14 và Mẫu số 14. */
function extractTemplateCodes(value: string): string[] {
  const normalized = value.toLocaleLowerCase("vi").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const compact = normalized.replace(/[^a-z0-9]/g, "");
  const matches = compact.match(/(?:mus|mfs|mau(?:so)?)[0-9]+[a-z]?/g) || [];
  return Array.from(new Set(matches.map(code => {
    const normalizedCode = code.replace(/^mauso/, "mau").replace(/^mus/, "mau").replace(/^mfs/, "mau").replace(/[a-z]$/, "");
    return normalizedCode;
  })));
}

function isExactTemplateReferenceMatch(reference: DvcReferenceBinary, component: DvcDossierComponent): boolean {
  const referenceText = `${reference.name} ${(reference.matchedKeywords || []).join(" ")}`;
  const componentText = `${component.name} ${component.evidence}`;
  const referenceCodes = extractTemplateCodes(referenceText);
  const componentCodes = extractTemplateCodes(componentText);
  if (referenceCodes.length > 0 && componentCodes.length > 0) return referenceCodes.some(code => componentCodes.includes(code));
  const normalize = (value: string) => value.toLocaleLowerCase("vi").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
  const referenceNames = [reference.name, ...(reference.matchedKeywords || [])]
    .map(value => normalize(value).replace(/\\.(docx?|pdf)$/i, ""))
    .filter(value => value.length >= 5);
  const componentName = normalize(component.name);
  return referenceNames.some(referenceName => componentName.includes(referenceName) || referenceName.includes(componentName));
}

/** Ghép file đúng mẫu đã tải từ nguồn tham khảo vào snapshot; không cấp Official. */
export function mergeDvcReferenceBinaries(scan: DvcScanResult, references: DvcReferenceBinary[]): DvcScanResult {
  const merged = [...scan.attachments];
  for (const reference of references) {
    const component = scan.dossierComponents.find(item => {
      return isExactTemplateReferenceMatch(reference, item);
    });
    if (!component || merged.some(item => item.url === reference.url || (reference.checksum && item.checksum === reference.checksum))) continue;
    merged.push({
      id: reference.id || `reference-${reference.checksum || reference.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`,
      name: reference.name,
      url: reference.url,
      kind: reference.kind,
      sourceUrl: reference.sourceUrl,
      checkedAt: reference.checkedAt || scan.checkedAt,
      status: "awaiting_manual_review",
      evidence: reference.evidence || "Đã đối chiếu đúng tên/mã mẫu và ghép vào hồ sơ; chờ người dùng kiểm tra thủ công trước khi nộp.",
      storageKey: reference.storageKey,
      fileUrl: reference.fileUrl,
      checksum: reference.checksum,
      fillable: reference.fillable,
      componentId: component.id,
      sourceLayer: "template_file",
    });
  }
  return { ...scan, attachments: merged };
}

/** Xác nhận thủ công một file tham khảo để dùng trong bộ hồ sơ cá nhân; không cấp Official Nhà nước. */
export function confirmReferenceForPersonalUse(scan: DvcScanResult, attachmentId: string): DvcScanResult {
  return {
    ...scan,
    attachments: scan.attachments.map(attachment =>
      attachment.id === attachmentId && (attachment.status === "awaiting_manual_review" || attachment.status === "matched_reference")
        ? {
            ...attachment,
            status: "confirmed_reference" as const,
            evidence: `${attachment.evidence} Người dùng đã xác nhận thủ công để sử dụng cá nhân; chưa phải Official Nhà nước.`,
          }
        : attachment,
    ),
  };
}

/** Gom toàn bộ thành phần và binary theo đúng snapshot của một thủ tục. */
function deriveOfficialLayers(scan: DvcScanResult): OfficialSourceLayers {
  const templateFiles = scan.attachments.filter(item => item.sourceLayer === "template_file" || ["verified_binary", "matched_reference", "awaiting_manual_review", "confirmed_reference"].includes(item.status));
  const legalDocumentUrls = scan.warnings
    .flatMap(item => item.match(/https?:\/\/\S+/g) || [])
    .filter(url => /gov\.vn|chinhphu\.vn|monre\.gov\.vn|mae\.gov\.vn/i.test(url));
  return {
    procedureUrl: {
      status: scan.sourceUrl ? "verified" : "not_found",
      url: scan.sourceUrl,
      evidence: scan.sourceUrl ? "URL thủ tục được lấy từ registry/DVC." : "Chưa có URL thủ tục xác minh.",
    },
    legalDocument: {
      status: legalDocumentUrls.length ? "verified" : "not_found",
      urls: Array.from(new Set(legalDocumentUrls)),
      evidence: legalDocumentUrls.length ? "Có URL văn bản pháp lý; văn bản được giữ riêng, không coi là mẫu đơn." : "Chưa trích xuất được URL văn bản pháp lý trong snapshot.",
    },
    templateFile: {
      status: templateFiles.some(item => item.status === "verified_binary") ? "verified" : templateFiles.length ? "pending" : "not_found",
      urls: templateFiles.map(item => item.fileUrl || item.url),
      evidence: templateFiles.some(item => item.status === "verified_binary") ? "Có binary mẫu/phụ lục đã kiểm tra." : templateFiles.length ? "Có file khớp mẫu nhưng chưa đủ điều kiện Official." : "Chưa có binary mẫu/phụ lục xác minh.",
    },
  };
}

export function assembleDvcProcedureBundle(scan: DvcScanResult, procedureCode: string): DvcProcedureBundle {
  const mappedAttachments = scan.attachments.map(attachment => {
    if (attachment.componentId) return attachment;
    const componentId = mapAttachmentToComponent(attachment, scan.dossierComponents);
    return componentId ? { ...attachment, componentId } : attachment;
  });
  const components = scan.dossierComponents.map(component => {
    const attachments = mappedAttachments
      .filter(attachment => attachment.componentId === component.id)
      .map(attachment => attachment.componentId === component.id ? attachment : { ...attachment, componentId: component.id });
    const hasVerified = attachments.some(attachment => attachment.status === "verified_binary");
    const hasMatchedReference = attachments.some(attachment => attachment.status === "matched_reference" || attachment.status === "awaiting_manual_review" || attachment.status === "confirmed_reference");
    const hasFailed = attachments.some(attachment => attachment.status === "failed");
    // A đúng-mẫu reference được ghép vào hồ sơ, nhưng chỉ verified_binary mới đủ điều kiện Official.
    return { ...component, attachments, status: hasVerified ? "ready" as const : hasMatchedReference ? "ready_reference" as const : hasFailed ? "failed" as const : "needs_file" as const };
  });
  return {
    procedureCode,
    sourceUrl: scan.sourceUrl,
    checkedAt: scan.checkedAt,
    components,
    allAttachments: mappedAttachments,
    missingComponents: components.filter(component => component.status !== "ready" && component.status !== "ready_reference").map(component => component.name),
    readyCount: components.filter(component => component.status === "ready" || component.status === "ready_reference").length,
    totalCount: components.length,
    officialLayers: deriveOfficialLayers(scan),
    referenceTemplates: mappedAttachments.filter(attachment => attachment.status === "matched_reference" || attachment.status === "awaiting_manual_review" || attachment.status === "confirmed_reference"),
    officialTemplates: mappedAttachments.filter(attachment => attachment.status === "verified_binary" && attachment.sourceLayer === "template_file"),
  };
}

export function listRegisteredDvcProvinces() {
  return Array.from(new Set(DVC_SOURCE_REGISTRY.filter(source => source.province).map(source => source.province!))).sort();
}

/** Coverage catalog toàn quốc dùng để hiển thị tỉnh đã kiểm tra và tỉnh còn chờ xác minh miền. */
const NATIONAL_PROVINCES_FOR_DVC = [
  "An Giang", "Bắc Ninh", "Cà Mau", "Cao Bằng", "Đắk Lắk", "Điện Biên", "Đồng Nai", "Đồng Tháp", "Gia Lai", "Hà Tĩnh", "Hải Phòng", "Hà Nội", "Hưng Yên", "Huế", "Khánh Hòa", "Lai Châu", "Lạng Sơn", "Lào Cai", "Lâm Đồng", "Nghệ An", "Ninh Bình", "Phú Thọ", "Quảng Ngãi", "Quảng Ninh", "Quảng Trị", "Sơn La", "Tây Ninh", "Thái Nguyên", "Thanh Hóa", "Thành phố Hồ Chí Minh", "Đà Nẵng", "Cần Thơ", "Vĩnh Long", "Tuyên Quang",
] as const;

export const DVC_PROVINCE_COVERAGE: DvcProvinceCoverage[] = NATIONAL_PROVINCES_FOR_DVC.map(province => {
  const registryProvince = province === "Thành phố Hồ Chí Minh" ? "Hồ Chí Minh" : province;
  const sourceIds = DVC_SOURCE_REGISTRY.filter(source => source.province === registryProvince).map(source => source.id);
  return {
    province,
    status: sourceIds.length ? "verified_domain" : "pending_domain_verification",
    sourceIds,
    note: sourceIds.length ? "Miền DVC địa phương đã được kiểm tra; vẫn phải xác minh từng thủ tục và binary." : "Chưa đăng ký miền DVC địa phương đã kiểm tra; không tự suy đoán URL.",
  };
});
