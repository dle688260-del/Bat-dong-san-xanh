import { describe, expect, it } from "vitest";
import { buildZaloReplyUrl, CONSIGNMENT_INTEREST, generateConsultationReply } from "./ConsultationAdmin";

describe("consultation reply composer", () => {
  it("creates an editable Vietnamese auto-reply with customer context", () => {
    const reply = generateConsultationReply("Nguyễn Văn A", "Nhà phố Sơn Trà", "qualify");
    expect(reply).toContain("Nguyễn Văn A");
    expect(reply).toContain("Nhà phố Sơn Trà");
    expect(reply).toContain("ngân sách");
  });

  it("builds an actionable Zalo reply URL from the selected editable message", () => {
    const message = generateConsultationReply("Nguyễn Văn A", "Nhà phố Sơn Trà", "viewing");
    const url = buildZaloReplyUrl("0989 682 825", message);
    expect(url).toContain("https://zalo.me/0989682825?text=");
    expect(decodeURIComponent(url.split("?text=")[1] ?? "")).toContain("đặt lịch xem nhà");
  });
});


describe("consignment intake", () => {
  it("keeps consignment requests explicitly identifiable for admin intake", () => {
    expect(CONSIGNMENT_INTEREST).toBe("Ký gửi bất động sản");
  });
});
