import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("AILegalKnowledgeBase batch discovery contract", () => {
  const source = readFileSync(resolve(process.cwd(), "client/src/pages/AILegalKnowledgeBase.tsx"), "utf8");

  it("exposes a whole-catalog discovery action", () => {
    expect(source).toContain("trpc.aiAutoDossier.batchSyncAll.useMutation");
    expect(source).toContain("Đồng bộ toàn bộ catalog thủ tục");
  });

  it("keeps the three file classes visible in the batch summary", () => {
    expect(source).toContain("Official {item.syncStatus.officialCount}");
    expect(source).toContain("Reference {item.syncStatus.referenceCount}");
    expect(source).toContain("Math.max(item.syncStatus.pendingCount || 0, item.warning || item.error ? 1 : 0)");
  });

  it("renders recovery warnings separately from procedure errors", () => {
    expect(source).toContain("item.warning &&");
    expect(source).toContain("Cảnh báo đồng bộ:");
    expect(source).toContain("item.error &&");
  });

  it("loads pending procedure codes from the server after a page reload", () => {
    expect(source).toContain("trpc.aiAutoDossier.pendingStatuses.useQuery");
    expect(source).toContain("const catalogCodes = useMemo");
    expect(source).toContain("pendingStatuses.data?.pendingCodes");
    expect(source).toContain("pendingStatuses.isLoading");
    expect(source).toContain("Đồng bộ lại Pending");
    expect(source).toContain("pendingStatuses.data?.pendingCodes?.length");
  });

  it("retries server-reported pending codes rather than only local batch state", () => {
    expect(source).toContain("const localPendingCodes");
    expect(source).toContain("const pendingCodes = pendingStatuses.data?.pendingCodes?.length ? pendingStatuses.data.pendingCodes : localPendingCodes");
    expect(source).toContain("onlyPending ? pendingCodes : catalogCodes");
  });

  it("shows a separate action for catalog codes that were not processed", () => {
    expect(source).toContain("const unprocessedCodes = useMemo");
    expect(source).toContain("Còn {unprocessedCodes.length} mã chưa chạy trong catalog.");
    expect(source).toContain("Chạy riêng {unprocessedCodes.length} mã chưa chạy");
    expect(source).toContain("runBatchDiscovery(false, unprocessedCodes)");
  });

  it("keeps whole-catalog and pending retry loading states distinct", () => {
    expect(source).toContain('const [batchMode, setBatchMode] = useState<"all" | "pending" | null>(null)');
    expect(source).toContain('setBatchMode(onlyPending ? "pending" : "all")');
    expect(source).toContain('batchSyncAll.isPending && batchMode === "all"');
    expect(source).toContain('batchSyncAll.isPending && batchMode === "pending" ? "Đang đồng bộ Pending…"');
  });

  it("retries each procedure separately and records an explicit recovery warning", () => {
    expect(source).toContain("for (const chunk of chunks)");
    expect(source).toContain("catch (error)");
    expect(source).toContain("for (const procedureCode of chunk)");
    expect(source).toContain("procedureCodes: [procedureCode]");
    expect(source).toContain("parts.push({ results: individualResults })");
    expect(source).toContain("singleError");
    expect(source).toContain("warning: `Chưa nhận được snapshot của thủ tục sau khi thử lại:");
    expect(source).toContain("Chưa nhận được snapshot thành phần — cần chạy lại");
    expect(source).toContain("item.error && !item.warning");
  });
});
