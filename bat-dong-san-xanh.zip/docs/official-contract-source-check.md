# Kiểm tra nguồn mẫu hợp đồng chuyển nhượng

## Kết quả

Nguồn Bộ Tư pháp đăng ngày 30/05/2025 có bài “Mẫu Hợp đồng chuyển nhượng quyền sử dụng đất và tài sản gắn liền với đất”. Bài viết hiển thị toàn văn mẫu hợp đồng và có tệp đính kèm dạng `.doc` với tên `[Mẫu tham khảo] HĐ chuyển nhượng QSDD và TS trên đất.doc`.

Nguồn này là trang phổ biến pháp luật của Bộ Tư pháp và chính trang gọi tệp là “file kèm theo”, nhưng nội dung trang không cho thấy đây là biểu mẫu bắt buộc được ban hành kèm một văn bản quy phạm pháp luật. Vì vậy cần đưa vào hệ thống dưới trạng thái `Reference`/`metadata-only` cho đến khi kiểm tra thêm căn cứ ban hành, phiên bản và khả năng áp dụng tại cơ quan tiếp nhận.

## URL nguồn

- Trang Bộ Tư pháp: https://htpldn.moj.gov.vn/Pages/chi-tiet-tin.aspx?ItemID=24&l=Phobienphapluatkinh
- Tệp đính kèm hiển thị trên trang: https://htpldn.moj.gov.vn/noidung/tintuc/Lists/Phobienphapluatkinh/Attachments/24/[Mẫu tham khảo] HĐ chuyển nhượng QSDD và TS trên đất.doc
- Nghị định 101/2024/NĐ-CP trên Cổng thông tin điện tử Chính phủ: https://vanban.chinhphu.vn/?pageid=27160&docid=210791
- Tệp Nghị định 101/2024/NĐ-CP: https://datafiles.chinhphu.vn/cpp/files/vbpq/2024/7/101-nd.signed.pdf

## Kết quả kiểm tra binary

- Tệp đã tải thụ động từ URL đính kèm của trang Bộ Tư pháp có định dạng **Composite Document File V2 / Microsoft Word `.doc`**, không phải DOCX/PDF.
- SHA-256: `616643918bb25a63e5fc31efb66d1add78a765b490a6376818f10b8d6556d427`.
- Metadata file ghi tiêu đề `Mu s 06/HCN`, khác với tên tệp hiển thị; đây là thêm một lý do để không gắn nhãn Official hoặc dùng làm mẫu điền tự động.
- File được lưu trên web storage dưới đường dẫn `/manus-storage/moj-mau-tham-khao-hop-dong-chuyen-nhuong-qsd-dat_e35a2638.doc` và chỉ được cung cấp như **Reference**.

## Ghi chú sử dụng

Nghị định 101/2024/NĐ-CP là căn cứ về đăng ký, cấp Giấy chứng nhận và hệ thống thông tin đất đai; nguồn đã đọc không chứng minh tệp hợp đồng nói trên là “Official Original” bắt buộc cho mọi trường hợp chuyển nhượng. Không được gắn nhãn Official, không được dùng làm căn cứ nộp hồ sơ chỉ dựa trên tên tệp hoặc việc tệp nằm trên một trang cơ quan nhà nước. Nếu tích hợp, cần tải tệp, kiểm tra loại file, nội dung, ngày/phiên bản, checksum và ghi rõ provenance; tốt nhất hiển thị là `Reference — nguồn Bộ Tư pháp, cần kiểm tra áp dụng`.
