# Kết quả khảo sát thủ tục 1.012789

Nguồn chính thức: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
Trang chi tiết được liên kết: https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=348167

Tên thủ tục: Cung cấp thông tin, dữ liệu đất đai.

Trình tự công bố trên DVC gồm 5 bước: người có nhu cầu nộp phiếu/văn bản yêu cầu; cơ quan tiếp nhận kiểm tra và cấp giấy tiếp nhận/hẹn trả; cơ quan cung cấp xử lý và thông báo phí/giá; người yêu cầu nộp phí nếu có; cơ quan cung cấp trả thông tin/dữ liệu.

Cơ quan tiếp nhận được nêu gồm Trung tâm Phục vụ hành chính công, Văn phòng đăng ký đất đai hoặc Chi nhánh Văn phòng đăng ký đất đai. Nếu địa phương chưa xây dựng cơ sở dữ liệu đất đai, hồ sơ có thể được chuyển đến Văn phòng đăng ký đất đai hoặc UBND cấp xã theo phân cấp.

DVC công bố cả hình thức trực tiếp và trực tuyến. Thời hạn thay đổi theo trường hợp: xử lý/thông báo trong ngày làm việc; trả ngay trong ngày nếu dữ liệu có sẵn; tối đa 2 ngày làm việc trong trường hợp dữ liệu chưa có sẵn trước khi có thể gia hạn; trường hợp cần tìm kiếm/tập hợp/phân tích hoặc lấy ý kiến có thể gia hạn theo thông tin công bố; trường hợp có thỏa thuận riêng thì theo thỏa thuận.

Các điểm cần parser động lấy thêm ở trang chi tiết: thành phần hồ sơ cụ thể, biểu mẫu tải xuống, căn cứ pháp lý, phí/giá, cơ quan thực hiện, điều kiện, kết quả và các file đính kèm. Không được suy đoán các trường chưa lấy được từ nguồn.

Ý nghĩa kiến trúc: mã thủ tục phải trở thành khóa đầu vào; backend tạo một ProcedureDefinition riêng gồm các bước, yêu cầu, nguồn, mẫu, cơ quan, thời hạn và điều kiện; frontend render pipeline từ definition thay vì dùng danh sách bước cố định.

## Phát hiện từ trang chi tiết

Trang chi tiết chính thức: https://vpcp.dichvucong.gov.vn/p/home/dvc-tthc-thu-tuc-hanh-chinh-chi-tiet.html?ma_thu_tuc=348167

DVC cung cấp URL tải bản Word chi tiết thủ tục: https://vpcp.dichvucong.gov.vn/jsp/tthc/export/export_word_detail_tthc.jsp?maTTHC=1.012789&idTTHC=348167

Trang chi tiết xác nhận thủ tục có cả hình thức trực tiếp và trực tuyến. Phí hiển thị theo quy định của Luật phí và lệ phí cùng các văn bản hướng dẫn, nhưng trang trích xuất hiện tại không cho một con số phí cố định. Đây phải là trường trạng thái “cần xác minh theo địa phương/nguồn phí”, không được tự điền số tiền.

Trang chi tiết vẫn cần parser động hoặc tải bản Word để lấy đầy đủ các mục chưa xuất hiện trong phần markdown, đặc biệt thành phần hồ sơ, biểu mẫu và căn cứ pháp lý. URL tải Word là một attachment chính thức để đưa vào hàng chờ Pending; không tự gọi nó là biểu mẫu hồ sơ hay Official Template nếu chưa phân tích nội dung và kiểm tra checksum.
