CREATE TABLE `legal_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`documentNumber` varchar(120),
	`documentType` varchar(120),
	`issuingBody` varchar(180),
	`sourceUrl` text NOT NULL,
	`fileUrl` text,
	`storageKey` text,
	`mimeType` varchar(120),
	`contentText` text,
	`contentHash` varchar(128),
	`status` enum('metadata_only','extracted','verified','superseded','needs_review') NOT NULL DEFAULT 'metadata_only',
	`effectiveFrom` timestamp,
	`effectiveTo` timestamp,
	`checkedAt` timestamp,
	`extractedBy` varchar(120),
	`warnings` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_procedure_requirements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`procedureId` int NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`label` varchar(255) NOT NULL,
	`requirementType` enum('document','field','condition','fee','instruction') NOT NULL,
	`required` tinyint NOT NULL DEFAULT 1,
	`fieldKey` varchar(100),
	`sourceDocumentId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `legal_procedure_requirements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_procedures` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(80) NOT NULL,
	`name` varchar(255) NOT NULL,
	`groupName` varchar(180) NOT NULL,
	`aliases` text,
	`authority` varchar(180),
	`defaultProvince` varchar(120),
	`processingTime` varchar(160),
	`feeNotes` text,
	`conditions` text,
	`workflow` text,
	`status` enum('active','needs_review','archived') NOT NULL DEFAULT 'active',
	`sourceDocumentIds` text,
	`lastReviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_procedures_id` PRIMARY KEY(`id`),
	CONSTRAINT `legal_procedures_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `legal_sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`baseUrl` text NOT NULL,
	`sourceType` enum('government','public_service','local_authority','official_gazette','other') NOT NULL,
	`jurisdiction` varchar(160),
	`active` tinyint NOT NULL DEFAULT 1,
	`lastCheckedAt` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_sources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_sync_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sourceId` int,
	`status` enum('running','completed','failed') NOT NULL DEFAULT 'running',
	`discoveredCount` int NOT NULL DEFAULT 0,
	`changedCount` int NOT NULL DEFAULT 0,
	`summary` text,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`finishedAt` timestamp,
	CONSTRAINT `legal_sync_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_template_fields` (
	`id` int AUTO_INCREMENT NOT NULL,
	`templateId` int NOT NULL,
	`fieldKey` varchar(100) NOT NULL,
	`label` varchar(180) NOT NULL,
	`dataType` enum('text','number','date','boolean','select') NOT NULL DEFAULT 'text',
	`required` tinyint NOT NULL DEFAULT 0,
	`placeholderToken` varchar(180),
	`validationRule` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `legal_template_fields_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `legal_templates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`procedureId` int,
	`sourceId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`documentType` varchar(120) NOT NULL,
	`format` enum('docx','pdf','html','scan') NOT NULL,
	`sourceUrl` text NOT NULL,
	`storageKey` text,
	`fileUrl` text,
	`sourceDocumentId` int,
	`provenance` enum('metadata_only','verified_binary','official') NOT NULL DEFAULT 'metadata_only',
	`checksum` varchar(128),
	`versionLabel` varchar(80),
	`effectiveFrom` timestamp,
	`effectiveTo` timestamp,
	`status` enum('active','needs_review','superseded') NOT NULL DEFAULT 'active',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `legal_templates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `legal_documents` ADD CONSTRAINT `ld_source_fk` FOREIGN KEY (`sourceId`) REFERENCES `legal_sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_procedure_requirements` ADD CONSTRAINT `lpr_proc_fk` FOREIGN KEY (`procedureId`) REFERENCES `legal_procedures`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_procedure_requirements` ADD CONSTRAINT `lpr_doc_fk` FOREIGN KEY (`sourceDocumentId`) REFERENCES `legal_documents`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_sync_runs` ADD CONSTRAINT `lsr_source_fk` FOREIGN KEY (`sourceId`) REFERENCES `legal_sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_fields` ADD CONSTRAINT `ltf_tpl_fk` FOREIGN KEY (`templateId`) REFERENCES `legal_templates`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_templates` ADD CONSTRAINT `lt_proc_fk` FOREIGN KEY (`procedureId`) REFERENCES `legal_procedures`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_templates` ADD CONSTRAINT `lt_source_fk` FOREIGN KEY (`sourceId`) REFERENCES `legal_sources`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_templates` ADD CONSTRAINT `lt_doc_fk` FOREIGN KEY (`sourceDocumentId`) REFERENCES `legal_documents`(`id`) ON DELETE no action ON UPDATE no action;