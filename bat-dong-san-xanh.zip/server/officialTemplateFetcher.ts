import { createHash } from "node:crypto";

const ALLOWED_HOST_SUFFIXES = [
  ".gov.vn",
  ".dichvucong.gov.vn",
  ".chinhphu.vn",
  ".cdnchinhphu.vn",
  ".monre.gov.vn",
  ".mae.gov.vn",
  ".moj.gov.vn",
];
const MAX_BYTES = 6 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 15_000;
const LINK_RE = /(?:href|src)=['"]([^'"]+\.(?:docx?|pdf)(?:\?[^'"]*)?)['"]/gi;

async function fetchWithTimeout(input: string | URL, init: RequestInit = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function assertAllowedHttpUrl(raw: string) {
  const url = new URL(raw);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Chỉ cho phép nguồn HTTP/HTTPS.");
  const host = url.hostname.toLowerCase();
  if (!ALLOWED_HOST_SUFFIXES.some(suffix => host.endsWith(suffix))) throw new Error("Miền nguồn chưa nằm trong danh sách nguồn nhà nước được phép.");
  return url;
}

function normalizeKeyword(value: string) {
  return value.trim().toLocaleLowerCase("vi").replace(/\s+/g, " ");
}

function scoreLink(url: URL, keywords: string[]) {
  const haystack = decodeURIComponent(url.href).toLocaleLowerCase("vi");
  return keywords.reduce((score, keyword) => score + (haystack.includes(normalizeKeyword(keyword)) ? 2 : 0), 0)
    + (url.pathname.toLocaleLowerCase("vi").endsWith(".docx") ? 1 : 0);
}

export async function findOfficialTemplateCandidates(input: { sourceUrl: string; keywords: string[]; minimumScore?: number }) {
  const source = assertAllowedHttpUrl(input.sourceUrl);
  const response = await fetchWithTimeout(source, { redirect: "follow", headers: { accept: "text/html,application/xhtml+xml" } });
  if (!response.ok) throw new Error(`Không đọc được nguồn (${response.status}).`);
  const html = await response.text();
  const keywords = input.keywords.map(normalizeKeyword).filter(Boolean);
  const candidates = Array.from(html.matchAll(LINK_RE)).map(match => {
    const url = new URL(match[1], source);
    return {
      url: url.toString(),
      fileName: decodeURIComponent(url.pathname.split("/").pop() || "template"),
      format: /\.docx(?:\?|$)/i.test(url.toString()) ? "docx" as const : /\.doc(?:\?|$)/i.test(url.toString()) ? "doc" as const : "pdf" as const,
      score: scoreLink(url, keywords),
    };
  }).filter(candidate => {
    try { assertAllowedHttpUrl(candidate.url); return candidate.score >= (input.minimumScore ?? 0); } catch { return false; }
  });
  return Array.from(new Map(candidates.map(item => [item.url, item])).values())
    .sort((a, b) => b.score - a.score).slice(0, 10);
}

/** Rà nhiều trang chính thức; file PDF nghị định không được coi là mẫu nếu không khớp từ khóa mẫu. */
export async function discoverOfficialTemplateFallbacks(input: {
  sourceUrls: string[];
  procedureName: string;
  procedureAliases?: string[];
  templateNames?: string[];
  templateCodes?: string[];
}) {
  const keywords = [
    ...(input.templateNames || []),
    ...(input.templateCodes || []),
    ...(input.procedureAliases || []),
    input.procedureName,
  ].map(normalizeKeyword).filter(Boolean).slice(0, 32);
  const results: Array<{ sourceUrl: string; candidates: Array<{ url: string; fileName: string; format: "docx" | "doc" | "pdf"; score: number; matchedKeywords: string[]; discovery: "official_fallback" }> }> = [];
  for (const sourceUrl of Array.from(new Set(input.sourceUrls.filter(Boolean)))) {
    try {
      const candidates = await findOfficialTemplateCandidates({ sourceUrl, keywords, minimumScore: 2 });
      results.push({ sourceUrl, candidates: candidates.map(candidate => ({
        ...candidate,
        matchedKeywords: keywords.filter(keyword => decodeURIComponent(candidate.url).toLocaleLowerCase("vi").includes(keyword)),
        discovery: "official_fallback" as const,
      })) });
    } catch {
      results.push({ sourceUrl, candidates: [] });
    }
  }
  return { keywords, sources: results, candidates: results.flatMap(item => item.candidates) };
}

export async function downloadOfficialTemplateCandidate(input: { candidateUrl: string; originalFileName?: string }) {
  const url = assertAllowedHttpUrl(input.candidateUrl);
  const response = await fetchWithTimeout(url, { redirect: "follow", headers: { accept: "application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword" } });
  if (!response.ok) throw new Error(`Không tải được binary (${response.status}).`);
  const contentLength = Number(response.headers.get("content-length") || 0);
  if (contentLength > MAX_BYTES) throw new Error("Binary vượt quá giới hạn 6 MB.");
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length > MAX_BYTES) throw new Error("Binary vượt quá giới hạn 6 MB.");
  const contentType = (response.headers.get("content-type") || "").split(";")[0].toLowerCase();
  const hintedName = input.originalFileName || decodeURIComponent(url.pathname.split("/").pop() || "");
  const extension = /\.docx?$/i.test(hintedName) ? "docx" : /\.pdf$/i.test(hintedName) ? "pdf" : (contentType === "application/pdf" ? "pdf" : "docx");
  const allowedMime = extension === "docx"
    ? ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword", "application/octet-stream"]
    : ["application/pdf", "application/octet-stream"];
  const isDocxSignature = bytes.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04])) && bytes.includes(Buffer.from("[Content_Types].xml"));
  const isPdfSignature = bytes.subarray(0, 5).toString("ascii") === "%PDF-";
  const signatureOk = extension === "docx" ? isDocxSignature : isPdfSignature;
  if (!signatureOk) throw new Error("Chữ ký binary không khớp định dạng DOCX/PDF.");
  if (contentType && !allowedMime.includes(contentType) && !(extension === "docx" && isDocxSignature)) throw new Error(`MIME không phù hợp với phần mở rộng: ${contentType}.`);
  return {
    bytes,
    checksum: createHash("sha256").update(bytes).digest("hex"),
    contentType: contentType || (extension === "docx" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "application/pdf"),
    fileName: input.originalFileName || decodeURIComponent(url.pathname.split("/").pop() || `official-template.${extension}`),
    sourceUrl: url.toString(),
  };
}

/**
 * Tải và kiểm tra một URL công khai được tìm thấy qua web search.
 * Kết quả luôn là reference_only; không được dùng để cấp Official Template.
 */
export async function downloadPublicReferenceCandidate(input: { candidateUrl: string; originalFileName?: string }) {
  const url = new URL(input.candidateUrl);
  if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Chỉ cho phép nguồn HTTP/HTTPS.');
  const response = await fetchWithTimeout(url, { redirect: 'follow', headers: { accept: 'application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/msword' } });
  if (!response.ok) throw new Error(`Không tải được reference binary (${response.status}).`);
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length > MAX_BYTES) throw new Error('Reference binary vượt quá giới hạn 6 MB.');
  const contentType = (response.headers.get('content-type') || '').split(';')[0].toLowerCase();
  const responseUrl = response.url || url.toString();
  const responseFileName = decodeURIComponent(new URL(responseUrl).pathname.split('/').pop() || 'reference-template');
  const requestedName = input.originalFileName?.trim() || '';
  const extension = /\.docx$/i.test(requestedName) || (!requestedName && /\.docx$/i.test(responseFileName))
    ? 'docx'
    : /\.doc$/i.test(requestedName) || (!requestedName && /\.doc$/i.test(responseFileName))
      ? 'doc'
      : /\.pdf$/i.test(requestedName) || (!requestedName && /\.pdf$/i.test(responseFileName))
        ? 'pdf'
        : contentType === 'application/msword'
          ? 'doc'
          : contentType === 'application/pdf'
            ? 'pdf'
            : 'other';
  const fileName = requestedName && /\.[a-z0-9]{2,5}$/i.test(requestedName)
    ? requestedName
    : `${requestedName || responseFileName || 'reference-template'}.${extension}`;
  const signature = bytes.subarray(0, 8);
  const isLegacyDocSignature = signature.equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
  const isDocxSignature = bytes.includes(Buffer.from('[Content_Types].xml'));
  const isPdfSignature = signature.toString('ascii', 0, 5) === '%PDF-';
  const signatureOk = extension === 'pdf' ? isPdfSignature : extension === 'docx' ? isDocxSignature : extension === 'doc' ? isLegacyDocSignature : false;
  return {
    bytes,
    checksum: createHash('sha256').update(bytes).digest('hex'),
    contentType,
    fileName,
    sourceUrl: responseUrl,
    extension,
    signatureOk,
    provenance: 'reference_only' as const,
    officialEligible: false as const,
  };
}

/**
 * Thử nguồn Official trước, sau đó fallback sang URL công khai do discovery cung cấp.
 * Fallback public luôn giữ provenance reference_only và không đủ điều kiện Official.
 */
export async function downloadTemplateWithPublicFallback(input: {
  officialUrl?: string;
  publicUrls?: string[];
  originalFileName?: string;
}) {
  if (input.officialUrl) {
    try {
      const official = await downloadOfficialTemplateCandidate({ candidateUrl: input.officialUrl, originalFileName: input.originalFileName });
      return { ...official, status: "verified_binary" as const, provenance: "official_source" as const, officialEligible: true as const };
    } catch {
      // DVC/official source may return 503; continue with public candidates.
    }
  }
  for (const publicUrl of Array.from(new Set(input.publicUrls || []))) {
    try {
      const reference = await downloadPublicReferenceCandidate({ candidateUrl: publicUrl, originalFileName: input.originalFileName });
      if (!reference.signatureOk) continue;
      return { ...reference, status: "matched_reference" as const };
    } catch {
      // Try the next public candidate without aborting the dossier build.
    }
  }
  return { status: "needs_file" as const, officialEligible: false as const };
}

export async function discoverOfficialTemplateCandidates(input: { sourceUrl: string; procedureName: string; procedureAliases?: string[]; templateNames?: string[]; templateCodes?: string[] }) {
  const keywords = [input.procedureName, ...(input.procedureAliases || []), ...(input.templateNames || []), ...(input.templateCodes || [])]
    .map(normalizeKeyword).filter(Boolean).slice(0, 24);
  const candidates = await findOfficialTemplateCandidates({ sourceUrl: input.sourceUrl, keywords });
  const enriched = candidates.map(candidate => ({
    ...candidate,
    matchedKeywords: keywords.filter(keyword => decodeURIComponent(candidate.url).toLocaleLowerCase("vi").includes(keyword)),
    discovery: "procedure_automatic" as const,
  }));
  return { sourceUrl: input.sourceUrl, keywords, candidates: enriched };
}

/**
 * Sinh truy vấn tìm kiếm công khai để caller/browser/search connector rà mẫu thay thế.
 * Đây chỉ là discovery hint; URL tìm được phải đi qua downloadPublicReferenceCandidate
 * hoặc downloadOfficialTemplateCandidate và không tự biến thành Official.
 */
export function buildPublicTemplateSearchQueries(input: {
  procedureCode?: string;
  procedureName?: string;
  componentName?: string;
  templateNames?: string[];
  templateCodes?: string[];
}) {
  const tokens = [
    input.procedureCode,
    input.procedureName,
    input.componentName,
    ...(input.templateNames || []),
    ...(input.templateCodes || []),
  ].map(value => value?.trim()).filter((value): value is string => Boolean(value));
  const unique = Array.from(new Set(tokens));
  const base = unique.join(" ");
  const variants = [
    `${base} file mẫu DOCX PDF`,
    `${base} phụ lục biểu mẫu`,
    `${base} Mus14 Mẫu số 14`,
    `${base} site:gov.vn filetype:docx`,
    `${base} site:gov.vn filetype:pdf`,
  ];
  return Array.from(new Set(variants));
}

export const officialTemplateFetcherPolicy = { allowedHostSuffixes: ALLOWED_HOST_SUFFIXES, maxBytes: MAX_BYTES, requestTimeoutMs: REQUEST_TIMEOUT_MS, verificationStatus: "needs_review" as const };
