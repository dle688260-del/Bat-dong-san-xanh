import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  Check,
  GripVertical,
  LayoutGrid,
  Lock,
  Pencil,
  Plus,
  Settings2,
  SlidersHorizontal,
  Trash2,
  Workflow,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";

export type ModuleRegistryItem = {
  id: string;
  name: string;
  description: string;
  group: string;
  route: string;
  components: string[];
  enabled: boolean;
  required?: boolean;
};

export const MODULE_REGISTRY: ModuleRegistryItem[] = [
  {
    id: "operating-center",
    name: "Trung tâm điều hành",
    description: "KPI, cảnh báo và toàn cảnh vận hành.",
    group: "Điều hành",
    route: "/dashboard",
    components: [
      "status-cards",
      "urgent-queue",
      "workflow-links",
      "ai-manager",
    ],
    enabled: true,
    required: true,
  },
  {
    id: "inventory",
    name: "Nguồn hàng & BĐS",
    description: "Tiếp nhận, khảo sát, pháp lý, định giá, ký gửi và bài đăng.",
    group: "Nguồn hàng",
    route: "/quan-ly-moi-gioi",
    components: [
      "source-status",
      "source-creation-workflow",
      "property-listings",
    ],
    enabled: true,
    required: true,
  },
  {
    id: "customers",
    name: "Khách hàng & Lead",
    description: "Hồ sơ khách, nhu cầu, phân công và chăm sóc.",
    group: "Kinh doanh",
    route: "/dashboard/khach-hang",
    components: ["lead-table", "customer-profile", "follow-up-queue"],
    enabled: true,
  },
  {
    id: "transactions",
    name: "Giao dịch",
    description: "Đàm phán, đặt cọc, công chứng, sang tên và bàn giao.",
    group: "Kinh doanh",
    route: "/dashboard/giao-dich",
    components: ["deal-pipeline", "transaction-dossier", "payment-tracker"],
    enabled: true,
  },
  {
    id: "ai-dossiers",
    name: "Hồ sơ đất đai AI",
    description: "Tạo, phân tích và kiểm tra hồ sơ theo thủ tục.",
    group: "AI & Hồ sơ",
    route: "/hs-dat-dai-ai",
    components: ["procedure-picker", "ocr-review", "legal-warnings"],
    enabled: true,
  },
  {
    id: "reports",
    name: "Báo cáo & Quản trị",
    description: "Doanh số, KPI, quyền truy cập và kiểm soát.",
    group: "Quản trị",
    route: "/dashboard/bao-cao",
    components: ["reports", "permissions", "audit-log"],
    enabled: true,
  },
];

export const COMPONENT_REGISTRY = [
  {
    id: "source-creation-workflow",
    name: "Workflow Tạo nguồn hàng",
    location: "Tầng 3 · Vận hành",
    safety: "Dữ liệu không bị xóa khi ẩn",
  },
  {
    id: "property-listings",
    name: "Tạo bài đăng sản phẩm",
    location: "Sau Ký gửi",
    safety: "Cần duyệt trước khi công khai",
  },
  {
    id: "ocr-review",
    name: "OCR có người xác nhận",
    location: "Hồ sơ đất đai AI",
    safety: "AI chỉ đề xuất, không kết luận pháp lý",
  },
  {
    id: "deal-pipeline",
    name: "Pipeline giao dịch",
    location: "Giao dịch",
    safety: "Giữ lịch sử giao dịch",
  },
] as const;

export type WorkflowRegistryItem = {
  id: string;
  name: string;
  description: string;
  required?: boolean;
  enabled: boolean;
};

export const SOURCE_CREATION_WORKFLOW: WorkflowRegistryItem[] = [
  {
    id: "intake",
    name: "Tiếp nhận",
    description: "Ghi nhận thông tin chủ nhà, BĐS và nhu cầu ký gửi.",
    required: true,
    enabled: true,
  },
  {
    id: "survey",
    name: "Khảo sát",
    description: "Khảo sát thực tế hiện trạng, vị trí và khu vực.",
    required: true,
    enabled: true,
  },
  {
    id: "planning",
    name: "Quy hoạch",
    description: "Đối chiếu quy hoạch và ghi nhận nguồn kiểm tra.",
    enabled: true,
  },
  {
    id: "legal",
    name: "Pháp lý",
    description: "Kiểm tra giấy tờ, tình trạng và cảnh báo thiếu hồ sơ.",
    required: true,
    enabled: true,
  },
  {
    id: "valuation",
    name: "Định giá",
    description: "Ghi nhận giá chủ nhà, giá tham chiếu và đề xuất.",
    enabled: true,
  },
  {
    id: "owner-negotiation",
    name: "Đàm phán chủ nhà",
    description: "Chốt giá, phí, điều kiện và thời hạn ký gửi.",
    required: true,
    enabled: true,
  },
  {
    id: "consignment",
    name: "Ký gửi",
    description: "Xác nhận thỏa thuận ký gửi và hồ sơ liên quan.",
    required: true,
    enabled: true,
  },
  {
    id: "listing",
    name: "Tạo bài đăng sản phẩm",
    description:
      "Tạo bản nháp bài đăng sau khi ký gửi; duyệt trước khi công khai.",
    required: true,
    enabled: true,
  },
];

export default function ModuleBuilderAdmin() {
  const [modules, setModules] = useState(MODULE_REGISTRY);
  const [selectedId, setSelectedId] = useState(MODULE_REGISTRY[0].id);
  const [pendingRemoval, setPendingRemoval] =
    useState<ModuleRegistryItem | null>(null);
  const [pendingComponentRemoval, setPendingComponentRemoval] = useState<{ moduleId: string; componentId: string } | null>(null);
  const [draggedModuleId, setDraggedModuleId] = useState<string | null>(null);
  const [editingModule, setEditingModule] = useState(false);
  const [moduleDraft, setModuleDraft] = useState({ name: "", description: "", route: "", group: "" });
  const [newModule, setNewModule] = useState({ name: "", route: "", group: "" });
  const [newComponentName, setNewComponentName] = useState("");
  const [newComponentPosition, setNewComponentPosition] = useState("end");
  const [editingComponentId, setEditingComponentId] = useState<string | null>(null);
  const [componentDraft, setComponentDraft] = useState({ name: "", location: "", safety: "" });
  const [components, setComponents] = useState<Array<{ id: string; name: string; location: string; safety: string; enabled: boolean }>>(() =>
    COMPONENT_REGISTRY.map(component => ({ ...component, enabled: true }))
  );
  const [workflowSteps, setWorkflowSteps] = useState(SOURCE_CREATION_WORKFLOW);
  const selected = useMemo(
    () => modules.find(item => item.id === selectedId) ?? modules[0],
    [modules, selectedId]
  );

  const toggleModule = (id: string, enabled: boolean) => {
    setModules(current =>
      current.map(item => (item.id === id ? { ...item, enabled } : item))
    );
    toast.success(enabled ? "Đã bật mô-đun" : "Đã ẩn mô-đun", {
      description: "Dữ liệu nghiệp vụ vẫn được giữ nguyên.",
    });
  };

  const toggleComponent = (id: string, enabled: boolean) => {
    setComponents(current =>
      current.map(item => (item.id === id ? { ...item, enabled } : item))
    );
    toast.success(enabled ? "Đã bật thành phần" : "Đã ẩn thành phần", {
      description: "Dữ liệu workflow và hồ sơ vẫn được giữ nguyên.",
    });
  };

  const moveModule = (id: string, direction: -1 | 1) => {
    setModules(current => {
      const index = current.findIndex(item => item.id === id);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= current.length) return current;
      const next = [...current];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next;
    });
  };

  const dropModule = (targetId: string) => {
    if (!draggedModuleId || draggedModuleId === targetId) return;
    setModules(current => {
      const from = current.findIndex(item => item.id === draggedModuleId);
      const to = current.findIndex(item => item.id === targetId);
      if (from < 0 || to < 0) return current;
      const next = [...current];
      const [moved] = next.splice(from, 1);
      next.splice(to, 0, moved);
      return next;
    });
    setDraggedModuleId(null);
    toast.success("Đã đổi vị trí mô-đun");
  };

  const startEditModule = (item: ModuleRegistryItem) => {
    setSelectedId(item.id);
    setModuleDraft({ name: item.name, description: item.description, route: item.route, group: item.group });
    setEditingModule(true);
  };

  const saveModuleEdit = () => {
    if (!selected || !moduleDraft.name.trim() || !moduleDraft.route.trim()) return;
    setModules(current => current.map(item => item.id === selected.id ? { ...item, name: moduleDraft.name.trim(), description: moduleDraft.description.trim(), route: moduleDraft.route.trim(), group: moduleDraft.group.trim() || item.group } : item));
    setEditingModule(false);
    toast.success("Đã cập nhật thông tin mô-đun", { description: "Chỉ cấu hình hiển thị được thay đổi." });
  };

  const addModule = () => {
    const name = newModule.name.trim();
    const route = newModule.route.trim();
    if (!name || !route) return;
    const id = `custom-${Date.now()}`;
    const item: ModuleRegistryItem = { id, name, route, group: newModule.group.trim() || "Tùy chỉnh", description: "Mô-đun tùy chỉnh do quản trị viên thêm.", components: [], enabled: true };
    setModules(current => [...current, item]);
    setSelectedId(id);
    setNewModule({ name: "", route: "", group: "" });
    toast.success("Đã thêm mô-đun mới", { description: "Mô-đun mới chưa xóa hoặc thay đổi dữ liệu CRM nào." });
  };

  const addComponentToSelected = () => {
    const name = newComponentName.trim();
    if (!selected || !name) return;
    const id = `custom-component-${Date.now()}`;
    const component = { id, name, location: selected.name, safety: "Thành phần hiển thị; dữ liệu nghiệp vụ không bị xóa khi ẩn.", enabled: true };
    setComponents(current => [...current, component]);
    setModules(current => current.map(item => {
      if (item.id !== selected.id) return item;
      const nextComponents = [...item.components];
      const targetIndex = newComponentPosition === "start" ? 0 : newComponentPosition === "end" ? nextComponents.length : nextComponents.indexOf(newComponentPosition);
      nextComponents.splice(targetIndex < 0 ? nextComponents.length : targetIndex, 0, id);
      return { ...item, components: nextComponents };
    }));
    setNewComponentName("");
    setNewComponentPosition("end");
    toast.success("Đã thêm thành phần vào mô-đun", { description: `Vị trí: ${newComponentPosition === "end" ? "cuối danh sách" : newComponentPosition === "start" ? "đầu danh sách" : "trước thẻ đã chọn"}.` });
  };

  const startEditComponent = (componentId: string) => {
    const component = components.find(item => item.id === componentId);
    if (!component) return;
    setEditingComponentId(componentId);
    setComponentDraft({ name: component.name, location: component.location, safety: component.safety });
  };

  const saveComponentEdit = () => {
    if (!editingComponentId || !componentDraft.name.trim()) return;
    setComponents(current => current.map(item => item.id === editingComponentId ? { ...item, name: componentDraft.name.trim(), location: componentDraft.location.trim() || item.location, safety: componentDraft.safety.trim() || item.safety } : item));
    setEditingComponentId(null);
    toast.success("Đã cập nhật thẻ thành phần", { description: "Chỉ nội dung hiển thị được thay đổi." });
  };

  const moveSelectedComponent = (componentId: string, direction: -1 | 1) => {
    if (!selected) return;
    setModules(current => current.map(item => {
      if (item.id !== selected.id) return item;
      const index = item.components.indexOf(componentId);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= item.components.length) return item;
      const next = [...item.components];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return { ...item, components: next };
    }));
    toast.success("Đã đổi vị trí thẻ trong module");
  };

  const removeComponentFromSelected = (componentId: string) => {
    if (!selected) return;
    setModules(current => current.map(item => item.id === selected.id ? { ...item, components: item.components.filter(id => id !== componentId) } : item));
    toast.success("Đã gỡ thành phần khỏi mô-đun", { description: "Thành phần và dữ liệu gốc vẫn còn trong registry." });
  };

  const moveWorkflowStep = (id: string, direction: -1 | 1) => {
    setWorkflowSteps(current => {
      const index = current.findIndex(item => item.id === id);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= current.length)
        return current;
      const next = [...current];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next;
    });
  };

  const toggleWorkflowStep = (id: string, enabled: boolean) => {
    setWorkflowSteps(current =>
      current.map(item => (item.id === id ? { ...item, enabled } : item))
    );
    toast.success(enabled ? "Đã bật bước workflow" : "Đã ẩn bước workflow", {
      description:
        "Cấu hình hiển thị thay đổi; dữ liệu bước vẫn được giữ nguyên.",
    });
  };

  const moveComponent = (id: string, direction: -1 | 1) => {
    setComponents(current => {
      const index = current.findIndex(item => item.id === id);
      const nextIndex = index + direction;
      if (index < 0 || nextIndex < 0 || nextIndex >= current.length)
        return current;
      const next = [...current];
      [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
      return next;
    });
  };

  const removeModule = (item: ModuleRegistryItem) => {
    if (item.required) {
      toast.error("Không thể xóa mô-đun bắt buộc", {
        description: "Bạn chỉ có thể ẩn hoặc sắp xếp lại mô-đun này.",
      });
      return;
    }
    setPendingRemoval(item);
  };

  return (
    <DashboardLayout>
      <div className="min-h-screen bg-[#f5f7f4] px-3 py-4 text-[#123d32] sm:px-5 lg:px-7">
        <div className="mx-auto max-w-7xl space-y-5">
          <header className="rounded-[28px] bg-[#123d32] p-6 text-white shadow-[0_22px_60px_rgba(18,61,50,0.16)] sm:p-8">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.24em] text-[#e8c66d]">
                  System architecture
                </p>
                <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">
                  Quản trị Module Builder
                </h1>
                <p className="mt-3 max-w-2xl text-sm leading-7 text-[#d4e4dc]">
                  Quản lý module, thành phần và vị trí workflow từ một registry
                  dùng chung. Thay đổi giao diện không xóa dữ liệu nghiệp vụ.
                </p>
              </div>
              <Badge className="w-fit bg-[#e8c66d] px-3 py-1.5 text-[#123d32]">
                Tương thích ngược
              </Badge>
            </div>
          </header>

          <div className="grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
            <Card className="border-[#dce7df] shadow-sm">
              <CardHeader className="flex-row items-center justify-between gap-3 border-b border-[#edf2ed]">
                <div>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <LayoutGrid className="h-5 w-5 text-[#197052]" /> Module
                    Registry
                  </CardTitle>
                  <p className="mt-1 text-sm text-[#6a7d74]">
                    Bật/tắt và sắp xếp các trung tâm CRM.
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    toast.success("Đã lưu cấu hình module", {
                      description: "Chỉ cấu hình hiển thị được thay đổi.",
                    })
                  }
                >
                  <Check className="mr-2 h-4 w-4" /> Lưu cấu hình
                </Button>
              </CardHeader>
              <div data-module-add-form className="grid gap-2 border-b border-[#edf2ed] bg-[#fbfdfb] p-4 sm:grid-cols-[1.2fr_1fr_0.8fr_auto]">
                <input value={newModule.name} onChange={event => setNewModule(current => ({ ...current, name: event.target.value }))} placeholder="Tên mô-đun mới" aria-label="Tên mô-đun mới" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm outline-none focus:border-[#197052]" />
                <input value={newModule.route} onChange={event => setNewModule(current => ({ ...current, route: event.target.value }))} placeholder="Route, ví dụ /dashboard/ai" aria-label="Route mô-đun mới" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm outline-none focus:border-[#197052]" />
                <input value={newModule.group} onChange={event => setNewModule(current => ({ ...current, group: event.target.value }))} placeholder="Nhóm" aria-label="Nhóm mô-đun mới" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm outline-none focus:border-[#197052]" />
                <Button type="button" onClick={addModule} disabled={!newModule.name.trim() || !newModule.route.trim()} className="bg-[#197052] hover:bg-[#145d44]"><Plus className="mr-2 h-4 w-4" /> Thêm module</Button>
              </div>
              <CardContent className="space-y-3 pt-5">
                {modules.map(item => (
                  <div
                    key={item.id}
                    draggable
                    onDragStart={() => setDraggedModuleId(item.id)}
                    onDragOver={event => event.preventDefault()}
                    onDrop={() => dropModule(item.id)}
                    onDragEnd={() => setDraggedModuleId(null)}
                    className={`flex flex-col gap-3 rounded-2xl border p-4 transition-colors sm:flex-row sm:items-center sm:justify-between ${selectedId === item.id ? "border-[#8eb9a5] bg-[#f2faf5]" : "border-[#e4ece6] bg-white"} ${draggedModuleId === item.id ? "opacity-50" : ""}`}
                  >
                    <button
                      type="button"
                      onClick={() => setSelectedId(item.id)}
                      className="flex min-w-0 items-start gap-3 text-left"
                    >
                      <GripVertical
                        className="mt-1 h-4 w-4 shrink-0 text-[#9aafa5]"
                        aria-hidden="true"
                      />
                      <span className="min-w-0">
                        <span className="block font-bold text-[#174d3e]">
                          {item.name}
                        </span>
                        <span className="mt-1 block text-sm leading-6 text-[#708078]">
                          {item.description}
                        </span>
                        <span className="mt-2 block text-xs font-semibold text-[#197052]">
                          {item.group} · {item.route}
                        </span>
                      </span>
                    </button>
                    <div className="flex shrink-0 items-center gap-3 pl-7 sm:pl-0">
                      <Switch
                        checked={item.enabled}
                        onCheckedChange={value => toggleModule(item.id, value)}
                        aria-label={`${item.enabled ? "Ẩn" : "Bật"} ${item.name}`}
                      />
                      <Button variant="ghost" size="icon" onClick={() => moveModule(item.id, -1)} disabled={modules[0]?.id === item.id} aria-label={`Đưa ${item.name} lên trước`}><ArrowUp className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => moveModule(item.id, 1)} disabled={modules[modules.length - 1]?.id === item.id} aria-label={`Đưa ${item.name} xuống sau`}><ArrowDown className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => startEditModule(item)} aria-label={`Chỉnh sửa ${item.name}`}><Pencil className="h-4 w-4 text-[#197052]" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => removeModule(item)} aria-label={`Ẩn ${item.name}`}><Trash2 className="h-4 w-4 text-[#a45d4a]" /></Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <div className="space-y-5">
              <Card className="border-[#dce7df] shadow-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-xl">
                    <Settings2 className="h-5 w-5 text-[#197052]" /> Module
                    Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-2xl bg-[#f4f8f4] p-4">
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-[#7a9187]">
                      Module đang chọn
                    </p>
                    <p className="mt-2 text-lg font-black">{selected.name}</p>
                    <p className="mt-1 text-sm leading-6 text-[#687b72]">
                      {selected.description}
                    </p>
                  </div>
                  {editingModule ? <div data-module-edit-form className="rounded-2xl border border-[#b9d7c5] bg-[#f7fbf8] p-4">
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-[#197052]">Chỉnh sửa module hiện tại</p>
                    <div className="mt-3 grid gap-2">
                      <input value={moduleDraft.name} onChange={event => setModuleDraft(current => ({ ...current, name: event.target.value }))} aria-label="Tên module đang chỉnh sửa" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm" />
                      <input value={moduleDraft.route} onChange={event => setModuleDraft(current => ({ ...current, route: event.target.value }))} aria-label="Route module đang chỉnh sửa" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm" />
                      <input value={moduleDraft.group} onChange={event => setModuleDraft(current => ({ ...current, group: event.target.value }))} aria-label="Nhóm module đang chỉnh sửa" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm" />
                      <textarea value={moduleDraft.description} onChange={event => setModuleDraft(current => ({ ...current, description: event.target.value }))} aria-label="Mô tả module đang chỉnh sửa" rows={2} className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm" />
                      <div className="flex gap-2"><Button type="button" onClick={saveModuleEdit} disabled={!moduleDraft.name.trim() || !moduleDraft.route.trim()} className="bg-[#197052] hover:bg-[#145d44]">Lưu chỉnh sửa</Button><Button type="button" variant="outline" onClick={() => setEditingModule(false)}>Hủy</Button></div>
                    </div>
                  </div> : null}
                  <div data-component-manager className="rounded-2xl border border-[#e4ece6] p-4">
                    <p className="text-xs font-bold uppercase tracking-wider text-[#80958b]">Thành phần / thẻ trong module</p>
                    <p className="mt-1 text-xs leading-5 text-[#80958b]">Có thể thêm thẻ ở đầu, cuối hoặc chèn trước một thẻ bất kỳ. Ví dụ A → B → C → D.</p>
                    <div className="mt-3 space-y-2">{selected.components.length ? selected.components.map((componentId, index) => {
                      const component = components.find(item => item.id === componentId);
                      return <div key={componentId} className="rounded-xl bg-[#f6faf7] p-2.5" data-component-row={componentId}>
                        <div className="flex items-center gap-2">
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#e2f0e7] text-[11px] font-black text-[#197052]">{index + 1}</span>
                          <span className="min-w-0 flex-1 truncate text-sm font-semibold text-[#1d6b56]">{component?.name ?? componentId}</span>
                          <Button type="button" variant="ghost" size="icon" onClick={() => moveSelectedComponent(componentId, -1)} disabled={index === 0} aria-label={`Đưa thẻ ${component?.name ?? componentId} lên trước`}><ArrowUp className="h-3.5 w-3.5" /></Button>
                          <Button type="button" variant="ghost" size="icon" onClick={() => moveSelectedComponent(componentId, 1)} disabled={index === selected.components.length - 1} aria-label={`Đưa thẻ ${component?.name ?? componentId} xuống sau`}><ArrowDown className="h-3.5 w-3.5" /></Button>
                          <Button type="button" variant="ghost" size="icon" onClick={() => component && startEditComponent(componentId)} aria-label={`Sửa thẻ ${component?.name ?? componentId}`}><Pencil className="h-3.5 w-3.5 text-[#197052]" /></Button>
                          <Button type="button" variant="ghost" size="icon" onClick={() => setPendingComponentRemoval({ moduleId: selected.id, componentId })} aria-label={`Gỡ ${component?.name ?? componentId}`}><Trash2 className="h-3.5 w-3.5 text-[#a45d4a]" /></Button>
                        </div>
                        {editingComponentId === componentId ? <div className="mt-2 grid gap-2 border-t border-[#dcebe0] pt-2 sm:grid-cols-3" data-component-edit-form>
                          <input value={componentDraft.name} onChange={event => setComponentDraft(current => ({ ...current, name: event.target.value }))} aria-label="Tên thẻ đang chỉnh sửa" className="rounded-lg border border-[#d7e4da] bg-white px-2.5 py-2 text-xs" />
                          <input value={componentDraft.location} onChange={event => setComponentDraft(current => ({ ...current, location: event.target.value }))} aria-label="Vị trí thẻ đang chỉnh sửa" className="rounded-lg border border-[#d7e4da] bg-white px-2.5 py-2 text-xs" />
                          <input value={componentDraft.safety} onChange={event => setComponentDraft(current => ({ ...current, safety: event.target.value }))} aria-label="Ghi chú an toàn thẻ đang chỉnh sửa" className="rounded-lg border border-[#d7e4da] bg-white px-2.5 py-2 text-xs" />
                          <div className="flex gap-2 sm:col-span-3"><Button type="button" size="sm" onClick={saveComponentEdit} disabled={!componentDraft.name.trim()} className="bg-[#197052] hover:bg-[#145d44]">Lưu thẻ</Button><Button type="button" size="sm" variant="outline" onClick={() => setEditingComponentId(null)}>Hủy</Button></div>
                        </div> : null}
                      </div>;
                    }) : <span className="text-xs text-[#80958b]">Chưa có thành phần</span>}</div>
                    <div className="mt-3 grid gap-2 sm:grid-cols-[1fr_auto_auto]">
                      <input value={newComponentName} onChange={event => setNewComponentName(event.target.value)} placeholder="Tên thẻ / thành phần mới" aria-label="Tên thành phần mới" className="min-w-0 rounded-xl border border-[#d7e4da] px-3 py-2 text-sm" />
                      <select value={newComponentPosition} onChange={event => setNewComponentPosition(event.target.value)} aria-label="Vị trí chèn thẻ mới" className="rounded-xl border border-[#d7e4da] bg-white px-3 py-2 text-sm"><option value="end">Chèn cuối</option><option value="start">Chèn đầu</option>{selected.components.map(componentId => <option key={componentId} value={componentId}>Chèn trước {components.find(component => component.id === componentId)?.name ?? componentId}</option>)}</select>
                      <Button type="button" size="sm" onClick={addComponentToSelected} disabled={!newComponentName.trim()} className="bg-[#197052] hover:bg-[#145d44]"><Plus className="mr-1 h-4 w-4" /> Thêm thẻ</Button>
                    </div>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
                    <div className="rounded-2xl border border-[#e4ece6] p-4">
                      <p className="text-xs font-bold uppercase tracking-wider text-[#80958b]">
                        Route
                      </p>
                      <p className="mt-2 font-semibold">{selected.route}</p>
                    </div>
                    <div className="rounded-2xl border border-[#e4ece6] p-4">
                      <p className="text-xs font-bold uppercase tracking-wider text-[#80958b]">
                        Thành phần
                      </p>
                      <p className="mt-2 font-semibold">
                        {selected.components.length} component registry
                      </p>
                    </div>
                  </div>
                  <Button
                    className="w-full bg-[#197052] hover:bg-[#145d44]"
                    onClick={() =>
                      toast.info("Cấu hình nâng cao sẽ mở theo quyền admin")
                    }
                  >
                    <SlidersHorizontal className="mr-2 h-4 w-4" /> Chỉnh cấu
                    hình nâng cao
                  </Button>
                </CardContent>
              </Card>
              <Card className="border-[#f1dfb8] bg-[#fffaf0] shadow-sm">
                <CardContent className="flex gap-3 p-5">
                  <Lock className="mt-0.5 h-5 w-5 shrink-0 text-[#b27b17]" />
                  <div>
                    <p className="font-bold text-[#795414]">
                      Nguyên tắc an toàn
                    </p>
                    <p className="mt-1 text-sm leading-6 text-[#806b47]">
                      Ẩn module chỉ thay đổi menu hiển thị. Không xóa hồ sơ,
                      tệp, giao dịch hoặc lịch sử. AI luôn là lớp hỗ trợ và cần
                      người dùng xác nhận.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card className="border-[#dce7df] shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <SlidersHorizontal className="h-5 w-5 text-[#197052]" />{" "}
                Component Registry
              </CardTitle>
              <p className="text-sm text-[#6a7d74]">
                Các thành phần dùng chung và vị trí workflow đã được chuẩn hóa.
              </p>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              {components.map((component, index) => (
                <div
                  key={component.id}
                  className={`rounded-2xl border p-4 ${component.enabled ? "border-[#e4ece6] bg-white" : "border-dashed border-[#d7dfd9] bg-[#f5f7f4] opacity-70"}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <p className="font-bold text-[#174d3e]">{component.name}</p>
                    <Switch
                      checked={component.enabled}
                      onCheckedChange={value =>
                        toggleComponent(component.id, value)
                      }
                      aria-label={`${component.enabled ? "Ẩn" : "Bật"} ${component.name}`}
                    />
                  </div>
                  <p className="mt-2 text-xs font-semibold text-[#197052]">
                    {component.location}
                  </p>
                  <p className="mt-3 flex gap-2 text-sm leading-6 text-[#687b72]">
                    <AlertTriangle className="mt-1 h-4 w-4 shrink-0 text-[#b27b17]" />
                    {component.safety}
                  </p>
                  <div className="mt-4 flex items-center justify-between border-t border-[#edf2ed] pt-3">
                    <span className="text-xs font-semibold text-[#80958b]">
                      Vị trí {index + 1}
                    </span>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        disabled={index === 0}
                        onClick={() => moveComponent(component.id, -1)}
                        aria-label={`Đưa ${component.name} lên trước`}
                      >
                        <ArrowUp className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        disabled={index === components.length - 1}
                        onClick={() => moveComponent(component.id, 1)}
                        aria-label={`Đưa ${component.name} xuống sau`}
                      >
                        <ArrowDown className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-[#dce7df] shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Workflow className="h-5 w-5 text-[#197052]" /> Workflow
                Configuration
              </CardTitle>
              <p className="text-sm text-[#6a7d74]">
                Thứ tự workflow dùng chung cho Tạo nguồn hàng. Ẩn một bước chỉ
                thay đổi hiển thị, không xóa dữ liệu đã nhập.
              </p>
            </CardHeader>
            <CardContent className="space-y-3">
              {workflowSteps.map((step, index) => (
                <div
                  key={step.id}
                  className={`flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-center sm:justify-between ${step.enabled ? "border-[#e4ece6] bg-white" : "border-dashed border-[#d7dfd9] bg-[#f5f7f4] opacity-70"}`}
                >
                  <div className="flex min-w-0 items-start gap-3">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#eaf3ed] text-sm font-bold text-[#197052]">
                      {index + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="font-bold text-[#174d3e]">{step.name}</p>
                        {step.required && (
                          <Badge
                            variant="outline"
                            className="border-[#e1c56a] text-[#967015]"
                          >
                            Bắt buộc
                          </Badge>
                        )}
                      </div>
                      <p className="mt-1 text-sm leading-6 text-[#687b72]">
                        {step.description}
                      </p>
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center justify-between gap-2 sm:justify-end">
                    <Switch
                      checked={step.enabled}
                      disabled={step.required}
                      onCheckedChange={value =>
                        toggleWorkflowStep(step.id, value)
                      }
                      aria-label={`${step.enabled ? "Ẩn" : "Bật"} bước ${step.name}`}
                    />
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        disabled={index === 0}
                        onClick={() => moveWorkflowStep(step.id, -1)}
                        aria-label={`Đưa bước ${step.name} lên trước`}
                      >
                        <ArrowUp className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        disabled={index === workflowSteps.length - 1}
                        onClick={() => moveWorkflowStep(step.id, 1)}
                        aria-label={`Đưa bước ${step.name} xuống sau`}
                      >
                        <ArrowDown className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              <div className="rounded-2xl bg-[#f7f3e7] px-4 py-3 text-sm leading-6 text-[#6e5b29]">
                AI chỉ đề xuất và hỗ trợ điền dữ liệu. Môi giới phải kiểm tra,
                xác nhận và chịu trách nhiệm trước khi chuyển bước hoặc công
                khai bài đăng.
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <AlertDialog
        open={Boolean(pendingRemoval)}
        onOpenChange={open => !open && setPendingRemoval(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Ẩn mô-đun này?</AlertDialogTitle>
            <AlertDialogDescription>
              Bạn sắp ẩn “{pendingRemoval?.name}”. Dữ liệu hồ sơ, tệp, giao dịch
              và lịch sử vẫn được giữ nguyên; chỉ menu hiển thị thay đổi.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Hủy</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (pendingRemoval) toggleModule(pendingRemoval.id, false);
                setPendingRemoval(null);
              }}
            >
              Xác nhận ẩn
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={Boolean(pendingComponentRemoval)} onOpenChange={open => !open && setPendingComponentRemoval(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Gỡ thành phần khỏi module?</AlertDialogTitle>
            <AlertDialogDescription>Thao tác này chỉ gỡ liên kết hiển thị khỏi module đang chọn. Thành phần trong registry và dữ liệu nghiệp vụ vẫn được giữ nguyên.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Hủy</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (pendingComponentRemoval) removeComponentFromSelected(pendingComponentRemoval.componentId); setPendingComponentRemoval(null); }}>Xác nhận gỡ</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
