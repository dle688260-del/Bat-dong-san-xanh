import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

let queryState: { list: { data?: any[]; isLoading: boolean; error: unknown }; areas: { data: any[] } } = {
  list: { data: [], isLoading: false, error: null },
  areas: { data: [] },
};
vi.mock("wouter", () => ({ Link: ({ href, children }: { href: string; children: React.ReactNode }) => React.createElement("a", { href }, children) }));
vi.mock("@/lib/trpc", () => ({
  trpc: { properties: { areas: { useQuery: () => queryState.areas }, list: { useQuery: () => queryState.list } } },
}));

import PropertyCatalog, { getPropertyCardImage } from "./PropertyCatalog";

describe("PropertyCatalog rendered states", () => {
  beforeEach(() => { queryState = { list: { data: [], isLoading: false, error: null }, areas: { data: [] } }; });

  it("renders loading and error messages from query state", () => {
    queryState.list = { data: undefined, isLoading: true, error: null };
    expect(renderToStaticMarkup(React.createElement(PropertyCatalog))).toContain("Đang tìm nguồn hàng");
    queryState.list = { data: undefined, isLoading: false, error: new Error("network") };
    expect(renderToStaticMarkup(React.createElement(PropertyCatalog))).toContain("Chưa thể tải danh sách");
  });

  it("keeps the public entry point focused on published products", () => {
    const html = renderToStaticMarkup(React.createElement(PropertyCatalog));
    expect(html).toContain("Nguồn hàng công khai");
    expect(html).toContain("Công khai");
    expect(html).not.toContain("Dành cho môi giới:");
    expect(html).not.toContain('href="/quan-ly-moi-gioi"');
  });

  it("falls back to the first valid imageUrls entry when imageUrl is missing", () => {
    expect(getPropertyCardImage({ imageUrl: null, imageUrls: ["", "/manus-storage/fallback.jpg"] })).toBe("/manus-storage/fallback.jpg");
    expect(getPropertyCardImage({ imageUrl: null, imageUrls: [] })).toBeNull();
  });

  it("renders empty state and a filtered result card", () => {
    expect(renderToStaticMarkup(React.createElement(PropertyCatalog))).toContain("Không tìm thấy sản phẩm phù hợp");
    queryState.list = { data: [{ id: 1, slug: "nha-thanh-khe", propertyType: "house", title: "Nhà 2 tầng Thanh Khê", price: "7.90", area: "95", bedrooms: 4, location: "Đà Nẵng", areaName: "Thanh Khê", areaProvince: "Đà Nẵng", imageUrl: "/manus-storage/nha-thanh-khe.jpg", imageUrls: ["/manus-storage/nha-thanh-khe.jpg"] }], isLoading: false, error: null };
    const html = renderToStaticMarkup(React.createElement(PropertyCatalog));
    expect(html).toContain("Nhà 2 tầng Thanh Khê");
    expect(html).toContain('/manus-storage/nha-thanh-khe.jpg');
    expect(html).toContain("7,9 tỷ");
    expect(html).toContain("95 m²");
    expect(html).toContain("Thanh Khê, Đà Nẵng");
    expect(html).toContain("/bat-dong-san/nha-thanh-khe");
    expect(html).toContain('href="tel:0989682825"');
    expect(html).toContain('href="https://zalo.me/0989682825"');
    expect(html).toContain('href="https://m.me/"');
    expect(html).toContain('href="https://www.facebook.com/"');
    expect(html).toContain("Xem chi tiết");
  });
});
