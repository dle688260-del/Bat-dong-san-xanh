import { createHash } from "node:crypto";
import type { Request, Response } from "express";
import {
  createLegalSyncRun,
  finishLegalSyncRun,
  listLegalProcedureVersions,
  saveLegalProcedureVersion,
  getLatestLegalSyncRun,
  enqueueLegalScanItems,
  listDueLegalScanItems,
  updateLegalScanItem,
  listLegalProcedures,
  listLegalSources,
  touchLegalSource,
  upsertReferenceLegalTemplate,
  upsertOfficialLegalTemplate,
  ensureLegalProcedureFromRegistry,
  upsertLegalDocument,
  upsertLegalSource,
  materializeLegalProcedureSnapshot,
} from "./db";
import { assembleDvcProcedureBundle, scanDvcProcedureSource } from "./dvcSourceRegistry";
import {   getReferencesForProcedure, LAND_LEGAL_REFERENCE_CATALOG } from "./landLegalReferenceCatalog";
import { downloadOfficialTemplateCandidate, downloadPublicReferenceCandidate } from "./officialTemplateFetcher";
import { getOfficialLandProcedure } from "./officialLandProcedureRegistry";
import { storagePut } from "./storage";
import { sdk } from "./_core/sdk";

function stableHash(value: unknown) {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

const SYNC_RUN_STALE_MS = 10 * 60_000;
const PROCEDURE_SYNC_TIMEOUT_MS = 45_000;

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((_, reject) => {
        timer = setTimeout(() => reject(new Error(`${label}: timeout sau ${Math.round(timeoutMs / 1000)} giây`)), timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function scheduledLegalSyncHandler(req: Request, res: Response) {
  let syncRunId: number | undefined;
  const startedAt = new Date();
  try {
    const user = await sdk.authenticateRequest(req);
    if (!user.isCron || !user.taskUid) {
      return res.status(403).json({ error: "cron-only" });
    }

    const sources = (await listLegalSources()).filter(source => source.active === 1);
    const source = sources.find(item => item.sourceType === "public_service") ?? sources[0];
    if (!source) {
      return res.json({ ok: true, skipped: "no-active-source", taskUid: user.taskUid });
    }

    const latestRun = await getLatestLegalSyncRun();
    if (latestRun?.status === "running") {
      const ageMs = startedAt.getTime() - latestRun.startedAt.getTime();
      if (ageMs < SYNC_RUN_STALE_MS) {
        return res.status(202).json({ ok: true, skipped: "sync-already-running", syncRunId: latestRun.id });
      }
      await finishLegalSyncRun(latestRun.id, {
        status: "failed",
        summary: JSON.stringify({ error: "Đóng run đồng bộ bị treo để tránh khóa các lần chạy sau.", staleAfterMs: SYNC_RUN_STALE_MS }),
        finishedAt: startedAt,
      });
    }

    const run = await createLegalSyncRun({ sourceId: source.id, status: "running", startedAt });
    syncRunId = run.id;
    // listLegalProcedures already merges the persisted catalog with the registry seed.
    // The registry is only a verification seed; it must never hide procedures that
    // were discovered/materialized into legal_procedures.
    const catalogProcedures = await listLegalProcedures();
    const allProcedures = Array.from(new Map(catalogProcedures.map(item => [item.code, item])).values());
    const persistedProcedures = catalogProcedures.filter(item => item.id > 0);
    await enqueueLegalScanItems(allProcedures.map(item => item.code));
    const dueQueueItems = await listDueLegalScanItems(3);
    const dueCodes = new Set(dueQueueItems.map(item => item.procedureCode));
    const procedures = allProcedures.filter(item => dueCodes.has(item.code));
    if (procedures.length === 0) {
      await finishLegalSyncRun(syncRunId, { status: "completed", summary: JSON.stringify({ taskUid: user.taskUid, procedureCount: 0, queued: allProcedures.length, message: "Không có mã đến hạn; hàng đợi sẽ tự thử lại theo nextAttemptAt." }), finishedAt: new Date() });
      return res.json({ ok: true, syncRunId, procedureCount: 0, queued: allProcedures.length, message: "Không có mã đến hạn; hàng đợi sẽ tự thử lại theo nextAttemptAt." });
    }
    const catalogSourceIds = new Map<string, number>();
    for (const candidate of LAND_LEGAL_REFERENCE_CATALOG) {
      const parsed = new URL(candidate.sourceUrl);
      const source = await upsertLegalSource({
        name: candidate.sourceLayer === "government" ? `Nguồn Chính phủ — ${parsed.hostname}` : `Nguồn tham khảo công khai — ${parsed.hostname}`,
        baseUrl: parsed.origin,
        sourceType: candidate.sourceLayer === "government" ? "government" : "other",
        jurisdiction: "national",
        notes: candidate.notes,
      });
      catalogSourceIds.set(candidate.id, source.id);
      if (candidate.kind === "legal_basis") {
        await upsertLegalDocument({
          sourceId: source.id,
          title: candidate.title,
          documentNumber: candidate.documentNumber,
          documentType: "nghi_dinh_dat_dai",
          issuingBody: "Cơ quan nhà nước công bố",
          sourceUrl: candidate.sourceUrl,
          mimeType: candidate.format === "pdf" ? "application/pdf" : "text/html",
          warnings: candidate.notes,
          status: "metadata_only",
        });
      }
    }
    let discoveredCount = 0;
    let changedCount = 0;
    let officialFiles = 0;
    let referenceFiles = 0;
    let pendingFiles = 0;
    const results: Array<{ code: string; status: "changed" | "unchanged" | "not-found" | "failed"; components: number; attachments: number; officialFiles: number; referenceFiles: number; pendingFiles: number; error?: string }> = [];

    const syncOne = async (procedure: (typeof procedures)[number]) => {
      const province = ("defaultProvince" in procedure ? procedure.defaultProvince : undefined) ?? undefined;
      const retryAt = (hours: number) => new Date(Date.now() + hours * 60 * 60 * 1000);
      await updateLegalScanItem(procedure.code, province, { status: "running", attempts: 1, lockedAt: startedAt, lastError: null });
      try {
        const registryProcedure = getOfficialLandProcedure(procedure.code);
        const scan = await scanDvcProcedureSource({ procedureCode: procedure.code, province });
        const bundle = assembleDvcProcedureBundle(scan, procedure.code);
        const dbProcedure = persistedProcedures.find(item => item.code === procedure.code) ?? await ensureLegalProcedureFromRegistry(procedure.code);
                  let persistedReferenceTemplates = 0;
          let downloadedReferenceBinaries = 0;
          let persistedOfficialTemplates = 0;
          if (dbProcedure) {
            for (const official of registryProcedure?.verifiedTemplates ?? []) {
              try {
                const downloaded = await downloadOfficialTemplateCandidate({ candidateUrl: official.sourceUrl, originalFileName: official.name });
                if (downloaded.checksum !== official.checksum) throw new Error("Checksum binary không khớp allowlist Official.");
                const stored = await storagePut(`legal-official/${procedure.code}/${downloaded.checksum}_${downloaded.fileName}`, downloaded.bytes, downloaded.contentType || undefined);
                await upsertOfficialLegalTemplate({ procedureId: dbProcedure.id, sourceId: source.id, name: official.name, documentType: official.documentType, format: official.format, sourceUrl: official.sourceUrl, storageKey: stored.key, fileUrl: stored.url, checksum: downloaded.checksum, notes: official.notes });
                persistedOfficialTemplates += 1;
              } catch {
                // Không hạ cấp Official; file chỉ được ghi khi URL, MIME và checksum khớp allowlist.
              }
            }

          const catalogAliases = registryProcedure?.aliases ?? (typeof procedure.aliases === "string" ? JSON.parse(procedure.aliases || "[]") as string[] : []);
          const catalogReferences = getReferencesForProcedure({ code: procedure.code, name: procedure.name, aliases: catalogAliases }).filter(item => item.kind === "reference_template");
          for (const reference of [...(registryProcedure?.referenceTemplates ?? []), ...catalogReferences]) {
            let storageKey: string | undefined;
            let fileUrl: string | undefined;
            let checksum: string | undefined;
            const referenceName = "title" in reference ? reference.title : reference.name;
            if (/\.(?:docx?|pdf)(?:\?|$)/i.test(reference.sourceUrl)) {
              try {
                const downloaded = await downloadPublicReferenceCandidate({ candidateUrl: reference.sourceUrl, originalFileName: referenceName });
                if (downloaded.signatureOk && (downloaded.extension === "doc" || downloaded.extension === "docx" || downloaded.extension === "pdf")) {
                  const stored = await storagePut(`legal-reference/${procedure.code}/${downloaded.checksum}_${downloaded.fileName}`, downloaded.bytes, downloaded.contentType || undefined);
                  storageKey = stored.key;
                  fileUrl = stored.url;
                  checksum = downloaded.checksum;
                  downloadedReferenceBinaries += 1;
                }
              } catch {
                // Luôn lưu metadata để kho hiển thị Reference cần bổ sung, không nâng Official.
              }
            }
            const catalogCandidate = "id" in reference ? reference : undefined;
            const templateSourceId = catalogCandidate ? catalogSourceIds.get(catalogCandidate.id) ?? source.id : source.id;
            const referenceFormat = reference.format === "html" ? "pdf" : reference.format;
            const referenceDocumentType = catalogCandidate ? "catalog_reference_template" : ("documentType" in reference ? reference.documentType : "reference_template");
            await upsertReferenceLegalTemplate({ procedureId: dbProcedure.id, sourceId: templateSourceId, name: referenceName, documentType: referenceDocumentType, format: referenceFormat, sourceUrl: reference.sourceUrl, storageKey, fileUrl, checksum, notes: storageKey ? "Bản tham khảo đã tải và kiểm tra chữ ký tệp; chưa đủ điều kiện Official." : "Bản tham khảo metadata-only; chưa tải được binary từ URL công bố." });
            persistedReferenceTemplates += 1;
          }
          for (const attachment of bundle.referenceTemplates) {
            const format = attachment.kind === "docx" || attachment.kind === "pdf" ? attachment.kind : undefined;
            if (!format) continue;
            await upsertReferenceLegalTemplate({ procedureId: dbProcedure.id, sourceId: source.id, name: attachment.name, documentType: "dvc_reference_attachment", format, sourceUrl: attachment.url || attachment.sourceUrl, storageKey: attachment.storageKey, fileUrl: attachment.fileUrl, checksum: attachment.checksum, notes: attachment.storageKey ? "Bản tham khảo đã được discovery tải và kiểm tra; chưa đủ điều kiện Official." : "Bản tham khảo từ discovery; chưa có binary lưu trong S3." });
            persistedReferenceTemplates += 1;
          }
        }
        const components = scan.dossierComponents.length;
        const attachments = scan.attachments.length;
        const verified = bundle.allAttachments.filter(item => item.status === "verified_binary").length;
        const references = bundle.allAttachments.filter(item => item.status === "matched_reference").length;
        const pending = bundle.allAttachments.filter(item => item.status === "pending" || item.status === "failed").length;
        discoveredCount += components + attachments;
        officialFiles += verified;
        referenceFiles += references;
        pendingFiles += pending;
        if (!scan.fetched && !components && !attachments) {
          await updateLegalScanItem(procedure.code, province, { status: "pending", nextAttemptAt: retryAt(6), lastHttpStatus: scan.warnings.some(item => /503/.test(item)) ? 503 : null, lastSourceUrl: scan.sourceUrl ?? null, lastError: scan.warnings.join("; ") || "Chưa nhận được snapshot từ nguồn DVC." , lockedAt: null });
          return { code: procedure.code, status: "not-found" as const, components, attachments, officialFiles: verified, referenceFiles: references, pendingFiles: pending };
        }
        await updateLegalScanItem(procedure.code, province, { status: pending > 0 ? "pending" : "succeeded", nextAttemptAt: pending > 0 ? retryAt(6) : null, lastHttpStatus: scan.warnings.some(item => /503/.test(item)) ? 503 : null, lastSourceUrl: scan.sourceUrl ?? null, lastError: scan.warnings.join("; ") || null, lockedAt: null, completedAt: pending > 0 ? null : new Date() });

        if (!dbProcedure) return { code: procedure.code, status: "changed" as const, components, attachments, officialFiles: verified + persistedOfficialTemplates, referenceFiles: references + persistedReferenceTemplates, pendingFiles: pending, downloadedReferenceBinaries };
        const workflowJson = JSON.stringify({ procedureCode: procedure.code, sourceUrl: scan.sourceUrl, checkedAt: scan.checkedAt, receivingSection: scan.receivingSection, processingSection: scan.processingSection });
        const requirementsJson = JSON.stringify({ dossierComponents: scan.dossierComponents, attachments: scan.attachments, warnings: scan.warnings, bundle });
        const sourceHash = stableHash({ workflowJson, requirementsJson });
        // Snapshot chỉ là lịch sử; module production đọc requirements/workflow trực tiếp.
        // Materialize cả khi sourceHash không đổi để tự phục hồi các DB đã từng thiếu rows.
        await materializeLegalProcedureSnapshot({
          procedureId: dbProcedure.id,
          workflow: { procedureCode: procedure.code, sourceUrl: scan.sourceUrl, checkedAt: scan.checkedAt, steps: scan.procedureSteps, receivingSection: scan.receivingSection, processingSection: scan.processingSection },
          dossierComponents: scan.dossierComponents,
          sourceDocumentId: null,
        });
        const previous = await listLegalProcedureVersions(dbProcedure.id);
        if (previous[0]?.sourceHash === sourceHash) return { code: procedure.code, status: "unchanged" as const, components, attachments, officialFiles: verified + persistedOfficialTemplates, referenceFiles: references + persistedReferenceTemplates, pendingFiles: pending, downloadedReferenceBinaries };
        await saveLegalProcedureVersion({ procedureId: dbProcedure.id, sourceUrl: scan.sourceUrl, sourceHash, workflowJson, requirementsJson, status: "discovered" });
        changedCount += 1;
        return { code: procedure.code, status: "changed" as const, components, attachments, officialFiles: verified + persistedOfficialTemplates, referenceFiles: references + persistedReferenceTemplates, pendingFiles: pending, downloadedReferenceBinaries };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        await updateLegalScanItem(procedure.code, province, { status: "failed", nextAttemptAt: retryAt(/503/.test(message) ? 6 : 24), lastHttpStatus: /503/.test(message) ? 503 : null, lastError: message, lockedAt: null });
        return { code: procedure.code, status: "failed" as const, components: 0, attachments: 0, officialFiles: 0, referenceFiles: 0, pendingFiles: 0, error: message };
      }
    };
    for (let offset = 0; offset < procedures.length; offset += 3) {
      results.push(...await Promise.all(procedures.slice(offset, offset + 3).map(procedure => withTimeout(syncOne(procedure), PROCEDURE_SYNC_TIMEOUT_MS, `Đồng bộ ${procedure.code}`).catch(error => ({ code: procedure.code, status: "failed" as const, components: 0, attachments: 0, officialFiles: 0, referenceFiles: 0, pendingFiles: 0, error: error instanceof Error ? error.message : String(error) })) )));
    }

    await touchLegalSource(source.id, new Date());
    await finishLegalSyncRun(syncRunId, {
      status: "completed",
      discoveredCount,
      changedCount,
      summary: JSON.stringify({ taskUid: user.taskUid, sourceId: source.id, procedureCount: procedures.length, officialFiles, referenceFiles, pendingFiles, results }),
      finishedAt: new Date(),
    });
    return res.json({ ok: true, syncRunId, sourceId: source.id, procedureCount: procedures.length, queuedProcedureCount: allProcedures.length, discoveredCount, changedCount, officialFiles, referenceFiles, pendingFiles, results });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (syncRunId !== undefined) {
      try {
        await finishLegalSyncRun(syncRunId, { status: "failed", summary: JSON.stringify({ error: message }), finishedAt: new Date() });
      } catch (finishError) {
        console.error("[LegalSync] Failed to persist failed run", finishError);
      }
    }
    console.error("[LegalSync] Scheduled sync failed", error);
    const statusCode = typeof error === "object" && error !== null && "statusCode" in error && typeof error.statusCode === "number" ? error.statusCode : 500;
    if (statusCode >= 400 && statusCode < 500) {
      return res.status(statusCode).json({ error: message, context: { url: req.originalUrl, taskUid: "cron" }, timestamp: new Date().toISOString() });
    }
    return res.status(500).json({ error: message, context: { url: req.originalUrl, taskUid: "cron" }, timestamp: new Date().toISOString() });
  }
}
