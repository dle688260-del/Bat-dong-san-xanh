# Audit nguồn DVC Quốc gia — 2026-08-24

## Nguồn đã mở
- Cổng DVC Quốc gia, thủ tục “Cung cấp thông tin, dữ liệu đất đai”: https://vpcp.dichvucong.gov.vn/p/home/dvc-chi-tiet-thu-tuc-hanh-chinh.html?ma_thu_tuc=1.012789
- Trang chi tiết mà cổng liên kết: `ma_thu_tuc=348167`.

## Quan sát
Trang HTML tải được phần mô tả thủ tục, các bước xử lý, cơ quan tiếp nhận và bảng hình thức nộp trực tiếp/trực tuyến. Trang vẫn có nút Đăng nhập/Đăng ký DVC Quốc gia và nội dung động “Đang xử lý...”; việc hiển thị chi tiết thành phần hoặc liên kết binary có thể phụ thuộc dữ liệu động và trạng thái upstream.

## Kết luận kỹ thuật
Có thể dùng URL thủ tục cấp Quốc gia làm `sourceUrl`/provenance để discovery metadata. Không được coi riêng HTML trang thủ tục là binary Official. Chỉ thêm attachment Official khi tải được tệp từ URL cơ quan, xác định đúng procedure/component, kiểm tra format và SHA-256; lỗi 503, trang rỗng hoặc URL không có tệp phải giữ Pending/Reference.
