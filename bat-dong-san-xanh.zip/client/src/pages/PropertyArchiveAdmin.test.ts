import { describe, expect, it } from "vitest";
import {
  ARCHIVE_CATEGORIES,
  archiveAccept,
  archiveAllFeatures,
  archiveCanDelete,
  archiveCanPreview,
  archiveCanUploadFile,
  archiveCategoryLabel,
  archiveFolderName,
  archiveMaxFileSize,
  archivePreviewKind,
  archiveSearchMatches,
  archiveStoragePath,
} from "./PropertyArchiveAdmin";

describe("PropertyArchiveAdmin archive contract", () => {
  it("exposes the five Vietnamese document groups", () => {
    expect(ARCHIVE_CATEGORIES.map(([, label]) => label)).toEqual([
      "Hồ sơ bất động sản",
      "Pháp lý",
      "Định giá & thị trường",
      "Marketing",
      "Giao dịch",
    ]);
    expect(archiveCategoryLabel("legal")).toBe("Pháp lý");
  });

  it("keeps each property in its own storage folder", () => {
    expect(archiveFolderName("BDS-001", "Nhà Thanh Khê – 95m²")).toBe("BDS-001 – Nhà Thanh Khê – 95m²");
    expect(archiveStoragePath(1, "legal", "so-hong.pdf")).toBe("property-archives/1/legal/so-hong.pdf");
  });

  it("supports search, preview and safe upload constraints", () => {
    expect(archiveSearchMatches("so-hong.pdf", "Hồ sơ pháp lý", "pháp lý")).toBe(true);
    expect(archivePreviewKind("image/jpeg")).toBe("image");
    expect(archiveCanPreview("application/pdf")).toBe(true);
    expect(archiveCanPreview("application/msword")).toBe(false);
    expect(archiveCanUploadFile({ size: archiveMaxFileSize(), type: "application/pdf" })).toBe(true);
    expect(archiveCanUploadFile({ size: archiveMaxFileSize() + 1, type: "application/pdf" })).toBe(false);
    expect(archiveAccept()).toContain(".pdf");
  });

  it("keeps destructive archive actions admin-only", () => {
    expect(archiveCanDelete(true)).toBe(true);
    expect(archiveCanDelete(false)).toBe(false);
    expect(archiveAllFeatures()).toEqual({ search: true, filter: true, preview: true, upload: true, download: true, rename: true, delete: true });
  });
});

export {};
