import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("AI dossier workspace module management contract", () => {
  const page = readFileSync(
    new URL("../client/src/pages/AIDossierAdmin.tsx", import.meta.url),
    "utf8"
  );

  it("keeps the procedure and legal source module mandatory", () => {
    expect(page).toContain('id: "procedure"');
    expect(page).toContain("removable: false");
    expect(page).toContain("Thủ tục và nguồn pháp lý là mô-đun bắt buộc");
  });

  it("offers a shared module manager with confirmation before hiding a module", () => {
    expect(page).toContain("Quản lý mô-đun hồ sơ");
    expect(page).toContain("Xóa mô-đun thừa");
    expect(page).toContain("AlertDialog");
    expect(page).toContain("pendingModuleId");
    expect(page).toContain("removeWorkspaceModule");
    expect(page).toContain("Hủy, giữ lại");
    expect(page).toContain("Xác nhận ẩn mô-đun");
    expect(page).toContain("Tài liệu gốc");
    expect(page).toContain("nguồn pháp lý và hồ sơ đã lưu không bị xóa");
  });

  it("persists hidden modules with the local draft and provides restore", () => {
    expect(page).toContain("hiddenModuleIds");
    expect(page).toContain("hiddenModuleIdSet");
    expect(page).toContain("Khôi phục tất cả mô-đun");
    expect(page).toContain("aiDossierRemoveModuleIds");
  });

  it("does not mutate the hidden set before explicit confirmation", () => {
    expect(page).toContain("setPendingModuleId(moduleId)");
    expect(page).toContain("confirmRemoveWorkspaceModule");
    expect(page).toContain("onClick={confirmRemoveWorkspaceModule}");
  });

  it("only allows removable module ids to be added to the hidden set", () => {
    expect(page).toContain("aiDossierRemovableModuleIds");
    expect(page).toContain(
      "if (!aiDossierRemovableModuleIds().includes(moduleId))"
    );
    expect(page).toContain('hiddenModuleIdSet.has("profile")');
    expect(page).toContain('hiddenModuleIdSet.has("documents")');
    expect(page).toContain('hiddenModuleIdSet.has("analysis")');
    expect(page).toContain('hiddenModuleIdSet.has("review")');
  });
});

// Contract-only coverage: module removal is draft UI state and must not delete
// source documents, legal catalog rows, properties, or saved dossier records.
