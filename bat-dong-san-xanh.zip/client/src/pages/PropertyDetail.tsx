import { useState, type FormEvent, type ReactNode } from "react";
import { Link, useRoute } from "wouter";
import {
  ArrowLeft,
  CalendarDays,
  Check,
  ChevronLeft,
  ChevronRight,
  Heart,
  MapPin,
  MessageCircle,
  Phone,
  Map,
  ExternalLink,
  Ruler,
  Share2,
  Sparkles,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";
import { getListingDisplayTitle, LISTING_KIND_LABELS } from "@/lib/propertyListingRegistry";
import { PropertyPostingTemplate, readGalleryLayout } from "@/components/PropertyPostingTemplate";

const typeLabels = LISTING_KIND_LABELS;
const PHONE_DISPLAY = "0989 682 825";
const PHONE_DIGITS = "0989682825";
const money = (value: string | number) => `${new Intl.NumberFormat("vi-VN").format(Number(value))} tỷ`;
const moneyPerM2 = (price: string | number, area: string | number) => {
  const total = Number(price);
  const sqm = Number(area);
  return total > 0 && sqm > 0 ? `${new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 }).format((total * 1000) / sqm)} triệu/m²` : "Đang cập nhật";
};
const coordinate = (value: unknown) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};
const valueOr = (value: unknown, fallback = "Đang cập nhật") => value ? String(value) : fallback;

export function getPropertyCtaLinks(title: string, shareUrl: string) {
  return {
    phone: `tel:${PHONE_DIGITS}`,
    phoneDisplay: PHONE_DISPLAY,
    zalo: `https://zalo.me/${PHONE_DIGITS}`,
    messenger: "https://m.me/",
    viewing: `/?interest=${encodeURIComponent(title)}#lien-he`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
  };
}

export function buildPropertyBookingPayload(input: { title: string; name: string; phone: string; date: string; time: string; message: string }) {
  const schedule = [input.date, input.time].filter(Boolean).join(" lúc ");
  return {
    interest: `Đặt lịch xem: ${input.title}`,
    name: input.name,
    phone: input.phone,
    message: `${schedule ? `Thời gian mong muốn: ${schedule}. ` : ""}${input.message || "Khách muốn được tư vấn và sắp xếp lịch xem bất động sản."}`,
  };
}

export default function PropertyDetail() {
  const [, params] = useRoute("/bat-dong-san/:slug");
  const { data, isLoading } = trpc.properties.detail.useQuery(
    { slug: params?.slug ?? "" },
    { enabled: Boolean(params?.slug) },
  );
  const [activeImage, setActiveImage] = useState(0);
  const [liked, setLiked] = useState(false);
  const [showPhone, setShowPhone] = useState(false);
  const [showBooking, setShowBooking] = useState(false);
  const [bookingSent, setBookingSent] = useState(false);
  const [bookingName, setBookingName] = useState("");
  const [bookingPhone, setBookingPhone] = useState("");
  const [bookingDate, setBookingDate] = useState("");
  const [bookingTime, setBookingTime] = useState("");
  const [bookingMessage, setBookingMessage] = useState("");
  const createConsultation = trpc.consultations.create.useMutation({
    onSuccess: () => {
      setBookingSent(true);
      setBookingName("");
      setBookingPhone("");
      setBookingDate("");
      setBookingTime("");
      setBookingMessage("");
    },
  });

  if (isLoading) return <div className="flex min-h-screen items-center justify-center bg-[#F7F5EC] text-[#60766D]">Đang tải thông tin...</div>;
  if (!data) return <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#F7F5EC] px-6 text-center text-[#173F35]"><h1 className="font-serif text-4xl">Không tìm thấy bất động sản</h1><Link href="/bat-dong-san" className="font-bold text-[#1F6B55]">Quay lại danh mục</Link></div>;

  const { property, images } = data;
  const shareUrl = typeof window !== "undefined" ? window.location.href : "";
  const ctaLinks = getPropertyCtaLinks(property.title, shareUrl);
  const imageList = images ?? [];
  const safeActiveImage = imageList.length ? Math.min(activeImage, imageList.length - 1) : 0;
  const activeImageUrl = imageList[safeActiveImage]?.url;
  const typeLabel = typeLabels[property.propertyType];
  const displayTitle = getListingDisplayTitle({ transaction: property.listingType === "rent" ? "rent" : "sale", propertyType: property.propertyType, area: String(property.area || ""), frontage: String((property as Record<string, unknown>).frontage || ""), depth: String((property as Record<string, unknown>).depth || "") });
  const latitude = coordinate(property.latitude);
  const longitude = coordinate(property.longitude);
  const dimensions = (property as Record<string, unknown>).frontage && (property as Record<string, unknown>).depth ? `${(property as Record<string, unknown>).frontage} × ${(property as Record<string, unknown>).depth} m` : "Đang cập nhật";
  const quick: Array<[string, string, typeof Ruler]> = [
    ["Diện tích", `${property.area} m²`, Ruler],
    ["Đơn giá", moneyPerM2(property.price, property.area), Ruler],
    ["Kích thước", dimensions, Ruler],
    ["Phòng ngủ", valueOr(property.bedrooms), Ruler],
    ["Số WC", valueOr(property.bathrooms), Ruler],
    ["Hướng", valueOr(property.orientation), MapPin],
  ];

  const copyShareLink = async () => {
    if (typeof navigator !== "undefined" && navigator.clipboard && shareUrl) {
      await navigator.clipboard.writeText(shareUrl);
    }
  };
  const revealPhone = () => setShowPhone(true);
  const openBooking = () => {
    setBookingSent(false);
    setShowBooking(true);
  };
  const submitBooking = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    createConsultation.mutate(buildPropertyBookingPayload({ title: property.title, name: bookingName, phone: bookingPhone, date: bookingDate, time: bookingTime, message: bookingMessage }));
  };

  return (
    <main className="min-h-screen bg-[#F7F5EC] pb-24 text-[#173F35]">
      <header className="sticky top-0 z-30 border-b border-[#173F35]/10 bg-[#F7F5EC]/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1240px] items-center justify-between gap-3 px-4 sm:px-6 lg:px-10">
          <Link href="/bat-dong-san" className="inline-flex min-w-0 items-center gap-2 text-sm font-bold text-[#173F35]">
            <ArrowLeft size={18} />
            <span className="truncate">Danh sách sản phẩm</span>
          </Link>
          <div className="flex shrink-0 items-center gap-2">
            <button type="button" onClick={() => setLiked(value => !value)} aria-label={liked ? "Bỏ yêu thích" : "Thêm yêu thích"} className={`grid h-10 w-10 place-items-center rounded-full border ${liked ? "border-[#B86B35] bg-[#B86B35]/10 text-[#B86B35]" : "border-[#173F35]/15 bg-white text-[#173F35]"}`}>
              <Heart size={18} fill={liked ? "currentColor" : "none"} />
            </button>
            <button type="button" onClick={copyShareLink} aria-label="Sao chép liên kết" className="grid h-10 w-10 place-items-center rounded-full border border-[#173F35]/15 bg-white text-[#173F35]">
              <Share2 size={17} />
            </button>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-[1240px] px-4 pt-5 sm:px-6 lg:px-10 lg:pt-8">
        <PropertyPostingTemplate title={property.title} location={property.location} typeLabel={typeLabel} price={money(property.price)} pricePerM2={moneyPerM2(property.price, property.area)} area={String(property.area)} frontage={String((property as Record<string, unknown>).frontage || "")} depth={String((property as Record<string, unknown>).depth || "")} orientation={String(property.orientation || "")} roadWidth={String(property.distanceToMainRoad || "")} bedrooms={valueOr(property.bedrooms)} bathrooms={valueOr(property.bathrooms)} legalItems={[property.legalStatus ? `Pháp lý: ${property.legalStatus}` : "", property.planningStatus ? `Quy hoạch: ${property.planningStatus}` : "", (property as Record<string, unknown>).loanSupport ? `Vay vốn: ${String((property as Record<string, unknown>).loanSupport)}` : ""].filter(Boolean)} images={imageList.map(image => image.url)} galleryLayout={readGalleryLayout((property as Record<string, unknown>).listingDetails)} latitude={latitude} longitude={longitude} detailHref={shareUrl} phone={ctaLinks.phone} zalo={ctaLinks.zalo} />

        <div className="mt-5 grid gap-3 rounded-2xl border border-[#B8D4C6] bg-[#F4FAF6] p-3 sm:grid-cols-[1fr_220px]"><div className="min-w-0"><p className="text-xs font-bold uppercase tracking-[.16em] text-[#1F6B55]">Vị trí</p><p className="mt-1 flex items-start gap-2 text-sm leading-6 text-[#486058]"><MapPin className="mt-1 shrink-0 text-[#B86B35]" size={16} />{property.location}</p></div><div className="relative overflow-hidden rounded-xl bg-[#DCEBE2]"><div className="h-32 w-full">{latitude !== null && longitude !== null ? <MapView className="h-32 w-full" initialCenter={{ lat: latitude, lng: longitude }} initialZoom={15} onMapReady={map => { new window.google!.maps.Marker({ map, position: { lat: latitude, lng: longitude }, title: property.title }); }} /> : <div className="grid h-full place-items-center p-3 text-center text-xs text-[#60766D]"><Map size={20} className="mx-auto text-[#1F6B55]" /><span className="mt-1 block">Bản đồ đang cập nhật</span></div>}</div><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(property.location)}`} target="_blank" rel="noreferrer" className="absolute bottom-2 right-2 inline-flex items-center gap-1 rounded-full bg-white/95 px-2 py-1 text-[10px] font-bold text-[#1F6B55] shadow-sm">Mở bản đồ <ExternalLink size={11} /></a></div></div><div className="mt-6 grid gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(320px,.8fr)]">
          <InfoSection title="Mô tả bất động sản"><p className="whitespace-pre-line leading-7 text-[#486058]">{property.description || "Thông tin mô tả đang được cập nhật. Vui lòng liên hệ chuyên viên để nhận tư vấn chi tiết."}</p></InfoSection>
          <InfoSection title="Vị trí & tiện ích"><InfoRows rows={[["Địa chỉ/khu vực", property.location], ["Đường lớn", property.distanceToMainRoad], ["Trường học", property.nearbySchools], ["Chợ", property.nearbyMarket], ["Bệnh viện", property.nearbyHospital], ["Trung tâm thành phố", property.distanceToCenter]]} /></InfoSection>
          <InfoSection title="Pháp lý"><InfoRows rows={[["Loại giấy chứng nhận", property.certificateType || property.legalStatus], ["Diện tích trên giấy", property.certificateArea ? `${property.certificateArea} m²` : null], ["Mục đích sử dụng đất", property.landUsePurpose], ["Tình trạng quy hoạch", property.planningStatus], ["Tình trạng thế chấp", property.mortgageStatus], ["Nguồn xác nhận", property.legalSource || "Theo hồ sơ/chủ nhà cung cấp"]]} /></InfoSection>
          <InfoSection title="Giá & điều kiện giao dịch"><InfoRows rows={[["Giá bán", money(property.price)], ["Thương lượng", property.negotiable ? "Có" : "Không"], ["Hoa hồng môi giới", property.brokerageFee], ["Điều kiện đặt cọc", property.depositTerms], ["Điều kiện giao dịch", property.transactionTerms]]} /></InfoSection>
        </div>

        <section className="mt-6 rounded-2xl bg-[#173F35] p-5 text-white sm:p-7"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#D9B45B]">Người đăng sản phẩm</p><h2 className="mt-2 font-serif text-2xl">{property.brokerName || "Bất động sản xanh"}</h2><p className="mt-1 text-sm text-white/70">{property.brokerPhone || "0989 682 825"} · Hỗ trợ tư vấn sản phẩm</p></div><a href={ctaLinks.phone} onClick={revealPhone} title={`Gọi ${ctaLinks.phoneDisplay}`} aria-label={`Gọi ${ctaLinks.phoneDisplay}`} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#D9B45B] px-5 py-3 text-sm font-bold text-[#173F35]"><Phone size={16} /> {showPhone ? ctaLinks.phoneDisplay : "Liên hệ ngay"}</a></div></section>
      </section>

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-[#173F35]/10 bg-white/95 p-3 shadow-[0_-10px_30px_rgba(24,53,45,.12)] backdrop-blur sm:hidden"><div className="mx-auto grid max-w-md grid-cols-4 gap-1.5"><a href={ctaLinks.phone} onClick={revealPhone} title={`Gọi ${ctaLinks.phoneDisplay}`} aria-label={`Gọi ${ctaLinks.phoneDisplay}`} className="inline-flex min-w-0 items-center justify-center gap-1 rounded-xl bg-[#1F6B55] px-1 py-3 text-[11px] font-bold text-white"><Phone size={14} /> <span className="truncate">{showPhone ? ctaLinks.phoneDisplay : "Gọi"}</span></a><a href={ctaLinks.zalo} target="_blank" rel="noreferrer" className="inline-flex min-w-0 items-center justify-center gap-1 rounded-xl border border-[#1F6B55]/25 px-1 py-3 text-[11px] font-bold text-[#1F6B55]"><span className="font-black">Z</span> Zalo</a><a href={ctaLinks.messenger} target="_blank" rel="noreferrer" aria-label="Nhắn Messenger" className="inline-flex min-w-0 items-center justify-center gap-1 rounded-xl border border-[#6C63FF]/25 px-1 py-3 text-[11px] font-bold text-[#5148D8]"><MessageCircle size={14} /> <span className="truncate">Messenger</span></a><button type="button" onClick={openBooking} className="inline-flex min-w-0 items-center justify-center gap-1 rounded-xl border border-[#173F35]/15 px-1 py-3 text-[11px] font-bold text-[#173F35]"><CalendarDays size={14} /> <span className="truncate">Đặt lịch</span></button><a href={ctaLinks.facebook} target="_blank" rel="noreferrer" className="inline-flex min-w-0 items-center justify-center gap-1 rounded-xl border border-[#1877F2]/25 px-1 py-3 text-[11px] font-bold text-[#1877F2]"><Share2 size={14} /> <span className="truncate">Facebook</span></a></div></div>
      {showBooking && <div className="fixed inset-0 z-50 grid place-items-center bg-[#173F35]/55 p-4" role="dialog" aria-modal="true" aria-labelledby="booking-title"><div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-[#FFFDF7] p-5 shadow-2xl sm:p-7"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#A27A26]">Yêu cầu tư vấn</p><h2 id="booking-title" className="mt-2 font-serif text-3xl text-[#173F35]">Đặt lịch xem bất động sản</h2><p className="mt-2 text-sm leading-6 text-[#60766D]">{property.title}</p></div><button type="button" onClick={() => setShowBooking(false)} aria-label="Đóng biểu mẫu đặt lịch" className="rounded-full border border-[#173F35]/15 px-3 py-1 text-xl text-[#173F35]">×</button></div>{bookingSent ? <div className="mt-6 rounded-xl bg-[#EAF5EE] p-5 text-center"><Check className="mx-auto text-[#1F6B55]" size={28} /><h3 className="mt-3 text-lg font-bold text-[#173F35]">Đã gửi yêu cầu đặt lịch</h3><p className="mt-2 text-sm leading-6 text-[#60766D]">Chuyên viên sẽ liên hệ để xác nhận thời gian xem phù hợp.</p><button type="button" onClick={() => setShowBooking(false)} className="mt-4 rounded-xl bg-[#1F6B55] px-4 py-3 text-sm font-bold text-white">Đóng</button></div> : <form onSubmit={submitBooking} className="mt-5 space-y-3"><label className="block text-sm font-semibold text-[#173F35]">Họ và tên<input required minLength={2} maxLength={120} value={bookingName} onChange={event => setBookingName(event.target.value)} className="mt-1 w-full rounded-xl border border-[#173F35]/15 bg-white px-3 py-3 font-normal outline-none focus:ring-2 focus:ring-[#D9B45B]" placeholder="Nguyễn Văn A" /></label><label className="block text-sm font-semibold text-[#173F35]">Số điện thoại<input required minLength={8} maxLength={30} value={bookingPhone} onChange={event => setBookingPhone(event.target.value)} className="mt-1 w-full rounded-xl border border-[#173F35]/15 bg-white px-3 py-3 font-normal outline-none focus:ring-2 focus:ring-[#D9B45B]" placeholder="0989 682 825" /></label><div className="grid gap-3 sm:grid-cols-2"><label className="block text-sm font-semibold text-[#173F35]">Ngày mong muốn<input type="date" value={bookingDate} onChange={event => setBookingDate(event.target.value)} className="mt-1 w-full rounded-xl border border-[#173F35]/15 bg-white px-3 py-3 font-normal outline-none focus:ring-2 focus:ring-[#D9B45B]" /></label><label className="block text-sm font-semibold text-[#173F35]">Giờ mong muốn<input type="time" value={bookingTime} onChange={event => setBookingTime(event.target.value)} className="mt-1 w-full rounded-xl border border-[#173F35]/15 bg-white px-3 py-3 font-normal outline-none focus:ring-2 focus:ring-[#D9B45B]" /></label></div><label className="block text-sm font-semibold text-[#173F35]">Lời nhắn<textarea maxLength={2000} value={bookingMessage} onChange={event => setBookingMessage(event.target.value)} className="mt-1 min-h-24 w-full rounded-xl border border-[#173F35]/15 bg-white px-3 py-3 font-normal outline-none focus:ring-2 focus:ring-[#D9B45B]" placeholder="Ví dụ: Tôi muốn xem vào cuối tuần…" /></label><button type="submit" disabled={createConsultation.isPending} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-[#1F6B55] px-4 py-3 text-sm font-bold text-white disabled:opacity-60"><CalendarDays size={16} />{createConsultation.isPending ? "Đang gửi yêu cầu…" : "Gửi yêu cầu đặt lịch"}</button>{createConsultation.error && <p className="text-sm font-semibold text-[#B42318]">{createConsultation.error.message}</p>}</form>}</div></div>}
    </main>
  );
}

function InfoSection({ title, children }: { title: string; children: ReactNode }) { return <section className="rounded-2xl bg-white p-5 shadow-[0_8px_24px_rgba(24,53,45,.05)] sm:p-6"><h2 className="font-serif text-2xl sm:text-3xl">{title}</h2><div className="mt-4">{children}</div></section>; }
function InfoRows({ rows }: { rows: Array<[string, unknown]> }) { return <dl className="space-y-3">{rows.map(([label, value]) => <div key={label} className="grid grid-cols-[42%_58%] gap-2 border-b border-[#173F35]/10 pb-3 text-sm"><dt className="text-[#60766D]">{label}</dt><dd className="font-semibold">{value ? String(value) : "Đang cập nhật"}</dd></div>)}</dl>; }
