import fs from "node:fs";

const dbPath = "server/db.ts";
const routerPath = "server/routers.ts";
let db = fs.readFileSync(dbPath, "utf8");
const helper = `export async function ensureDealForSoldProperty(propertyId: number, assignedTo: number) { const db = await getDb(); if (!db) throw new Error("Database is not available"); const property = (await db.select({ id: properties.id, propertyCode: properties.propertyCode, title: properties.title, price: properties.price, location: properties.location, ownerName: properties.ownerName }).from(properties).where(and(eq(properties.id, propertyId), eq(properties.status, "sold"))).limit(1))[0]; if (!property) return { success: false, reason: "not_sold" } as const; const existing = (await db.select({ id: deals.id, transactionCode: deals.transactionCode, stage: deals.stage }).from(deals).where(and(eq(deals.propertyId, propertyId), ne(deals.stage, "cancelled"))).orderBy(desc(deals.updatedAt)).limit(1))[0]; if (existing) return { success: true, created: false, dealId: existing.id, transactionCode: existing.transactionCode, stage: existing.stage } as const; const result = await db.insert(deals).values({ propertyId, assignedTo, stage: "new", agreedPrice: property.price, ownerId: null, notes: "Tự động nhận từ BĐS đã bán trong phần bán hàng." }); const dealId = Number(result[0].insertId); const transactionCode = "GD-" + new Date().getFullYear() + "-" + String(dealId).padStart(5, "0"); await db.update(deals).set({ transactionCode }).where(eq(deals.id, dealId)); return { success: true, created: true, dealId, transactionCode, stage: "new" as const, propertyCode: property.propertyCode, title: property.title, location: property.location, ownerName: property.ownerName } as const; }`;
if (!db.includes("export async function ensureDealForSoldProperty")) {
  const marker = "export async function listSoldPropertiesForTransaction";
  if (!db.includes(marker)) throw new Error("sold property helper marker not found");
  db = db.replace(marker, helper + "\n" + marker);
  fs.writeFileSync(dbPath, db);
}
let router = fs.readFileSync(routerPath, "utf8");
if (!router.includes("ensureDealForSoldProperty")) {
  router = router.replace("updatePropertyStatus, listPropertyDossiers", "updatePropertyStatus, ensureDealForSoldProperty, listPropertyDossiers");
  const pattern = /if \(input\.status === "sold"\) \{ const dossier = await ensurePropertyDossier\(\{ propertyId: input\.id, createdBy: ctx\.user\.id \}\); return \{ \.\.\.result, sold: true as const, dossierId: dossier\.id, dossierCreated: dossier\.created, productionStatus: dossier\.created \? "queued" as const : "ready_for_production" as const \}; \}/;
  if (!pattern.test(router)) throw new Error("sold updateStatus block not found");
  router = router.replace(pattern, 'if (input.status === "sold") { const dossier = await ensurePropertyDossier({ propertyId: input.id, createdBy: ctx.user.id }); const deal = await ensureDealForSoldProperty(input.id, ctx.user.id); return { ...result, sold: true as const, dossierId: dossier.id, dossierCreated: dossier.created, deal, productionStatus: dossier.created ? "queued" as const : "ready_for_production" as const }; }');
  fs.writeFileSync(routerPath, router);
}
console.log("Automatic sold-property handoff is enabled; manual selection remains available.");
