ALTER TABLE `land_dossier_audits` DROP FOREIGN KEY `land_dossier_audits_dossierId_land_dossiers_id_fk`;
--> statement-breakpoint
ALTER TABLE `land_dossier_audits` DROP FOREIGN KEY `land_dossier_audits_actorId_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `legal_procedure_versions` DROP FOREIGN KEY `legal_procedure_versions_procedureId_legal_procedures_id_fk`;
--> statement-breakpoint
ALTER TABLE `legal_template_mappings` DROP FOREIGN KEY `legal_template_mappings_procedureId_legal_procedures_id_fk`;
--> statement-breakpoint
ALTER TABLE `legal_template_mappings` DROP FOREIGN KEY `legal_template_mappings_requirementId_legal_procedure_requirements_id_fk`;
--> statement-breakpoint
ALTER TABLE `legal_template_mappings` DROP FOREIGN KEY `legal_template_mappings_templateId_legal_templates_id_fk`;
--> statement-breakpoint
ALTER TABLE `legal_template_mappings` DROP FOREIGN KEY `legal_template_mappings_reviewedBy_users_id_fk`;
--> statement-breakpoint
ALTER TABLE `land_dossier_audits` ADD CONSTRAINT `lda_dossier_fk` FOREIGN KEY (`dossierId`) REFERENCES `land_dossiers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `land_dossier_audits` ADD CONSTRAINT `lda_actor_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_procedure_versions` ADD CONSTRAINT `lpv_procedure_fk` FOREIGN KEY (`procedureId`) REFERENCES `legal_procedures`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `ltm_procedure_fk` FOREIGN KEY (`procedureId`) REFERENCES `legal_procedures`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `ltm_requirement_fk` FOREIGN KEY (`requirementId`) REFERENCES `legal_procedure_requirements`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `ltm_template_fk` FOREIGN KEY (`templateId`) REFERENCES `legal_templates`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `legal_template_mappings` ADD CONSTRAINT `ltm_reviewer_fk` FOREIGN KEY (`reviewedBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;