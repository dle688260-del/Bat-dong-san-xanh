# Ghi chú nguồn tham khảo biểu mẫu đất đai

Ngày tra cứu: 18/08/2026.

Các nguồn công khai dùng để tham khảo cấu trúc, không dùng làm căn cứ gắn nhãn Official cho file hệ thống:

1. Mẫu 01/LPTB — Tờ khai lệ phí trước bạ áp dụng đối với nhà, đất: https://luatvietnam.vn/bieu-mau/mau-so-01-lptb-to-khai-le-phi-truoc-ba-ap-dung-doi-voi-nha-dat-571-111070-article.html
   Các nhóm trường được tham khảo: kỳ tính thuế; người nộp thuế; mã số thuế/số định danh; địa chỉ; đặc điểm đất; thửa đất/tờ bản đồ; địa chỉ thửa đất; mục đích sử dụng; diện tích; nguồn gốc; giá trị chuyển giao; đồng sở hữu; giấy tờ kèm theo; chữ ký.

2. Mẫu 03/BĐS-TNCN — Tờ khai thuế TNCN đối với chuyển nhượng bất động sản: https://luatvietnam.vn/bieu-mau/mau-so-03-bds-tncn-to-khai-thue-doi-voi-ca-nhan-co-thu-nahp-tu-chuyen-nhuong-bat-dong-san-571-107512-article.html
   Các nhóm trường được tham khảo: kỳ tính thuế; bên chuyển nhượng; bên nhận chuyển nhượng; giấy tờ quyền sử dụng đất; thông tin thửa đất; loại bất động sản; giá trị chuyển nhượng; miễn thuế; hồ sơ kèm theo; cam đoan và chữ ký.

3. Mẫu đơn đăng ký biến động đất đai: https://luatvietnam.vn/bieu-mau/don-dang-ky-bien-dong-dat-dai-571-19811-article.html
   Nguồn mô tả mẫu số 18 theo bài viết và hướng dẫn công khai; hệ thống vẫn phải kiểm tra mẫu địa phương/thời điểm nộp. Các nhóm trường được tham khảo: cơ quan nhận; người sử dụng đất/chủ sở hữu; giấy tờ nhân thân/pháp nhân; địa chỉ/liên hệ; nội dung biến động; giấy tờ nộp kèm; ngày và chữ ký.

Phạm vi sử dụng: các file do hệ thống tạo là bản tham khảo/confirmed draft, để người dùng kiểm tra, chỉnh sửa, in, ký và mang đến cơ quan có thẩm quyền kiểm tra. Không gắn nhãn Official nếu chưa có file nhị phân gốc được xác minh.
