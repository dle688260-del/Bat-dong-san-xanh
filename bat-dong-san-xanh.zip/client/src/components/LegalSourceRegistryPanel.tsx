import { trpc } from "@/lib/trpc";
import { ExternalLink, Globe2, MapPinned } from "lucide-react";

export function LegalSourceRegistryPanel({ procedureId, title = "Nguồn pháp lý dùng chung" }: { procedureId: string; title?: string }) {
  const query = trpc.legalKnowledge.listDvcSources.useQuery({ procedureId }, { enabled: procedureId.trim().length >= 2 });
  const sources = query.data?.sources ?? [];
  const provinces = query.data?.provinces ?? [];

  return <section className="rounded-2xl border border-[#D7E8DC] bg-[#F7FBF7] p-4" aria-label={title}>
    <div className="flex items-start justify-between gap-3">
      <div><p className="text-xs font-black uppercase tracking-[0.12em] text-[#B38321]">Registry dùng chung</p><h3 className="mt-1 text-base font-black text-[#1F5A4A]">{title}</h3><p className="mt-1 text-xs leading-5 text-[#60766D]">Các module hồ sơ dùng cùng danh mục nguồn; URL discovery không đồng nghĩa với file Official.</p></div>
      <Globe2 className="h-5 w-5 shrink-0 text-[#1F5A4A]" />
    </div>
    {query.isLoading ? <p className="mt-3 text-xs text-[#60766D]">Đang tải registry nguồn…</p> : sources.length ? <div className="mt-3 space-y-2">{sources.slice(0, 12).map(source => <div key={source.id} className="rounded-xl border border-[#DCE9DF] bg-white p-3"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="text-xs font-black text-[#18352D]">{source.authority}</p><p className="mt-1 text-[11px] text-[#60766D]">Tầng {source.tier} · {source.scope} · {source.administrativeLevel}{source.province ? ` · ${source.province}` : ""}</p></div><span className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-black ${source.discoveryOnly ? "bg-[#FFF0C8] text-[#795C1A]" : "bg-[#DDEFE1] text-[#1F5A4A]"}`}>{source.discoveryOnly ? "Chỉ tra cứu" : "Đã đăng ký"}</span></div><a href={source.sourceUrl} target="_blank" rel="noreferrer" className="mt-2 flex items-center gap-1 break-all text-[11px] text-[#1F5A4A] underline"><ExternalLink className="h-3 w-3 shrink-0" />{source.sourceUrl}</a>{source.note && <p className="mt-1 text-[10px] leading-4 text-[#60766D]">{source.note}</p>}</div>)}</div> : <p className="mt-3 rounded-xl bg-[#FFF9EA] p-3 text-xs leading-5 text-[#6F5520]">{query.data?.notice || "Chưa có nguồn tương ứng với mã thủ tục này."}</p>}
    {provinces.length > 0 && <div className="mt-3 flex items-start gap-2 rounded-xl border border-[#DCE9DF] bg-white p-3 text-[11px] text-[#60766D]"><MapPinned className="mt-0.5 h-4 w-4 shrink-0 text-[#1F5A4A]" /><span>Coverage địa phương đã đăng ký: {provinces.slice(0, 8).join(" · ")}{provinces.length > 8 ? ` · +${provinces.length - 8} tỉnh/thành` : ""}</span></div>}
  </section>;
}
