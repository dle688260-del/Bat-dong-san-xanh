import React from "react";
import { Download, Smartphone } from "lucide-react";
import { toast } from "sonner";
import { usePwaInstallPrompt } from "@/hooks/usePwaInstallPrompt";

type PwaInstallButtonProps = {
  appName: "Website bán hàng" | "CRM";
  className?: string;
};

export function PwaInstallButton({ appName, className = "" }: PwaInstallButtonProps) {
  const { canInstall, installed, install } = usePwaInstallPrompt();

  const handleInstall = async () => {
    const outcome = await install();
    if (outcome === "accepted") {
      toast.success(`${appName} đã được cài vào điện thoại`);
      return;
    }
    if (outcome === "dismissed") {
      toast.info("Bạn có thể cài ứng dụng bất cứ lúc nào từ menu Chrome");
      return;
    }
    toast.info("Để cài app: mở menu Chrome ⋮ rồi chọn Thêm vào màn hình chính hoặc Cài đặt ứng dụng.");
  };

  return (
    <button
      type="button"
      onClick={handleInstall}
      aria-label={installed ? `${appName} đã được cài` : `Cài ${appName} vào điện thoại`}
      className={`inline-flex items-center gap-2 rounded-xl px-3 py-3 text-left font-bold transition hover:bg-[#F5F7F4] ${className}`}
    >
      {installed ? <Smartphone size={17} aria-hidden="true" /> : <Download size={17} aria-hidden="true" />}
      {installed ? `${appName} đã cài` : canInstall ? `Cài ${appName}` : `Cài ${appName} vào điện thoại`}
    </button>
  );
}
